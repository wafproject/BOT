# WAFPROJECT TOPUP - Auto Update

Repo update: `wafproject/BOT` (branch `main`).

## Membuat update baru
1. Edit source developer.
2. Naikkan `version` di `package.json` (contoh `1.1.1`).
3. Jalankan `npm run build:update`.
4. Folder `release/` akan berisi ZIP update dan `update-topup.json`.
5. Upload kedua file itu ke folder `bot-topup/` di repo GitHub `wafproject/BOT`.

`settings.js`, `database/`, `session/`, `auth/`, `node_modules/`, `temp/`, dan `backups/` tidak masuk paket update.
`settings.js` milik pembeli juga dilindungi oleh updater dan tidak ditimpa.
