const { nativeFlowMessage, quickReplyButton } = require('../../lib/zapo-message')
// plugins/unreg.js
// UNREGISTER AKUN SENDIRI + PERSETUJUAN

function normalizeNumber(input = "") {
  let n = String(input || "").replace(/[^\d]/g, "")
  if (!n) return ""
  if (n.startsWith("0")) n = "62" + n.slice(1)
  return n
}

function numberFromJid(jid = "") {
  return normalizeNumber(String(jid || "").split("@")[0])
}

module.exports = async function (m, { wafproject, db, command, text, usedPrefix }) {
  if (!["unreg", "unreg_acc", "unreg_cancel"].includes(command)) return

  const root = db.list()
  root.user ||= {}

  const prefix = usedPrefix || "."

  // data user pengirim
  const user = (root.user[m.sender] ||= {
    registered: false,
    regDate: 0,
    name: m.pushName || "Unknown",
  })

  if (typeof user.pendingUnreg === "undefined") user.pendingUnreg = null

  // =========================
  // .unreg <nomor_sendiri>
  // =========================
  if (command === "unreg") {
    const inputNum = normalizeNumber(text)
    if (!inputNum) {
      return m.reply(
        `⚠️ Format salah.\nContoh:\n${prefix}unreg 62876xxxxx`
      )
    }

    const senderNum = numberFromJid(m.sender)

    // ❌ kalau nomor tidak sama
    if (inputNum !== senderNum) {
      return m.reply("⛔ Bukan nomormu itu. Kamu hanya bisa unreg akun sendiri.")
    }

    // simpan pending
    user.pendingUnreg = {
      nomor: senderNum,
      jid: m.sender,
      username: m.pushName || "Unknown",
      ts: Date.now(),
    }
    await db.save()

    // ===== TEMPLATE 2 =====
    const textMsg =
      `🛑 *KONFIRMASI UNREGISTER*\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `📱 *Informasi Akun*\n` +
      `• Nomor WA : ${user.pendingUnreg.nomor}\n` +
      `• JID      : ${user.pendingUnreg.jid}\n` +
      `• Username : ${user.pendingUnreg.username}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `⚠️ *Dampak UNREGISTER*\n` +
      `• Akses fitur bot akan dibatasi\n` +
      `• Status akun menjadi *TIDAK TERDAFTAR*\n` +
      `• Perlu daftar ulang untuk menggunakan bot\n\n` +
      `👉 Silakan pilih:`

    return wafproject.sendMessage(
      m.chat,
      nativeFlowMessage({
        text: textMsg,
        footer: "Konfirmasi tindakan kamu",
        buttons: [
          quickReplyButton("✅ Setuju Unreg", `${prefix}unreg_acc`),
          quickReplyButton("❌ Batal", `${prefix}unreg_cancel`),
        ],
      }),
      { quote: m }
    )
  }

  // =========================
  // .unreg_acc (SETUJU)
  // =========================
  if (command === "unreg_acc") {
    const p = user.pendingUnreg
    if (!p) {
      return m.reply(`⚠️ Tidak ada unreg yang pending.\nGunakan ${prefix}unreg <nomor_kamu>`)
    }

    // safety check
    if (p.jid !== m.sender) {
      user.pendingUnreg = null
      await db.save()
      return m.reply("⛔ Data unreg tidak valid.")
    }

    user.registered = false
    user.regDate = 0
    user.pendingRegister = null
    user.pendingUnreg = null

    await db.save()

    return m.reply(
      `✅ *UNREGISTER BERHASIL*\n\n` +
      `Akun kamu sekarang *TIDAK TERDAFTAR*.\n` +
      `Silakan daftar ulang jika ingin menggunakan fitur bot kembali.`
    )
  }

  // =========================
  // .unreg_cancel (BATAL)
  // =========================
  if (command === "unreg_cancel") {
    if (!user.pendingUnreg) {
      return m.reply("⚠️ Tidak ada unreg yang pending.")
    }
    user.pendingUnreg = null
    await db.save()
    return m.reply("❌ Unregister dibatalkan.")
  }
}

// =========================
// MENU METADATA
// =========================
module.exports.help = ["unreg"]
module.exports.category = "main"
module.exports.description = "Unregister akun sendiri (dengan konfirmasi)"
module.exports.command = ["unreg", "unreg_acc", "unreg_cancel"]