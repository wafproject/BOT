/**
 * Digiflazz catalog sync (WhatsApp)
 * - Price-list disimpan ke JSON lokal
 * - Field stock/cut-off/multi/type/desc ikut disimpan
 * - Produk yang hilang dari price-list ditandai stale/nonaktif
 * - Kategori hybrid: manual dipertahankan, kategori provider yang belum ada ditambahkan otomatis
 * - Brand hybrid: alias/nama manual dipertahankan, brand provider baru ditambahkan otomatis
 */

const fs = require('fs')
const path = require('path')
const chalk = require('chalk')
const Digiflazz = require('../../lib/digiflazz')
const { mergeCatalog } = require('../../lib/topup-catalog')
const { DATABASE_DIR } = require("../../lib/project-paths")

const line = '━━━━━━━━━━━━━━━━━━'
const DB_DIR = process.env.TOPUP_DB_DIR || DATABASE_DIR
const FILE_PRODUCTS = path.join(DB_DIR, 'products.json')
const FILE_SUBRULES = path.join(DB_DIR, 'subrules.json')
const FILE_CATEGORIES = path.join(DB_DIR, 'categories.json')
const FILE_DIGI_RAW = path.join(DB_DIR, 'digi_raw.json')

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return fallback }
}

function writeJson(file, value) {
  ensureDir(path.dirname(file))
  fs.writeFileSync(file, JSON.stringify(value, null, 2))
}

function initFiles() {
  ensureDir(DB_DIR)
  if (!fs.existsSync(FILE_PRODUCTS)) writeJson(FILE_PRODUCTS, { brands: [], products: [] })
  if (!fs.existsSync(FILE_SUBRULES)) writeJson(FILE_SUBRULES, {})
  if (!fs.existsSync(FILE_CATEGORIES)) writeJson(FILE_CATEGORIES, [])
  if (!fs.existsSync(FILE_DIGI_RAW)) writeJson(FILE_DIGI_RAW, { items: [] })
}
initFiles()

const loadProducts = () => readJson(FILE_PRODUCTS, { brands: [], products: [] })
const loadSubrules = () => readJson(FILE_SUBRULES, {})
const loadRaw = () => readJson(FILE_DIGI_RAW, { items: [] })
const loadCategories = () => readJson(FILE_CATEGORIES, [])

function mergeCategoriesHybrid(existingCategories, apiItems) {
  const existing = Array.isArray(existingCategories) ? existingCategories : []
  const out = []
  const seen = new Set()

  // Data manual selalu masuk lebih dulu dan tidak diubah penulisannya.
  for (const value of existing) {
    const name = String(value || '').trim().replace(/\s+/g, ' ')
    if (!name) continue
    const key = norm(name)
    if (!key || seen.has(key)) continue
    seen.add(key)
    out.push(name)
  }

  let added = 0
  const providerCategories = []
  const providerSeen = new Set()
  for (const item of Array.isArray(apiItems) ? apiItems : []) {
    const name = String(item?.category || '').trim().replace(/\s+/g, ' ') || 'Lainnya'
    const key = norm(name)
    if (!key || providerSeen.has(key)) continue
    providerSeen.add(key)
    providerCategories.push(name)
  }

  providerCategories.sort((a, b) => a.localeCompare(b, 'id'))
  for (const name of providerCategories) {
    const key = norm(name)
    if (seen.has(key)) continue
    seen.add(key)
    out.push(name)
    added++
  }

  return {
    categories: out,
    added,
    existing: out.length - added,
    total: out.length,
    providerTotal: providerCategories.length
  }
}

function onlyNum(value) {
  return String(value || '').replace(/[^\d]/g, '')
}

function isOwnerJid(jid = '') {
  const arr = Array.isArray(global.owner) ? global.owner : []
  const me = onlyNum(jid)
  return arr.some(value => {
    if (Array.isArray(value) && value[0]) return onlyNum(value[0]) === me
    return onlyNum(value) === me
  })
}

function norm(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function tokensOf(value) {
  return norm(value).split(' ').filter(Boolean)
}

function parseCsvArgs(value, min = 2) {
  const parts = String(value || '').split(',').map(v => v.trim()).filter(Boolean)
  return parts.length >= min ? parts : null
}

function findBrandCI(products, category, alias) {
  return (products.brands || []).find(b =>
    norm(b.category) === norm(category) &&
    String(b.alias || '').toLowerCase() === String(alias || '').toLowerCase()
  ) || null
}

let syncInProgress = false
async function doSync() {
  if (syncInProgress) throw new Error('Sinkronisasi Digiflazz sedang berjalan.')
  syncInProgress = true
  try {
    const started = Date.now()
    const { products: apiItems } = await Digiflazz.priceList()
    const currentCategories = loadCategories()
    const categoryMerge = mergeCategoriesHybrid(currentCategories, apiItems)
    const merged = mergeCatalog({
      existing: loadProducts(),
      existingSubs: loadSubrules(),
      apiItems,
      syncedAt: Date.now()
    })

    writeJson(FILE_PRODUCTS, merged.products)
    writeJson(FILE_SUBRULES, merged.subrules)
    writeJson(FILE_CATEGORIES, categoryMerge.categories)
    writeJson(FILE_DIGI_RAW, merged.digiRaw)

    return {
      ...merged.stats,
      categories: categoryMerge.total,
      addedCategories: categoryMerge.added,
      existingCategories: categoryMerge.existing,
      durationMs: Date.now() - started
    }
  } finally {
    syncInProgress = false
  }
}

function tplSinkron(result) {
  return `✅ *SINKRON DIGIFLAZZ SELESAI*
${line}
📂 *Kategori*          : ${result.categories} ${result.addedCategories ? `(+${result.addedCategories} baru)` : ''}
🏷️ *Brand*             : ${result.brands} ${result.addedBrands ? `(+${result.addedBrands} baru)` : ''}
📦 *Produk provider*   : ${result.products}
✅ *Aktif*              : ${result.active}
🗃️ *Produk lama tersimpan* : ${result.stale}
⏱️ *Durasi*            : ${result.durationMs} ms
${line}
Produk lama yang sudah tidak ada di price-list terbaru tetap disimpan untuk riwayat, tetapi tidak ditampilkan dan tidak bisa diorder.`
}

function getSyncErrorInfo(error) {
  if (typeof Digiflazz.explainError === 'function') return Digiflazz.explainError(error)
  return {
    category: 'unknown',
    reason: String(error?.message || error || 'Sinkronisasi gagal.'),
    suggestion: 'Katalog lama tetap digunakan. Coba sinkron kembali beberapa saat lagi.',
    http: Number(error?.status || 0) || 0,
    rc: '',
    providerMessage: '',
    receivedType: '',
    responsePreview: ''
  }
}

function tplSyncError(error) {
  const info = getSyncErrorInfo(error)
  const details = []
  if (info.http) details.push(`🌐 *HTTP*              : ${info.http}`)
  if (info.rc) details.push(`🔢 *RC Digiflazz*      : ${info.rc}`)
  if (info.providerMessage) details.push(`💬 *Pesan Digiflazz*   : ${info.providerMessage}`)
  if (info.receivedType) details.push(`🧩 *Tipe data diterima*: ${info.receivedType}`)
  if (info.responsePreview && !info.providerMessage) {
    details.push(`🔎 *Ringkasan respons* : ${info.responsePreview.slice(0, 220)}`)
  }

  return `❌ *SINKRONISASI DIGIFLAZZ GAGAL*
${line}
📌 ${info.reason}
${details.length ? details.join('\n') + '\n' : ''}🛡️ ${info.suggestion}
${line}`
}

function logAutoSyncSuccess(result, intervalMs) {
  const minutes = Math.max(1, Math.round(intervalMs / 60000))
  console.log(chalk.hex('#45B7D1').bold('\n🔄 Auto-sync Digiflazz...'))
  console.log(chalk.hex('#00FF7F')('✅ Sinkronisasi berhasil'))
  console.log(chalk.hex('#96CEB4')(`📂 Kategori: ${result.categories}${result.addedCategories ? ` | +${result.addedCategories} baru` : ''}`))
  console.log(chalk.hex('#96CEB4')(`🏷️ Brand: ${result.brands}${result.addedBrands ? ` | +${result.addedBrands} baru` : ''}`))
  console.log(chalk.hex('#96CEB4')(`📦 Produk aktif: ${result.active}`))
  console.log(chalk.hex('#FFD93D')(`🗃️ Produk lama tersimpan: ${result.stale}`))
  console.log(chalk.hex('#96CEB4')(`⏱️ Sinkron berikutnya: ±${minutes} menit`))
}

function logAutoSyncFailure(error, intervalMs) {
  const info = getSyncErrorInfo(error)
  const minutes = Math.max(1, Math.round(intervalMs / 60000))
  console.log(chalk.hex('#45B7D1').bold('\n🔄 Auto-sync Digiflazz...'))
  console.log(chalk.red('❌ Sinkronisasi gagal'))
  console.log(chalk.yellow(`📌 ${info.reason}`))
  if (info.http) console.log(chalk.gray(`🌐 HTTP: ${info.http}`))
  if (info.rc) console.log(chalk.gray(`🔢 RC Digiflazz: ${info.rc}`))
  if (info.providerMessage) console.log(chalk.gray(`💬 Pesan Digiflazz: ${info.providerMessage}`))
  if (info.receivedType) console.log(chalk.gray(`🧩 Tipe data diterima: ${info.receivedType}`))
  if (info.responsePreview && !info.providerMessage) {
    console.log(chalk.gray(`🔎 Respons: ${info.responsePreview.slice(0, 240)}`))
  }
  console.log(chalk.hex('#FFD93D')(`🛡️ ${info.suggestion}`))
  if (info.category !== 'rate_limit') {
    console.log(chalk.hex('#96CEB4')(`⏱️ Auto-sync terjadwal berikutnya tetap ±${minutes} menit`))
  }
}

async function autosub({ category, brandAlias, subAlias, keyword }) {
  const products = loadProducts()
  const raw = loadRaw()
  const subrules = loadSubrules()
  const brand = findBrandCI(products, category, brandAlias)
  if (!brand) throw new Error(`Brand .${String(brandAlias).toUpperCase()} pada kategori ${category} tidak ditemukan.`)

  const kw = tokensOf(keyword)
  const selectedCodes = new Set((raw.items || []).filter(item => {
    if (norm(item.category) !== norm(brand.category)) return false
    if (norm(item.brand) !== norm(brand.name)) return false
    const blob = norm([item.name, item.type, item.subsuggest, item.desc].join(' '))
    return kw.every(token => blob.includes(token))
  }).map(item => String(item.code || '').toUpperCase()).filter(Boolean))

  if (!selectedCodes.size) return { selected: 0, changed: 0 }

  let changed = 0
  for (const product of products.products || []) {
    if (!selectedCodes.has(String(product.code || '').toUpperCase())) continue
    product.subAlias = String(subAlias || '').toUpperCase()
    product.meta = { ...(product.meta || {}), manual_sub_alias: true }
    changed++
  }

  const key = String(brand.alias || '').toLowerCase()
  subrules[key] ||= { subs: {}, rules: [] }
  subrules[key].subs ||= {}
  subrules[key].rules ||= []
  subrules[key].subs[String(subAlias).toUpperCase()] ||= { name: String(subAlias).toUpperCase() }

  writeJson(FILE_PRODUCTS, products)
  writeJson(FILE_SUBRULES, subrules)
  return { selected: selectedCodes.size, changed }
}

let handler = async (m, { wafproject, db, args, usedPrefix, command, isOwner, isROwner }) => {
  const conn = wafproject
  const say = text => conn.sendMessage(m.chat, { text: String(text) }, { quoted: m })

  const ownerAllowed = Boolean(
    isOwner || isROwner || isOwnerJid(m.sender || m.key?.participant || m.chat)
  )
  if (!ownerAllowed) return say('Khusus owner.')

  const cmd = String(command || '').toLowerCase()
  const argText = (args || []).join(' ').trim()

  if (cmd === 'sinkron') {
    await say('⏳ Sinkronisasi katalog Digiflazz...')
    try {
      const result = await doSync()
      try { await db?.save?.() } catch (error) { console.error("[ERROR][commands/topup/digiflazz-sync.js]", error?.message || error) }
      return say(tplSinkron(result))
    } catch (error) {
      return say(tplSyncError(error))
    }
  }

  if (cmd === 'showraw') {
    const items = loadRaw().items || []
    if (!items.length) return say('RAW kosong. Jalankan *sinkron* dulu.')

    let filtered = items
    const tokens = tokensOf(argText)
    if (tokens.length) {
      filtered = items.filter(item => {
        const blob = norm([item.category, item.brand, item.name, item.type, item.desc].join(' '))
        return tokens.every(token => blob.includes(token))
      })
    }
    if (!filtered.length) return say('⚠️ Tidak ada data yang cocok di RAW.')

    let out = `📄 *RAW DIGIFLAZZ*\n${line}`
    for (const item of filtered.slice(0, 20)) {
      const stock = item.unlimited_stock ? '∞' : Number(item.stock || 0)
      out += `\n• ${item.category} › ${item.brand}\n  └─ ${item.code} — ${item.name} [${item.type || 'Umum'}] | stok ${stock}`
    }
    if (filtered.length > 20) out += `\n… dan ${filtered.length - 20} lainnya.`
    return say(out)
  }

  if (cmd === 'autosub') {
    const parts = parseCsvArgs(argText, 4)
    if (!parts) {
      return say(`Format: *${usedPrefix}autosub <Kategori>, <AliasBrand>, <AliasTipe>, <kata kunci>*`)
    }
    const [category, brandAlias, subAlias, keyword] = parts
    try {
      const result = await autosub({ category, brandAlias, subAlias, keyword })
      if (!result.selected) return say('⚠️ Tidak ada item RAW yang cocok dengan kata kunci tersebut.')
      return say(`✅ Autosub selesai.\n• RAW cocok: *${result.selected}*\n• Produk dipindahkan: *${result.changed}*\n• Alias tipe: *${String(subAlias).toUpperCase()}*\n\nAlias manual ini akan dipertahankan saat sinkron berikutnya.`)
    } catch (error) {
      return say(`❌ Autosub gagal: ${error?.message || error}`)
    }
  }
}

handler.help = ['sinkron', 'showraw <kata>', 'autosub <cat>, <aliasbrand>, <aliastipe>, <keyword>']
handler.category = ['owner']
handler.command = /^(sinkron|showraw|autosub)$/i
handler.rowner = true
handler.register = false
handler.doSync = doSync

function clearAutoSyncJob() {
  const job = global.__WAF_DFZ_SYNC_JOB__
  if (!job) return
  try { if (job.startup) clearTimeout(job.startup) } catch (error) { console.error("[ERROR][commands/topup/digiflazz-sync.js]", error?.message || error) }
  try { if (job.interval) clearInterval(job.interval) } catch (error) { console.error("[ERROR][commands/topup/digiflazz-sync.js]", error?.message || error) }
  delete global.__WAF_DFZ_SYNC_JOB__
}

function startAutoSyncJob() {
  // Hot-reload plugin tidak dihitung sebagai restart bot.
  // Startup sync hanya dijalankan sekali per proses agar save plugin tidak
  // memicu request price-list tambahan.
  const hadExistingJob = Boolean(global.__WAF_DFZ_SYNC_JOB__)
  clearAutoSyncJob()

  const enabled = !/^(0|false|off|no)$/i.test(String(process.env.DIGIFLAZZ_SYNC_ENABLED ?? global.dfzSyncEnabled ?? 'true'))
  if (!enabled) return

  const syncAtStartup = !/^(0|false|off|no)$/i.test(String(process.env.DIGIFLAZZ_SYNC_AT_STARTUP ?? global.dfzSyncAtStartup ?? 'true'))
  const intervalMs = Math.max(
    15 * 60 * 1000,
    Number(process.env.DIGIFLAZZ_SYNC_INTERVAL_MS || global.dfzSyncIntervalMs || 30 * 60 * 1000)
  )

  const run = async () => {
    try {
      const result = await doSync()
      logAutoSyncSuccess(result, intervalMs)
    } catch (error) {
      logAutoSyncFailure(error, intervalMs)
    }
  }

  // Tetap langsung cek saat proses bot benar-benar start/restart.
  // Tidak memakai random delay. Delay kecil hanya memberi waktu startup inti selesai.
  const startup = syncAtStartup && !hadExistingJob
    ? setTimeout(() => void run(), Math.max(1000, Number(global.dfzSyncStartupDelayMs || 3000)))
    : null
  if (startup?.unref) startup.unref()

  const interval = setInterval(() => void run(), intervalMs)
  if (interval?.unref) interval.unref()

  global.__WAF_DFZ_SYNC_JOB__ = { startup, interval, intervalMs }
}

startAutoSyncJob()

module.exports = handler
