// commands/topup/depo.js
// Deposit saldo via PayKita QRIS
// Command: .depo <nominal> / .deposit <nominal>

const fs = require('fs')
const path = require('path')
const QRCode = require('qrcode')
const PayKita = require('../../lib/paykita')
const BalanceAudit = require('../../lib/balance-audit')
const { DATABASE_DIR } = require("../../lib/project-paths")

const DB_DIR = DATABASE_DIR
const FILE_SALDO = path.join(DB_DIR, 'saldousers.json')
const FILE_PENDING = path.join(DB_DIR, 'paykita_deposit_pending.json')

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return fallback }
}

function writeJson(file, value) {
  ensureDir(path.dirname(file))
  const temp = `${file}.tmp`
  fs.writeFileSync(temp, JSON.stringify(value, null, 2))
  fs.renameSync(temp, file)
}

;(function init() {
  ensureDir(DB_DIR)
  if (!fs.existsSync(FILE_SALDO)) writeJson(FILE_SALDO, {})
  if (!fs.existsSync(FILE_PENDING)) writeJson(FILE_PENDING, {})
})()

const loadSaldo = () => readJson(FILE_SALDO, {})
const saveSaldo = (value) => writeJson(FILE_SALDO, value)
const loadPending = () => readJson(FILE_PENDING, {})
const savePending = (value) => writeJson(FILE_PENDING, value)

function getSaldo(number) {
  return Number(loadSaldo()[number] || 0)
}

function setSaldo(number, value) {
  const db = loadSaldo()
  db[number] = Math.max(0, Math.round(Number(value) || 0))
  saveSaldo(db)
  return db[number]
}

function addSaldo(number, amount) {
  return setSaldo(number, getSaldo(number) + Number(amount || 0))
}

function getPending(number) {
  return loadPending()[number] || null
}

function setPending(number, value) {
  const db = loadPending()
  db[number] = value
  savePending(db)
  return value
}

function clearPending(number) {
  const db = loadPending()
  delete db[number]
  savePending(db)
}

const fmtRp = (value) => 'Rp ' + Math.round(Number(value) || 0).toLocaleString('id-ID')
const onlyNum = (value) => String(value || '').replace(/[^\d]/g, '')
const jidNum = (jid) => onlyNum(String(jid || '').replace(/:\d+(?=@|$)/g, '').split('@')[0] || '')
const line = '━━━━━━━━━━━━━━━━━━'
const PAYKITA_TTL_SECONDS = Math.max(60, Number(global.paykitaTtlSeconds || 900))
const PAYKITA_POLL_MS = Math.max(2000, Number(global.paykitaPollMs || 5000))

function createReference(prefix, userNumber) {
  const userTail = String(userNumber || '').slice(-8)
  const random = Math.random().toString(36).slice(2, 7).toUpperCase()
  return `${prefix}-${userTail}-${Date.now()}-${random}`
}

function captionDeposit({ orderId, amount, payAmount, expiresIn, feeAmount, uniqueCode }) {
  const minutes = Math.max(1, Math.ceil(Number(expiresIn || 0) / 60))
  return `🧾 *DEPOSIT SALDO* 🧾
${line}
🆔 *Order ID*  : ${orderId}
💰 *Nominal*   : ${fmtRp(amount)}
📊 *Bayar*     : ${fmtRp(payAmount)}
${Number(feeAmount || 0) > 0 ? `💸 *Fee*       : ${fmtRp(feeAmount)}\n` : ''}${Number(uniqueCode || 0) > 0 ? `🔢 *Kode Unik* : ${uniqueCode}\n` : ''}⏳ *Expired*   : ±${minutes} menit
${line}

⚠️ Bayar sesuai nominal yang tampil agar pembayaran terdeteksi otomatis.`
}

function orderAmountsMatch(order, pending) {
  if (Number(order.baseAmount) > 0 && Number(order.baseAmount) !== Number(pending.amount)) return false
  if (Number(order.payAmount) > 0 && Number(order.payAmount) !== Number(pending.payAmount)) return false
  return true
}

async function cancelSilently(orderId) {
  try {
    await PayKita.cancelOrder(orderId)
    return true
  } catch (error) {
    console.error("[ERROR][commands/topup/depo.js]", error?.message || error)
    return false
  }
}

function startPolling({ conn, userNumber, chatId, messageKey, orderId, expiresAt }) {
  global.__WAF_PAYKITA_DEPOSIT_POLLERS__ ||= new Map()
  const pollers = global.__WAF_PAYKITA_DEPOSIT_POLLERS__
  if (pollers.has(String(orderId))) return pollers.get(String(orderId))

  let finished = false
  let checking = false

  const finish = () => {
    if (finished) return false
    finished = true
    clearInterval(timer)
    pollers.delete(String(orderId))
    return true
  }

  const removeQrMessage = async () => {
    try { if (messageKey) await conn.sendMessage(chatId, { delete: messageKey }) } catch (error) { console.error("[ERROR][commands/topup/depo.js]", error?.message || error) }
  }

  // Jika TTL habis dan status tidak dapat diverifikasi, hentikan transaksi lokal.
  // Tidak ada lagi status REVIEW/recovery untuk deposit kedaluwarsa.
  const expireUnverifiedDeposit = async (error) => {
    const latest = getPending(userNumber)
    if (!latest || latest.orderId !== orderId) return false
    if (!finish()) return true

    if (global.paykitaDebug) {
      console.log('[PAYKITA DEPOSIT EXPIRED UNVERIFIED]', orderId, error?.message || error)
    }

    await removeQrMessage()
    clearPending(userNumber)
    try {
      await conn.sendMessage(chatId, { text: '⏰ Waktu pembayaran habis.' }, {})
    } catch (notifyError) {
      console.error('[PAYKITA DEPOSIT EXPIRED NOTIFY ERROR]', notifyError?.message || notifyError)
    }
    return true
  }

  const tick = async () => {
    if (finished || checking) return
    checking = true

    try {
      const response = await PayKita.getOrder(orderId)
      const order = PayKita.normalizeOrder(response)
      const pending = getPending(userNumber)

      if (!pending || pending.orderId !== orderId) {
        finish()
        return
      }

      pending.lastStatus = order.status
      pending.lastCheck = Date.now()
      pending.rawStatusLast = order.raw
      pending.verifyFailures = 0
      pending.lastVerificationError = ''
      setPending(userNumber, pending)

      if (PayKita.isPaidStatus(order.status)) {
        if (!orderAmountsMatch(order, pending)) {
          if (!finish()) return

          pending.status = 'REVIEW'
          pending.reviewReason = 'PAYKITA_AMOUNT_MISMATCH'
          pending.reviewAt = Date.now()
          pending.receivedBaseAmount = Number(order.baseAmount || 0)
          pending.receivedPayAmount = Number(order.payAmount || 0)
          setPending(userNumber, pending)

          console.error('[PAYKITA DEPOSIT] nominal pembayaran tidak cocok:', {
            orderId,
            expectedBaseAmount: Number(pending.amount || 0),
            receivedBaseAmount: Number(order.baseAmount || 0),
            expectedPayAmount: Number(pending.payAmount || 0),
            receivedPayAmount: Number(order.payAmount || 0)
          })

          await removeQrMessage()
          await conn.sendMessage(chatId, {
            text:
              '⚠️ Pembayaran terdeteksi, tetapi nominal dari PayKita tidak cocok dengan invoice.\n' +
              'Deposit ditahan untuk pemeriksaan agar saldo tidak masuk ganda.\n' +
              `🆔 Order ID: ${orderId}`
          }, {})
          return
        }

        if (!finish()) return
        await removeQrMessage()

        const latest = getPending(userNumber)
        if (!latest || latest.orderId !== orderId || latest.status !== 'PENDING') return

        latest.status = 'PROCESSING'
        latest.paidAt = Date.now()
        setPending(userNumber, latest)

        const mutation = BalanceAudit.applyMutation({
          user: userNumber,
          delta: Number(latest.amount || 0),
          type: 'deposit_credit',
          source: 'paykita_deposit',
          reference: orderId,
          note: 'Deposit PayKita terbayar',
          idempotencyKey: `paykita-deposit:${orderId}`
        })
        if (!mutation.ok) throw new Error('Gagal menambahkan saldo deposit.')

        const userJid = `${userNumber}@s.whatsapp.net`
        try {
          await conn.sendMessage(chatId, {
            text:
              `✅ *Deposit Berhasil*\n` +
              `Saldo @${userNumber} bertambah *${fmtRp(latest.amount)}*.\n\n` +
              `💳 Saldo sekarang: *${fmtRp(getSaldo(userNumber))}*`,
            mentions: [userJid]
          }, {})
          latest.userNotified = true
          setPending(userNumber, latest)
          clearPending(userNumber)
        } catch (notifyError) {
          latest.status = 'PROCESSING'
          latest.notificationError = String(notifyError?.message || notifyError)
          latest.lastNotificationAttempt = Date.now()
          setPending(userNumber, latest)
          console.error('[PAYKITA DEPOSIT NOTIFY ERROR]', notifyError?.message || notifyError)
        }
        return
      }

      if (PayKita.isFinalFailStatus(order.status)) {
        if (!finish()) return
        await removeQrMessage()
        const latest = getPending(userNumber)
        if (latest?.orderId === orderId) clearPending(userNumber)
        await conn.sendMessage(chatId, { text: `⏰ Transaksi berakhir: *${order.status}*` }, {})
        return
      }

      if (Date.now() >= expiresAt) {
        // Status terakhir masih PENDING. Batalkan di PayKita terlebih dahulu.
        // Pending lokal baru boleh dibersihkan jika cancel benar-benar berhasil.
        try {
          await PayKita.cancelOrder(orderId)
        } catch (cancelError) {
          if (global.paykitaDebug) console.log('[PAYKITA DEPOSIT CANCEL VERIFY ERROR]', cancelError?.message || cancelError)
          await expireUnverifiedDeposit(cancelError)
          return
        }

        if (!finish()) return
        await removeQrMessage()
        const latest = getPending(userNumber)
        if (latest?.orderId === orderId) clearPending(userNumber)
        await conn.sendMessage(chatId, { text: '⏰ Waktu pembayaran habis.' }, {})
      }
    } catch (error) {
      if (global.paykitaDebug) console.log('[PAYKITA DEPOSIT POLL ERROR]', error?.message || error)
      if (Date.now() >= expiresAt) {
        await expireUnverifiedDeposit(error)
      }
    } finally {
      checking = false
    }
  }

  const timer = setInterval(tick, PAYKITA_POLL_MS)
  pollers.set(String(orderId), timer)
  void tick()
  return timer
}


async function recoverPendingPayKitaDeposits(conn) {
  const pendingDb = loadPending()
  const rows = Object.entries(pendingDb || {})
  let resumed = 0
  let credited = 0
  let cleared = 0

  for (const [userNumber, pending] of rows) {
    if (!pending?.orderId) continue
    const status = String(pending.status || 'PENDING').toUpperCase()
    const chatId = pending.chatId || `${userNumber}@s.whatsapp.net`

    try {
      if (status === 'PROCESSING') {
        const mutation = BalanceAudit.applyMutation({
          user: userNumber,
          delta: Number(pending.amount || 0),
          type: 'deposit_credit',
          source: 'paykita_deposit',
          reference: pending.orderId,
          note: 'Lanjutkan deposit PayKita setelah restart',
          idempotencyKey: `paykita-deposit:${pending.orderId}`
        })

        if (!mutation.ok) {
          pending.processingError = mutation.reason || 'Gagal melanjutkan saldo deposit.'
          setPending(userNumber, pending)
          continue
        }

        const userJid = `${userNumber}@s.whatsapp.net`
        await conn.sendMessage(chatId, {
          text:
            `✅ *Deposit Berhasil*\n` +
            `Saldo @${userNumber} bertambah *${fmtRp(pending.amount)}*.\n\n` +
            `💳 Saldo sekarang: *${fmtRp(getSaldo(userNumber))}*`,
          mentions: [userJid]
        }, {})

        clearPending(userNumber)
        credited++
        resumed++
        continue
      }

      // Sisa data versi lama: REVIEW status-unverified dibuang tanpa recovery/notifikasi.
      if (status === 'REVIEW' && pending.reviewReason === 'PAYKITA_STATUS_UNVERIFIED') {
        await cancelSilently(pending.orderId)
        clearPending(userNumber)
        cleared++
        continue
      }

      if (status === 'PENDING') {
        const expiresAt = Number(pending.expiresAt || 0)
        if (!(expiresAt > Date.now())) {
          await cancelSilently(pending.orderId)
          clearPending(userNumber)
          cleared++
          continue
        }

        startPolling({
          conn,
          userNumber,
          chatId,
          messageKey: null,
          orderId: pending.orderId,
          expiresAt
        })
        resumed++
      }
    } catch (error) {
      console.error(`[PAYKITA DEPOSIT STARTUP] ${pending.orderId}:`, error?.message || error)
    }
  }

  return { total: rows.length, resumed, credited, cleared }
}

global.__WAF_RECOVER_PAYKITA_DEPOSITS__ = recoverPendingPayKitaDeposits

let handler = async (m, { wafproject, args, usedPrefix, command }) => {
  const conn = wafproject
  if (!conn) return

  const say = (text) => conn.sendMessage(m.chat, { text: String(text) }, { quoted: m })
  const cmd = String(command || '').toLowerCase()
  if (!['depo', 'deposit'].includes(cmd)) return

  if (!args?.length) {
    return say(
`💳 *DEPOSIT SALDO* 💳
─────────────────────
📌 *Format:* ${usedPrefix}${cmd} <nominal>
🧾 *Contoh:* ${usedPrefix}${cmd} 100000
─────────────────────
⏳ Setelah dibayar, saldo masuk otomatis.`
    )
  }

  const userNumber = jidNum(m.sender || m.key?.participant || m.chat)
  const amount = Number(onlyNum(args.join(' '))) || 0

  if (amount < 1000) return say('❌ Nominal terlalu kecil (minimal Rp1.000).')

  let existing = getPending(userNumber)
  let existingStatus = String(existing?.status || '').toUpperCase()
  let existingValid = existingStatus === 'PENDING' && Number(existing?.expiresAt || 0) > Date.now()

  // Bersihkan sisa REVIEW status-unverified dari versi lama tanpa recovery/notifikasi.
  if (existing && existingStatus === 'REVIEW' && existing.reviewReason === 'PAYKITA_STATUS_UNVERIFIED') {
    if (existing.orderId) await cancelSilently(existing.orderId)
    clearPending(userNumber)
    existing = null
    existingStatus = ''
    existingValid = false
  }

  if (existing && ['PROCESSING', 'REVIEW'].includes(existingStatus)) {
    return say(
      `⚠️ Kamu masih punya deposit *${existingStatus}*.\n` +
      `🆔 Order ID: ${existing.orderId || '-'}\n` +
      (existingStatus === 'PROCESSING'
        ? 'Pembayaran sudah terdeteksi dan saldo sedang diproses.\n'
        : 'Deposit sedang ditahan untuk pemeriksaan nominal.\n') +
      'Tunggu transaksi tersebut selesai sebelum membuat deposit baru.'
    )
  }

  // Deposit PENDING yang kedaluwarsa selalu dibersihkan lokal.
  // Gagal cancel di API tidak lagi membuat REVIEW/recovery.
  if (existing && existingStatus === 'PENDING' && !existingValid) {
    if (existing.orderId) await cancelSilently(existing.orderId)
    clearPending(userNumber)
    existing = null
    existingStatus = ''
    existingValid = false
  }

  if (existingValid) {
    return say(
      `⏳ Kamu masih punya deposit *PENDING*.\n` +
      `🆔 Order ID: ${existing.orderId}\n` +
      `💰 Nominal: ${fmtRp(existing.amount)}\n` +
      `📊 Bayar: ${fmtRp(existing.payAmount)}\n` +
      'Tunggu sampai pembayaran selesai atau kedaluwarsa.'
    )
  }

  try {
    const reference = createReference('DEP', userNumber)
    const raw = await PayKita.createOrder({
      baseAmount: amount,
      reference,
      ttlSeconds: PAYKITA_TTL_SECONDS,
      redirectUrl: global.paykitaRedirectUrl || undefined
    })
    const order = PayKita.normalizeOrder(raw)

    if (!order.id) throw new Error('PayKita tidak mengembalikan order id.')
    if (!order.qris && !order.checkoutUrl) throw new Error('PayKita tidak mengembalikan QRIS atau checkout URL.')

    const expiresIn = order.expiresIn > 0 ? order.expiresIn : PAYKITA_TTL_SECONDS
    const payAmount = order.payAmount > 0 ? order.payAmount : amount
    const startedAt = Date.now()
    const expiresAt = startedAt + (expiresIn * 1000)

    setPending(userNumber, {
      status: 'PENDING',
      orderId: order.id,
      reference,
      chatId: m.chat,
      amount,
      payAmount,
      feeAmount: order.feeAmount,
      uniqueCode: order.uniqueCode,
      checkoutUrl: order.checkoutUrl,
      startedAt,
      expiresAt,
      lastStatus: order.status || 'pending',
      rawCreate: order.raw
    })

    const caption = captionDeposit({
      orderId: order.id,
      amount,
      payAmount,
      expiresIn,
      feeAmount: order.feeAmount,
      uniqueCode: order.uniqueCode
    })

    let sent
    try {
      if (order.qris) {
        const image = await QRCode.toBuffer(order.qris, {
          type: 'png',
          errorCorrectionLevel: 'H',
          width: 900
        })
        sent = await conn.sendMessage(m.chat, { image, caption }, { quoted: m })
      } else {
        sent = await conn.sendMessage(m.chat, {
          text: `${caption}\n\n🔗 *Link Pembayaran:*\n${order.checkoutUrl}`
        }, { quoted: m })
      }
    } catch (error) {
      // Jangan biarkan order PayKita aktif tanpa QR/link. Jika cancel gagal,
      // pending tetap disimpan dan dipantau sampai status provider final.
      const cancelled = await cancelSilently(order.id)
      const latest = getPending(userNumber)
      if (latest?.orderId === order.id) {
        if (cancelled) {
          clearPending(userNumber)
        } else {
          latest.deliveryFailed = true
          latest.deliveryError = String(error?.message || error)
          setPending(userNumber, latest)
          startPolling({
            conn,
            userNumber,
            chatId: m.chat,
            messageKey: null,
            orderId: order.id,
            expiresAt
          })
        }
      }
      throw new Error(`Gagal mengirim QRIS PayKita: ${error?.message || error}`)
    }

    startPolling({
      conn,
      userNumber,
      chatId: m.chat,
      messageKey: sent?.key,
      orderId: order.id,
      expiresAt
    })
  } catch (error) {
    return say('❌ Gagal membuat invoice deposit: ' + (error?.message || error))
  }
}

handler.help = ['depo <nominal>', 'deposit <nominal>']
handler.category = ['topup']
handler.command = /^(depo|deposit)$/i
handler.register = false

module.exports = handler
