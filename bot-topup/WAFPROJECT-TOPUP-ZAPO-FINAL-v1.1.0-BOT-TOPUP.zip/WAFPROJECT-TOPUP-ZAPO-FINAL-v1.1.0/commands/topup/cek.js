// Topup — CEKSTATUS + CEK
const fs = require('fs')
const path = require('path')
const Digiflazz = require('../../lib/digiflazz')
const { availability, typeDisplayName } = require('../../lib/topup-product-utils')
const { DATABASE_DIR } = require("../../lib/project-paths")

const DB_DIR = process.env.TOPUP_DB_DIR || DATABASE_DIR
const FILE_PRODUCTS = path.join(DB_DIR, 'products.json')
const FILE_PROFIT = path.join(DB_DIR, 'profit.json')
const FILE_TX = path.join(DB_DIR, 'tx.json')
const line = '━━━━━━━━━━━━━━━━━━'
const fmtRp = n => 'Rp ' + Math.round(Number(n) || 0).toLocaleString('id-ID')

function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return fallback } }
const loadProducts = () => readJson(FILE_PRODUCTS, { brands: [], products: [] })
const loadProfit = () => readJson(FILE_PROFIT, { bronze: 1.5, silver: 1, gold: 0.5, owner: 0 })
const loadTx = () => readJson(FILE_TX, { list: [] })

function priceByRole(base) {
  base = Number(base) || 0
  const p = loadProfit()
  return {
    bronze: base + Math.round(base * (Number(p.bronze || 0) / 100)),
    silver: base + Math.round(base * (Number(p.silver || 0) / 100)),
    gold: base + Math.round(base * (Number(p.gold || 0) / 100))
  }
}

function sameBrand(p, brand) {
  const pa = String(p.brandAlias || '').toLowerCase()
  if (pa) return pa === String(brand.alias || '').toLowerCase()
  return String(p.brand || '').toLowerCase() === String(brand.name || '').toLowerCase()
}

function renderKeteranganBlock(prefix) {
  const pfx = String(prefix || '.')
  return `💬  *CARA ORDER :*\n* ${pfx}order <kode> <tujuan>\n* ${pfx}order ml5 123654672 (0987)\n* ${pfx}order dna10 085706676534`
}

function statusLabel(status) {
  const s = String(status || '').toLowerCase()
  if (s === 'success') return 'Sukses'
  if (s === 'failed') return 'Gagal'
  if (s === 'pending' || s === 'processing') return 'Pending'
  return status || '-'
}

async function handler(m, ctx) {
  const conn = ctx?.wafproject
  if (!conn) return
  const say = text => conn.sendMessage(m.chat, { text: String(text) }, { quoted: m })
  const command = String(ctx?.command || '').toLowerCase()
  const args = Array.isArray(ctx?.args) ? ctx.args : []
  const prefix = String(ctx?.prefix || ctx?.usedPrefix || '.')

  if (command === 'cekstatus') {
    const ref = String(args[0] || '').trim()
    if (!ref) return say('Format: *cekstatus <ref_id>*')

    let tx = (loadTx().list || []).find(row => String(row.ref_id || '') === ref)
    if (!tx) {
      return say('❌ Ref ID tidak ditemukan di riwayat bot. Untuk prepaid, status Digiflazz tidak boleh dicek hanya dengan ref_id karena SKU dan tujuan transaksi juga diperlukan.')
    }

    if (['pending', 'processing'].includes(String(tx.status || '').toLowerCase())) {
      try {
        const manager = global.__WAF_TOPUP_DFZ__
        if (manager?.checkPendingDfz) await manager.checkPendingDfz(ref)
      } catch (error) { console.error("[ERROR][commands/topup/cek.js]", error?.message || error) }
      tx = (loadTx().list || []).find(row => String(row.ref_id || '') === ref) || tx
    }

    return say(
      `🔴 *STATUS TRANSAKSI*\n${line}\n` +
      `🆔 *RefID* : ${ref}\n` +
      `📊 *Status* : ${statusLabel(tx.status)}\n` +
      `🔢 *Kode* : ${tx.buyer_sku_code || '-'}\n` +
      `🎯 *Tujuan* : ${tx.customer_no || tx.tujuan || '-'}\n` +
      `📄 *SN* : ${tx.sn || '-'}\n` +
      `🔖 *RC* : ${tx.response_code || '-'}\n` +
      `💰 *Saldo Digi terakhir* : ${tx.buyer_last_saldo != null ? fmtRp(tx.buyer_last_saldo) : '-'}\n` +
      `📝 *Keterangan* : ${tx.provider_message || tx.provider_error || '-'}\n${line}`
    )
  }

  if (command === 'cek') {
    const products = loadProducts()
    const kode = String(args[0] || '').trim()
    if (!kode) return say('Format: *cek <kode>*')
    const p = (products.products || []).find(x => String(x.code || '').toUpperCase() === kode.toUpperCase())
    if (!p) return say(`⚠️ Kode *${kode}* tidak ditemukan.`)

    const base = Number(p.price || 0)
    const { bronze, silver, gold } = priceByRole(base)
    const av = availability(p)
    const brandObj = (products.brands || []).find(b => sameBrand(p, b))
    const brandName = brandObj?.name || p.brand || 'Produk'
    const tipe = typeDisplayName(p?.meta?.provider_type || p?.type || p?.subAlias || 'Umum')

    return say(
      `${renderKeteranganBlock(prefix)}\n\n` +
      `┏━━━『 *${brandName}* 』━━━⌬\n\n` +
      `🛒 *${String(p.name || kode).toUpperCase()}*\n` +
      `> 🔏 Kode : \`${String(p.code).toUpperCase()}\`\n` +
      `> 📦 Tipe : *${tipe}*\n` +
      `> 🥉 Bronze : *${fmtRp(bronze)}*\n` +
      `> 🥈 Silver : *${fmtRp(silver)}*\n` +
      `> 🥇 Gold : *${fmtRp(gold)}*\n` +
      `> ${av.available ? '✅' : '⛔'} Status : *${av.available ? 'Tersedia' : 'Tidak Tersedia'}*` +
      `${av.available ? '' : `\n> ⚠️ ${av.reason}`}`
    )
  }
}

handler.help = ['cekstatus', 'cek']
handler.category = ['topup']
handler.command = /^(cekstatus|cek)$/i
handler.register = false
module.exports = handler
