// commands/topup/cekriwayat.js
// ✨ Topup — CEK RIWAYAT (per buyer, per bulan) — prioritas /database/tx.json
// CJS version (cocok struktur bot handler)

const fs = require('fs')
const path = require('path')
const { DATABASE_DIR } = require("../../lib/project-paths")

const DB_DIR = DATABASE_DIR
const PRIORITY_FILE = path.join(DB_DIR, 'tx.json')
const FILE_PRODUCTS = path.join(DB_DIR, 'products.json')

const TX_CANDIDATES = [
  'transactions.json', 'orders.json', 'riwayat.json', 'transaksi.json',
  'payments.json', 'history.json', 'trx.json'
].map(f => path.join(DB_DIR, f))

const readJson = (f, fb) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')) } catch { return fb } }

function pickTxSource() {
  const tryFile = (f) => {
    if (!fs.existsSync(f)) return null
    const j = readJson(f, null)
    if (j == null) return null
    if (Array.isArray(j)) return { file: f, raw: j }
    if (Array.isArray(j?.list)) return { file: f, raw: j.list }
    if (Array.isArray(j?.items)) return { file: f, raw: j.items }
    return { file: f, raw: j }
  }
  const pri = tryFile(PRIORITY_FILE); if (pri) return pri
  for (const f of TX_CANDIDATES) { const r = tryFile(f); if (r) return r }
  for (const name of fs.existsSync(DB_DIR) ? fs.readdirSync(DB_DIR).filter(x => x.endsWith('.json')) : []) {
    const f = path.join(DB_DIR, name); if (f === PRIORITY_FILE) continue
    const r = tryFile(f); if (r) return r
  }
  return { file: null, raw: null }
}

// ===== util basic =====
const onlyNum = s => String(s || '').replace(/[^\d]/g, '')
const jidNum = jid => onlyNum(String(jid || '').replace(/:\d+(?=@|$)/g, '').split('@')[0] || '')
const toIntl = (n, locale = 'id-ID') => Math.round(Number(n) || 0).toLocaleString(locale)
const fmtRp = n => 'Rp ' + toIntl(n)

const ID_MONTHS = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
const MONTH_MAP = new Map([
  ['januari', 0], ['jan', 0], ['january', 0],
  ['februari', 1], ['feb', 1], ['february', 1],
  ['maret', 2], ['mar', 2], ['march', 2],
  ['april', 3], ['apr', 3],
  ['mei', 4], ['may', 4],
  ['juni', 5], ['jun', 5], ['june', 5],
  ['juli', 6], ['jul', 6], ['july', 6],
  ['agustus', 7], ['agu', 7], ['ags', 7], ['august', 7], ['aug', 7],
  ['september', 8], ['sep', 8], ['sept', 8],
  ['oktober', 9], ['okt', 9], ['october', 9], ['oct', 9],
  ['november', 10], ['nov', 10],
  ['desember', 11], ['des', 11], ['december', 11], ['dec', 11],
])

function parseBulanTahun(args) {
  const now = new Date()
  let y = now.getFullYear(), m = now.getMonth()
  if (!args || !args.length) return { year: y, monthIndex: m }

  const a0 = String(args[0] || '').toLowerCase()
  const a1 = String(args[1] || '').toLowerCase()

  const tryM = t => MONTH_MAP.has(t) ? MONTH_MAP.get(t) : (!isNaN(+t) && +t >= 1 && +t <= 12 ? +t - 1 : null)
  const tryY = t => (!isNaN(+t) && +t >= 1970 && +t <= 9999 ? +t : null)

  const m0 = tryM(a0), y0 = tryY(a0), m1 = tryM(a1), y1 = tryY(a1)
  if (m0 != null && y1 != null) return { year: y1, monthIndex: m0 }
  if (y0 != null && m1 != null) return { year: y0, monthIndex: m1 }
  if (m0 != null && !a1) return { year: y, monthIndex: m0 }
  if (y0 != null && !a1) return { year: y0, monthIndex: m }
  return { year: y, monthIndex: m }
}

// ===== date (WIB) =====
function wibParts(ts) {
  let t = ts
  if (typeof ts === 'string') {
    const p = Date.parse(ts)
    t = isNaN(p) ? Number(ts) : p
  }
  if (typeof t === 'number' && t < 2e10) t = t * 1000 // sec->ms
  const d = new Date(Number(t) || 0)
  const tz = 'Asia/Jakarta'
  return {
    y: Number(d.toLocaleString('id-ID', { year: 'numeric', timeZone: tz })),
    m: Number(d.toLocaleString('id-ID', { month: '2-digit', timeZone: tz })),
    D: Number(d.toLocaleString('id-ID', { day: '2-digit', timeZone: tz })),
    H: d.toLocaleString('id-ID', { hour: '2-digit', hour12: false, timeZone: tz }),
    M: d.toLocaleString('id-ID', { minute: '2-digit', timeZone: tz })
  }
}
const fmtDateLine = ts => {
  const p = wibParts(ts)
  const day = String(p.D).padStart(2, '0')
  const monName = ID_MONTHS[(p.m - 1 + 12) % 12]
  const timeHM = `${String(p.H).padStart(2, '0')}.${String(p.M).padStart(2, '0')}`
  return `${day} ${monName} ${p.y} | ${timeHM}`
}

// ===== user match =====
function normalizeMsisdn(msisdn) {
  const n = onlyNum(msisdn || '')
  if (!n) return ''
  if (n.startsWith('62')) return n
  if (n.startsWith('0')) return '62' + n.slice(1)
  if (n.startsWith('8')) return '62' + n
  return n
}
function extractNumberDeep(val, depth = 0) {
  if (val == null) return ''
  if (depth > 2) return ''
  if (typeof val === 'string') return normalizeMsisdn(val)
  if (typeof val === 'number') return normalizeMsisdn(String(val))
  if (typeof val === 'object') {
    if (val.jid) return extractNumberDeep(val.jid, depth + 1)
    if (val.number) return extractNumberDeep(val.number, depth + 1)
    for (const k of Object.keys(val)) {
      const got = extractNumberDeep(val[k], depth + 1)
      if (got) return got
    }
  }
  return ''
}
function isTxOfUser(tx, user62) {
  const fields = ['buyer', 'user', 'from', 'buyer_number', 'sender', 'msisdn', 'buyerJid', 'senderJid', 'buyer_jid', 'jid', 'wa', 'wa_number', 'phone', 'hp', 'number']
  for (const k of fields) {
    if (k in (tx || {})) {
      const got = extractNumberDeep(tx[k])
      if (got && got === user62) return true
    }
  }
  const nested = extractNumberDeep(tx?.meta) || extractNumberDeep(tx?.data) || extractNumberDeep(tx?.buyer_info)
  return !!(nested && nested === user62)
}

// ===== status =====
function statusEmoji(st) {
  const s = String(st || '').trim().toUpperCase()
  if (['SUKSES', 'SUCCESS', 'BERHASIL', 'PAID'].includes(s)) return ' ✅'
  if (['GAGAL', 'FAILED'].includes(s)) return ' ❌'
  return ''
}
function statusLabel(st) {
  const s = String(st || '').trim().toUpperCase()
  if (['SUCCESS', 'BERHASIL', 'PAID'].includes(s)) return 'SUKSES'
  if (['FAILED'].includes(s)) return 'GAGAL'
  return s || '-'
}
const pickTs = t => t?.ts ?? t?.time ?? t?.timestamp ?? t?.created_at ?? t?.date ?? t?.createdAt

// ===== product name fallback from products.json =====
function getProductNameByCode(code) {
  if (!code) return ''
  if (!fs.existsSync(FILE_PRODUCTS)) return ''
  const products = readJson(FILE_PRODUCTS, { products: [] })
  const p = (products.products || []).find(x => String(x.code || '').toUpperCase() === String(code).toUpperCase())
  return p?.name || ''
}

// ===== balance (sisa saldo saat order) =====
function pickBalanceAtOrder(tx) {
  const keys = [
    'balance_after', 'balanceAfter', 'saldo_akhir', 'saldoAkhir',
    'final_balance', 'ending_balance', 'balance_end',
    'balance', 'saldo', 'remaining_balance', 'sisa_saldo'
  ]
  for (const k of keys) {
    const v = tx?.[k]
    if (v == null) continue
    const num = Number(String(v).replace(/[^\d.-]/g, ''))
    if (!isNaN(num)) return num
  }
  const nested = tx?.meta || tx?.data || {}
  for (const k of keys) {
    const v = nested?.[k]
    if (v == null) continue
    const num = Number(String(v).replace(/[^\d.-]/g, ''))
    if (!isNaN(num)) return num
  }
  return null
}

// ================== HANDLER ==================
let handler = async (m, { wafproject, args, command }) => {
  if (!/^cekriwayat$/i.test(command)) return
  const conn = wafproject

  const say = async (txt) => {
    try { if (typeof m.reply === 'function') return await m.reply(String(txt)) } catch (error) { console.error("[ERROR][commands/topup/cekriwayat.js]", error?.message || error) }
    return conn.sendMessage(m.chat, { text: String(txt) }, { quoted: m })
  }

  const { year, monthIndex } = parseBulanTahun(args || [])
  const headerMonthName = ID_MONTHS[monthIndex]

  const senderNum = jidNum(m.sender || m.key?.participant || m.participant || m.key?.remoteJid)
  const me = normalizeMsisdn(senderNum)
  const displayName = m?.pushName ? `${m.pushName}` : me

  const { raw } = pickTxSource()
  if (!raw) {
    return say(`📜 *RIWAYAT TRANSAKSI — ${headerMonthName} ${year}*\n━━━━━━━━━━━━━━━━━━\n*Nama :* ${displayName}\n*Total :* 0 trx \n*Sukses :* 0 \n*Gagal :* 0\n\nBelum ada riwayat transaksi di bulan ini.`)
  }

  // ambil milik user
  let mine = []
  if (Array.isArray(raw)) {
    mine = raw.filter(tx => isTxOfUser(tx, me))
  } else {
    mine = raw[me] || raw[me.replace(/^62/, '0')] || raw[me.replace(/^62/, '')] || []
    if (!Array.isArray(mine)) {
      const arrays = Object.values(raw).filter(Array.isArray)
      mine = [].concat(...arrays).filter(tx => isTxOfUser(tx, me))
    }
  }

  const filtered = mine.filter(t => {
    const ts = pickTs(t); if (!ts) return false
    const p = wibParts(ts)
    return p.y === year && p.m === (monthIndex + 1)
  })

  if (!filtered.length) {
    return say(
`📜 *RIWAYAT TRANSAKSI — ${headerMonthName} ${year}*
━━━━━━━━━━━━━━━━━━
*Nama :* ${displayName}
*Total :* 0 trx 
*Sukses :* 0 
*Gagal :* 0

Belum ada riwayat transaksi di bulan ini.`)
  }

  filtered.sort((a, b) => {
    const A = pickTs(a), B = pickTs(b)
    const aN = Number(A), bN = Number(B)
    const aT = isNaN(aN) ? Date.parse(A) : aN
    const bT = isNaN(bN) ? Date.parse(B) : bN
    return (bT || 0) - (aT || 0)
  })

  let total = filtered.length, ok = 0, fail = 0
  for (const t of filtered) {
    const s = statusLabel(t?.status)
    if (s === 'SUKSES') ok++; else if (s === 'GAGAL') fail++
  }

  const line2 = '━━━━━━━━━━━━━━━━━━'
  let out = `📜 *RIWAYAT TRANSAKSI — ${headerMonthName} ${year}*
${line2}
*Nama :* ${displayName}
*Total :* ${total} trx 
*Sukses :* ${ok} 
*Gagal :* ${fail}
`

  for (const t of filtered) {
    const when = fmtDateLine(pickTs(t))
    const sLab = statusLabel(t?.status)
    const sEmo = statusEmoji(t?.status)

    const code = String(t?.buyer_sku_code || t?.sku || t?.code || '').toUpperCase()
    let name = String(t?.product_name || t?.name || '').trim()
    if (!name) name = getProductNameByCode(code) || code || '-'

    const tujuanFull = String(t?.customer_no || t?.target || t?.tujuan || t?.customer || '-')
    const harga = Number(t?.price_sell ?? t?.selling_price ?? t?.amount ?? t?.price ?? t?.total ?? 0)
    const ref = String(t?.ref_id || t?.ref || t?.reference || '-')
    const desc = String(t?.sn || t?.message || t?.desc || t?.note || '').trim()
    const bal = pickBalanceAtOrder(t)

    out += `\n*${when} | ${sLab}*${sEmo}
*Produk :* ${name}
*Tujuan :* ${tujuanFull}
*Harga :* ${fmtRp(harga)}
*Ref ID :* ${ref} 
*Deskripsi :*${desc ? ' ' + desc : ''}${bal != null ? `\n*Sisa Saldo :* ${fmtRp(bal)}` : ''}
${line2}`
  }

  return say(out.trim())
}

handler.help = ['cekriwayat']
handler.category = ['topup']
handler.command = /^cekriwayat$/i
handler.register = false

module.exports = handler
