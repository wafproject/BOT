/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI | Adapt: WAFPROJECT-7 (CJS)
© 2025 — All Rights Reserved 🔒
========================
*/

// commands/owner/ubahrole.js
// ✨ Owner — UBAH ROLE USER (Bronze | Silver | Gold | Owner)
// ✅ Reply + Mention (LID SAFE)
// ✅ Role simpan ke /database/users.json (sinkron order.js)

const fs = require('fs')
const path = require('path')
const { DATABASE_DIR } = require("../../lib/project-paths")

// ====== DATA DIR & FILE ======
const DB_DIR     = process.env.TOPUP_DB_DIR || DATABASE_DIR
const FILE_USERS = path.join(DB_DIR, 'users.json')

// ====== UTIL ======
function ensureDir(d){ if(!fs.existsSync(d)) fs.mkdirSync(d,{recursive:true}) }
function readJson(f, fb){ try{ return JSON.parse(fs.readFileSync(f,'utf8')) }catch{ return fb } }
function writeJson(f, v){ ensureDir(path.dirname(f)); fs.writeFileSync(f, JSON.stringify(v, null, 2)) }

const onlyNum  = (s) => String(s || '').replace(/[^\d]/g, '')
const jidNum   = (jid) => onlyNum(String(jid || '').replace(/:\d+(?=@|$)/g, '').split('@')[0] || '')

const ROLE_KEYS = ['bronze','silver','gold','owner']
const roleLabel = (r) => ({
  bronze:'Bronze',
  silver:'Silver',
  gold:'Gold',
  owner:'Owner'
})[String(r||'').toLowerCase()] || 'Bronze'

// normalize nomor ke 62xxxxxxxxxx
function norm62FromDigits(numDigits){
  const n = onlyNum(numDigits || '')
  if (!n) return ''
  if (n.startsWith('62')) return n
  if (n.startsWith('0')) return '62' + n.slice(1)
  if (n.startsWith('8')) return '62' + n
  return n
}

function normalizeJidFromNumber(input){
  const digits = onlyNum(input || '')
  if (!digits) return null
  const n62 = norm62FromDigits(digits)
  return n62 ? `${n62}@s.whatsapp.net` : null
}

// ================================
// ✅ LID SAFE RESOLVER
// ================================
async function resolveToRealJid(wafproject, m, rawJid) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith('@s.whatsapp.net')) return s

  if (!m.isGroup) return s

  let meta
  try {
    meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const participants = meta?.participants || []
  const found = participants.find(p =>
    p?.lid === s ||
    p?.id === s ||
    p?.jid === s ||
    p?.participant === s
  )

  return found?.jid || found?.id || found?.participant || s
}

async function getTargetJid(wafproject, m, args) {
  let raw = null

  // reply
  if (m.quoted?.sender) raw = m.quoted.sender
  else if (m.quoted?.key?.participant) raw = m.quoted.key.participant

  // mention popup
  else if (m.mentionedJid?.length) raw = m.mentionedJid[0]

  // nomor manual
  else if (args[0]) {
    const n = String(args[0]).replace(/[^0-9]/g, '')
    if (n.length >= 8) return normalizeJidFromNumber(n)
  }

  const real = await resolveToRealJid(wafproject, m, raw)
  if (!real) return null
  if (!String(real).endsWith('@s.whatsapp.net')) return null

  return real
}

// ====== Owner detector (simple) ======
function collectOwners(){
  const set = new Set()
  const add = (v) => {
    if (!v) return
    if (Array.isArray(v)) { v.flat().forEach(add); return }
    if (typeof v === 'object') { Object.values(v).forEach(add); return }
    const d = onlyNum(v)
    if (!d) return
    set.add(norm62FromDigits(d))
  }

  add(global.nomorown || global.nomorowner)
  add(global.rowner)
  add(global.owner)

  return set
}

function isOwnerSender(senderJid){
  const s = jidNum(senderJid)
  if (!s) return false
  return collectOwners().has(norm62FromDigits(s))
}

// ================== HANDLER ==================
let handler = async (m, { wafproject, usedPrefix, command, text, args, isOwner, isROwner }) => {
  const conn = wafproject
  if (!conn) return

  const cmd = String(command || '').toLowerCase()
  if (cmd !== 'ubahrole') return

  // owner gate
  const senderJid = m.sender || m.key?.participant || m.key?.remoteJid || m.chat
  const okOwner = !!isOwner || !!isROwner || isOwnerSender(senderJid)
  if (!okOwner) {
    return conn.sendMessage(m.chat, { text: 'Khusus owner.' }, { quoted: m })
  }

  const pref = usedPrefix || global.prefix || '.'
  const argv = Array.isArray(args) ? args : String(text || '').trim().split(/\s+/).filter(Boolean)

  // role token selalu terakhir
  const roleRaw = String(argv[argv.length - 1] || '').toLowerCase()

  if (!ROLE_KEYS.includes(roleRaw)) {
    return conn.sendMessage(
      m.chat,
      {
        text:
          `❌ *Format salah*\n\n` +
          `Contoh:\n` +
          `${pref}ubahrole 6281234567890 gold\n` +
          `${pref}ubahrole @user silver\n` +
          `atau reply user:\n${pref}ubahrole bronze\n\n` +
          `Role: bronze | silver | gold | owner`
      },
      { quoted: m }
    )
  }

  // jika cuma kirim role tanpa target
  if (argv.length === 1 && !m.quoted && !(m.mentionedJid && m.mentionedJid.length)) {
    return conn.sendMessage(
      m.chat,
      {
        text:
          `❌ *Target belum ada*\n\n` +
          `Gunakan:\n` +
          `${pref}ubahrole @user ${roleRaw}\n` +
          `${pref}ubahrole 628xxxx ${roleRaw}\n` +
          `atau reply user lalu ketik:\n${pref}ubahrole ${roleRaw}`
      },
      { quoted: m }
    )
  }

  // ambil target LID safe
  const targetJid = await getTargetJid(conn, m, argv)
  if (!targetJid) {
    return conn.sendMessage(
      m.chat,
      {
        text:
          `❌ Gagal membaca nomor asli dari mention.\n\n` +
          `Solusi:\n` +
          `1) Mention popup yang benar\n` +
          `2) Reply pesan user lalu ketik: ${pref}ubahrole ${roleRaw}\n` +
          `3) Atau pakai nomor manual: ${pref}ubahrole 628xxxx ${roleRaw}`
      },
      { quoted: m }
    )
  }

  const keyNum = norm62FromDigits(jidNum(targetJid))
  if (!keyNum) {
    return conn.sendMessage(m.chat, { text: '❌ Nomor target tidak valid.' }, { quoted: m })
  }

  // load users.json
  ensureDir(DB_DIR)
  const users = readJson(FILE_USERS, {})

  if (!users[keyNum]) {
    users[keyNum] = { role: 'bronze', tx: 0, spent: 0, profit_contrib: 0, created: Date.now() }
  }

  const prev = String(users[keyNum].role || 'bronze').toLowerCase()
  users[keyNum].role = roleRaw
  writeJson(FILE_USERS, users)

  // ✅ reply + mention LID safe
  await conn.sendMessage(
    m.chat,
    {
      text:
        `✅ *Role berhasil diubah*\n` +
        `👤 User: @${keyNum}\n` +
        `🛡️ Role: *${roleLabel(prev)} → ${roleLabel(roleRaw)}*`,
      mentions: [targetJid]
    },
    { quoted: m }
  )

  return
}

handler.help = ['ubahrole @user gold', 'ubahrole 628xxxx silver', 'ubahrole (reply) bronze']
handler.category = ['owner']
handler.command = /^ubahrole$/i
handler.rowner = true

module.exports = handler
