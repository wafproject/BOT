// commands/topup/listtopup.js
// ✨ Topup — LIST & ALIAS FLOW (tanpa profil/cekstatus/cek)
// CommonJS + cocok handler wafproject
// Fokus: alias 1 kata (strict), whitelist dari DB, dan respon normal
// ✅ FIX: Judul item TIDAK lagi diprefix brand.name (biar gak double MOBILE LEGENDS)
// ✅ RAPIN: auto-hide tipe yang itemnya 0 + GEN selalu paling bawah (kalau ada itemnya)
// ✅ RENAME: .listtopup -> .listproduk
// ✅ ADD: .produk (alias untuk .listproduk)
// ✅ MAPPING NAMA: kategori / brand / tipe / produk
//
// 🔧 REV (fix masalah kategori muncul lagi):
// - renderListBrands sekarang HANYA pakai categories.json sebagai whitelist kategori tampilan
// - Tidak lagi merge dengan brand.category dari products.json (yang balik lagi setelah sinkron)

const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const { availability, typeDisplayName } = require('../../lib/topup-product-utils')
const {
  detectVariation,
  stripVariationFromName,
  variationCommandCode,
  groupVariations
} = require('../../lib/product-variation')
const { DATABASE_DIR } = require("../../lib/project-paths")

// ================== DB FILES ==================
const DB_DIR = process.env.TOPUP_DB_DIR || DATABASE_DIR
const FILE_PRODUCTS   = path.join(DB_DIR, 'products.json')
const FILE_DB         = path.join(DB_DIR, 'users.json')
const FILE_PROFIT     = path.join(DB_DIR, 'profit.json')
const FILE_SUBRULES   = path.join(DB_DIR, 'subrules.json')
const FILE_CATEGORIES = path.join(DB_DIR, 'categories.json')

// ===== INIT =====
function ensureDir(d){ if(!fs.existsSync(d)) fs.mkdirSync(d,{recursive:true}) }
function readJson(f, fb){ try{ return JSON.parse(fs.readFileSync(f,'utf8')) }catch{ return fb } }
function writeJson(f, v){ ensureDir(path.dirname(f)); fs.writeFileSync(f, JSON.stringify(v,null,2)) }

;(function init(){
  ensureDir(DB_DIR)
  if(!fs.existsSync(FILE_PRODUCTS))   writeJson(FILE_PRODUCTS,{brands:[],products:[]})
  if(!fs.existsSync(FILE_DB))         writeJson(FILE_DB,{})
  if(!fs.existsSync(FILE_PROFIT))     writeJson(FILE_PROFIT,{ bronze:1.5,silver:1,gold:0.5,owner:0 })
  if(!fs.existsSync(FILE_SUBRULES))   writeJson(FILE_SUBRULES,{})
  if(!fs.existsSync(FILE_CATEGORIES)) writeJson(FILE_CATEGORIES,[])
})()

// ===== UTIL =====
const fmtRp=(n)=>'Rp '+Math.round(Number(n)||0).toLocaleString('id-ID')
const onlyNum=(s)=>String(s||'').replace(/[^\d]/g,'')
const jidNum=(jid)=>onlyNum(String(jid||'').replace(/:\d+(?=@|$)/g,'').split('@')[0]||'')

const loadProducts = ()=> readJson(FILE_PRODUCTS,{brands:[],products:[]})
const loadDB       = ()=> readJson(FILE_DB,{})
const saveDB       = (db)=> writeJson(FILE_DB, db)
const loadProfit   = ()=> readJson(FILE_PROFIT,{ bronze:1.5,silver:1,gold:0.5,owner:0 })
const loadSubs     = ()=> readJson(FILE_SUBRULES, {})
const loadCats     = ()=> readJson(FILE_CATEGORIES, [])

// ===== PREFIX DISPLAY (FIX TAMPILAN SAJA) =====
// - Kalau bot no-prefix: ctx.usedPrefix biasanya ''/undefined → tampil kosong
// - Jangan fallback '.' supaya tidak muncul titik saat no-prefix
function getDisplayPrefix(ctx){
  const p = (ctx?.usedPrefix != null ? String(ctx.usedPrefix) : '').trim()
  return p
}
function dispCmd(prefix, cmd){
  return prefix ? `${prefix}${cmd}` : `${cmd}`
}

// ===== USER ROLE / STAT =====
// Gunakan root users.json agar role katalog sama dengan _order.js, profil.js, dan _ubahrole.js.
// users.json memakai root nomor user secara langsung; namespace legacy database.topup.users sudah dibersihkan.
function ensureUser(num){
  const db = loadDB()
  if(!db[num]) db[num]={role:'bronze',tx:0,spent:0,profit_contrib:0,created:Date.now()}
  saveDB(db)
  return db[num]
}

function priceByRole(base){
  base=Number(base)||0
  const p=loadProfit()
  return {
    bronze: base + Math.round(base*(Number(p.bronze||0)/100)),
    silver: base + Math.round(base*(Number(p.silver||0)/100)),
    gold:   base + Math.round(base*(Number(p.gold||0)/100)),
  }
}

function priceForRole(base, role){
  base = Number(base) || 0
  const r = String(role || 'bronze').toLowerCase()
  const p = loadProfit()
  if (r === 'owner') return base + Math.round(base * (Number(p.owner || 0) / 100))
  const map = priceByRole(base)
  return map[r] ?? map.bronze
}

function normalizeOwnerNumber(value){
  let digits = onlyNum(value)
  if(!digits) return ''
  if(digits.startsWith('0')) digits = `62${digits.slice(1)}`
  return digits
}

function configuredOwnerNumbers(){
  const out = new Set()
  const add = value => {
    if(!value) return
    if(Array.isArray(value)) return value.flat(Infinity).forEach(add)
    if(typeof value === 'object') return Object.values(value).forEach(add)
    const num = normalizeOwnerNumber(value)
    if(num) out.add(num)
  }
  add(global.nomorown || global.nomorowner)
  add(global.rowner)
  add(global.owner)
  return out
}

function effectiveRole(num, storedRole, ctx){
  if(ctx?.isOwner || ctx?.isROwner || configuredOwnerNumbers().has(normalizeOwnerNumber(num))) return 'owner'
  return String(storedRole || 'bronze').toLowerCase()
}

// ===== helpers brand/product =====
function resolveStatus(it){
  return availability(it).available ? 'open' : 'close'
}

function isVisibleProduct(it){
  // Katalog tetap menampilkan produk current meskipun sedang tidak tersedia.
  // Produk stale (sudah hilang dari price-list Digiflazz terbaru) tetap disembunyikan
  // agar katalog tidak berisi SKU yang memang sudah tidak dijual provider.
  const meta = it?.meta || {}
  return !(meta.stale === true || it?.stale === true)
}

function getBrandByAlias(products, alias){
  return (products.brands||[]).find(b=>String(b.alias||'').toLowerCase()===String(alias||'').toLowerCase()) || null
}

const normCat = s => String(s||'').trim().replace(/\s+/g,' ').toLowerCase()

function providerIdentityFromProduct(product){
  const meta = product?.meta || {}
  const category = String(meta.provider_category || '').trim()
  const brand = String(meta.provider_brand || '').trim()
  if (!category || !brand) return null
  return { category, brand, key: `${normCat(category)}__${normCat(brand)}` }
}

function resolveBrandProviderIdentity(products, brand){
  const directCategory = String(brand?.providerCategory || brand?.provider_category || '').trim()
  const directBrand = String(brand?.providerBrand || brand?.provider_brand || '').trim()
  if (directCategory && directBrand) {
    return {
      category: directCategory,
      brand: directBrand,
      key: `${normCat(directCategory)}__${normCat(directBrand)}`
    }
  }

  // Kompatibilitas database lama: cari identitas provider dari SKU yang pernah
  // terhubung ke alias brand ini. Pakai pasangan yang paling sering muncul, lalu
  // kumpulkan SEMUA SKU provider dengan pasangan category+brand tersebut.
  const alias = String(brand?.alias || '').toLowerCase()
  const counts = new Map()
  for (const product of (products?.products || [])) {
    if (String(product?.brandAlias || '').toLowerCase() !== alias) continue
    const identity = providerIdentityFromProduct(product)
    if (!identity) continue
    const current = counts.get(identity.key) || { ...identity, count: 0 }
    current.count += 1
    counts.set(identity.key, current)
  }

  const best = [...counts.values()].sort((a,b) => b.count - a.count)[0]
  if (best) return best

  // Fallback terakhir untuk katalog lama yang belum punya meta provider.
  const category = String(brand?.category || '').trim()
  const name = String(brand?.name || '').trim()
  if (category && name) return { category, brand: name, key: `${normCat(category)}__${normCat(name)}` }
  return null
}

function sameBrand(products, p, brand){
  const wanted = resolveBrandProviderIdentity(products, brand)
  const actual = providerIdentityFromProduct(p)

  // Prioritas identitas provider, bukan alias display. Ini mencegah satu provider
  // brand terpecah karena alias/mapping legacy atau rename manual.
  if (wanted && actual) return wanted.key === actual.key

  const pa = String(p.brandAlias || '').toLowerCase()
  if (pa) return pa === String(brand.alias || '').toLowerCase()
  const nameOk = normCat(p.brand) === normCat(brand.name)
  const catOk  = normCat(p.brandCategory || p.category) === normCat(brand.category)
  return nameOk && catOk
}

// ===== DISPLAY NAMA =====
// - Judul kategori tetap CAPSLOCK sesuai permintaan.
// - Nama brand/produk/tampilan lain dirapikan agar tidak tampil capslock penuh.
const DISPLAY_NAME_ACRONYMS = new Set([
  'PLN','TV','SMS','PPOB','PDAM','BPJS','OTP','PUBG','FC','ID','MY','PH','SG','TH','VN','BR','BRL','RS','TR','US','EU','SEA','COD'
])
const DISPLAY_NAME_LOWER_WORDS = new Set(['dan', 'di', 'ke', 'dari', 'untuk', '&', 'of', 'the'])

function displayCategoryName(value){
  return String(value || 'LAINNYA').trim().replace(/\s+/g, ' ').toUpperCase() || 'LAINNYA'
}

function formatDisplayWord(word, index){
  const raw = String(word || '').trim()
  if (!raw) return ''

  if (/^\d+[A-Za-z]*$/.test(raw) || /^[A-Za-z]+\d+$/.test(raw)) return raw.toUpperCase()

  const upper = raw.toUpperCase()
  if (DISPLAY_NAME_ACRONYMS.has(upper)) return upper

  const lower = raw.toLowerCase()
  if (index > 0 && DISPLAY_NAME_LOWER_WORDS.has(lower)) return lower

  if (raw.includes('-')) {
    return raw.split('-').map((part, i) => formatDisplayWord(part, i)).join('-')
  }

  return lower.charAt(0).toUpperCase() + lower.slice(1)
}

function normalizeDisplayName(value, fallback = '-'){
  const raw = String(value || '').trim().replace(/\s+/g, ' ')
  if (!raw) return fallback
  return raw.split(' ').map((word, index) => formatDisplayWord(word, index)).join(' ')
}

// ===== MAPPING NAMA =====
// DB lama tetap:
// - category
// - brand
// - subAlias
// - name
//
// Mapping baru di code/tampilan:
// - kategori
// - brand
// - tipe
// - produk

function mapProductNaming(p, brandObj){
  return {
    kategori: String(p?.category || brandObj?.category || '').trim(),
    brand: String(p?.brand || brandObj?.name || '').trim(),
    tipe: typeDisplayName(p?.meta?.provider_type || p?.type || p?.subAlias || 'Umum'),
    produk: String(p?.name || '').trim()
  }
}

function availableBrandProducts(products, brand){
  return (products.products || []).filter(p => {
    if (!sameBrand(products, p, brand) || !isVisibleProduct(p)) return false
    return availability(p).available === true
  })
}

function getManualVariation(product, brand){
  const meta = product?.meta || {}
  if (meta.manual_sub_alias !== true || !String(product?.subAlias || '').trim()) return null

  const alias = String(product.subAlias).toUpperCase()
  const cfg = loadSubs()?.[String(brand?.alias || '').toLowerCase()]?.subs?.[alias] || {}
  return {
    key: `manual:${alias.toLowerCase()}`,
    name: String(cfg?.name || alias),
    emoji: String(cfg?.flag || '⚡'),
    rank: Number.isFinite(Number(cfg?.rank)) ? Number(cfg.rank) : 500,
    explicit: true,
    commandCode: alias,
    manual: true
  }
}

function productVariation(product, brand){
  const manual = getManualVariation(product, brand)
  if (manual) return manual
  const detected = detectVariation(product)
  return { ...detected, commandCode: variationCommandCode(detected) }
}

// Persis seperti bot Telegram: Membership dulu, kemudian negara/region,
// Global mendekati bawah, dan Umum paling bawah.
function brandVariations(products, brand){
  const list = availableBrandProducts(products, brand)
  const grouped = new Map()

  for (const product of list){
    const variation = productVariation(product, brand)
    const current = grouped.get(variation.key) || {
      ...variation,
      count: 0,
      minPrice: Number.POSITIVE_INFINITY
    }
    current.count += 1
    current.minPrice = Math.min(current.minPrice, Number(product.price || 0))
    grouped.set(variation.key, current)
  }

  return [...grouped.values()]
    .map(item => ({
      ...item,
      commandCode: item.commandCode || variationCommandCode(item),
      minPrice: Number.isFinite(item.minPrice) ? item.minPrice : 0
    }))
    .sort((a,b) => (Number(a.rank || 999) - Number(b.rank || 999)) || String(a.name).localeCompare(String(b.name), 'id'))
}

function renderTipeList(products, brand, prefix){
  const variations = brandVariations(products, brand)
  const brandAliasUp = String(brand.alias || '').toUpperCase()
  const brandTitle = normalizeDisplayName(brand.name || brandAliasUp || 'PRODUK', 'Produk')
  const categoryTitle = displayCategoryName(brand.category || 'LAINNYA')
  const first = variations[0]
  const example = first ? dispCmd(prefix, `${brandAliasUp}${first.commandCode}`) : dispCmd(prefix, brandAliasUp)

  let t = `⚡ *PILIH TIPE LAYANAN*\n\n` +
    `Kategori: *${categoryTitle}*\n` +
    `Brand: *${brandTitle}*\n\n`

  if (!variations.length){
    return t + 'Belum ada produk aktif untuk brand ini.'
  }

  t += `Ketik kode tipe yang tersedia:\n`
  for (const variation of variations){
    const fullCode = `${brandAliasUp}${variation.commandCode}`
    t += `\n${variation.emoji || '⚡'} \`${fullCode}\` *${variation.name}*`
  }

  t += `\n\nContoh: *${example}*`
  return t.trimEnd()
}

function renderListBrands(products, prefix){
  const catsFromFile = loadCats().map(s => String(s).trim()).filter(Boolean)
  const brands = Array.isArray(products.brands) ? products.brands : []
  const mergedCats = catsFromFile.length ? catsFromFile : ['LAINNYA']
  const contoh = dispCmd(prefix, 'ML')

  let t = `🗒️ *CARA PENGGUNAAN :* \n> Ketik \`KODE\` untuk melihat produk\n> Contoh : *${contoh}*`

  for (const kategori of mergedCats){
    const kategoriKey = normCat(kategori)
    const kategoriDisplay = displayCategoryName(kategori)
    t += `\n\n╭─❖  *${kategoriDisplay}*`

    const under = brands
      .filter(b => normCat(String(b.category || 'LAINNYA')) === kategoriKey)
      // Seperti Telegram: brand tampil hanya jika punya produk aktif/tersedia.
      .filter(b => availableBrandProducts(products, b).length > 0)
      .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''), 'id'))

    if (!under.length){
      t += `\n│ (Belum ada brand)\n╰───────────────❖`
      continue
    }

    for (const b of under){
      const brandCode = String(b.alias || '').toUpperCase() || '—'
      const brandName = normalizeDisplayName(b.name || '-', '-')
      t += `\n│ 🔏  : \`${brandCode}\` ${brandName}`
    }

    t += `\n╰───────────────❖`
  }

  return t.trimEnd()
}

function renderKeteranganBlock(prefix){
  const a = dispCmd(prefix, 'order')
  return `💬  *CARA ORDER :*\n* ${a} <kode> <tujuan>\n* ${a} ml5 123654672 (0987)\n* ${a} dna10 085706676534`
}

function productsForVariation(products, brand, variationKey){
  return availableBrandProducts(products, brand)
    .filter(product => productVariation(product, brand).key === variationKey)
    .map(product => {
      const variation = productVariation(product, brand)
      return {
        product,
        variation,
        displayName: stripVariationFromName(product.name, variation)
      }
    })
    .sort((a,b) => {
      const priceDiff = Number(a.product.price || 0) - Number(b.product.price || 0)
      return priceDiff || String(a.displayName || '').localeCompare(String(b.displayName || ''), 'id')
    })
}

function renderItemsOfVariation(products, brand, variation, role, prefix){
  const all = productsForVariation(products, brand, variation.key)
  if (!all.length) return `Belum ada produk aktif pada tipe *${variation.name}*.`

  // Tampilan final: seluruh produk dalam satu pesan, tanpa pagination.
  // Hanya produk aktif/tersedia yang masuk karena productsForVariation()
  // sudah mengambil data dari availableBrandProducts().
  let t = `${renderKeteranganBlock(prefix)}\n\n`

  for (const entry of all){
    const p = entry.product
    const price = priceForRole(Number(p.price || 0), role)
    const displayName = normalizeDisplayName(
      entry.displayName || p.name || p.code || '-',
      '-'
    ).toUpperCase()

    t += `\n🛒 *${displayName}*\n` +
         `> 🔏 Kode : \`${String(p.code || '').toUpperCase()}\`\n` +
         `> 💰 Price : *${fmtRp(price)}*\n` +
         `> ✅ Status : *Tersedia*\n`
  }

  return t.trimEnd()
}

function buildAliasMap(products){
  const map = new Map()
  for (const brand of (products.brands || [])){
    const alias = String(brand.alias || '').toLowerCase()
    if (!alias) continue
    const variations = brandVariations(products, brand)
    if (!variations.length) continue
    map.set(alias, new Map(variations.map(item => [String(item.commandCode).toUpperCase(), item])))
  }
  return map
}

// ================== HANDLER ==================
async function handler(m, ctx){
  const wafproject = ctx?.wafproject
  if (!wafproject) return

  const say = async (txt) => {
    const t = String(txt)
    try { if (typeof m.reply === 'function') return await m.reply(t) } catch (error) { console.error("[ERROR][commands/topup/listtopup.js]", error?.message || error) }
    return wafproject.sendMessage(m.chat, { text: t }, { quoted: m })
  }

  const command = String(ctx?.command || '').toLowerCase()

  // jangan ganggu command plugin lain
  if (['topup','depo','depo1','order','order1','profil','cekstatus','cek'].includes(command)) return

  const products = loadProducts()
  const meNum = jidNum(m.sender || m.key?.participant || m.key?.remoteJid)

  // ✅ prefix tampilan ikut bot (no-prefix -> kosong)
  const prefix = getDisplayPrefix(ctx)

  // ✅ rename command: listproduk / produk
  if (command === 'listproduk' || command === 'produk') return say(renderListBrands(products, prefix))

  // ===== ALIAS & TIPE FLOW =====
  // Command adalah token pertama. Daftar produk ditampilkan penuh tanpa pagination.
  const aliasMap = buildAliasMap(products)
  const token = command
  const u = ensureUser(meNum)
  const role = effectiveRole(meNum, u.role, ctx)

  // 1) Kode brand langsung.
  // Sama seperti Telegram: jika cuma satu variasi, langsung tampil daftar produk.
  // Jika lebih dari satu, tampilkan pilihan tipe/region terlebih dahulu.
  if (aliasMap.has(token)) {
    const brand = getBrandByAlias(products, token)
    if (!brand) return
    const variations = brandVariations(products, brand)
    if (!variations.length) return say('Belum ada produk aktif untuk brand ini.')
    if (variations.length === 1) {
      return say(renderItemsOfVariation(products, brand, variations[0], role, prefix))
    }
    return say(renderTipeList(products, brand, prefix))
  }

  // 2) Kode brand + kode tipe/region, contoh MLID / MLGL / MLMB.
  const hit = [...aliasMap.keys()]
    .filter(a => token.startsWith(a) && token.length > a.length)
    .sort((a,b)=>b.length-a.length)[0]
  if (!hit) return

  const tipeCode = token.slice(hit.length).toUpperCase()
  const variation = aliasMap.get(hit)?.get(tipeCode)
  if (!variation) return

  const brand = getBrandByAlias(products, hit)
  if (brand) return say(renderItemsOfVariation(products, brand, variation, role, prefix))

}

handler.help = ['listproduk', 'produk']
handler.category = ['topup']

// ✅ listproduk/produk + alias-only (min 2 char) dan exclude command penting
handler.command = /^(listproduk|produk|(?!(topup|depo|depo1|order|order1|profil|cekstatus|cek)$)[a-z0-9]{2,20})$/i
handler.register = false

module.exports = handler
