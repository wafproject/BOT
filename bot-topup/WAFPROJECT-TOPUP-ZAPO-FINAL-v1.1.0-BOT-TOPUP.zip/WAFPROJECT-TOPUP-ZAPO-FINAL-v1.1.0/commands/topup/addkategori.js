// commands/owner/digiflazz-manage.js
// ✨ Owner — Manage Katalog (CJS, wafproject)
// Commands utama:
// - addkategori, delkategori
// - addbrand, delbrand
// - addtipe, deltipe, edittipe
//
// Alias legacy (tetap jalan, disembunyikan dari menu):
// - addsubkategori -> addbrand
// - delsubkategori -> delbrand
// - additem        -> addtipe
// - delitem        -> deltipe
// - edititem       -> edittipe
// - delsubproduk   -> legacy hapus tipe
//
// ✅ DB: <project>/database/*.json
// ✅ Struktur nama final: kategori / brand / tipe / produk
// ✅ Struktur DB lama tetap dipakai agar aman:
//    - brands[]
//    - products[]
//    - subrules[brand].subs[tipe]

const fs = require('fs')
const path = require('path')
const { DATABASE_DIR } = require("../../lib/project-paths")

// ================== DB FILES ==================
const DB_DIR = process.env.TOPUP_DB_DIR || DATABASE_DIR
const FILE_PRODUCTS   = path.join(DB_DIR, 'products.json')
const FILE_SUBRULES   = path.join(DB_DIR, 'subrules.json')
const FILE_CATEGORIES = path.join(DB_DIR, 'categories.json')

// ===== INIT =====
function ensureDir(d){ if(!fs.existsSync(d)) fs.mkdirSync(d,{recursive:true}) }
function readJson(f, fb){ try{ return JSON.parse(fs.readFileSync(f,'utf8')) }catch{ return fb } }
function writeJson(f, v){ ensureDir(path.dirname(f)); fs.writeFileSync(f, JSON.stringify(v,null,2)) }

;(function init(){
  ensureDir(DB_DIR)
  if(!fs.existsSync(FILE_PRODUCTS))   writeJson(FILE_PRODUCTS,{ brands: [], products: [] })
  if(!fs.existsSync(FILE_SUBRULES))   writeJson(FILE_SUBRULES,{})
  if(!fs.existsSync(FILE_CATEGORIES)) writeJson(FILE_CATEGORIES,[])
})()

// ===== LOAD/SAVE =====
const loadProducts = ()=> readJson(FILE_PRODUCTS,{ brands: [], products: [] })
const saveProducts = (v)=> writeJson(FILE_PRODUCTS, v)

function loadSubs(){
  const raw = readJson(FILE_SUBRULES, {})
  const map = {}
  for (const [k,v] of Object.entries(raw || {})){
    const key = String(k).toLowerCase()
    map[key] = (v && typeof v === 'object') ? v : { subs:{}, rules:[] }
    if (!map[key].subs) map[key].subs = {}
    if (!Array.isArray(map[key].rules)) map[key].rules = []
  }
  return map
}
const saveSubs = (v)=> writeJson(FILE_SUBRULES, v)

const loadCats = ()=> readJson(FILE_CATEGORIES, [])
function saveCats(arr){
  const out = Array.from(new Set((arr||[]).map(x=>String(x).trim()).filter(Boolean)))
  writeJson(FILE_CATEGORIES, out)
}

// ===== UTIL =====
const line = '━━━━━━━━━━━━━━━━━━'

function parseCsvArgs(str, countMin = 2){
  const arr = String(str || '')
    .split(',')
    .map(x => x.trim())
    .filter(Boolean)
  if (arr.length < countMin) return null
  return arr
}

function ensureBrandSubs(subMap, aliasBrand){
  const key = String(aliasBrand || '').toLowerCase()
  if (!subMap[key]) subMap[key] = { subs:{}, rules:[] }
  if (!subMap[key].subs) subMap[key].subs = {}
  if (!Array.isArray(subMap[key].rules)) subMap[key].rules = []
  return subMap[key]
}

function findBrandCI(data, kategori, aliasLower){
  const kat = String(kategori || '').toLowerCase()
  const al  = String(aliasLower || '').toLowerCase()
  return (data.brands || []).find(b =>
    String(b.category || '').toLowerCase() === kat &&
    String(b.alias || '').toLowerCase() === al
  )
}

// OWNER CHECK
function isOwnerJid(jid = ''){
  const arr = Array.isArray(global.owner) ? global.owner : []
  const me = String(jid || '').replace(/[^\d]/g,'')
  return arr.some(x => {
    if (Array.isArray(x) && x[0]) return String(x[0]).replace(/[^\d]/g,'') === me
    return String(x).replace(/[^\d]/g,'') === me
  })
}

// ===== COMMAND NORMALIZER =====
function normalizeCommand(cmdRaw){
  const cmd = String(cmdRaw || '').toLowerCase()

  if (cmd === 'addsubkategori') return 'addbrand'
  if (cmd === 'delsubkategori') return 'delbrand'
  if (cmd === 'additem') return 'addtipe'
  if (cmd === 'delitem') return 'deltipe'
  if (cmd === 'edititem') return 'edittipe'

  return cmd
}

// ================== HANDLER ==================
async function handler(m, ctx){
  const wafproject = ctx?.wafproject
  if (!wafproject) return

  const say = async (txt) => {
    const t = String(txt)
    try { if (typeof m.reply === 'function') return await m.reply(t) } catch (error) { console.error("[ERROR][commands/topup/addkategori.js]", error?.message || error) }
    return wafproject.sendMessage(m.chat, { text: t }, { quoted: m })
  }

  // Gunakan hasil deteksi owner dari handler utama terlebih dahulu.
  // Ini penting untuk akun WhatsApp yang sender-nya terbaca sebagai @lid.
  const ownerAllowed = Boolean(
    ctx?.isOwner ||
    ctx?.isROwner ||
    isOwnerJid(m.sender || m.key?.participant || m.key?.remoteJid)
  )
  if (!ownerAllowed) return say('Khusus owner.')

  const cmdRaw = String(ctx?.command || '').toLowerCase()
  const cmd = normalizeCommand(cmdRaw)
  const args = Array.isArray(ctx?.args) ? ctx.args : []
  const usedPrefix = (ctx?.usedPrefix != null ? String(ctx.usedPrefix) : '').trim()
  const argText = args.join(' ').trim()

  // =========================
  // addkategori <NamaKategori>
  // =========================
  if (cmd === 'addkategori'){
    if (!argText) return say(`Format: *${usedPrefix}addkategori <NamaKategori>*`)
    const cats = loadCats()
    cats.push(argText)
    saveCats(cats)
    return say(`✅ Kategori *${argText}* ditambahkan.`)
  }

  // =========================
  // delkategori <NamaKategori>
  // =========================
  if (cmd === 'delkategori'){
    if (!argText) return say(`Format: *${usedPrefix}delkategori <NamaKategori>*`)
    const kategori = String(argText).trim()
    const cats = loadCats()
    const beforeCats = cats.length
    const newCats = cats.filter(c => String(c).toLowerCase() !== kategori.toLowerCase())
    saveCats(newCats)

    const data = loadProducts()
    const removedBrands = (data.brands || []).filter(b => String(b.category||'').toLowerCase() === kategori.toLowerCase())
    const removedAliases = new Set(removedBrands.map(b => String(b.alias||'').toLowerCase()))

    const beforeBrands = (data.brands || []).length
    data.brands = (data.brands || []).filter(b => String(b.category||'').toLowerCase() !== kategori.toLowerCase())

    const beforeProducts = (data.products || []).length
    data.products = (data.products || []).filter(p => !removedAliases.has(String(p.brandAlias||'').toLowerCase()))
    saveProducts(data)

    const subs = loadSubs()
    let removedSubs = 0
    for (const a of removedAliases){
      if (subs[a]) { delete subs[a]; removedSubs++ }
    }
    saveSubs(subs)

    return say(
`🗑️ Hapus kategori *${kategori}*
${line}
• Kategori dihapus: ${beforeCats - newCats.length > 0 ? 1 : 0}
• Brand dihapus: ${beforeBrands - data.brands.length}
• Produk dihapus: ${beforeProducts - data.products.length}
• Subrules dihapus: ${removedSubs}
${line}`
    )
  }

  // =========================
  // addbrand <Kategori>, <AliasBrand>, <NamaBrand>
  // =========================
  if (cmd === 'addbrand'){
    const parts = parseCsvArgs(argText, 3)
    if (!parts) return say(`Format: *${usedPrefix}addbrand <Kategori>, <AliasBrand>, <NamaBrand>*`)
    const [kategoriRaw, aliasBrandRaw, namaBrandRaw] = parts
    const kategori = String(kategoriRaw||'').trim()
    const aliasBrand = String(aliasBrandRaw||'').trim().toLowerCase()
    const namaBrand  = String(namaBrandRaw||'').trim()
    if (!kategori || !aliasBrand || !namaBrand) return say('❌ Data tidak lengkap.')

    const data = loadProducts()
    const aliasCollision = (data.brands || []).find(b =>
      String(b.alias || '').toLowerCase() === aliasBrand &&
      String(b.category || '').toLowerCase() !== kategori.toLowerCase()
    )
    if (aliasCollision) {
      return say(
        `❌ Alias brand *${usedPrefix}${aliasBrand.toUpperCase()}* sudah dipakai oleh *${aliasCollision.name || '-'}* ` +
        `di kategori *${aliasCollision.category || '-'}*. Gunakan alias lain agar command produk tidak bentrok.`
      )
    }

    const exists = findBrandCI(data, kategori, aliasBrand)
    if (exists){
      exists.name = namaBrand
      saveProducts(data)
      return say(`📝 Brand *${usedPrefix}${aliasBrand.toUpperCase()}* di kategori *${kategori}* diupdate menjadi *${namaBrand}*.`)
    }

    data.brands ||= []
    data.brands.push({ category: kategori, name: namaBrand, alias: aliasBrand })
    saveProducts(data)
    return say(`✅ Brand *${namaBrand}* [*${usedPrefix}${aliasBrand.toUpperCase()}*] ditambahkan ke kategori *${kategori}*.`)
  }

  // =========================
  // delbrand <Kategori>, <AliasBrand>
  // =========================
  if (cmd === 'delbrand'){
    const parts = parseCsvArgs(argText, 2)
    if (!parts) return say(`Format: *${usedPrefix}delbrand <Kategori>, <AliasBrand>*`)
    const [kategoriRaw, aliasBrandRaw] = parts
    const kategori = String(kategoriRaw||'').trim()
    const aliasBrand = String(aliasBrandRaw||'').trim().toLowerCase()

    const data = loadProducts()
    const brand = findBrandCI(data, kategori, aliasBrand)
    if (!brand) return say(`⚠️ Brand *${usedPrefix}${aliasBrand.toUpperCase()}* pada kategori *${kategori}* tidak ditemukan.`)

    const beforeBrands = (data.brands || []).length
    data.brands = (data.brands || []).filter(b =>
      !(String(b.alias||'').toLowerCase() === aliasBrand && String(b.category||'').toLowerCase() === kategori.toLowerCase())
    )

    const beforeProducts = (data.products || []).length
    data.products = (data.products || []).filter(p => String(p.brandAlias||'').toLowerCase() !== String(brand.alias||'').toLowerCase())
    saveProducts(data)

    const subs = loadSubs()
    const key = String(brand.alias||'').toLowerCase()
    const hadSubs = !!subs[key]
    if (hadSubs) delete subs[key]
    saveSubs(subs)

    return say(
`🗑️ Brand *${usedPrefix}${aliasBrand.toUpperCase()}* di *${kategori}* dihapus
${line}
• Brand dihapus: ${beforeBrands - data.brands.length}
• Produk dihapus: ${beforeProducts - data.products.length}
• Subrules dihapus: ${hadSubs ? 1 : 0}
${line}`
    )
  }

  // =========================
  // addtipe <Kategori>, <AliasBrand>, <AliasTipe>, <NamaTipe>
  // =========================
  if (cmd === 'addtipe'){
    const parts = parseCsvArgs(argText, 4)
    if (!parts) return say(`Format: *${usedPrefix}addtipe <Kategori>, <AliasBrand>, <AliasTipe>, <NamaTipe>*`)
    const [kategoriRaw, aliasBrandRaw, aliasTipeRaw, namaTipeRaw] = parts
    const kategori   = String(kategoriRaw||'').trim()
    const aliasBrand = String(aliasBrandRaw||'').trim().toLowerCase()
    const aliasTipe  = String(aliasTipeRaw||'').trim().toUpperCase()
    const namaTipe   = String(namaTipeRaw||'').trim()
    if (!kategori || !aliasBrand || !aliasTipe || !namaTipe) return say('❌ Data tidak lengkap.')

    const data = loadProducts()
    const brand = findBrandCI(data, kategori, aliasBrand)
    if (!brand) return say(`❌ Brand *${usedPrefix}${aliasBrand.toUpperCase()}* pada kategori *${kategori}* tidak ditemukan. Tambahkan dulu via *addbrand*.`)

    const subs = loadSubs()
    const cfg = ensureBrandSubs(subs, aliasBrand)
    cfg.subs[aliasTipe] = { name: namaTipe || aliasTipe }
    saveSubs(subs)

    return say(`✅ Tipe *${aliasTipe}* → *${cfg.subs[aliasTipe].name}* didaftarkan di *${usedPrefix}${aliasBrand.toUpperCase()}* (kategori *${kategori}*).`)
  }

  // =========================
  // deltipe <Kategori>, <AliasBrand>, <AliasTipe>
  // =========================
  if (cmd === 'deltipe'){
    const parts = parseCsvArgs(argText, 3)
    if (!parts) return say(`Format: *${usedPrefix}deltipe <Kategori>, <AliasBrand>, <AliasTipe>*`)
    const [kategoriRaw, aliasBrandRaw, aliasTipeRaw] = parts
    const kategori   = String(kategoriRaw||'').trim()
    const aliasBrand = String(aliasBrandRaw||'').trim().toLowerCase()
    const aliasTipe  = String(aliasTipeRaw||'').trim().toUpperCase()

    const data = loadProducts()
    const brand = findBrandCI(data, kategori, aliasBrand)
    if (!brand) return say(`❌ Brand *${usedPrefix}${aliasBrand.toUpperCase()}* pada kategori *${kategori}* tidak ditemukan.`)

    const subs = loadSubs()
    const cfg = ensureBrandSubs(subs, aliasBrand)
    const had = !!cfg.subs[aliasTipe]
    if (had) delete cfg.subs[aliasTipe]
    saveSubs(subs)

    const before = (data.products || []).length
    data.products = (data.products || []).filter(p => !(
      String(p.brandAlias||'').toLowerCase() === String(brand.alias||'').toLowerCase() &&
      String(p.subAlias||'').toUpperCase() === aliasTipe
    ))
    saveProducts(data)

    return say(
`🗑️ Tipe *${aliasTipe}* di *${usedPrefix}${aliasBrand.toUpperCase()}* (kategori *${kategori}*) dihapus
${line}
• Subrules terhapus: ${had ? 1 : 0}
• Produk dihapus: ${before - data.products.length}
${line}`
    )
  }

  // =========================
  // edittipe <AliasBrand>, <TipeLama>, <TipeBaru>, <NamaBaru>
  // =========================
  if (cmd === 'edittipe'){
    const parts = parseCsvArgs(argText, 4)
    if (!parts) return say(`Format: *${usedPrefix}edittipe <AliasBrand>, <TipeLama>, <TipeBaru>, <NamaBaru>*`)
    const [aliasBrandRaw, oldTipeRaw, newTipeRaw, newNamaRaw] = parts
    const aliasBrand = String(aliasBrandRaw||'').trim().toLowerCase()
    const oldTipe = String(oldTipeRaw||'').trim().toUpperCase()
    const newTipe = String(newTipeRaw||'').trim().toUpperCase()
    const newNama = String(newNamaRaw||'').trim() || newTipe

    const subs = loadSubs()
    const cfg = ensureBrandSubs(subs, aliasBrand)
    if (!cfg.subs[oldTipe]) return say(`❌ Tipe *${oldTipe}* di *${usedPrefix}${aliasBrand.toUpperCase()}* tidak ditemukan.`)
    if (oldTipe !== newTipe && cfg.subs[newTipe]) {
      return say(`❌ Tipe tujuan *${newTipe}* sudah ada di *${usedPrefix}${aliasBrand.toUpperCase()}*. Gunakan kode tipe lain agar data tidak tertimpa.`)
    }

    if (oldTipe !== newTipe){
      cfg.subs[newTipe] = cfg.subs[oldTipe]
      delete cfg.subs[oldTipe]
    }
    cfg.subs[newTipe].name = newNama
    saveSubs(subs)

    const data = loadProducts()
    let changed = 0
    for (const p of (data.products || [])){
      if (
        String(p.brandAlias||'').toLowerCase() === aliasBrand &&
        String(p.subAlias||'').toUpperCase() === oldTipe
      ){
        p.subAlias = newTipe
        p.meta = { ...(p.meta || {}), manual_sub_alias: true }
        changed++
      }
    }
    saveProducts(data)

    return say(
`📝 Edit tipe selesai
${line}
• Brand: *${usedPrefix}${aliasBrand.toUpperCase()}*
• ${oldTipe} → ${newTipe}
• Nama baru: *${newNama}*
• Produk ter-update: ${changed}
${line}`
    )
  }

  // =========================
  // delsubproduk (LEGACY)
  // =========================
  if (cmdRaw === 'delsubproduk'){
    const parts = parseCsvArgs(argText, 2)
    if (!parts) {
      return say(`Format lama: *${usedPrefix}delsubproduk <AliasBrand>, <AliasTipe>*
(disarankan pakai: *${usedPrefix}deltipe <Kategori>, <AliasBrand>, <AliasTipe>*)`)
    }

    const [aliasBrandRaw, aliasTipeRaw] = parts
    const aliasBrand = String(aliasBrandRaw||'').trim().toLowerCase()
    const aliasTipe = String(aliasTipeRaw||'').trim().toUpperCase()

    const data = loadProducts()
    const brand = (data.brands || []).find(b => String(b.alias||'').toLowerCase() === aliasBrand)
    if (!brand) return say(`❌ Brand *${usedPrefix}${aliasBrand.toUpperCase()}* tidak ditemukan.`)

    const kategori = String(brand.category || '').trim()
    if (!kategori) return say(`❌ Kategori untuk brand *${usedPrefix}${aliasBrand.toUpperCase()}* tidak valid.`)

    const subs = loadSubs()
    const cfg = ensureBrandSubs(subs, aliasBrand)
    const had = !!cfg.subs[aliasTipe]
    if (had) delete cfg.subs[aliasTipe]
    saveSubs(subs)

    const before = (data.products || []).length
    data.products = (data.products || []).filter(p => !(
      String(p.brandAlias||'').toLowerCase() === String(brand.alias||'').toLowerCase() &&
      String(p.subAlias||'').toUpperCase() === aliasTipe
    ))
    saveProducts(data)

    return say(
`🗑️ (Legacy) Tipe *${aliasTipe}* di *${usedPrefix}${aliasBrand.toUpperCase()}* (kategori *${kategori}*) dihapus
${line}
• Subrules terhapus: ${had ? 1 : 0}
• Produk dihapus: ${before - data.products.length}
${line}`
    )
  }
}

handler.help = [
  'addkategori <NamaKategori>',
  'delkategori <NamaKategori>',
  'addbrand <Kategori>, <AliasBrand>, <NamaBrand>',
  'delbrand <Kategori>, <AliasBrand>',
  'addtipe <Kategori>, <AliasBrand>, <AliasTipe>, <NamaTipe>',
  'deltipe <Kategori>, <AliasBrand>, <AliasTipe>',
  'edittipe <AliasBrand>, <TipeLama>, <TipeBaru>, <NamaBaru>'
]
handler.category = ['owner']

// Command utama + alias legacy tetap hidup
handler.command = /^(addkategori|delkategori|addbrand|delbrand|addtipe|deltipe|edittipe|addsubkategori|delsubkategori|additem|delitem|edititem|delsubproduk)$/i
handler.rowner = true
handler.register = false

module.exports = handler
