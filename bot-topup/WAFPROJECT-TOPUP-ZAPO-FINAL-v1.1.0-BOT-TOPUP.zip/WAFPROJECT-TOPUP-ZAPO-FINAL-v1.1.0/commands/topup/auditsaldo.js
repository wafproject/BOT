const BalanceAudit = require('../../lib/balance-audit')

const onlyNum = (value) => String(value || '').replace(/[^0-9]/g, '')
const fmtRp = (value) => 'Rp ' + Math.round(Number(value) || 0).toLocaleString('id-ID')

function ownerNumberFromConfig(jid = '') {
  const me = onlyNum(jid)
  const owners = Array.isArray(global.owner) ? global.owner : []
  return owners.some(item => {
    const value = Array.isArray(item) ? item[0] : item
    return onlyNum(value) === me
  })
}

function resolveTarget(m, args = []) {
  const quoted = onlyNum(m?.quoted?.sender || m?.quoted?.key?.participant || '')
  if (quoted) return quoted

  const mentioned = Array.isArray(m?.mentionedJid) && m.mentionedJid.length
    ? onlyNum(m.mentionedJid[0])
    : ''
  if (mentioned) return mentioned

  const fromArgs = onlyNum(args.join(' '))
  if (fromArgs) return fromArgs

  return ''
}

function typeLabel(type) {
  const map = {
    order_debit: 'Order debit',
    order_refund: 'Order refund',
    paykita_order_credit: 'QRIS order credit',
    deposit_credit: 'Deposit',
    admin_credit: 'Admin tambah saldo',
    admin_debit: 'Admin kurang saldo'
  }
  return map[type] || type || 'Perubahan saldo'
}

let handler = async (m, { wafproject, args, isOwner, isROwner, usedPrefix, command }) => {
  const conn = wafproject
  if (!conn) return

  const say = (text) => conn.sendMessage(m.chat, { text: String(text) }, { quoted: m })
  const allowed = Boolean(isOwner || isROwner || ownerNumberFromConfig(m.sender || m.key?.participant || m.chat))
  if (!allowed) return say('Khusus owner.')

  const target = resolveTarget(m, args || [])
  if (!target) {
    return say(
      `📒 *AUDIT SALDO*\n\n` +
      `Gunakan: *${usedPrefix}${command} 628xxxx*\n` +
      `atau reply pesan user lalu ketik *${usedPrefix}${command}*`
    )
  }

  const rows = (BalanceAudit.loadAudit().list || [])
    .filter(item => String(item.user || '') === String(target))
    .slice(0, 10)

  if (!rows.length) return say(`📒 Belum ada audit saldo untuk *${target}*.`)

  const lines = rows.map((item, index) => {
    const date = new Date(Number(item.ts || Date.now())).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      hour12: false
    })
    const sign = Number(item.delta || 0) >= 0 ? '+' : '-'
    return (
      `*${index + 1}. ${typeLabel(item.type)}*\n` +
      `🕒 ${date}\n` +
      `💵 ${fmtRp(item.before)} → ${fmtRp(item.after)} (${sign}${fmtRp(Math.abs(Number(item.delta || 0)))})\n` +
      `🧾 Ref: ${item.reference || '-'}\n` +
      `📌 ${item.note || '-'}`
    )
  })

  return say(`📒 *AUDIT SALDO — ${target}*\n━━━━━━━━━━━━━━━━━━\n\n${lines.join('\n\n')}`)
}

handler.help = ['auditsaldo <nomor/reply>']
handler.category = ['owner']
handler.command = /^(auditsaldo|cekauditsaldo)$/i
handler.rowner = true
handler.register = false

module.exports = handler
