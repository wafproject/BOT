// commands/topup/profil.js
// ✨ PROFIL — Saldo diambil dari /database/saldousers.json
// ✅ TRX/Role diambil dari /database/users.json (sinkron dengan order.js)
// ✅ Fallback hitung TRX dari /database/tx.json bila users.tx kosong (opsional)

const fs = require('fs')
const path = require('path')
const { DATABASE_DIR } = require("../../lib/project-paths")

const DB_DIR = process.env.TOPUP_DB_DIR || DATABASE_DIR
const FILE_SALDO = path.join(DB_DIR, 'saldousers.json')
const FILE_USERS = path.join(DB_DIR, 'users.json')
const FILE_TX    = path.join(DB_DIR, 'tx.json')

function ensureDir(d){ if(!fs.existsSync(d)) fs.mkdirSync(d,{recursive:true}) }
function readJson(f, fb){ try{ return JSON.parse(fs.readFileSync(f,'utf8')) }catch{ return fb } }
function writeJson(f, v){ ensureDir(path.dirname(f)); fs.writeFileSync(f, JSON.stringify(v,null,2)) }

;(function init(){
  ensureDir(DB_DIR)
  if(!fs.existsSync(FILE_SALDO)) writeJson(FILE_SALDO, {})
  if(!fs.existsSync(FILE_USERS)) writeJson(FILE_USERS, {})      // ✅
  if(!fs.existsSync(FILE_TX))    writeJson(FILE_TX, { list: [] }) // ✅ optional
})()

const fmtRp=(n)=>'Rp '+Math.round(Number(n)||0).toLocaleString('id-ID')
const onlyNum=(s)=>String(s||'').replace(/[^\d]/g,'')
const jidNum=(jid)=>onlyNum(String(jid||'').replace(/:\d+(?=@|$)/g,'').split('@')[0]||'')
const line='━━━━━━━━━━━━━━━━━━'

const loadSaldo = ()=> readJson(FILE_SALDO, {})
const loadUsers = ()=> readJson(FILE_USERS, {})
const loadTx    = ()=> readJson(FILE_TX, { list: [] })

function getSaldo(num){
  const db = loadSaldo()
  return Number(db[num] || 0)
}

function roleLabel(role){
  const r=String(role||'bronze').toLowerCase()
  if(r==='bronze') return 'Bronze'
  if(r==='silver') return 'Silver'
  if(r==='gold')   return 'Gold'
  if(r==='owner')  return 'Owner'
  return 'Bronze'
}

// fallback: hitung trx dari tx.json kalau users.tx tidak ada
function countTrxFromTxJson(meNum){
  const tx = loadTx()
  const list = Array.isArray(tx?.list) ? tx.list : []
  // hanya transaksi order/topup (bukan komisi grup, dll)
  // di order.js transaksi punya: type? tidak; tapi punya ref_id & user
  return list.filter(it => String(it?.user || '') === String(meNum) && (it?.status === 'success' || it?.status === 'failed' || it?.status === 'pending')).length
}

// ================== HANDLER ==================
async function handler(m, ctx){
  const wafproject = ctx?.wafproject
  if (!wafproject) return

  const say = async (txt) => {
    const t = String(txt)
    try { if (typeof m.reply === 'function') return await m.reply(t) } catch (error) { console.error("[ERROR][commands/topup/profil.js]", error?.message || error) }
    return wafproject.sendMessage(m.chat, { text: t }, { quoted: m })
  }

  const command = String(ctx?.command || '').toLowerCase()
  if (command !== 'profil') return

  const meNum = jidNum(m.sender || m.key?.participant || m.key?.remoteJid || m.chat)
  const name = m?.pushName || meNum

  const users = loadUsers()
  const u = users[meNum] || {}
  const role = u.role || 'bronze'
  const saldo = getSaldo(meNum)

  // tx dari users.json (yang diupdate order.js)
  let trx = Number(u.tx || 0)

  // fallback kalau 0 tapi sebenarnya sudah ada histori transaksi
  if (!trx) {
    const fallback = countTrxFromTxJson(meNum)
    if (fallback > 0) trx = fallback
  }

  const spent = Number(u.spent || 0)

  return say(
    `👤 *PROFIL USER*\n${line}\n`+
    `👥 *Nama* : ${name}\n`+
    `🛡️ *Role* : ${roleLabel(role)}\n`+
    `💰 *Saldo* : ${fmtRp(saldo)}\n`+
    `🔁 *TRX* : ${trx}\n`+
    `🧾 *Total Belanja* : ${fmtRp(spent)}\n`+
    `${line}`
  )
}

handler.help = ['profil']
handler.category = ['topup']
handler.command = /^profil$/i
handler.register = false

module.exports = handler
