// commands/owner/digiflazz-saldo.js
// ✨ OWNER — ADDSALDO + DELSALDO (REPLY + MENTION LID SAFE)
// ✅ Saldo user disimpan di <project>/database/saldousers.json

const fs = require('fs')
const path = require('path')
const { DATABASE_DIR } = require("../../lib/project-paths")
const BalanceAudit = require("../../lib/balance-audit")

const fmtRp = (n) => 'Rp ' + Math.round(Number(n) || 0).toLocaleString('id-ID')
const onlyNum = (s) => String(s || '').replace(/[^\d]/g, '')
const line = '━━━━━━━━━━━━━━━━━━'

const DB_DIR = DATABASE_DIR
const FILE_SALDO = path.join(DB_DIR, 'saldousers.json')

function ensureDir(d){ if(!fs.existsSync(d)) fs.mkdirSync(d,{recursive:true}) }
function readJson(f, fb){ try{ return JSON.parse(fs.readFileSync(f,'utf8')) }catch{ return fb } }
function writeJson(f, v){ ensureDir(path.dirname(f)); fs.writeFileSync(f, JSON.stringify(v,null,2)) }

;(function init(){
  ensureDir(DB_DIR)
  if(!fs.existsSync(FILE_SALDO)) writeJson(FILE_SALDO, {})
})()

const loadSaldo = ()=> readJson(FILE_SALDO, {})
const saveSaldo = (v)=> writeJson(FILE_SALDO, v)

function getSaldo(num){
  const db = loadSaldo()
  return Number(db[num] || 0)
}
function setSaldo(num, val){
  const db = loadSaldo()
  db[num] = Math.max(0, Math.round(Number(val) || 0))
  saveSaldo(db)
  return db[num]
}

/* ======================
   OWNER CHECK
====================== */
function isOwnerJid(jid = '') {
  const arr = Array.isArray(global.owner) ? global.owner : []
  const me = onlyNum(jid)
  return arr.some(x => {
    if (Array.isArray(x) && x[0]) return onlyNum(x[0]) === me
    return onlyNum(x) === me
  })
}

/* ======================
   LID SAFE RESOLVER
====================== */
function normalizeJidFromNumber(input) {
  const num = String(input || '').replace(/[^0-9]/g, '')
  if (!num) return null
  return num + '@s.whatsapp.net'
}

async function resolveToRealJid(wafproject, m, rawJid) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith('@s.whatsapp.net')) return s

  // kalau bukan grup, ga bisa resolve peserta
  if (!m.isGroup) return s

  let meta
  try {
    meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const participants = meta?.participants || []

  const found = participants.find(p =>
    p?.lid === s ||
    p?.id === s ||
    p?.jid === s ||
    p?.participant === s
  )

  return found?.jid || found?.id || found?.participant || s
}

async function getTargetJid(wafproject, m, args) {
  // PRIORITAS:
  // 1) reply
  // 2) mention
  // 3) nomor manual
  let raw = null

  // reply
  if (m.quoted?.sender) raw = m.quoted.sender
  else if (m.quoted?.key?.participant) raw = m.quoted.key.participant

  // mention popup / mention biasa
  else if (m.mentionedJid?.length) raw = m.mentionedJid[0]

  // nomor manual
  else if (args[0]) {
    const n = String(args[0]).replace(/[^0-9]/g, '')
    if (n.length >= 8) return normalizeJidFromNumber(n)
  }

  const real = await resolveToRealJid(wafproject, m, raw)
  if (!real) return null

  // kalau hasil bukan s.whatsapp.net, berarti gagal resolve (lid masih)
  if (!String(real).endsWith('@s.whatsapp.net')) return null
  return real
}

/* ======================
   HANDLER
====================== */
let handler = async (m, { wafproject, args, usedPrefix, command, isOwner, isROwner }) => {
  const conn = wafproject
  const say = (t) => conn.sendMessage(m.chat, { text: String(t) }, { quoted: m })

  // Prioritaskan status owner dari handler utama agar aman saat sender memakai @lid.
  const ownerAllowed = Boolean(
    isOwner ||
    isROwner ||
    isOwnerJid(m.sender || m.key?.participant || m.chat)
  )
  if (!ownerAllowed) return say('Khusus owner.')

  const cmd = String(command || '').toLowerCase()
  const argText = (args || []).join(' ').trim()

  if (cmd === 'addsaldo' || cmd === 'delsaldo') {
    const toks = argText.split(/\s+/).filter(Boolean)

    // =========================
    // PARSING NOMINAL (token terakhir)
    // - kalau reply/mention: .addsaldo 5000
    // - kalau manual nomor: .addsaldo 628xxx 5000
    // - kalau mention: .addsaldo @user 5000
    // =========================
    if (!toks.length) {
      return say(
        `❌ *Format salah*\n\n` +
        `Contoh:\n` +
        `${usedPrefix}${cmd} 628xxxx 5000\n` +
        `${usedPrefix}${cmd} @user 5000\n` +
        `atau reply user:\n${usedPrefix}${cmd} 5000`
      )
    }

    const amtToken = toks[toks.length - 1]
    const amt = Number(String(amtToken).replace(/[^\d]/g, '')) || 0
    if (!amt) {
      return say(
        `❌ Nominal tidak valid.\n\n` +
        `Contoh:\n` +
        `${usedPrefix}${cmd} 628xxxx 5000\n` +
        `${usedPrefix}${cmd} @user 5000\n` +
        `atau reply user:\n${usedPrefix}${cmd} 5000`
      )
    }

    // kalau user hanya kirim nominal tapi TIDAK reply & TIDAK mention → tolak (biar sama "ketat"-nya)
    if (toks.length === 1 && !m.quoted && !(m.mentionedJid && m.mentionedJid.length)) {
      return say(
        `❌ *Target belum ada*\n\n` +
        `Gunakan:\n` +
        `${usedPrefix}${cmd} @user ${amtToken}\n` +
        `${usedPrefix}${cmd} 628xxxx ${amtToken}\n` +
        `atau reply user lalu ketik:\n${usedPrefix}${cmd} ${amtToken}`
      )
    }

    const targetJid = await getTargetJid(conn, m, toks)
    if (!targetJid) {
      return say(
        `❌ Gagal membaca nomor asli dari mention.\n\n` +
        `Solusi:\n` +
        `1) Mention pakai popup yang benar\n` +
        `2) Atau reply pesan user lalu ketik: ${usedPrefix}${cmd} ${amtToken}\n` +
        `3) Atau pakai nomor: ${usedPrefix}${cmd} 628xxxx ${amtToken}`
      )
    }

    const num = String(targetJid).replace(/:\d+(?=@|$)/g, '').split('@')[0].replace(/[^0-9]/g, '')
    const ownerNumber = onlyNum(m.sender || m.key?.participant || m.chat)
    const mutation = BalanceAudit.applyMutation({
      user: num,
      delta: cmd === 'addsaldo' ? amt : -amt,
      type: cmd === 'addsaldo' ? 'admin_credit' : 'admin_debit',
      source: 'owner_command',
      reference: `${cmd}:${Date.now()}`,
      actor: ownerNumber,
      note: `${cmd} oleh owner`,
      allowClamp: true
    })
    const awal = Number(mutation.before || 0)
    const akhir = Number(mutation.after || 0)

    return conn.sendMessage(
      m.chat,
      {
        text:
`${cmd === 'addsaldo' ? '✅ *SALDO DITAMBAHKAN*' : '✅ *SALDO DIKURANGI*'}
${line}
👤 *User*       : @${num}
📱 *Nomor*      : *${num}*
💵 *Saldo Awal*  : ${fmtRp(awal)}
💰 *Saldo Akhir* : ${fmtRp(akhir)}
${line}`,
        mentions: [targetJid]
      },
      { quoted: m }
    )
  }
}

handler.help = ['addsaldo <no/@user/reply> <nominal>', 'delsaldo <no/@user/reply> <nominal>']
handler.category = ['owner']
handler.command = /^(addsaldo|delsaldo)$/i
handler.rowner = true
handler.register = false

module.exports = handler
