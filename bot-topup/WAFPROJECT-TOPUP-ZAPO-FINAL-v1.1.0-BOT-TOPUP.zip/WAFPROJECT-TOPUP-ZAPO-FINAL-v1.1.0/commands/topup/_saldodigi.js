// Owner — cek saldo Digiflazz
const Digiflazz = require('../../lib/digiflazz')

const fmtRp = n => 'Rp ' + Math.round(Number(n) || 0).toLocaleString('id-ID')
const line = '━━━━━━━━━━━━━━━━━━'

let handler = async (m, { wafproject }) => {
  try {
    const cfg = Digiflazz.getConfig()
    const info = await Digiflazz.checkBalance()
    const out = `💳 *SALDO DIGIFLAZZ*\n${line}\n👤 *Username* : ${cfg.username}\n💰 *Saldo*    : ${fmtRp(info.deposit)}\n${line}`
    await wafproject.sendMessage(m.chat, { text: out }, { quoted: m })
  } catch (e) {
    await m.reply('❌ Gagal cek saldo: ' + (e?.message || e))
  }
}

handler.help = ['saldodigi', 'cekdigi', 'cekdigiflazz']
handler.category = ['owner']
handler.command = /^(saldodigi|cekdigi|cekdigiflazz)$/i
handler.register = false
handler.owner = true
module.exports = handler
