// commands/owner/digiflazz-profit.js
// ✨ Digiflazz OWNER (CJS) — SETPROFIT (+ cekprofit)
// ✅ DB STYLE: <project>/database/*.json
// ✅ LOGIKA TETAP, hanya dipisah file

const crypto = require('crypto')
const fs = require('fs')
const path = require('path')
const { DATABASE_DIR } = require("../../lib/project-paths")

const ROLE_KEYS = ['bronze', 'silver', 'gold', 'owner']
const DEFAULT_PROFIT = { bronze: 1.5, silver: 1, gold: 0.5, owner: 0 }

const md5 = (s) => crypto.createHash('md5').update(String(s)).digest('hex')
const fmtRp = (n) => 'Rp ' + Math.round(Number(n) || 0).toLocaleString('id-ID')
const onlyNum = (s) => String(s || '').replace(/[^\d]/g, '')
const line = '━━━━━━━━━━━━━━━━━━'

/* ======================
   DB FILES
====================== */
const DB_DIR = DATABASE_DIR
const FILE_USERS      = path.join(DB_DIR, 'users.json')
const FILE_PROFIT     = path.join(DB_DIR, 'profit.json')

// keep konsisten sama file utama
function ensureDir(d){ if(!fs.existsSync(d)) fs.mkdirSync(d,{recursive:true}) }
function readJson(f, fb){ try{ return JSON.parse(fs.readFileSync(f,'utf8')) }catch{ return fb } }
function writeJson(f, v){ ensureDir(path.dirname(f)); fs.writeFileSync(f, JSON.stringify(v,null,2)) }

;(function init(){
  ensureDir(DB_DIR)
  if(!fs.existsSync(FILE_USERS))      writeJson(FILE_USERS,{})
  if(!fs.existsSync(FILE_PROFIT))     writeJson(FILE_PROFIT,{ ...DEFAULT_PROFIT })
})()

const loadProfit = ()=> readJson(FILE_PROFIT,{ ...DEFAULT_PROFIT })
const saveProfit = (v)=> writeJson(FILE_PROFIT, v)

// users.json tetap ikut di-root loader kamu (tidak dipakai di sini), tapi tetap ada
const loadUsers = ()=> readJson(FILE_USERS,{})
const saveUsers = (v)=> writeJson(FILE_USERS, v)

function getTopupRoot(_db) {
  const T = {
    users: loadUsers(),
    profit: loadProfit(),
    _save() {
      saveUsers(this.users || {})
      saveProfit(this.profit || { ...DEFAULT_PROFIT })
    }
  }
  if (!T.users || typeof T.users !== 'object') T.users = {}
  if (!T.profit || typeof T.profit !== 'object') T.profit = { ...DEFAULT_PROFIT }
  return T
}

function roleLabel(role) {
  const r = String(role || 'bronze').toLowerCase()
  if (r === 'bronze') return 'Bronze'
  if (r === 'silver') return 'Silver'
  if (r === 'gold') return 'Gold'
  if (r === 'owner') return 'Owner'
  return 'Bronze'
}

/* ======================
   OWNER CHECK
====================== */
function isOwnerJid(jid = '') {
  const arr = Array.isArray(global.owner) ? global.owner : []
  const me = onlyNum(jid)
  return arr.some(x => {
    if (Array.isArray(x) && x[0]) return onlyNum(x[0]) === me
    return onlyNum(x) === me
  })
}

/* ======================
   TEMPLATES
====================== */
const tplProfit = (p) =>
  `📈 *PROFIT ROLES*
${line}
🥉 *Bronze* : ${p.bronze}%
🥈 *Silver* : ${p.silver}%
🥇 *Gold*   : ${p.gold}%
👑 *Owner*  : ${p.owner}%
${line}`

/* ======================
   HANDLER
====================== */
let handler = async (m, { wafproject, db, args, usedPrefix, command, isOwner, isROwner }) => {
  const conn = wafproject
  const say = (t) => conn.sendMessage(m.chat, { text: String(t) }, { quoted: m })

  // Prioritaskan status owner dari handler utama agar aman saat sender memakai @lid.
  const ownerAllowed = Boolean(
    isOwner ||
    isROwner ||
    isOwnerJid(m.sender || m.key?.participant || m.chat)
  )
  if (!ownerAllowed) return say('Khusus owner.')

  const T = getTopupRoot(db)
  const cmd = String(command || '').toLowerCase()
  const argText = (args || []).join(' ').trim()

  if (cmd === 'cekprofit') return say(tplProfit(T.profit || DEFAULT_PROFIT))

  if (cmd === 'setprofit') {
    const [roleRaw, persenRaw] = argText.split(/\s+/)
    const role = String(roleRaw || '').toLowerCase()
    const persen = Number(String(persenRaw || '').replace(',','.').replace('%',''))
    if (!ROLE_KEYS.includes(role) || !Number.isFinite(persen)) {
      return say(`Format: *${usedPrefix}setprofit <bronze|silver|gold|owner> <persen>*`)
    }
    T.profit ||= { ...DEFAULT_PROFIT }
    T.profit[role] = persen

    T._save()
    try { await db.save?.() } catch (error) { console.error("[ERROR][commands/topup/digiflazz-profit.js]", error?.message || error) }

    return say(`✅ Profit *${roleLabel(role)}* diset *${persen}%*`)
  }

  return
}

handler.help = ['cekprofit', 'setprofit <role> <persen>']
handler.category = ['owner']
handler.command = /^(cekprofit|setprofit)$/i
handler.rowner = true
handler.register = false

module.exports = handler
