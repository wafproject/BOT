// commands/tools/sc.js
// ✅ CMD: .sc
// Kirim promo text + vCard owner (hardcoded, tidak ambil dari global.owner)

let handler = async (m, { wafproject, usedPrefix, command }) => {
  const conn = wafproject
  if (!conn) return
  if (!/^sc$/i.test(String(command || ''))) return

  const textPromo = `🔥 *BOT WHATSAPP TOP UP OTOMATIS – FULL AUTO 24 JAM* 🔥
💥 _Solusi usaha pulsa & PPOB langsung dari WhatsApp!_ 💥

🤖 *BOT WHATSAPP MULTI-FUNGSI (ZAPO)*

Bot dibangun dengan sistem stabil & aman, siap dipakai jangka panjang:

✅ Zapo versi terbaru
✅ Multi-File Auth → aman, anti logout
✅ JID Normalizer (LID-safe) → anti error nomor baru
✅ Auto reconnect (mati nyala tetap jalan)
✅ Logger rapi & ringan

💰 *BOT TOP UP OTOMATIS*
🚀 Semua transaksi langsung via WhatsApp – tanpa ribet!

⚡ *Top Up Langsung dari Chat*
• Pulsa & paket data via perintah WA
• 100% otomatis, tanpa campur tangan admin
• Bisa melayani order 24 jam non-stop

💳 *PEMBAYARAN QRIS OTOMATIS*
• QRIS dibuat otomatis oleh bot
• User bayar → saldo masuk otomatis
• Langsung masuk ke e-wallet kalian
• Tanpa konfirmasi manual
• Cepat, aman, & real-time

💸 *SISTEM SALDO & DEPOSIT*
• Deposit saldo user otomatis
• Cek status deposit
• Riwayat transaksi tersimpan rapi
• Transparan & minim kesalahan

🔗 *SUPPORT DIGIFLAZZ (REAL-TIME)*
• Sinkron produk otomatis
• Cek saldo Digiflazz
• Hitung profit otomatis
• Order top up real-time

👑 *FITUR OWNER (FULL CONTROL)*
• Multi owner
• Ganti prefix bot
• Lihat list grup bot
• Auto backup database
• Proteksi bot (anti call & anti tag)

🎯 *COCOK UNTUK:*
✅ Jualan pulsa & paket data
✅ Bot PPOB
✅ Reseller digital
✅ Usaha top up otomatis via WhatsApp

🔥 *TINGGAL PASANG, JALAN, & TERIMA ORDER!* 🔥
📲 Usaha top up makin praktis, cepat, dan profesional

> Jika minat script silahkan chat owner untuk order 👇🏻`

  // kirim promo dulu
  await conn.sendMessage(m.chat, { text: textPromo }, { quoted: m })

  // ✅ hardcoded owner vCard
  const ownerNum = '6287731282876'
  const displayName = 'Enzi Developer'
  const ownerJid = ownerNum + '@s.whatsapp.net'

  const vcard =
`BEGIN:VCARD
VERSION:3.0
FN:${displayName}
TEL;type=CELL;type=VOICE;waid=${ownerNum}:${ownerNum}
END:VCARD`

  // kirim vcard
  await conn.sendMessage(m.chat, {
    contacts: {
      displayName,
      contacts: [{ vcard }]
    }
  }, { quoted: m })
}

handler.help = ['sc']
handler.category = ['tools']
handler.command = /^(sc)$/i
handler.register = false

module.exports = handler
