// ✨ Plugin Copy Nomor (FINAL - TANPA NAMA) ✨
// Cmd:
// .copy @mention
// (reply pesan user) .copy
//
// ✅ Global Anti-LID
// ✅ Mention & Reply
// ✅ Native tombol "SALIN NOMOR"
// ❌ TANPA nama (sesuai request)

const { nativeFlowMessage, copyButton } = require('../../lib/zapo-message')

const handler = async (m, { wafproject }) => {
  try {
    if (!m || !wafproject) return
    if (m.fromMe) return

    // ===== ambil target (reply > mention)
    const raw =
      m?.quoted?.sender ||
      m?.quoted?.key?.participant ||
      (Array.isArray(m?.mentionedJid) && m.mentionedJid[0])

    if (!raw) {
      return m.reply(
        "Tag atau reply targetnya.\n\nContoh:\n.copy @user\natau reply pesan user lalu ketik: .copy"
      )
    }

    // ===== normalize via GLOBAL Anti-LID
    const jid = normJid(raw)
    if (!String(jid || "").endsWith("@s.whatsapp.net")) {
      return m.reply("Gagal mengambil nomor asli. Coba reply pesan target.")
    }

    const number = String(jid).split("@")[0].replace(/\D/g, "")
    if (!number) return m.reply("Nomor tidak valid.")

    const text =
      `✅ *BERHASIL COPY NOMOR*\n\n` +
      `📱: ${jid}\n\n` +
      `Tekan tombol di bawah untuk menyalin nomor`

    // ===== native-flow Zapo (raw Proto.IMessage, tanpa wrapper viewOnce legacy)
    const msg = nativeFlowMessage({
      text,
      buttons: [copyButton("📋 SALIN NOMOR", number)]
    })

    await wafproject.sendMessage(m.chat, msg, { quote: m })
  } catch {
    try {
      const raw =
        m?.quoted?.sender ||
        m?.quoted?.key?.participant ||
        (Array.isArray(m?.mentionedJid) && m.mentionedJid[0])
      const jid = normJid(raw)
      const number = String(jid).split("@")[0].replace(/\D/g, "")
      await m.reply(
        `✅ *BERHASIL COPY NOMOR*\n\n` +
        `📱: ${jid}\n\n` +
        `Nomor:\n${number}`
      )
    } catch (error) { console.error("[ERROR][commands/tools/copy.js]", error?.message || error) }
  }
}

handler.help = ["copy @mention", "copy (reply)"]
handler.category = ["tools"]
handler.command = /^(\.?(copy))$/i
handler.register = true

module.exports = handler

// ===================
// GLOBAL NORMALIZER
// ===================
function normJid(id) {
  try {
    if (typeof global.normalizeJid === "function") return String(global.normalizeJid(id) || "")
    if (typeof global.jidNormalized === "function") return String(global.jidNormalized(id) || "")
    if (global.JidNormalizer?.normalize) return String(global.JidNormalizer.normalize(id) || "")
  } catch (error) { console.error("[ERROR][commands/tools/copy.js]", error?.message || error) }
  return String(id || "").trim()
}