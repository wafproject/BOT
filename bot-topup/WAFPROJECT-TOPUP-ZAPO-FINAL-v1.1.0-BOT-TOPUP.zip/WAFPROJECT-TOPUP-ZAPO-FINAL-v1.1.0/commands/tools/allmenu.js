/**
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒

WAF PROJECT — BUAT BOT SEMAKIN KEREN ✨
BUTUH PANEL UNTUK RUN BOT? HUBUNGI: 0877-3128-2876 📞
JASA PEMBUATAN BOT WHATSAPP 🤖
*/

const moment = require('moment-timezone')
const db = require('../../lib/db')
const { nativeFlowMessage, quickReplyButton, singleSelectButton } = require('../../lib/zapo-message')
moment.tz.setDefault('Asia/Jakarta').locale('id')

// =========================
// Helper Waktu & Tanggal
// =========================
const formatJamWIB = (d = new Date()) =>
  moment(d).tz('Asia/Jakarta').format('HH:mm:ss')
const formatTanggalPendek = (d = new Date()) =>
  moment(d).tz('Asia/Jakarta').format('DD MMM YYYY').toUpperCase()
const formatHariEN = (d = new Date()) =>
  moment(d).tz('Asia/Jakarta').format('dddd').toUpperCase()

// =========================
// Fancy text (small caps)
// =========================
const smallCapsMap = {
  a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ',
  h: 'ʜ', i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ',
  o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ', s: 'ꜱ', t: 'ᴛ', u: 'ᴜ',
  v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
}
function toSmallCaps (str = '') {
  return String(str)
    .split('')
    .map(ch => smallCapsMap[ch.toLowerCase()] || ch)
    .join('')
}

function toTitleCase (str = '') {
  return String(str)
    .replace(/_/g, ' ')
    .toLowerCase()
    .replace(/\b\w/g, c => c.toUpperCase())
}

// =========================
// ✅ Rapihin command biar gak semerawut
// - buang command simbol doang (=>, >, $, dll)
// - potong command kepanjangan
// =========================
function cleanCmdText (cmd = '') {
  let c = String(cmd).trim()
  if (!c) return ''

  // buang command yang cuma simbol / operator
  if (/^[^a-zA-Z0-9]+$/.test(c)) return ''

  // rapihin: spasi -> hilang, panjang max 32
  c = c.replace(/\s+/g, '')
  if (c.length > 32) c = c.slice(0, 32) + '…'
  return c
}

// =========================
// Build data dari global.plugins
// ✅ Ambil dari plugin.help (bukan plugin.command)
// =========================
function buildCategoryMapFromPlugins () {
  const map = {}
  const plugins = global.plugins || []

  for (const plug of plugins) {
    if (!plug) continue
    if (plug.disabled) continue

    // ✅ sekarang sumber menu dari help
    const helpsRaw = plug.help
    if (!helpsRaw) continue

    const cat = String(plug.category || 'lainnya').toLowerCase().trim()
    if (!cat) continue

    const helps = Array.isArray(helpsRaw) ? helpsRaw : [helpsRaw]

    // ambil token pertama dari help: "daftar [opsi]" -> "daftar"
    const cmds = helps
      .map(h => String(h || '').trim())
      .filter(Boolean)
      .map(h => h.split(/\s+/)[0])
      .map(cleanCmdText)
      .filter(Boolean)

    if (!cmds.length) continue

    map[cat] ||= []
    for (const c of cmds) {
      map[cat].push({ cmd: c, desc: plug.description || '-' })
    }
  }

  // unique + sort
  for (const k of Object.keys(map)) {
    const seen = new Set()
    map[k] = map[k]
      .filter(x => {
        const key = `${x.cmd}`
        if (seen.has(key)) return false
        seen.add(key)
        return true
      })
      .sort((a, b) => a.cmd.localeCompare(b.cmd))
  }

  return map
}

function countMenuAndFitur (catMap) {
  const menu = Object.keys(catMap || {}).length
  let fitur = 0
  for (const cmds of Object.values(catMap || {})) fitur += cmds.length
  return { menu, fitur }
}

// =========================
// ✅ Format list command (kategori) - style lu TETAP
// =========================
function formatCmdList (cmds = [], prefix = '.') {
  if (!cmds.length) return '│ (kosong)'
  return cmds.map(x => `│ • ${prefix}${toSmallCaps(x.cmd)}`).join('\n')
}

function blockCategoryMenu (rawTag, cmds = [], prefix = '.') {
  const pretty = toSmallCaps(String(rawTag || '').replace(/_/g, ' '))
  return [
    `╭─❖  *ᴍᴇɴᴜ ${pretty}*`,
    formatCmdList(cmds, prefix),
    '╰───────────────❖'
  ].join('\n')
}

function resolveCategoryTag (input, catMap) {
  if (!input) return null
  const low = input.toLowerCase()

  if (catMap[low]) return low

  const variants = [
    low,
    low.replace(/\s+/g, ''),
    low.replace(/\s+/g, '_'),
    low.replace(/\s+/g, '-')
  ]

  const keys = Object.keys(catMap || {})
  for (const v of variants) {
    const found = keys.find(k => k.toLowerCase() === v)
    if (found) return found
  }

  const partial = keys.find(k => k.toLowerCase().startsWith(low))
  return partial || null
}

// =========================
// Main Handler
// =========================
const menulist = async (m, { wafproject, usedPrefix, command, args }) => {
  const catMap = buildCategoryMapFromPlugins()
  const allTags = Object.keys(catMap).sort()
  const { menu, fitur } = countMenuAndFitur(catMap)

  const now = new Date()
  const jam = formatJamWIB(now)

  const hari = toSmallCaps(formatHariEN(now))
  const tanggal = toSmallCaps(formatTanggalPendek(now))

  const hour = moment(now).tz('Asia/Jakarta').hour()
  let waktuTxt = 'ᴘᴀɢɪ 🌅'
  if (hour >= 11 && hour < 15) waktuTxt = 'ꜱɪᴀɴɢ ☀️'
  else if (hour >= 15 && hour < 18) waktuTxt = 'ꜱᴏʀᴇ 🌤'
  else if (hour >= 18 || hour < 4) waktuTxt = 'ᴍᴀʟᴀᴍ 🌙'

  const userName = toSmallCaps(m.name || m.pushName || 'kak')
  const botName = toSmallCaps(global.namebot || global.namabot || wafproject.user?.name || 'waf bot')
  const ownerName = toSmallCaps((global.owner?.[0]?.[1] || global.ownerName || global.namaowner || 'owner') + '')

  let modeStr = '👥 ɢʀᴜᴘ'
  try {
    const root = db.list()
    root.settings ||= {}
    if (root.settings.botMode === 'group_private') {
      modeStr = '👥 + 👤 ɢʀᴜᴘ + ᴘʀɪᴠᴀᴛ'
    }
  } catch (error) {
    console.error("[ERROR][commands/tools/allmenu.js]", error?.message || error)
  }

  const menuCount = String(menu || 0)
  const fiturCount = String(fitur || 0)

  const perintah = (args[0] || '').toLowerCase().trim()

  // =========================
  // .menu (utama)
  // =========================
  if (!perintah && command === 'menu') {
    const menuUtamaList =
      allTags.map(t => `│ • ᴍᴇɴᴜ ${toSmallCaps(t)}`).join('\n') || '│ (kosong)'

    const textMenu = [
      `ʜᴀʟᴏ, ꜱᴇʟᴀᴍᴀᴛ *${waktuTxt}*, ᴋᴀᴋ *${userName}* 👋`,
      '',
      '╭─❖  *ᴅᴀᴛᴇ & ᴛɪᴍᴇ*',
      `│ 📆 ʜᴀʀɪ    : ${hari}`,
      `│ 📅 ᴛᴀɴɢɢᴀʟ : ${tanggal}`,
      `│ ⏰ ᴊᴀᴍ     : ${jam} ᴡɪʙ`,
      '╰───────────────❖',
      '',
      '╭─❖  *ʙᴏᴛ ɪɴꜰᴏ*',
      `│ 🏷 ɴᴀᴍᴀ   : ${botName}`,
      `│ 👑 ᴏᴡɴᴇʀ  : ${ownerName}`,
      `│ 🌐 ᴍᴏᴅᴇ ʙᴏᴛ : ${modeStr}`,
      `│ 📃 ᴍᴇɴᴜ   : ${menuCount}`,
      `│ ✨ ꜰɪᴛᴜʀ  : ${fiturCount} ꜰɪᴛᴜʀ`,
      '╰───────────────❖',
      '',
      '╭─❖  *ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ*',
      '│ • ᴀʟʟᴍᴇɴᴜ',
      menuUtamaList,
      '╰───────────────❖',
      '',
      '📂 Silakan tekan tombol *Daftar Menu* untuk pilih kategori.'
    ].filter(Boolean)

    const caption = textMenu.join('\n')

    // nativeFlow single_select rows
    const rows = []
    rows.push({
      title: 'All Menu',
      description: `Total fitur: ${fiturCount} perintah`,
      id: `${usedPrefix}allmenu`
    })

    for (const tag of allTags) {
      const cmds = catMap[tag] || []
      rows.push({
        title: toTitleCase(tag),
        description: `Total fitur: ${cmds.length} perintah`,
        id: `${usedPrefix}menu ${tag}`
      })
    }

    const listMessage = {
      title: 'Daftar Menu',
      sections: [
        { title: 'Pilih Kategori', highlight_label: 'Populer 🔥', rows }
      ]
    }

    const buttons = [
      singleSelectButton('Daftar Menu', listMessage.sections),
      // ✅ tombol sewa dihapus
      // ✅ tombol owner diganti jadi BUY SCRIPT menuju .sc
      quickReplyButton('BUY SCRIPT 🛒', `${usedPrefix}sc`)
    ]

    try {
      await wafproject.sendMessage(
        m.chat,
        nativeFlowMessage({
          text: caption,
          footer: global.namebot || 'WAF PROJECT',
          buttons
        }),
        { quote: m }
      )
    } catch (error) {
      // Beberapa sesi/grup menolak payload tombol interaktif.
      // Tetap kirim menu versi teks agar pengguna tidak melihat bot diam.
      console.error(
        `[MENU BUTTON SEND ERROR] ${m.chat}: ${error?.message || error}. Mengirim fallback teks.`
      )
      await wafproject.sendMessage(
        m.chat,
        { text: caption },
        { quote: m }
      )
    }
    return
  }

  // =========================
  // .allmenu → dump semua kategori (teks) - 1 blok per kategori
  // =========================
  if (perintah === 'all' || command === 'allmenu') {
    if (!allTags.length) return m.reply('⚠️ Belum ada data menu/kategori dari plugin.')

    const blocks = []
    for (const tag of allTags) {
      const cmds = catMap[tag] || []
      blocks.push(blockCategoryMenu(tag, cmds, usedPrefix))
    }

    await wafproject.sendMessage(m.chat, { text: blocks.join('\n\n') }, { quote: m })
    return
  }

  // =========================
  // .menu <kategori> - 1 blok saja
  // =========================
  if (perintah && command === 'menu') {
    const tag = resolveCategoryTag(perintah, catMap)

    if (!tag || !catMap[tag] || !catMap[tag].length) {
      await m.reply(
        `⚠️ Kategori *${perintah}* tidak ditemukan.\n` +
        `Gunakan *${usedPrefix}menu* lalu tekan tombol *Daftar Menu* untuk melihat list kategori.\n\n` +
        `Contoh:\n• ${usedPrefix}menu tools\n• ${usedPrefix}menu owner\n• ${usedPrefix}menu group`
      )
      return
    }

    const caption = blockCategoryMenu(tag, catMap[tag], usedPrefix)
    await wafproject.sendMessage(m.chat, { text: caption }, { quote: m })
    return
  }
}

menulist.command = ['menu', 'allmenu']
menulist.category = 'main'
menulist.description = 'Menu utama bot'

module.exports = menulist
