/**
========================
🚀 WAF PROJECT — DEBUG DIGIFLAZZ
🧑‍💻 Developer : ENZI | Adapt: WAFPROJECT-7
© 2025 — All Rights Reserved 🔒
========================
*/

// commands/owner/debugdigi.js
// ✨ Owner — DEBUG DIGIFLAZZ SIGNATURE (aman, tanpa bocor apikey)

const crypto = require('crypto')

const md5 = (s) => crypto.createHash('md5').update(String(s)).digest('hex')
const API_BASE = 'https://api.digiflazz.com/v1/'

async function postJSON(pathUrl, body) {
  if (typeof fetch !== 'function') throw new Error('fetch() tidak tersedia di Node ini.')

  const res = await fetch(API_BASE + pathUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })

  const text = await res.text()
  let json = null
  try { json = text ? JSON.parse(text) : null } catch (error) { console.error("[ERROR][commands/tools/debugdigi.js]", error?.message || error) }

  // jangan dibersihin biar kelihatan mentah alasan signature
  if (!res.ok) {
    const msg = json?.data?.message || json?.message || json?.error || text || 'Request gagal.'
    const err = new Error(msg)
    err._raw = { status: res.status, body: json || text }
    throw err
  }

  return json || {}
}

function safeStr(v){ return String(v == null ? '' : v) }
function redactedKey(k){
  const s = safeStr(k)
  if (!s) return '(empty)'
  if (s.length <= 8) return '(len ' + s.length + ')'
  return s.slice(0, 4) + '…' + s.slice(-4) + ` (len ${s.length})`
}

function guessProblem(u, k){
  const ut = safeStr(u).trim()
  const kt = safeStr(k).trim()
  if (!ut) return '❗ global.digiflazzUser kosong.'
  if (!kt) return '❗ global.digiflazzApiKey kosong.'
  if (ut !== safeStr(u)) return '⚠️ digiflazzUser ada spasi/enter (gunakan trim).'
  if (kt !== safeStr(k)) return '⚠️ digiflazzApiKey ada spasi/enter (gunakan trim).'
  if (kt.length < 20) return '⚠️ panjang apikey terlalu pendek, kemungkinan salah copy.'
  return '✅ Format variabel terlihat normal. Jika tetap salah, biasanya username API atau apikey tidak match.'
}

async function testCekSaldo(u, k){
  const sign = md5(u + k + 'depo') // sesuai docs cek-saldo
  const payload = { cmd: 'deposit', username: u, sign }
  const res = await postJSON('cek-saldo', payload)
  const saldo = Number(res?.data?.deposit ?? res?.data?.balance ?? 0)
  return { ok: true, saldo, signPrefix: sign.slice(0, 10) }
}

let handler = async (m, { wafproject, isOwner }) => {
  const conn = wafproject
  if (!conn) return

  if (!isOwner) {
    return conn.sendMessage(m.chat, { text: '❌ Khusus owner.' }, { quoted: m })
  }

  const uRaw = safeStr(global.digiflazzUser || '')
  const kRaw = safeStr(global.digiflazzApiKey || '')

  const u = uRaw.trim()
  const k = kRaw.trim()

  const signDepo = md5(u + k + 'depo')
  const dummyRef = 'DBG' + Date.now()
  const signRef  = md5(u + k + dummyRef)

  let out =
`🧪 *DEBUG DIGIFLAZZ*
━━━━━━━━━━━━━━━━━━
👤 Username(raw): *${uRaw || '(empty)'}*
👤 Username(trim): *${u || '(empty)'}*
🔑 ApiKey: *${redactedKey(kRaw)}*
🔑 ApiKey(trim): *${redactedKey(k)}*

🧾 Sign(cek-saldo / depo):
• md5(user + key + "depo") = *${signDepo.slice(0, 12)}…*

🧾 Sign(transaksi / ref):
• ref dummy: *${dummyRef}*
• md5(user + key + ref) = *${signRef.slice(0, 12)}…*

📌 Diagnosa:
${guessProblem(uRaw, kRaw)}
━━━━━━━━━━━━━━━━━━`

  // test hit API cek saldo
  try {
    const r = await testCekSaldo(u, k)
    out += `\n\n✅ *TEST CEK SALDO BERHASIL*\n💰 Deposit: *Rp ${r.saldo.toLocaleString('id-ID')}*`
  } catch (e) {
    const rawMsg = safeStr(e?.message || e)
    out += `\n\n❌ *TEST CEK SALDO GAGAL*\nAlasan: *${rawMsg}*`

    // hint lebih spesifik kalau signature salah
    if (/signature/i.test(rawMsg) && /salah|invalid|wrong/i.test(rawMsg)) {
      out +=
        `\n\n🔎 *Hint cepat*\n` +
        `• Pastikan username ini adalah *username API* (bukan hanya login panel)\n` +
        `• Pastikan apikey adalah *buyer api key* yang aktif\n` +
        `• Kalau baru ganti key, update settings.js lalu restart bot`
    }
  }

  await conn.sendMessage(m.chat, { text: out }, { quoted: m })
}

handler.help = ['debugdigi']
handler.category = ['owner']
handler.command = /^debugdigi$/i
handler.rowner = false

module.exports = handler
