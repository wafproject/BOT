/**
========================
🚀 WAF PROJECT — CEK NICKNAME GAME (CJS)
🧑‍💻 Adapt: WAFPROJECT-7
========================
Endpoint: https://api.isan.eu.org/nickname
Docs: /<game>?id=... [&server=...]
========================
*/

const onlyNum = (s) => String(s || '').replace(/[^\d]/g, '')
const line = '━━━━━━━━━━━━━━━━━━'

const API_BASE = 'https://api.isan.eu.org/nickname'
const TIMEOUT_MS = 8000
const CACHE_TTL_MS = 10 * 60 * 1000
const _cache = new Map()

function normGame(g) {
  return String(g || '').trim().toLowerCase()
}

function cacheGet(key) {
  const v = _cache.get(key)
  if (!v) return null
  if (v.expiresAt <= Date.now()) { _cache.delete(key); return null }
  return v
}
function cacheSet(key, val) {
  _cache.set(key, { ...val, expiresAt: Date.now() + CACHE_TTL_MS })
}

function gameNeedsServer(game) {
  return ['ml', 'la', 'mcgg', 'pgr'].includes(game)
}

function helpText(prefix) {
  return `🎮 *CEK NICKNAME GAME*
${line}
*Format:*
${prefix}cekign <game> <id> [server]

*Contoh:*
• ${prefix}cekign ml 1114917746 13486
• ${prefix}cekign ff 225009777
• ${prefix}cekign gi 600000000
• ${prefix}cekign la 22512309 milestone
• ${prefix}cekign pgr 16746755 AP
• ${prefix}cekign valo Westbourne#USA

*Daftar game (kode):*
gi, hi, hsr, la, ld, mcgg, pb, pgr, sm, sus, valo, zzz, aov, cod, ff, ml
${line}`
}

async function fetchNick({ game, id, server }) {
  if (typeof fetch !== 'function') throw new Error('fetch() tidak tersedia di Node ini.')

  const g = normGame(game)
  const _id = String(id || '').trim()
  const _server = String(server || '').trim()

  if (!g) throw new Error('Game kosong.')
  if (!_id) throw new Error('ID kosong.')

  // cache key
  const key = `${g}|${_id}|${_server}`
  const c = cacheGet(key)
  if (c) return { ...c, cached: true }

  const qs = new URLSearchParams()
  qs.set('id', _id)
  if (_server) qs.set('server', _server)

  const url = `${API_BASE}/${encodeURIComponent(g)}?${qs.toString()}`

  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), TIMEOUT_MS)

  try {
    const res = await fetch(url, { method: 'GET', signal: ac.signal })
    const j = await res.json().catch(() => null)

    // asumsi output: { success:boolean, game?:string, id?:..., server?:..., name:string, message?:string }
    const ok = !!j?.success
    const name = String(j?.name || '').trim()
    const message = String(j?.message || '').trim()

    const out = {
      ok,
      game: String(j?.game || g || '').toUpperCase(),
      id: j?.id ?? _id,
      server: j?.server ?? (_server || ''),
      name,
      message: message || (ok ? '' : 'Nickname tidak ditemukan')
    }

    if (ok && name) cacheSet(key, out)
    return out
  } catch (e) {
    const msg = e?.name === 'AbortError' ? 'Timeout cek nickname.' : (e?.message || String(e))
    return { ok: false, game: g.toUpperCase(), id: _id, server: _server, name: '', message: msg }
  } finally {
    clearTimeout(t)
  }
}

let handler = async (m, { wafproject, usedPrefix }) => {
  const conn = wafproject
  if (!conn) return
  const say = (t) => conn.sendMessage(m.chat, { text: String(t) }, { quoted: m })

  const raw = String(m.text || '').trim()
  const pref = (typeof usedPrefix === 'string' && usedPrefix) ? usedPrefix : (global?.prefix || '.')
  let text = raw

  // strip prefix 1x kalau masih kebawa
  if (pref && text.startsWith(pref)) text = text.slice(pref.length).trim()

  const cmd = (text.split(/\s+/)[0] || '').toLowerCase()
  const args = text.split(/\s+/).slice(1)

  if (!['cekign', 'cekid', 'cekname', 'ign'].includes(cmd)) return

  if (args.length < 2) return say(helpText(pref))

  const game = normGame(args[0])
  const idRaw = args[1]
  const serverRaw = args.slice(2).join(' ').trim()

  // normalisasi id untuk game yang id-nya numeric (biar user masukin pakai simbol/spasi tetap aman)
  // NOTE: valorant id boleh ada '#', point blank id bisa alnum, jadi jangan force numeric semua.
  const numericGames = new Set(['gi', 'hi', 'hsr', 'ld', 'sm', 'sus', 'zzz', 'aov', 'cod', 'ff', 'ml', 'mcgg'])
  const id = numericGames.has(game) ? onlyNum(idRaw) : String(idRaw || '').trim()
  const server = serverRaw

  if (gameNeedsServer(game) && !server) {
    return say(`❌ Game *${game.toUpperCase()}* butuh parameter *server/zone*.\nContoh: *${pref}cekign ${game} ${id || '<id>'} <server>*`)
  }

  await say('⏳ Mengecek nickname...')

  const r = await fetchNick({ game, id, server })

  if (!r.ok) {
    return say(`❌ *Gagal cek nickname*
${line}
🎮 *Game*   : ${r.game || game.toUpperCase()}
🆔 *ID*     : ${id || '-'}${server ? `\n🗺️ *Server* : ${server}` : ''}
${line}
⚠️ *Alasan* : ${r.message || '-'}
${line}`)
  }

  return say(`✅ *Nickname ditemukan*
${line}
🎮 *Game*   : ${r.game || game.toUpperCase()}
🆔 *ID*     : ${r.id ?? id}${r.server ? `\n🗺️ *Server* : ${r.server}` : ''}
🏷️ *Nick*   : ${r.name || '-'}${r.cached ? '\n🧠 *Cache*  : Ya' : ''}
${line}`)
}

handler.help = ['cekign <game> <id> [server]', 'cekid <game> <id> [server]']
handler.category = ['tools']
handler.command = ['cekign', 'cekid', 'cekname', 'ign']
handler.register = false

module.exports = handler
