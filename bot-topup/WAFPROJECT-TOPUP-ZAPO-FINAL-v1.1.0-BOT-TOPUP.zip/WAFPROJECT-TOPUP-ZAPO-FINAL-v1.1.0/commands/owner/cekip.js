const https = require('https')

function httpsGet(url, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { timeout: timeoutMs, headers: { 'User-Agent': 'wafproject-bot' } }, (res) => {
      let data = ''
      res.on('data', (c) => (data += c))
      res.on('end', () => resolve({ status: res.statusCode || 0, data }))
    })
    req.on('timeout', () => req.destroy(new Error('timeout')))
    req.on('error', reject)
  })
}

async function fetchText(url) {
  // prefer fetch kalau ada
  if (typeof fetch === 'function') {
    const r = await fetch(url, { headers: { 'User-Agent': 'wafproject-bot' } })
    const t = await r.text()
    return { status: r.status, data: t }
  }
  return await httpsGet(url)
}

async function fetchJson(url) {
  const r = await fetchText(url)
  let j = null
  try { j = JSON.parse(r.data) } catch (error) { console.error("[ERROR][commands/owner/cekip.js]", error?.message || error) }
  return { status: r.status, json: j, raw: r.data }
}

function pickIPv4(text) {
  const m = String(text || '').match(/\b(\d{1,3}\.){3}\d{1,3}\b/)
  return m ? m[0] : null
}

function clean(s) {
  return String(s || '').replace(/\s+/g, ' ').trim()
}

let handler = async (m, { wafproject, usedPrefix, command }) => {
  const conn = wafproject
  if (!conn) return
  const cmd = String(command || '').toLowerCase()
  if (!/^(cekip|getip)$/i.test(cmd)) return

  const say = (t) => conn.sendMessage(m.chat, { text: String(t) }, { quoted: m })

  // beberapa sumber IP (fallback)
  const ipSources = [
    { name: 'ipify', url: 'https://api.ipify.org?format=text' },
    { name: 'ifconfig.me', url: 'https://ifconfig.me/ip' },
    { name: 'icanhazip', url: 'https://icanhazip.com/' },
    { name: 'ident.me', url: 'https://ident.me/' }
  ]

  let ip = null
  let src = null
  for (const s of ipSources) {
    try {
      const r = await fetchText(s.url)
      if (r.status >= 200 && r.status < 300) {
        const got = pickIPv4(r.data)
        if (got) { ip = got; src = s.name; break }
      }
    } catch (error) { console.error("[ERROR][commands/owner/cekip.js]", error?.message || error) }
  }

  if (!ip) {
    return say('❌ Gagal mengambil IP publik (semua provider gagal). Coba lagi nanti.')
  }

  // ambil info geo/isp (opsional)
  // ipapi.co cukup simple, limit rate kadang ada.
  let meta = null
  try {
    const r = await fetchJson(`https://ipapi.co/${ip}/json/`)
    if (r.status >= 200 && r.status < 300 && r.json && !r.json.error) meta = r.json
  } catch (error) { console.error("[ERROR][commands/owner/cekip.js]", error?.message || error) }

  const line = '━━━━━━━━━━━━━━━━━━'
  let out = `🌐 *INFO IP VPS*\n${line}\n`
  out += `📌 *Public IPv4* : ${ip}\n`
  out += `🔎 *Source*      : ${src}\n`

  if (meta) {
    const city = clean(meta.city)
    const region = clean(meta.region)
    const country = clean(meta.country_name || meta.country)
    const org = clean(meta.org || meta.asn || meta.network)
    const tz = clean(meta.timezone)

    if (org) out += `🏢 *Org/ISP*     : ${org}\n`
    if (city || region || country) out += `📍 *Lokasi*     : ${[city, region, country].filter(Boolean).join(', ')}\n`
    if (tz) out += `🕒 *Timezone*   : ${tz}\n`
  }

  out += `${line}\n`
  out += `🧾 *Cmd:* ${usedPrefix || '.'}${cmd}`

  return say(out)
}

handler.help = ['cekip', 'getip']
handler.category = ['tools']
handler.command = /^(cekip|getip)$/i
handler.rowner = true
handler.register = true

module.exports = handler
