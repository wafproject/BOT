// TOOLS - search plugin (COMMAND + FALLBACK CONTENT)
// Scan source text (tanpa require) supaya tidak error gara-gara dependensi/global

const fs = require("fs")
const path = require("path")

function safeReadDir(dir) {
  try {
    return fs.readdirSync(dir)
  } catch {
    return []
  }
}
function safeStat(p) {
  try {
    return fs.statSync(p)
  } catch {
    return null
  }
}
function safeReadFile(p) {
  try {
    return fs.readFileSync(p, "utf8")
  } catch {
    return ""
  }
}

function walkJsFiles(dir, out = []) {
  for (const name of safeReadDir(dir)) {
    const p = path.join(dir, name)
    const st = safeStat(p)
    if (!st) continue
    if (st.isDirectory()) walkJsFiles(p, out)
    else if (st.isFile() && name.endsWith(".js")) out.push(p)
  }
  return out
}

// ambil statement "handler.xxx = ...;" (bisa multi-line)
function extractAssignStatementAt(src, startIdx) {
  const slice = src.slice(startIdx)
  const semi = slice.indexOf(";")
  if (semi === -1) return slice.trim()
  return slice.slice(0, semi + 1).trim()
}

function normalizeToken(s) {
  return String(s || "")
    .replace(/^\^/, "")
    .replace(/\$$/, "")
    .replace(/[\\\/]/g, "")
    .toLowerCase()
    .trim()
}

function extractTokensFromAssign(assignText) {
  const tokens = []
  if (!assignText) return tokens

  // regex literal: = /.../i
  const eq = assignText.indexOf("=")
  if (eq !== -1) {
    const after = assignText.slice(eq + 1)
    const firstSlash = after.indexOf("/")
    const lastSlash = after.lastIndexOf("/")
    if (firstSlash !== -1 && lastSlash !== -1 && lastSlash > firstSlash) {
      const body = after.slice(firstSlash + 1, lastSlash)
      tokens.push(normalizeToken(body))
    }
  }

  // array: = ['a','b']
  const arrMatch = assignText.match(/\[([\s\S]*?)\]/)
  if (arrMatch && arrMatch[1]) {
    arrMatch[1]
      .split(",")
      .map((s) => s.trim())
      .forEach((v) => {
        const cleaned = v.replace(/^['"`]|['"`]$/g, "")
        if (cleaned) tokens.push(normalizeToken(cleaned))
      })
  }

  // string: = 'afk'
  const strMatch = assignText.match(/=\s*['"`]([^'"`]+)['"`]/)
  if (strMatch && strMatch[1]) tokens.push(normalizeToken(strMatch[1]))

  return [...new Set(tokens.filter(Boolean))]
}

function extractAllPossibleCommands(src) {
  const out = new Set()
  const keys = ["handler.command", "handler.help", "handler.alias", "handler.category"]

  for (const key of keys) {
    let pos = 0
    while (true) {
      const idx = src.indexOf(key, pos)
      if (idx === -1) break
      const stmt = extractAssignStatementAt(src, idx)
      extractTokensFromAssign(stmt).forEach((t) => out.add(t))
      pos = idx + key.length
    }
  }
  return [...out]
}

function escapeRegExp(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}

async function reply(m, wafproject, text) {
  // ✅ FIX: kalau m.reply gak ada, fallback ke sendMessage
  try {
    if (typeof m?.reply === "function") return await m.reply(text)
  } catch (error) { console.error("[ERROR][commands/owner/srchp.js]", error?.message || error) }
  try {
    if (wafproject && typeof wafproject.sendMessage === "function") {
      return await wafproject.sendMessage(m.chat, { text }, { quoted: m })
    }
  } catch (error) { console.error("[ERROR][commands/owner/srchp.js]", error?.message || error) }
}

function pickPluginsRoot() {
  // ✅ prioritas: folder commands di root project
  const cwdCommands = path.join(process.cwd(), "commands")
  if (safeStat(cwdCommands)?.isDirectory()) return cwdCommands

  // fallback: 1 level di atas file (kalau file ada di commands/owner)
  const up1 = path.resolve(__dirname, "..")
  if (safeStat(up1)?.isDirectory()) return up1

  // fallback terakhir
  return process.cwd()
}

let handler = async (m, { args, usedPrefix, command, wafproject }) => {
  if (!args[0]) {
    return reply(
      m,
      wafproject,
      `📌 Contoh penggunaan :\n\n${usedPrefix + command} afk\n${usedPrefix + command} menu`
    )
  }

  const keyword = String(args[0]).replace(/[^a-zA-Z0-9]/g, "").toLowerCase()
  if (!keyword) return reply(m, wafproject, "❌ Keyword tidak valid.")

  const pluginsRoot = pickPluginsRoot()

  const files = walkJsFiles(pluginsRoot).filter(
    (p) => path.basename(p) !== path.basename(__filename)
  )

  const foundByCommand = []
  const foundByContent = []
  const kwRe = new RegExp(`\\b${escapeRegExp(keyword)}\\b`, "i")

  for (const filePath of files) {
    const src = safeReadFile(filePath)
    if (!src) continue

    const rel = path
      .relative(pluginsRoot, filePath)
      .split(path.sep)
      .join("/")
      .replace(/\.js$/i, "")

    // 1) cari via command tokens
    const tokens = extractAllPossibleCommands(src)
    const hitCmd = tokens.some((t) => t.includes(keyword))
    if (hitCmd) {
      foundByCommand.push(`📁 ${rel}`)
      continue
    }

    // 2) fallback: cari keyword di nama file atau isi file
    const base = path.basename(filePath).toLowerCase()
    if (base.includes(keyword) || kwRe.test(src)) {
      foundByContent.push(`📄 ${rel}`)
    }
  }

  if (!foundByCommand.length && !foundByContent.length) {
    return reply(m, wafproject, `❌ Tidak ditemukan plugin yang terkait keyword *${keyword}*`)
  }

  let out = `🔎 *HASIL SEARCH:* ${keyword}\n`
  out += `📦 Scan file: ${files.length}\n\n`

  if (foundByCommand.length) {
    out += `✅ *Ketemu dari command (${foundByCommand.length}):*\n${foundByCommand.join("\n")}\n\n`
  } else {
    out += `⚠️ *Tidak ada yang cocok dari command.*\n\n`
  }

  if (foundByContent.length) {
    out += `🧩 *Fallback (ketemu dari isi file/nama file) (${foundByContent.length}):*\n${foundByContent.join("\n")}\n`
  }

  return reply(m, wafproject, out.trim())
}

handler.help = ["srchp <keyword>"]
handler.category = ["owner"] 
handler.command = /^srchp$/i
handler.owner = true

handler.register = true

module.exports = handler