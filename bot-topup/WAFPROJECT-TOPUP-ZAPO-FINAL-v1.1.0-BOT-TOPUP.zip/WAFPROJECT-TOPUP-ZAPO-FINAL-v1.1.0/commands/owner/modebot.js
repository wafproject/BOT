/**
 * WAF PROJECT — MODE BOT
 * Owner dapat memilih akses bot:
 *   - GRUP
 *   - GRUP + PRIVAT
 *
 * Catatan:
 * Owner selalu dapat memakai command dari private agar tidak terkunci.
 */

const db = require('../../lib/db')

const MODE_GROUP = 'group'
const MODE_GROUP_PRIVATE = 'group_private'

function normalizeMode(value = '') {
  const input = String(value || '')
    .toLowerCase()
    .trim()
    .replace(/[+&]/g, ' ')
    .replace(/[\s_-]+/g, ' ')

  if ([
    'grup',
    'group',
    'gc',
    'gconly',
    'group only',
    'grup only',
  ].includes(input)) {
    return MODE_GROUP
  }

  if ([
    'all',
    'semua',
    'publik',
    'public',
    'grup privat',
    'group private',
    'group pc',
    'grup pc',
    'grouppc',
    'gruppc',
    'grupprivate',
    'groupprivate',
  ].includes(input)) {
    return MODE_GROUP_PRIVATE
  }

  return null
}

function modeLabel(mode) {
  return mode === MODE_GROUP_PRIVATE
    ? '👥 + 👤 GRUP + PRIVAT'
    : '👥 GRUP'
}

let handler = async (m, { args, usedPrefix, command, wafproject }) => {
  const root = db.list()
  root.settings ||= {}

  if (![MODE_GROUP, MODE_GROUP_PRIVATE].includes(root.settings.botMode)) {
    root.settings.botMode = MODE_GROUP
  }

  if (!args[0]) {
    return wafproject.sendMessage(
      m.chat,
      {
        text:
          `⚙️ *MODE BOT*\n` +
          `━━━━━━━━━━━━━━━━━━\n` +
          `Mode saat ini: *${modeLabel(root.settings.botMode)}*\n\n` +
          `*Pilihan:*\n` +
          `• ${usedPrefix + command} grup\n` +
          `  User hanya bisa memakai bot di grup.\n\n` +
          `• ${usedPrefix + command} grupprivat\n` +
          `  User bisa memakai bot di grup dan private.\n\n` +
          `📌 Owner tetap bisa memakai bot lewat private pada kedua mode.`
      },
      { quoted: m }
    )
  }

  const requested = normalizeMode(args.join(' '))

  if (!requested) {
    return m.reply(
      `❌ Mode tidak dikenal.\n\n` +
      `Gunakan:\n` +
      `• ${usedPrefix + command} grup\n` +
      `• ${usedPrefix + command} grupprivat`
    )
  }

  const previous = root.settings.botMode
  root.settings.botMode = requested

  try {
    await db.flush()
  } catch (error) {
    root.settings.botMode = previous
    console.error('[MODE BOT SAVE ERROR]', error?.message || error)
    return m.reply('❌ Gagal menyimpan mode bot. Pengaturan tidak diubah.')
  }

  const extra = requested === MODE_GROUP
    ? 'User biasa sekarang hanya diproses jika mengirim command dari grup. Chat private user akan diabaikan.'
    : 'User biasa sekarang dapat memakai command dari grup maupun private.'

  return wafproject.sendMessage(
    m.chat,
    {
      text:
        `✅ *MODE BOT BERHASIL DIUBAH*\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `Mode: *${modeLabel(requested)}*\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `${extra}`
    },
    { quoted: m }
  )
}

handler.help = ['modebot']
handler.category = ['owner']
handler.description = 'Atur akses bot: grup atau grup + private'
handler.command = /^(modebot|botmode)$/i
handler.owner = true

module.exports = handler
