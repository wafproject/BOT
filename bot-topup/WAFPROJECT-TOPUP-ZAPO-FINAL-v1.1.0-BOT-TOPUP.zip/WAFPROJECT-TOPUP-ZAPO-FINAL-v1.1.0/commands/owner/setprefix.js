/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒

WAF PROJECT — BUAT BOT SEMAKIN KEREN ✨
========================
 */

/**
 * Owner: Set Prefix (safe version - CJS)
 * Support: default | off | multi | regex | string
 */

const textReply = (wafproject, m, text) =>
  wafproject.sendMessage(m.chat, { text }, { quote: m })

let handler = async (m, { args, usedPrefix, command, wafproject }) => {

  // TAMPILKAN PREFIX SAAT INI
  if (!args[0]) {
    const current = wafproject.prefix ?? global.prefix
    const shown =
      current === null ? String(global.prefix) :
      current === '' ? 'OFF (tanpa prefix)' :
      Array.isArray(current) ? current.join(' , ') :
      current instanceof RegExp ? current.toString() :
      String(current)

    return textReply(wafproject, m,
`📌 *PREFIX BOT SAAT INI*
${shown}

🛠 *Penggunaan*
${usedPrefix + command} default
${usedPrefix + command} off
${usedPrefix + command} !
${usedPrefix + command} multi !.?
${usedPrefix + command} regex ^[!?.]

📎 *Contoh*
${usedPrefix + command} !
${usedPrefix + command} multi !.?
${usedPrefix + command} regex ^[!?.]`)
  }

  const sub = args[0].toLowerCase()
  let newPrefix = null

  // MODE DEFAULT
  if (sub === 'default') {
    newPrefix = null
  }

  // MODE OFF (TANPA PREFIX)
  else if (sub === 'off') {
    newPrefix = ''
  }

  // MODE MULTI PREFIX
  else if (sub === 'multi') {
    const chars = (args[1] || '').trim()
    if (!chars)
      return textReply(wafproject, m,
        `Masukkan karakter.\nContoh: ${usedPrefix + command} multi !.?`)
    newPrefix = [...new Set(chars.split(''))]
  }

  // MODE REGEX
  else if (sub === 'regex') {
    const pattern = (args[1] || '').trim()
    if (!pattern)
      return textReply(wafproject, m,
        `Masukkan regex.\nContoh: ${usedPrefix + command} regex ^[!?.]`)
    try {
      newPrefix = new RegExp(pattern)
    } catch (e) {
      return textReply(wafproject, m, `❌ Regex tidak valid:\n${e.message}`)
    }
  }

  // MODE STRING BIASA
  else {
    newPrefix = args.join(' ').trim()
    if (!newPrefix)
      return textReply(wafproject, m, 'Prefix tidak boleh kosong')
  }

  // TERAPKAN RUNTIME
  wafproject.prefix = newPrefix

  // SIMPAN KE DATABASE
  global.db.data ||= {}
  global.db.data.settings ||= {}
  const jid = wafproject.user?.jid || wafproject.user?.id || 'bot'
  const normalizedJid = String(jid || '').replace(/:\d+(?=@)/, '')

  // Simpan ke JID saat ini dan JID canonical tanpa suffix device.
  // Jadi setting tidak hilang setelah relog/re-pair WhatsApp.
  const currentSetting = global.db.data.settings[jid] ||= {}
  currentSetting.prefix = newPrefix

  const canonicalSetting = global.db.data.settings[normalizedJid] ||= {}
  canonicalSetting.prefix = newPrefix

  // Adapter bot ini memakai db.save()/db.flush(), bukan global.db.write().
  try {
    const db = require('../../lib/db')
    db.save(100)
  } catch (error) { console.error("[ERROR][commands/owner/setprefix.js]", error?.message || error) }
  await global.db.write?.()

  const finalShown =
    newPrefix === null ? String(global.prefix) :
    newPrefix === '' ? 'OFF (tanpa prefix)' :
    Array.isArray(newPrefix) ? newPrefix.join(' , ') :
    newPrefix instanceof RegExp ? newPrefix.toString() :
    String(newPrefix)

  return textReply(wafproject, m, `✅ Prefix berhasil diubah:\n${finalShown}`)
}

handler.help = ['setprefix']
handler.category = ['owner']
handler.command = /^setprefix$/i
handler.owner = true

module.exports = handler