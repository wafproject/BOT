"use strict"

const { checkLicense } = require("../../lib/sticker")
const {
  DEFAULT_MANIFEST_URL,
  formatBytes,
  checkForUpdate,
  performUpdate,
} = require("../../lib/self-updater")

function getBotNumber(wafproject) {
  const raw = String(wafproject?.user?.id || wafproject?.user?.jid || "")
  return raw.split("@")[0].split(":")[0].replace(/\D/g, "")
}

function formatNotes(notes) {
  if (!notes) return ""
  const arr = Array.isArray(notes) ? notes : [notes]
  const clean = arr.map((v) => String(v || "").trim()).filter(Boolean)
  return clean.length ? `\n\n📝 *Perubahan:*\n${clean.map((v) => `• ${v}`).join("\n")}` : ""
}

let handler = async (m, { wafproject }) => {
  if (global.__WAF_UPDATING__) {
    return m.reply("⏳ Update sedang berjalan. Jangan jalankan command update dua kali.")
  }

  const licenseNumber = getBotNumber(wafproject)
  if (!licenseNumber) return m.reply("❌ Nomor WhatsApp bot tidak terbaca. Update dibatalkan.")

  await m.reply("🔎 *WAF PROJECT UPDATE*\nMengecek licence dan versi terbaru...")

  let licensed = false
  try {
    licensed = await checkLicense(licenseNumber)
  } catch {}
  if (!licensed) {
    return m.reply(`⛔ Licence nomor *${licenseNumber}* tidak dapat diverifikasi.\nLicence mungkin sudah dicabut atau server licence sedang tidak dapat diakses.\nUpdate source ditolak.`)
  }

  let check
  try {
    check = await checkForUpdate({ licenseNumber })
  } catch (error) {
    const hint = String(error?.response?.status || "") === "404"
      ? `\n\nManifest belum tersedia di:\n${DEFAULT_MANIFEST_URL}`
      : ""
    return m.reply(`❌ Gagal mengecek update.\n${error?.message || error}${hint}`)
  }

  if (!check.hasUpdate) {
    return m.reply(
      `✅ *SOURCE SUDAH TERBARU*\n` +
      `Versi terpasang: *v${check.currentVersion}*\n` +
      `Versi server: *v${check.latestVersion}*`
    )
  }

  await m.reply(
    `⬆️ *UPDATE DITEMUKAN*\n` +
    `v${check.currentVersion} → *v${check.latestVersion}*` +
    formatNotes(check.manifest.notes || check.manifest.changelog) +
    `\n\n📦 Mengunduh dan memverifikasi update...`
  )

  try {
    const result = await performUpdate({
      manifest: check.manifest,
      licenseNumber,
      onStatus: async (step, info = {}) => {
        if (step === "backup") {
          await m.reply(`🛡️ Paket valid. Membuat backup source lama...\nJS diperiksa: *${info.jsFiles || 0} file*`)
        } else if (step === "dependencies") {
          await m.reply("📦 Source sudah diterapkan. Menyesuaikan dependency...")
        } else if (step === "rollback") {
          await m.reply("⚠️ Update gagal. Mengembalikan source dari backup...")
        }
      },
    })

    await m.reply(
      `✅ *UPDATE BERHASIL*\n` +
      `Versi: *v${result.from} → v${result.to}*\n` +
      `Ukuran: *${formatBytes(result.downloadedBytes)}*\n` +
      `Database, session dan settings.js tetap dipertahankan.\n\n` +
      `♻️ Bot akan restart otomatis.`
    )

    setTimeout(() => {
      // Exit non-zero supaya PM2/Pterodactyl menganggap proses perlu dijalankan ulang.
      process.exit(75)
    }, 2500)
  } catch (error) {
    console.error("[AUTO UPDATE ERROR]", error)
    return m.reply(`❌ *UPDATE GAGAL*\n${error?.message || error}\n\nSource lama dipulihkan jika proses sempat menerapkan file.`)
  }
}

handler.help = ["updatesc"]
handler.category = ["owner"]
handler.description = "Update source bot otomatis ke versi terbaru"
handler.command = /^updatesc$/i
handler.owner = true

module.exports = handler
