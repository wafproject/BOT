const { exec } = require("child_process")
const util = require("util")
const execPromise = util.promisify(exec)

let handler = async (m, { wafproject, usedPrefix, command, text, isOwner }) => {

    if (!text) return m.reply(`Contoh penggunaan:
${usedPrefix}=> wafproject.sendMessage(...)
${usedPrefix}> 1+1
${usedPrefix}$ ls`)
    
    // Eval async: =>
    if (command === '=>') {
        try {
            const result = await eval(`(async () => { 
                try { return await ${text} } 
                catch (e) { return e } 
            })()`)
            return m.reply(util.format(result))
        } catch (e) {
            return m.reply(util.format(e))
        }
    }

    // Eval sync: >
    if (command === '>') {
        try {
            const result = eval(text)
            return m.reply(util.format(result))
        } catch (e) {
            return m.reply(util.format(e))
        }
    }

    // Shell exec: $
    if (command === '$') {
        try {
            const { stdout, stderr } = await execPromise(text)
            let output = ''

            if (stdout) output += `*[ stdout ]*\n${stdout.trim()}\n\n`
            if (stderr) output += `*[ stderr ]*\n${stderr.trim()}`

            if (!stdout && !stderr) output = "✅ Perintah selesai tanpa output."

            return m.reply(output)
        } catch (e) {
            return m.reply(`❌ ERROR:\n${e.stderr || e.stdout || e.message}`)
        }
    }
}

handler.command = ['=>', '>', '$']
handler.category = 'owner'
handler.description = 'Eval & shell command untuk developer'
handler.owner = true

module.exports = handler