/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒

WAF PROJECT — BUAT BOT SEMAKIN KEREN ✨
BUTUH PANEL UNTUK RUN BOT? HUBUNGI: 0877-3128-2876 📞
JASA PEMBUATAN BOT WHATSAPP 🤖
========================
*/

const fs = require('fs')
const path = require('path')
const chalk = require('chalk')

// =========================
// WAKTU WIB (tanpa moment)
// =========================
const TZ_OFFSET_MIN = 7 * 60 // WIB UTC+7
function toWIBDate(date = new Date()) {
  const utc = date.getTime() + date.getTimezoneOffset() * 60000
  return new Date(utc + TZ_OFFSET_MIN * 60000)
}
const pad2 = (n) => String(n).padStart(2, '0')

const d = toWIBDate(new Date())
const locale = 'id'
const weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
const week = d.toLocaleDateString(locale, { weekday: 'long' })
const date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
const wibh = pad2(d.getHours())
const wibm = pad2(d.getMinutes())
const wibs = pad2(d.getSeconds())
const wktuwib = `${wibh} H ${wibm} M ${wibs} S`

// readMore
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

// =========================
// OWNER & BOT INFO
// =========================

// 👑 REAL OWNER (CORE DEVELOPER)
global.rowner = [
  '6283866217844@s.whatsapp.net',
  '6283866217844@s.whatsapp.net'
]


// 👥 OWNER BIASA (BOLEH BANYAK) - ROWNER TIDAK WAJIB MASUK SINI
global.owner = [
  '6283866217844@s.whatsapp.net',
  '6283866217844@s.whatsapp.net'
]// 👑 REAL OWNER (CORE DEVELOPER)

global.namaowner = 'KROKODILSTORE'
global.mod = []
global.nomorbot = '6283134717806'
global.nomorown = '6283866217844'

global.autotyping = false      // untuk typing
global.autorecording = false  // untuk recording

/*============= DIGIFLAZZ =============*/
/* Wajib diisi untuk fitur sinkron/topup Digiflazz */
global.digiflazzUser   = process.env.DIGIFLAZZ_USERNAME || 'rufaveD78JZW'
global.digiflazzApiKey = process.env.DIGIFLAZZ_API_KEY || 'r463127g-9856-2760-ftad-90g0eby370'
global.digiflazzBaseUrl = process.env.DIGIFLAZZ_BASE_URL || 'https://api.digiflazz.com'

// Digiflazz safety / scheduler
global.dfzTimeoutMs = 30 * 1000
global.dfzPendingPollMs = 10 * 1000          // jangan kurang dari 1 menit
global.dfzPendingMonitorTickMs = 5 * 1000  // scheduler lokal, request tetap mengikuti pendingPollMs
global.dfzPendingMaxAgeMs = 7 * 24 * 60 * 60 * 1000
global.dfzMaxPriceBuffer = 0                 // max_price = harga modal snapshot + buffer
global.orderDuplicateWindowMs = 15 * 1000       // cegah double order identik dalam 15 detik
global.dfzSyncEnabled = true
global.dfzSyncAtStartup = false
global.dfzSyncIntervalMs = 30 * 60 * 1000        // sinkron katalog setiap 30 menit

/*============= PAYKITA (PAYMENT GATEWAY) =============*/
// API key LIVE tersedia di PayKita -> Profil -> API Key & Keamanan.
global.paykitaApiKey = process.env.PAYKITA_API_KEY || 'pk_live_boi1gg1S1jSnDRXnk2040yo7nSIIBhUB'
global.paykitaBaseUrl = 'https://pay.digikita.id'
global.paykitaTtlSeconds = 10 * 60
global.paykitaPollMs = 2000
global.paykitaFetchTimeoutMs = 20000
global.paykitaDebug = false
global.paykitaRedirectUrl = ''

// =========================
// PREFIX
// =========================
global.prefix = ['.', '!', '/']

// =========================
// WATERMARK / BRANDING
// =========================
global.readMore = readMore
global.author = 'KROKODILSTORE'
global.namebot = 'KROKODIL V.2'
global.botdate = `DATE: ${week} ${date}\nTIME: ${wktuwib}`
global.bottime = `T I M E : ${wktuwib}`
global.week = `${week} ${date}`
global.wibb = `${wktuwib}`
global.weton = weton

// =========================
// HOT RELOAD (CommonJS)
// =========================
const FILE = __filename
fs.watchFile(FILE, () => {
  fs.unwatchFile(FILE)
  console.log(chalk.redBright("Update 'settings.js'"))
  delete require.cache[require.resolve(FILE)]
  require(FILE)
})
