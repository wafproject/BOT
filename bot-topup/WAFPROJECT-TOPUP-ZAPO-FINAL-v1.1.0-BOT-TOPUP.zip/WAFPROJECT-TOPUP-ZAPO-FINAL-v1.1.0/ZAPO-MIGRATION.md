# WAF PROJECT TOPUP — Migrasi Full Zapo

Versi ini memindahkan transport WhatsApp dari Baileys ke Zapo tanpa mengubah logic bisnis topup.

## Flow login/licence

### Metode 1 — Pairing Code
1. Pilih `1`.
2. Masukkan nomor WhatsApp.
3. Nomor tersebut langsung dicek ke licence GitHub.
4. Jika licence tidak valid: proses dihentikan, socket/pairing/plugin tidak dilanjutkan.
5. Jika valid: Zapo connect dan pairing code diminta.
6. Setelah akun benar-benar terhubung, nomor yang login harus sama dengan nomor yang telah lolos licence.
7. Baru setelah itu plugin dimuat.

### Metode 2 — QR
1. Pilih `2`.
2. Zapo menampilkan QR tanpa meminta nomor.
3. Setelah QR discan dan WhatsApp `open`, bot membaca nomor yang benar-benar login.
4. Nomor tersebut baru dicek licence.
5. Jika tidak valid: logout, session dihapus, plugin tidak dimuat.
6. Jika valid: plugin baru dimuat.

### Auto Login
Session Zapo lama tetap diperiksa licence pada `connection === open` sebelum plugin dimuat.

## Logic topup yang dipertahankan

Seluruh 13 file `commands/topup/*.js` dipertahankan byte-for-byte dari source asli:
- order Digiflazz
- PayKita order/deposit
- saldo
- audit saldo
- katalog/sync
- role
- riwayat
- profil

Recovery transaksi tetap dijalankan setelah plugin sudah berhasil dimuat dan koneksi WhatsApp sudah open.

## Zapo runtime

Dependency inti:
- `zapo-js` 1.9.0
- `@zapo-js/store-sqlite` 1.3.0
- `@zapo-js/media-utils` 1.0.0
- `better-sqlite3` 13.0.3
- `sharp` 0.35.4
- `pino` 9.14.0

Session:
- `session/zapo-state.sqlite`
- `session/.zapo-paired.json`

Store/cache:
- `database/zapo_store.json`

`canvas` lama dihapus. Generator invoice dipindah ke `sharp` supaya kompatibel dengan Node.js 22/Pterodactyl.

## Install bersih

Gunakan Node.js 22 x64.

```bash
rm -rf node_modules
rm -f package-lock.json
npm cache clean --force
npm install
npm run runtime:check
npm run check
npm run audit:zapo
npm start
```

Gunakan startup command `npm install && npm start`, bukan `npm install; npm start`.

## Audit statis

Sebelum ZIP dibuat:
- syntax seluruh JavaScript: OK
- runtime import Baileys: 0
- legacy outgoing `externalAdReply` di command: 0
- classic `buttonId/buttonText/headerType`: 0
- `m.isBaileys`: 0
- dependency `canvas`: 0
- dependency `wa-sticker-formatter`: 0

Catatan: pairing WhatsApp nyata dan request provider/payment hanya dapat diuji pada server/account milik pengguna.
