"use strict"

const fs = require("fs")
const path = require("path")
const crypto = require("crypto")
const AdmZip = require("adm-zip")

const ROOT = path.resolve(__dirname, "..")
const pkg = require(path.join(ROOT, "package.json"))
const releaseDir = path.join(ROOT, "release")
const version = String(pkg.version || "0.0.0")
const zipName = `WAFPROJECT-TOPUP-v${version}.zip`
const zipPath = path.join(releaseDir, zipName)

const skipRoot = new Set([
  "node_modules", "session", "auth", "temp", "backups", "release", ".git", "database"
])

function shouldSkip(rel) {
  const normalized = String(rel).replace(/\\/g, "/")
  const first = normalized.split("/")[0]
  return skipRoot.has(first) || normalized === ".env" || normalized === "settings.js"
}

function walk(dir, rel = "", out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const childRel = path.join(rel, entry.name)
    if (shouldSkip(childRel)) continue
    const abs = path.join(dir, entry.name)
    if (entry.isDirectory()) walk(abs, childRel, out)
    else if (entry.isFile()) out.push(childRel)
  }
  return out
}

fs.mkdirSync(releaseDir, { recursive: true })
const zip = new AdmZip()
for (const rel of walk(ROOT)) {
  zip.addLocalFile(path.join(ROOT, rel), path.dirname(rel) === "." ? "" : path.dirname(rel))
}
zip.writeZip(zipPath)

const sha256 = crypto.createHash("sha256").update(fs.readFileSync(zipPath)).digest("hex")
const manifest = {
  product: "wafproject-topup-zapo",
  version,
  zip_url: `https://raw.githubusercontent.com/wafproject/BOT/main/bot-topup/${zipName}`,
  sha256,
  notes: ["Isi changelog update di sini"],
  delete: [],
}
const manifestPath = path.join(releaseDir, "update-topup.json")
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2))

console.log(`Release: ${zipPath}`)
console.log(`SHA256 : ${sha256}`)
console.log(`Manifest: ${manifestPath}`)
console.log("Upload ZIP + update-topup.json ke folder bot-topup/ di repo GitHub wafproject/BOT.")
