#!/usr/bin/env node
const fs = require('fs')
const path = require('path')
const { spawnSync } = require('child_process')

const root = path.resolve(__dirname, '..')
const syntaxOnly = process.argv.includes('--syntax-only')
const ignored = new Set(['node_modules', '.git', 'sessions', 'temp', 'tmp'])

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) walk(full, out)
    else if (entry.isFile() && entry.name.endsWith('.js')) out.push(full)
  }
  return out
}

const files = walk(root)
let failed = 0

for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' })
  if (result.status !== 0) {
    failed++
    console.error(`\n[SYNTAX ERROR] ${path.relative(root, file)}`)
    console.error((result.stderr || result.stdout || '').trim())
  }
}

console.log(`[CHECK] Syntax: ${files.length - failed}/${files.length} file OK`)
if (failed) process.exit(1)
if (syntaxOnly) process.exit(0)

const forbidden = []
for (const file of files) {
  const rel = path.relative(root, file)
  if (rel.startsWith(`scripts${path.sep}`)) continue
  const text = fs.readFileSync(file, 'utf8')
  if (text.includes('@whiskeysockets/baileys')) forbidden.push(rel)
}

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
for (const section of ['dependencies', 'devDependencies', 'optionalDependencies']) {
  if (pkg[section]?.['@whiskeysockets/baileys']) forbidden.push(`package.json:${section}`)
}

if (forbidden.length) {
  console.error('[CHECK] Masih ada dependency/import Baileys:', forbidden.join(', '))
  process.exit(1)
}

const legacyNative = []
for (const file of files) {
  const rel = path.relative(root, file)
  if (rel.startsWith(`scripts${path.sep}`)) continue
  const text = fs.readFileSync(file, 'utf8')
  if (/require\(['"]canvas['"]\)/.test(text)) legacyNative.push(`${rel}:canvas`)
  if (text.includes('wa-sticker-formatter')) legacyNative.push(`${rel}:wa-sticker-formatter`)
}
if (pkg.dependencies?.canvas) legacyNative.push('package.json:canvas')
if (pkg.dependencies?.['wa-sticker-formatter']) legacyNative.push('package.json:wa-sticker-formatter')
if (legacyNative.length) {
  console.error('[CHECK] Legacy native sticker dependency masih ada:', legacyNative.join(', '))
  process.exit(1)
}

const required = [
  'zapo-js',
  '@zapo-js/store-sqlite',
  '@zapo-js/media-utils',
  'file-type'
]
const missing = required.filter((name) => !pkg.dependencies?.[name])
if (missing.length) {
  console.error('[CHECK] Dependency Zapo belum lengkap:', missing.join(', '))
  process.exit(1)
}

const adapterText = fs.readFileSync(path.join(root, 'lib', 'zapo-adapter.js'), 'utf8')
const migrationGuards = [
  ['pairing event', "'auth_pairing_required'"],
  ['addon event', "'message_addon'"],
  ['protocol event', "'message_protocol'"],
  ['persistent sqlite', "zapo-state.sqlite"],
  ['paired marker', ".zapo-paired.json"]
]
const missingGuards = migrationGuards.filter(([, needle]) => !adapterText.includes(needle)).map(([name]) => name)
if (missingGuards.length) {
  console.error('[CHECK] Guard migrasi Zapo hilang:', missingGuards.join(', '))
  process.exit(1)
}
if (!/^(?:\^)?19(?:\.|$)/.test(String(pkg.dependencies?.['file-type'] || ''))) {
  console.error('[CHECK] file-type harus major ^19 agar kompatibel dengan @zapo-js/media-utils')
  process.exit(1)
}

console.log('[CHECK] Runtime import Baileys: 0')
console.log('[CHECK] Dependency inti Zapo: OK')
console.log('[CHECK] Legacy canvas/wa-sticker-formatter: 0')
console.log('[CHECK] Guard pairing/addon/protocol/session: OK')
