#!/usr/bin/env node
const fs = require('fs')
const path = require('path')

const root = path.resolve(__dirname, '..')
let errors = 0

function ok(label, condition, detail = '') {
  const mark = condition ? 'OK' : 'FAIL'
  console.log(`[${mark}] ${label}${detail ? ` - ${detail}` : ''}`)
  if (!condition) errors++
}

ok('index.js', fs.existsSync(path.join(root, 'index.js')))
ok('Zapo adapter', fs.existsSync(path.join(root, 'lib', 'zapo-adapter.js')))
ok('package.json', fs.existsSync(path.join(root, 'package.json')))

try {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
  ok('zapo-js dependency', Boolean(pkg.dependencies?.['zapo-js']), pkg.dependencies?.['zapo-js'] || '')
  ok('SQLite store dependency', Boolean(pkg.dependencies?.['@zapo-js/store-sqlite']), pkg.dependencies?.['@zapo-js/store-sqlite'] || '')
  ok('Media utils dependency', Boolean(pkg.dependencies?.['@zapo-js/media-utils']), pkg.dependencies?.['@zapo-js/media-utils'] || '')
  ok('file-type v19 compatibility', /^(?:\^)?19(?:\.|$)/.test(String(pkg.dependencies?.['file-type'] || '')), pkg.dependencies?.['file-type'] || '')
  ok('Baileys dependency removed', !pkg.dependencies?.['@whiskeysockets/baileys'])
} catch (error) {
  ok('package.json valid JSON', false, error.message)
}

const sessionDir = path.join(root, 'sessions')
const marker = path.join(sessionDir, '.zapo-paired.json')
const db = path.join(sessionDir, 'zapo-state.sqlite')
console.log(`[INFO] Session DB: ${fs.existsSync(db) ? 'ada' : 'belum ada'}`)
console.log(`[INFO] Paired marker: ${fs.existsSync(marker) ? 'ada' : 'belum ada'}`)

if (errors) process.exit(1)
console.log('[HEALTH] Pemeriksaan project selesai tanpa error statis.')
