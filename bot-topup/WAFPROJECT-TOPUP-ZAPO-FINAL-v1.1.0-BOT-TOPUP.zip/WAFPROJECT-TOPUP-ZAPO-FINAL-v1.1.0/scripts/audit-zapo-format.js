#!/usr/bin/env node
'use strict'

const fs = require('fs')
const path = require('path')

const root = path.resolve(__dirname, '..')
const commandRoot = path.join(root, 'commands')
const indexFile = path.join(root, 'index.js')
const adapterFile = path.join(root, 'lib', 'zapo-adapter.js')

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) walk(full, out)
    else if (entry.isFile() && entry.name.endsWith('.js')) out.push(full)
  }
  return out
}

const problems = []
const commandFiles = walk(commandRoot)
const allRuntimeFiles = [...commandFiles, ...walk(path.join(root, 'lib')), indexFile]

function add(file, label) {
  problems.push(`${path.relative(root, file)}: ${label}`)
}

for (const file of allRuntimeFiles) {
  const text = fs.readFileSync(file, 'utf8')
  if (/require\(['"]@(?:whiskeysockets|adiwajshing)\/baileys['"]\)|from\s+['"]@(?:whiskeysockets|adiwajshing)\/baileys['"]/.test(text)) {
    add(file, 'runtime import Baileys')
  }
}

// These are source-level outgoing Baileys-era payloads that caused rendering
// differences under Zapo. Raw WhatsApp Proto context used only inside the Zapo
// adapter is intentionally not rejected here.
const forbiddenCommandPatterns = [
  [/\bexternalAdReply\s*:/, 'externalAdReply di command (gunakan sendRichPreview)'],
  [/\binteractiveButtons\s*:/, 'interactiveButtons legacy'],
  [/\bbuttonId\s*:/, 'buttonId classic'],
  [/\bbuttonText\s*:/, 'buttonText classic'],
  [/\bheaderType\s*:/, 'headerType classic'],
  [/\bforwardingScore\s*:/, 'forwardingScore di content/contextInfo'],
  [/\bisForwarded\s*:/, 'isForwarded di content/contextInfo'],
  [/\bm\.isBaileys\b/, 'guard m.isBaileys legacy']
]

for (const file of commandFiles) {
  const text = fs.readFileSync(file, 'utf8')
  for (const [re, label] of forbiddenCommandPatterns) {
    if (re.test(text)) add(file, label)
  }
}

const indexText = fs.readFileSync(indexFile, 'utf8')
for (const [needle, label] of [
  ['makeWASocket', 'makeWASocket legacy'],
  ['useMultiFileAuthState', 'useMultiFileAuthState legacy'],
  ['patchMessageBeforeSending', 'patchMessageBeforeSending legacy'],
  ['fetchLatestBaileysVersion', 'fetchLatestBaileysVersion legacy']
]) {
  if (indexText.includes(needle)) add(indexFile, label)
}

if (!fs.existsSync(adapterFile)) add(adapterFile, 'Zapo adapter tidak ditemukan')

if (problems.length) {
  console.error('[ZAPO FORMAT AUDIT] GAGAL')
  for (const problem of problems) console.error(` - ${problem}`)
  process.exit(1)
}

console.log(`[ZAPO FORMAT AUDIT] ${commandFiles.length} plugin source diperiksa`)
console.log('[ZAPO FORMAT AUDIT] Runtime import Baileys: 0')
console.log('[ZAPO FORMAT AUDIT] Legacy outgoing externalAdReply/buttons/forwarding di command: 0')
console.log('[ZAPO FORMAT AUDIT] Legacy m.isBaileys guard: 0')
console.log('[ZAPO FORMAT AUDIT] index.js memakai createZapoSocket/createZapoAuthState')
console.log('[ZAPO FORMAT AUDIT] OK')
