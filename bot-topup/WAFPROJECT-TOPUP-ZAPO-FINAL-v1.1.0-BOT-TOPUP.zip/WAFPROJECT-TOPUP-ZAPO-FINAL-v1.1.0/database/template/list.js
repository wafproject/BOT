/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
 
WAF PROJECT — BUAT BOT SEMAKIN KEREN ✨
BUTUH PANEL UNTUK RUN BOT? HUBUNGI: 0877-3128-2876 📞
JASA PEMBUATAN BOT WHATSAPP 🤖
========================
 */

// database/template/list.js
// Kumpulan template + helper applyTemplate (CommonJS)

// ===== ARRAY TEMPLATE =====
const templates = [
  {
    name: "Template 1",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "│⊸",
    data: `𝗛𝗮𝗹𝗼 𝗸𝗮𝗸 @name 🌹

┌─[ 🛒 *@group* ]─✧
│📆 *Date:* \`@date\`
│⏰ *Time:* \`@time\`
└──────────────────✧

(｡•ㅅ•｡)
┌∪━∪━[ *KATALOG* ]━
│
@list
│
└──────────────────✧

Untuk melihat detail, *ketik nama produk* 
Contoh : "Canva"`,
  },
  {
    name: "Template 2",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "- ",
    data: `Halo @name

Selamat Datang di grub @group

📆 Tanggal : @date
⏰ Jam     : @time

╭✄┈ BERIKUT DAFTAR LIST🍧
@list
╰──────────◇
Untuk Melihat List menu
Ketik *teks* di atas`,
  },
  {
    name: "Template 3",
    isUppercase: true,
    sortList: true,
    orderNumber: true,
    prefixSymbol: "┊⫹⫺",
    data: `Halo @name

Berikut Daftar List
╭═┅═━––––––❍
@list
╰═┅═━––––––❍`,
  },
  {
    name: "Template 4",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "┃ 𖥻 ",
    data: `말차, • ──, 𝗁𝖺𝗅𝗈𝗈 @name nama ﹗𝗄𝖾𝗍𝗂𝗄 𝗅𝗂𝗌𝗍 𝖽𝗂𝖻𝖺𝗐𝖺𝗁 𝗂𝗇𝗂 𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗇𝖺𝗆𝗉𝗂𝗅𝗄𝖺𝗇 𝖺𝗅𝗅 𝗉𝗋𝗈𝖽𝖚𝗄 ꒱ 🧺 𝅄   .

🎀 ⸼ 𝗱𝗮𝘁𝗲  ꧇ @date

╭  ❝ 🏷️ 𝗰𝗮𝘁𝗮𝗹𝗼𝗴𝘂𝗲 사랑
@list
╰    ┄─ׅ─ ─  ʚ⃘ɞ  ─ ─ׅ─┄ 


 🛒  𝅃 𝗻𝗼𝘁𝗲  ..
 𝗍𝗋𝖺𝗇𝗌𝖺𝗄𝗌𝗂 𝗁𝗮𝗇𝗒𝗮 𝗆𝗲𝗅𝗮𝗅𝗎𝗂 𝖺𝖽𝗆𝗂𝗇 ,
 𝗇𝗈 𝗌𝗉𝖺𝗆 𝖻𝗈𝗍 ,
 𝗈𝗋𝖽𝖾𝗋 𝗉𝖺𝗍𝗎𝗁𝗂 𝗌𝗇𝗄 𝗒𝗀 𝖻𝗲𝗋𝗅𝖺𝗄𝗎 .`,
  },
  {
    name: "Template 5",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "┆ 𐙚 ",
    data: `𝗵𝗮𝗶𝗶𝗶 @name Ꮺ  . . 

❲ 🎀  아름다움 ❳  ..  ‣ 𝗹𝗶𝘀𝘁 " :
╭──────────── ʚɞ  ⸼──╮ 
@list
╰── ʚɞ  ⸼────────────╯

| " .. 비엘   ▸   𝗻𝗼𝘁𝗲 📋 : 
> 𝖺𝗅𝗅 𝗍𝗋𝖺𝗇𝗌𝖺𝗄𝗌𝗂 𝗈𝗇𝗅𝗒 𝗄𝖾 admin
> 𝗄𝖾𝗍𝗂𝗄 𝗽𝗮𝘆 𝗎𝗇𝗍𝗎𝗸 𝗉𝖾𝗆𝖻𝖺𝗒𝖺𝗋𝖺𝗇
> 𝖺𝖽𝗆𝗂𝗇 𝗃𝗎𝗀𝖺 𝗆𝖺𝗇𝗎𝗌𝗂𝖺 𝗁𝖺𝗋𝖺𝗉 𝖻𝗲𝗋𝖘𝖺𝖻𝖺𝗋.`,
  },
  {
    name: "Template 6",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "📝",
    data: `❋々┈–––┈–––┈⳹
Hi kak @name Selamat @greeting 🌚🏙️ , Selamat datang di *@group* pada pukul _@time_ .🫣

💥 𝘚𝘪𝘭𝘢𝘩𝘬𝘢𝘯 𝘬𝘦𝘵𝘪𝘬 𝘱𝘳𝘰𝘥𝘶𝘬 𝘺𝘢𝘯𝘨 𝘵𝘦𝘳𝘴𝘦𝘥𝘪𝘢 𝘥𝘪 𝘣𝘢𝘸𝘢𝘩 𝘪𝘯𝘪. 🐣
@list

┈–––┈–––┈⳹`,
  },
  {
    name: "Template 7",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "»",
    data: `Hari @day
*⬇️ List Menu ⬇️*

@list

Untuk Melihat List menu
Ketik *teks* di atas`,
  },
  {
    name: "Template 8",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "◧",
    data: `@greeting kak @name

*DAFTAR LIST*
@list

_Untuk Melihat List menu_
_Ketik *teks* di atas_`,
  },
  {
    name: "Template 9",
    isUppercase: true,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "┊┊ ׁ𔘓 ࣪.",
    data: `╭╮━━━━━━━━━━━━━━━━━━━┓
┆┊.   ︶꒷꒦︶ ๋࣭ ⭑ ꒰ᐢ. .ᐢ꒱ ⭑. ๋ ︶꒷꒦︶ 
┆┊.           𝐃𝐀𝐅𝐓𝐀𝐑 𝐌𝐄𝐍𝐔
┆┊          ︶︶︶  ୨୧  ︶︶︶ 
┆┆ selamat @greeting kak @name 
┆┆ @date 
┆┆ @time 
┆╰─── • ┈ ┈ ୨♡୧  ┈ ┈ • ───
@list`,
  },
  {
    name: "Template 10",
    isUppercase: false,
    sortList: true,
    orderNumber: false,
    prefixSymbol: "*╰⋆.🎀*",
    data: `𝗛-𝗛𝗲𝗹𝗹𝗼𝘄𝘄 𝗞𝗮𝗮 @name ✧
⊂⊃ ‘ 제아, 𝗰𝝰𝘁𝝰𝗹𝗼𝗴𝘂𝗲' 𝘀𝘁𝗼𝗿𝗲 𝓼 ₎ა
   ╰╸◌ 𝗄𝖾𝗍𝗂𝗄 𝗇𝖺𝗆𝖾 𝗅𝗂𝗌𝗍 𝖽𝗂 𝖻𝖺𝗐𝖺𝗁 🍒 ꒱
╭──┄┄───┄┄┄─┄─┄─╮
│
@list
│
╰╸ 𝂅ׄ ┄╶─꯭─꯭─꯭─꯭─꯭─꯭───┈╶╯
‧₊˚✩ 𝘁𝗵𝗲 𝗹𝗶𝘁𝘁𝗹𝗲 𝗻𝗼𝘁𝗲𝗱 🍓
> ⓘ 𝗍𝗋𝖺𝗇𝗌𝖺𝗄𝗌𝗂 𝖽𝗂 𝗀𝖼 𝗇𝗈 𝗉𝖼
> ⓘ 𝖽𝗈𝗇𝗍 𝗌𝗉𝖺𝗆 𝖻𝗈𝗍
> ⓘ 𝗍𝖺𝗀 𝗮𝗱𝗺𝗶𝗻 𝗄𝖺𝗅𝗈 𝗌𝗅𝗈𝗐 𝗋𝖾𝗌𝗉𝗈𝗇`,
  },
]

// ===== APPLY TEMPLATE (FIX LIST ONLY) =====
function applyTemplate(templateIndex = 1, data = {}) {
  const idx = Number(templateIndex) || 1
  const selectedTemplate = templates[idx - 1] || templates[0]

  const safe = {
    name: data.name ?? "kak",
    date: data.date ?? "-",
    day: data.day ?? "-",
    time: data.time ?? "-",
    desc: data.desc ?? "",
    group: data.group ?? "Grup",
    greeting: data.greeting ?? "",
    size: data.size ?? "",
    list: Array.isArray(data.list) ? data.list : [],
  }

  let list = [...safe.list]

  if (selectedTemplate.sortList) {
    list.sort((a, b) =>
      String(a).localeCompare(String(b), "id", { sensitivity: "base" })
    )
  }

  // ===== FIX LIST PRODUK =====
  const renderedList = list
    .map((rawItem, i) => {
      let item = String(rawItem ?? "").trim()
      if (!item) return null

      item = item.replace(/\r/g, "").replace(/\n+/g, " ")

      if (selectedTemplate.isUppercase) {
        item = item.toUpperCase()
      }

      const order = selectedTemplate.orderNumber ? `${i + 1}. ` : ""
      const prefix = selectedTemplate.prefixSymbol
        ? `${selectedTemplate.prefixSymbol} `
        : ""

      return `${prefix}${order}*${item}*`
    })
    .filter(Boolean)
    .join("\n")

  return String(selectedTemplate.data || "")
    .replace(/@name/g, String(safe.name))
    .replace(/@date/g, String(safe.date))
    .replace(/@day/g, String(safe.day))
    .replace(/@desc/g, String(safe.desc))
    .replace(/@group/g, String(safe.group))
    .replace(/@greeting/g, String(safe.greeting))
    .replace(/@size/g, String(safe.size))
    .replace(/@time/g, String(safe.time))
    .replace(/@list/g, renderedList)
}

// ===== EXPORT =====
const TEMPLATE_COUNT = templates.length
module.exports = {
  applyTemplate,
  TEMPLATE_COUNT,
  templates,
}