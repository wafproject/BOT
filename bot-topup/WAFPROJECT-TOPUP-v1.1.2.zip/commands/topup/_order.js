/**
========================
🚀 WAF PROJECT — TOPUP ORDER (CJS) — SALDO + PAYKITA QRIS
🧑‍💻 Developer : ENZI | Adapt: WAFPROJECT-7
© 2025 — All Rights Reserved 🔒
========================
*/

const crypto = require('crypto')
const QRCode = require('qrcode')
const fs = require('fs')
const path = require('path')
const PayKita = require('../../lib/paykita')
const BalanceAudit = require('../../lib/balance-audit')
const Digiflazz = require('../../lib/digiflazz')
const InvoiceImage = require('../../lib/invoice-image')
const { availability, typeDisplayName } = require('../../lib/topup-product-utils')

// ✅ axios untuk fallback nickname ML
const axios = require('axios')
const { DATABASE_DIR } = require("../../lib/project-paths")

// ================== UTIL ==================
const md5 = (s) => crypto.createHash('md5').update(String(s)).digest('hex')
const onlyNum = (s) => String(s || '').replace(/[^\d]/g, '')
const jidNum = (jid) => onlyNum(String(jid || '').replace(/:\d+(?=@|$)/g, '').split('@')[0] || '')
const fmtRp = (n) => 'Rp ' + Math.round(Number(n) || 0).toLocaleString('id-ID')
const now = () => Date.now()
const line = '━━━━━━━━━━━━━━━━━━'
// ================== OWNER JID ==================
function normalizeToJid(val) {
  if (!val) return null
  const s = String(val)
  if (s.includes('@s.whatsapp.net')) return s
  const digits = s.replace(/\D/g, '')
  return digits ? `${digits}@s.whatsapp.net` : null
}

function getOwnerJid() {
  const fromSetting = normalizeToJid(global.nomorown || global.nomorowner)
  if (fromSetting) return fromSetting

  try {
    if (Array.isArray(global.owner)) {
      const first = global.owner?.[0]
      if (Array.isArray(first)) return normalizeToJid(first[0])
      return normalizeToJid(first)
    }
  } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }

  return normalizeToJid(global.rowner)
}

async function sendReportOwner(conn, payload) {
  const ownerJid = getOwnerJid()
  if (!ownerJid) return
  try {
    await conn.sendMessage(ownerJid, { text: tplReportOwner(payload) })
  } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }
}

// ================== NICKNAME LOOKUP ==================
const NICK_API_BASE = 'https://api.isan.eu.org/nickname'
const NICK_TIMEOUT_MS = 8000
const NICK_CACHE_TTL_MS = 10 * 60 * 1000
const NICK_CACHE_MAX = 1000
const _nickCache = new Map()

function normalizeNickname(nick) {
  return String(nick || '')
    .replace(/\+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function normGame(g) {
  return String(g || '').trim().toLowerCase()
}

function nickCacheGet(key) {
  const v = _nickCache.get(key)
  if (!v) return null
  if (v.expiresAt <= Date.now()) {
    _nickCache.delete(key)
    return null
  }
  return v
}

function nickCacheSet(key, val) {
  if (_nickCache.size >= NICK_CACHE_MAX && !_nickCache.has(key)) {
    const oldestKey = _nickCache.keys().next().value
    if (oldestKey !== undefined) _nickCache.delete(oldestKey)
  }
  _nickCache.set(key, { ...val, expiresAt: Date.now() + NICK_CACHE_TTL_MS })
}

function gameNeedsServer(game) {
  return ['ml', 'la', 'mcgg', 'pgr'].includes(game)
}

const ISAN_GAMES = new Set([
  'gi', 'hi', 'hsr', 'la', 'ld', 'mcgg', 'pb', 'pgr',
  'sm', 'sus', 'valo', 'zzz', 'aov', 'cod', 'ff', 'ml'
])

function detectGameFromProduct(prod, code) {
  const c = String(code || prod?.code || '').trim().toLowerCase()
  const namaProduk = String(prod?.name || '').trim().toLowerCase()
  const namaBrand = String(prod?.brand || '').trim().toLowerCase()
  const namaKategori = String(prod?.category || '').trim().toLowerCase()
  const gameField = String(prod?.game || '').trim().toLowerCase()

  if (gameField && ISAN_GAMES.has(gameField)) return gameField

  const hay = `${c} ${namaProduk} ${namaBrand} ${namaKategori}`

  if (/\bmobile\s*legends\b|\bmlbb\b|\bml\b/.test(hay) || c.startsWith('ml')) return 'ml'
  if (/\bfree\s*fire\b|\bff\b/.test(hay) || c.startsWith('ff')) return 'ff'
  if (/\bcall\s*of\s*duty\b|\bcod\b/.test(hay) || c.startsWith('cod')) return 'cod'
  if (/\barena\s*of\s*valor\b|\baov\b/.test(hay) || c.startsWith('aov')) return 'aov'
  if (/\bgenshin\b|\bgi\b/.test(hay) || c.startsWith('gi')) return 'gi'
  if (/\bhonkai\s*impact\b|\bhi\b/.test(hay) || c.startsWith('hi')) return 'hi'
  if (/\bstar\s*rail\b|\bhsr\b/.test(hay) || c.startsWith('hsr')) return 'hsr'
  if (/\bzenless\b|\bzzz\b/.test(hay) || c.startsWith('zzz')) return 'zzz'
  if (/\bdeepspace\b|\bld\b/.test(hay) || c.startsWith('ld')) return 'ld'
  if (/\blifeafter\b|\bla\b/.test(hay) || c.startsWith('la')) return 'la'
  if (/\bmagic\s*chess\b|\bmcgg\b/.test(hay) || c.startsWith('mcgg')) return 'mcgg'
  if (/\bpoint\s*blank\b|\bpb\b/.test(hay) || c.startsWith('pb')) return 'pb'
  if (/\bgray\s*raven\b|\bpgr\b/.test(hay) || c.startsWith('pgr')) return 'pgr'
  if (/\bsausage\b|\bsm\b/.test(hay) || c.startsWith('sm')) return 'sm'
  if (/\bsuper\s*sus\b|\bsus\b/.test(hay) || c.startsWith('sus')) return 'sus'
  if (/\bvalorant\b|\bvalo\b/.test(hay) || c.startsWith('valo')) return 'valo'

  return ''
}

// ================== RETRY + ML FALLBACK ==================
async function withRetry(fn, { retries = 2, baseDelay = 600 } = {}) {
  let lastErr
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn()
    } catch (e) {
      lastErr = e
      const code = e?.code || ''
      const msg = String(e?.message || '')
      const retriable =
        code === 'ECONNRESET' ||
        code === 'ETIMEDOUT' ||
        code === 'EAI_AGAIN' ||
        msg.includes('socket hang up') ||
        msg.toLowerCase().includes('timeout')

      if (!retriable || i === retries) break
      await new Promise(r => setTimeout(r, baseDelay * (i + 1)))
    }
  }
  throw lastErr
}

async function fetchNicknameVreden(userId, zoneId) {
  const url = `https://api.vreden.my.id/api/v1/stalker/mobilelegends?id_game=${encodeURIComponent(userId)}&id_zone=${encodeURIComponent(zoneId)}`
  const rsp = await withRetry(
    () => axios.get(url, {
      timeout: 15000,
      headers: { 'User-Agent': 'Mozilla/5.0' },
      validateStatus: () => true
    }),
    { retries: 2 }
  )

  if (rsp.status < 200 || rsp.status >= 300) {
    throw new Error(`Gagal ambil username (Vreden): ${rsp.status}`)
  }

  const result = rsp.data?.result
  if (!result) throw new Error('Akun tidak ditemukan (Vreden)')
  const username = String(result.username || '').trim()
  if (!username) throw new Error('Username kosong (Vreden)')
  return username
}

const gempay = {
  baseUrl: 'https://www.gempaytopup.com',

  getToken: async () => {
    const res = await withRetry(
      () => axios.get(gempay.baseUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
        withCredentials: true,
        validateStatus: () => true,
        timeout: 15000
      }),
      { retries: 2 }
    )

    const cookies = res.headers['set-cookie'] || []
    const joinedCookies = cookies.map(c => c.split(';')[0]).join('; ')
    const html = res.data || ''
    const m = /name="csrf-token"\s+content="([^"]+)"/i.exec(html)
    if (!m) throw new Error('CSRF token tidak ditemukan (Gempay)')
    return { csrfToken: m[1], joinedCookies }
  },

  stalkML: async (uid, zone) => {
    const { csrfToken, joinedCookies } = await gempay.getToken()

    const rsp = await withRetry(
      () => axios.post(`${gempay.baseUrl}/stalk-ml`, { uid, zone }, {
        headers: {
          'X-CSRF-Token': csrfToken,
          'Content-Type': 'application/json',
          'Cookie': joinedCookies,
          'User-Agent': 'Mozilla/5.0'
        },
        timeout: 20000,
        validateStatus: () => true
      }),
      { retries: 2 }
    )

    if (rsp.status < 200 || rsp.status >= 300) {
      throw new Error(`Gagal ambil data ML (Gempay): ${rsp.status}`)
    }

    const data = rsp.data
    if (!data) throw new Error('Data ML kosong (Gempay)')

    let unameRaw = String(data.username || data.nickname || '')
    unameRaw = unameRaw.replace(/\+/g, ' ')
    try { unameRaw = decodeURIComponent(unameRaw) } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }

    const username = unameRaw.trim()
    if (!username) throw new Error('Username kosong (Gempay)')
    return username
  }
}

async function fetchNicknameMLFallback(userId, zoneId) {
  try {
    const u = await fetchNicknameVreden(userId, zoneId)
    return { ok: true, name: normalizeNickname(u), source: 'vreden' }
  } catch (e1) {
    try {
      const u = await gempay.stalkML(userId, zoneId)
      return { ok: true, name: normalizeNickname(u), source: 'gempay' }
    } catch (e2) {
      const msg = `ML fallback gagal. Vreden: ${e1?.message || e1} | Gempay: ${e2?.message || e2}`
      return { ok: false, name: '', message: msg }
    }
  }
}

async function fetchNickIsan({ game, id, server }) {
  if (typeof fetch !== 'function') throw new Error('fetch() tidak tersedia di Node ini.')

  const g = normGame(game)
  const _id = String(id || '').trim()
  const _server = String(server || '').trim()

  if (!g || !ISAN_GAMES.has(g)) return { ok: false, name: '', message: 'Game tidak didukung.' }
  if (!_id) return { ok: false, name: '', message: 'ID kosong.' }
  if (gameNeedsServer(g) && !_server) return { ok: false, name: '', message: 'Server/zone wajib.' }

  const key = `${g}|${_id}|${_server}`
  const c = nickCacheGet(key)
  if (c) return { ...c, cached: true }

  const qs = new URLSearchParams()
  qs.set('id', _id)
  if (_server) qs.set('server', _server)
  qs.set('decode', 'false')

  const url = `${NICK_API_BASE}/${encodeURIComponent(g)}?${qs.toString()}`
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), NICK_TIMEOUT_MS)

  try {
    const res = await fetch(url, { method: 'GET', signal: ac.signal })
    const j = await res.json().catch(() => null)

    const ok = !!j?.success
    let rawName = String(j?.name || '').trim()
    const message = String(j?.message || '').trim()

    if (rawName) {
      rawName = rawName.replace(/\+/g, ' ')
      try { rawName = decodeURIComponent(rawName) } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }
    }

    if (ok && rawName) {
      const out = { ok: true, name: normalizeNickname(rawName), source: 'isan' }
      nickCacheSet(key, out)
      return out
    }

    if (g === 'ml') {
      const fb = await fetchNicknameMLFallback(_id, _server)
      if (fb.ok && fb.name) {
        const out = { ok: true, name: fb.name, source: fb.source || 'fallback' }
        nickCacheSet(key, out)
        return out
      }
      return { ok: false, name: '', message: fb.message || message || 'Nickname ML tidak ditemukan.' }
    }

    return { ok: false, name: '', message: message || 'Nickname tidak ditemukan.' }
  } catch (e) {
    const msg = e?.name === 'AbortError' ? 'Timeout cek nickname.' : (e?.message || String(e))

    if (g === 'ml' && _server) {
      const fb = await fetchNicknameMLFallback(_id, _server)
      if (fb.ok && fb.name) {
        const out = { ok: true, name: fb.name, source: fb.source || 'fallback' }
        nickCacheSet(key, out)
        return out
      }
      return { ok: false, name: '', message: fb.message || msg }
    }

    return { ok: false, name: '', message: msg }
  } finally {
    clearTimeout(t)
  }
}

// ======= PART 1 END =======
// ================== DB FILES ==================
const DB_DIR = process.env.TOPUP_DB_DIR || DATABASE_DIR
const FILE_PRODUCTS = path.join(DB_DIR, 'products.json')
const FILE_USERS    = path.join(DB_DIR, 'users.json')
const FILE_SALDO    = path.join(DB_DIR, 'saldousers.json')
const FILE_PROFIT   = path.join(DB_DIR, 'profit.json')
const FILE_TX       = path.join(DB_DIR, 'tx.json')
const FILE_PENDING  = path.join(DB_DIR, 'paykita_order_pending.json')
const FILE_DFZ_PENDING = path.join(DB_DIR, 'digiflazz_pending.json')

function ensureDir(d) {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true })
}

function readJson(f, fb) {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'))
  } catch {
    return fb
  }
}

function writeJson(f, v) {
  ensureDir(path.dirname(f))
  fs.writeFileSync(f, JSON.stringify(v, null, 2))
}

;(function init() {
  ensureDir(DB_DIR)

  if (!fs.existsSync(FILE_PRODUCTS)) writeJson(FILE_PRODUCTS, { brands: [], products: [] })
  if (!fs.existsSync(FILE_USERS))    writeJson(FILE_USERS, {})
  if (!fs.existsSync(FILE_SALDO))    writeJson(FILE_SALDO, {})
  if (!fs.existsSync(FILE_PROFIT))   writeJson(FILE_PROFIT, { bronze: 1.5, silver: 1, gold: 0.5, owner: 0 })
  if (!fs.existsSync(FILE_TX))       writeJson(FILE_TX, { list: [] })
  if (!fs.existsSync(FILE_PENDING))  writeJson(FILE_PENDING, {})
  if (!fs.existsSync(FILE_DFZ_PENDING)) writeJson(FILE_DFZ_PENDING, {})
})()

const loadProducts = () => readJson(FILE_PRODUCTS, { brands: [], products: [] })
const saveProducts = (v) => writeJson(FILE_PRODUCTS, v)
const loadUsers    = () => readJson(FILE_USERS, {})
const saveUsers    = (u) => writeJson(FILE_USERS, u)
const loadProfit   = () => readJson(FILE_PROFIT, { bronze: 1.5, silver: 1, gold: 0.5, owner: 0 })
const loadTx       = () => readJson(FILE_TX, { list: [] })
const saveTx       = (t) => writeJson(FILE_TX, t)

// ================== PENDING ORDER QRIS ==================
const loadPending = () => readJson(FILE_PENDING, {})
const savePending = (v) => writeJson(FILE_PENDING, v)

function getPending(orderId) {
  const key = String(orderId || '')
  if (!key) return null
  const pend = loadPending()
  if (pend[key]) return pend[key]
  return Object.values(pend).find(row => String(row?.orderId || '') === key) || null
}

function setPending(orderId, data) {
  const key = String(orderId || data?.orderId || '')
  if (!key) throw new Error('orderId pending QRIS wajib diisi.')
  const pend = loadPending()

  // Migrasi transparan format lama yang memakai nomor user sebagai key.
  for (const [oldKey, row] of Object.entries(pend)) {
    if (oldKey !== key && String(row?.orderId || '') === key) delete pend[oldKey]
  }

  pend[key] = { ...data, orderId: key }
  savePending(pend)
  return pend[key]
}

function clearPending(orderId) {
  const key = String(orderId || '')
  if (!key) return
  const pend = loadPending()
  delete pend[key]
  for (const [oldKey, row] of Object.entries(pend)) {
    if (String(row?.orderId || '') === key) delete pend[oldKey]
  }
  savePending(pend)
}

function pendingUserNumber(storageKey, pending) {
  const explicit = String(pending?.meNum || pending?.snapshot?.meNum || '').replace(/\D/g, '')
  if (explicit) return explicit
  const legacy = String(storageKey || '')
  return /^\d+$/.test(legacy) ? legacy : ''
}

// ================== SALDO USERS ==================
const loadSaldoDB = () => readJson(FILE_SALDO, {})
const saveSaldoDB = (v) => writeJson(FILE_SALDO, v)

function getSaldo(num) {
  const db = loadSaldoDB()
  return Number(db[num] || 0)
}

function setSaldo(num, val) {
  const db = loadSaldoDB()
  db[num] = Math.max(0, Number(val) || 0)
  saveSaldoDB(db)
  return db[num]
}

function addSaldo(num, delta) {
  const db = loadSaldoDB()
  const cur = Number(db[num] || 0)
  db[num] = Math.max(0, cur + Number(delta || 0))
  saveSaldoDB(db)
  return db[num]
}

// ================== USERS ROLE / STAT ==================
function ensureUserTopup(num) {
  const users = loadUsers()

  if (!users[num]) {
    users[num] = {
      role: 'bronze',
      tx: 0,
      spent: 0,
      profit_contrib: 0,
      created: now()
    }
  }

  saveUsers(users)

  const sdb = loadSaldoDB()
  if (typeof sdb[num] === 'undefined') {
    sdb[num] = 0
    saveSaldoDB(sdb)
  }

  return users[num]
}

function updateUserTopup(num, patchFn) {
  const users = loadUsers()

  if (!users[num]) {
    users[num] = {
      role: 'bronze',
      tx: 0,
      spent: 0,
      profit_contrib: 0,
      created: now()
    }
  }

  patchFn(users[num], users)
  saveUsers(users)

  const sdb = loadSaldoDB()
  if (typeof sdb[num] === 'undefined') {
    sdb[num] = 0
    saveSaldoDB(sdb)
  }

  return users[num]
}

function marginFor(role) {
  const p = loadProfit()
  const r = String(role || 'bronze').toLowerCase()
  return Number((p[r] ?? p.bronze) || 0)
}

function roleLabel(role) {
  const r = String(role || 'bronze').toLowerCase()
  if (r === 'bronze') return 'Bronze'
  if (r === 'silver') return 'Silver'
  if (r === 'gold') return 'Gold'
  if (r === 'owner') return 'Owner'
  return 'Bronze'
}

function normalizeOwnerNumber(value) {
  let digits = onlyNum(value)
  if (!digits) return ''
  if (digits.startsWith('0')) digits = `62${digits.slice(1)}`
  return digits
}

function configuredOwnerNumbers() {
  const out = new Set()
  const add = value => {
    if (!value) return
    if (Array.isArray(value)) return value.flat(Infinity).forEach(add)
    if (typeof value === 'object') return Object.values(value).forEach(add)
    const num = normalizeOwnerNumber(value)
    if (num) out.add(num)
  }
  add(global.nomorown || global.nomorowner)
  add(global.rowner)
  add(global.owner)
  return out
}

function effectiveRoleForUser(num, storedRole = 'bronze', ctx = {}) {
  const normalized = normalizeOwnerNumber(num)
  if (ctx?.isOwner || ctx?.isROwner || configuredOwnerNumbers().has(normalized)) return 'owner'
  return String(storedRole || 'bronze').toLowerCase()
}

const FRESH_PRICE_CACHE_TTL_MS = 15 * 1000
const _freshPriceCache = new Map()

async function refreshProductPriceBeforeConfirm(code, fallbackProduct) {
  const sku = String(code || '').trim().toUpperCase()
  if (!sku) return fallbackProduct

  const cached = _freshPriceCache.get(sku)
  if (cached && cached.expiresAt > Date.now()) return cached.product || fallbackProduct

  try {
    const response = await Digiflazz.priceList({ code: sku })
    const item = (response.products || []).find(row =>
      String(row?.buyer_sku_code || row?.code || '').trim().toUpperCase() === sku
    )
    const freshPrice = Number(item?.price || 0)
    if (!item || !(freshPrice > 0)) {
      _freshPriceCache.set(sku, { product: fallbackProduct, expiresAt: Date.now() + FRESH_PRICE_CACHE_TTL_MS })
      return fallbackProduct
    }

    const db = loadProducts()
    const idx = (db.products || []).findIndex(row => String(row?.code || '').trim().toUpperCase() === sku)
    if (idx < 0) return fallbackProduct

    const local = db.products[idx]
    const boolLike = (value, fallback) => {
      if (typeof value === 'boolean') return value
      if (value == null || value === '') return fallback
      if (/^(false|0|no|off)$/i.test(String(value).trim())) return false
      if (/^(true|1|yes|on)$/i.test(String(value).trim())) return true
      return fallback
    }
    const hasStockInfo = Object.prototype.hasOwnProperty.call(item, 'unlimited_stock') ||
      Object.prototype.hasOwnProperty.call(item, 'stock')
    const buyerOk = boolLike(item.buyer_product_status, true)
    const sellerOk = boolLike(item.seller_product_status, true)
    const unlimited = hasStockInfo ? boolLike(item.unlimited_stock, false) : true
    const stock = Number(item.stock || 0)
    const providerAvailable = Boolean(buyerOk && sellerOk && (unlimited || stock > 0))

    // Per-order refresh hanya boleh memperbarui ke harga provider yang terbaca saat ini.
    // Ini mencegah konfirmasi memakai snapshot katalog lama sebelum pembayaran dibuat.
    local.price = freshPrice
    local.status = providerAvailable ? 'open' : 'close'
    local.active = providerAvailable
    local.stale = false
    local.meta ||= {}
    local.meta.buyer_product_status = buyerOk
    local.meta.seller_product_status = sellerOk
    local.meta.unlimited_stock = unlimited
    local.meta.stock = stock
    local.meta.provider_available = providerAvailable
    local.meta.stale = false
    local.meta.last_price_check_at = Date.now()
    db.products[idx] = local
    saveProducts(db)

    _freshPriceCache.set(sku, { product: local, expiresAt: Date.now() + FRESH_PRICE_CACHE_TTL_MS })
    return local
  } catch (error) {
    // Gagal cek price-list tidak boleh mematikan bot. Order masih dilindungi max_price.
    console.error('[DIGIFLAZZ PRICE CHECK]', error?.message || error)
    _freshPriceCache.set(sku, { product: fallbackProduct, expiresAt: Date.now() + 5000 })
    return fallbackProduct
  }
}

// ================== AFFILIATE ==================
function hargaJualBot(base, roleMarginPct) {
  return Number(base) + Math.round(Number(base) * (Number(roleMarginPct) / 100))
}

function hargaFinalGrup(hargaBot, ratePct) {
  const r = Math.max(0, Number(ratePct) || 0) / 100
  const bot = Number(hargaBot) || 0
  return bot + Math.round(bot * r)
}

function getGroupRatePct(_gid) {
  return 0
}

function addGroupCommission(gid, amount, reference = '') {
  if (!gid || !gid.endsWith('@g.us')) return false

  const tx = loadTx()
  const val = Math.max(0, Number(amount) || 0)
  const ref = String(reference || '').trim()

  // Idempotent: restart di antara write komisi dan flag affiliate_applied
  // tidak boleh membuat komisi grup tercatat dua kali.
  if (ref && (tx.list || []).some(item =>
    item?.type === 'group_commission' && String(item?.reference || '') === ref
  )) {
    return true
  }

  tx.list.unshift({
    ts: now(),
    type: 'group_commission',
    gid,
    amount: val,
    reference: ref || undefined
  })

  saveTx(tx)
  return true
}



// ================== PAYKITA QRIS CONFIG ==================
const PAYKITA_TTL_SECONDS = Math.max(60, Number(global.paykitaTtlSeconds || 900))
const PAYKITA_POLL_MS = Math.max(2000, Number(global.paykitaPollMs || 5000))
const ORDER_DUPLICATE_WINDOW_MS = Math.max(3000, Number(global.orderDuplicateWindowMs || 5000))
const MAX_ORDER_QTY = Math.max(1, Math.floor(Number(global.maxOrderQty || 20)))

function createPayKitaReference(prefix, userNumber) {
  const userTail = String(userNumber || '').slice(-8)
  const random = Math.random().toString(36).slice(2, 7).toUpperCase()
  return `${prefix}-${userTail}-${Date.now()}-${random}`
}

function captionPayKita({ orderId, harga, unitPrice, qty = 1, totalPay, expiresIn, feeAmount, uniqueCode, produk, tujuanFmt, nickname, brand, kategori, tipe }) {
  const expiredMin = Math.max(1, Math.ceil(Number(expiresIn || 0) / 60))
  const qtySafe = Math.max(1, Math.floor(Number(qty || 1)))
  return `🧾 *INVOICE PEMBAYARAN*
${line}
🛍️ *Produk*    : ${produk}
🎮 *Brand*     : ${brand || '-'}
📂 *Kategori*  : ${kategori || '-'}
📦 *Tipe*      : ${tipe || '-'}
🎯 *Tujuan*    : ${tujuanFmt}
🏷️ *Nickname*  : ${nickname || '-'}
📦 *Jumlah*    : ${qtySafe}x
${line}
💰 *Harga*     : ${fmtRp(unitPrice || harga)}${qtySafe > 1 ? ' / transaksi' : ''}
${qtySafe > 1 ? `🧮 *Total*     : ${fmtRp(harga)}\n` : ''}💳 *Bayar*     : ${fmtRp(totalPay)}
🆔 *Order ID*  : ${orderId}
${Number(feeAmount || 0) > 0 ? `💸 *Fee*       : ${fmtRp(feeAmount)}\n` : ''}${Number(uniqueCode || 0) > 0 ? `🔢 *Kode Unik* : ${uniqueCode}\n` : ''}⏳ *Expired*   : ${expiredMin} menit
${line}
Silakan scan QRIS di atas.
Pesanan otomatis diproses setelah pembayaran terdeteksi.`
}

function payKitaOrderAmountsMatch(order, pending) {
  if (Number(order.baseAmount) > 0 && Number(order.baseAmount) !== Number(pending.amount)) return false
  if (Number(order.payAmount) > 0 && Number(order.payAmount) !== Number(pending.totalPayAmount)) return false
  return true
}

async function cancelPayKitaSilently(orderId) {
  try {
    await PayKita.cancelOrder(orderId)
    return true
  } catch (error) {
    console.error("[ERROR][commands/topup/_order.js]", error?.message || error)
    return false
  }
}


async function resumePaidPayKitaOrder(conn, meNum, pending, quoted = null) {
  if (!pending?.orderId) throw new Error('Pending PayKita order tidak memiliki orderId.')
  const snap = pending.snapshot || {}
  const unitPrice = Number(snap.price || 0)
  const qty = Math.max(1, Math.floor(Number(snap.qty || 1)))
  const totalPrice = Number(snap.totalPrice || (unitPrice * qty))
  if (!(unitPrice > 0) || !(totalPrice > 0)) throw new Error('Snapshot harga order PayKita tidak valid.')

  if (!Array.isArray(pending.topupRefs) || pending.topupRefs.length !== qty) {
    pending.topupRefs = Array.from({ length: qty }, (_, i) =>
      `BOTQ${Date.now()}${Math.random().toString(36).slice(2, 6).toUpperCase()}${String(i + 1).padStart(2, '0')}`
    )
    pending.topupRef = pending.topupRefs[0]
    setPending(pending.orderId, pending)
  }

  // Kredit sementara dibuat idempotent per invoice PayKita.
  // Untuk batch, kredit = total seluruh item; setiap item lalu didebit terpisah.
  const credit = BalanceAudit.applyMutation({
    user: meNum,
    delta: totalPrice,
    type: 'paykita_order_credit',
    source: 'paykita_order',
    reference: pending.orderId,
    note: `Kredit sementara pembayaran QRIS untuk ${qty} order Digiflazz`,
    idempotencyKey: `paykita-order-credit:${pending.orderId}`
  })
  if (!credit.ok) throw new Error('Gagal menerapkan kredit pembayaran PayKita.')

  const msg = quoted
    ? { ...quoted, chat: pending.chatId, sender: meNum }
    : { chat: pending.chatId, key: {}, sender: meNum }

  await doTopupBatchFromSnapshot({
    conn,
    m: msg,
    snap: { ...snap, qty, totalPrice, price: unitPrice },
    me: meNum,
    refOverrides: pending.topupRefs
  })

  return pending.topupRefs
}

function startPollingPayKitaOrder({ conn, meNum, chatId, msgKey, orderId, expiresAt }) {
  global.__WAF_PAYKITA_ORDER_POLLERS__ ||= new Map()
  const pollers = global.__WAF_PAYKITA_ORDER_POLLERS__
  if (pollers.has(String(orderId))) return pollers.get(String(orderId))

  let finished = false
  let checking = false

  const finish = () => {
    if (finished) return false
    finished = true
    clearInterval(timer)
    pollers.delete(String(orderId))
    return true
  }

  const removeQrMessage = async () => {
    try { if (msgKey) await conn.sendMessage(chatId, { delete: msgKey }) } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }
  }

  const expireUnverifiedOrder = async (error) => {
    const latest = getPending(orderId)
    if (!latest) return false
    if (!finish()) return true

    if (global.paykitaDebug) {
      console.log('[PAYKITA ORDER EXPIRED UNVERIFIED]', orderId, error?.message || error)
    }

    await removeQrMessage()
    clearPending(orderId)
    try {
      await conn.sendMessage(chatId, { text: '⏰ Waktu pembayaran habis.' }, { quoted: latest?.quoted || undefined })
    } catch (notifyError) {
      console.error('[PAYKITA ORDER EXPIRED NOTIFY ERROR]', notifyError?.message || notifyError)
    }
    return true
  }

  const tick = async () => {
    if (finished || checking) return
    checking = true

    try {
      const raw = await PayKita.getOrder(orderId)
      const order = PayKita.normalizeOrder(raw)
      const pending = getPending(orderId)

      if (!pending) {
        finish()
        return
      }

      pending.lastStatus = order.status
      pending.lastCheck = Date.now()
      pending.rawStatusLast = order.raw
      pending.verifyFailures = 0
      pending.lastVerificationError = ''
      setPending(orderId, pending)

      if (PayKita.isPaidStatus(order.status)) {
        if (!payKitaOrderAmountsMatch(order, pending)) {
          if (!finish()) return

          pending.status = 'REVIEW'
          pending.reviewReason = 'PAYKITA_AMOUNT_MISMATCH'
          pending.reviewAt = Date.now()
          pending.receivedBaseAmount = Number(order.baseAmount || 0)
          pending.receivedPayAmount = Number(order.payAmount || 0)
          setPending(orderId, pending)

          console.error('[PAYKITA ORDER] nominal pembayaran tidak cocok:', {
            orderId,
            expectedBaseAmount: Number(pending.amount || 0),
            receivedBaseAmount: Number(order.baseAmount || 0),
            expectedPayAmount: Number(pending.totalPayAmount || 0),
            receivedPayAmount: Number(order.payAmount || 0)
          })

          await removeQrMessage()
          await conn.sendMessage(chatId, {
            text:
              '⚠️ Pembayaran terdeteksi, tetapi nominal dari PayKita tidak cocok dengan invoice.\n' +
              'Pesanan ditahan untuk pemeriksaan agar saldo/order tidak diproses ganda.\n' +
              `🆔 Order ID: ${orderId}`
          }, { quoted: pending?.quoted || undefined })
          return
        }

        if (!finish()) return
        await removeQrMessage()

        const latest = getPending(orderId)
        if (!latest || latest.status !== 'PENDING') return

        latest.status = 'PROCESSING'
        latest.paidAt = Date.now()
        setPending(orderId, latest)

        try {
          const qty = Math.max(1, Number(latest?.snapshot?.qty || 1))
          await conn.sendMessage(chatId, { text: `*✅ Pembayaran terdeteksi. Memproses ${qty} pesanan...*` }, { quoted: latest?.quoted || undefined })
          await resumePaidPayKitaOrder(conn, meNum, latest, latest?.quoted || null)
          clearPending(orderId)
        } catch (error) {
          const still = getPending(orderId)
          if (still) {
            still.status = 'PROCESSING'
            still.processingError = String(error?.message || error)
            still.lastProcessingAttempt = Date.now()
            setPending(orderId, still)
          }
          await conn.sendMessage(chatId, {
            text: '⚠️ Pembayaran sudah masuk. Pesanan belum selesai diproses dan akan dilanjutkan otomatis oleh recovery bot: ' + (error?.message || error)
          }, { quoted: latest?.quoted || undefined })
        }
        return
      }

      if (PayKita.isFinalFailStatus(order.status)) {
        if (!finish()) return
        await removeQrMessage()
        const latest = getPending(orderId)
        if (latest) clearPending(orderId)
        await conn.sendMessage(chatId, {
          text: `⏰ Transaksi berakhir: *${order.status}*`
        }, { quoted: latest?.quoted || undefined })
        return
      }

      if (Date.now() >= expiresAt) {
        try {
          await PayKita.cancelOrder(orderId)
        } catch (cancelError) {
          if (global.paykitaDebug) console.log('[PAYKITA ORDER CANCEL VERIFY ERROR]', cancelError?.message || cancelError)
          await expireUnverifiedOrder(cancelError)
          return
        }

        if (!finish()) return
        await removeQrMessage()
        const latest = getPending(orderId)
        if (latest) clearPending(orderId)
        await conn.sendMessage(chatId, { text: '⏰ Waktu pembayaran habis.' }, { quoted: latest?.quoted || undefined })
      }
    } catch (error) {
      if (global.paykitaDebug) console.log('[PAYKITA ORDER POLL ERROR]', error?.message || error)
      if (Date.now() >= expiresAt) {
        await expireUnverifiedOrder(error)
      }
    } finally {
      checking = false
    }
  }

  const timer = setInterval(tick, PAYKITA_POLL_MS)
  pollers.set(String(orderId), timer)
  void tick()
  return timer
}


async function recoverPendingPayKitaOrders(conn) {
  const pendingDb = loadPending()
  const rows = Object.entries(pendingDb || {})
  let resumed = 0
  let processing = 0
  let cleared = 0

  for (const [storageKey, pendingRaw] of rows) {
    const orderId = String(pendingRaw?.orderId || storageKey || '')
    if (!orderId) continue
    const meNum = pendingUserNumber(storageKey, pendingRaw)
    if (!meNum) {
      console.error(`[PAYKITA ORDER STARTUP] ${orderId}: nomor user tidak ditemukan`)
      continue
    }

    if (storageKey !== orderId || pendingRaw?.meNum !== meNum) {
      setPending(orderId, { ...pendingRaw, meNum })
    }
    const pending = getPending(orderId) || pendingRaw
    const status = String(pending.status || 'PENDING').toUpperCase()
    const chatId = pending.chatId || `${meNum}@s.whatsapp.net`

    try {
      if (status === 'PROCESSING') {
        processing++
        await resumePaidPayKitaOrder(conn, meNum, pending, pending?.quoted || null)
        clearPending(orderId)
        resumed++
        continue
      }

      if (status === 'REVIEW' && pending.reviewReason === 'PAYKITA_STATUS_UNVERIFIED') {
        await cancelPayKitaSilently(orderId)
        clearPending(orderId)
        cleared++
        continue
      }

      if (status === 'PENDING') {
        const expiresAt = Number(pending.expiresAt || 0)
        if (!(expiresAt > Date.now())) {
          await cancelPayKitaSilently(orderId)
          clearPending(orderId)
          cleared++
          continue
        }

        startPollingPayKitaOrder({ conn, meNum, chatId, msgKey: null, orderId, expiresAt })
        resumed++
      }
    } catch (error) {
      console.error(`[PAYKITA ORDER STARTUP] ${orderId}:`, error?.message || error)
    }
  }

  return { total: rows.length, resumed, processing, cleared }
}

global.__WAF_RECOVER_PAYKITA_ORDERS__ = recoverPendingPayKitaOrders

async function handlePayKitaQrisFromState(conn, m, st) {
  const meNum = st?.snapshot?.meNum || jidNum(m?.sender || m?.key?.participant || m?.chat)
  const snap = st?.snapshot
  if (!snap) throw new Error('Snapshot order tidak ditemukan.')

  const qty = Math.max(1, Math.floor(Number(snap.qty || 1)))
  const unitPrice = Number(snap.price || 0)
  const totalPrice = Number(snap.totalPrice || (unitPrice * qty))
  if (!(unitPrice > 0) || !(totalPrice > 0)) throw new Error('Harga order tidak valid.')

  const reference = createPayKitaReference('ORD', meNum)
  const raw = await PayKita.createOrder({
    baseAmount: totalPrice,
    reference,
    ttlSeconds: PAYKITA_TTL_SECONDS,
    redirectUrl: global.paykitaRedirectUrl || undefined
  })
  const order = PayKita.normalizeOrder(raw)

  if (!order.id) throw new Error('PayKita tidak mengembalikan order id.')
  if (!order.qris && !order.checkoutUrl) throw new Error('PayKita tidak mengembalikan QRIS atau checkout URL.')

  const expiresIn = order.expiresIn > 0 ? order.expiresIn : PAYKITA_TTL_SECONDS
  const payAmount = order.payAmount > 0 ? order.payAmount : totalPrice
  const startedAt = Date.now()
  const expiresAt = startedAt + (expiresIn * 1000)
  const mapNama = mapProdukNaming(snap.prod)
  const kategori = mapNama.kategori
  const brand = mapNama.brand
  const tipe = mapNama.tipe
  const produk = mapNama.produk || snap.prod?.name || '-'

  setPending(order.id, {
    status: 'PENDING',
    orderId: order.id,
    meNum,
    reference,
    chatId: m.chat,
    amount: totalPrice,
    totalPayAmount: payAmount,
    feeAmount: order.feeAmount,
    uniqueCode: order.uniqueCode,
    checkoutUrl: order.checkoutUrl,
    startedAt,
    expiresAt,
    lastStatus: order.status || 'pending',
    rawCreate: order.raw,
    quoted: {
      key: m.key,
      message: m.message
    },
    snapshot: {
      meNum: snap.meNum,
      prod: snap.prod,
      code: snap.code,
      tujuan: snap.tujuan,
      customerParam: snap.customerParam,
      nickname: snap.nickname,
      role: snap.role,
      base: snap.base,
      price: unitPrice,
      qty,
      totalPrice,
      rateGrup: snap.rateGrup,
      hargaBot: snap.hargaBot,
      affiliateFee: snap.affiliateFee,
      gidAffiliate: snap.gidAffiliate
    }
  })

  const tujuanFmt = `${snap.tujuan.id}${snap.tujuan.server ? ` (${snap.tujuan.server})` : ''}`
  const caption = captionPayKita({
    orderId: order.id,
    harga: totalPrice,
    unitPrice,
    qty,
    totalPay: payAmount,
    expiresIn,
    feeAmount: order.feeAmount,
    uniqueCode: order.uniqueCode,
    produk,
    brand,
    kategori,
    tipe,
    tujuanFmt,
    nickname: snap.nickname || '-'
  })

  let sent
  try {
    if (order.qris) {
      const image = await QRCode.toBuffer(order.qris, {
        type: 'png',
        errorCorrectionLevel: 'H',
        width: 900
      })
      sent = await conn.sendMessage(m.chat, { image, caption }, { quoted: m })
    } else {
      sent = await conn.sendMessage(m.chat, {
        text: `${caption}\n\n🔗 *Link Pembayaran:*\n${order.checkoutUrl}`
      }, { quoted: m })
    }
  } catch (error) {
    const cancelled = await cancelPayKitaSilently(order.id)
    const latest = getPending(order.id)
    if (latest) {
      if (cancelled) {
        clearPending(order.id)
      } else {
        latest.deliveryFailed = true
        latest.deliveryError = String(error?.message || error)
        setPending(order.id, latest)
        startPollingPayKitaOrder({
          conn,
          meNum,
          chatId: m.chat,
          msgKey: null,
          orderId: order.id,
          expiresAt
        })
      }
    }
    throw new Error(`Gagal mengirim QRIS PayKita: ${error?.message || error}`)
  }

  startPollingPayKitaOrder({
    conn,
    meNum,
    chatId: m.chat,
    msgKey: sent?.key,
    orderId: order.id,
    expiresAt
  })
}

// ================== MAPPING NAMA ==================
// DB lama:
// - category
// - brand
// - subAlias
// - name
//
// Mapping baru:
// - kategori
// - brand
// - tipe
// - produk
function mapProdukNaming(prod) {
  return {
    kategori: String(prod?.category || '').trim(),
    brand: String(prod?.brand || '').trim(),
    tipe: typeDisplayName(prod?.meta?.provider_type || prod?.type || prod?.subAlias || 'Umum'),
    produk: String(prod?.name || '').trim()
  }
}

// ================== UI TEXT ==================
function invSuccessText({
  produk,
  brand,
  kategori,
  tipe,
  invoice,
  tujuan,
  nickname,
  tanggal,
  jam,
  harga,
  snOrNote,
  qty = 1,
  totalHarga = 0,
  title = 'TRANSAKSI SUKSES'
}) {
  const safeNickname = String(nickname || '').trim()
  const nicknameLine = safeNickname && safeNickname !== '-' ? `
🏷️ *Nickname*  : ${safeNickname}` : ''
  const qtySafe = Math.max(1, Math.floor(Number(qty || 1)))
  const bulkLines = qtySafe > 1
    ? `
📦 *Jumlah*    : ${qtySafe}x
💰 *Harga*     : ${fmtRp(harga)} / transaksi
🧮 *Total*     : ${fmtRp(totalHarga || (Number(harga || 0) * qtySafe))}`
    : `
💰 *Harga*     : ${fmtRp(harga)}`
  return `✅〔 *${title}* 〕✅
*${produk}*
${line}
🪼 *Invoice*   : ${invoice}
🎯 *Tujuan*    : ${tujuan}${nicknameLine}
📅 *Waktu*     : ${tanggal}
⏰ *Jam*       : ${jam} WIB${bulkLines}
${line}
🔑 *Serial Number:*
${snOrNote || '-'}
${line}`
}


function invFailedText({
  produk,
  brand,
  kategori,
  tipe,
  invoice,
  tujuan,
  nickname,
  tanggal,
  jam,
  alasan,
  refund
}) {
  return `❌〔  *TRANSAKSI GAGAL*  〕❌
*${produk}*
${line}
🎮 *Brand*     : ${brand || '-'}
🧾 *Invoice*   : ${invoice}
🎯 *Tujuan*    : ${tujuan}
🏷️ *Nickname*  : ${nickname || '-'}
📅 *Tanggal*   : ${tanggal}
⏰ *Jam*       : ${jam} WIB
${line}
⚠️ *Alasan* : ${alasan || '-'}
${line}

*_PESANAN GAGAL – SILAKAN HUBUNGI ADMIN_*

💸 *Dana kamu telah dikembalikan ke saldo* sebesar *${fmtRp(refund || 0)}*.`
}

const tplReportOwner = ({
  status,
  nama,
  nomor,
  hargaJual,
  hargaPokok,
  profit,
  jam,
  produk,
  brand,
  kategori,
  tipe,
  tujuan,
  saldoDigi,
  alasan
}) =>
  `📊 *REPORT TRANSAKSI (${String(status || '').toUpperCase()})*
${line}
👤 *Nama*        : ${nama}
📱 *Nomor*       : ${nomor}
🛍️ *Produk*      : ${produk}
🎮 *Brand*       : ${brand || '-'}
🎯 *Tujuan*      : ${tujuan}
⏰ *Jam*         : ${jam}
${status === 'sukses'
    ? `💰 *Harga Jual*  : ${fmtRp(hargaJual)}
💸 *Harga Pokok* : ${fmtRp(hargaPokok)}
📈 *Keuntungan*  : ${fmtRp(profit)}`
    : `⚠️ *Alasan*      : ${alasan || '-'}`
}
${line}
💳 *Sisa Saldo Digi :* ${fmtRp(saldoDigi)}`

// ======= PART 2 END =======
// ================== DIGIFLAZZ ==================
// Prepaid Digiflazz mengembalikan status langsung (Sukses/Pending/Gagal).
// Jika Pending/UNKNOWN, status dicek dengan mengirim ulang topup memakai
// buyer_sku_code + customer_no + ref_id yang SAMA. Request yang sama dijaga
// minimal 60 detik agar tidak memicu race condition di sisi provider.

const PENDING_POLL_MS = Math.max(10 * 1000, Number(global.dfzPendingPollMs || 60 * 1000))
const PENDING_MONITOR_TICK_MS = Math.max(10 * 1000, Number(global.dfzPendingMonitorTickMs || 15 * 1000))
const PENDING_MAX_AGE_MS = Math.min(
  89 * 24 * 60 * 60 * 1000,
  Math.max(60 * 60 * 1000, Number(global.dfzPendingMaxAgeMs || 7 * 24 * 60 * 60 * 1000))
)
const MAX_PRICE_BUFFER = Math.max(0, Number(global.dfzMaxPriceBuffer || 0))
const _dfzFinalizeLocks = new Set()
const _dfzCheckLocks = new Set()

const loadDfzPending = () => readJson(FILE_DFZ_PENDING, {})
const saveDfzPending = value => writeJson(FILE_DFZ_PENDING, value)

function getDfzPending(ref) {
  return loadDfzPending()[String(ref)] || null
}

function setDfzPending(ref, patch) {
  const db = loadDfzPending()
  const key = String(ref)
  db[key] = { ...(db[key] || {}), ...(patch || {}) }
  saveDfzPending(db)
  return db[key]
}

function clearDfzPending(ref) {
  const db = loadDfzPending()
  delete db[String(ref)]
  saveDfzPending(db)
}

function getTxByRef(ref) {
  const tx = loadTx()
  return (tx.list || []).find(item => String(item.ref_id || '') === String(ref)) || null
}

function patchTxByRef(ref, patch = {}) {
  const tx = loadTx()
  tx.list ||= []
  let item = tx.list.find(row => String(row.ref_id || '') === String(ref))
  if (!item) {
    item = { ref_id: String(ref), ts: now() }
    tx.list.unshift(item)
  }
  Object.assign(item, patch)
  saveTx(tx)
  return item
}

function recoverOrApplyBalanceMutation(ref, kind, user, amount) {
  const key = String(ref)
  const delta = kind === 'debit' ? -Math.abs(Number(amount || 0)) : Math.abs(Number(amount || 0))
  let tx = getTxByRef(key) || patchTxByRef(key, {})
  const stateKey = `${kind}_state`
  const beforeKey = `${kind}_before`
  const afterKey = `${kind}_after`

  if (tx[stateKey] === 'done') {
    recordOrderBalanceAudit(key, kind, user, tx)
    return { ok: true, balance: getSaldo(user), recovered: false }
  }

  let current = getSaldo(user)
  if (tx[stateKey] === 'prepared') {
    const before = Number(tx[beforeKey])
    const after = Number(tx[afterKey])
    if (current === after) {
      const updated = patchTxByRef(key, { [stateKey]: 'done', balance_after: current })
      recordOrderBalanceAudit(key, kind, user, updated)
      return { ok: true, balance: current, recovered: true }
    }
    if (current !== before) {
      patchTxByRef(key, { [stateKey]: 'review', balance_review_reason: `Saldo berubah saat recovery ${kind}.` })
      return { ok: false, review: true, balance: current }
    }
    setSaldo(user, after)
    current = getSaldo(user)
    const updated = patchTxByRef(key, { [stateKey]: 'done', balance_after: current })
    recordOrderBalanceAudit(key, kind, user, updated)
    return { ok: true, balance: current, recovered: true }
  }

  if (kind === 'debit' && current < Math.abs(delta)) {
    return { ok: false, insufficient: true, balance: current }
  }

  const after = Math.max(0, current + delta)
  patchTxByRef(key, { [stateKey]: 'prepared', [beforeKey]: current, [afterKey]: after })
  setSaldo(user, after)
  const finalBalance = getSaldo(user)
  const updated = patchTxByRef(key, { [stateKey]: 'done', balance_after: finalBalance })
  recordOrderBalanceAudit(key, kind, user, updated)
  return { ok: true, balance: finalBalance, recovered: false }
}

function applyOrderDebit(ref, user, amount) {
  return recoverOrApplyBalanceMutation(ref, 'debit', user, amount)
}

function applyOrderRefund(ref, user, amount) {
  return recoverOrApplyBalanceMutation(ref, 'refund', user, amount)
}

function wibDateKey(ts = Date.now()) {
  const d = new Date(Number(ts) || Date.now())
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(d)
  const get = type => parts.find(p => p.type === type)?.value || ''
  return `${get('year')}-${get('month')}-${get('day')}`
}

function hasDuplicateNonMulti(user, code, customer) {
  const today = wibDateKey()
  return (loadTx().list || []).some(tx => {
    if (!['success', 'pending', 'processing'].includes(String(tx.status || '').toLowerCase())) return false
    if (String(tx.user || '') !== String(user || '')) return false
    if (String(tx.buyer_sku_code || '').toUpperCase() !== String(code || '').toUpperCase()) return false
    if (String(tx.tujuan || tx.customer_no || '') !== String(customer || '')) return false
    return wibDateKey(tx.ts) === today
  })
}


function findRecentDuplicateOrder(user, code, customer, excludeRef = '') {
  const nowTs = Date.now()
  const userKey = String(user || '')
  const codeKey = String(code || '').toUpperCase()
  const customerKey = String(customer || '')
  const exclude = String(excludeRef || '')

  return (loadTx().list || []).find(tx => {
    if (exclude && String(tx.ref_id || '') === exclude) return false
    if (String(tx.user || '') !== userKey) return false
    if (String(tx.buyer_sku_code || '').toUpperCase() !== codeKey) return false
    if (String(tx.tujuan || tx.customer_no || '') !== customerKey) return false

    const status = String(tx.status || '').toLowerCase()

    // Anti-double hanya jendela pendek untuk mencegah klik/pesan ganda.
    // Pending lama tidak boleh mengunci user tanpa batas waktu.
    const eventAt = Number(status === 'success' ? (tx.completed_at || tx.ts || 0) : (tx.ts || 0))
    const age = nowTs - eventAt
    if (['pending', 'processing', 'queued', 'success'].includes(status) && age >= 0 && age <= ORDER_DUPLICATE_WINDOW_MS) return true

    return false
  }) || null
}

function getUserStatsSnapshot(user) {
  const users = loadUsers()
  const cur = users[String(user)] || {}
  return {
    tx: Number(cur.tx || 0),
    spent: Number(cur.spent || 0),
    profit_contrib: Number(cur.profit_contrib || 0)
  }
}

function setUserStatsSnapshot(user, snapshot = {}) {
  const key = String(user)
  const users = loadUsers()
  if (!users[key]) {
    users[key] = {
      role: 'bronze',
      tx: 0,
      spent: 0,
      profit_contrib: 0,
      created: now()
    }
  }

  users[key].tx = Number(snapshot.tx || 0)
  users[key].spent = Number(snapshot.spent || 0)
  users[key].profit_contrib = Number(snapshot.profit_contrib || 0)
  saveUsers(users)
  return getUserStatsSnapshot(key)
}

function sameUserStats(a = {}, b = {}) {
  return Number(a.tx || 0) === Number(b.tx || 0) &&
    Number(a.spent || 0) === Number(b.spent || 0) &&
    Number(a.profit_contrib || 0) === Number(b.profit_contrib || 0)
}

function applySuccessStatsJournal(ref, ctx, profit) {
  const key = String(ref)
  let tx = getTxByRef(key) || patchTxByRef(key, {})
  if (tx.stats_applied === true) return { ok: true, recovered: false }

  const current = getUserStatsSnapshot(ctx.user)

  if (tx.stats_state === 'prepared' && tx.stats_before && tx.stats_after) {
    const before = tx.stats_before
    const after = tx.stats_after

    if (sameUserStats(current, after)) {
      patchTxByRef(key, {
        stats_state: 'done',
        stats_applied: true,
        stats_recovered_at: Date.now()
      })
      return { ok: true, recovered: true }
    }

    if (sameUserStats(current, before)) {
      setUserStatsSnapshot(ctx.user, after)
      patchTxByRef(key, {
        stats_state: 'done',
        stats_applied: true,
        stats_recovered_at: Date.now()
      })
      return { ok: true, recovered: true }
    }

    patchTxByRef(key, {
      stats_state: 'review',
      stats_applied: false,
      review_required: true,
      stats_review_reason: 'Statistik user berubah saat recovery transaksi sukses.'
    })
    setDfzPending(key, {
      review_required: true,
      stats_review: true,
      nextCheckAt: 0
    })
    return { ok: false, review: true }
  }

  const after = {
    tx: current.tx + 1,
    spent: current.spent,
    profit_contrib: current.profit_contrib
  }

  if (ctx.role !== 'owner') {
    after.spent += Number(ctx.selling_price || 0)
    after.profit_contrib += Number(profit || 0)
  }

  patchTxByRef(key, {
    stats_state: 'prepared',
    stats_before: current,
    stats_after: after
  })

  setUserStatsSnapshot(ctx.user, after)
  patchTxByRef(key, {
    stats_state: 'done',
    stats_applied: true
  })
  return { ok: true, recovered: false }
}

function recordOrderBalanceAudit(ref, kind, user, tx = {}) {
  const stateKey = `${kind}_state`
  const beforeKey = `${kind}_before`
  const afterKey = `${kind}_after`
  if (tx[stateKey] !== 'done') return null

  const before = Number(tx[beforeKey])
  const after = Number(tx[afterKey])
  if (!Number.isFinite(before) || !Number.isFinite(after)) return null

  return BalanceAudit.record({
    user,
    type: kind === 'debit' ? 'order_debit' : 'order_refund',
    source: 'digiflazz_order',
    reference: ref,
    before,
    delta: after - before,
    after,
    note: kind === 'debit' ? 'Debit saldo untuk order Digiflazz' : 'Refund saldo order Digiflazz gagal',
    idempotencyKey: `order:${ref}:${kind}`
  })
}

function orderTimeParts(ts = Date.now()) {
  return {
    tanggal: new Date(ts).toLocaleDateString('id-ID', {
      timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric'
    }),
    jam: new Date(ts).toLocaleTimeString('id-ID', {
      timeZone: 'Asia/Jakarta', hour12: false
    })
  }
}

function resultReason(result) {
  if (/saldo.*(tidak|tdk).*cukup|insufficient balance/i.test(String(result?.message || ''))) {
    return 'Saldo Digi tidak cukup.'
  }
  return Digiflazz.cleanReason(result?.message || '') || 'Supplier sedang gangguan.'
}

const _bulkNotifyLocks = new Set()

function isBulkDfzContext(ctx) {
  return Boolean(ctx?.batch_id) && Array.isArray(ctx?.batch_refs) && ctx.batch_refs.length > 1
}

function bulkFailureReason(tx = {}) {
  return Digiflazz.cleanReason(tx.provider_message || tx.sn || '') || 'Transaksi gagal.'
}

async function maybeNotifyBulkInvoice(ctx, quoted = null) {
  if (!isBulkDfzContext(ctx)) return false

  const refs = ctx.batch_refs.map(String)
  const batchId = String(ctx.batch_id || `BULK-${refs[0] || Date.now()}`)
  if (_bulkNotifyLocks.has(batchId)) return false
  _bulkNotifyLocks.add(batchId)

  try {
    const rows = refs.map(ref => getTxByRef(ref))
    const allFinal = rows.every(tx => {
      const status = String(tx?.status || '').toLowerCase()
      return tx?.finalized === true && (status === 'success' || status === 'failed')
    })
    if (!allFinal) return false

    const coordinator = rows[0] || {}
    if (coordinator.batch_user_notified === true) {
      for (const ref of refs) {
        const pending = getDfzPending(ref)
        if (pending) {
          setDfzPending(ref, { user_notified: true, batch_user_notified: true })
          clearDfzPending(ref)
        }
      }
      return true
    }

    const conn = global.wafproject || global.conn
    if (!conn || !ctx.chatId) return false

    const successCount = rows.filter(tx => String(tx?.status || '').toLowerCase() === 'success').length
    const failedCount = rows.length - successCount
    const serialLines = rows.map((tx, index) => {
      if (String(tx?.status || '').toLowerCase() === 'success') {
        return `${index + 1}. ${String(tx?.sn || '-').trim() || '-'}`
      }
      return `${index + 1}. ❌ GAGAL — ${bulkFailureReason(tx)}`
    }).join('\n')

    const completedAt = Math.max(...rows.map(tx => Number(tx?.completed_at || 0)), Date.now())
    const { tanggal, jam } = orderTimeParts(completedAt)
    const unitPrice = Number(ctx.selling_price || 0)
    const title = failedCount > 0 ? 'TRANSAKSI SELESAI' : 'TRANSAKSI SUKSES'
    const replyQuoted = quoted || ctx.quotedMessage || null

    // Bulk sengaja dikirim sebagai TEKS, tanpa gambar invoice, agar seluruh SN muat dalam satu pesan.
    await conn.sendMessage(ctx.chatId, {
      text: invSuccessText({
        produk: ctx.produk,
        brand: ctx.brand,
        kategori: ctx.kategori,
        tipe: ctx.tipe,
        invoice: batchId,
        tujuan: ctx.tujuanFmt,
        nickname: ctx.nickname || '-',
        tanggal,
        jam,
        harga: unitPrice,
        qty: refs.length,
        totalHarga: unitPrice * refs.length,
        snOrNote: serialLines,
        title
      })
    }, replyQuoted ? { quoted: replyQuoted } : {})

    for (const ref of refs) {
      patchTxByRef(ref, {
        batch_id: batchId,
        batch_user_notified: true,
        batch_success_count: successCount,
        batch_failed_count: failedCount
      })
      const pending = getDfzPending(ref)
      if (pending) setDfzPending(ref, { user_notified: true, batch_user_notified: true })
    }

    for (const ref of refs) clearDfzPending(ref)
    return true
  } catch (error) {
    console.error('[BULK INVOICE NOTIFY ERROR]', error?.message || error)
    return false
  } finally {
    _bulkNotifyLocks.delete(batchId)
  }
}

async function finalizeDfz(ref, result, quoted) {
  const key = String(ref)
  if (_dfzFinalizeLocks.has(key)) return getTxByRef(key)
  _dfzFinalizeLocks.add(key)

  try {
    const ctx = getDfzPending(key)
    if (!ctx) return getTxByRef(key)

    const existing = getTxByRef(key) || {}
    const existingStatus = String(existing.status || '').toLowerCase()

    // Pending final baru dibersihkan setelah notifikasi customer benar-benar terkirim.
    // Jika restart terjadi setelah provider final tetapi sebelum invoice/status dikirim,
    // recovery masih punya konteks untuk mencoba lagi.
    if (
      existingStatus === 'success' &&
      existing.finalized === true &&
      existing.stats_applied === true &&
      ctx.user_notified === true
    ) {
      clearDfzPending(key)
      return existing
    }

    if (
      existingStatus === 'failed' &&
      existing.finalized === true &&
      existing.refund_state === 'done' &&
      ctx.user_notified === true
    ) {
      clearDfzPending(key)
      return existing
    }

    const providerCost = Number(result?.price || 0) > 0
      ? Number(result.price)
      : Number(ctx.base_price || 0)
    const serial = String(result?.serialNumber || result?.message || '-').trim() || '-'
    const conn = global.wafproject || global.conn
    const { tanggal, jam } = orderTimeParts(Date.now())

    if (result.status === 'success') {
      const profit = Number(ctx.selling_price || 0) - providerCost
      const completedAt = Number(existing.completed_at || Date.now())

      // Jangan tandai stats_applied/affiliate_applied sebelum perubahan terkait selesai.
      patchTxByRef(key, {
        status: 'success',
        completed_at: completedAt,
        provider_status: result.rawStatus || 'Sukses',
        response_code: result.responseCode || '',
        provider_price: providerCost,
        buyer_last_saldo: Number(result.buyerLastSaldo || 0),
        sn: serial,
        raw: result.raw,
        price: providerCost,
        profit,
        balance_after: getSaldo(ctx.user)
      })

      const statsResult = applySuccessStatsJournal(key, ctx, profit)
      if (!statsResult.ok) return getTxByRef(key)

      const txAfterStats = getTxByRef(key) || {}
      const needsAffiliate =
        txAfterStats.affiliate_applied !== true &&
        Number(ctx.affiliateFee || 0) > 0 &&
        ctx.gidAffiliate

      if (needsAffiliate) {
        addGroupCommission(ctx.gidAffiliate, Number(ctx.affiliateFee || 0), key)
        patchTxByRef(key, { affiliate_applied: true })
      }

      patchTxByRef(key, {
        finalized: true,
        balance_after: getSaldo(ctx.user)
      })

      const latestCtxBeforeNotify = getDfzPending(key) || ctx
      if (isBulkDfzContext(latestCtxBeforeNotify)) {
        await maybeNotifyBulkInvoice(latestCtxBeforeNotify, quoted)
      } else if (!latestCtxBeforeNotify.user_notified && conn && latestCtxBeforeNotify.chatId) {
        try {
          let sentInvoice = false
          try {
            const image = await InvoiceImage.createInvoiceImage({
              transactionId: key,
              product: latestCtxBeforeNotify.produk,
              sn: serial,
              date: new Date()
            })
            const replyQuoted = quoted || latestCtxBeforeNotify.quotedMessage || ctx.quotedMessage || null
            await conn.sendMessage(
              latestCtxBeforeNotify.chatId,
              {
                image,
                caption: invSuccessText({
                  produk: latestCtxBeforeNotify.produk,
                  brand: latestCtxBeforeNotify.brand,
                  kategori: latestCtxBeforeNotify.kategori,
                  tipe: latestCtxBeforeNotify.tipe,
                  invoice: key,
                  tujuan: latestCtxBeforeNotify.tujuanFmt,
                  nickname: latestCtxBeforeNotify.nickname || '-',
                  tanggal,
                  jam,
                  harga: latestCtxBeforeNotify.selling_price,
                  snOrNote: serial
                })
              },
              replyQuoted ? { quoted: replyQuoted } : {}
            )
            sentInvoice = true
          } catch (invoiceError) {
            console.error('[INVOICE IMAGE ERROR]', invoiceError?.message || invoiceError)
          }

          // Fallback ke invoice teks jika generator/kirim gambar gagal.
          if (!sentInvoice) {
            await conn.sendMessage(latestCtxBeforeNotify.chatId, {
              text: invSuccessText({
                produk: latestCtxBeforeNotify.produk,
                brand: latestCtxBeforeNotify.brand,
                kategori: latestCtxBeforeNotify.kategori,
                tipe: latestCtxBeforeNotify.tipe,
                invoice: key,
                tujuan: latestCtxBeforeNotify.tujuanFmt,
                nickname: latestCtxBeforeNotify.nickname || '-',
                tanggal,
                jam,
                harga: latestCtxBeforeNotify.selling_price,
                snOrNote: serial
              })
            }, (quoted || latestCtxBeforeNotify.quotedMessage || ctx.quotedMessage)
              ? { quoted: quoted || latestCtxBeforeNotify.quotedMessage || ctx.quotedMessage }
              : {})
          }

          setDfzPending(key, { user_notified: true })
        } catch (error) {
          console.error('[ORDER SUCCESS NOTIFY ERROR]', error?.message || error)
        }
      }

      const latestCtxForOwner = getDfzPending(key) || ctx
      if (!latestCtxForOwner.owner_reported && conn) {
        try {
          const saldoDigi = (await Digiflazz.checkBalance()).deposit
          await sendReportOwner(conn, {
            status: 'sukses',
            nama: latestCtxForOwner.pushName || latestCtxForOwner.user,
            nomor: latestCtxForOwner.user,
            hargaJual: latestCtxForOwner.selling_price,
            hargaPokok: providerCost,
            profit,
            jam,
            produk: latestCtxForOwner.produk,
            brand: latestCtxForOwner.brand,
            kategori: latestCtxForOwner.kategori,
            tipe: latestCtxForOwner.tipe,
            tujuan: latestCtxForOwner.tujuanFmt,
            saldoDigi
          })
          setDfzPending(key, { owner_reported: true })
        } catch (error) {
          console.error('[ORDER OWNER REPORT ERROR]', error?.message || error)
        }
      }

      // Owner report best-effort; pending dipertahankan hanya bila customer belum menerima status.
      const latestCtx = getDfzPending(key)
      if (latestCtx?.user_notified === true) clearDfzPending(key)

      return getTxByRef(key)
    }

    if (result.status === 'failed') {
      const refundNeeded = ctx.payMode === 'saldo'
      const alasan = resultReason(result)
      const completedAt = Number(existing.completed_at || Date.now())

      patchTxByRef(key, {
        status: 'failed',
        completed_at: completedAt,
        provider_status: result.rawStatus || 'Gagal',
        response_code: result.responseCode || '',
        provider_price: providerCost,
        buyer_last_saldo: Number(result.buyerLastSaldo || 0),
        raw: result.raw,
        sn: serial,
        profit: 0
      })

      if (refundNeeded) {
        const refund = applyOrderRefund(key, ctx.user, Number(ctx.selling_price || 0))
        if (!refund.ok) {
          patchTxByRef(key, {
            status: 'failed',
            finalized: false,
            review_required: true
          })
          setDfzPending(key, {
            review_required: true,
            refund_review: true,
            nextCheckAt: 0
          })
          return getTxByRef(key)
        }
      } else {
        patchTxByRef(key, { refund_state: 'done' })
      }

      patchTxByRef(key, {
        finalized: true,
        refund_done: true,
        balance_after: getSaldo(ctx.user)
      })

      const latestCtxBeforeNotify = getDfzPending(key) || ctx
      if (isBulkDfzContext(latestCtxBeforeNotify)) {
        await maybeNotifyBulkInvoice(latestCtxBeforeNotify, quoted)
      } else if (!latestCtxBeforeNotify.user_notified && conn && latestCtxBeforeNotify.chatId) {
        try {
          await conn.sendMessage(latestCtxBeforeNotify.chatId, {
            text: invFailedText({
              produk: latestCtxBeforeNotify.produk,
              brand: latestCtxBeforeNotify.brand,
              kategori: latestCtxBeforeNotify.kategori,
              tipe: latestCtxBeforeNotify.tipe,
              invoice: key,
              tujuan: latestCtxBeforeNotify.tujuanFmt,
              nickname: latestCtxBeforeNotify.nickname || '-',
              tanggal,
              jam,
              alasan,
              refund: latestCtxBeforeNotify.selling_price
            })
          }, (quoted || latestCtxBeforeNotify.quotedMessage || ctx.quotedMessage)
            ? { quoted: quoted || latestCtxBeforeNotify.quotedMessage || ctx.quotedMessage }
            : {})
          setDfzPending(key, { user_notified: true })
        } catch (error) {
          console.error('[ORDER FAILED NOTIFY ERROR]', error?.message || error)
        }
      }

      const latestCtxForOwner = getDfzPending(key) || ctx
      if (!latestCtxForOwner.owner_reported && conn) {
        try {
          const saldoDigi = (await Digiflazz.checkBalance()).deposit
          await sendReportOwner(conn, {
            status: 'gagal',
            nama: latestCtxForOwner.pushName || latestCtxForOwner.user,
            nomor: latestCtxForOwner.user,
            hargaJual: latestCtxForOwner.selling_price,
            hargaPokok: providerCost,
            profit: 0,
            jam,
            produk: latestCtxForOwner.produk,
            brand: latestCtxForOwner.brand,
            kategori: latestCtxForOwner.kategori,
            tipe: latestCtxForOwner.tipe,
            tujuan: latestCtxForOwner.tujuanFmt,
            saldoDigi,
            alasan
          })
          setDfzPending(key, { owner_reported: true })
        } catch (error) {
          console.error('[ORDER OWNER REPORT ERROR]', error?.message || error)
        }
      }

      const latestCtx = getDfzPending(key)
      if (latestCtx?.user_notified === true) clearDfzPending(key)

      return getTxByRef(key)
    }

    return existing
  } finally {
    _dfzFinalizeLocks.delete(key)
  }
}

async function checkPendingDfz(ref, { force = false, quoted = null } = {}) {
  const key = String(ref)
  if (_dfzCheckLocks.has(key)) return { state: 'locked' }
  _dfzCheckLocks.add(key)

  try {
    let ctx = getDfzPending(key)
    if (!ctx) return { state: 'missing' }

    const age = Date.now() - Number(ctx.createdAt || Date.now())
    if (age > PENDING_MAX_AGE_MS) {
      setDfzPending(key, { review_required: true, nextCheckAt: 0 })
      patchTxByRef(key, { status: 'pending', review_required: true })
      if (!ctx.review_notified) {
        const conn = global.wafproject || global.conn
        if (conn && ctx.chatId) {
          try { await conn.sendMessage(ctx.chatId, { text: `⚠️ Order *${key}* masih belum mendapat status final dari provider dan perlu pengecekan admin. Saldo tidak direfund otomatis agar tidak terjadi refund ganda.` }) } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }
        }
        setDfzPending(key, { review_notified: true })
      }
      return { state: 'review' }
    }

    const last = Number(ctx.lastCheckAt || 0)
    const remaining = PENDING_POLL_MS - (Date.now() - last)
    if (!force && last > 0 && remaining > 0) return { state: 'too_soon', remaining }

    const checkAt = Date.now()
    ctx = setDfzPending(key, {
      lastCheckAt: checkAt,
      nextCheckAt: checkAt + PENDING_POLL_MS,
      last_error: ''
    })
    patchTxByRef(key, { last_provider_check_at: checkAt, next_provider_check_at: checkAt + PENDING_POLL_MS })

    let result
    try {
      result = await Digiflazz.checkTransaction({
        code: ctx.buyer_sku_code,
        customer: ctx.customer_no,
        ref: key,
        maxPrice: ctx.max_price
      })
    } catch (error) {
      const msg = String(error?.message || error)
      setDfzPending(key, { provider_status: 'UNKNOWN', last_error: msg })
      patchTxByRef(key, { status: 'pending', provider_status: 'UNKNOWN', provider_error: msg })
      return { state: 'pending', error: msg }
    }

    setDfzPending(key, {
      provider_status: result.rawStatus || result.status,
      response_code: result.responseCode,
      provider_message: result.message,
      provider_price: result.price,
      raw: result.raw
    })
    patchTxByRef(key, {
      provider_status: result.rawStatus || result.status,
      response_code: result.responseCode,
      provider_message: result.message,
      provider_price: result.price,
      raw: result.raw
    })

    if (result.status === 'success' || result.status === 'failed') {
      await finalizeDfz(key, result, quoted)
      return { state: result.status, result }
    }

    patchTxByRef(key, { status: 'pending' })
    return { state: 'pending', result }
  } finally {
    _dfzCheckLocks.delete(key)
  }
}

function startPersistentDfzMonitor() {
  const old = global.__WAF_DFZ_PENDING_MONITOR__
  if (old) {
    try { clearInterval(old) } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }
  }

  const tick = async () => {
    const pending = loadDfzPending()
    const due = Object.values(pending)
      .filter(item => item && !item.review_required && Number(item.nextCheckAt || 0) <= Date.now())
      .sort((a, b) => Number(a.nextCheckAt || 0) - Number(b.nextCheckAt || 0))
      .slice(0, Math.max(1, Number(global.dfzMaxChecksPerTick || 5)))

    for (const item of due) {
      try {
        if (item.ready !== true) {
          const tx = getTxByRef(item.ref_id) || {}
          if (item.payMode === 'saldo') {
            const debit = applyOrderDebit(item.ref_id, item.user, item.selling_price)
            if (!debit.ok) {
              setDfzPending(item.ref_id, { review_required: true, nextCheckAt: 0 })
              patchTxByRef(item.ref_id, { review_required: true })
              continue
            }
          }
          setDfzPending(item.ref_id, { ready: true, nextCheckAt: Date.now() })
        }
        await checkPendingDfz(item.ref_id)
      } catch (error) {
        console.error(`[Digiflazz] Monitor ${item.ref_id} gagal:`, error?.message || error)
      }
    }
  }

  const timer = setInterval(() => void tick(), PENDING_MONITOR_TICK_MS)
  if (timer?.unref) timer.unref()
  global.__WAF_DFZ_PENDING_MONITOR__ = timer

  const startup = setTimeout(() => void tick(), 5000)
  if (startup?.unref) startup.unref()
}

startPersistentDfzMonitor()

// ================== TOPUP FLOW DIGIFLAZZ ==================
async function doTopupFlow({
  conn,
  m,
  prod,
  code,
  tujuan,
  customerParam,
  base,
  price,
  role,
  nickname,
  me,
  payMode,
  affiliateFee = 0,
  gidAffiliate = null,
  refOverride = '',
  silentStart = false,
  deferFirstCheck = false,
  batchInfo = null
}) {
  const say = txt => conn.sendMessage(m.chat, { text: String(txt) }, { quoted: m })

  // Ambil snapshot produk terbaru tepat sebelum debit saldo.
  const currentProduct = (loadProducts().products || []).find(p => String(p.code || '').toUpperCase() === String(code || '').toUpperCase()) || prod
  const available = availability(currentProduct)
  if (!available.available) return say(`❌ Produk tidak dapat diproses. ${available.reason}`)

  const currentBase = Number(currentProduct.price || 0)
  if (currentBase !== Number(base || 0)) {
    return say('⚠️ Harga produk baru saja berubah setelah konfirmasi. Silakan ulangi *.order* agar harga terbaru tampil sebelum pembayaran diproses.')
  }

  const ref = String(refOverride || '').trim() || `BOT${Date.now()}${Math.random().toString(36).slice(2, 6).toUpperCase()}`
  const existingRefTx = getTxByRef(ref)
  if (existingRefTx?.finalized === true) return existingRefTx

  // Recovery/batch retry dengan ref yang sama tidak boleh menginisialisasi ulang debit.
  // Jika journal + pending sudah ada, cukup lanjutkan pengecekan transaksi tersebut.
  if (refOverride && existingRefTx) {
    const existingPending = getDfzPending(ref)
    if (existingPending) {
      if (deferFirstCheck) return ref
      await checkPendingDfz(ref, { force: true, quoted: m })
      return ref
    }
  }

  if (!refOverride) {
    const recentDuplicate = findRecentDuplicateOrder(me, code, customerParam, ref)
    if (recentDuplicate) {
      return say(
        `⚠️ Pesanan yang sama masih diproses atau baru saja dikirim.\n` +
        `🆔 Invoice: *${recentDuplicate.ref_id || '-'}*\n` +
        `Tunggu status transaksi tersebut sebelum mengirim ulang.`
      )
    }

    if (currentProduct?.meta?.multi === false && hasDuplicateNonMulti(me, code, customerParam)) {
      return say('❌ Produk ini tidak mendukung transaksi berulang ke tujuan yang sama pada hari yang sama. Gunakan produk/denom lain atau coba kembali besok.')
    }
  }
  const mapNama = mapProdukNaming(currentProduct)
  const kategori = mapNama.kategori
  const brand = mapNama.brand
  const tipe = mapNama.tipe
  const produk = mapNama.produk || currentProduct?.name || code || '-'
  const tujuanFmt = `${tujuan.id}${tujuan.server ? ` (${tujuan.server})` : ''}`
  const maxPrice = Math.floor(currentBase + MAX_PRICE_BUFFER)

  if (!silentStart) await say('*⏳ Mohon bersabar, pesanan sedang diproses...*')

  if (payMode === 'saldo' && Number(getSaldo(me)) < Number(price || 0)) {
    return say('❌ Saldo tidak cukup.')
  }

  // Simpan journal SEBELUM debit/request. Jika proses restart di tengah jalan,
  // monitor dapat melanjutkan tanpa kehilangan order atau menggandakan debit.
  const createdAt = Date.now()
  patchTxByRef(ref, {
    ts: Number(existingRefTx?.ts || createdAt),
    ref_id: ref,
    buyer_sku_code: code,
    tujuan: customerParam,
    customer_no: customerParam,
    user: me,
    product_name: produk,
    price: currentBase,
    selling_price: price,
    profit: 0,
    status: existingRefTx?.status || 'pending',
    provider_status: existingRefTx?.provider_status || 'QUEUED',
    max_price: maxPrice,
    payment_mode: payMode,
    balance_after: getSaldo(me),
    finalized: false,
    refund_done: existingRefTx?.refund_done === true,
    debit_state: existingRefTx?.debit_state || (payMode === 'saldo' ? 'pending' : 'done'),
    refund_state: existingRefTx?.refund_state || 'pending',
    ...(batchInfo ? {
      batch_id: String(batchInfo.id || ''),
      batch_refs: Array.isArray(batchInfo.refs) ? batchInfo.refs.map(String) : [],
      batch_qty: Number(batchInfo.qty || 1),
      batch_index: Number(batchInfo.index || 0),
      batch_user_notified: false
    } : {})
  })

  setDfzPending(ref, {
    ref_id: ref,
    buyer_sku_code: code,
    customer_no: customerParam,
    user: me,
    chatId: m.chat,
    pushName: m.pushName || me,
    base_price: currentBase,
    selling_price: Number(price || 0),
    max_price: maxPrice,
    payMode,
    role,
    nickname: nickname || '-',
    produk,
    brand,
    kategori,
    tipe,
    tujuanFmt,
    affiliateFee: Number(affiliateFee || 0),
    gidAffiliate: gidAffiliate || null,
    quotedMessage: m?.key && m?.message ? {
      key: m.key,
      message: m.message,
      pushName: m.pushName || undefined
    } : null,
    createdAt,
    lastCheckAt: 0,
    nextCheckAt: createdAt,
    ready: payMode !== 'saldo',
    user_notified: false,
    owner_reported: false,
    review_required: false,
    ...(batchInfo ? {
      batch_id: String(batchInfo.id || ''),
      batch_refs: Array.isArray(batchInfo.refs) ? batchInfo.refs.map(String) : [],
      batch_qty: Number(batchInfo.qty || 1),
      batch_index: Number(batchInfo.index || 0),
      batch_user_notified: false
    } : {})
  })

  if (payMode === 'saldo') {
    const debit = applyOrderDebit(ref, me, Number(price || 0))
    if (!debit.ok) {
      setDfzPending(ref, { review_required: true, nextCheckAt: 0 })
      patchTxByRef(ref, { review_required: true })
      return say(debit.insufficient ? '❌ Saldo tidak cukup.' : '⚠️ Order ditahan untuk pemeriksaan saldo agar tidak terjadi debit ganda.')
    }
    setDfzPending(ref, { ready: true, nextCheckAt: Date.now() })
  }

  // Batch dapat menahan request provider sampai seluruh debit item sudah di-reserve.
  if (deferFirstCheck) return ref

  // Request pertama sekaligus merupakan sumber status awal. Response tidak dibuang.
  await checkPendingDfz(ref, { force: true, quoted: m })
  return ref
}

async function doTopupBatchFromSnapshot({ conn, m, snap, me, refOverrides = null, onReserved = null }) {
  const qty = Math.max(1, Math.floor(Number(snap?.qty || 1)))

  if (qty === 1) {
    const ref = Array.isArray(refOverrides) ? String(refOverrides[0] || '') : ''
    return [await doTopupFlow({
      conn,
      m,
      prod: snap.prod,
      code: snap.code,
      tujuan: snap.tujuan,
      customerParam: snap.customerParam,
      base: snap.base,
      price: snap.price,
      role: snap.role,
      nickname: snap.nickname,
      me,
      payMode: 'saldo',
      affiliateFee: snap.affiliateFee,
      gidAffiliate: snap.gidAffiliate,
      refOverride: ref,
      silentStart: Boolean(ref)
    })]
  }

  const refs = Array.isArray(refOverrides) && refOverrides.length === qty
    ? refOverrides.map(String)
    : Array.from({ length: qty }, (_, i) =>
        `BOTB${Date.now()}${Math.random().toString(36).slice(2, 5).toUpperCase()}${String(i + 1).padStart(2, '0')}`
      )
  const batchId = `BULK-${refs[0]}`

  // Tahap 1: journal + reserve/debit semua item terlebih dulu.
  // Dengan begitu order lain dari user tidak menyebabkan batch berhenti setengah jalan karena saldo habis.
  for (let i = 0; i < qty; i++) {
    await doTopupFlow({
      conn,
      m,
      prod: snap.prod,
      code: snap.code,
      tujuan: snap.tujuan,
      customerParam: snap.customerParam,
      base: snap.base,
      price: snap.price,
      role: snap.role,
      nickname: snap.nickname,
      me,
      payMode: 'saldo',
      affiliateFee: snap.affiliateFee,
      gidAffiliate: snap.gidAffiliate,
      refOverride: refs[i],
      silentStart: true,
      deferFirstCheck: true,
      batchInfo: { id: batchId, refs, qty, index: i + 1 }
    })
  }

  if (typeof onReserved === 'function') {
    try { onReserved() } catch (_releaseError) {}
  }

  try {
    await conn.sendMessage(m.chat, { text: `*⏳ Memproses ${qty} pesanan...*` }, { quoted: m })
  } catch (_notifyError) {}

  // Tahap 2: setelah seluruh saldo item sudah ter-reserve, kirim ke provider satu per satu.
  for (const ref of refs) {
    await checkPendingDfz(ref, { force: true, quoted: m })
  }

  return refs
}

// Dipakai cekstatus agar request manual tetap memakai payload transaksi lengkap.
global.__WAF_TOPUP_DFZ__ = {
  checkPendingDfz,
  getDfzPending,
  getTxByRef,
  pollMs: PENDING_POLL_MS
}

// ======= PART 3 END =======

// ================== KONFIRMASI STATE ==================
const CONFIRM = new Map()
const CONFIRM_TIMEOUT_MS = Number(global.orderConfirmTimeoutMs || 2 * 60 * 1000)

function clearConfirm(user) {
  const st = CONFIRM.get(user)
  if (st?.timeout) {
    try { clearTimeout(st.timeout) } catch (error) { console.error("[ERROR][commands/topup/_order.js]", error?.message || error) }
  }
  CONFIRM.delete(user)
}

function denyIfLocked(user) {
  const st = CONFIRM.get(user)
  if (!st) return false
  return ['locked_saldo', 'locked_qr', 'locked_cancel'].includes(st.status)
}

function parseTujuan(raw) {
  const s = String(raw || '').trim()

  let m = s.match(/^\s*(\d+)(?:\s*\((\d+)\))?\s*$/)
  if (m) return { id: m[1], server: m[2] || '' }

  m = s.match(/^\s*(\d+)\s+(\d+)\s*$/)
  if (m) return { id: m[1], server: m[2] || '' }

  m = s.match(/^\s*(\d+)\s*\|\s*(\d+)\s*$/)
  if (m) return { id: m[1], server: m[2] || '' }

  return { id: s, server: '' }
}

function parseTargetQty(raw, { serverRequired = false } = {}) {
  const original = String(raw || '').trim()
  const match = original.match(/^(.*?)\|\s*(\d+)\s*$/)
  if (!match) return { targetRaw: original, qty: 1, error: '' }

  const left = String(match[1] || '').trim()
  const qty = Number(match[2] || 0)

  // Untuk game yang wajib server, format lama ID|SERVER tetap didukung.
  // Qty ditulis ID SERVER|QTY, misalnya: 9243934 8343|5.
  if (serverRequired && !/[\s()]/.test(left)) {
    return { targetRaw: original, qty: 1, error: '' }
  }

  if (!Number.isInteger(qty) || qty < 1) {
    return { targetRaw: left, qty: 1, error: 'Qty minimal 1.' }
  }
  if (qty > MAX_ORDER_QTY) {
    return { targetRaw: left, qty, error: `Qty maksimal ${MAX_ORDER_QTY} per command.` }
  }
  return { targetRaw: left, qty, error: '' }
}

function formatKonfirmasi({ prod, tujuan, nickname, price, qty = 1, totalPrice, saldo }) {
  const tujuanFmt = `${tujuan.id}${tujuan.server ? ` (${tujuan.server})` : ''}`
  const mapNama = mapProdukNaming(prod)

  const kategori = mapNama.kategori
  const brand = mapNama.brand
  const tipe = mapNama.tipe
  const produk = mapNama.produk || prod?.name || '-'

  return `🧾 *KONFIRMASI PESANAN*
${line}
🛍️ *Produk*    : ${produk}
🎮 *Brand*     : ${brand || '-'}
🎯 *Tujuan*    : ${tujuanFmt}
🏷️ *Nickname*  : ${nickname || '-'}
📦 *Jumlah*    : ${Math.max(1, Number(qty || 1))}x
💰 *Harga*     : ${fmtRp(price)}${Number(qty || 1) > 1 ? ' / transaksi' : ''}
🧮 *Total*     : ${fmtRp(totalPrice || (Number(price || 0) * Math.max(1, Number(qty || 1))))}
💳 *Saldo Anda:* ${fmtRp(saldo)}
${line}
*Ketik:*
• S = Order pakai saldo
• Q = Order pakai QRIS otomatis
• N = Batalkan

⏳ Otomatis batal dalam ${Math.round(CONFIRM_TIMEOUT_MS / 60000)} menit jika tidak ada balasan.`
}

// ================== MAIN HANDLER ==================
let handler = async (m, { wafproject, usedPrefix, isOwner, isROwner }) => {
  const conn = wafproject
  if (!conn) return

  const say = (t) => conn.sendMessage(m.chat, { text: String(t) }, { quoted: m })

  const rawText = String(m.text || '').trim()
  const meNum = jidNum(m.sender || m.key?.participant || m.chat)

  const showPref = (typeof usedPrefix === 'string')
    ? usedPrefix
    : (typeof global?.prefix === 'string' ? global.prefix : '.')

  let text = rawText

  if (typeof usedPrefix === 'string' && usedPrefix && text.startsWith(usedPrefix)) {
    text = text.slice(usedPrefix.length).trim()
  } else if (typeof global?.prefix === 'string' && global.prefix && text.startsWith(global.prefix)) {
    text = text.slice(global.prefix.length).trim()
  }

  const cmd = (text.split(/\s+/)[0] || '').toLowerCase()
  const args = text.split(/\s+/).slice(1)

  // ===== KONFIRMASI S / Q / N DENGAN PREFIX =====
  if (['s', 'q', 'n'].includes(cmd)) {
    const st = CONFIRM.get(meNum)
    if (!st) return

    if (denyIfLocked(meNum)) {
      return say('❌ Kamu sudah melakukan konfirmasi. Tidak bisa mengubah pilihan lagi.')
    }

    if (st.status === 'allow_only_q') {
      if (cmd !== 'q') return say('❌ Saldo kamu tidak cukup. Hanya *Q* yang diterima.')
      st.status = 'locked_qr'
      try {
        await handlePayKitaQrisFromState(conn, m, st)
        clearConfirm(meNum)
      } catch (e) {
        st.status = 'locked_cancel'
        clearConfirm(meNum)
        await say('❌ Gagal membuat invoice: ' + (e?.message || e))
      }
      return
    }

    if (st.status === 'await_choice') {
      if (cmd === 'n') {
        st.status = 'locked_cancel'
        clearConfirm(meNum)
        return say('✅ Pesanan dibatalkan.')
      }

      if (cmd === 'q') {
        st.status = 'locked_qr'
        try {
          await handlePayKitaQrisFromState(conn, m, st)
          clearConfirm(meNum)
        } catch (e) {
          st.status = 'locked_cancel'
          clearConfirm(meNum)
          await say('❌ Gagal membuat invoice: ' + (e?.message || e))
        }
        return
      }

      if (cmd === 's') {
        const saldo = getSaldo(meNum)
        const price = Number(st.snapshot.totalPrice || st.snapshot.price || 0)

        if (saldo < price) {
          st.status = 'allow_only_q'
          return say('❌ Saldo kamu tidak cukup. Ketik *Q* untuk QRIS.')
        }

        st.status = 'locked_saldo'
        const snap = st.snapshot
        let released = false
        const releaseConfirm = () => {
          if (released) return
          released = true
          clearConfirm(meNum)
        }

        try {
          await doTopupBatchFromSnapshot({
            conn,
            m,
            snap,
            me: meNum,
            onReserved: Number(snap.qty || 1) > 1 ? releaseConfirm : null
          })
        } catch (error) {
          console.error('[ORDER SALDO FLOW ERROR]', error?.message || error)
          try {
            await say('⚠️ Terjadi error saat memproses order. Jika saldo sudah terpotong, jangan ulangi order; transaksi yang sudah tercatat tetap dipantau oleh sistem.')
          } catch (_notifyError) {}
        } finally {
          releaseConfirm()
        }
        return
      }
    }

    return
  }

  if (cmd !== 'order') return

  const active = CONFIRM.get(meNum)

  if (active) {
    return say('⚠️ Kamu masih punya konfirmasi/proses pesanan aktif. Selesaikan dulu dengan ketik *S*, *Q*, atau *N*, atau tunggu proses/timeout selesai.')
  }

  if (args.length < 2) {
    return say(
      `Format: *${showPref || ''}order <kode_produk> <tujuan>|<qty>*\n` +
      `Contoh 1x: *${showPref || ''}order MLID5 290188675 (9507)*\n` +
      `Contoh 5x: *${showPref || ''}order MLID5 290188675 9507|5*`
    )
  }

  const productsDB = loadProducts()
  const code = String(args[0] || '').toUpperCase()
  const rawTargetWithQty = args.slice(1).join(' ')

  let prod = (productsDB.products || []).find((p) => String(p.code || '').toUpperCase() === code)

  if (!prod) {
    return say('Kode produk tidak ditemukan.')
  }

  const gameForParsing = detectGameFromProduct(prod, code)
  const parsedOrder = parseTargetQty(rawTargetWithQty, {
    serverRequired: Boolean(gameForParsing && gameNeedsServer(gameForParsing))
  })
  if (parsedOrder.error) return say(`❌ ${parsedOrder.error}`)

  const qty = parsedOrder.qty
  const tujuanRaw = parsedOrder.targetRaw
  const tujuan = parseTujuan(tujuanRaw)
  const customerParam = tujuan.server ? `${tujuan.id} ${tujuan.server}` : tujuan.id

  // Cek SKU lagi sebelum menampilkan konfirmasi agar harga order tidak memakai
  // snapshot katalog lama. Jika endpoint price-list sedang bermasalah, fallback
  // ke katalog lokal dan max_price tetap menjadi pengaman transaksi.
  prod = await refreshProductPriceBeforeConfirm(code, prod)

  const availableNow = availability(prod)
  if (!availableNow.available) {
    return say(`❌ Produk tidak dapat diproses. ${availableNow.reason}`)
  }

  if (qty > 1 && prod?.meta?.multi === false) {
    return say('❌ Produk ini tidak mendukung pembelian berulang ke tujuan yang sama dalam satu batch.')
  }

  const u = ensureUserTopup(meNum)
  const role = effectiveRoleForUser(meNum, u.role || 'bronze', { isOwner, isROwner })
  const margin = marginFor(role)
  const base = Number(prod.price || 0)

  const hargaBot = hargaJualBot(base, margin)

  let rateGrup = 0
  if (m.chat.endsWith('@g.us')) {
    rateGrup = getGroupRatePct(m.chat)
  }

  const price = hargaFinalGrup(hargaBot, rateGrup)
  const totalPrice = price * qty
  const affiliateFee = Math.max(0, price - hargaBot)

  let nickname = '-'
  const saldoNow = getSaldo(meNum)

  const game = gameForParsing

  if (game) {
    const ck = await fetchNickIsan({
      game,
      id: tujuan.id,
      server: tujuan.server
    })

    if (ck.ok) {
      nickname = ck.name || '-'
    } else {
      if (gameNeedsServer(game)) {
        return say(`❌ ID/Server tidak valid atau gagal cek nickname.\nAlasan: ${ck.message || '-'}`)
      }

      nickname = '-'
    }
  }

  await say(formatKonfirmasi({
    prod,
    tujuan,
    nickname,
    price,
    qty,
    totalPrice,
    saldo: saldoNow
  }))

  const timeout = setTimeout(() => {
    const s = CONFIRM.get(meNum)
    if (!s) return

    if (['await_choice', 'allow_only_q'].includes(s.status)) {
      s.status = 'locked_cancel'

      conn.sendMessage(s.chatId, {
        text: '⏰ Waktu konfirmasi habis. Pesanan dibatalkan.'
      }).catch(() => {})

      clearConfirm(meNum)
    }
  }, CONFIRM_TIMEOUT_MS)

  CONFIRM.set(meNum, {
    chatId: m.chat,
    expireAt: Date.now() + CONFIRM_TIMEOUT_MS,
    timeout,
    status: 'await_choice',
    snapshot: {
      meNum,
      prod,
      code,
      tujuan,
      customerParam,
      nickname,
      role,
      base,
      price,
      qty,
      totalPrice,
      rateGrup,
      hargaBot,
      affiliateFee,
      gidAffiliate: m.chat.endsWith('@g.us') ? m.chat : null
    }
  })
}

// ================== ALL HANDLER S / Q / N TANPA PREFIX ==================
handler.all = async (m, { wafproject }) => {
  const conn = wafproject
  if (!conn) return

  const rawText = String(m.text || '').trim()
  const meNum = jidNum(m.sender || m.key?.participant || m.chat)

  if (!CONFIRM.has(meNum)) return
  if (!/^[sqn]$/i.test(rawText)) return

  const say = (t) => conn.sendMessage(m.chat, { text: String(t) }, { quoted: m })
  const cmd = rawText.toLowerCase()
  const st = CONFIRM.get(meNum)

  if (!st) return

  if (denyIfLocked(meNum)) {
    return say('❌ Kamu sudah melakukan konfirmasi.')
  }

  // khusus saldo kurang → hanya boleh Q
  if (st.status === 'allow_only_q') {
    if (cmd !== 'q') {
      return say('❌ Saldo tidak cukup. Hanya *Q* yang diterima.')
    }

    st.status = 'locked_qr'

    try {
      await handlePayKitaQrisFromState(conn, m, st)
      clearConfirm(meNum)
    } catch (e) {
      st.status = 'locked_cancel'
      clearConfirm(meNum)
      await say('❌ Gagal membuat invoice: ' + (e?.message || e))
    }

    return
  }

  if (st.status === 'await_choice') {

    if (cmd === 'n') {
      st.status = 'locked_cancel'
      clearConfirm(meNum)
      return say('✅ Pesanan dibatalkan.')
    }

    // ================= QRIS =================
    if (cmd === 'q') {
      st.status = 'locked_qr'

      try {
        await handlePayKitaQrisFromState(conn, m, st)
        clearConfirm(meNum)
      } catch (e) {
        st.status = 'locked_cancel'
        clearConfirm(meNum)
        await say('❌ Gagal membuat invoice: ' + (e?.message || e))
      }

      return
    }

    // ================= SALDO =================
    if (cmd === 's') {
      const saldo = getSaldo(meNum)
      const price = Number(st.snapshot.totalPrice || st.snapshot.price || 0)

      if (saldo < price) {
        st.status = 'allow_only_q'
        return say('❌ Saldo tidak cukup. Ketik *Q* untuk QRIS.')
      }

      st.status = 'locked_saldo'
      const snap = st.snapshot
      let released = false
      const releaseConfirm = () => {
        if (released) return
        released = true
        clearConfirm(meNum)
      }

      try {
        await doTopupBatchFromSnapshot({
          conn,
          m,
          snap,
          me: meNum,
          onReserved: Number(snap.qty || 1) > 1 ? releaseConfirm : null
        })
      } catch (error) {
        console.error('[ORDER SALDO FLOW ERROR]', error?.message || error)
        try {
          await say('⚠️ Terjadi error saat memproses order. Jika saldo sudah terpotong, jangan ulangi order; transaksi yang sudah tercatat tetap dipantau oleh sistem.')
        } catch (_notifyError) {}
      } finally {
        releaseConfirm()
      }
      return
    }
  }
}

// ================== META ==================
handler.help = ['order <kode> <tujuan>|<qty>']
handler.category = ['topup']
handler.command = ['order']
handler.register = false

module.exports = handler
