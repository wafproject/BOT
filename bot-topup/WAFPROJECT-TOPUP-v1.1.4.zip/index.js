/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 FINAL INDEX.JS (ANTI EDIT FIX)
========================
*/
// ✅ Load settings (SET GLOBAL.* SEKALI)
require("./settings")

const fs = require("fs")
const os = require("os")
const path = require("path")
const axios = require("axios")
const chalk = require("chalk")
const readline = require("readline")
const { Boom } = require("@hapi/boom")
const qrcode = require("qrcode-terminal")
const NodeCache = require("node-cache")
const { toBuffer } = require("qrcode")
const { exec } = require("child_process")
const { parsePhoneNumber } = require("awesome-phonenumber")

const {
  createZapoAuthState,
  ZapoDisconnectReason,
  decodeJid,
  normalizeUserJid,
  createZapoSocket,
  downloadMediaMessage,
} = require("./lib/zapo-adapter.js")

const { app, server, PORT } = require("./lib/server")
const { dataBase } = require("./lib/database")
const { ROOT_DIR, SESSION_DIR, LEGACY_AUTH_DIR, TEMP_DIR } = require("./lib/project-paths")
const { checkDatabaseHealth } = require("./lib/health-check")

// ✅ Print chat rapi (PESAN MASUK) - hanya incoming
const { printIncomingChat } = require("./lib/printchat")

// ✅ Unified template logger (sesuai revisi console log)
const log = require("./lib/consoleLog")

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

// Variabel lifecycle koneksi/login
let usePairingCode = null
let pairingPhoneNumber = ""
let loginMethodConfigured = false
let loginFlow = null
let reconnectTimer = null
let startInProgress = false
let shutdownStarted = false
let activeSocketGeneration = 0
let pluginsBootstrapped = false
let verifiedLicenseNumber = ""
let commandWatcher = null
let commandReloadTimer = null
let commandReloadRunning = false
let commandReloadPending = false
let commandReloadPendingFile = ""
let autosaveTimer = null

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

function getDisconnectStatusCode(error) {
  try {
    return (
      error?.output?.statusCode ||
      error?.data?.statusCode ||
      error?.statusCode ||
      new Boom(error)?.output?.statusCode ||
      0
    )
  } catch {
    return 0
  }
}

function sanitizePhoneNumber(value) {
  let number = String(value || "").replace(/\D/g, "")
  if (number.startsWith("0")) number = "62" + number.slice(1)
  return number
}

function getConnectedPhoneNumber(wafproject, state) {
  const candidates = [
    wafproject?.user?.id,
    wafproject?.user?.jid,
    state?.creds?.me?.id,
    state?.creds?.me?.jid,
  ]

  for (const candidate of candidates) {
    const jid = String(candidate || "")
    const localPart = jid.split("@")[0].split(":")[0]
    const number = sanitizePhoneNumber(localPart)

    if (/^\d{8,15}$/.test(number)) return number
  }

  return ""
}

function printLicenseRejected(number = "") {
  console.log("")
  console.log(
    chalk.red.bold(
      `⛔ Licence tidak valid${number ? ` untuk nomor ${number}` : ""}!`
    )
  )
  console.log(
    chalk.yellow.bold(
      "Login dibatalkan dan plugin tidak akan dimuat."
    )
  )
  console.log(
    chalk.blue.bold(
      "Enzi WAF Project — 0877 3128 2876"
    )
  )
  console.log("")
}

async function verifyLicenseNumber(number, { silent = false } = {}) {
  const normalized = sanitizePhoneNumber(number)

  if (!/^\d{8,15}$/.test(normalized)) {
    if (!silent) console.log(chalk.red("✗ Nomor licence tidak valid."))
    return false
  }

  if (!silent) {
    console.log(
      chalk.hex("#45B7D1")(
        `\n🔐 Memeriksa licence nomor: ${normalized}`
      )
    )
  }

  const valid = await checkLicense(normalized)
  if (!valid) return false

  verifiedLicenseNumber = normalized

  if (!silent) {
    console.log(
      chalk.hex("#00FF7F").bold(
        "✅ Licence terverifikasi."
      )
    )
  }

  return true
}

async function rejectAndExitForInvalidLicense(number = "") {
  printLicenseRejected(number)
  try { rl.close() } catch {}
  process.exit(1)
}

function purgeWhatsAppSession() {
  for (const dir of [SESSION_DIR, LEGACY_AUTH_DIR]) {
    try {
      fs.rmSync(dir, { recursive: true, force: true })
    } catch {}
  }
}

// JID akun WhatsApp dapat berubah suffix device setelah relog/re-pair,
// contoh 628xxx:23@s.whatsapp.net menjadi 628xxx:24@s.whatsapp.net.
// Setting seperti prefix harus dibaca berdasarkan nomor dasarnya, bukan suffix device.
function normalizeAccountJid(jid = "") {
  const raw = String(jid || "").trim()
  if (!raw) return ""
  try {
    return normalizeUserJid(raw) || raw.replace(/:\d+(?=@)/, "")
  } catch {
    return raw.replace(/:\d+(?=@)/, "")
  }
}

function findSavedPrefix(settings, accountJid) {
  if (!settings || typeof settings !== "object") {
    return { found: false, prefix: undefined, source: "" }
  }

  const raw = String(accountJid || "")
  const normalized = normalizeAccountJid(raw)
  const hasPrefix = (value) =>
    !!value && typeof value === "object" &&
    Object.prototype.hasOwnProperty.call(value, "prefix")

  // 1. Exact current JID.
  if (hasPrefix(settings[raw])) {
    return { found: true, prefix: settings[raw].prefix, source: raw }
  }

  // 2. Canonical JID without device suffix.
  if (hasPrefix(settings[normalized])) {
    return { found: true, prefix: settings[normalized].prefix, source: normalized }
  }

  // 3. Migrasi setting lama yang tersimpan menggunakan suffix device berbeda.
  const entries = Object.entries(settings)
  for (let i = entries.length - 1; i >= 0; i--) {
    const [key, value] = entries[i]
    if (normalizeAccountJid(key) === normalized && hasPrefix(value)) {
      return { found: true, prefix: value.prefix, source: key }
    }
  }

  return { found: false, prefix: undefined, source: "" }
}

// ===== DATABASE FILES =====
// Instalasi lama boleh punya cache bernama baileys_store.json.
// Runtime Zapo selalu menulis ke zapo_store.json.
const legacyStoreFile = path.join(ROOT_DIR, "database", "baileys_store.json")
const zapoStoreFile = path.join(ROOT_DIR, "database", "zapo_store.json")

if (!fs.existsSync(zapoStoreFile) && fs.existsSync(legacyStoreFile)) {
  try {
    fs.copyFileSync(legacyStoreFile, zapoStoreFile)
  } catch (error) {
    console.warn("[ZAPO STORE MIGRATION]", error?.message || error)
  }
}

const storeDB = dataBase("zapo_store.json")
const database = dataBase("database.json")

// adapter supaya lib/db.js nulis ke file yang sama
global.dbAdapter = database

// ✅ WAJIB: db diambil dari /lib/db (bukan ./db di root)
const db = require("./lib/db")
const handleMessage = require("./lib/handler")
const groupParticipantsUpdate = require("./lib/group-participants")
const antiCallHandler = require("./lib/anticall")
const { checkLicense } = require("./lib/sticker")

// ✅ GLOBAL ANTI-LID
const JidNormalizer = require("./lib/JidNormalizer")

global.plugins = []

let autosaveStarted = false

// ✅ DEDUPE CACHE (ANTI DOUBLE UPSET AWAL: notify/append + LID->JID)
const upsertDedupe = new NodeCache({ stdTTL: 15, checkperiod: 30, maxKeys: 5000 })

// ✅ GROUP METADATA CACHE (ANTI DELAY)
const groupMetaCache = new NodeCache({ stdTTL: 60, checkperiod: 120, maxKeys: 2000 }) // TTL 60 detik
const groupMetaInflight = new Map()

async function getGroupMetadataCached(wafproject, jid) {
  const key = String(jid || "")
  const cached = groupMetaCache.get(key)
  if (cached) return cached

  if (groupMetaInflight.has(key)) return groupMetaInflight.get(key)

  const task = Promise.resolve()
    .then(() => wafproject.groupMetadata(key))
    .then((meta) => {
      if (meta) groupMetaCache.set(key, meta)
      return meta
    })
    .finally(() => groupMetaInflight.delete(key))

  groupMetaInflight.set(key, task)
  return task
}

// Dipakai handler.js supaya warmup index + handler memakai satu cache/request.
global.__wafGetGroupMetadataCached = getGroupMetadataCached
global.__wafPeekGroupMetadata = (jid) => groupMetaCache.get(String(jid || "")) || null

function unwrapIncomingMessage(message) {
  let current = message || {}
  for (let i = 0; i < 8; i++) {
    if (current?.ephemeralMessage?.message) current = current.ephemeralMessage.message
    else if (current?.viewOnceMessage?.message) current = current.viewOnceMessage.message
    else if (current?.viewOnceMessageV2?.message) current = current.viewOnceMessageV2.message
    else if (current?.viewOnceMessageV2Extension?.message) current = current.viewOnceMessageV2Extension.message
    else if (current?.documentWithCaptionMessage?.message) current = current.documentWithCaptionMessage.message
    else if (current?.editedMessage?.message) current = current.editedMessage.message
    else break
  }
  return current || {}
}

function getIncomingText(message) {
  const msg = unwrapIncomingMessage(message)
  let body =
    msg?.buttonsResponseMessage?.selectedButtonId ||
    msg?.buttonsResponseMessage?.selectedDisplayText ||
    msg?.listResponseMessage?.singleSelectReply?.selectedRowId ||
    msg?.templateButtonReplyMessage?.selectedId ||
    msg?.templateButtonReplyMessage?.selectedDisplayText ||
    msg?.conversation ||
    msg?.extendedTextMessage?.text ||
    msg?.imageMessage?.caption ||
    msg?.videoMessage?.caption ||
    msg?.documentMessage?.caption ||
    ""

  if (!body && msg?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson) {
    try {
      const parsed = JSON.parse(msg.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson)
      body = parsed?.id || parsed?.selectedId || parsed?.buttonId || ""
    } catch {}
  }

  return String(body || "")
}

function recoverIncomingMessage(raw) {
  if (raw?.message && typeof raw.message === "object") return raw.message

  const event = raw?.__zapoEvent || raw || {}
  const candidates = [
    event?.message,
    event?.content?.message,
    event?.decrypted?.message,
    event?.payload?.message,
    event?.content,
    event?.decrypted,
    event?.payload,
  ]

  const knownKeys = new Set([
    "conversation",
    "extendedTextMessage",
    "imageMessage",
    "videoMessage",
    "documentMessage",
    "audioMessage",
    "stickerMessage",
    "buttonsResponseMessage",
    "listResponseMessage",
    "templateButtonReplyMessage",
    "interactiveResponseMessage",
    "reactionMessage",
    "protocolMessage",
    "pollUpdateMessage",
    "ephemeralMessage",
    "viewOnceMessage",
    "viewOnceMessageV2",
    "viewOnceMessageV2Extension",
    "documentWithCaptionMessage",
    "editedMessage",
  ])

  for (const candidate of candidates) {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue
    if (Object.keys(candidate).some((key) => knownKeys.has(key))) return candidate
  }

  return null
}

function ensureIncomingTimestamp(raw) {
  if (raw?.messageTimestamp) return
  const ts =
    raw?.timestamp ??
    raw?.__zapoEvent?.messageTimestamp ??
    raw?.__zapoEvent?.timestamp ??
    raw?.__zapoEvent?.serverTimestamp ??
    raw?.__zapoEvent?.time ??
    null

  if (ts != null) raw.messageTimestamp = ts
  else raw.messageTimestamp = Math.floor(Date.now() / 1000)
}

/**
 * ==============================
 * ✅ WARMUP ALL GROUPS (NO UI)
 * - Non-blocking: dipanggil tanpa await
 * - Concurrency limited: aman & cepat
 * - Output rapi: start + done
 * ==============================
 */
async function warmupAllGroupsNoUI(wafproject, opts = {}) {
  const concurrency = Math.max(1, Number(opts.concurrency || 3))

  console.log(chalk.hex("#FFD93D").bold("\n📚 Sedang membaca metadata group..."))

  let groupsObj = {}
  try {
    groupsObj = await wafproject.groupFetchAllParticipating()
  } catch {
    console.log(chalk.red("❌ Gagal mengambil daftar grup (groupFetchAllParticipating)."))
    return { total: 0, ok: 0, fail: 0 }
  }

  const gids = Object.keys(groupsObj || {}).filter((x) => String(x).endsWith("@g.us"))
  const total = gids.length
  if (!total) {
    console.log(chalk.yellow("⚠️ Tidak ada grup terdeteksi untuk warmup."))
    return { total: 0, ok: 0, fail: 0 }
  }

  let ok = 0
  let fail = 0
  let idx = 0

  async function worker() {
    while (idx < total) {
      const i = idx++
      const gid = gids[i]
      try {
        const meta = await JidNormalizer.warmupGroupCache(wafproject, gid)
        if (meta) ok++
        else fail++
      } catch {
        fail++
      }
    }
  }

  const workers = Array.from({ length: concurrency }, () => worker())
  await Promise.allSettled(workers)

  console.log(
    chalk.hex("#00FF7F")(`✅ Warmup selesai: ${ok}/${total} sukses`) + chalk.hex("#FF6B6B")(` | ${fail} gagal`)
  )

  return { total, ok, fail }
}

// ===== LOAD COMMANDS =====
// Tampilan hybrid: plugin sukses diringkas per kategori,
// sedangkan plugin yang gagal tetap ditampilkan detailnya.
function formatPluginCategory(category) {
  const labels = {
    ai: "AI",
    downloader: "Downloader",
    group: "Group",
    main: "Main",
    owner: "Owner",
    pribadi: "Pribadi",
    search: "Search",
    stalk: "Stalk",
    sticker: "Sticker",
    store: "Store",
    tools: "Tools",
  }

  const key = String(category || "lainnya").toLowerCase()
  return labels[key] || key.charAt(0).toUpperCase() + key.slice(1)
}

function loadCommands(dir = path.join(__dirname, "./commands")) {
  const startedAt = process.hrtime.bigint()
  const categoryStats = new Map()
  const failedPlugins = []

  global.plugins = []

  const ensureCategory = (category) => {
    if (!categoryStats.has(category)) {
      categoryStats.set(category, { success: 0, failed: 0 })
    }
    return categoryStats.get(category)
  }

  const walk = (folder) => {
    fs.readdirSync(folder).forEach((file) => {
      const filepath = path.join(folder, file)
      const stat = fs.lstatSync(filepath)

      if (stat.isDirectory()) {
        walk(filepath)
        return
      }

      if (!file.endsWith(".js")) return

      const relativePath = path.relative(dir, filepath)
      const parts = relativePath.split(path.sep)
      const category = parts.length > 1 ? parts[0] : "lainnya"
      const stats = ensureCategory(category)

      try {
        delete require.cache[require.resolve(filepath)]
        const cmd = require(filepath)

        if (typeof cmd !== "function") {
          throw new TypeError("Plugin wajib mengekspor function handler")
        }

        const commands = Array.isArray(cmd.command)
          ? cmd.command
          : cmd.command instanceof RegExp
            ? [cmd.command]
            : typeof cmd.command === "string"
              ? [cmd.command]
              : []

        if (commands.length === 0 && typeof cmd.all !== "function" && typeof cmd.before !== "function") {
          console.warn(chalk.yellow(`  ⚠ Plugin tanpa command/hook: ${relativePath}`))
        }

        cmd.__file = relativePath
        global.plugins.push(cmd)
        stats.success += 1
      } catch (error) {
        stats.failed += 1
        failedPlugins.push({
          file: relativePath,
          message: String(error?.message || error || "Unknown error").split("\n")[0],
        })
      }
    })
  }

  console.log(chalk.hex("#45B7D1").bold("\n📦 Memuat Plugin...\n"))

  try {
    walk(dir)
  } catch (error) {
    failedPlugins.push({
      file: path.relative(__dirname, dir) || "commands",
      message: String(error?.message || error || "Gagal membaca folder plugin").split("\n")[0],
    })
  }

  const rows = [...categoryStats.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([category, stats]) => ({
      label: formatPluginCategory(category),
      success: stats.success,
      failed: stats.failed,
      total: stats.success + stats.failed,
    }))

  const longestLabel = Math.max(10, ...rows.map((row) => row.label.length))

  for (const row of rows) {
    const label = row.label.padEnd(longestLabel, " ")
    if (row.failed > 0) {
      console.log(
        "  " +
          chalk.yellow("⚠") +
          " " +
          chalk.white(label) +
          "  " +
          chalk.yellow(`${row.success}/${row.total} plugin`)
      )
    } else {
      console.log(
        "  " +
          chalk.hex("#00FF7F")("✓") +
          " " +
          chalk.white(label) +
          "  " +
          chalk.hex("#96CEB4")(`${row.success} plugin`)
      )
    }
  }

  if (failedPlugins.length > 0) {
    console.log(chalk.yellow.bold("\n⚠️ Plugin gagal dimuat:\n"))
    for (const failure of failedPlugins) {
      console.log(chalk.red(`  • ${failure.file}`))
      console.log(chalk.gray(`    Error: ${failure.message}`))
    }
  }

  // Deteksi command duplikat tanpa mematikan plugin.
  const commandOwners = new Map()
  for (const plugin of global.plugins) {
    const values = Array.isArray(plugin.command)
      ? plugin.command
      : typeof plugin.command === "string"
        ? [plugin.command]
        : []

    for (const value of values) {
      const key = String(value || "").trim().toLowerCase()
      if (!key) continue
      const owners = commandOwners.get(key) || []
      owners.push(plugin.__file || "unknown")
      commandOwners.set(key, owners)
    }
  }

  const duplicateCommands = [...commandOwners.entries()].filter(([, owners]) => owners.length > 1)
  if (duplicateCommands.length) {
    console.log(chalk.yellow.bold("\n⚠️ Command duplikat terdeteksi:"))
    for (const [name, owners] of duplicateCommands) {
      console.log(chalk.yellow(`  • ${name}: ${owners.join(" | ")}`))
    }
  }

  const elapsedMs = Number(process.hrtime.bigint() - startedAt) / 1_000_000
  const divider = "─".repeat(40)

  console.log(chalk.gray(`\n${divider}`))
  console.log(chalk.hex("#00FF7F")(`✅ ${global.plugins.length} plugin berhasil dimuat`))

  if (failedPlugins.length > 0) {
    console.log(chalk.red(`❌ ${failedPlugins.length} plugin gagal dimuat`))
  }

  console.log(chalk.hex("#45B7D1")(`⏱️ Proses selesai dalam ${elapsedMs.toFixed(0)} ms`))
  console.log(
    failedPlugins.length > 0
      ? chalk.yellow("🟡 Bot tetap dijalankan dengan plugin yang berhasil")
      : chalk.hex("#00FF7F")("🟢 Semua plugin siap digunakan")
  )
  console.log(chalk.gray(divider))

  return {
    loaded: global.plugins.length,
    failed: failedPlugins.length,
    categories: rows,
    elapsedMs,
  }
}


function bootstrapPluginsAfterPairing() {
  if (pluginsBootstrapped) {
    return {
      loaded: global.plugins.length,
      skipped: true,
    }
  }

  console.log(
    chalk.hex("#45B7D1").bold(
      "\n🔓 Pairing/login sukses — baru memuat plugin..."
    )
  )

  const result = loadCommands()
  watchCommands()
  pluginsBootstrapped = true
  return result
}

function watchCommands(dir = path.join(__dirname, "./commands")) {
  if (commandWatcher) return commandWatcher

  const DEBOUNCE_MS = 800

  const reloadPlugins = async (filename = "commands") => {
    // Saat .updatesc sedang menerapkan banyak file sekaligus, jangan hot-reload
    // source setengah jadi. Proses akan restart setelah update selesai.
    if (global.__WAF_UPDATING__) return

    if (commandReloadRunning) {
      commandReloadPending = true
      commandReloadPendingFile = filename || commandReloadPendingFile
      return
    }

    commandReloadRunning = true
    try {
      console.log(chalk.yellow(`\n♻️ Plugin ${filename} berubah, memuat ulang...`))
      loadCommands(dir)
    } catch (error) {
      console.error(chalk.red("[PLUGIN RELOAD ERROR]"), error?.message || error)
    } finally {
      commandReloadRunning = false
      if (commandReloadPending) {
        const pendingFile = commandReloadPendingFile || filename
        commandReloadPending = false
        commandReloadPendingFile = ""
        clearTimeout(commandReloadTimer)
        commandReloadTimer = setTimeout(() => void reloadPlugins(pendingFile), DEBOUNCE_MS)
      }
    }
  }

  try {
    commandWatcher = fs.watch(dir, { recursive: true }, (_eventType, filename) => {
      if (global.__WAF_UPDATING__) return
      if (!filename) return
      const normalized = String(filename).replace(/\\/g, "/").trim()
      if (!normalized.toLowerCase().endsWith(".js")) return

      const basename = path.basename(normalized)
      if (
        basename.startsWith(".") ||
        basename.startsWith("#") ||
        basename.endsWith("~") ||
        basename.endsWith(".tmp") ||
        basename.endsWith(".temp") ||
        basename.endsWith(".swp") ||
        basename.endsWith(".swo") ||
        basename.endsWith(".bak")
      ) return

      clearTimeout(commandReloadTimer)
      commandReloadTimer = setTimeout(() => void reloadPlugins(normalized), DEBOUNCE_MS)
    })

    commandWatcher.on("error", (error) => {
      console.error(chalk.red("[PLUGIN WATCHER ERROR]"), error?.message || error)
    })

    console.log(chalk.green("✅ Watcher plugin aktif"))
    return commandWatcher
  } catch (error) {
    console.error(chalk.red("[PLUGIN WATCHER START ERROR]"), error?.message || error)
    commandWatcher = null
    return null
  }
}

// ===== SESSION CHECK (ZAPO) =====
function prepareSessionDirectory() {
  try {
    fs.mkdirSync(SESSION_DIR, { recursive: true })

    // File Baileys lama seperti creds.json boleh tetap ada sebagai arsip.
    // Zapo tidak membacanya; session dianggap valid hanya bila SQLite + marker Zapo ada.
    if (fs.existsSync(path.join(SESSION_DIR, "creds.json"))) {
      console.log(
        chalk.gray(
          "ℹ️ Session Baileys lama terdeteksi. Zapo akan membuat session baru tanpa memakai creds.json lama."
        )
      )
    }
  } catch (error) {
    console.error(
      "[SESSION] Gagal menyiapkan folder session:",
      error?.message || error
    )
    fs.mkdirSync(SESSION_DIR, { recursive: true })
  }
}

function checkSessionExists() {
  try {
    const marker = path.join(SESSION_DIR, ".zapo-paired.json")
    const sqlite = path.join(SESSION_DIR, "zapo-state.sqlite")

    if (!fs.existsSync(sqlite) || !fs.existsSync(marker)) return false

    const parsed = JSON.parse(fs.readFileSync(marker, "utf8"))
    return parsed?.registered === true
  } catch {
    return false
  }
}

function moveLegacyTempContents(sourceDir) {
  if (!fs.existsSync(sourceDir) || path.resolve(sourceDir) === path.resolve(TEMP_DIR)) return
  const sourceName = path.basename(sourceDir)

  for (const entry of fs.readdirSync(sourceDir, { withFileTypes: true })) {
    const sourcePath = path.join(sourceDir, entry.name)
    let targetPath = path.join(TEMP_DIR, entry.name)
    if (fs.existsSync(targetPath)) {
      targetPath = path.join(TEMP_DIR, `${sourceName}-${Date.now()}-${entry.name}`)
    }

    try {
      fs.renameSync(sourcePath, targetPath)
    } catch (error) {
      console.warn(`[TEMP] Rename gagal (${entry.name}), mencoba copy: ${error?.message || error}`)
      fs.cpSync(sourcePath, targetPath, { recursive: true, force: true })
      fs.rmSync(sourcePath, { recursive: true, force: true })
    }
  }

  fs.rmSync(sourceDir, { recursive: true, force: true })
}

function prepareTempDirectory() {
  try {
    fs.mkdirSync(TEMP_DIR, { recursive: true })
    moveLegacyTempContents(path.join(ROOT_DIR, "tmp"))
    moveLegacyTempContents(path.join(ROOT_DIR, "temp-edit"))
  } catch (error) {
    console.error("[TEMP] Gagal menyatukan folder sementara:", error?.message || error)
  }
}


// ✅ helper: format waktu WIB untuk log connected
function formatWIBDateTime(date = new Date()) {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }).format(date)
  } catch {
    return String(date?.toLocaleString?.() || new Date().toLocaleString())
  }
}

// ===== BANNER + DETECT LOGIN METHOD =====
async function showBannerAndDetectMethod() {
  console.clear()

  try {
    log.header({
      version: String(global.version || "2.0.0"),
      engine: "Zapo",
    })
  } catch {
    console.log(chalk.hex("#FFD93D").bold("WhatsApp Bot"))
  }

  const sessionExists = checkSessionExists()

  // Session Zapo valid -> auto login.
  // Licence nomor aktual tetap diperiksa setelah connection === "open"
  // dan plugin belum dimuat sebelum verifikasi selesai.
  if (sessionExists) {
    console.log(chalk.hex("#00FF7F").bold("\n✅ Session ditemukan!"))
    console.log(chalk.hex("#45B7D1")("📱 Mode: Auto Login"))
    console.log(
      chalk.hex("#96CEB4")(
        "🔐 Licence akan diperiksa dari nomor WhatsApp yang terhubung sebelum plugin dimuat."
      )
    )
    console.log(chalk.hex("#FFD93D").bold("=".repeat(40)))
    console.log(chalk.hex("#96CEB4")("🚀 Menghubungkan ke WhatsApp..."))

    usePairingCode = false
    loginFlow = "auto"
    return usePairingCode
  }

  console.log(chalk.hex("#FF6B6B").bold("\n⚠️  Session tidak ditemukan"))
  console.log(chalk.hex("#45B7D1").bold("📱 Pilih Metode Login:"))
  console.log(chalk.hex("#FFEAA7").bold("  [1] ") + chalk.white("Pairing Code (No HP)"))
  console.log(chalk.hex("#FFEAA7").bold("  [2] ") + chalk.white("QR Code"))
  console.log(chalk.hex("#FFD93D").bold("=".repeat(40)))

  let choice = ""
  while (!["1", "2"].includes(choice)) {
    choice = String(
      await question(chalk.hex("#4ECDC4")("Pilihan Anda (1/2): "))
    ).trim()

    if (!["1", "2"].includes(choice)) {
      console.log(chalk.red("✗ Pilihan tidak valid. Masukkan 1 atau 2."))
    }
  }

  if (choice === "1") {
    usePairingCode = true
    loginFlow = "pairing"
    console.log(chalk.hex("#96CEB4")("✓ Mode: Pairing Code dipilih"))

    while (!pairingPhoneNumber) {
      console.log(
        chalk.hex("#4ECDC4").bold(
          "\n📞 Masukkan nomor WhatsApp yang akan dipairing"
        )
      )
      console.log(
        chalk.white("   Contoh: 6281234567890 (tanpa tanda +)")
      )

      const rawNumber = await question(
        chalk.hex("#4ECDC4")("Nomor: ")
      )

      const normalized = sanitizePhoneNumber(rawNumber)

      if (/^\d{8,15}$/.test(normalized)) {
        pairingPhoneNumber = normalized
      } else {
        console.log(
          chalk.red(
            "✗ Format nomor tidak valid. Gunakan kode negara, tanpa tanda +."
          )
        )
      }
    }

    // FLOW WAJIB MODE 1:
    // input nomor -> cek licence -> valid baru socket Zapo dibuat -> pairing code.
    let valid = false
    try {
      valid = await verifyLicenseNumber(pairingPhoneNumber)
    } catch (error) {
      console.error(
        chalk.red(
          `✗ Gagal memeriksa licence: ${error?.message || error}`
        )
      )
    }

    if (!valid) {
      await rejectAndExitForInvalidLicense(pairingPhoneNumber)
    }

    console.log(
      chalk.hex("#96CEB4")(
        "🔓 Licence valid. Pairing Code akan diminta setelah koneksi pairing siap."
      )
    )
  } else {
    // FLOW WAJIB MODE 2:
    // QR langsung ditampilkan -> setelah scan/open ambil nomor aktual -> cek licence.
    usePairingCode = false
    loginFlow = "qr"
    console.log(chalk.hex("#96CEB4")("✓ Mode: QR Code dipilih"))
    console.log(
      chalk.hex("#96CEB4")(
        "📷 QR akan ditampilkan setelah koneksi siap. Licence baru diperiksa setelah QR berhasil discan."
      )
    )
  }

  console.log(chalk.hex("#FFD93D").bold("=".repeat(40)))
  return usePairingCode
}

function scheduleReconnect(delayMs = 5000, label = "Mencoba menghubungkan ulang...") {
  if (reconnectTimer) return
  console.log(chalk.yellow(`🔁 ${label}`))
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null
    void start({ reconnect: true })
  }, delayMs)
}

// ===== START BOT =====
async function start({ reconnect = false } = {}) {
  if (startInProgress) return
  startInProgress = true

  try {
    // Pemilihan metode hanya sekali. Reconnect tidak boleh membuka prompt/banner ulang.
    if (!loginMethodConfigured) {
      await showBannerAndDetectMethod()
      loginMethodConfigured = true
    } else if (reconnect) {
      console.log(chalk.cyan("🔄 Membuat socket WhatsApp baru..."))
    }

    const { state, saveCreds } = await createZapoAuthState(SESSION_DIR)

    const socketGeneration = ++activeSocketGeneration
    let socketClosed = false
    let pairingRequested = false
    let latestQr = null
    let qrRouteMounted = false

    const socketConfig = {
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      nodeQueryTimeoutMs: 60000,
      keepAliveIntervalMs: 30000,
      historyEnabled: true,
      historyRequireFullSync: false,
      linkPreviewHq: true,
    }

    const wafproject = createZapoSocket(socketConfig)

    // Scheduler/recovery topup tetap memakai instance terbaru.
    global.wafproject = wafproject
    global.conn = wafproject

    // Canonical JID helper untuk PN/LID/device suffix.
    wafproject.decodeJid = (jid) => {
      if (!jid) return jid
      const value = String(jid).trim()

      try {
        const decoded = decodeJid(value) || {}
        if (decoded.user && decoded.server) {
          return `${decoded.user}@${decoded.server}`
        }
      } catch (error) {
        console.error("[ERROR][index.js]", error?.message || error)
      }

      return value.replace(/:\d+(?=@)/g, "")
    }

    // PENTING:
    // loadCommands()/watchCommands() TIDAK dipanggil di sini.
    // Plugin baru dimuat setelah WhatsApp open + licence lolos.

  // =========================
  // ✅ AUTO WARMUP GROUP BARU TANPA NUNGGU CHAT
  // groups.upsert biasanya muncul saat bot ditambahkan ke grup
  // =========================
  wafproject.ev.on("groups.upsert", (groups) => {
  if (!pluginsBootstrapped) return

  try {
    // ✅ anti-culik paling stabil
    void groupParticipantsUpdate.onGroupsUpsert?.(wafproject, groups)

    for (const g of groups || []) {
      const gid = String(g?.id || "")
      if (gid.endsWith("@g.us")) {
        void JidNormalizer.warmupGroupCache(wafproject, gid)
      }
    }
  } catch (error) { console.error("[ERROR][index.js]", error?.message || error) }
})
      

  // ===== MESSAGE HANDLER =====
  wafproject.ev.on("messages.upsert", async ({ messages, type }) => {
    // Satu event upsert dapat membawa beberapa pesan sekaligus.
    // Semua pesan wajib diproses; sebelumnya hanya messages[0] yang dibaca,
    // sehingga pesan grup lain dalam batch yang sama dapat terlewat.
    for (const incoming of Array.isArray(messages) ? messages : []) {
      let raw = incoming

      // Beberapa event Zapo membawa payload di content/decrypted lebih dulu.
      // Recover sebelum memutuskan event kosong supaya command valid tidak hilang.
      if (!raw?.message) {
        const recoveredMessage = recoverIncomingMessage(raw)
        if (recoveredMessage) raw = { ...raw, message: recoveredMessage }
      }
      if (!raw?.message) continue

      // Jangan proses command/event plugin sebelum login + licence lolos.
      if (!pluginsBootstrapped) continue

      try {

        // ✅ GLOBAL ANTI-LID (NON-BLOCKING, seawal mungkin)
        // IMPORTANT: jangan await (hot path)
        try {
          JidNormalizer.normalizeAllFromUpsert(wafproject, raw)
        } catch (error) { console.error("[ERROR][index.js]", error?.message || error) }

        // ✅ FIX: ANTI DOUBLE UPSET AWAL (notify/append + LID->JID) - hanya skip duplikat
        try {
          const norm = (j = "") => String(j || "").replace(/:.*@/, "@")

          const chat = norm(raw.key?.remoteJid || "")
          const sender = norm(raw.key?.participant || raw.key?.senderPn || raw.key?.remoteJid || "")

          const body = getIncomingText(raw.message)
          const id = raw.key?.id || ""
          const bodyTrim = String(body || "").trim()
          const unwrapped = unwrapIncomingMessage(raw.message)
          const messageKind =
            unwrapped?.protocolMessage ? "protocol" :
            unwrapped?.reactionMessage ? "reaction" :
            unwrapped?.pollUpdateMessage ? "poll-update" :
            unwrapped?.imageMessage ? "image" :
            unwrapped?.videoMessage ? "video" :
            unwrapped?.documentMessage ? "document" :
            unwrapped?.audioMessage ? "audio" :
            unwrapped?.stickerMessage ? "sticker" :
            Object.keys(unwrapped || {})[0] || "empty"

          // PENTING: event Zapo kadang datang 2 tahap dengan message ID yang sama:
          // tahap awal belum punya body, tahap berikutnya baru berisi teks lengkap.
          // Jangan dedupe hanya berdasarkan ID, karena event kosong pertama akan
          // membuang event lengkap dan command terlihat "tidak respon".
          if (id || bodyTrim) {
            const fp = id
              ? `id:${chat}|${id}|${bodyTrim ? "text" : `kind:${messageKind}`}`
              : `fp:${chat}|${sender}|${bodyTrim.slice(0, 120)}`

            if (upsertDedupe.get(fp)) continue
            upsertDedupe.set(fp, true)
          }
        } catch (error) { console.error("[ERROR][index.js]", error?.message || error) }

        // =========================
        // ✅ FIX FINAL: NORMALISASI EDIT MESSAGE
        // Karena edit sering masuk sebagai:
        // raw.message.editedMessage.message.protocolMessage
        // =========================
        if (raw.message?.editedMessage?.message?.protocolMessage) {
          raw.message.protocolMessage = raw.message.editedMessage.message.protocolMessage
        }

        // ===== DETEKSI EDIT (SUPPORT number + string)
        const isEdit =
          raw.message?.protocolMessage?.type === 14 ||
          raw.message?.protocolMessage?.type === "MESSAGE_EDIT"

        // ❗ Jangan skip fromMe kalau itu edit
        if (raw.key?.fromMe && !isEdit) continue

        // Pilih JID nomor asli terlebih dahulu. Pada sebagian grup WhatsApp baru,
        // key.participant dapat berupa @lid sedangkan key.senderPn berisi nomor asli.
        const getCorrectRemoteJid = (key = {}) => {
          const decoded = [key.senderPn, key.participant, key.remoteJid]
            .filter(Boolean)
            .map((jid) => wafproject.decodeJid(jid))

          return (
            decoded.find((jid) => String(jid || "").endsWith("@s.whatsapp.net")) ||
            decoded.find(Boolean) ||
            ""
          )
        }

        raw.chat = wafproject.decodeJid(raw.key.remoteJid)
        raw.sender = getCorrectRemoteJid(raw.key)
        raw.fromMe = !!raw.key?.fromMe
        if (raw.key.participant) raw.key.participant = wafproject.decodeJid(raw.key.participant)
        if (raw.key.senderPn) raw.key.senderPn = wafproject.decodeJid(raw.key.senderPn)
        raw.isGroup = String(raw.chat || "").endsWith("@g.us")
        raw.pushName = raw.pushName || "User"
        ensureIncomingTimestamp(raw)

        // ✅ wrapper-safe text parser (ephemeral/viewOnce/document caption/native flow)
        const unwrappedMessage = unwrapIncomingMessage(raw.message)
        raw.text = getIncomingText(raw.message)

        // ✅ quoted handler (wrapper-safe)
        if (unwrappedMessage?.extendedTextMessage?.contextInfo?.quotedMessage) {
          const ctx = unwrappedMessage.extendedTextMessage.contextInfo
          const quoted = ctx.quotedMessage
          const type = Object.keys(quoted)[0]
          const msg = quoted[type]
          const quotedParticipant = wafproject.decodeJid(ctx.participant)
          raw.quoted = {
            key: {
              remoteJid: wafproject.decodeJid(ctx.remoteJid || raw.chat),
              fromMe: quotedParticipant
                ? normalizeUserJid(quotedParticipant) === normalizeUserJid(wafproject.user.id)
                : false,
              id: ctx.stanzaId,
              participant: quotedParticipant,
            },
            sender: quotedParticipant,
            message: quoted,
            type,
            msg,
            text:
              msg?.text ||
              msg?.conversation ||
              msg?.caption ||
              msg?.contentText ||
              msg?.selectedDisplayText ||
              msg?.title ||
              (typeof msg === "string" ? msg : "") ||
              "",
            isMedia: !!(msg?.mimetype || msg?.thumbnailDirectPath),
            download: () =>
              downloadMediaMessage(
                { message: quoted },
                "buffer",
                {},
                { logger: console, reuploadRequest: wafproject.updateMediaMessage }
              ),
          }
        }

        // reply helper
        raw.reply = (txt) => wafproject.sendMessage(raw.chat, { text: String(txt) }, { quote: raw })

        // print incoming chat
        try {
          printIncomingChat(raw, wafproject)
        } catch (error) { console.error("[ERROR][index.js]", error?.message || error) }

        // Warmup metadata grup di background.
        // JANGAN di-await di jalur utama: pada beberapa grup, request metadata
        // dapat menggantung sehingga pesan terlihat di console tetapi command
        // tidak pernah sampai ke handler.
        if (raw.isGroup) {
          void getGroupMetadataCached(wafproject, raw.chat)
            .then((metadata) => {
              raw.groupMetadata = metadata || raw.groupMetadata || {}
              const participants = Array.isArray(metadata?.participants)
                ? metadata.participants
                : []
              const norm = (jid = "") => String(jid || "").replace(/:.*@/, "@")
              const sender = norm(raw.sender)
              const bot = norm(wafproject.user?.id || "")

              raw.isAdmin = participants.some(
                (participant) =>
                  norm(participant?.id || participant?.jid || participant?.participant) === sender &&
                  participant?.admin != null
              )
              raw.isBotAdmin = participants.some(
                (participant) =>
                  norm(participant?.id || participant?.jid || participant?.participant) === bot &&
                  participant?.admin != null
              )
            })
            .catch(() => {})
        }

        // =========================
        // ✅ ROUTER: jalankan processor anti-edit (hook dari plugin)
        // (✅ non-blocking agar command tidak ketahan)
        // =========================
        if (raw.message?.protocolMessage) {
          try {
            const tasks = []
            for (const plg of global.plugins || []) {
              if (typeof plg?.processEditFromUpsert === "function") {
                tasks.push(
                  Promise.resolve()
                    .then(() => plg.processEditFromUpsert(wafproject, db, raw))
                    .catch((e) => {
                      console.error(chalk.red("Error processEditFromUpsert:"), e)
                    })
                )
              }
            }
            // fire-and-forget: jangan block handleMessage
            void Promise.allSettled(tasks)
          } catch (e) {
            console.error(chalk.red("Error route processEditFromUpsert:"), e)
          }
        }

        // =========================
        // ✅ ROUTER: jalankan processor reaction (hook dari plugin)
        // (✅ non-blocking agar command tidak ketahan)
        // =========================
        if (raw.message?.reactionMessage) {
          try {
            const tasks = []
            for (const plg of global.plugins || []) {
              if (typeof plg?.processReactionFromUpsert === "function") {
                tasks.push(
                  Promise.resolve()
                    .then(() => plg.processReactionFromUpsert(wafproject, db, raw))
                    .catch((e) => {
                      console.error(chalk.red("Error processReactionFromUpsert:"), e)
                    })
                )
              }
            }
            // fire-and-forget: jangan block handleMessage
            void Promise.allSettled(tasks)
          } catch (e) {
            console.error(chalk.red("Error route processReactionFromUpsert:"), e)
          }
        }

        // lanjut handler command biasa
        await handleMessage(raw, {
          wafproject,
          usedPrefixList: Array.isArray(global.prefix) ? global.prefix : [".", "!", "/"],
        })
      } catch (e) {
        console.error(
          chalk.red("Error memproses pesan masuk:"),
          raw?.key?.remoteJid || "-",
          e
        )
      }
    }
  })
  // ===== GROUP UPDATE =====
  wafproject.ev.on("group-participants.update", async (update) => {
    if (!pluginsBootstrapped) return

    try {
      // ✅ GLOBAL ANTI-LID (normalize participants lid->jid jika bisa)
      try {
        await JidNormalizer.normalizeGroupUpdate(wafproject, update)
      } catch (error) { console.error("[ERROR][index.js]", error?.message || error) }

      // ✅ AUTO MAP JOIN (non-blocking): paksa warmup supaya lid->jid ke-cache tanpa nunggu chat
      try {
        const gid = String(update?.id || "")
        if (gid.endsWith("@g.us")) {
          void JidNormalizer.warmupGroupCache(wafproject, gid)
        }
      } catch (error) { console.error("[ERROR][index.js]", error?.message || error) }

      await groupParticipantsUpdate(wafproject, update)
    } catch (e) {
      console.error(chalk.red("Error group-participants.update:"), e)
    }
  })

  // ===== CALL =====
  wafproject.ev.on("call", async (call) => {
    if (!pluginsBootstrapped) return

    try {
      await antiCallHandler(wafproject, call)
    } catch (e) {
      console.error(chalk.red("Error antiCall:"), e)
    }
  })

  // ===== CREDS UPDATE =====
  wafproject.ev.on("creds.update", saveCreds)

  // ===== CONNECTION UPDATE =====
  wafproject.ev.on("connection.update", async (update) => {
    const {
      qr,
      pairingRequired,
      pairingCode,
      passkeyRequired,
      hasPasskeySigner,
      connection,
      lastDisconnect,
      isNewLogin,
      receivedPendingNotifications,
    } = update

    try {
      const loadData = await database.read()
      const storeLoadData = await storeDB.read()

      if (!loadData || Object.keys(loadData).length === 0) {
        global.db = { data: { settings: {} } }
        await database.write(global.db)
      } else {
        global.db = loadData
        if (!global.db.data) global.db.data = {}
        if (!global.db.data.settings) global.db.data.settings = {}
      }

      if (!storeLoadData || Object.keys(storeLoadData).length === 0) {
        global.store = {
          contacts: {},
          presences: {},
          messages: {},
          groupMetadata: {},
          ...(storeLoadData || {}),
        }
        await storeDB.write(global.store)
      } else {
        global.store = storeLoadData
      }
    } catch (error) {
      console.error(chalk.red("Database Error:"), error)
      process.exit(1)
    }

    if (!autosaveStarted) {
      autosaveStarted = true
      autosaveTimer = setInterval(async () => {
        try {
          if (global.db) await database.write(global.db)
          if (global.store) await storeDB.write(global.store)
        } catch (error) {
          console.error("[ERROR][index.js]", error?.message || error)
        }
      }, 30_000)
    }

    if (connection) {
      console.log(chalk.hex("#45B7D1")(`📡 Status: ${connection}`))
    }

    if (qr) latestQr = qr

    if (passkeyRequired && !hasPasskeySigner) {
      console.log(
        chalk.yellow(
          "⚠️ WhatsApp meminta passkey untuk menautkan perangkat. Pairing headless tidak bisa dilanjutkan tanpa passkey signer."
        )
      )
    }

    // Bila Zapo mengirim pairing code sebagai event, tampilkan sebagai fallback.
    if (pairingCode && usePairingCode && !pairingRequested) {
      const formatted =
        String(pairingCode).match(/.{1,4}/g)?.join("-") ||
        String(pairingCode)

      console.log(chalk.hex("#00FF7F").bold(`\n>>> ${formatted} <<<\n`))
    }

    // ===== PAIRING CODE MODE =====
    // auth_pairing_required adalah trigger utama. auth_qr dipakai fallback,
    // karena beberapa flow WhatsApp mengirim QR lebih dulu sebelum code request.
    if (
      (pairingRequired || qr) &&
      !state.creds.registered &&
      usePairingCode &&
      !pairingRequested &&
      !socketClosed &&
      socketGeneration === activeSocketGeneration
    ) {
      pairingRequested = true

      try {
        await sleep(800)

        if (
          socketClosed ||
          socketGeneration !== activeSocketGeneration
        ) {
          pairingRequested = false
          return
        }

        console.log(chalk.hex("#45B7D1").bold("\n📲 Pairing Code"))
        console.log(chalk.hex("#96CEB4")(`Nomor: ${pairingPhoneNumber}`))

        const code = await wafproject.requestPairingCode(pairingPhoneNumber)
        const formattedCode =
          String(code || "").match(/.{1,4}/g)?.join("-") ||
          String(code || "")

        if (formattedCode) {
          console.log(
            chalk.hex("#00FF7F").bold(`\n>>> ${formattedCode} <<<\n`)
          )
        }

        console.log(
          chalk.hex("#96CEB4")(
            "Masukkan kode di WhatsApp → Perangkat tertaut"
          )
        )
      } catch (error) {
        pairingRequested = false
        const status = getDisconnectStatusCode(error)

        console.log(
          chalk.red(`\n✗ Gagal meminta pairing code: ${error.message}`)
        )
        console.log(
          chalk.yellow(`Detail status: ${status || "tidak tersedia"}`)
        )

        if (
          status === 428 ||
          /connection closed/i.test(String(error.message || ""))
        ) {
          scheduleReconnect(
            2500,
            "Socket tertutup sebelum pairing. Mengulang dengan socket baru..."
          )
        }
      }
    }

    // ===== QR CODE MODE =====
    if (
      qr &&
      !state.creds.registered &&
      !usePairingCode &&
      !socketClosed
    ) {
      console.log(chalk.hex("#FF6B6B").bold("\n📷 QR CODE MODE"))
      console.log(chalk.hex("#96CEB4")("Scan QR code di bawah ini:"))
      console.log(chalk.hex("#FFD93D").bold("─".repeat(40)))
      qrcode.generate(qr, { small: true })
      console.log(chalk.hex("#FFD93D").bold("─".repeat(40)))
      console.log(
        chalk.yellow("atau buka: ") +
          chalk.white(`http://localhost:${PORT || 3000}/qr`)
      )

      if (!qrRouteMounted) {
        qrRouteMounted = true
        app.get("/qr", async (_req, res) => {
          try {
            if (!latestQr) {
              return res.status(503).send("QR belum tersedia")
            }

            res.setHeader("content-type", "image/png")
            res.end(await toBuffer(latestQr))
          } catch {
            res.status(500).send("Gagal membuat QR")
          }
        })
      }
    }

    // ===== CONNECTION OPEN =====
    if (connection === "open") {
      const connectedNumber = getConnectedPhoneNumber(
        wafproject,
        state
      )

      // MODE 1:
      // nomor licence sudah dicek SEBELUM socket dibuat.
      // Sesudah pairing, pastikan nomor yang benar-benar terhubung sama.
      if (loginFlow === "pairing") {
        if (
          connectedNumber &&
          pairingPhoneNumber &&
          connectedNumber !== pairingPhoneNumber
        ) {
          console.log(
            chalk.red.bold(
              `⛔ Nomor yang terhubung (${connectedNumber}) berbeda dari nomor licence/pairing (${pairingPhoneNumber}).`
            )
          )

          try { await wafproject.logout?.() } catch {}
          purgeWhatsAppSession()
          process.exit(1)
        }

        console.log(
          chalk.hex("#00FF7F").bold(
            `✅ Pairing sukses. Licence ${
              verifiedLicenseNumber || pairingPhoneNumber
            } aktif.`
          )
        )
      } else {
        // MODE 2 / QR dan AUTO LOGIN:
        // nomor aktual baru diketahui saat connection open.
        if (!connectedNumber) {
          console.log(
            chalk.red.bold(
              "⛔ Nomor WhatsApp yang terhubung tidak dapat dibaca. Licence tidak bisa diverifikasi."
            )
          )

          try { await wafproject.logout?.() } catch {}
          purgeWhatsAppSession()
          process.exit(1)
        }

        let licenceValid = false
        try {
          licenceValid = await verifyLicenseNumber(connectedNumber)
        } catch (error) {
          console.error(
            chalk.red(
              `✗ Gagal memeriksa licence setelah login: ${
                error?.message || error
              }`
            )
          )
        }

        if (!licenceValid) {
          printLicenseRejected(connectedNumber)

          try { await wafproject.logout?.() } catch {}

          // QR/session tidak valid tidak boleh meninggalkan session aktif.
          purgeWhatsAppSession()
          process.exit(1)
        }

        console.log(
          chalk.hex("#00FF7F").bold(
            `✅ Licence ${connectedNumber} aktif.`
          )
        )
      }

      // SATU-SATUNYA titik plugin dimuat saat startup.
      // Topup/order/payment tidak pernah di-require sebelum login+licence lolos.
      bootstrapPluginsAfterPairing()

      global.wafproject = wafproject
      global.conn = wafproject

      console.log(chalk.green("🤖 BOT CONNECTED"))

      // ===== RECOVERY TRANSAKSI SETELAH RESTART =====
      // Plugin sudah dimuat di atas sehingga hook recovery tersedia.
      void (async () => {
        try {
          const orderRecovery =
            typeof global.__WAF_RECOVER_PAYKITA_ORDERS__ === "function"
              ? await global.__WAF_RECOVER_PAYKITA_ORDERS__(wafproject)
              : { total: 0, resumed: 0, processing: 0 }

          const depositRecovery =
            typeof global.__WAF_RECOVER_PAYKITA_DEPOSITS__ === "function"
              ? await global.__WAF_RECOVER_PAYKITA_DEPOSITS__(wafproject)
              : { total: 0, resumed: 0, credited: 0 }

          const totalPending =
            Number(orderRecovery.total || 0) +
            Number(depositRecovery.total || 0)

          if (totalPending > 0) {
            console.log(
              chalk.hex("#45B7D1")(
                "♻️ Recovery transaksi setelah restart..."
              )
            )
            console.log(
              chalk.hex("#96CEB4")(
                `✅ PayKita order dilanjutkan: ${
                  orderRecovery.resumed || 0
                }/${orderRecovery.total || 0}`
              )
            )
            console.log(
              chalk.hex("#96CEB4")(
                `✅ Deposit dilanjutkan: ${
                  depositRecovery.resumed || 0
                }/${depositRecovery.total || 0}`
              )
            )
          }
        } catch (error) {
          console.error(
            "[TRANSACTION RECOVERY ERROR]",
            error?.message || error
          )
        }
      })()

      void warmupAllGroupsNoUI(wafproject, { concurrency: 3 })
        .then(() => {
          console.log(
            chalk.hex("#45B7D1")(
              "💬 Menunggu pesan masuk dari chat.."
            )
          )
        })
        .catch(() => {
          console.log(
            chalk.hex("#45B7D1")(
              "💬 Menunggu pesan masuk dari chat.."
            )
          )
        })

      // LOAD PREFIX DARI DATABASE
      try {
        const jid =
          wafproject.user?.jid ||
          wafproject.user?.id ||
          "bot"

        const normalizedJid = normalizeAccountJid(jid)
        const settings = global.db?.data?.settings || {}
        const saved = findSavedPrefix(settings, jid)

        if (saved.found) {
          wafproject.prefix = saved.prefix

          settings[normalizedJid] ||= {}
          settings[normalizedJid].prefix = saved.prefix
          db.save(100)

          console.log(
            chalk.hex("#DDA0DD")("🎯 Prefix loaded: ") +
              chalk.white(
                saved.prefix === ""
                  ? "OFF (no prefix)"
                  : saved.prefix === null
                    ? "DEFAULT"
                    : Array.isArray(saved.prefix)
                      ? saved.prefix.join(" , ")
                      : String(saved.prefix)
              ) +
              chalk.gray(
                saved.source !== normalizedJid
                  ? " (setting lama dipulihkan)"
                  : ""
              )
          )
        } else {
          wafproject.prefix = null
          console.log(chalk.hex("#DDA0DD")("🎯 Prefix: DEFAULT"))
        }
      } catch (error) {
        console.error("Failed load prefix:", error)
      }

      const user = wafproject.user || {}
      const jidStr = user.id || user.jid || "-"
      const loginWIB = formatWIBDateTime(new Date())

      let method = "QR Code"
      if (loginFlow === "auto") method = "Auto Login"
      else if (loginFlow === "pairing") method = "Pairing Code"

      try {
        log.connected({
          user: (user.name || "Unknown") + "",
          jid: jidStr + "",
          loginTimeWIB: loginWIB + "",
          method: method + "",
          plugins: Number(global.plugins.length || 0),
        })
      } catch {
        console.log(chalk.green("CONNECTED SUCCESSFULLY"))
        console.log("User:", user.name || "Unknown")
        console.log("JID:", jidStr)
        console.log("Login:", loginWIB)
        console.log("Method:", method)
        console.log("Plugins:", global.plugins.length)
      }

      console.log(chalk.hex("#FFD93D").bold("=".repeat(40)))
      console.log(
        chalk.hex("#FF6B6B")("🤖 Bot Status: ") +
          chalk.green("ONLINE")
      )
      console.log(
        chalk.hex("#96CEB4")("📁 Plugins: ") +
          chalk.white(global.plugins.length + " loaded")
      )
      console.log(chalk.hex("#FFD93D").bold("=".repeat(40)))
    }

    // ===== CONNECTION CLOSE =====
    if (connection === "close") {
      socketClosed = true

      if (shutdownStarted) return

      const rawError = lastDisconnect?.error
      const reason = getDisconnectStatusCode(rawError)
      const errorMessage =
        rawError?.message ||
        rawError?.output?.payload?.message ||
        "Unknown"

      const messages = {
        [ZapoDisconnectReason.connectionLost]:
          chalk.yellow("📡 Koneksi terputus."),
        [ZapoDisconnectReason.connectionClosed]:
          chalk.yellow("🔒 Koneksi ditutup."),
        [ZapoDisconnectReason.restartRequired]:
          chalk.cyan("🔄 Restart socket diperlukan."),
        [ZapoDisconnectReason.timedOut]:
          chalk.yellow("⏰ Koneksi timeout."),
        [ZapoDisconnectReason.badSession]:
          chalk.red("🗑️ Session rusak."),
        [ZapoDisconnectReason.connectionReplaced]:
          chalk.red("⚠️ Koneksi diganti oleh perangkat lain."),
        [ZapoDisconnectReason.loggedOut]:
          chalk.red("🚪 Akun sudah logout."),
        [ZapoDisconnectReason.forbidden]:
          chalk.red("⛔ Koneksi ditolak/forbidden."),
        [ZapoDisconnectReason.multideviceMismatch]:
          chalk.red("📱 Multi-device mismatch."),
      }

      console.log(
        messages[reason] ||
          chalk.red(`❌ Koneksi tertutup: ${reason || "unknown"}`)
      )
      console.log(
        chalk.gray(
          `   Detail: ${errorMessage} | status=${reason || "-"}`
        )
      )

      if (socketGeneration !== activeSocketGeneration) return

      await wafproject.closeStore?.()

      const zapoLogout = rawError?.isLogout === true

      if (
        zapoLogout ||
        reason === ZapoDisconnectReason.loggedOut
      ) {
        try {
          fs.rmSync(SESSION_DIR, {
            recursive: true,
            force: true,
          })
          fs.mkdirSync(SESSION_DIR, { recursive: true })
        } catch (error) {
          console.error(
            "[ERROR][index.js]",
            error?.message || error
          )
        }

        loginMethodConfigured = false
        usePairingCode = null
        pairingPhoneNumber = ""
        loginFlow = null

        console.log(
          chalk.yellow(
            "🗑️ Session dihapus. Jalankan ulang bot untuk login kembali."
          )
        )
        process.exit(1)
      }

      if (
        reason === ZapoDisconnectReason.connectionReplaced
      ) {
        console.log(
          chalk.red(
            "Bot tidak melakukan reconnect agar tidak terjadi loop dua perangkat."
          )
        )
        return
      }

      const waitMs =
        reason === ZapoDisconnectReason.restartRequired ||
        reason === 515
          ? 1200
          : 3500

      scheduleReconnect(waitMs)
    }

    if (isNewLogin) {
      console.log(chalk.cyan("\n🆕 New device login detected!"))
    }

    if (receivedPendingNotifications === true) {
      console.log(
        chalk.yellow("\n⏳ Please wait, syncing messages...")
      )

      if (typeof wafproject.ev.flush === "function") {
        wafproject.ev.flush()
      }
    }
  })

  // ===== CONTACTS UPDATE =====
  wafproject.ev.on("contacts.update", (update) => {
    for (let contact of update || []) {
      let id = wafproject.decodeJid(contact.id)
      if (_toggleStoreContacts() && global.store && global.store.contacts) {
        global.store.contacts[id] = {
          id,
          name: contact.notify,
        }
      }
    }
  })
  } finally {
    startInProgress = false
  }
}

// helper agar aman kalau store belum siap
function _toggleStoreContacts() {
  try {
    return true
  } catch {
    return false
  }
}

// ===== RUN =====
async function bootstrap() {
  prepareSessionDirectory()
  prepareTempDirectory()

  try {
    const health = await checkDatabaseHealth()
    if (health.invalid.length) {
      for (const item of health.invalid) {
        console.error(chalk.red(`❌ Database tidak valid: ${item.file} — ${item.error}`))
      }
      throw new Error(`${health.invalid.length} file database JSON tidak valid`)
    }
    console.log(chalk.green(`✅ Database health: ${health.valid}/${health.checked} JSON valid`))
  } catch (error) {
    console.error(chalk.red("❌ Database health check gagal:"), error?.message || error)
    process.exit(1)
  }

  console.log(chalk.hex("#45B7D1")("\n🚀 Starting WhatsApp Bot..."))
  await start()
}

bootstrap().catch((error) => {
  console.error(chalk.red("Fatal error:"), error)
  process.exit(1)
})

// Handle process exit dengan batas waktu agar database sempat flush.
async function gracefulShutdown(signal) {
  if (shutdownStarted) return
  shutdownStarted = true

  console.log(chalk.yellow(`\n\n👋 Shutting down bot (${signal})...`))

  const forceTimer = setTimeout(() => {
    console.error(chalk.red("Shutdown timeout, proses dihentikan paksa."))
    process.exit(1)
  }, 8000)
  forceTimer.unref?.()

  try {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer)
      reconnectTimer = null
    }
    if (commandReloadTimer) {
      clearTimeout(commandReloadTimer)
      commandReloadTimer = null
    }
    if (commandWatcher) {
      try { commandWatcher.close() } catch (error) {
        console.error("[PLUGIN WATCHER CLOSE ERROR]", error?.message || error)
      }
      commandWatcher = null
    }
    if (autosaveTimer) {
      clearInterval(autosaveTimer)
      autosaveTimer = null
    }

    upsertDedupe.flushAll()
    groupMetaCache.flushAll()

    try {
      await global.wafproject?.disconnect?.()
    } catch (error) {
      console.error("[ZAPO DISCONNECT ERROR]", error?.message || error)
    }

    await db.flush?.()
    rl.close()
    server?.close?.()
  } catch (error) {
    console.error("Shutdown error:", error?.message || error)
  } finally {
    clearTimeout(forceTimer)
    process.exit(0)
  }
}

process.once("SIGINT", () => gracefulShutdown("SIGINT"))
process.once("SIGTERM", () => gracefulShutdown("SIGTERM"))
