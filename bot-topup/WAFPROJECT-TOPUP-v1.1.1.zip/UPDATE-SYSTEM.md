# Sistem `.updatesc` — WAF PROJECT TOPUP

## Alur pembeli

Pembeli cukup menjalankan:

```text
.updatesc
```

Bot akan:

1. mengecek ulang licence nomor WhatsApp bot;
2. membaca manifest update;
3. membandingkan versi lokal dengan versi server;
4. mengunduh ZIP update;
5. memverifikasi SHA-256 jika manifest menyediakannya;
6. mengecek syntax seluruh file JavaScript pada paket update;
7. membuat backup source lama;
8. menerapkan source baru tanpa menimpa `database/`, `session/`, `auth/`, `settings.js`, `.env`, `temp/`, atau `backups/`;
9. langsung restart proses dengan exit code `75` agar Pterodactyl menjalankannya kembali.

Updater **tidak menjalankan `npm install`**. Karena itu, release update biasa harus memakai dependency yang sudah tersedia di SC utama. Jika suatu versi benar-benar membutuhkan package npm baru, dependency tersebut harus dimasukkan pada rilis SC utama berikutnya.

Command ini `owner-only` dan licence dicek ulang setiap kali `.updatesc` dipakai.

## Lokasi manifest default

Source ini membaca:

```text
https://raw.githubusercontent.com/wafproject/BOT/main/bot-topup/update-topup.json
```

Bisa diganti tanpa mengedit source melalui environment variable:

```text
UPDATE_MANIFEST_URL=https://domain-kamu.com/update-topup.json
```

## Format manifest

```json
{
  "product": "wafproject-topup-zapo",
  "version": "1.2.0",
  "zip_url": "https://domain-kamu.com/releases/WAFPROJECT-TOPUP-v1.2.0.zip",
  "sha256": "64-karakter-sha256-zip",
  "notes": [
    "Multi order diperbaiki",
    "Tambah fitur baru"
  ],
  "delete": []
}
```

`zip_url` wajib HTTPS. `product` harus persis `wafproject-topup-zapo`.

## Membuat release update

Naikkan versi di `package.json`, misalnya `1.1.0` menjadi `1.1.1`, lalu jalankan:

```bash
npm run build:update
```

Hasil ada di folder `release/`:

- `WAFPROJECT-TOPUP-vX.Y.Z.zip`
- `update-topup.json`

Edit `zip_url` di `release/update-topup.json`, lalu upload ZIP ke hosting/GitHub Release dan upload ZIP dan manifest ke folder `bot-topup/` di repo `wafproject/BOT`.

## Data yang tidak disentuh update

Updater sengaja mempertahankan:

- `database/`
- `session/`
- `auth/`
- `settings.js`
- `.env`
- `temp/`
- `backups/`
- `node_modules/`

Karena `settings.js` dipertahankan, nomor owner, API key PayKita/Digiflazz, branding, dan konfigurasi milik pembeli tidak tertimpa.

## Backup

Setiap update membuat backup source di:

```text
backups/update-<timestamp>/
```

Jika penerapan update gagal, updater mencoba rollback otomatis ke backup tersebut.
