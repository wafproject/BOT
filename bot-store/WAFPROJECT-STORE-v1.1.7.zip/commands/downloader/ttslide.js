"use strict";
const {fetchTikTok,isTikTokUrl}=require("../../lib/tiktok-provider.js");
const {sendSlides}=require("../../lib/tiktok-slides.js");
let handler=async(m,{wafproject,text,usedPrefix,command})=>{
  const link=String(text||"").trim();
  if(!link)return m.reply(`📌 *Cara pakai:*\n${usedPrefix+command} <link slide TikTok>`);
  if(!isTikTokUrl(link))return m.reply("❌ Link TikTok tidak valid.");
  const title="🖼️ *TikTok Slide Downloader*";
  let status=null;
  const edit=async s=>{
    if(!status?.key)return false;
    try{await wafproject.sendMessage(m.chat,{text:s,edit:status.key});return true;}
    catch{return false;}
  };
  const react=async e=>{
    try{await wafproject.sendMessage(m.chat,{react:{text:e,key:m.key}});}catch{}
  };
  try{
    await react("⏳");
    try{status=await wafproject.sendMessage(m.chat,
      {text:`${title}\n━━━━━━━━━━━━━━━━━━\n🔎 Mencari slide...\n🔁 Fallback otomatis aktif\n━━━━━━━━━━━━━━━━━━`},{quoted:m});}catch{}
    const result=await fetchTikTok(link,"images");
    const stats=await sendSlides(wafproject,m,link,result,async({index,total,sent,failed,source})=>
      edit(`${title}\n━━━━━━━━━━━━━━━━━━\n📡 ${source}\n🖼️ Slide ${index}/${total}\n✅ Terkirim: ${sent} | ❌ Gagal: ${failed}\n━━━━━━━━━━━━━━━━━━`));
    await edit(`${title}\n━━━━━━━━━━━━━━━━━━\n✅ Selesai\n🖼️ Terkirim: *${stats.sent}*\n❌ Gagal: *${stats.failed}*\n🎵 Audio: *${stats.music}*\n━━━━━━━━━━━━━━━━━━`);
    await react("✅");
  }catch(error){
    await react("❌");
    console.error("[TikTok Slide]",error?.message||error);
    const key=String(global.jagoanKey||global.jagprokey||"\0");
    const msg=String(error?.message||error).replaceAll(key,"[API_KEY]").slice(0,500);
    const fail=`${title}\n━━━━━━━━━━━━━━━━━━\n❌ Download gagal\n📌 ${msg}\n━━━━━━━━━━━━━━━━━━`;
    if(!await edit(fail))return m.reply(fail);
  }
};
handler.command=["ttslide","tiktokslide"];
handler.help=["ttslide <url>","tiktokslide <url>"];
handler.tags=["downloader"];
handler.category=["downloader"];
handler.limit=true;
handler.register=true;
module.exports=handler;
