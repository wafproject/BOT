"use strict";
/** WAF PROJECT TikTok: .tt (video or slide automatically), .tikmp3 (audio). */
const {fetchTikTok, isTikTokUrl} = require("../../lib/tiktok-provider.js");
const {sendWhatsApp} = require("../../lib/tiktok-transfer.js");
const {sendSlides} = require("../../lib/tiktok-slides.js");
const clip = (s, max=450) => String(s || "").replace(/[\r\n]+/g," ").replace(/\s+/g," ").trim().slice(0,max);
const format = n => Number(n || 0).toLocaleString("id-ID");

let handler = async (m, {wafproject, command, text, usedPrefix}) => {
  const input = String(text || "").trim();
  if (!input) return m.reply(`📌 *Penggunaan:*\n${usedPrefix+command} <link TikTok>\n\nContoh:\n${usedPrefix+command} https://vt.tiktok.com/xxxx/`);
  if (!isTikTokUrl(input)) return m.reply("❌ Link TikTok tidak valid.");
  const isAudio = String(command).toLowerCase() === "tikmp3";
  const title = isAudio ? "🎧 *TikTok Audio*" : "🎬 *TikTok Downloader*";
  let status = null;
  const react = async emoji => {
    try {await wafproject.sendMessage(m.chat,{react:{text:emoji,key:m.key}});}
    catch { /* WhatsApp may not support reaction in every chat */ }
  };
  const edit = async value => {
    if (!status?.key) return false;
    try {await wafproject.sendMessage(m.chat,{text:value,edit:status.key});return true;}
    catch {return false;}
  };
  try {
    await react("⏳");
    try {status=await wafproject.sendMessage(m.chat,
      {text:`${title}\n━━━━━━━━━━━━━━━━━━\n🔎 Mencari media...\n🔁 JagoanProject + server cadangan\n━━━━━━━━━━━━━━━━━━`},
      {quoted:m});} catch { /* Optional progress */ }
    let result=await fetchTikTok(input,isAudio?"audio":"auto");
    if (!isAudio && !(result.video?.url || result.video?.buffer) && result.images?.length) {
      const stats=await sendSlides(wafproject,m,input,result, async progress =>
        edit(`${title}\n━━━━━━━━━━━━━━━━━━\n📦 *Foto TikTok* (${progress.source})\n🖼️ Slide ${progress.index}/${progress.total}\n✅ Terkirim: ${progress.sent}\n━━━━━━━━━━━━━━━━━━`));
      await edit(`${title}\n━━━━━━━━━━━━━━━━━━\n✅ Slide berhasil diproses\n🖼️ ${stats.sent}/${stats.total} gambar terkirim\n🎵 Audio: ${stats.music}\n━━━━━━━━━━━━━━━━━━`);
      await react("✅");
      return;
    }
    const caption = !isAudio
      ? `🎬 *TikTok Downloader*\n━━━━━━━━━━━━━━━━━━\n` +
        `📝 ${clip(result.title,600) || "-"}\n` +
        (result.author ? `👤 ${clip(result.author,80)}\n` : "") +
        (result.stats?.views || result.stats?.likes ? `▶️ ${format(result.stats.views)} views • ❤️ ${format(result.stats.likes)} suka\n` : "") +
        `📡 Sumber: ${result.source}` : "";
    await edit(`${title}\n━━━━━━━━━━━━━━━━━━\n✅ Media ditemukan\n📤 Mengirim ${isAudio?"audio":"video"}...\n📡 ${result.source}\n━━━━━━━━━━━━━━━━━━`);
    try {
      await sendWhatsApp(wafproject,m.chat,isAudio?result.audio:result.video,isAudio?"audio":"video",caption,m,"tiktok-audio");
    } catch (err) {
      if (result.source !== "JagoanProject") throw err;
      await edit(`${title}\n━━━━━━━━━━━━━━━━━━\n⚠️ Server utama tidak dapat mengirim file\n🔁 Menggunakan server cadangan...\n━━━━━━━━━━━━━━━━━━`);
      result=await fetchTikTok(input,isAudio?"audio":"video",{skipJagoan:true});
      await sendWhatsApp(wafproject,m.chat,isAudio?result.audio:result.video,isAudio?"audio":"video",caption,m,"tiktok-audio");
    }
    await edit(`${title}\n━━━━━━━━━━━━━━━━━━\n✅ Berhasil dikirim!\n📡 ${result.source}\n━━━━━━━━━━━━━━━━━━`);
    await react("✅");
  } catch (error) {
    await react("❌");
    console.error("[TikTok Downloader]", error?.message || error);
    const key=String(global.jagoanKey || global.jagprokey || "\0");
    const message=clip(error?.message || error,500).replaceAll(key,"[API_KEY]");
    const notice=`${title}\n━━━━━━━━━━━━━━━━━━\n❌ Download gagal\n📌 ${message}\n━━━━━━━━━━━━━━━━━━`;
    if (!await edit(notice)) return m.reply(notice);
  }
};
handler.help=["tt <url>","tikmp3 <url>"];
handler.tags=["downloader"];
handler.category=["downloader"];
handler.command=["tt","tiktok","tikmp3"];
handler.limit=true;
handler.register=true;
module.exports=handler;
