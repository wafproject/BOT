// commands/store/store-list.js
// 📜 Store - list (CommonJS)
// SAVE/READ: database/databaseStore.json
// - .list baca items dari file yang sama dengan store-menu
// - .setlist simpan templateIndex/manualTemplate di file yang sama
// - template bawaan ambil dari database/template/list.js (CommonJS) via require
// - (DIHAPUS) tombol NativeFlow

const fs = require('fs')
const fsp = fs.promises
const path = require('path')

const { databaseFile } = require('../../lib/project-paths')
const STORE_PATH = databaseFile('databaseStore.json')
const STORE_DIR = path.dirname(STORE_PATH)


async function readJsonSafe() {
  try {
    await fsp.mkdir(STORE_DIR, { recursive: true })
    return JSON.parse(await fsp.readFile(STORE_PATH, 'utf8'))
  } catch (error) {
    if (error?.code !== 'ENOENT') console.error('[STORE DB] read:', error?.message || error)
    return {}
  }
}
async function writeJsonSafe(data) {
  try {
    await fsp.mkdir(STORE_DIR, { recursive: true })
    await fsp.writeFile(STORE_PATH, JSON.stringify(data, null, 2), 'utf8')
    return true
  } catch (error) {
    console.error('[STORE DB] write:', error?.message || error)
    return false
  }
}

function ensureGroupNode(db, gid) {
  if (!db[gid]) db[gid] = {}
  db[gid].items ||= {}
  db[gid].notes ||= {}
  if (typeof db[gid].templateIndex !== 'number') db[gid].templateIndex = 1
  if (typeof db[gid].manualTemplate !== 'string') db[gid].manualTemplate = ''
  return db[gid]
}

// WIB helpers
const ID_DAYS = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu']
const pad2 = (n) => String(n).padStart(2, '0')
function toWIBDate(date = new Date()) {
  const utc = date.getTime() + (date.getTimezoneOffset() * 60000)
  return new Date(utc + 7 * 60 * 60000)
}
function getGreetingWIB(d = toWIBDate()) {
  const h = d.getHours()
  if (h >= 4 && h < 11) return 'pagi'
  if (h >= 11 && h < 15) return 'siang'
  if (h >= 15 && h < 18) return 'sore'
  return 'malam'
}
function formatDateDDMMYYYY(d) {
  return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`
}
function formatTimeHHMMSS(d) {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())} WIB`
}

function renderManualTemplate(tpl, data) {
  const listText = (data.list || []).map((x) => `- ${x}`).join('\n')
  const map = {
    '@name': data.name,
    '@user': data.name,
    '@group': data.group,
    '@date': data.date,
    '@day': data.day,
    '@time': data.time,
    '@greeting': data.greeting,
    '@size': String(data.size ?? ''),
    '@list': listText
  }
  let out = String(tpl || '')
  for (const [k, v] of Object.entries(map)) out = out.split(k).join(String(v ?? ''))
  return out
}

const textReply = (wafproject, m, text) =>
  wafproject.sendMessage(m.chat, { text: String(text) }, { quote: m })

// ✅ load template CommonJS (auto-reload on file change)
let cachedTpl = null
function loadTemplates() {
  if (cachedTpl) return cachedTpl

  const filePath = path.join(process.cwd(), 'database', 'template', 'list.js')

  // buang cache supaya perubahan file langsung kebaca
  try {
    delete require.cache[require.resolve(filePath)]
  } catch (_error) { console.error("[ERROR][commands/store/store-list.js]", _error?.message || _error) }

  const mod = require(filePath)

  const applyTemplate = mod?.applyTemplate
  const TEMPLATE_COUNT = mod?.TEMPLATE_COUNT ?? mod?.templates?.length ?? 0

  if (typeof applyTemplate !== 'function') {
    throw new Error('Template loader error: applyTemplate is not a function (cek database/template/list.js)')
  }

  cachedTpl = { applyTemplate, TEMPLATE_COUNT }
  return cachedTpl
}

async function getGroupName(wafproject, m) {
  if (!m.isGroup) return 'Grup'
  try {
    const meta = await wafproject.groupMetadata(m.chat)
    return meta?.subject || 'Grup'
  } catch {
    return 'Grup'
  }
}

const plugin = async (m, { wafproject, usedPrefix = '.', command, recallCommand, text = '', isAdmin, isOwner }) => {
  try {
    if (!wafproject) return
    if (!m.isGroup) return

    const cmd = String(command || '').toLowerCase()
    if (cmd !== 'list' && cmd !== 'setlist') return

    const gid = m.chat
    const dbJson = await readJsonSafe()
    const node = ensureGroupNode(dbJson, gid)

    // ===================== SETLIST =====================
    if (cmd === 'setlist') {
      if (!(isAdmin || isOwner)) return textReply(wafproject, m, '🚫 Perintah *setlist* khusus admin/owner grup.')

      const { TEMPLATE_COUNT } = loadTemplates()
      const input = String(text || '').trim()

      if (!input) {
        return textReply(
          wafproject, m,
          `*SETLIST (Template List)*\n\n` +
          `Mode 1 — Template Bawaan:\n` +
          `› *${usedPrefix}setlist <1-${TEMPLATE_COUNT}>*\n\n` +
          `Mode 2 — Template Manual (Custom):\n` +
          `› *${usedPrefix}setlist <teks template>*\n\n` +
          `Reset manual template:\n` +
          `› *${usedPrefix}setlist reset*\n\n` +
          `Placeholder: @name/@user, @group, @date, @day, @time, @greeting, @size, @list`
        )
      }

      if (input.toLowerCase() === 'reset') {
        node.manualTemplate = ''
        await writeJsonSafe(dbJson)
        return textReply(wafproject, m, '✅ Template manual dihapus. Sekarang kembali pakai template bawaan.')
      }

      const num = parseInt(input, 10)
      if (Number.isFinite(num) && String(num) === input) {
        if (num < 1 || num > TEMPLATE_COUNT) {
          return textReply(wafproject, m, `❌ Format: *${usedPrefix}setlist <1-${TEMPLATE_COUNT}>*`)
        }
        node.templateIndex = num
        node.manualTemplate = ''
        await writeJsonSafe(dbJson)
        return textReply(wafproject, m, `✅ Template list grup ini di-set ke *Template ${num}* (bawaan).`)
      }

      if (input.length > 4000) return textReply(wafproject, m, '❌ Template terlalu panjang (maks 4000 karakter).')
      node.manualTemplate = input
      await writeJsonSafe(dbJson)
      return textReply(wafproject, m, `✅ Template manual tersimpan!\nKetik *${usedPrefix}list* untuk lihat hasilnya.`)
    }

    // ===================== LIST =====================
    const itemMap = node.items || {}
    const names = Object.values(itemMap)
      .map(it => String(it?.key || '').trim())
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b, 'id', { sensitivity: 'base' }))

    if (!names.length) {
      return textReply(wafproject, m, `😔 Belum ada item.\nAdmin bisa tambah pakai *${usedPrefix}addlist*.`)
    }

    const groupName = await getGroupName(wafproject, m)
    const now = toWIBDate(new Date())

    const data = {
      name: m.pushName || 'kak',
      group: groupName,
      date: formatDateDDMMYYYY(now),
      day: ID_DAYS[now.getDay()],
      time: formatTimeHHMMSS(now),
      greeting: getGreetingWIB(now),
      size: names.length,
      desc: '',
      list: names
    }

    let textOut = ''
    const manual = String(node.manualTemplate || '').trim()
    if (manual.length) {
      textOut = renderManualTemplate(manual, data)
    } else {
      const { applyTemplate } = loadTemplates()
      textOut = applyTemplate(node.templateIndex || 1, data)
    }

    // ✅ kirim teks list saja (tombol NativeFlow dihapus)
    await wafproject.sendMessage(m.chat, { text: textOut }, { quote: m })
  } catch (e) {
    console.error('store-list error:', e)
    return textReply(wafproject, m, '❌ Terjadi kesalahan di fitur *list*.')
  }
}

plugin.help = ['list', 'setlist']
plugin.tags = ['store']
plugin.command = ['list', 'setlist']
plugin.category = 'store'
plugin.group = true
plugin.owner = false
plugin.limit = false

plugin.adminCommands = ['setlist']

module.exports = plugin