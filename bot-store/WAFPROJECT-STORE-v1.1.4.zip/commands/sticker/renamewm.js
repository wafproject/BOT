////////////////////////////
/* WAF PROJECT - WM (Rename Watermark Manual)
   Cmd : .wm
   Pakai:
   - Reply sticker + .wm Rafi Ni bos
   - Reply sticker + .wm  (pakai global.packname)
   Author dikosongin (manual rename pack aja)
*/
////////////////////////////

const { Sticker } = require('../../lib/sticker-formatter')

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m

  const isSticker =
    q?.mtype === 'stickerMessage' ||
    q?.message?.stickerMessage ||
    (q?.msg?.mimetype && /webp/i.test(q.msg.mimetype))

  if (!isSticker) {
    return m.reply(
      'Reply stikernya dulu.\n' +
      `Contoh:\n• Reply sticker lalu ketik ${usedPrefix + command} Rafi Ni bos`
    )
  }

  const packname = String(text || '').trim() || global.packname || 'WAF PROJECT'
  const author = '' // ✅ manual rename: author dikosongin

  try {
    await wafproject.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    let buffer = null
    try { buffer = await q.download?.() } catch (_error) { console.error("[ERROR][commands/sticker/renamewm.js]", _error?.message || _error) }
    if (!buffer) {
      try { buffer = await wafproject.downloadMediaMessage(q) } catch (_error) { console.error("[ERROR][commands/sticker/renamewm.js]", _error?.message || _error) }
    }
    if (!buffer) throw new Error('Gagal download sticker.')

    const sticker = new Sticker(buffer, {
      type: 'full',
      pack: packname,
      author,
      quality: 60
    })

    const out = await sticker.toBuffer()

    await wafproject.sendMessage(m.chat, { sticker: out }, { quote: m })
    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('WM ERROR:', e)
    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
    m.reply('Gagal rename watermark.')
  }
}

handler.help = ['wm','colong']
handler.category = ['sticker']
handler.command = /^(wm|colong)$/i
handler.limit = true
handler.register = true

module.exports = handler