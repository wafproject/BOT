const axios = require('axios')
const { Sticker } = require('../../lib/sticker-formatter')

const PACKS = {
  dinokuning: 'dinokuning',
  sdino: 'dinokuning',

  patrick: 'patrick',
  spatrick: 'patrick',

  spongebob: 'spongebob',
  sspongebob: 'spongebob',

  doge: 'doge',
  sdoge: 'doge',

  manusialidi: 'manusialidi',
  smanusialidi: 'manusialidi',
}

let handler = async (m, { wafproject, command, usedPrefix }) => {
  const errorImg = 'https://telegra.ph/file/12141dd462ecabeed1347.png'

  try {
    const key = String(command || '').toLowerCase()
    const packName = PACKS[key]
    if (!packName) return

    const base = global.apibtc || 'https://api.botcahx.eu.org'
    const apikey = global.btc
    if (!apikey) {
      return m.reply(`🚩 APIKEY belum diset. Isi dulu global.btc di settings.js`)
    }

    const url = `${base}/api/sticker/${packName}?apikey=${encodeURIComponent(apikey)}`

    // ambil file dari API
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 45000 })
    const buf = Buffer.from(res.data)

    // convert ke sticker
    const pack = global.packname || 'Sticker Bot'
    const author = global.author || 'Bot'
    const stk = new Sticker(buf, { pack, author, type: 'full', quality: 70 })
    const out = await stk.toBuffer()

    await wafproject.sendMessage(m.chat, { sticker: out }, { quote: m })
  } catch (e) {
    console.log('STICKERPACK ERROR:', e?.message || e)
    // kirim gambar error
    try {
      await wafproject.sendMessage(m.chat, { image: { url: errorImg }, caption: '🚩 Gagal mengambil sticker.' }, { quote: m })
    } catch {
      // fallback kalau image gagal
      await m.reply('🚩 Gagal mengambil sticker.')
    }
  }
}

handler.help = [
  'dinokuning',
  'sdino',
  'patrick',
  'spatrick',
  'spongebob',
  'sspongebob',
  'doge',
  'sdoge',
  'manusialidi',
  'smanusialidi',
]

handler.category = ['sticker']
handler.command = Object.keys(PACKS)

handler.limit = true
handler.premium = false
handler.register = true

module.exports = handler
