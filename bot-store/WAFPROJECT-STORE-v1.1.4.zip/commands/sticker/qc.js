////////////////////////////
/* 🚀 WAF PROJECT - QC (Quoted Chat → Sticker)
   Cmd : .qc
   Revisi:
   - .qc saja → tampilkan cara pakai
   - Pakai global.packname & global.author
*/
////////////////////////////

const axios = require('axios')
const { Sticker } = require('../../lib/sticker-formatter')

const colorPalette = {
  1: '1C2526',
  2: 'F5F6F5',
  3: 'D90429',
  4: '2BA84A',
  5: '2F97C1',
  6: 'F8E9A1',
  7: '00C4B4',
  8: 'C71585',
  9: 'F4A261',
  10: '7209B7',
  11: 'FFFFFF',
  12: '000000'
}

function parseTextAndColor(input = '', fallback = '') {
  let text = input || fallback || ''
  let color = 1

  if (input) {
    const parts = input.trim().split(/\s+/)
    const last = parts[parts.length - 1]
    if (/^\d+$/.test(last) && colorPalette[last]) {
      color = Number(last)
      text = parts.slice(0, -1).join(' ')
    }
  }

  return { text: String(text).trim(), color }
}

async function createSticker(buffer) {
  return new Sticker(buffer, {
    type: 'full',
    pack: global.packname || 'WAF PROJECT',
    author: global.author || 'Bot',
    quality: 60
  }).toBuffer()
}

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  // =========================
  // ❗ JIKA .qc SAJA
  // =========================
  if (!text && !m.quoted) {
    return m.reply(
      `✨ *STICKER QUOTED CHAT (.qc)*

📝 *Cara pakai:*
• ${usedPrefix + command} halo dunia
• ${usedPrefix + command} halo dunia 5
• Reply pesan lalu ketik ${usedPrefix + command}
• Reply pesan lalu ${usedPrefix + command} 3

🎨 *Pilihan warna (1–12):*
1 abu tua 🌑
2 abu muda ☁️
3 merah 🔥
4 hijau 🌿
5 biru 🌊
6 kuning 🌼
7 toska 🐬
8 ungu 💜
9 jingga 🏜️
10 ungu tua 🌌
11 putih ❄️
12 hitam ⚫`
    )
  }

  const q = m.quoted ? m.quoted : m
  const fallbackText = q.text || q.caption || ''
  const { text: quoteText, color } = parseTextAndColor(text, fallbackText)

  if (!quoteText) {
    return m.reply('❌ Tidak ada teks yang bisa dijadikan sticker.')
  }

  await wafproject.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  try {
    const target = q.sender || m.sender
    let pp = await wafproject.profilePictureUrl(target, 'image').catch(
      () => 'https://telegra.ph/file/320b066dc81928b782c7b.png'
    )

    const name =
      q.name ||
      q.pushName ||
      m.name ||
      m.pushName ||
      'User'

    const payload = {
      type: 'quote',
      format: 'png',
      backgroundColor: `#${colorPalette[color]}`,
      width: 512,
      height: 768,
      scale: 2,
      messages: [
        {
          entities: [],
          avatar: true,
          from: {
            id: 1,
            name,
            photo: { url: pp }
          },
          text: quoteText,
          replyMessage: {}
        }
      ]
    }

    const res = await axios.post(
      'https://qc.botcahx.eu.org/generate',
      payload,
      {
        headers: { 'Content-Type': 'application/json' },
        timeout: 45000
      }
    )

    const buffer = Buffer.from(res.data.result.image, 'base64')
    const sticker = await createSticker(buffer)

    await wafproject.sendMessage(m.chat, { sticker }, { quote: m })
    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('QC ERROR:', e)
    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
    m.reply('❌ Gagal membuat QC sticker.')
  }
}

handler.help = ['qc <teks> [warna]']
handler.category = ['sticker']
handler.command = /^(qc|quotely)$/i
handler.register = true
handler.limit = true

module.exports = handler