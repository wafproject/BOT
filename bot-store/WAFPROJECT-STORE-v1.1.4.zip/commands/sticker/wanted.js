const { Sticker } = require('../../lib/sticker-formatter')
const sharp = require('sharp')
const axios = require('axios')

const TEMPLATE_URL = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/menntahhan.png'

// ukuran slot foto (sesuaikan kalau template berubah)
const FRAME_W = 1000
const FRAME_H = 1000

let handler = async (m, { wafproject, command, usedPrefix }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || q.mediaType || ''

    // ✅ validasi mime yang rapi
    if (!/^image\/(png|jpe?g|webp)$/i.test(mime)) {
      return m.reply(`📸 Reply gambar (PNG/JPEG/WebP) atau sticker dengan caption *${usedPrefix + command}* untuk membuat stiker wanted!`)
    }

    await wafproject.sendMessage(m.chat, { react: { text: '🎯', key: m.key } })

    const media = await q.download()
    const templateRes = await axios.get(TEMPLATE_URL, { responseType: 'arraybuffer', timeout: 30000 })
    const templateBuffer = Buffer.from(templateRes.data)
    const templateMeta = await sharp(templateBuffer).metadata()
    const width = Number(templateMeta.width || 1000)
    const height = Number(templateMeta.height || 1000)

    const frameW = Math.min(FRAME_W, width)
    const frameH = Math.min(FRAME_H, height)
    const frameX = Math.max(0, Math.round((width - frameW) / 2))
    const frameY = Math.max(0, Math.round((height - frameH) / 2))

    const userLayer = await sharp(media, { animated: false, failOn: 'none' })
      .rotate()
      .resize(frameW, frameH, { fit: 'cover' })
      .png()
      .toBuffer()

    // Pertahankan perilaku lama: template bawah -> foto -> template atas.
    const pngBuffer = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 0, g: 0, b: 0, alpha: 0 }
      }
    })
      .composite([
        { input: templateBuffer, left: 0, top: 0 },
        { input: userLayer, left: frameX, top: frameY },
        { input: templateBuffer, left: 0, top: 0 }
      ])
      .png()
      .toBuffer()

    // ✅ watermark pack/author
    const sticker = new Sticker(pngBuffer, {
      pack: global.packname || 'Wanted Sticker',
      author: global.author || 'WAFPROJECT',
      type: 'full',
      quality: 70
    })

    const out = await sticker.toBuffer()

    // ✅ kirim sticker cara native WAFPROJECT_4
    await wafproject.sendMessage(m.chat, { sticker: out }, { quote: m })
    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('WANTED ERROR:', e?.message || e)
    try {
      await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    } catch (_error) { console.error("[ERROR][commands/sticker/wanted.js]", _error?.message || _error) }
    return m.reply('❌ Gagal membuat stiker wanted. Pastikan gambar valid dan module canvas terpasang.')
  }
}

handler.help = ['wanted']
handler.category = ['sticker']
handler.command = /^wanted$/i
handler.limit = true
handler.register = true

module.exports = handler
