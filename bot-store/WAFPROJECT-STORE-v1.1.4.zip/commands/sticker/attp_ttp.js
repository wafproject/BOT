const sharp = require('sharp')
const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const { Sticker } = require('../../lib/sticker-formatter')

const { TEMP_DIR: TMP } = require('../../lib/project-paths')
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true })

function escapeXml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
}

function pickFontSize(text) {
  const len = String(text).length
  if (len > 20) return 40
  if (len > 10) return 60
  return 80
}

function wrapTextLines(text, fontSize, size) {
  const words = String(text).split(/\s+/).filter(Boolean)
  const maxChars = Math.max(4, Math.floor((size - 40) / Math.max(12, fontSize * 0.58)))
  const lines = []
  let line = ''
  for (const word of words) {
    const test = line ? `${line} ${word}` : word
    if (test.length > maxChars && line) {
      lines.push(line)
      line = word
    } else {
      line = test
    }
  }
  if (line) lines.push(line)
  return lines.length ? lines : ['']
}

async function renderTextPng(text, color, size = 400) {
  const fontSize = pickFontSize(text)
  const lines = wrapTextLines(text, fontSize, size)
  const lineHeight = Math.round(fontSize * 1.08)
  const total = lines.length * lineHeight
  const firstY = Math.round((size - total) / 2 + fontSize)
  const tspans = lines.map((line, i) =>
    `<tspan x="50%" y="${firstY + i * lineHeight}">${escapeXml(line)}</tspan>`
  ).join('')

  const svg = `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="none"/>
      <text x="50%" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700"
            font-size="${fontSize}" fill="${escapeXml(color)}">${tspans}</text>
    </svg>`

  return sharp(Buffer.from(svg)).png().toBuffer()
}

async function createFrame(text, color, outPath, size = 400) {
  fs.writeFileSync(outPath, await renderTextPng(text, color, size))
}

async function createTTP(text, size = 400) {
  return renderTextPng(text, 'white', size)
}

function runFfmpeg(args, tag = 'ffmpeg') {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] })
    let err = ''
    proc.stderr.on('data', d => (err += d.toString()))
    proc.on('error', e => reject(new Error(`${tag} error: ${e.message}\n${err}`)))
    proc.on('close', code => {
      if (code !== 0) return reject(new Error(`${tag} gagal: ${err}`))
      resolve()
    })
  })
}

async function createATTP(text, size = 400) {
  const ts = Date.now()
  const dir = path.join(TMP, `attp_${ts}`)
  fs.mkdirSync(dir, { recursive: true })

  const colors = ['red', 'green', 'blue', 'yellow', 'purple', 'orange']
  const framePattern = path.join(dir, 'frame_%d.png')
  const outputGif = path.join(dir, 'attp.gif')

  try {
    // bikin frame_0.png ... frame_5.png
    for (let i = 0; i < colors.length; i++) {
      const framePath = path.join(dir, `frame_${i}.png`)
      await createFrame(text, colors[i], framePath, size)
    }

    // ffmpeg: frame_%d.png => gif
    // NB: mulai dari 0, jadi pakai -start_number 0
    const args = [
      '-y',
      '-framerate', '10',
      '-start_number', '0',
      '-i', path.join(dir, 'frame_%d.png'),
      '-vf', `scale=${size}:${size}:flags=lanczos`,
      outputGif
    ]
    await runFfmpeg(args, 'attp-gif')

    const buff = fs.readFileSync(outputGif)
    return buff
  } finally {
    // cleanup folder
    try {
      const files = fs.readdirSync(dir)
      for (const f of files) {
        try { fs.unlinkSync(path.join(dir, f)) } catch (_error) { console.error("[ERROR][commands/sticker/attp_ttp.js]", _error?.message || _error) }
      }
      fs.rmdirSync(dir)
    } catch (_error) { console.error("[ERROR][commands/sticker/attp_ttp.js]", _error?.message || _error) }
  }
}

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Contoh: ${usedPrefix + command} halo`)

  try {
    let inputBuffer

    if (String(command).toLowerCase() === 'attp') {
      inputBuffer = await createATTP(text)
    } else {
      inputBuffer = await createTTP(text)
    }

    // bikin sticker + watermark
    const sticker = new Sticker(inputBuffer, {
      pack: global.packname || 'WAFPROJECT Sticker',
      author: global.author || 'WAFPROJECT',
      type: 'full',
      quality: 70
    })

    const out = await sticker.toBuffer()
    await wafproject.sendMessage(m.chat, { sticker: out }, { quote: m })
  } catch (e) {
    console.error('TTP/ATTP ERROR:', e?.message || e)
    return m.reply('Terjadi kesalahan saat membuat sticker.')
  }
}

handler.command = ['attp', 'ttp']
handler.category = ['sticker']
handler.help = ['attp <text>', 'ttp <text>']
handler.register = true
handler.limit = true

module.exports = handler
