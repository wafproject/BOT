const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const https = require('https')
const { Sticker } = require('../../lib/sticker-formatter')

const { TEMP_DIR: tmp } = require('../../lib/project-paths')
const overlayUrl = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/trigermentah.png'

if (!fs.existsSync(tmp)) fs.mkdirSync(tmp, { recursive: true })

function downloadImage(url, dest) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest)
    https.get(url, (response) => {
      if (response.statusCode !== 200) {
        file.close(() => {})
        return reject(new Error(`Gagal mengunduh overlay: ${response.statusCode}`))
      }
      response.pipe(file)
      file.on('finish', () => file.close(resolve))
    }).on('error', (err) => {
      fs.unlink(dest, () => reject(err))
    })
  })
}

function runFfmpeg(args, errTag = 'ffmpeg') {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] })
    let errorOutput = ''
    proc.stderr.on('data', (d) => (errorOutput += d.toString()))
    proc.on('error', (err) => reject(new Error(`${errTag} error: ${err.message}\n${errorOutput}`)))
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(`${errTag} gagal: ${errorOutput}`))
      resolve()
    })
  })
}

async function running(img, duration = 1.8, fps = 30) {
  const timestamp = Date.now()
  const inputImage = path.join(tmp, `${timestamp}.png`)
  const overlayImage = path.join(tmp, `${timestamp}-trigger.png`)
  const outputWebp = path.join(tmp, `${timestamp}.webp`)
  const frameList = []

  const cleanup = () => {
    const files = [inputImage, overlayImage, ...frameList, outputWebp]
    for (const f of files) {
      try { if (fs.existsSync(f)) fs.unlinkSync(f) } catch (_error) { console.error("[ERROR][commands/sticker/trigger.js]", _error?.message || _error) }
    }
  }

  try {
    fs.writeFileSync(inputImage, img)
    await downloadImage(overlayUrl, overlayImage)

    const frameCount = Math.floor(duration * fps)

    for (let i = 0; i < frameCount; i++) {
      const xShake = (i % 5 === 0 ? 8 : -8)
      const yShake = (i % 6 === 0 ? 8 : -8)
      const framePath = path.join(tmp, `frame-${timestamp}-${i}.png`)
      frameList.push(framePath)

      const filterComplex = `
        [0:v]scale=512:512[bg];
        [1:v]scale=512:512[ov];
        [bg][ov]overlay=0:0[merged];
        [merged]pad=520:520:4:4:color=0x00000000[padded];
        [padded]crop=512:512:${4 + xShake}:${4 + yShake}
      `.replace(/\s+/g, '')

      const args = [
        '-y',
        '-i', inputImage,
        '-i', overlayImage,
        '-filter_complex', filterComplex,
        '-frames:v', '1',
        framePath
      ]

      await runFfmpeg(args, `ffmpeg frame ${i}`)
    }

    const inputs = frameList.flatMap((f) => ['-i', f])
    const filter = `concat=n=${frameCount}:v=1:a=0,format=yuva420p`
    const argsWebp = [
      '-y',
      ...inputs,
      '-filter_complex', filter,
      '-r', String(fps),
      '-loop', '0',
      '-vcodec', 'libwebp',
      outputWebp
    ]

    await runFfmpeg(argsWebp, 'ffmpeg webp')

    if (!fs.existsSync(outputWebp)) throw new Error('Output webp tidak ditemukan')
    const result = fs.readFileSync(outputWebp)

    cleanup()
    return result
  } catch (e) {
    cleanup()
    throw e
  }
}

let handler = async (m, { wafproject }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''

  const supported = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp']
  if (!supported.includes(mime)) {
    return m.reply('✳️ Media tidak didukung! Balas gambar (PNG/JPG/JPEG/WEBP) dengan caption *trigger*.')
  }

  try {
    const img = await q.download()
    await m.reply('_⏳ Membuat efek trigger..._')

    // hasil dari ffmpeg: webp anim
    const webpBuffer = await running(img)

    // ✅ kasih watermark packname/author
    const sticker = new Sticker(webpBuffer, {
      pack: global.packname || 'WAFPROJECT Sticker',
      author: global.author || 'WAFPROJECT',
      type: 'full',
      quality: 70
    })

    const stickerBuffer = await sticker.toBuffer()

    await wafproject.sendMessage(m.chat, { sticker: stickerBuffer }, { quote: m })
  } catch (e) {
    console.error('TRIGGER ERROR:', e?.message || e)
    await m.reply('⚠️ Gagal membuat stiker trigger, pastikan media gambar statis (bukan video / gif).')
  }
}

handler.help = ['trigger']
handler.category = ['sticker']
handler.command = /^trigger$/i
handler.limit = true
handler.register = true

module.exports = handler
