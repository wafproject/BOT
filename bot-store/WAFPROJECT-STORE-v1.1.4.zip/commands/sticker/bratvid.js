/*
• Project : WAF PROJECT
• Fitur   : Bratvid (text → animated sticker)
• API     : https://brat.siputzx.my.id/gif?text=
• Note    : Convert GIF -> WEBP (animated) pakai ffmpeg + watermark pack/author
*/

const axios = require('axios')
const fs = require('fs')
const path = require('path')
const os = require('os')
const { exec } = require('child_process')
const { Sticker } = require('../../lib/sticker-formatter')

function run(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, (err, stdout, stderr) => {
      if (err) return reject(stderr || err.message || err)
      resolve(stdout || '')
    })
  })
}

async function gifToAnimatedWebp(gifBuffer) {
  const tmp = os.tmpdir()
  const base = `bratvid_${Date.now()}_${Math.random().toString(16).slice(2)}`
  const inFile = path.join(tmp, `${base}.gif`)
  const outFile = path.join(tmp, `${base}.webp`)

  fs.writeFileSync(inFile, gifBuffer)

  const cmd =
    `ffmpeg -y -i "${inFile}" ` +
    `-vf "fps=15,scale=512:512:force_original_aspect_ratio=decrease,` +
    `pad=512:512:-1:-1:color=white@0.0" ` +
    `-loop 0 -an -vsync 0 -vcodec libwebp -q:v 70 -preset default "${outFile}"`

  await run(cmd)

  const webp = fs.readFileSync(outFile)

  try { fs.unlinkSync(inFile) } catch (_error) { console.error("[ERROR][commands/sticker/bratvid.js]", _error?.message || _error) }
  try { fs.unlinkSync(outFile) } catch (_error) { console.error("[ERROR][commands/sticker/bratvid.js]", _error?.message || _error) }

  return webp
}

let handler = async (m, { wafproject, args, usedPrefix, command }) => {
  let text =
    (Array.isArray(args) && args.length ? args.join(' ') : '') ||
    m.quoted?.text ||
    m.quoted?.caption ||
    ''

  if (!text) {
    return wafproject.sendMessage(
      m.chat,
      {
        text:
          '✨ Masukin teks dong!\n' +
          'Contoh:\n' +
          `• ${usedPrefix || '.'}${command || 'bratvid'} halo sayang`
      },
      { quote: m }
    )
  }

  text = String(text).trim()
  if (text.length > 100) text = text.slice(0, 100)

  const url = `https://brat.siputzx.my.id/gif?text=${encodeURIComponent(text)}`

  try {
    await wafproject.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    // ambil gif
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 45000 })
    const gifBuffer = Buffer.from(res.data)

    // convert ke animated webp
    const webpBuffer = await gifToAnimatedWebp(gifBuffer)

    // === WATERMARK METADATA ===
    const packname = global.packname || 'WAF PROJECT'
    const author = global.author || 'Bot'

    const sticker = new Sticker(webpBuffer, {
      pack: packname,
      author: author,
      type: 'full',
      quality: 70
    })

    const finalSticker = await sticker.toBuffer()

    // kirim sticker animated
    await wafproject.sendMessage(
      m.chat,
      { sticker: finalSticker },
      { quote: m }
    )

    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('BRATVID ERROR:', e)

    try {
      await wafproject.sendMessage(
        m.chat,
        { video: { url }, caption: '⚠️ Sticker gagal, ini versi GIF/video dulu.', gifPlayback: true },
        { quote: m }
      )
    } catch (_error) { console.error("[ERROR][commands/sticker/bratvid.js]", _error?.message || _error) }

    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
  }
}

handler.help = ['bratvid <teks>']
handler.category = ['sticker']
handler.command = /^bratvid$/i
handler.limit = true
handler.register = true

module.exports = handler