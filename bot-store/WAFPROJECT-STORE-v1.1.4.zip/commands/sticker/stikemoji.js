const axios = require('axios')
const { Sticker } = require('../../lib/sticker-formatter')

const VENDORS = {
  stikapple: 'apple',
  stikgoogle: 'google',
  stiksamsung: 'samsung',
  stikmicrosoft: 'microsoft',
  stikwhatsapp: 'whatsapp',
  stiktwitter: 'twitter',
  stikfacebook: 'facebook',
  stikskype: 'skype',
  stikjoypixels: 'joypixels',
  stikopenmoji: 'openmoji',
  stikemojipedia: 'emojipedia',
  stiklg: 'lg',
  stikhtc: 'htc',
  stikmozilla: 'mozilla',
  stiksoftbank: 'softbank',
  stikdocomo: 'docomo',
  stikkddi: 'kddi',
}

async function replyText(m, wafproject, text) {
  // base ini biasanya punya m.reply
  if (typeof m.reply === 'function') return m.reply(String(text))
  // fallback kalau suatu saat m.reply tidak ada
  return wafproject.sendMessage(m.chat, { text: String(text) }, { quote: m })
}

let handler = async (m, { wafproject, command, text, usedPrefix }) => {
  if (!text) {
  return replyText(m, wafproject, `*Contoh:* ${usedPrefix + command} 🗿`)
}

  await replyText(m, wafproject, global.wait || '⏳ Tunggu sebentar...')

  try {
    const vendor = VENDORS[String(command || '').toLowerCase()]
    if (!vendor) throw 'Vendor tidak dikenal.'

    const base = global.apibtc || 'https://api.botcahx.eu.org'
    const apikey = global.btc
    if (!apikey) throw 'APIKEY belum diset (global.btc).'

    const url =
      `${base}/api/emoji/${vendor}` +
      `?emoji=${encodeURIComponent(text)}` +
      `&apikey=${encodeURIComponent(apikey)}`

    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 45000 })
    const imgBuf = Buffer.from(res.data)

    const pack = global.packname || 'Sticker Bot'
    const author = global.author || 'Bot'
    const stk = new Sticker(imgBuf, { pack, author, type: 'full', quality: 70 })
    const stickerBuffer = await stk.toBuffer()

    await wafproject.sendMessage(m.chat, { sticker: stickerBuffer }, { quote: m })
  } catch (e) {
    console.log('STIKEMOJI ERROR:', e?.message || e)
    throw '*🚩 Stiker tidak di temukan!*'
  }
}

handler.help = Object.keys(VENDORS).map(v => `${v} <emoji>`)
handler.category = ['sticker']
handler.command = Object.keys(VENDORS)

handler.limit = true
handler.premium = false
handler.register = true

module.exports = handler
