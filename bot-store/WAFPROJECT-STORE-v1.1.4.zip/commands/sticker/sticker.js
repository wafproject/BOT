////////////////////////////
/* WAF PROJECT - STICKER (FIX CAPTION)
   - Reply / Kirim gambar + caption "s" / URL
   - Packname: global.packname
   - Author  : global.author
   - Download fallback: Zapo media adapter
*/
////////////////////////////

const axios = require('axios')
const fs = require('fs')
const path = require('path')
const os = require('os')
const { exec } = require('child_process')
const { Sticker } = require('../../lib/sticker-formatter')
const { downloadMediaMessage } = require('../../lib/zapo-adapter.js')

function run(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, (err, stdout, stderr) => {
      if (err) return reject(stderr || err.message || err)
      resolve(stdout || '')
    })
  })
}

function reactSafe(wafproject, m, emoji) {
  try {
    wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }).catch(() => {})
  } catch (_error) { console.error("[ERROR][commands/sticker/sticker.js]", _error?.message || _error) }
}

function isUrl(text) {
  return /https?:\/\/.+\.(jpg|jpeg|png|webp|gif|mp4)/i.test(String(text || ''))
}

// unwrap viewOnce / ephemeral biar ketemu imageMessage/videoMessage
function unwrapMessage(msg) {
  let m = msg
  for (let i = 0; i < 5; i++) {
    if (!m || typeof m !== 'object') break
    if (m.viewOnceMessage?.message) m = m.viewOnceMessage.message
    else if (m.viewOnceMessageV2?.message) m = m.viewOnceMessageV2.message
    else if (m.ephemeralMessage?.message) m = m.ephemeralMessage.message
    else if (m.documentWithCaptionMessage?.message) m = m.documentWithCaptionMessage.message
    else break
  }
  return m
}

function detectType(messageObj) {
  const mm = unwrapMessage(messageObj || {})
  if (mm.imageMessage) return 'image'
  if (mm.videoMessage) return 'video'
  if (mm.stickerMessage) return 'webp'
  return ''
}

async function toWebp(buffer, isVideo = false) {
  const tmp = os.tmpdir()
  const base = `stk_${Date.now()}_${Math.random().toString(16).slice(2)}`
  const input = path.join(tmp, `${base}.${isVideo ? 'mp4' : 'img'}`)
  const output = path.join(tmp, `${base}.webp`)

  fs.writeFileSync(input, buffer)

  const cmd =
    `ffmpeg -y -i "${input}" ` +
    (isVideo ? `-t 10 ` : ``) +
    `-vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:-1:-1:color=white@0.0" ` +
    `-vcodec libwebp -q:v 70 -an "${output}"`

  await run(cmd)

  const webp = fs.readFileSync(output)
  try { fs.unlinkSync(input) } catch (_error) { console.error("[ERROR][commands/sticker/sticker.js]", _error?.message || _error) }
  try { fs.unlinkSync(output) } catch (_error) { console.error("[ERROR][commands/sticker/sticker.js]", _error?.message || _error) }

  return webp
}

// downloader paling aman untuk base kamu
async function downloadAny(wafproject, msgContainer) {
  // 1) kalau ada .download (biasanya reply)
  try {
    if (typeof msgContainer?.download === 'function') {
      const b = await msgContainer.download()
      if (b) return b
    }
  } catch (_error) { console.error("[ERROR][commands/sticker/sticker.js]", _error?.message || _error) }

  // 2) fallback: Zapo downloadMediaMessage adapter
  try {
    // msgContainer harus punya .message (raw)
    const rawMsg = msgContainer?.message ? msgContainer : { message: msgContainer }
    const buff = await downloadMediaMessage(
      rawMsg,
      'buffer',
      {},
      { logger: console, reuploadRequest: wafproject.updateMediaMessage }
    )
    if (buff) return buff
  } catch (e) {
    console.error('downloadMediaMessage error:', e?.message || e)
  }

  return null
}

function pickContainer(m) {
  if (m?.quoted) return m.quoted
  return m
}

let handler = async (m, { wafproject, args, usedPrefix, command }) => {
  reactSafe(wafproject, m, '⏳')

  try {
    const packname = global.packname || 'Sticker Bot'
    const author = global.author || 'Bot'

    let stickerBuffer = null

    // URL mode
    if (args?.[0] && isUrl(args[0])) {
      const res = await axios.get(args[0], { responseType: 'arraybuffer', timeout: 45000 })
      const imgBuf = Buffer.from(res.data)
      const webp = await toWebp(imgBuf, false)
      const stk = new Sticker(webp, { pack: packname, author, type: 'full', quality: 70 })
      stickerBuffer = await stk.toBuffer()

      await wafproject.sendMessage(m.chat, { sticker: stickerBuffer }, { quote: m })
      reactSafe(wafproject, m, '✅')
      return
    }

    // Reply / Caption mode
    const container = pickContainer(m)
    const type = detectType(container?.message || m?.message || container?.msg || {})

    if (!type) {
      throw (
        `Reply gambar/video/sticker atau kirim gambar dengan caption.\n\n` +
        `Contoh:\n• reply gambar lalu ketik ${usedPrefix + command}\n` +
        `• kirim gambar + caption: ${usedPrefix + command}\n` +
        `• ${usedPrefix + command} https://.../gambar.jpg`
      )
    }

    const buf = await downloadAny(wafproject, container)
    if (!buf) throw 'Gagal download media.'

    if (type === 'webp') {
      // re-embed metadata biar pack/author tampil
      const stk = new Sticker(buf, { pack: packname, author, type: 'full', quality: 70 })
      stickerBuffer = await stk.toBuffer()
    } else {
      const webp = await toWebp(buf, type === 'video')
      const stk = new Sticker(webp, { pack: packname, author, type: 'full', quality: 70 })
      stickerBuffer = await stk.toBuffer()
    }

    await wafproject.sendMessage(m.chat, { sticker: stickerBuffer }, { quote: m })
    reactSafe(wafproject, m, '✅')
  } catch (e) {
    console.error('STICKER ERROR:', e)
    reactSafe(wafproject, m, '❌')
    m.reply(String(e?.message || e || 'Gagal membuat sticker.'))
  }
}

handler.help = ['st', 'sticker']
handler.category = ['sticker']

// CMD aktif: .st dan .sticker
handler.command = /^(st|sticker)$/i

handler.limit = true
handler.register = true

module.exports = handler