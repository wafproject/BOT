////////////////////////////
/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!
*/
////////////////////////////
// ✨ Plugin Sticker - smeme (FULL LOKAL / NO API) ✨
// Cara:
// 1) reply gambar/sticker lalu ketik: .smeme atas|bawah
// 2) atau: .smeme atas
// NOTE: butuh ffmpeg + font (dejavu) ada di ubuntu

const fs = require('fs')
const path = require('path')
const os = require('os')
const { exec } = require('child_process')

function run(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, (err, stdout, stderr) => {
      if (err) return reject(stderr || err.message || err)
      resolve(stdout)
    })
  })
}

// escape buat ffmpeg drawtext
function escDrawtext(s = '') {
  return String(s)
    .replace(/\\/g, '\\\\')
    .replace(/:/g, '\\:')
    .replace(/'/g, "\\'")
    .replace(/\n/g, ' ')
}

async function makeMemeToWebp(inputPath, topText, bottomText) {
  const tmp = os.tmpdir()
  const outFile = path.join(tmp, `smeme_${Date.now()}_${Math.random().toString(16).slice(2)}.webp`)

  // font default ubuntu
  const font = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

  // ✅ request kamu:
  const FONT_SIZE = 64      // huruf dibesarin
  const BORDER_W  = 3       // outline ditipisin

  const atas = escDrawtext(topText || '')
  const bawah = escDrawtext(bottomText || '')

  const topDraw =
    `drawtext=fontfile=${font}:text='${atas}':` +
    `x=(w-text_w)/2:y=18:fontsize=${FONT_SIZE}:` +
    `fontcolor=white:borderw=${BORDER_W}:bordercolor=black`

  // bottom draw hanya kalau ada teks bawah
  const botDraw =
    `drawtext=fontfile=${font}:text='${bawah}':` +
    `x=(w-text_w)/2:y=h-text_h-18:fontsize=${FONT_SIZE}:` +
    `fontcolor=white:borderw=${BORDER_W}:bordercolor=black`

  // base image -> 512x512 (sticker WA)
  let filters = [
    `scale=512:512:force_original_aspect_ratio=decrease`,
    `pad=512:512:-1:-1:color=white@0.0`,
    topDraw
  ]

  // ✅ kalau bawah kosong: jangan tempel apa-apa
  if (bawah && bawah.trim().length) filters.push(botDraw)

  const vf = filters.join(',')

  const cmd =
    `ffmpeg -y -i "${inputPath}" ` +
    `-vf "${vf}" ` +
    `-vcodec libwebp -lossless 0 -q:v 70 -preset default -an -vsync 0 "${outFile}"`

  await run(cmd)
  const webp = fs.readFileSync(outFile)
  try { fs.unlinkSync(outFile) } catch (_error) { console.error("[ERROR][commands/sticker/smeme.js]", _error?.message || _error) }
  return webp
}

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  // kalau cuma .smeme tanpa teks => kasih cara pakai
  if (!text) {
    return wafproject.sendMessage(
      m.chat,
      {
        text:
          '✨ *SMEME (meme sticker)*\n\n' +
          'Cara pakai:\n' +
          `• Reply gambar/sticker → ${usedPrefix + command} atas|bawah\n` +
          `• Reply gambar/sticker → ${usedPrefix + command} atas\n\n` +
          'Contoh:\n' +
          `• ${usedPrefix + command} halo|sayang\n` +
          `• ${usedPrefix + command} diam| (bawah kosong)\n` +
          `• ${usedPrefix + command} woy`
      },
      { quote: m }
    )
  }

  let [atas, bawah] = String(text).split('|')
  atas = (atas || '').trim()
  bawah = (bawah || '').trim()

  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || q.mediaType || ''
  if (!mime && q.mtype === 'stickerMessage') mime = 'image/webp'

  if (!mime) {
    return wafproject.sendMessage(
      m.chat,
      { text: `Reply gambar/sticker dulu, lalu ketik ${usedPrefix + command} atas|bawah` },
      { quote: m }
    )
  }

  // kalau atas kosong juga, kasih warning biar gak blank semua
  if (!atas) {
    return wafproject.sendMessage(
      m.chat,
      { text: `Teks atasnya kosong.\nContoh: ${usedPrefix + command} diam|kauu` },
      { quote: m }
    )
  }

  await wafproject.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  const tmp = os.tmpdir()
  const inBase = path.join(tmp, `smeme_in_${Date.now()}_${Math.random().toString(16).slice(2)}`)
  let ext = 'jpg'
  if (/png/.test(mime)) ext = 'png'
  else if (/webp/.test(mime)) ext = 'webp'
  else if (/gif/.test(mime)) ext = 'gif'
  else if (/jpe?g/.test(mime)) ext = 'jpg'

  const inputPath = `${inBase}.${ext}`

  try {
    const media = await q.download()
    if (!media) throw new Error('Gagal download media.')

    fs.writeFileSync(inputPath, media)

    // kalau sticker webp anim, ambil frame pertama biar aman
    let finalInput = inputPath
    if (/webp/.test(ext)) {
      const firstFrame = `${inBase}_frame.png`
      await run(`ffmpeg -y -i "${inputPath}" -vframes 1 "${firstFrame}"`)
      finalInput = firstFrame
    }

    // ✅ bawah kosong = gak ditempel drawtext bawah
    const webpSticker = await makeMemeToWebp(finalInput, atas, bawah)

    await wafproject.sendMessage(m.chat, { sticker: webpSticker }, { quote: m })
    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('SMEME LOCAL ERROR:', e)
    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
    await m.reply(`❌ Error: ${e.message || e}`)
  } finally {
    // bersihin file yg dibuat plugin ini aja
    try {
      const files = fs.readdirSync(tmp)
      for (const f of files) {
        if (f.startsWith('smeme_in_') || f.startsWith('smeme_')) {
          try { fs.unlinkSync(path.join(tmp, f)) } catch (_error) { console.error("[ERROR][commands/sticker/smeme.js]", _error?.message || _error) }
        }
      }
    } catch (_error) { console.error("[ERROR][commands/sticker/smeme.js]", _error?.message || _error) }
  }
}

handler.help = ['smeme <atas|bawah>']
handler.category = ['sticker']
handler.command = /^(smeme|stickermeme|stikermeme)$/i
handler.limit = true
handler.register = true

module.exports = handler