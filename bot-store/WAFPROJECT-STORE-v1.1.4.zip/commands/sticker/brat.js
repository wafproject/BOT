/*
• Project : WAF PROJECT
• Fitur   : Brat (text → sticker)
• Mode    : ffmpeg + local sticker formatter (biar ADA watermark)
• API     : https://aqul-brat.hf.space?text=
*/

const axios = require('axios')
const fs = require('fs')
const path = require('path')
const os = require('os')
const { exec } = require('child_process')
const { Sticker } = require('../../lib/sticker-formatter')

function run(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, (err, stdout, stderr) => {
      if (err) return reject(stderr || err.message || err)
      resolve(stdout || '')
    })
  })
}

async function toWebpFromBuffer(inputBuffer) {
  const tmp = os.tmpdir()
  const base = `brat_${Date.now()}_${Math.random().toString(16).slice(2)}`
  const inFile = path.join(tmp, `${base}.png`)
  const outFile = path.join(tmp, `${base}.webp`)

  fs.writeFileSync(inFile, inputBuffer)

  const cmd =
    `ffmpeg -y -i "${inFile}" ` +
    `-vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:-1:-1:color=white@0.0" ` +
    `-vcodec libwebp -q:v 70 -an "${outFile}"`

  await run(cmd)

  const webp = fs.readFileSync(outFile)
  try { fs.unlinkSync(inFile) } catch (_error) { console.error("[ERROR][commands/sticker/brat.js]", _error?.message || _error) }
  try { fs.unlinkSync(outFile) } catch (_error) { console.error("[ERROR][commands/sticker/brat.js]", _error?.message || _error) }

  return webp
}

let handler = async (m, { wafproject, args, usedPrefix, command }) => {
  let text =
    (args && args.length ? args.join(' ') : '') ||
    m.quoted?.text ||
    m.quoted?.caption ||
    ''

  if (!text) {
    return wafproject.sendMessage(
      m.chat,
      {
        text:
          '✨ Masukin teks dong!\n' +
          'Contoh:\n' +
          `• ${usedPrefix || '.'}${command || 'brat'} palak bapak kau`
      },
      { quote: m }
    )
  }

  text = String(text).trim()
  if (text.length > 100) text = text.slice(0, 100)

  const url = `https://aqul-brat.hf.space?text=${encodeURIComponent(text)}`

  try {
    await wafproject.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    // ambil gambar dari API
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 45000 })
    const imgBuffer = Buffer.from(res.data)

    // convert ke webp
    const webpBuffer = await toWebpFromBuffer(imgBuffer)

    // === WATERMARK DI SINI ===
    const packname = global.packname || 'WAF PROJECT'
    const author = global.author || 'Bot'

    const sticker = new Sticker(webpBuffer, {
      pack: packname,
      author: author,
      type: 'full',
      quality: 70
    })

    const finalSticker = await sticker.toBuffer()

    await wafproject.sendMessage(
      m.chat,
      { sticker: finalSticker },
      { quote: m }
    )

    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('BRAT ERROR:', e)

    try {
      await wafproject.sendMessage(
        m.chat,
        { image: { url }, caption: '⚠️ Sticker gagal, ini versi gambarnya dulu.' },
        { quote: m }
      )
    } catch (_error) { console.error("[ERROR][commands/sticker/brat.js]", _error?.message || _error) }

    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
  }
}

handler.help = ['brat <teks>']
handler.category = ['sticker']
handler.command = /^brat$/i
handler.limit = true
handler.register = true

module.exports = handler