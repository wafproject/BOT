// commands/tools/infouser.js
// WhatsApp Profile Stalk (GLOBAL Anti-LID consumer)
// ✅ Mention asli (tap-able) via mentions:[jid] + teks @<nomor>
// ✅ Negara via awesome-phonenumber (jika tersedia)
// ✅ WA link fix
// ✅ Foto profil jika ada

let PhoneNumber = null
try {
  // dependency sudah ada di index.js kamu
  PhoneNumber = require("awesome-phonenumber")
} catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }

let handler = async (m, { wafproject, usedPrefix, command }) => {
  const text = getText(m)

  // kirim dulu biar responsif
  const sent = await wafproject.sendMessage(m.chat, { text: "Checking user..." }, { quote: m })

  const target = await pickTargetJid(wafproject, m, text)
  if (!target) return safeEditOrReply(wafproject, m, sent?.key, helpText(usedPrefix, command))

  const name = await safeGetName(wafproject, m, target)
  const status = await safeGetStatus(wafproject, target)

  const num = jidToNumber(target) // hanya jika jid memang angka@
  const waLink = num ? `https://wa.me/${num}` : "-"
  const mentionText = num ? `@${num}` : "-"

  const { countryName, countryFlag } = detectCountry(num)

  const caption =
    `🌍 *WhatsApp Profile Stalk* 🌍\n\n` +
    `👤 *Nama:* ${name || "Tanpa Nama"}\n` +
    `📍 *Negara:* ${countryName}${countryFlag ? " " + countryFlag : ""}\n` +
    `🔗 *WA Link:* ${waLink}\n` +
    `🏷️ *Mention:* ${mentionText}\n` +
    `📝 *Status:* ${status ? status : "❌ Tidak ada status"}\n` +
    `📅 *Tanggal Status:* ❓ Unknown\n` +
    `🌐 *Kehadiran:* unknown\n\n` +
    `📱 *Akun WhatsApp Standar* 📱`

  // coba foto profil
  const pfp = await safeGetProfilePictureUrl(wafproject, target)

  // kirim hasil (pakai mentions agar mention asli)
  const msgOpts = { quoted: m }
  const content = pfp
    ? { image: { url: pfp }, caption, mentions: num ? [normJid(target)] : [] }
    : { text: caption, mentions: num ? [normJid(target)] : [] }

  try {
    await wafproject.sendMessage(m.chat, content, msgOpts)
    // optional edit "Checking..."
    try { await wafproject.sendMessage(m.chat, { text: "✅ Done.", edit: sent?.key }) } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
    return
  } catch {
    // fallback: edit / reply teks
    return safeEditOrReply(wafproject, m, sent?.key, caption)
  }
}

handler.help = ["wastalk"]
handler.category = ["tools"]
handler.command = /^wastalk$/i
handler.limit = false
handler.register = false

module.exports = handler

// =================== HELPERS (GLOBAL ANTI-LID CONSUMER) ===================

function normJid(id) {
  try {
    if (typeof global.normalizeJid === "function") return String(global.normalizeJid(id) || "")
    if (typeof global.jidNormalized === "function") return String(global.jidNormalized(id) || "")
    if (global.JidNormalizer && typeof global.JidNormalizer.normalize === "function") {
      return String(global.JidNormalizer.normalize(id) || "")
    }
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  return String(id || "").trim()
}

function getText(m) {
  return String(
    m?.text ??
      m?.body ??
      m?.message?.conversation ??
      m?.message?.extendedTextMessage?.text ??
      ""
  ).trim()
}

function getSenderNorm(m) {
  return normJid(m?.sender || m?.participant || m?.key?.participant || "")
}

function getMentionsNorm(m) {
  const out = []
  try {
    if (Array.isArray(m?.mentionedJid)) out.push(...m.mentionedJid)

    const ctx =
      m?.message?.extendedTextMessage?.contextInfo ||
      m?.message?.imageMessage?.contextInfo ||
      m?.message?.videoMessage?.contextInfo ||
      m?.message?.documentMessage?.contextInfo ||
      null

    if (Array.isArray(ctx?.mentionedJid)) out.push(...ctx.mentionedJid)
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  return [...new Set(out.map((x) => normJid(x)).filter(Boolean))]
}

function getQuotedSenderNorm(m) {
  try {
    const q1 = m?.quoted?.sender || m?.quoted?.participant
    if (q1) return normJid(q1)

    const ctx =
      m?.message?.extendedTextMessage?.contextInfo ||
      m?.message?.imageMessage?.contextInfo ||
      m?.message?.videoMessage?.contextInfo ||
      m?.message?.documentMessage?.contextInfo ||
      null

    const qp = ctx?.participant
    if (qp) return normJid(qp)
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  return ""
}

function parseNumberArgToJid(text) {
  try {
    const cleaned = String(text || "")
      .replace(/^\s*\.?(infouser|userinfo|whois|stalk)\b/i, "")
      .trim()
    if (!cleaned) return ""

    const tokens = cleaned.split(/\s+/).filter(Boolean)
    for (const t of tokens) {
      const digits = (String(t).match(/\d+/g) || []).join("")
      if (digits.length >= 5) return normJid(`${digits}@s.whatsapp.net`)
    }
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  return ""
}

async function pickTargetJid(wafproject, m, text) {
  const q = getQuotedSenderNorm(m)
  if (q) return q

  const mentions = getMentionsNorm(m)
  if (mentions.length) return mentions[0]

  const byNum = parseNumberArgToJid(text)
  if (byNum) return byNum

  const s = getSenderNorm(m)
  return s || ""
}

// hanya ambil nomor kalau jid memang angka@ (TIDAK parsing dari lid)
function jidToNumber(jid) {
  const s = String(jid || "")
  const mm = s.match(/^(\d{5,20})@/)
  return mm ? mm[1] : ""
}

async function safeGetName(wafproject, m, jid) {
  const j = normJid(jid)

  // sender sendiri → sama seperti menu
  try {
    const sender = getSenderNorm(m)
    if (sender && j && sender === j) {
      const n = m?.name || m?.pushName
      if (n) return String(n)
    }
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }

  // cara index.js: global.store.contacts[j].name
  try {
    const c = global?.store?.contacts?.[j]
    const n = c?.name
    if (n) return String(n)
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }

  // fallback wafproject.contacts
  try {
    const c2 = wafproject?.contacts?.[j]
    const n2 = c2?.name || c2?.notify || c2?.verifiedName || c2?.pushname
    if (n2) return String(n2)
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }

  const num = jidToNumber(j)
  return num ? `+${num}` : ""
}

async function safeGetStatus(wafproject, jid) {
  try {
    if (typeof wafproject.fetchStatus === "function") {
      const r = await wafproject.fetchStatus(jid).catch(() => null)
      const st = r?.status
      if (typeof st === "string" && st.trim()) return st.trim()
    }
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  return ""
}

async function safeGetProfilePictureUrl(wafproject, jid) {
  try {
    if (typeof wafproject.profilePictureUrl === "function") {
      const url = await wafproject.profilePictureUrl(jid, "image").catch(() => null)
      if (typeof url === "string" && url) return url
    }
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  return ""
}

// Negara: best-effort dari awesome-phonenumber + Intl.DisplayNames
function detectCountry(num) {
  if (!num) return { countryName: "Unknown", countryFlag: "" }

  // helper: flag dari ISO2
  const flagFromIso2 = (iso2) => {
    try {
      const cc = String(iso2 || "").toUpperCase()
      if (!/^[A-Z]{2}$/.test(cc)) return ""
      const A = 0x1F1E6
      const codePoints = [...cc].map((c) => A + (c.charCodeAt(0) - 65))
      return String.fromCodePoint(...codePoints)
    } catch {
      return ""
    }
  }

  // default (kalau PhoneNumber ga ada)
  if (!PhoneNumber) {
    if (String(num).startsWith("62")) return { countryName: "INDONESIA", countryFlag: "🇮🇩" }
    return { countryName: "Unknown", countryFlag: "" }
  }

  try {
    const pn = new PhoneNumber(`+${num}`)
    const region = pn.getRegionCode ? pn.getRegionCode() : ""
    const iso2 = String(region || "").toUpperCase()

    let countryName = "Unknown"
    try {
      // bahasa Indonesia kalau ada
      const dn = new Intl.DisplayNames(["id"], { type: "region" })
      const nm = dn.of(iso2)
      if (nm) countryName = String(nm).toUpperCase()
    } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }

    if (countryName === "Unknown" && iso2 === "ID") countryName = "INDONESIA"

    return { countryName, countryFlag: flagFromIso2(iso2) }
  } catch {
    if (String(num).startsWith("62")) return { countryName: "INDONESIA", countryFlag: "🇮🇩" }
    return { countryName: "Unknown", countryFlag: "" }
  }
}

async function safeEditOrReply(wafproject, m, editKey, text) {
  try {
    if (editKey) {
      await wafproject.sendMessage(m.chat, { text, edit: editKey })
      return
    }
  } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  try {
    await wafproject.sendMessage(m.chat, { text }, { quote: m })
  } catch {
    try { m.reply?.(text) } catch (_error) { console.error("[ERROR][commands/tools/infouser.js]", _error?.message || _error) }
  }
}

function helpText(usedPrefix, command) {
  const p = usedPrefix || "."
  const c = command || "infouser"
  return (
    `Cara pakai:\n` +
    `• ${p}${c} @tag\n` +
    `• reply pesan lalu ${p}${c}\n` +
    `• ${p}${c} 628xxxx`
  )
}