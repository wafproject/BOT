let handler = async (m, { wafproject, usedPrefix, command }) => {
  const start = Date.now()

  // kirim dulu biar dapat "round-trip" realtime
  const sent = await wafproject.sendMessage(m.chat, { text: 'Testing...' }, { quote: m })

  const end = Date.now()
  const ms = end - start

  // ambil uptime process (kalau ada)
  const uptimeSec = process.uptime ? process.uptime() : 0
  const uptime = formatUptime(uptimeSec)

  // edit pesan kalau base kamu support (sebagian base support wafproject.sendMessage dengan edit)
  // kalau tidak support, fallback kirim pesan baru
  try {
    await wafproject.sendMessage(m.chat, {
      text: `✅ *Pong!*\n⏱️ *Respon:* ${ms} ms\n🕒 *Uptime:* ${uptime}`,
      edit: sent.key
    })
  } catch {
    await wafproject.sendMessage(m.chat, { text: `✅ *Pong!*\n⏱️ *Respon:* ${ms} ms\n🕒 *Uptime:* ${uptime}` }, { quote: m })
  }
}

handler.help = ['ping', 'tes', 'test']
handler.category = ['tools']
handler.command = /^(ping|tes|test)$/i
handler.limit = false
handler.register = false

module.exports = handler

function formatUptime(seconds) {
  seconds = Math.floor(seconds)
  const d = Math.floor(seconds / (3600 * 24))
  seconds %= 3600 * 24
  const h = Math.floor(seconds / 3600)
  seconds %= 3600
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return (d ? `${d}d ` : '') + `${h}h ${m}m ${s}s`
}