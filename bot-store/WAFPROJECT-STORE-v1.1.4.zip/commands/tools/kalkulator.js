// ✨ Plugin kalkulator ✨

/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒

WAF PROJECT — BUAT BOT SEMAKIN KEREN ✨
BUTUH PANEL UNTUK RUN BOT? HUBUNGI: 0877-3128-2876 📞
JASA PEMBUATAN BOT WHATSAPP 🤖
========================
*/

let handler = async (m, { wafproject, usedPrefix, command, text }) => {
  const id = m.chat

  // anti-cheat / anti spam per chat (biar gak abuse)
  wafproject.math = wafproject.math ? wafproject.math : {}
  if (id in wafproject.math) {
    try { clearTimeout(wafproject.math[id][3]) } catch (_error) { console.error("[ERROR][commands/tools/kalkulator.js]", _error?.message || _error) }
    delete wafproject.math[id]
    return m.reply('Hmmm...ngecheat?')
  }

  // input
  const input = String(text || '').trim()
  if (!input) return m.reply(`Contoh: ${usedPrefix + command} 4+7`)

  // sanitize: hanya angka + operator yang diizinkan
  let val = input
    .replace(/[^0-9\-\/+*×÷πEe()piPI.]/g, '') // allow titik (desimal)
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/π|pi/gi, 'Math.PI')
    .replace(/e/gi, 'Math.E')
    .replace(/\/+/g, '/')
    .replace(/\++/g, '+')
    .replace(/-+/g, '-')

  // format tampilan hasil
  const format = val
    .replace(/Math\.PI/g, 'π')
    .replace(/Math\.E/g, 'e')
    .replace(/\//g, '÷')
    .replace(/\*/g, '×')

  try {
    // blok input aneh: harus ada angka minimal
    if (!/\d/.test(val)) throw new Error('NO_NUMBER')

    // evaluasi aman-ish (karena sudah disaring ketat)
    const result = Function('"use strict"; return (' + val + ')')()

    // handle NaN / Infinity
    if (typeof result !== 'number' || !isFinite(result)) {
      return m.reply('Hasil tidak valid (NaN/Infinity). Coba input lain.')
    }

    return m.reply(`*${format}* = _${result}_`)
  } catch (e) {
    return m.reply(
      `Format salah.\nHanya mendukung: 0-9 dan simbol -, +, *, /, ×, ÷, π, e, (, ), .\n\nContoh: ${usedPrefix + command} (10+5)×2`
    )
  }
}

handler.help = ['kalkulator <soal>']
handler.category = ['tools']
handler.command = /^(k|calc(ulat(e|or))?|kalk(ulator)?)$/i
handler.limit = false
handler.register = false

module.exports = handler