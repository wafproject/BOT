// commands/tools/idgc.js
// ✅ Show Group ID (JID) + tombol COPY (cta_copy)
// Command: .idgc

const { nativeFlowMessage, copyButton } = require('../../lib/zapo-message')

let handler = async function (m, { wafproject }) {
  const conn = wafproject

  // silent kalau bukan grup
  if (!m.isGroup) return

  const gcid = String(m.chat || '')
  const gname = (m?.metadata?.subject || 'Grup')
  const members =
    (m?.metadata?.participants && Array.isArray(m.metadata.participants))
      ? m.metadata.participants.length
      : null

  const text =
`🆔 *ID GRUP*
━━━━━━━━━━━━━━━━━━
• Nama   : ${gname}
• ID     : ${gcid}${members != null ? `\n• Member : ${members}` : ''}
━━━━━━━━━━━━━━━━━━
`

  const buttonMessage = nativeFlowMessage({
    text,
    footer: "Klik tombol di bawah untuk menyalin ID grup.",
    buttons: [copyButton("📋 Salin ID GC", gcid, gcid)]
  })

  return await conn.sendMessage(m.chat, buttonMessage, { quote: m })
}

handler.help = ['idgc']
handler.category = ['tools']
handler.command = /^(idgc)$/i
handler.register = false

module.exports = handler