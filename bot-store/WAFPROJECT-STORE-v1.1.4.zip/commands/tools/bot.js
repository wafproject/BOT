/**
========================
🚀 WAF PROJECT - BOT INFO
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

function formatRuntime(sec = 0) {
  sec = Math.floor(sec)
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = sec % 60

  const out = []
  if (h) out.push(`${h} jam`)
  if (m) out.push(`${m} menit`)
  out.push(`${s} detik`)
  return out.join(' ')
}

async function sendBotInfo(m, wafproject) {
  const botName =
    global.namebot ||
    global.namabot ||
    wafproject.user?.name ||
    'WAF BOT'

  const ownerNumber =
    global.nomorown ||
    global.nomorowner ||
    '628xxxxxxxxxx'

  const runtime = formatRuntime(process.uptime())

  const text = `
🤖✨ *HALO KAK!* ✨🤖

Aku *${botName}* 🌸  

⏱️ Saat ini aku sudah *aktif selama*  
🕒 *${runtime}*

💬 Aku siap membantu kalian  
di grup ini ✨  

Kalau ada:
• ❌ *Error/Bug*
• ⚠️ *Kendala*
• 🚀 *Request fitur*
• 🛒 *Mau sewa bot*

Silakan hubungi *Owner* aku ya 👑  

📞 *Owner:* wa.me/${ownerNumber}

Terima kasih sudah pakai aku 💖  
Semoga harimu menyenangkan 🌈
`.trim()

  await wafproject.sendMessage(m.chat, { text }, { quote: m })
}

const handler = async () => {}

handler.all = async (m, { wafproject }) => {
  const text = (m.text || '').trim().toLowerCase()

  // ✅ trigger TANPA prefix
  if (text === 'bot') {
    return sendBotInfo(m, wafproject)
  }
}

handler.help = ['bot']
handler.category = ['tools']
handler.limit = false
handler.register = false

module.exports = handler