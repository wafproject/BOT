// plugins/tools - tourl.js (CJS)
// Upload media -> URL + tombol Copy URL (tanpa GoFile)

const axios = require('axios')
const FormData = require('form-data')
const { fromBuffer } = require('../../lib/file-type.js')
const { downloadContentFromMessage } = require('../../lib/zapo-adapter.js')
const crypto = require('crypto')
const { nativeFlowMessage } = require('../../lib/zapo-message')

// limit size
const MAX_SIZE = 100 * 1024 * 1024 // 100MB

// ===== Helpers =====
function unwrapMessage(obj) {
  let msg = obj?.message || obj?.msg?.message || obj?.msg || obj
  if (!msg) return { type: null, node: null }

  if (msg?.message) msg = msg.message
  if (msg.ephemeralMessage?.message) msg = msg.ephemeralMessage.message
  if (msg.viewOnceMessageV2?.message) msg = msg.viewOnceMessageV2.message
  if (msg.viewOnceMessage?.message) msg = msg.viewOnceMessage.message

  const type = msg && Object.keys(msg)[0]
  const node = type ? msg[type] : null
  return { type, node }
}

function toDlType(type) {
  if (type === 'imageMessage') return 'image'
  if (type === 'videoMessage') return 'video'
  if (type === 'audioMessage') return 'audio'
  if (type === 'documentMessage') return 'document'
  if (type === 'stickerMessage') return 'sticker'
  return null
}

async function downloadMediaAny(q) {
  // 1) kalau base punya q.download()
  try {
    if (typeof q?.download === 'function') {
      const b = await q.download()
      if (b) return b
    }
  } catch (_error) { console.error("[ERROR][commands/tools/tourl.js]", _error?.message || _error) }

  // 2) stream media Zapo (buat kasus send+caption)
  const { type, node } = unwrapMessage(q)
  const dlType = toDlType(type)
  if (!node || !dlType) return null

  const stream = await downloadContentFromMessage(node, dlType)
  let buf = Buffer.alloc(0)
  for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
  return buf.length ? buf : null
}

async function detectFile(buffer, fallbackMime = '') {
  const ft = await fromBuffer(buffer).catch(() => null)
  let ext = ft?.ext
  let mime = ft?.mime || fallbackMime || 'application/octet-stream'
  if (!ext && mime && mime.includes('/')) {
    ext = mime.split('/')[1]
    if (ext && (ext.length > 8 || ext.includes('-'))) ext = 'bin'
  }
  if (!ext) ext = 'bin'
  return { ext, mime }
}

function asBuffer(input) {
  if (Buffer.isBuffer(input)) return input
  if (input instanceof Uint8Array) return Buffer.from(input)
  if (input instanceof ArrayBuffer) return Buffer.from(new Uint8Array(input))
  if (typeof input === 'object' && input?.data) return Buffer.from(input.data)
  throw new Error('Invalid buffer input')
}

function safeId(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 24)
}

function shortErr(e) {
  const msg = e?.response?.data
    ? (typeof e.response.data === 'string' ? e.response.data : JSON.stringify(e.response.data))
    : (e?.message || String(e))
  return String(msg).replace(/\s+/g, ' ').slice(0, 120)
}

// ===== Uploaders =====
async function uploadYupra(buffer, filename) {
  buffer = asBuffer(buffer)
  const form = new FormData()
  form.append('files', buffer, { filename })

  const res = await axios.post('https://cdn.yupra.my.id/upload', form, {
    headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0 (Android 10)' },
    timeout: 120_000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  })

  const data = res.data
  if (!data?.success || !data?.files?.[0]?.url) throw new Error('Yupra upload failed')
  return `https://cdn.yupra.my.id${data.files[0].url}`
}

async function uploadCatbox(buffer) {
  buffer = asBuffer(buffer)
  const ft = await fromBuffer(buffer).catch(() => null)
  const ext = ft?.ext || 'bin'

  const form = new FormData()
  form.append('reqtype', 'fileupload')
  form.append('fileToUpload', buffer, `file.${ext}`)

  const res = await axios.post('https://catbox.moe/user/api.php', form, {
    headers: { ...form.getHeaders() },
    timeout: 120_000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  })

  const url = String(res.data || '').trim()
  if (!/^https?:\/\//i.test(url)) throw new Error('Catbox upload failed')
  return url
}

async function uploadQuax(buffer) {
  buffer = asBuffer(buffer)
  const ft = await fromBuffer(buffer).catch(() => null)
  const ext = ft?.ext || 'bin'
  const mime = ft?.mime || 'application/octet-stream'

  const form = new FormData()
  form.append('files[]', buffer, { filename: `tmp.${ext}`, contentType: mime })
  form.append('expiry', '-1')

  const { data } = await axios.post('https://qu.ax/upload.php', form, {
    headers: { ...form.getHeaders() },
    timeout: 120_000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  })

  const url = data?.files?.[0]?.url
  if (!url) throw new Error('Qu.ax upload failed')
  return url
}

async function uploadPomf2(buffer, ext = 'bin') {
  buffer = asBuffer(buffer)
  const form = new FormData()
  form.append('files[]', buffer, `${crypto.randomBytes(6).toString('hex')}.${ext}`)

  const res = await axios.post('https://pomf2.lain.la/upload.php', form, {
    headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0 (Android 10)' },
    timeout: 120_000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  })

  const data = res.data
  if (!data?.success || !data?.files?.[0]?.url) throw new Error('Pomf2 upload failed')
  return data.files[0].url
}

// ===== Main handler =====
let handler = async (m, { wafproject, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m
  const mime = q.mimetype || q.msg?.mimetype || unwrapMessage(q).node?.mimetype || ''

  // tidak support text-only
  if (!mime || /text\/plain/i.test(mime)) {
    return wafproject.sendMessage(
      m.chat,
      { text: `Reply/kirim *media* dengan perintah:\n*${usedPrefix + command}*\n\n✅ Support: image/video/audio/document/sticker` },
      { quote: m }
    )
  }

  await wafproject.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {})

  try {
    const media = await downloadMediaAny(q)
    if (!media) throw new Error('Gagal download media dari WhatsApp.')
    if (media.length > MAX_SIZE) throw new Error('File terlalu besar (maks 100MB).')

    const { ext, mime: realMime } = await detectFile(media, mime)
    const fileName = `file-${Date.now()}.${ext}`

    const providers = [
      { name: 'Yupra', note: 'Tanpa expired', fn: () => uploadYupra(media, fileName) },
      { name: 'Catbox', note: 'Tanpa expired', fn: () => uploadCatbox(media) },
      { name: 'Qu.ax', note: 'Tanpa expired', fn: () => uploadQuax(media) },
      { name: 'Pomf2', note: 'Tanpa expired', fn: () => uploadPomf2(media, ext) }
    ]

    const results = await Promise.allSettled(providers.map(p => p.fn()))

    // susun teks + tombol hanya untuk yang sukses
    const header = [
      '▣────────────────···',
      `📦 *File*: ${fileName}`,
      `🧾 *Mime*: ${realMime}`,
      `📏 *Size*: ${(media.length / 1024 / 1024).toFixed(2)} MB`,
      '▣────────────────···\n'
    ]

    const blocks = []
    const buttons = []

    providers.forEach((p, i) => {
      const r = results[i]
      if (r.status === 'fulfilled' && r.value && /^https?:\/\//i.test(String(r.value))) {
        const url = String(r.value)
        blocks.push(`✅ *${p.name}* — ${p.note}\n${url}\n`)

        buttons.push({
          name: 'cta_copy',
          buttonParamsJson: JSON.stringify({
            display_text: `Copy ${p.name} URL`,
            id: `copy_${safeId(p.name)}`,
            copy_code: url
          })
        })
      } else {
        const err = r.status === 'rejected' ? shortErr(r.reason) : 'Unknown error'
        blocks.push(`❌ *${p.name}* — Gagal\n${err}\n`)
      }
    })

    const messageText = header.concat(blocks).concat(['▣────────────────···']).join('\n')

    // kalau tidak ada yang sukses, kirim teks biasa saja
    if (!buttons.length) {
      await wafproject.sendMessage(m.chat, { text: messageText }, { quote: m })
      await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
      return
    }

    // Kirim lewat adapter Zapo langsung; tidak bergantung pada generator legacy.
    await wafproject.sendMessage(
      m.chat,
      nativeFlowMessage({
        text: messageText,
        footer: 'Tombol hanya muncul untuk provider yang sukses ✅',
        buttons
      }),
      { quote: m }
    )
    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {})
  } catch (e) {
    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
    return wafproject.sendMessage(m.chat, { text: `❌ Gagal membuat link:\n${e?.message || String(e)}` }, { quote: m })
  }
}

handler.help = ['tourl (reply/kirim media)']
handler.category = ['tools']
handler.command = /^(tourl|to(url|link))$/i
handler.limit = false
handler.register = true

module.exports = handler