/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

// commands/owner/setppbot.js

const fs = require("fs")
const path = require("path")

function getMime(target) {
  return (
    target?.mimetype ||
    target?.msg?.mimetype ||
    target?.mediaType ||
    target?.msg?.mediaType ||
    ""
  )
}

function isImageMessage(target) {
  const mime = getMime(target)
  if (/image\/(jpe?g|png|webp)/i.test(mime)) return true

  return Boolean(
    target?.message?.imageMessage ||
    target?.msg?.imageMessage ||
    target?.imageMessage
  )
}

let handler = async (m, { wafproject, usedPrefix, command }) => {
  const conn = wafproject

  try {
    const q = m.quoted ? m.quoted : m

    const isQuotedImage = !!m.quoted && isImageMessage(m.quoted)
    const isSelfImage = isImageMessage(m)

    if (!isQuotedImage && !isSelfImage) {
      return conn.sendMessage(
        m.chat,
        {
          text:
`❌ Format salah.

Gunakan salah satu cara berikut:
- Kirim gambar dengan caption *${usedPrefix + command}*
- Reply gambar lalu ketik *${usedPrefix + command}*`
        },
        { quote: m }
      )
    }

    const media = await q.download()
    if (!media) {
      return conn.sendMessage(
        m.chat,
        { text: "❌ Gagal mengunduh gambar." },
        { quote: m }
      )
    }

    const { TEMP_DIR } = require('../../lib/project-paths')
    const dir = TEMP_DIR
    const filePath = path.join(dir, `setppbot_${Date.now()}.jpg`)

    fs.mkdirSync(dir, { recursive: true })
    fs.writeFileSync(filePath, media)

    const rawId =
      conn.user?.jid ||
      conn.user?.id ||
      conn.authState?.creds?.me?.id ||
      conn?.authState?.creds?.me?.jid

    const botJid = conn.decodeJid ? conn.decodeJid(rawId) : rawId

    if (!botJid) {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath)
      return conn.sendMessage(
        m.chat,
        { text: "❌ JID bot tidak ditemukan. Cek object conn.user pada base bot kamu." },
        { quote: m }
      )
    }

    await conn.updateProfilePicture(botJid, { url: filePath })

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath)
    }

    return conn.sendMessage(
      m.chat,
      { text: "✅ Foto profil bot berhasil diupdate." },
      { quote: m }
    )
  } catch (e) {
    console.error("setppbot error:", e)

    return wafproject.sendMessage(
      m.chat,
      {
        text: `❌ Gagal mengganti foto profil bot.\n${e.message || e}`
      },
      { quote: m }
    )
  }
}

handler.help = ["setppbot"]
handler.tags = ["owner"]
handler.category = "owner"
handler.command = /^(setppbot)$/i
handler.rowner = true
handler.owner = true

module.exports = handler