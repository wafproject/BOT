/**
 * Plugin SEWA BOT STORE — PayKita
 * Flow: pilih paket -> create order -> QRIS -> polling status -> PAID -> extend sewa
 */

const fs = require("fs")
const path = require("path")
const QRCode = require("qrcode")
const { readSewaResult, updateSewa } = require("../../lib/sewa-store")
const { nativeFlowMessage, singleSelectButton } = require("../../lib/zapo-message")
const PayKita = require("../../lib/paykita")
const { DATABASE_DIR: DB_DIR } = require("../../lib/project-paths")

const FILE_PENDING = path.join(DB_DIR, "sewa_pending.json")
const PAYKITA_TTL_SECONDS = Number(global.paykitaOrderTtlSeconds || 600)
const PAYKITA_POLL_MS = Number(global.paykitaPollMs || 5000)

const LIST_SEWA_STORE = {
  "30": 5000,
  "60": 10000,
  "90": 15000,
  "150": 20000,
  "365": 45000
}

function ensureDir(d) {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true })
}

function readJson(f, fallback) {
  try { return JSON.parse(fs.readFileSync(f, "utf8")) } catch { return fallback }
}

function writeJson(f, value) {
  ensureDir(path.dirname(f))
  const tmp = f + ".tmp"
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2))
  fs.renameSync(tmp, f)
}

;(function init() {
  ensureDir(DB_DIR)
  if (!fs.existsSync(FILE_PENDING)) writeJson(FILE_PENDING, {})
})()

const loadPending = () => readJson(FILE_PENDING, {})
const savePending = (value) => writeJson(FILE_PENDING, value)
const now = () => Date.now()
const fmtRp = (value) => "Rp" + Number(value || 0).toLocaleString("id-ID")
const line = "━━━━━━━━━━━━━━━━━━"

function keyToMs(key) {
  const days = Number(key)
  return Number.isFinite(days) ? days * 86400000 : null
}

function labelDurasi(key) {
  key = String(key)

  if (key === "30") return "1 Bulan"
  if (key === "60") return "2 Bulan"
  if (key === "90") return "3 Bulan"
  if (key === "150") return "5 Bulan"
  if (key === "365") return "1 Tahun"

  return `${key} Hari`
}

function isGroupJid(jid) {
  return String(jid || "").endsWith("@g.us")
}

function fmtWib(ms) {
  return new Date(ms).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta"
  }) + " WIB"
}

function makeReference(gid) {
  const groupId = String(gid || "")
    .split("@")[0]
    .replace(/[^0-9A-Za-z_-]/g, "")
    .slice(0, 40)

  return `SEWA-${groupId}-${Date.now()}`.slice(0, 120)
}

// ===================== MENU =====================

function menuText() {
  return `🛍️ *HARGA SEWA BOT STORE*\n\n` +
    `💳 *Sewa Bot:*\n` +
    `• 1 Bulan   : *${fmtRp(LIST_SEWA_STORE["30"])}*\n` +
    `• 2 Bulan   : *${fmtRp(LIST_SEWA_STORE["60"])}*\n` +
    `• 3 Bulan   : *${fmtRp(LIST_SEWA_STORE["90"])}*\n` +
    `• 5 Bulan   : *${fmtRp(LIST_SEWA_STORE["150"])}*\n` +
    `• 1 Tahun   : *${fmtRp(LIST_SEWA_STORE["365"])}*`
}

async function sendSewaMenu(conn, chatId) {
  const sections = [{
    title: "Pilih durasi sewa",
    rows: [
      { title: "1 Bulan", description: "Rp5.000", id: "sewa 30" },
      { title: "2 Bulan", description: "Rp10.000", id: "sewa 60" },
      { title: "3 Bulan", description: "Rp15.000", id: "sewa 90" },
      { title: "5 Bulan", description: "Rp20.000", id: "sewa 150" },
      { title: "1 Tahun", description: "Rp45.000", id: "sewa 365" }
    ]
  }]

  return conn.sendMessage(
    chatId,
    nativeFlowMessage({
      title: "🛍️ HARGA SEWA BOT STORE",
      text: menuText(),
      footer: "Pembayaran via QRIS PayKita",
      buttons: [
        singleSelectButton("🧾 Pilih Paket Sewa", sections)
      ]
    })
  )
}

// ===================== PENDING =====================

function getPendingGid(gid) {
  const db = loadPending()
  return db[gid] || null
}

function setPendingGid(gid, data) {
  const db = loadPending()
  db[gid] = data
  savePending(db)
  return db[gid]
}

function clearPendingGid(gid) {
  const db = loadPending()
  delete db[gid]
  savePending(db)
}

function isPendingValid(rec) {
  if (!rec) return false
  if (rec.status !== "PENDING") return false
  if (!rec.transactionId) return false
  if (!rec.expiresAt || now() >= rec.expiresAt) return false
  return true
}

// ===================== CAPTION =====================

function captionSewa({
  trxId,
  durKey,
  amountBase,
  feeAmount,
  uniqueCode,
  payAmount,
  expiredMin
}) {
  return `🧾 *SEWA BOT (GRUP INI)* 🧾\n${line}\n` +
    `🆔 *Order ID*   : ${trxId}\n` +
    `📅 *Durasi*     : ${labelDurasi(durKey)}\n` +
    `💰 *Harga*      : ${fmtRp(amountBase)}\n` +
    `🧾 *Fee*        : ${fmtRp(feeAmount)}\n` +
    `🔢 *Kode Unik*  : ${uniqueCode || 0}\n` +
    `💳 *Total Bayar*: *${fmtRp(payAmount)}*\n` +
    `⏳ *Expired*    : ±${expiredMin} menit\n${line}\n\n` +
    `⚠️ Bayar sesuai *Total Bayar*.\n` +
    `✅ Nominal QRIS dibuat otomatis oleh PayKita.`
}

// ===================== DELETE QR =====================

async function safeDelete(conn, gid, keyObj) {
  const msgId = keyObj?.id
  if (!gid || !msgId) return

  try {
    await conn.sendMessage(gid, {
      delete: {
        remoteJid: gid,
        fromMe: true,
        id: msgId
      }
    })
  } catch (error) {
    console.error("[SEWA DELETE]", error?.message || error)
  }
}

// ===================== NOTIF ROWNER =====================

async function notifyRowner(conn, {
  kind,
  groupName,
  gid,
  payerJid,
  durasiKey,
  expiredNew,
  trxId
}) {
  try {
    const rowner = global.rowner
    if (!rowner) return

    const targets = Array.isArray(rowner)
      ? rowner
      : [rowner]

    const payerTag = payerJid
      ? `@${String(payerJid).split("@")[0]}`
      : "-"

    const msg =
      `📢 *NOTIFIKASI SEWA BOT STORE*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `✅ Pembayaran PayKita terdeteksi!\n\n` +
      `🧾 Order ID : ${trxId || "-"}\n` +
      `🧩 Status   : *${kind || "-"}*\n` +
      `📛 Grup     : ${groupName}\n` +
      `🔗 JID      : ${gid}\n` +
      `👤 Pembeli  : ${payerTag}\n` +
      `📦 Paket    : +${labelDurasi(durasiKey)}\n` +
      `📅 Expired  : ${fmtWib(expiredNew)}\n` +
      `━━━━━━━━━━━━━━━━━━`

    for (const jid of targets) {
      if (!jid) continue

      await conn.sendMessage(jid, {
        text: msg,
        mentions: payerJid ? [payerJid] : []
      })
    }
  } catch (error) {
    console.error("[SEWA ROWNER]", error?.message || error)
  }
}

// ===================== APPLY SEWA =====================

async function applyPaidExtend({
  conn,
  gid,
  payerJid,
  durasiMs,
  durasiKey,
  trxId
}) {
  const tnow = now()
  const read = readSewaResult({ allowCached: true })

  let groupName =
    read.data?.[gid]?.name || gid

  try {
    let timer

    const meta = await Promise.race([
      conn.groupMetadata(gid),

      new Promise((resolve) => {
        timer = setTimeout(
          () => resolve(null),
          2500
        )
      })
    ]).finally(
      () => clearTimeout(timer)
    )

    groupName =
      meta?.subject || groupName
  } catch (error) {
    console.warn(
      `[SEWA PAYMENT META] ${gid}: ${error?.message || error}`
    )
  }

  const applied =
    await updateSewa((data) => {
      const old =
        data[gid] || {}

      if (
        trxId &&
        old.lastSewaTransactionId === trxId
      ) {
        return {
          alreadyApplied: true,
          kind: "SUDAH DIPROSES",
          expiredNew: Number(old.expired || 0),
          groupName: old.name || groupName
        }
      }

      const prevExpired =
        Number(old.expired || 0)

      const baseTime =
        prevExpired > tnow
          ? prevExpired
          : tnow

      const expiredNew =
        baseTime + Number(durasiMs)

      const wasActive =
        prevExpired > tnow

      const kind =
        wasActive
          ? "PERPANJANG"
          : "SEWA BARU"

      data[gid] = {
        ...old,
        name: groupName,
        expired: expiredNew,
        status: "active",
        lastSewaTransactionId:
          trxId ||
          old.lastSewaTransactionId ||
          null,
        updatedAt: Date.now()
      }

      return {
        alreadyApplied: false,
        kind,
        expiredNew,
        groupName
      }
    })

  if (applied.alreadyApplied) {
    console.log(
      `[SEWA PAYKITA] ${gid} transaksi ${trxId} sudah diproses`
    )

    return applied
  }

  const mention =
    payerJid
      ? [payerJid]
      : []

  const tag =
    payerJid
      ? `@${String(payerJid).split("@")[0]}`
      : "-"

  try {
    await conn.sendMessage(gid, {
      text:
        `✅ *PEMBAYARAN PAYKITA TERDETEKSI*\n` +
        `🧩 Status: *${applied.kind}*\n` +
        `👤 Pembayar: ${tag}\n` +
        `➕ Tambahan: *${labelDurasi(durasiKey)}*\n` +
        `📅 Expired baru: *${fmtWib(applied.expiredNew)}*`,

      mentions: mention
    })
  } catch (error) {
    console.error(
      "[SEWA PAYMENT NOTIFY]",
      error?.message || error
    )
  }

  await notifyRowner(conn, {
    kind: applied.kind,
    groupName: applied.groupName,
    gid,
    payerJid,
    durasiKey,
    expiredNew: applied.expiredNew,
    trxId
  })

  return applied
}

// ===================== CREATE ORDER =====================

async function handleBuyFromButton({
  conn,
  m,
  gid,
  durKey
}) {
  const pend =
    getPendingGid(gid)

  if (
    isPendingValid(pend)
  ) {
    try {
      if (pend.qris) {
        const img =
          await QRCode.toBuffer(
            pend.qris,
            {
              type: "png",
              errorCorrectionLevel: "H",
              width: 900
            }
          )

        return conn.sendMessage(
          gid,
          {
            image: img,

            caption:
              `⏳ QR sebelumnya masih aktif.\n` +
              `💳 Total: *${fmtRp(pend.payAmount)}*\n` +
              `Silakan lakukan pembayaran.`
          },
          {
            quote: m
          }
        )
      }
    } catch (error) {
      console.error(
        "[SEWA RESEND QR]",
        error?.message || error
      )
    }

    return conn.sendMessage(
      gid,
      {
        text:
          "⏳ Invoice sebelumnya masih aktif. Silakan bayar dulu."
      },
      {
        quote: m
      }
    )
  }

  if (
    pend &&
    !isPendingValid(pend)
  ) {
    clearPendingGid(gid)
  }

  const amountBase =
    LIST_SEWA_STORE[
      String(durKey)
    ]

  if (!amountBase) {
    return conn.sendMessage(
      gid,
      {
        text:
          "❌ Durasi tidak tersedia."
      },
      {
        quote: m
      }
    )
  }

  const durasiMs =
    keyToMs(durKey)

  if (!durasiMs) {
    return conn.sendMessage(
      gid,
      {
        text:
          "❌ Durasi tidak valid."
      },
      {
        quote: m
      }
    )
  }

  let inv

  try {
    inv =
      await PayKita.createOrder({
        amount: Number(amountBase),
        reference: makeReference(gid),
        ttlSeconds: PAYKITA_TTL_SECONDS
      })
  } catch (error) {
    return conn.sendMessage(
      gid,
      {
        text:
          "❌ Gagal membuat invoice PayKita:\n" +
          String(error?.message || error)
      },
      {
        quote: m
      }
    )
  }

  if (
    !inv?.transactionId ||
    !inv?.qris
  ) {
    return conn.sendMessage(
      gid,
      {
        text:
          "❌ PayKita tidak mengembalikan order ID / QRIS."
      },
      {
        quote: m
      }
    )
  }

  const startedAt =
    now()

  let expiresAt =
    startedAt +
    PAYKITA_TTL_SECONDS * 1000

  if (inv.expiresAt) {
    const parsed =
      new Date(inv.expiresAt).getTime()

    if (
      Number.isFinite(parsed)
    ) {
      expiresAt =
        parsed
    }
  }

  setPendingGid(
    gid,
    {
      status: "PENDING",
      provider: "PAYKITA",

      transactionId:
        inv.transactionId,

      reference:
        inv.reference,

      payer:
        m.sender,

      chatId:
        gid,

      durasiKey:
        String(durKey),

      durasiMs:
        Number(durasiMs),

      amountBase:
        Number(
          inv.baseAmount ||
          amountBase
        ),

      feeAmount:
        Number(
          inv.feeAmount ||
          0
        ),

      uniqueCode:
        Number(
          inv.uniqueCode ||
          0
        ),

      payAmount:
        Number(
          inv.payAmount ||
          amountBase
        ),

      qris:
        inv.qris,

      checkoutUrl:
        inv.checkoutUrl || "",

      startedAt,
      expiresAt,

      lastStatus:
        "pending"
    }
  )

  const img =
    await QRCode.toBuffer(
      inv.qris,
      {
        type: "png",
        errorCorrectionLevel: "H",
        width: 900
      }
    )

  const expiredMin =
    Math.ceil(
      PAYKITA_TTL_SECONDS /
      60
    )

  const cap =
    captionSewa({
      trxId:
        inv.transactionId,

      durKey,

      amountBase:
        inv.baseAmount ||
        amountBase,

      feeAmount:
        inv.feeAmount ||
        0,

      uniqueCode:
        inv.uniqueCode ||
        0,

      payAmount:
        inv.payAmount ||
        amountBase,

      expiredMin
    })

  const sent =
    await conn.sendMessage(
      gid,
      {
        image: img,
        caption: cap
      },
      {
        quote: m
      }
    )

  try {
    const p =
      getPendingGid(gid)

    if (
      p &&
      p.transactionId ===
        inv.transactionId
    ) {
      p.qrMsgKey = {
        id:
          sent?.key?.id
      }

      setPendingGid(
        gid,
        p
      )
    }
  } catch (error) {
    console.error(
      "[SEWA SAVE MSG]",
      error?.message || error
    )
  }
}

// ===================== POLLER =====================

if (
  !global.__sewaPayKitaPollerStarted
) {
  global.__sewaPayKitaPollerStarted =
    true

  setInterval(
    async () => {
      const conn =
        global.__sewaConn

      if (!conn) return

      const pendAll =
        loadPending()

      const tnow =
        now()

      let changed =
        false

      for (
        const gid
        of Object.keys(pendAll)
      ) {
        const rec =
          pendAll[gid]

        if (!rec) continue

        if (
          rec.provider &&
          rec.provider !== "PAYKITA"
        ) {
          continue
        }

        if (
          !isPendingValid(rec)
        ) {
          if (
            rec?.expiresAt &&
            tnow >= rec.expiresAt
          ) {
            await safeDelete(
              conn,
              gid,
              rec.qrMsgKey
            )

            try {
              await conn.sendMessage(
                gid,
                {
                  text:
                    "⏰ Waktu pembayaran habis (timeout)."
                }
              )
            } catch {}
          }

          delete pendAll[gid]

          changed = true
          continue
        }

        let statusResult

        try {
          statusResult =
            await PayKita.checkStatus(
              rec.transactionId
            )
        } catch (error) {
          console.error(
            `[SEWA PAYKITA CHECK] ${rec.transactionId}:`,
            error?.message || error
          )

          continue
        }

        const status =
          String(
            statusResult?.status ||
            rec.lastStatus ||
            "pending"
          ).toLowerCase()

        rec.lastStatus =
          status

        rec.lastCheck =
          tnow

        rec.rawStatusLast =
          statusResult?.raw

        if (
          statusResult?.payAmount
        ) {
          rec.payAmount =
            statusResult.payAmount
        }

        pendAll[gid] =
          rec

        changed = true

        if (
          PayKita.isPaidStatus(status)
        ) {
          try {
            await applyPaidExtend({
              conn,
              gid,

              payerJid:
                rec.payer,

              durasiMs:
                rec.durasiMs,

              durasiKey:
                rec.durasiKey,

              trxId:
                rec.transactionId
            })
          } catch (error) {
            console.error(
              `[SEWA PAYMENT APPLY] ${gid}:`,
              error?.message || error
            )

            continue
          }

          await safeDelete(
            conn,
            gid,
            rec.qrMsgKey
          )

          delete pendAll[gid]

          changed = true
          continue
        }

        if (
          PayKita.isFinalFailStatus(
            status
          )
        ) {
          await safeDelete(
            conn,
            gid,
            rec.qrMsgKey
          )

          try {
            await conn.sendMessage(
              gid,
              {
                text:
                  `⏰ Transaksi PayKita berakhir: *${status.toUpperCase()}*`
              }
            )
          } catch {}

          delete pendAll[gid]

          changed = true
          continue
        }

        if (
          rec.expiresAt &&
          tnow >= rec.expiresAt
        ) {
          await safeDelete(
            conn,
            gid,
            rec.qrMsgKey
          )

          try {
            await conn.sendMessage(
              gid,
              {
                text:
                  "⏰ Waktu pembayaran habis (timeout)."
              }
            )
          } catch {}

          delete pendAll[gid]

          changed = true
        }
      }

      if (changed) {
        savePending(
          pendAll
        )
      }
    },
    PAYKITA_POLL_MS
  )
}

// ===================== MAIN =====================

let handler =
  async (
    m,
    {
      wafproject
    }
  ) => {
    const conn =
      wafproject

    global.__sewaConn =
      conn

    if (
      !isGroupJid(
        m.chat
      )
    ) {
      return conn.sendMessage(
        m.chat,
        {
          text:
            "❌ .sewa hanya bisa dipakai di grup."
        },
        {
          quote: m
        }
      )
    }

    return sendSewaMenu(
      conn,
      m.chat
    )
  }

// ===================== BUTTON =====================

handler.before =
  async function (
    m,
    {
      wafproject
    }
  ) {
    const conn =
      wafproject

    global.__sewaConn =
      conn

    let id =
      m.message
        ?.listResponseMessage
        ?.singleSelectReply
        ?.selectedRowId

    if (!id) {
      const paramsJson =
        m.message
          ?.interactiveResponseMessage
          ?.nativeFlowResponseMessage
          ?.paramsJson

      if (
        paramsJson
      ) {
        try {
          const parsed =
            JSON.parse(
              paramsJson
            )

          id =
            parsed?.id
        } catch (error) {
          console.error(
            "[SEWA BUTTON JSON]",
            error?.message || error
          )
        }
      }
    }

    if (!id) return

    id =
      String(id).trim()

    if (
      !/^sewa\s+(30|60|90|150|365)$/i.test(id)
    ) {
      return
    }

    if (
      !isGroupJid(
        m.chat
      )
    ) {
      return
    }

    const durKey =
      id.split(/\s+/)[1]

    await handleBuyFromButton({
      conn,
      m,
      gid: m.chat,
      durKey
    })

    return true
  }

handler.help = ["sewa"]
handler.category = ["info"]
handler.command = /^(sewa)$/i
handler.register = true

module.exports = handler