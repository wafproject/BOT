/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

// commands/main/owner.js (CommonJS)
// ✨ Cmd: .owner + kirim VCard Owner

function normalizeNumber(num = '') {
  return String(num).replace(/\D/g, '')
}

function getOwnerNumber() {
  // prioritas global.nomorowner
  if (global.nomorowner) return normalizeNumber(global.nomorowner)

  // fallback global.owner [[number, name, isCreator]]
  if (Array.isArray(global.owner) && global.owner[0]) {
    const o = global.owner[0]
    if (Array.isArray(o)) return normalizeNumber(o[0])
    return normalizeNumber(o)
  }

  // fallback global.rowner
  if (global.rowner) return normalizeNumber(global.rowner)

  return ''
}

const handler = async (m, { wafproject }) => {
  const ownerNum = getOwnerNumber()
  const ownerName =
    global.ownerName ||
    global.namaowner ||
    'Owner WAF PROJECT'

  const text =
`👑 *OWNER BOT*

Ini owner ku ya kak 😊
Kalau mau *lapor error / bug / request fitur / sewa bot*,
langsung chat owner dengan *sopan* ya 🙏✨

📩 *Kontak owner ada di bawah ini 👇*`

  // kirim teks dulu
  await wafproject.sendMessage(m.chat, { text }, { quote: m })

  // kirim vcard (kalau nomor owner ada)
  if (!ownerNum) return

  const vcard =
`BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
ORG:WAF PROJECT;
TEL;type=CELL;type=VOICE;waid=${ownerNum}:${ownerNum}
END:VCARD`

  await wafproject.sendMessage(
    m.chat,
    {
      contacts: {
        displayName: ownerName,
        contacts: [{ vcard }]
      }
    },
    { quote: m }
  )
}

handler.help = ['owner']
handler.command = ['owner']
handler.category = 'info'
handler.description = 'Info kontak owner bot + vcard'

handler.owner = false
handler.admin = false
handler.group = false
handler.private = false
handler.limit = false

module.exports = handler