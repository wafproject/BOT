// ✨ Plugin: AI Image Edit (JagoanProject Nano Banana) - CJS ✨
// Command: .aiedit <prompt>
//
// Flow:
// reply image
// -> download
// -> upload ke pxpic
// -> GET JagoanProject /api/ai/nanobanana
// -> kirim hasil
//
// config.js / settings.js:
// global.jagoanApi = "https://api.jagoanproject.com";
// global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";

const axios = require("axios");
const { fromBuffer } = require("../../lib/file-type.js");
const {
  downloadContentFromMessage,
} = require("../../lib/zapo-adapter.js");

////////////////////////////
// 🌐 Upload helper
////////////////////////////
const pxpic = {
  upload: async (buffer) => {
    const ft = (await fromBuffer(buffer)) || {};

    const ext = ft.ext || "jpg";
    const mime = ft.mime || "image/jpeg";

    const fileName =
      `${Date.now()}-` +
      `${Math.random().toString(36).slice(2, 10)}.${ext}`;

    const folder = "uploads";

    const response = await axios.post(
      "https://pxpic.com/getSignedUrl",
      {
        folder,
        fileName,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
        timeout: 60000,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
      }
    );

    const presignedUrl = response?.data?.presignedUrl;

    if (!presignedUrl) {
      throw new Error(
        "Upload CDN gagal: presignedUrl tidak ditemukan."
      );
    }

    await axios.put(presignedUrl, buffer, {
      headers: {
        "Content-Type": mime,
      },
      timeout: 60000,
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });

    return (
      "https://files.fotoenhancer.com/uploads/" +
      fileName
    );
  },
};

////////////////////////////
// 🧩 Unwrap message
////////////////////////////
function unwrapMessage(obj) {
  let msg =
    obj?.message ||
    obj?.msg?.message ||
    obj?.msg ||
    obj;

  if (!msg) {
    return {
      type: null,
      node: null,
    };
  }

  if (msg?.message) {
    msg = msg.message;
  }

  if (msg.ephemeralMessage?.message) {
    msg = msg.ephemeralMessage.message;
  }

  if (msg.viewOnceMessageV2?.message) {
    msg = msg.viewOnceMessageV2.message;
  }

  if (msg.viewOnceMessage?.message) {
    msg = msg.viewOnceMessage.message;
  }

  if (msg.viewOnceMessageV2Extension?.message) {
    msg = msg.viewOnceMessageV2Extension.message;
  }

  const type = msg && Object.keys(msg)[0];
  const node = type ? msg[type] : null;

  return {
    type,
    node,
  };
}

////////////////////////////
// 🧩 Convert media type
////////////////////////////
function toDownloadType(type) {
  if (type === "imageMessage") return "image";
  if (type === "videoMessage") return "video";
  if (type === "audioMessage") return "audio";
  if (type === "documentMessage") return "document";
  if (type === "stickerMessage") return "sticker";

  return null;
}

////////////////////////////
// 📥 Download media
////////////////////////////
async function downloadMediaAny(obj) {
  // Coba gunakan helper download dari bot
  try {
    if (typeof obj?.download === "function") {
      const buffer = await obj.download();

      if (Buffer.isBuffer(buffer) && buffer.length) {
        return buffer;
      }
    }
  } catch (error) {
    console.log(
      "[AI Edit] Download bawaan gagal:",
      error?.message || error
    );
  }

  // Fallback menggunakan Zapo media stream
  const { type, node } = unwrapMessage(obj);
  const downloadType = toDownloadType(type);

  if (!node || !downloadType) {
    return null;
  }

  const stream = await downloadContentFromMessage(
    node,
    downloadType
  );

  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(chunk);
  }

  const buffer = Buffer.concat(chunks);

  return buffer.length ? buffer : null;
}

////////////////////////////
// 🔍 Ambil MIME
////////////////////////////
function getMimeAny(obj) {
  const { node } = unwrapMessage(obj);

  return (
    node?.mimetype ||
    obj?.mimetype ||
    obj?.msg?.mimetype ||
    ""
  );
}

////////////////////////////
// 🔍 Cek URL valid
////////////////////////////
function isValidUrl(value) {
  return (
    typeof value === "string" &&
    /^https?:\/\//i.test(value)
  );
}

////////////////////////////
// 🔍 Ambil URL hasil API
////////////////////////////
function getResultUrl(data) {
  const possibleUrls = [
    data?.url,
    data?.result,
    data?.result?.url,

    data?.data,
    data?.data?.url,
    data?.data?.image,
    data?.data?.image_url,
    data?.data?.result,
    data?.data?.result?.url,

    data?.output,
    data?.output?.url,

    data?.image,
    data?.image_url,
    data?.result_url,

    // Fallback jika respons berbentuk array
    Array.isArray(data?.data?.results)
      ? data.data.results.find(
          (item) =>
            item?.status === true &&
            isValidUrl(item?.url)
        )?.url
      : null,

    Array.isArray(data?.results)
      ? data.results.find(
          (item) =>
            item?.status === true &&
            isValidUrl(item?.url)
        )?.url
      : null,

    Array.isArray(data?.data)
      ? data.data.find(
          (item) =>
            item?.status === true &&
            isValidUrl(item?.url)
        )?.url
      : null,

    // Fallback ambil URL pertama
    Array.isArray(data?.data?.results)
      ? data.data.results.find(
          (item) => isValidUrl(item?.url)
        )?.url
      : null,

    Array.isArray(data?.results)
      ? data.results.find(
          (item) => isValidUrl(item?.url)
        )?.url
      : null,
  ];

  return possibleUrls.find(isValidUrl) || null;
}

////////////////////////////
// 🤖 JagoanProject Nano Banana
////////////////////////////
async function jagoanImageEdit({
  prompt,
  imageUrl,
}) {
  if (!global.jagoanApi) {
    throw new Error(
      "Config belum lengkap: global.jagoanApi belum di-set."
    );
  }

  if (!global.jagoanKey) {
    throw new Error(
      "Config belum lengkap: global.jagoanKey belum di-set."
    );
  }

  const baseUrl = String(global.jagoanApi)
    .trim()
    .replace(/\/+$/, "");

  const apiKey = String(global.jagoanKey).trim();

  if (!apiKey) {
    throw new Error(
      "API key JagoanProject kosong."
    );
  }

  if (!imageUrl || !isValidUrl(imageUrl)) {
    throw new Error(
      "URL gambar sumber tidak valid."
    );
  }

  if (!prompt || !String(prompt).trim()) {
    throw new Error(
      "Prompt edit gambar tidak boleh kosong."
    );
  }

  const endpoint =
    `${baseUrl}/api/ai/nanobanana` +
    `?image_url=${encodeURIComponent(imageUrl)}` +
    `&prompt=${encodeURIComponent(prompt)}`;

  const response = await axios.get(endpoint, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0",
    },
    timeout: 300000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });

  const data = response.data;

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    const errorData =
      typeof data === "string"
        ? data
        : JSON.stringify(data);

    throw new Error(
      `JagoanProject HTTP ${response.status}: ` +
      errorData.slice(0, 500)
    );
  }

  if (
    data?.status === false ||
    data?.success === false
  ) {
    throw new Error(
      `JagoanProject gagal: ${
        data?.message ||
        data?.error ||
        JSON.stringify(data).slice(0, 500)
      }`
    );
  }

  const resultUrl = getResultUrl(data);

  if (!resultUrl) {
    throw new Error(
      "URL hasil tidak ditemukan: " +
      JSON.stringify(data).slice(0, 700)
    );
  }

  console.log(
    "[JagoanProject Nano Banana] Berhasil:",
    resultUrl
  );

  return {
    url: resultUrl,
    creator:
      data?.creator ||
      "Jagoan Project",
    message:
      data?.message ||
      "AI image edit berhasil",
  };
}

////////////////////////////
// 📥 Download hasil
////////////////////////////
async function downloadResultImage(url) {
  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 180000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    headers: {
      Accept: "image/*,*/*",
      "User-Agent": "Mozilla/5.0",
    },
  });

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    throw new Error(
      `Gagal download hasil HTTP ${response.status}`
    );
  }

  const buffer = Buffer.from(response.data);

  if (!buffer.length) {
    throw new Error(
      "File hasil kosong."
    );
  }

  return buffer;
}

////////////////////////////
// 📤 Kirim gambar hasil
////////////////////////////
async function sendResultImage(
  wafproject,
  chat,
  url,
  caption,
  quoted
) {
  try {
    return await wafproject.sendMessage(
      chat,
      {
        image: {
          url,
        },
        caption,
      },
      {
        quoted,
      }
    );
  } catch (error) {
    console.log(
      "[AI Edit] Kirim URL gagal, mencoba buffer:",
      error?.message || error
    );

    const buffer = await downloadResultImage(url);

    return wafproject.sendMessage(
      chat,
      {
        image: buffer,
        caption,
      },
      {
        quoted,
      }
    );
  }
}

////////////////////////////
// 🧠 Handler
////////////////////////////
let handler = async (
  m,
  {
    wafproject,
    usedPrefix,
    command,
    text,
  }
) => {
  const q = m.quoted ? m.quoted : m;
  const prompt = String(text || "").trim();

  if (!prompt) {
    return m.reply(
      "📌 *Cara pakai:*\n" +
      "Balas foto dengan perintah:\n" +
      `*${usedPrefix + command}* <prompt>\n\n` +
      "Contoh:\n" +
      `${usedPrefix + command} bikin jadi anime style`
    );
  }

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Tambahkan konfigurasi berikut di config.js:\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";'
    );
  }

  const mime =
    getMimeAny(q) ||
    q?.mimetype ||
    q?.msg?.mimetype ||
    "";

  if (
    !mime ||
    !/^image\//i.test(mime)
  ) {
    return m.reply(
      "📌 *Wajib reply gambar!*\n\n" +
      "Contoh:\n" +
      `*${usedPrefix + command}* bikin jadi anime`
    );
  }

  const react = async (emoji) => {
    try {
      await wafproject.sendMessage(
        m.chat,
        {
          react: {
            text: emoji,
            key: m.key,
          },
        }
      );
    } catch (_error) { console.error("[ERROR][commands/tools/ai-edit.js]", _error?.message || _error) }
  };

  let statusMessage;

  const sendStatus = async (statusText) => {
    try {
      statusMessage =
        await wafproject.sendMessage(
          m.chat,
          {
            text: statusText,
          },
          {
            quote: m,
          }
        );

      return statusMessage;
    } catch {
      return null;
    }
  };

  const editStatus = async (statusText) => {
    if (!statusMessage?.key) {
      return null;
    }

    try {
      return await wafproject.sendMessage(
        m.chat,
        {
          text: statusText,
          edit: statusMessage.key,
        }
      );
    } catch {
      return null;
    }
  };

  try {
    await react("🕒");

    await sendStatus(
      "🎨 *AI Image Edit*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "📸 Foto diterima ✅\n" +
      "🧠 Engine: *JagoanProject Nano Banana*\n" +
      "⏳ Status: Mengunduh gambar...\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    ////////////////////////////
    // 1. Download image
    ////////////////////////////
    const buffer =
      await downloadMediaAny(q);

    if (
      !Buffer.isBuffer(buffer) ||
      !buffer.length
    ) {
      throw new Error(
        "Gagal download foto dari WhatsApp."
      );
    }

    const maxSize =
      8 * 1024 * 1024;

    if (buffer.length > maxSize) {
      throw new Error(
        "Ukuran gambar terlalu besar. Maksimal 8 MB."
      );
    }

    await editStatus(
      "🎨 *AI Image Edit*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "📤 Mengunggah gambar... ⏳\n" +
      "🧠 Engine: *JagoanProject Nano Banana*\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    ////////////////////////////
    // 2. Upload ke CDN
    ////////////////////////////
    const uploadedUrl =
      await pxpic.upload(buffer);

    await editStatus(
      "🎨 *AI Image Edit*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "🧠 Memproses gambar... ⏳\n" +
      "⚙️ Engine: *JagoanProject Nano Banana*\n" +
      `📝 Prompt: ${prompt.slice(0, 100)}\n` +
      "━━━━━━━━━━━━━━━━━━"
    );

    ////////////////////////////
    // 3. JagoanProject API
    ////////////////////////////
    const result =
      await jagoanImageEdit({
        prompt,
        imageUrl: uploadedUrl,
      });

    await editStatus(
      "🎨 *AI Image Edit*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Proses selesai!\n" +
      "📤 Mengirim hasil... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    ////////////////////////////
    // 4. Kirim hasil
    ////////////////////////////
    await sendResultImage(
      wafproject,
      m.chat,
      result.url,
      "✅ *AI Edit selesai!*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `📝 Prompt: ${prompt}\n` +
      "🧠 Engine: *JagoanProject Nano Banana*",
      m
    );

    await editStatus(
      "🎨 *AI Image Edit*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Hasil berhasil dikirim!\n" +
      "🧠 Engine: *JagoanProject Nano Banana*\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    await react("✅");
  } catch (error) {
    console.error(
      "[JagoanProject Nano Banana Error]",
      error
    );

    await react("❌");

    const errorMessage = String(
      error?.message || error
    )
      .replace(
        String(global.jagoanKey || ""),
        "[API_KEY]"
      )
      .slice(0, 500);

    const edited = await editStatus(
      "🎨 *AI Image Edit*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "❌ Proses gagal!\n" +
      `📌 ${errorMessage}\n` +
      "━━━━━━━━━━━━━━━━━━"
    );

    if (!edited) {
      return m.reply(
        "❌ *AI Edit gagal:*\n" +
        errorMessage
      );
    }
  }
};

handler.help = [
  "aiedit <prompt> (reply gambar)",
];

handler.tags = [
  "ai",
  "tools",
];

handler.category = [
  "ai",
  "tools",
];

handler.command = /^aiedit$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;