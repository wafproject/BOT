/**
========================
🚀 WAF PROJECT - RUNTIME
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

function formatUptime(sec = 0) {
  sec = Math.max(0, Math.floor(Number(sec) || 0))
  const d = Math.floor(sec / 86400)
  sec %= 86400
  const h = Math.floor(sec / 3600)
  sec %= 3600
  const m = Math.floor(sec / 60)
  const s = sec % 60

  const parts = []
  if (d) parts.push(`${d} hari`)
  if (h) parts.push(`${h} jam`)
  if (m) parts.push(`${m} menit`)
  parts.push(`${s} detik`)
  return parts.join(' ')
}

const handler = async (m, { wafproject }) => {
  try {
    const up = process.uptime() // uptime process node (runtime bot)
    const teks = `⏱️ *RUNTIME BOT*\n\nBot sudah berjalan selama:\n*${formatUptime(up)}*`
    await wafproject.sendMessage(m.chat, { text: teks }, { quote: m })
  } catch (e) {
    console.error('RUNTIME ERROR:', e)
    await wafproject.sendMessage(m.chat, { text: '❌ Gagal cek runtime.' }, { quote: m })
  }
}

handler.help = ['runtime']
handler.category = ['tools']
handler.command = /^runtime$/i
handler.limit = false
handler.owner = false
handler.group = false
handler.private = false

module.exports = handler