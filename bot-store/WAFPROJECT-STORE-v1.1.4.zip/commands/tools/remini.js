/* 🚀 WAF Project - Remini HD (JagoanProject) 🚀

   Mendukung:
   - Kirim gambar langsung dengan caption .hd / .hdr
   - Reply gambar dengan command .hd / .hdr
   - Foto View Once
   - Pengiriman hasil melalui URL dan fallback buffer

   Endpoint:
   GET https://api.jagoanproject.com/api/tools/remini?image_url=<imageUrl>

   Headers:
   Authorization: Bearer APIKEY

   config.js / settings.js:
   global.jagoanApi = "https://api.jagoanproject.com";
   global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";
*/

const {
  downloadContentFromMessage,
} = require("../../lib/zapo-adapter.js");

const axios = require("axios");
const { fromBuffer } = require("../../lib/file-type.js");

////////////////////////////
// Upload CDN
////////////////////////////

const pxpic = {
  upload: async (buffer) => {
    if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
      throw new Error("Buffer gambar untuk upload tidak valid");
    }

    const fileType = (await fromBuffer(buffer)) || {};
    const extension = fileType.ext || "jpg";
    const mimeType = fileType.mime || "image/jpeg";

    const fileName =
      `${Date.now()}-` +
      `${Math.random().toString(36).slice(2, 10)}.${extension}`;

    const folder = "uploads";

    const response = await axios.post(
      "https://pxpic.com/getSignedUrl",
      {
        folder,
        fileName,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
        timeout: 60000,
        validateStatus: () => true,
      }
    );

    if (response.status < 200 || response.status >= 300) {
      const responseData =
        typeof response.data === "string"
          ? response.data
          : JSON.stringify(response.data);

      throw new Error(
        `Upload CDN HTTP ${response.status}: ${responseData.slice(0, 300)}`
      );
    }

    const presignedUrl = response?.data?.presignedUrl;

    if (!presignedUrl) {
      throw new Error(
        "Upload gagal: presignedUrl tidak ditemukan"
      );
    }

    const uploadResponse = await axios.put(
      presignedUrl,
      buffer,
      {
        headers: {
          "Content-Type": mimeType,
        },
        timeout: 60000,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        validateStatus: () => true,
      }
    );

    if (
      uploadResponse.status < 200 ||
      uploadResponse.status >= 300
    ) {
      throw new Error(
        `Upload file gagal HTTP ${uploadResponse.status}`
      );
    }

    return `https://files.fotoenhancer.com/uploads/${fileName}`;
  },
};

////////////////////////////
// Ambil URL hasil API
////////////////////////////

function getResultUrl(data) {
  const results = Array.isArray(data?.data?.results)
    ? data.data.results
    : [];

  const successfulProvider = results.find(
    (item) =>
      item?.status === true &&
      typeof item?.url === "string" &&
      /^https?:\/\//i.test(item.url)
  );

  const anyProvider = results.find(
    (item) =>
      typeof item?.url === "string" &&
      /^https?:\/\//i.test(item.url)
  );

  const possibleUrls = [
    successfulProvider?.url,
    anyProvider?.url,

    data?.url,
    data?.result,
    data?.result?.url,

    data?.data?.url,
    data?.data?.result,
    data?.data?.result?.url,

    data?.output,
    data?.output?.url,

    data?.image_url,
    data?.result_url,
  ];

  return possibleUrls.find(
    (value) =>
      typeof value === "string" &&
      /^https?:\/\//i.test(value)
  );
}

////////////////////////////
// Ambil provider berhasil
////////////////////////////

function getSuccessfulProvider(data) {
  if (!Array.isArray(data?.data?.results)) {
    return null;
  }

  return (
    data.data.results.find(
      (item) =>
        item?.status === true &&
        typeof item?.url === "string" &&
        /^https?:\/\//i.test(item.url)
    ) || null
  );
}

////////////////////////////
// Proses Remini
////////////////////////////

async function jagoanRemini(buffer) {
  if (!global.jagoanApi || !global.jagoanKey) {
    throw new Error(
      "Config belum lengkap. Tambahkan global.jagoanApi dan global.jagoanKey"
    );
  }

  const baseUrl = String(global.jagoanApi)
    .trim()
    .replace(/\/+$/, "");

  const apiKey = String(global.jagoanKey).trim();

  if (!baseUrl) {
    throw new Error("Base URL JagoanProject kosong");
  }

  if (!apiKey) {
    throw new Error("API key JagoanProject kosong");
  }

  const imageUrl = await pxpic.upload(buffer);

  const endpoint =
    `${baseUrl}/api/tools/remini` +
    `?image_url=${encodeURIComponent(imageUrl)}`;

  const response = await axios.get(endpoint, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Accept: "application/json",
    },
    timeout: 180000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });

  const data = response.data;

  if (response.status < 200 || response.status >= 300) {
    const errorData =
      typeof data === "string"
        ? data
        : JSON.stringify(data);

    throw new Error(
      `JagoanProject HTTP ${response.status}: ` +
        errorData.slice(0, 500)
    );
  }

  if (data?.status !== true) {
    const apiMessage =
      data?.message ||
      JSON.stringify(data).slice(0, 500);

    throw new Error(
      `JagoanProject gagal: ${apiMessage}`
    );
  }

  const resultUrl = getResultUrl(data);
  const provider = getSuccessfulProvider(data);

  if (!resultUrl) {
    throw new Error(
      `URL hasil tidak ditemukan: ` +
        JSON.stringify(data).slice(0, 700)
    );
  }

  console.log("[JagoanProject Remini] Berhasil:", {
    provider: provider?.provider || "unknown",
    url: resultUrl,
  });

  return {
    url: resultUrl,
    provider:
      provider?.provider ||
      "JagoanProject",
    scale: data?.data?.scale || null,
  };
}

////////////////////////////
// Download URL ke buffer
////////////////////////////

async function downloadImageBuffer(url) {
  if (
    typeof url !== "string" ||
    !/^https?:\/\//i.test(url)
  ) {
    throw new Error("URL hasil gambar tidak valid");
  }

  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 180000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    headers: {
      Accept: "image/*,*/*",
      "User-Agent": "Mozilla/5.0",
    },
    validateStatus: () => true,
  });

  if (response.status < 200 || response.status >= 300) {
    throw new Error(
      `Gagal download hasil HTTP ${response.status}`
    );
  }

  const contentType =
    response.headers?.["content-type"] || "";

  if (
    contentType &&
    !contentType.includes("image") &&
    !contentType.includes("octet-stream")
  ) {
    const bodyText = Buffer.from(response.data)
      .toString("utf8")
      .slice(0, 200);

    throw new Error(
      `Hasil bukan gambar. Content-Type: ${contentType}. ` +
        `Response: ${bodyText}`
    );
  }

  const buffer = Buffer.from(response.data);

  if (buffer.length === 0) {
    throw new Error("Hasil gambar kosong");
  }

  return buffer;
}

////////////////////////////
// Kirim gambar hasil
////////////////////////////

async function sendImage(
  wafproject,
  chat,
  result,
  caption,
  quoted
) {
  const url =
    typeof result === "string"
      ? result
      : result?.url;

  if (!url) {
    throw new Error(
      "URL hasil gambar tidak tersedia"
    );
  }

  try {
    return await wafproject.sendMessage(
      chat,
      {
        image: {
          url,
        },
        caption,
      },
      {
        quoted,
      }
    );
  } catch (error) {
    console.log(
      "[JagoanProject Remini] Kirim URL gagal, mencoba buffer:",
      error?.message || error
    );

    const buffer = await downloadImageBuffer(url);

    return wafproject.sendMessage(
      chat,
      {
        image: buffer,
        caption,
      },
      {
        quoted,
      }
    );
  }
}

////////////////////////////
// Ambil pesan asli
////////////////////////////

function getRawMessage(messageObject) {
  return (
    messageObject?.message ||
    messageObject?.msg?.message ||
    null
  );
}

////////////////////////////
// Deteksi pesan View Once
////////////////////////////

function getViewOnceMessage(messageObject) {
  const message =
    getRawMessage(messageObject) ||
    messageObject?.message ||
    {};

  if (message?.viewOnceMessage?.message) {
    return message.viewOnceMessage.message;
  }

  if (message?.viewOnceMessageV2?.message) {
    return message.viewOnceMessageV2.message;
  }

  if (
    message?.viewOnceMessageV2Extension?.message
  ) {
    return message.viewOnceMessageV2Extension.message;
  }

  if (
    messageObject?.msg?.viewOnceMessage?.message
  ) {
    return messageObject.msg.viewOnceMessage.message;
  }

  if (
    messageObject?.msg?.viewOnceMessageV2?.message
  ) {
    return messageObject.msg.viewOnceMessageV2.message;
  }

  return null;
}

////////////////////////////
// Ambil jenis media
////////////////////////////

function getMediaMessage(message) {
  if (!message) {
    return null;
  }

  if (message.imageMessage) {
    return {
      type: "image",
      message: message.imageMessage,
    };
  }

  if (message.videoMessage) {
    return {
      type: "video",
      message: message.videoMessage,
    };
  }

  return null;
}

////////////////////////////
// Cari imageMessage
////////////////////////////

function getImageMessage(messageObject) {
  if (!messageObject) {
    return null;
  }

  const candidates = [
    messageObject?.msg,

    messageObject?.message?.imageMessage,
    messageObject?.imageMessage,

    messageObject?.message?.viewOnceMessage
      ?.message?.imageMessage,

    messageObject?.message?.viewOnceMessageV2
      ?.message?.imageMessage,

    messageObject?.message
      ?.viewOnceMessageV2Extension
      ?.message?.imageMessage,

    messageObject?.msg?.imageMessage,

    messageObject?.msg?.viewOnceMessage
      ?.message?.imageMessage,

    messageObject?.msg?.viewOnceMessageV2
      ?.message?.imageMessage,
  ];

  return (
    candidates.find((item) => {
      if (!item || typeof item !== "object") {
        return false;
      }

      const mime = String(item?.mimetype || "");

      return (
        /image/i.test(mime) ||
        Boolean(item?.jpegThumbnail) ||
        Boolean(item?.directPath) ||
        Boolean(item?.url)
      );
    }) || null
  );
}

////////////////////////////
// Ambil MIME media
////////////////////////////

function getMimeType(messageObject) {
  const imageMessage =
    getImageMessage(messageObject);

  return (
    messageObject?.mimetype ||
    messageObject?.msg?.mimetype ||
    messageObject?.message?.imageMessage
      ?.mimetype ||
    messageObject?.imageMessage?.mimetype ||
    imageMessage?.mimetype ||
    ""
  );
}

////////////////////////////
// Download media aman
////////////////////////////

async function downloadMediaSafe(messageObject) {
  if (!messageObject) {
    throw new Error(
      "Objek pesan media tidak tersedia"
    );
  }

  /*
   * Reply media biasanya memiliki method download().
   * Gambar langsung dengan caption belum tentu memilikinya.
   */
  if (
    typeof messageObject.download === "function"
  ) {
    try {
      const downloaded =
        await messageObject.download();

      if (
        Buffer.isBuffer(downloaded) &&
        downloaded.length > 0
      ) {
        return downloaded;
      }
    } catch (error) {
      console.log(
        "[HD] Download wrapper gagal, mencoba media mentah:",
        error?.message || error
      );
    }
  }

  const imageMessage =
    getImageMessage(messageObject);

  if (!imageMessage) {
    throw new Error(
      "Data imageMessage tidak ditemukan"
    );
  }

  const stream =
    await downloadContentFromMessage(
      imageMessage,
      "image"
    );

  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(
      Buffer.isBuffer(chunk)
        ? chunk
        : Buffer.from(chunk)
    );
  }

  const buffer = Buffer.concat(chunks);

  if (buffer.length === 0) {
    throw new Error(
      "File gambar berhasil dibaca tetapi kosong"
    );
  }

  return buffer;
}

////////////////////////////
// Handler
////////////////////////////

let handler = async (m, { wafproject }) => {
  wafproject.enhancer =
    wafproject.enhancer || {};

  if (m.sender in wafproject.enhancer) {
    throw (
      "⏳ *Sabar ya!* Proses sebelumnya masih berjalan...\n\n" +
      "📌 Tunggu sampai selesai ya."
    );
  }

  wafproject.enhancer[m.sender] = true;

  const send = (text) =>
    wafproject.sendMessage(
      m.chat,
      {
        text,
      },
      {
        quote: m,
      }
    );

  const edit = async (key, text) => {
    if (!key) {
      return null;
    }

    try {
      return await wafproject.sendMessage(
        m.chat,
        {
          text,
          edit: key,
        }
      );
    } catch (error) {
      console.log(
        "[JagoanProject Remini] Edit pesan gagal:",
        error?.message || error
      );

      return null;
    }
  };

  /*
   * Jika pengguna reply gambar:
   * q = pesan yang direply.
   *
   * Jika pengguna mengirim gambar + caption:
   * q = pesan m itu sendiri.
   */
  const q = m.quoted || m;

  const mime =
    getMimeType(q) ||
    getMimeType(m);

  const viewOnceContent =
    getViewOnceMessage(q) ||
    getViewOnceMessage(m);

  const viewOnceMedia =
    getMediaMessage(viewOnceContent);

  const isViewOnce =
    Boolean(viewOnceMedia);

  let buffer;
  let statusMsg;

  try {
    ////////////////////////////
    // Validasi media
    ////////////////////////////

    if (isViewOnce) {
      if (
        viewOnceMedia.type !== "image"
      ) {
        throw new Error(
          "Hanya foto View Once yang bisa diproses"
        );
      }
    } else {
      const imageMessage =
        getImageMessage(q) ||
        getImageMessage(m);

      if (
        !imageMessage &&
        !/image/i.test(mime)
      ) {
        throw new Error(
          "Cara pakai:\n" +
            "Kirim foto dengan caption .hd\n" +
            "atau reply foto dengan command .hd"
        );
      }

      if (
        mime &&
        !/image/i.test(mime)
      ) {
        throw new Error(
          "Format tidak didukung. Hanya gambar atau foto"
        );
      }
    }

    ////////////////////////////
    // Status awal
    ////////////////////////////

    statusMsg = await send(
      "✨ *HD Enhancer*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "📸 *Foto diterima!* ✅\n" +
        "⚙️ Engine: *JagoanProject Remini*\n" +
        "📤 *Output:* Menunggu ⏳\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "⏱️ *Tunggu sebentar ya...*"
    );

    ////////////////////////////
    // Download foto
    ////////////////////////////

    if (isViewOnce) {
      await edit(
        statusMsg?.key,
        "✨ *HD Enhancer*\n" +
          "━━━━━━━━━━━━━━━━━━\n" +
          "📥 *Mengambil foto View Once...* ⏳\n" +
          "⚙️ Engine: *JagoanProject Remini*\n" +
          "━━━━━━━━━━━━━━━━━━"
      );

      const stream =
        await downloadContentFromMessage(
          viewOnceMedia.message,
          "image"
        );

      const chunks = [];

      for await (const chunk of stream) {
        chunks.push(
          Buffer.isBuffer(chunk)
            ? chunk
            : Buffer.from(chunk)
        );
      }

      buffer = Buffer.concat(chunks);
    } else {
      await edit(
        statusMsg?.key,
        "✨ *HD Enhancer*\n" +
          "━━━━━━━━━━━━━━━━━━\n" +
          "📥 *Mengunduh foto...* ⏳\n" +
          "⚙️ Engine: *JagoanProject Remini*\n" +
          "━━━━━━━━━━━━━━━━━━"
      );

      /*
       * Tidak lagi langsung memakai q.download().
       * Fungsi ini mendukung reply dan gambar langsung.
       */
      buffer =
        await downloadMediaSafe(q);
    }

    if (
      !Buffer.isBuffer(buffer) ||
      buffer.length === 0
    ) {
      throw new Error(
        "File gambar gagal diunduh atau file kosong"
      );
    }

    ////////////////////////////
    // Proses API
    ////////////////////////////

    await edit(
      statusMsg?.key,
      "✨ *HD Enhancer*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "📤 *Mengunggah foto...* ⏳\n" +
        "🧪 *Memproses Remini...*\n" +
        "⚙️ Engine: *JagoanProject Remini*\n" +
        "━━━━━━━━━━━━━━━━━━"
    );

    const result =
      await jagoanRemini(buffer);

    ////////////////////////////
    // Kirim hasil
    ////////////////////////////

    await edit(
      statusMsg?.key,
      "✨ *HD Enhancer*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "✅ *Proses selesai!* 🎉\n" +
        "📤 *Mengirim hasil...*\n" +
        "━━━━━━━━━━━━━━━━━━"
    );

    const providerText =
      result?.provider
        ? `\n🔧 Provider: *${result.provider}*`
        : "";

    const scaleText =
      result?.scale
        ? `\n🔍 Scale: *${result.scale}*`
        : "";

    await sendImage(
      wafproject,
      m.chat,
      result,
      "✅ *Done!* ✨\n" +
        "⚙️ Engine: *JagoanProject Remini*" +
        providerText +
        scaleText,
      m
    );

    await edit(
      statusMsg?.key,
      "✨ *HD Enhancer*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "✅ *Output berhasil terkirim!*\n" +
        "⚙️ Engine: *JagoanProject Remini*\n" +
        "━━━━━━━━━━━━━━━━━━"
    );
  } catch (error) {
    console.error(
      "[JagoanProject Remini Error]",
      error
    );

    const rawError = String(
      error?.message || error
    );

    const apiKey =
      String(global.jagoanKey || "");

    const errorMessage = apiKey
      ? rawError
          .split(apiKey)
          .join("[API_KEY]")
          .slice(0, 500)
      : rawError.slice(0, 500);

    if (statusMsg?.key) {
      const edited = await edit(
        statusMsg.key,
        "✨ *HD Enhancer*\n" +
          "━━━━━━━━━━━━━━━━━━\n" +
          "❌ *Proses gagal!*\n" +
          `📌 ${errorMessage}\n` +
          "━━━━━━━━━━━━━━━━━━"
      );

      if (edited) {
        return;
      }
    }

    await m.reply(
      "❌ *Proses HD gagal!* 😿\n" +
        `📌 ${errorMessage}`
    );
  } finally {
    delete wafproject.enhancer[m.sender];
  }
};

handler.help = ["hd", "hdr"];
handler.tags = ["tools"];
handler.command = ["hd", "hdr"];
handler.limit = true;
handler.register = true;

module.exports = handler;