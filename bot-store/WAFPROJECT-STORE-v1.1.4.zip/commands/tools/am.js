/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const axios = require('axios')

/* =========================================================
   RETRY
   ========================================================= */

async function withRetry(
  fn,
  {
    retries = 2,
    baseDelay = 700
  } = {}
) {
  let lastErr

  for (let i = 0; i <= retries; i++) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err

      const code =
        err?.code || ''

      const status =
        err?.response?.status || 0

      const msg =
        String(
          err?.message || ''
        ).toLowerCase()

      const retriable =
        code === 'ECONNRESET' ||
        code === 'ETIMEDOUT' ||
        code === 'EAI_AGAIN' ||
        msg.includes('socket hang up') ||
        msg.includes('timeout') ||
        status === 429 ||
        status >= 500

      if (
        !retriable ||
        i === retries
      ) {
        break
      }

      await new Promise(resolve =>
        setTimeout(
          resolve,
          baseDelay * (i + 1)
        )
      )
    }
  }

  throw lastErr
}

/* =========================================================
   CONFIG
   ========================================================= */

function getConfig() {
  if (!global.jagoanApi) {
    throw new Error(
      'global.jagoanApi belum diset di settings.js'
    )
  }

  if (!global.jagoanKey) {
    throw new Error(
      'global.jagoanKey belum diset di settings.js'
    )
  }

  return {
    baseUrl:
      String(
        global.jagoanApi
      )
        .trim()
        .replace(/\/+$/, ''),

    apiKey:
      String(
        global.jagoanKey
      ).trim()
  }
}

/* =========================================================
   VALIDATOR
   ========================================================= */

function isValidEmail(
  email = ''
) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
    String(email).trim()
  )
}

function isValidLink(
  link = ''
) {
  try {
    const url =
      new URL(
        String(link).trim()
      )

    return (
      url.protocol === 'https:' ||
      url.protocol === 'http:'
    )
  } catch {
    return false
  }
}

/* =========================================================
   SEND MAGIC LINK
   ========================================================= */

async function sendMagicLink(
  email
) {
  const {
    baseUrl,
    apiKey
  } = getConfig()

  const res =
    await withRetry(() =>
      axios.get(
        `${baseUrl}/api/alight-motion/send`,
        {
          params: {
            email
          },

          headers: {
            'X-API-Key':
              apiKey,

            'Authorization':
              `Bearer ${apiKey}`,

            'Accept':
              'application/json',

            'User-Agent':
              'WAF-PROJECT/1.0'
          },

          timeout: 30000,

          validateStatus:
            () => true
        }
      )
    )

  const data =
    res.data

  if (
    res.status < 200 ||
    res.status >= 300
  ) {
    throw new Error(
      data?.message ||
      data?.error ||
      `HTTP ${res.status}`
    )
  }

  if (
    data?.status !== true
  ) {
    throw new Error(
      data?.message ||
      'Gagal mengirim Magic Link'
    )
  }

  return data
}

/* =========================================================
   VERIFY MAGIC LINK
   ========================================================= */

async function verifyMagicLink(
  email,
  link
) {
  const {
    baseUrl,
    apiKey
  } = getConfig()

  const res =
    await withRetry(() =>
      axios.get(
        `${baseUrl}/api/alight-motion/verify`,
        {
          params: {
            email,
            link
          },

          headers: {
            'X-API-Key':
              apiKey,

            'Authorization':
              `Bearer ${apiKey}`,

            'Accept':
              'application/json',

            'User-Agent':
              'WAF-PROJECT/1.0'
          },

          timeout: 30000,

          validateStatus:
            () => true
        }
      )
    )

  const data =
    res.data

  if (
    res.status < 200 ||
    res.status >= 300
  ) {
    throw new Error(
      data?.message ||
      data?.error ||
      `HTTP ${res.status}`
    )
  }

  if (
    data?.status !== true
  ) {
    throw new Error(
      data?.message ||
      'Gagal memverifikasi Magic Link'
    )
  }

  return data
}

/* =========================================================
   ERROR UTIL
   ========================================================= */

function getErrorMessage(
  err
) {
  const data =
    err?.response?.data

  let message =
    data?.message ||
    data?.error ||
    err?.message ||
    'Terjadi kesalahan'

  if (
    typeof message !== 'string'
  ) {
    try {
      message =
        JSON.stringify(
          message
        )
    } catch {
      message =
        'Terjadi kesalahan'
    }
  }

  if (
    message.length > 400
  ) {
    message =
      `${message.slice(
        0,
        400
      )}...`
  }

  return message
}

/* =========================================================
   HANDLER
   ========================================================= */

async function plugin(
  m,
  {
    wafproject,
    args,
    text,
    usedPrefix,
    command
  }
) {
  const cmd =
    String(
      command || ''
    ).toLowerCase()

  const pfx =
    usedPrefix || '.'

  /* =====================================================
     .amsend
     ===================================================== */

  if (
    cmd === 'amsend'
  ) {
    const email =
      (
        args?.length
          ? args.join(' ')
          : text || ''
      ).trim()

    if (
      !email ||
      !isValidEmail(email)
    ) {
      return wafproject.sendMessage(
        m.chat,

        {
          text:
`❓ *Format tidak valid.*

Gunakan:
${pfx}amsend email@gmail.com`
        },

        {
          quote: m
        }
      )
    }

    try {
      /* ================= LOADING ================= */

      await wafproject
        .sendMessage(
          m.chat,

          {
            react: {
              text: '⏳',
              key: m.key
            }
          }
        )
        .catch(() => {})

      /* ================= API ================= */

      const result =
        await sendMagicLink(
          email
        )

      const message =
        result?.message ||
        result?.result?.message ||
        'Link verifikasi berhasil dikirim.'

      /* ================= OUTPUT ================= */

      const output =
`🔗 *ALIGHT MOTION - MAGIC LINK*

📧 *Email:*
${email}

✅ ${message}

📥 Silakan cek:
• Inbox
• Spam
• Junk

Setelah Magic Link masuk, gunakan:

${pfx}amverif ${email}|LINK_MAGIC`

      await wafproject.sendMessage(
        m.chat,

        {
          text: output
        },

        {
          quote: m
        }
      )

      /* ================= SUCCESS ================= */

      await wafproject
        .sendMessage(
          m.chat,

          {
            react: {
              text: '✅',
              key: m.key
            }
          }
        )
        .catch(() => {})

      return

    } catch (err) {
      /* ================= ERROR ================= */

      await wafproject
        .sendMessage(
          m.chat,

          {
            react: {
              text: '❌',
              key: m.key
            }
          }
        )
        .catch(() => {})

      console.error(
        '[ERROR][commands/tools/alightmotion.js][SEND]',
        err?.response?.status || '',
        err?.response?.data ||
        err?.message ||
        err
      )

      return wafproject.sendMessage(
        m.chat,

        {
          text:
`❌ *Gagal mengirim Magic Link.*

${getErrorMessage(err)}`
        },

        {
          quote: m
        }
      )
    }
  }

  /* =====================================================
     .amverif
     ===================================================== */

  if (
    cmd === 'amverif'
  ) {
    const raw =
      (
        args?.length
          ? args.join(' ')
          : text || ''
      ).trim()

    /* ================= SPLIT EMAIL | LINK ================= */

    const separator =
      raw.indexOf('|')

    if (
      separator === -1
    ) {
      return wafproject.sendMessage(
        m.chat,

        {
          text:
`❓ *Format tidak valid.*

Gunakan:
${pfx}amverif email@gmail.com|https://alight-creative.firebaseapp.com/...`
        },

        {
          quote: m
        }
      )
    }

    const email =
      raw
        .slice(
          0,
          separator
        )
        .trim()

    const link =
      raw
        .slice(
          separator + 1
        )
        .trim()

    /* ================= VALIDASI ================= */

    if (
      !isValidEmail(email)
    ) {
      return wafproject.sendMessage(
        m.chat,

        {
          text:
`❌ Email tidak valid.

Contoh:
${pfx}amverif email@gmail.com|LINK_MAGIC`
        },

        {
          quote: m
        }
      )
    }

    if (
      !link ||
      !isValidLink(link)
    ) {
      return wafproject.sendMessage(
        m.chat,

        {
          text:
`❌ Magic Link tidak valid.

Contoh:
${pfx}amverif ${email}|https://alight-creative.firebaseapp.com/...`
        },

        {
          quote: m
        }
      )
    }

    try {
      /* ================= LOADING ================= */

      await wafproject
        .sendMessage(
          m.chat,

          {
            react: {
              text: '⏳',
              key: m.key
            }
          }
        )
        .catch(() => {})

      /* ================= VERIFY ================= */

      const result =
        await verifyMagicLink(
          email,
          link
        )

      /* ================= RESULT USER ================= */

      const user =
        result?.result?.user ||
        result?.user ||
        {}

      const resultMessage =
        result?.result?.message ||
        result?.message ||
        'Magic Link berhasil diverifikasi.'

      const emailResult =
        user?.email ||
        result?.email ||
        email

      const emailVerified =
        user?.emailVerified === true
          ? '✅ Ya'
          : user?.emailVerified === false
            ? '❌ Tidak'
            : '-'

      const newUser =
        user?.isNewUser === true
          ? '✅ Ya'
          : user?.isNewUser === false
            ? '❌ Tidak'
            : '-'

      /* ================= OPTIONAL DATA ================= */

      let optionalText = ''

      if (
        user?.uid
      ) {
        optionalText +=
          `\n🆔 *UID:* ${user.uid}`
      }

      if (
        user?.displayName
      ) {
        optionalText +=
          `\n👤 *Nama:* ${user.displayName}`
      }

      if (
        user?.photoUrl
      ) {
        optionalText +=
          `\n🖼️ *Photo:* ${user.photoUrl}`
      }

      if (
        user?.createdAt
      ) {
        optionalText +=
          `\n📅 *Dibuat:* ${user.createdAt}`
      }

      if (
        user?.lastLoginAt
      ) {
        optionalText +=
          `\n🕒 *Login Terakhir:* ${user.lastLoginAt}`
      }

      /* ================= OUTPUT ================= */

      const output =
`✅ *ALIGHT MOTION BERHASIL*

📧 *Email:* ${emailResult}
🔐 *Email Verified:* ${emailVerified}
🆕 *User Baru:* ${newUser}${optionalText}

💬 ${resultMessage}`

      await wafproject.sendMessage(
        m.chat,

        {
          text: output
        },

        {
          quote: m
        }
      )

      /* ================= SUCCESS ================= */

      await wafproject
        .sendMessage(
          m.chat,

          {
            react: {
              text: '✅',
              key: m.key
            }
          }
        )
        .catch(() => {})

      return

    } catch (err) {
      /* ================= ERROR ================= */

      await wafproject
        .sendMessage(
          m.chat,

          {
            react: {
              text: '❌',
              key: m.key
            }
          }
        )
        .catch(() => {})

      console.error(
        '[ERROR][commands/tools/alightmotion.js][VERIFY]',
        err?.response?.status || '',
        err?.response?.data ||
        err?.message ||
        err
      )

      return wafproject.sendMessage(
        m.chat,

        {
          text:
`❌ *Gagal memverifikasi Magic Link.*

${getErrorMessage(err)}`
        },

        {
          quote: m
        }
      )
    }
  }
}

/* =========================================================
   PLUGIN INFO
   ========================================================= */

plugin.command = [
  'amsend',
  'amverif'
]

plugin.category =
  'tools'

plugin.description =
  'Kirim dan verifikasi Magic Link Alight Motion'

module.exports =
  plugin