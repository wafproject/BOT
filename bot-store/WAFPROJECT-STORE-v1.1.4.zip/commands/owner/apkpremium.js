/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

// commands/owner/apkpremium-owner.js
// Khusus OWNER: Manajemen produk APK premium + stok + rekap
// Perintah Owner:
// - addproduk <kode> , <nama> , <harga> , <desk>
// - delproduk <kode>
// - addstok <kode> , <email> , <password> [, <email> , <password> ...]
// - delstok <kode> , <jumlah>
// - setnamaproduk <kode> , <nama_baru>
// - setsnkproduk <kode> , <deskripsi_baru> (bisa reply teks)
// - setharga <kode> , <harga_baru>
// - rekap

const fs = require("fs")
const path = require("path")

const { DATABASE_DIR: DB_DIR } = require("../../lib/project-paths")
const FILE_PREMIUM = path.join(DB_DIR, "premium_apk.json")

function ensureDir(d) {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true })
}
function readJson(f, fb) {
  try {
    return JSON.parse(fs.readFileSync(f, "utf8"))
  } catch {
    return fb
  }
}
function writeJson(f, v) {
  ensureDir(path.dirname(f))
  fs.writeFileSync(f, JSON.stringify(v, null, 2))
}
;(function init() {
  ensureDir(DB_DIR)
  if (!fs.existsSync(FILE_PREMIUM)) writeJson(FILE_PREMIUM, { products: [] })
})()

const fmtRp = (n) => "Rp" + Math.round(Number(n) || 0).toLocaleString("id-ID")
const clean = (s) => String(s || "").trim()
const toCode = (s) => clean(s).toUpperCase().replace(/\s+/g, "")
const line = "──────────────────────"

function load() {
  return readJson(FILE_PREMIUM, { products: [] })
}
function save(db) {
  writeJson(FILE_PREMIUM, db)
}
function findIndex(db, code) {
  const cc = toCode(code)
  return (db.products || []).findIndex(
    (p) => String(p.code || "").toUpperCase() === cc
  )
}

// ambil teks dari quoted (bot kamu sudah bikin m.quoted.text di index.js)
function getQuotedText(m) {
  try {
    if (m?.quoted?.text) return String(m.quoted.text)
  } catch (_error) { console.error("[ERROR][commands/owner/apkpremium.js]", _error?.message || _error) }
  return ""
}

function renderRekap(db) {
  const items = Array.isArray(db.products) ? db.products : []
  if (!items.length) return "📦 Belum ada produk."

  let totalItems = 0
  let totalValue = 0
  let t = "📊 *REKAP PRODUK APK PREMIUM*\n" + line + "\n"

  for (const p of items) {
    const stok = Number(p.items?.length || p.stock || 0)
    const harga = Number(p.price || 0)
    totalItems += stok
    totalValue += stok * harga

    t += `🆔 *${p.code}* — *${p.name}*\n`
    if (p.snk) t += `📝 ${p.snk}\n`
    t += `💰 Harga: *${fmtRp(harga)}*\n`
    t += `📦 Stok : *${stok}*\n`
    t += line + "\n"
  }

  t += `\n🧮 *Total Item:* ${totalItems}\n💸 *Total Nilai Stok:* ${fmtRp(totalValue)}`
  return t
}

const handler = async (m, { wafproject, args, command }) => {
  // command dari handler.js sudah lowercase
  const cmd = String(command || "").toLowerCase()

  const say = async (txt) => {
    try {
      if (typeof m.reply === "function") return await m.reply(String(txt))
    } catch (_error) { console.error("[ERROR][commands/owner/apkpremium.js]", _error?.message || _error) }
    return wafproject.sendMessage(m.chat, { text: String(txt) }, { quote: m })
  }

  const db = load()

  const raw = clean(args.join(" "))
  const parts = raw.split(/\s*,\s*/).map((s) => s)

  try {
    // ADD PRODUK
    if (cmd === "addproduk") {
      if (parts.length < 4)
        return say("Format: *addproduk <kode> , <nama> , <harga> , <desk>*")

      const code = toCode(parts[0])
      const name = clean(parts[1])
      const price = Number(parts[2])
      const descShort = parts.slice(3).join(", ")

      if (!code || !name || !Number.isFinite(price))
        return say("❌ Data tidak valid. Pastikan harga angka.")
      if (findIndex(db, code) >= 0) return say("❌ Kode produk sudah ada.")

      db.products.push({
        code,
        name,
        price,
        stock: 0,
        descShort,
        snk: "",
        desc: descShort,
        items: [],
      })
      save(db)

      return say(
        `✅ *Produk ditambahkan*
${line}
🆔 Kode : ${code}
🏷️ Nama : ${name}
💰 Harga: ${fmtRp(price)}
🗒️ Desk : ${descShort}
📦 Stok : 0`
      )
    }

    // DELETE PRODUK
    if (cmd === "delproduk") {
      if (parts.length < 1) return say("Format: *delproduk <kode>*")

      const code = toCode(parts[0])
      const idx = findIndex(db, code)
      if (idx < 0) return say("❌ Kode tidak ditemukan.")

      const p = db.products[idx]
      db.products.splice(idx, 1)
      save(db)
      return say(`🗑️ Produk *${p.code} — ${p.name}* dihapus.`)
    }

    // ADD STOK
    if (cmd === "addstok") {
      if (parts.length < 3) {
        return say(
          "Format: *addstok <kode> , <email> , <password> [, <email> , <password> ...]*"
        )
      }

      const code = toCode(parts[0])
      const idx = findIndex(db, code)
      if (idx < 0) return say("❌ Kode tidak ditemukan.")

      const fields = parts.slice(1)
      if (fields.length % 2 !== 0) {
        return say("❌ Data tidak lengkap. Gunakan pasangan *email, password* berulang.")
      }

      if (!Array.isArray(db.products[idx].items)) db.products[idx].items = []

      let added = 0
      for (let i = 0; i < fields.length; i += 2) {
        const email = clean(fields[i])
        const password = clean(fields[i + 1])
        if (!email || !password) continue
        db.products[idx].items.push({ email, password, desc: "", addedAt: Date.now() })
        added++
      }

      db.products[idx].stock = db.products[idx].items.length
      save(db)

      if (added === 0) return say("❌ Tidak ada item valid yang ditambahkan.")
      return say(
        `✅ *Stok berhasil ditambahkan*
${line}
🆔 ${db.products[idx].code} — ${db.products[idx].name}
➕ Ditambah : ${added} item
📦 Total    : ${db.products[idx].items.length} item`
      )
    }

    // DEL STOK
    if (cmd === "delstok") {
      if (parts.length < 2) return say("Format: *delstok <kode> , <jumlah>*")

      const code = toCode(parts[0])
      const qty = Number(parts[1])
      if (!Number.isFinite(qty) || qty <= 0) return say("❌ Jumlah harus angka > 0.")

      const idx = findIndex(db, code)
      if (idx < 0) return say("❌ Kode tidak ditemukan.")

      if (!Array.isArray(db.products[idx].items)) db.products[idx].items = []

      const before = db.products[idx].items.length
      const remove = Math.min(qty, before)
      db.products[idx].items.splice(before - remove, remove)
      db.products[idx].stock = db.products[idx].items.length
      save(db)

      return say(
        `🧮 Stok dikurangi
${line}
🆔 ${db.products[idx].code} — ${db.products[idx].name}
➖ Dikurangi : ${remove} item
📦 Sisa     : ${db.products[idx].items.length} item`
      )
    }

    // SET NAMA
    if (cmd === "setnamaproduk") {
      if (parts.length < 2) return say("Format: *setnamaproduk <kode> , <nama_baru>*")

      const code = toCode(parts[0])
      const name = clean(parts[1])

      const idx = findIndex(db, code)
      if (idx < 0) return say("❌ Kode tidak ditemukan.")

      db.products[idx].name = name
      save(db)
      return say(
        `✏️ Nama diubah.
${line}
🆔 ${db.products[idx].code}
🏷️ Nama: ${db.products[idx].name}`
      )
    }

    // SET SNK
    if (cmd === "setsnkproduk") {
      if (parts.length < 1)
        return say(
          "Format: *setsnkproduk <kode> , <deskripsi_baru>* (atau reply teks lalu ketik *setsnkproduk <kode>*)"
        )

      const code = toCode(parts[0])
      const idx = findIndex(db, code)
      if (idx < 0) return say("❌ Kode tidak ditemukan.")

      let snkText = ""
      if (parts.length >= 2) snkText = parts.slice(1).join(", ")
      else {
        const qt = clean(getQuotedText(m))
        if (!qt)
          return say(
            "Format: *setsnkproduk <kode> , <deskripsi_baru>* (atau reply teks lalu ketik *setsnkproduk <kode>*)"
          )
        snkText = qt
      }

      db.products[idx].snk = snkText
      save(db)
      return say(
        `📝 SNK diubah.
${line}
🆔 ${db.products[idx].code}
📜 ${db.products[idx].snk || "-"}`
      )
    }

    // SET HARGA
    if (cmd === "setharga") {
      if (parts.length < 2) return say("Format: *setharga <kode> , <harga_baru>*")

      const code = toCode(parts[0])
      const price = Number(parts[1])
      if (!Number.isFinite(price) || price < 0) return say("❌ Harga tidak valid.")

      const idx = findIndex(db, code)
      if (idx < 0) return say("❌ Kode tidak ditemukan.")

      db.products[idx].price = price
      save(db)

      return say(
        `💰 Harga diubah.
${line}
🆔 ${db.products[idx].code}
💰 Harga: ${fmtRp(db.products[idx].price)}`
      )
    }

    // REKAP
    if (cmd === "rekap") {
      return say(renderRekap(db))
    }
  } catch (e) {
    return say("❌ Terjadi kesalahan: " + (e?.message || e))
  }
}

handler.command = /^(addproduk|delproduk|addstok|delstok|setnamaproduk|setsnkproduk|setharga|rekap)$/i
handler.category = "owner"
handler.description = "Manajemen produk APK premium + stok + rekap"
handler.owner = true
handler.limit = false

module.exports = handler