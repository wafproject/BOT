/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { nativeFlowMessage, copyButton, urlButton } = require('../../lib/zapo-message');

/* =======================
   Fetch resolver (no crash)
   ======================= */
function getFetch() {
  if (typeof fetch === 'function') return fetch;
  try {
    // optional kalau node-fetch terpasang
    // eslint-disable-next-line global-require
    return require('node-fetch');
  } catch {
    return null;
  }
}

/* =======================
   Reply helper (wafproject only)
   ======================= */
async function replyText(m, wafproject, text, extra = {}) {
  try {
    // kalau base kamu punya wafproject.reply
    if (typeof wafproject.reply === 'function') return await wafproject.reply(m.chat, String(text), m, extra);
    // fallback Zapo sendMessage wrapper
    const mentions = Array.isArray(extra.mentions) ? extra.mentions : undefined;
    return await wafproject.sendMessage(m.chat, { text: String(text) }, { quote: m, ...(mentions ? { mentions } : {}) });
  } catch (_error) { console.error("[ERROR][commands/owner/cpanel.js]", _error?.message || _error) }
}

/* ============================================================
   PATH BARU: simpan data panel di:
   database/pterodactyl/file.json
   ============================================================ */
const { databaseFile } = require('../../lib/project-paths');
const DATA_BASE = databaseFile('pterodactyl');
const ensureDir = (d) => { try { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); } catch (_error) { console.error("[ERROR][commands/owner/cpanel.js]", _error?.message || _error) } };
ensureDir(DATA_BASE);

const rolesPath = path.join(DATA_BASE, 'roles.json');
const panelDataPath = path.join(DATA_BASE, 'file.json');

function ensureJson(f, init) {
  ensureDir(path.dirname(f));
  if (!fs.existsSync(f)) fs.writeFileSync(f, JSON.stringify(init, null, 2));
}
function readJson(f, fallback = {}) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fallback; }
}
function writeJson(f, v) {
  ensureDir(path.dirname(f));
  fs.writeFileSync(f, JSON.stringify(v, null, 2));
}

/* roles tanpa reseller */
ensureJson(rolesPath, { partners: [], adminsPanel: [] });
/* file data panel */
ensureJson(panelDataPath, { panels: [] });

function addPanelRecord(rec) {
  const db = readJson(panelDataPath, { panels: [] });
  if (!Array.isArray(db.panels)) db.panels = [];
  db.panels.push(rec);
  writeJson(panelDataPath, db);
}

/* =======================
   Roles
   ======================= */
function hasRole(num, list) { return Array.isArray(list) && list.includes(num); }
function getRole(jid, { isRowner = false } = {}) {
  const num = String(jid || '').split('@')[0];
  const roles = readJson(rolesPath);
  if (isRowner) return 'rowner';
  if (hasRole(num, roles.partners)) return 'partner';
  if (hasRole(num, roles.adminsPanel)) return 'adminPanel';
  return 'guest';
}

/* =======================
   FIX: Deteksi owner robust
   ======================= */
function normalizeNum(s) {
  if (s == null) return null;
  let x = String(s).toLowerCase().trim();
  if (/@s\.whatsapp\.net$/.test(x)) x = x.split('@')[0];
  x = x.replace(/[^\d]/g, '');
  if (!x) return null;
  if (x.startsWith('0')) x = '62' + x.slice(1);
  return x;
}
function collectOwnerNumbers() {
  const set = new Set();
  const pushAny = (v) => {
    if (!v) return;
    if (Array.isArray(v)) { for (const it of v) pushAny(Array.isArray(it) ? it[0] : it); return; }
    if (typeof v === 'object') { for (const val of Object.values(v)) pushAny(val); return; }
    const n = normalizeNum(v); if (n) set.add(n);
  };
  pushAny(global.rowner);
  pushAny(global.owner);
  pushAny(global.ownerNumber);
  pushAny(global.nomorowner);
  pushAny(global.numberowner);
  return set;
}
function isRownerFn(jid) {
  const me = normalizeNum(String(jid || '').split('@')[0]);
  const owners = collectOwnerNumbers();
  return me && owners.has(me);
}

/* =======================
   Paket & versi
   ======================= */
const specsMap = {
  '1gb':  { ram: 1000,  disk: 1000,  cpu: 30 },
  '2gb':  { ram: 2000,  disk: 1500,  cpu: 35 },
  '3gb':  { ram: 3000,  disk: 2500,  cpu: 40 },
  '4gb':  { ram: 4000,  disk: 3500,  cpu: 45 },
  '5gb':  { ram: 5000,  disk: 4500,  cpu: 50 },
  '6gb':  { ram: 6000,  disk: 5500,  cpu: 55 },
  '7gb':  { ram: 7000,  disk: 6500,  cpu: 60 },
  '8gb':  { ram: 8000,  disk: 7500,  cpu: 65 },
  '9gb':  { ram: 9000,  disk: 8500,  cpu: 70 },
  '10gb': { ram: 10000, disk: 9500,  cpu: 75 },
  'unlimited': { ram: 0, disk: 0, cpu: 80 },
  'unli':      { ram: 0, disk: 0, cpu: 80 }
};

function versiConfig(versi) {
  const map = {
    v1:{domain:global.domain,apikey:global.apikey,loc:global.loc,egg:global.egg,nestid:global.nestid},
    v2:{domain:global.domainV2,apikey:global.apikeyV2,loc:global.locV2,egg:global.eggV2,nestid:global.nestidV2},
    v3:{domain:global.domainV3,apikey:global.apikeyV3,loc:global.locV3,egg:global.eggV3,nestid:global.nestidV3},
    v4:{domain:global.domainV4,apikey:global.apikeyV4,loc:global.locV4,egg:global.eggV4,nestid:global.nestidV4},
    v5:{domain:global.domainV5,apikey:global.apikeyV5,loc:global.locV5,egg:global.eggV5,nestid:global.nestidV5}
  };
  return map[String(versi || '').toLowerCase()] || null;
}

async function validateResponse(res, tag) {
  if (res.ok) return res;
  let text = ''; try { text = await res.text(); } catch (_error) { console.error("[ERROR][commands/owner/cpanel.js]", _error?.message || _error) }
  let body = null; try { body = JSON.parse(text); } catch (_error) { console.error("[ERROR][commands/owner/cpanel.js]", _error?.message || _error) }
  const err = new Error(`HTTP ${res.status} (${tag})`);
  err.status = res.status;
  err.bodyText = text;
  err.body = body;
  throw err;
}

function humanizePanelError(err) {
  const body = err?.body || (() => { try { return JSON.parse(err?.bodyText || '{}'); } catch { return null; } })();
  const arr = Array.isArray(body?.errors) ? body.errors : [];
  if (arr.length) {
    const lines = ['‼️ Gagal provisioning:'];
    for (const e of arr) {
      const field = e?.meta?.source_field;
      const rule  = String(e?.meta?.rule || '').toLowerCase();
      const detail= String(e?.detail || '').toLowerCase();
      if (field === 'email' && (rule === 'unique' || detail.includes('already'))) { lines.push('• Email sudah terpakai.'); continue; }
      if (field === 'username' && (rule === 'unique' || detail.includes('already'))) { lines.push('• Username sudah terpakai.'); continue; }
      if (field === 'password' && rule === 'min') { lines.push('• Password terlalu pendek (min 8).'); continue; }
      if (e?.detail) lines.push('• ' + e.detail);
    }
    return lines.join('\n');
  }
  if (err?.status === 422) return '‼️ Data tidak valid (422).';
  return `‼️ ${err?.message || 'Unknown error'}`;
}

function toGB(mb){ return mb === 0 ? 'Unlimited' : `${Math.ceil(mb / 1024)} GB`; }

/* =======================
   Tanggal Indo
   ======================= */
function addDays(baseDate, days){
  const d = new Date(baseDate.getTime());
  d.setDate(d.getDate() + days);
  return d;
}
function formatTanggalIndo(dateObj){
  const tz='Asia/Jakarta';
  const day = new Intl.DateTimeFormat('id-ID', { day:'2-digit', timeZone: tz }).format(dateObj);
  let month = new Intl.DateTimeFormat('id-ID', { month:'long', timeZone: tz }).format(dateObj);
  const year = new Intl.DateTimeFormat('id-ID', { year:'numeric', timeZone: tz }).format(dateObj);
  month = month.charAt(0).toUpperCase() + month.slice(1);
  return `${day} ${month} ${year}`;
}

/* =======================
   Parse target & username
   Format:
   .1gb v1 username 628xxx (nomor opsional)
   ======================= */
function phoneToJid(raw){
  if(!raw) return null;
  let num = String(raw).replace(/[^\d+]/g,'');
  if(!num) return null;
  if(num.startsWith('+')) num=num.slice(1);
  if(num.startsWith('0')) num='62'+num.slice(1);
  if(!/^\d{8,15}$/.test(num)) return null;
  return num+'@s.whatsapp.net';
}
function phoneDisplay(raw){
  if(!raw) return null;
  let s=String(raw).replace(/[^\d+]/g,'');
  if(!s) return null;
  if(s.startsWith('+')) return s;
  if(s.startsWith('0')) return '+62'+s.slice(1);
  if(s.startsWith('62')) return '+'+s;
  return '+'+s;
}
function parseTargetAndUsername(rawText, defaultJid){
  const clean=(rawText||'').trim();
  if(!clean) return { versi:'v1', username:null, targetJid:defaultJid, targetDisplay:null };

  let raw = clean;
  let versi='v1';
  const mv = raw.match(/^(v[1-5])\s+/i);
  if(mv){ versi=mv[1].toLowerCase(); raw=raw.replace(mv[0],'').trim(); }

  const parts = raw.split(/\s+/);
  const username=(parts.shift()||'').toLowerCase().replace(/[^\w.-]/g,'');
  let targetJid=defaultJid, targetDisplay=null;

  if(parts.length){
    const jid=phoneToJid(parts[0]);
    if(jid){ targetJid=jid; targetDisplay=phoneDisplay(parts[0]); }
  }
  return { versi, username, targetJid, targetDisplay };
}

/* =======================
   UI: send panel card
   ======================= */
async function sendPanelCard(wafproject, jid, { text, url, username, password, quoted }) {
  const tmp = path.join(DATA_BASE, `akunpanel_${Date.now()}_${crypto.randomBytes(2).toString('hex')}.txt`);
  try {
    fs.writeFileSync(tmp, text);

    const interactiveMessage = nativeFlowMessage({
      text,
      footer: 'TEKAN TOMBOL UNTUK SALIN DATA ATAU BUKA PANEL',
      buttons: [
        copyButton('📋 Copy Username', String(username), `copy_username_${username}`),
        copyButton('📋 Copy Password', String(password), `copy_password_${password}`),
        urlButton('🌐 Login Panel', url)
      ]
    });

    // Typed media Zapo dan native-flow adalah dua content family berbeda.
    // Kirim file akun lalu kartu tombol native-flow secara terpisah agar keduanya valid.
    await wafproject.sendMessage(jid, {
      document: fs.readFileSync(tmp),
      fileName: 'akunpanel.txt',
      mimetype: 'text/plain',
      caption: text
    }, { quote: quoted });
    await wafproject.sendMessage(jid, interactiveMessage, { quote: quoted });

  } catch (e) {
    await wafproject.sendMessage(jid, {
      text: `${text}

🔘 *Login Panel:* ${url}
📋 *Username:* ${username}
🔐 *Password:* ${password}

(ℹ️ Jika tombol tidak muncul, tap & tahan teks di atas untuk menyalin.)`
    }, { quoted });
  } finally {
    try { fs.unlinkSync(tmp); } catch (_error) { console.error("[ERROR][commands/owner/cpanel.js]", _error?.message || _error) }
  }
}

/* =======================
   Provision panel
   ======================= */
async function provisionPanel({ versi, plan, username, targetJid, wafproject, quoted }) {
  const $fetch = getFetch();
  if (!$fetch) throw new Error('Fetch tidak tersedia. Gunakan Node 18+ atau install node-fetch.');

  const conf = versiConfig(versi);
  if(!conf?.domain || !conf?.apikey || !conf?.loc || !conf?.egg || !conf?.nestid) {
    throw new Error('Config panel belum lengkap (domain/apikey/loc/egg/nestid).');
  }

  const specs = specsMap[plan.toLowerCase()];
  if(!specs) throw new Error('Paket tidak valid.');

  // dibuat unik biar gak sering bentrok email
  const suffix = crypto.randomBytes(2).toString('hex');
  const email = `${username}${suffix}@gmail.com`;
  const password = `${username}${Math.floor(100 + Math.random() * 900)}`;
  const name = username;

  // Create user
  let res = await $fetch(`${conf.domain}/api/application/users`, {
    method:'POST',
    headers:{
      'Accept':'application/json',
      'Content-Type':'application/json',
      Authorization:`Bearer ${conf.apikey}`
    },
    body:JSON.stringify({
      email,
      username,
      first_name:name,
      last_name:'Bot',
      password,
      language:'en'
    })
  });

  res = await validateResponse(res,'users');
  const user = await res.json();

  // Egg detail
  let eggRes = await $fetch(`${conf.domain}/api/application/nests/${conf.nestid}/eggs/${conf.egg}`, {
    headers:{'Accept':'application/json', Authorization:`Bearer ${conf.apikey}`}
  });
  eggRes = await validateResponse(eggRes,'egg');
  const eggDetail = await eggRes.json();

  // Date
  const now = new Date();
  const tanggalIndo = formatTanggalIndo(now);

  const expiredObj = addDays(now, 30);
  const expiredIndo = formatTanggalIndo(expiredObj);
  const serverDesc = `Expired ${expiredIndo}`; // disimpan ke description, tidak ditampilkan

  // Create server
  let srvRes = await $fetch(`${conf.domain}/api/application/servers`, {
    method:'POST',
    headers:{
      'Accept':'application/json',
      'Content-Type':'application/json',
      Authorization:`Bearer ${conf.apikey}`
    },
    body:JSON.stringify({
      name,
      description: serverDesc,
      user:user.attributes.id,
      egg:parseInt(conf.egg),
      docker_image:eggDetail.attributes.docker_image,
      startup:eggDetail.attributes.startup,
      environment:{
        INST:'npm',
        CMD_RUN:'npm start',
        AUTO_UPDATE:'0',
        USER_UPLOAD:'0'
      },
      limits:{
        memory:specs.ram,
        swap:0,
        disk:specs.disk,
        io:500,
        cpu:specs.cpu
      },
      feature_limits:{ databases:3, backups:3, allocations:2 },
      deploy:{ locations:[parseInt(conf.loc)], dedicated_ip:false, port_range:[] }
    })
  });

  srvRes = await validateResponse(srvRes,'servers');
  const server = await srvRes.json();
  const serverId = server?.attributes?.id ?? server?.attributes?.identifier ?? '-';

  const hasil = `🔐 *BERIKUT DATA AKUN PANEL ANDA*

👤 *Username:* ${user.attributes.username}
🔐 *Password:* ${password}
🆔 *Server ID:* ${serverId}
🗓️ *Tanggal:* ${tanggalIndo}
📴 *Expired:* ${expiredIndo}

🧠 *Spesifikasi:*
• RAM: ${toGB(specs.ram)}
• Disk: ${toGB(specs.disk)}
• CPU: ${specs.cpu}%

🌐 *Link Panel:*
${conf.domain}

📝 *Catatan:*
- Masa aktif 30 hari
- Garansi 15 hari (1x klaim)
- Simpan data ini baik-baik! karena admin hanya mengirim 1x
- Jangan bagikan data ini ke siapa pun meskipun itu teman mu`;

  await sendPanelCard(wafproject, targetJid, {
    text: hasil,
    url: conf.domain,
    username: user.attributes.username,
    password,
    quoted
  });

  addPanelRecord({
    type: 'panel',
    plan,
    versi,
    username: user?.attributes?.username || username,
    password,
    email,
    targetJid,
    by: quoted?.sender || quoted?.key?.participant || null,
    serverId,
    domain: conf.domain,
    serverDescription: serverDesc,
    createdAt: Date.now(),
    createdAtIndo: tanggalIndo,
    expiredAtIndo: expiredIndo
  });

  return true;
}

/* =======================
   HANDLER UTAMA
   ======================= */
let handler = async (m, { wafproject, text, command }) => {
  if (!wafproject) return;

  const isRowner = isRownerFn(m.sender);
  const roles = readJson(rolesPath);
  const saveRoles = () => writeJson(rolesPath, roles);

  const getNum = () => {
    const mj = (m.mentionedJid && m.mentionedJid[0]) ? m.mentionedJid[0].split('@')[0] : null;
    if (mj) return mj;
    const n = text ? String(text).replace(/\D/g, '') : '';
    return n || null;
  };

  const cmd = String(command || '').toLowerCase();
  const arg = String(text || '').trim();

  // ===== ADMIN PANEL =====
  if (cmd === 'addadminpanel') {
    if (!isRowner) return replyText(m, wafproject, 'Hanya owner.');
    const n = getNum();
    if (!n) return replyText(m, wafproject, '*.addadminpanel @/628xxx*');
    roles.adminsPanel = Array.isArray(roles.adminsPanel) ? roles.adminsPanel : [];
    if (!roles.adminsPanel.includes(n)) roles.adminsPanel.push(n);
    saveRoles();
    return replyText(m, wafproject, `✅ @${n} jadi admin panel.`, { mentions: [n + '@s.whatsapp.net'] });
  }

  if (cmd === 'deladminpanel') {
    if (!isRowner) return replyText(m, wafproject, 'Hanya owner.');
    const n = getNum();
    roles.adminsPanel = (roles.adminsPanel || []).filter(x => x !== n);
    saveRoles();
    return replyText(m, wafproject, `✅ @${n} dihapus admin panel.`, { mentions: [n + '@s.whatsapp.net'] });
  }

  if (cmd === 'listadminpanel') {
    if (!isRowner) return replyText(m, wafproject, 'Hanya owner.');
    const list = (roles.adminsPanel || []).map((n, i) => `${i + 1}. @${n}`).join('\n') || '(kosong)';
    return replyText(m, wafproject, `📜 *Daftar Admin Panel*\n\n${list}`, {
      mentions: (roles.adminsPanel || []).map(n => n + '@s.whatsapp.net')
    });
  }

  // ===== PARTNER =====
  if (cmd === 'addpartner') {
    if (!isRowner) return replyText(m, wafproject, 'Hanya owner.');
    const n = getNum();
    if (!n) return replyText(m, wafproject, '*.addpartner @/628xxx*');
    roles.partners = Array.isArray(roles.partners) ? roles.partners : [];
    if (!roles.partners.includes(n)) roles.partners.push(n);
    saveRoles();
    return replyText(m, wafproject, `✅ @${n} jadi partner.`, { mentions: [n + '@s.whatsapp.net'] });
  }

  if (cmd === 'delpartner') {
    if (!isRowner) return replyText(m, wafproject, 'Hanya owner.');
    const n = getNum();
    roles.partners = (roles.partners || []).filter(x => x !== n);
    saveRoles();
    return replyText(m, wafproject, `✅ @${n} dihapus partner.`, { mentions: [n + '@s.whatsapp.net'] });
  }

  if (cmd === 'listpartner') {
    if (!isRowner) return replyText(m, wafproject, 'Hanya owner.');
    const list = (roles.partners || []).map((n, i) => `${i + 1}. @${n}`).join('\n') || '(kosong)';
    return replyText(m, wafproject, `📜 *Daftar Partner*\n\n${list}`, {
      mentions: (roles.partners || []).map(n => n + '@s.whatsapp.net')
    });
  }

  // ===== CADMIN =====
  if (cmd === 'cadmin') {
    const roleNow = getRole(m.sender, { isRowner });
    if (!(roleNow === 'partner' || roleNow === 'rowner')) return replyText(m, wafproject, 'Khusus partner/owner.');
    if (!arg) return replyText(m, wafproject, '*.cadmin <v1-v5> <username>*');

    let raw = arg;
    let versi = 'v1';
    const mV = raw.match(/^(v[1-5])\s+/i);
    if (mV) { versi = mV[1].toLowerCase(); raw = raw.replace(mV[0], '').trim(); }

    const username = raw.toLowerCase().replace(/[^\w.-]/g, '');
    if (!username) return replyText(m, wafproject, 'Username kosong.');

    const $fetch = getFetch();
    if (!$fetch) return replyText(m, wafproject, 'Fetch tidak tersedia. Gunakan Node 18+ atau install node-fetch.');

    const conf = versiConfig(versi);
    if (!conf?.domain || !conf?.apikey) return replyText(m, wafproject, 'Versi panel tidak valid / config belum lengkap.');

    try {
      const suffix = crypto.randomBytes(2).toString('hex');
      const email = `${username}${suffix}@gmail.com`;
      const password = `${username}${Math.floor(100 + Math.random() * 900)}`;

      let res = await $fetch(`${conf.domain}/api/application/users`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Bearer ${conf.apikey}`
        },
        body: JSON.stringify({
          email,
          username,
          first_name: username,
          last_name: 'Admin',
          root_admin: true,
          language: 'en',
          password
        })
      });

      res = await validateResponse(res, 'create-admin');
      const data = await res.json();

      const now = new Date();
      const tanggalIndo = formatTanggalIndo(now);
      const expiredIndo = formatTanggalIndo(addDays(now, 30));
      const serverIdLike = data?.attributes?.id ?? '-';

      const teks = `🔐 *BERIKUT DATA ADMIN PANEL ANDA*

👤 *Username:* ${data.attributes.username}
🔐 *Password:* ${password}
🆔 *Server ID:* ${serverIdLike}
🗓️ *Tanggal:* ${tanggalIndo}
📴 *Expired:* ${expiredIndo}

🌐 *Link Panel:*
${conf.domain}

📝 *Catatan:*
- Masa aktif 30 hari
- Garansi 15 hari (1x klaim)
- Simpan data ini baik-baik! karena admin hanya mengirim 1x
- Dilarang keras membuat akun admin panel, jika ketahuan auto hapus`;

      await sendPanelCard(wafproject, m.sender, {
        text: teks,
        url: conf.domain,
        username: data.attributes.username,
        password,
        quoted: m
      });

      addPanelRecord({
        type: 'cadmin',
        versi,
        username: data?.attributes?.username || username,
        password,
        email,
        targetJid: m.sender,
        by: m.sender,
        serverId: serverIdLike,
        domain: conf.domain,
        createdAt: Date.now(),
        createdAtIndo: tanggalIndo,
        expiredAtIndo: expiredIndo
      });

      return replyText(m, wafproject, '✅ Admin panel berhasil dibuat & dikirim ke private chat');
    } catch (e) {
      console.error(e);
      return replyText(m, wafproject, humanizePanelError(e));
    }
  }

  // ===== PAKET PANEL =====
  const pkgRe = /^(1gb|2gb|3gb|4gb|5gb|6gb|7gb|8gb|9gb|10gb|unli|unlimited)$/i;
  if (pkgRe.test(cmd)) {
    const roleNow = getRole(m.sender, { isRowner });
    if (!(roleNow === 'adminPanel' || roleNow === 'partner' || roleNow === 'rowner')) {
      return replyText(m, wafproject, 'Perintah ini hanya untuk Admin Panel/Partner/Owner.');
    }

    const plan = cmd.toLowerCase();
    const { versi, username, targetJid, targetDisplay } = parseTargetAndUsername(arg, m.sender);
    if (!username) return replyText(m, wafproject, `Format: *.${plan} <v1-v5?> <username> <nomor?>*`);

    try {
      await provisionPanel({ versi, plan, username, targetJid, wafproject, quoted: m });
      if (targetJid === m.sender) return replyText(m, wafproject, '✅ Akun panel berhasil dibuat & dikirim ke private chat');
      return replyText(m, wafproject, `✅ Akun panel berhasil dibuat & dikirim ke private chat (${targetDisplay || 'target'})`);
    } catch (e) {
      console.error(e);
      return replyText(m, wafproject, humanizePanelError(e));
    }
  }

  return;
};

handler.help = [
  'addadminpanel @/nomor',
  'deladminpanel @/nomor',
  'listadminpanel',

  'addpartner @/nomor',
  'delpartner @/nomor',
  'listpartner',

  '1gb <v1-v5?> <username> <nomor?>',
  '2gb <v1-v5?> <username> <nomor?>',
  '3gb <v1-v5?> <username> <nomor?>',
  '4gb <v1-v5?> <username> <nomor?>',
  '5gb <v1-v5?> <username> <nomor?>',
  '6gb <v1-v5?> <username> <nomor?>',
  '7gb <v1-v5?> <username> <nomor?>',
  '8gb <v1-v5?> <username> <nomor?>',
  '9gb <v1-v5?> <username> <nomor?>',
  '10gb <v1-v5?> <username> <nomor?>',

  'unli <v1-v5?> <username> <nomor?>',
  'unlimited <v1-v5?> <username> <nomor?>',

  'cadmin <v1-v5> <username>'
];
handler.category = 'cpanel';
handler.description = 'Create panel (Pterodactyl) + role adminPanel/partner.';
handler.command = /^(addadminpanel|deladminpanel|listadminpanel|addpartner|delpartner|listpartner|1gb|2gb|3gb|4gb|5gb|6gb|7gb|8gb|9gb|10gb|unli|unlimited|cadmin)$/i;
handler.limit = false;

module.exports = handler;