// ✨ Plugin owner - add-del-list prem ✨ (CJS + LID SAFE)
// ================================
// 👑 OWNER PREMIUM MANAGER (LID SAFE + DEL BY INDEX)
// Commands:
// .addprem nomor 30d
// .addprem @user 30d   (LID SAFE: popup mention)
// (reply) .addprem 30d
// .delprem nomor/@user/reply
// .delprem 1  (berdasarkan urutan listprem terakhir di chat itu)
// .listprem
// ================================

const MS = 1000
const MIN = 60 * MS
const HOUR = 60 * MIN
const DAY = 24 * HOUR
const WEEK = 7 * DAY

function parseDuration(input = '') {
  const s = String(input).trim().toLowerCase()
  const m = s.match(/^(\d+)(s|m|h|d|w|mo|y)$/)
  if (!m) return 0

  const n = parseInt(m[1], 10)
  const u = m[2]
  if (!Number.isFinite(n) || n <= 0) return 0

  switch (u) {
    case 's': return n * MS
    case 'm': return n * MIN
    case 'h': return n * HOUR
    case 'd': return n * DAY
    case 'w': return n * WEEK
    case 'mo': return n * 30 * DAY
    case 'y': return n * 365 * DAY
    default: return 0
  }
}

function formatRemaining(ms) {
  if (ms <= 0) return 'expired'
  let t = ms
  const d = Math.floor(t / DAY); t %= DAY
  const h = Math.floor(t / HOUR); t %= HOUR
  const m = Math.floor(t / MIN)
  return [d && `${d}d`, h && `${h}h`, `${m}m`].filter(Boolean).join(' ')
}

function normalizeJidFromNumber(input) {
  const num = String(input || '').replace(/[^0-9]/g, '')
  if (!num) return null
  return num + '@s.whatsapp.net'
}

function ensureUser(db, jid) {
  const root = db?.list ? db.list() : (db?.data || {})
  root.user ||= {}
  root.user[jid] ||= {}

  const u = root.user[jid]
  if (typeof u.premiumTime !== 'number') u.premiumTime = 0
  if (typeof u.premium !== 'boolean') u.premium = false
  return u
}

// cache listprem per chat (RAM)
function getCacheRoot(wafproject) {
  wafproject._premCache = wafproject._premCache || {}
  return wafproject._premCache
}
function setListCache(wafproject, chatId, arr) {
  const root = getCacheRoot(wafproject)
  root[chatId] = { ts: Date.now(), list: Array.isArray(arr) ? arr : [] }
}
function getListCache(wafproject, chatId) {
  const root = getCacheRoot(wafproject)
  return root[chatId] || null
}

// ================================
// ✅ LID SAFE RESOLVER
// - mention popup di grup sekarang sering 'xxxx@lid'
// - kita ubah jadi jid asli '62xxx@s.whatsapp.net' via groupMetadata.participants
// ================================
async function resolveToRealJid(wafproject, m, rawJid) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith('@s.whatsapp.net')) return s

  // kalau bukan grup, ga bisa resolve peserta
  if (!m.isGroup) return s

  let meta
  try {
    meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const participants = meta?.participants || []

  // cari yang cocok di lid/id/jid
  const found = participants.find(p =>
    p?.lid === s ||
    p?.id === s ||
    p?.jid === s ||
    p?.participant === s
  )

  return found?.jid || found?.id || found?.participant || s
}

async function getTargetJid(wafproject, m, args) {
  // PRIORITAS:
  // 1) reply
  // 2) mention
  // 3) nomor manual
  let raw = null

  // reply
  if (m.quoted?.sender) raw = m.quoted.sender
  else if (m.quoted?.key?.participant) raw = m.quoted.key.participant

  // mention popup / mention biasa
  else if (m.mentionedJid?.length) raw = m.mentionedJid[0]

  // nomor manual
  else if (args[0]) {
    const n = String(args[0]).replace(/[^0-9]/g, '')
    if (n.length >= 8) return normalizeJidFromNumber(n)
  }

  const real = await resolveToRealJid(wafproject, m, raw)
  if (!real) return null

  // kalau hasil bukan s.whatsapp.net, berarti gagal resolve (lid masih)
  if (!String(real).endsWith('@s.whatsapp.net')) return null
  return real
}

let handler = async (m, { text, usedPrefix, command, wafproject, db }) => {
  const cmd = String(command || '').toLowerCase()
  const args = String(text || '').trim().split(/\s+/).filter(Boolean)

  // =====================
  // LIST PREMIUM
  // =====================
  if (cmd === 'listprem') {
    const root = db?.list ? db.list() : {}
    root.user ||= {}

    const now = Date.now()
    const users = root.user || {}

    const list = Object.entries(users)
      .filter(([jid, u]) =>
        jid &&
        String(jid).endsWith('@s.whatsapp.net') &&
        u &&
        typeof u.premiumTime === 'number' &&
        u.premiumTime > now
      )
      .map(([jid, u]) => ({
        jid,
        exp: u.premiumTime,
        left: u.premiumTime - now
      }))
      .sort((a, b) => a.left - b.left)

    // simpan urutan untuk delprem index
    setListCache(wafproject, m.chat, list.map(v => v.jid))

    if (!list.length) {
      await m.reply('👑 *LIST PREMIUM*\n\nTidak ada user premium aktif.')
      return
    }

    let out = `👑 *LIST PREMIUM (${list.length})*\n\n`
    out += list.map((u, i) => {
      const num = String(u.jid).split('@')[0].replace(/[^0-9]/g, '') || String(u.jid).split('@')[0]
      return (
        `${i + 1}. @${num}\n` +
        `   📱 nomor: *${num}*\n` +
        `   ⏳ sisa: *${formatRemaining(u.left)}*\n` +
        `   🗓️ sampai: *${new Date(u.exp).toLocaleString()}*`
      )
    }).join('\n\n')

    await wafproject.sendMessage(
      m.chat,
      { text: out, mentions: list.map(v => v.jid) },
      { quote: m }
    )
    return
  }

  // =====================
  // ADD PREMIUM
  // =====================
  if (cmd === 'addprem') {
    // minimal harus ada durasi + target (atau reply)
    if (!args.length && !m.quoted && !(m.mentionedJid && m.mentionedJid.length)) {
      await m.reply(
        `❌ *Format salah*\n\n` +
        `Contoh:\n` +
        `${usedPrefix}addprem 6287731282876 30d\n` +
        `${usedPrefix}addprem @user 30d\n` +
        `atau reply user:\n${usedPrefix}addprem 30d\n\n` +
        `Durasi: 30d, 12h, 7d, 1mo`
      )
      return
    }

    // durasi token selalu terakhir
    const durToken = args[args.length - 1]
    const durMs = parseDuration(durToken)

    if (!durMs) {
      await m.reply('❌ Durasi tidak valid.\nContoh: 30d, 12h, 7d, 1mo')
      return
    }

    // kalau user hanya kirim "addprem 30d" tanpa reply → tolak
    if (args.length === 1 && !m.quoted && !(m.mentionedJid && m.mentionedJid.length)) {
      await m.reply(
        `❌ *Target belum ada*\n\n` +
        `Gunakan:\n` +
        `${usedPrefix}addprem @user ${durToken}\n` +
        `${usedPrefix}addprem 628xxxx ${durToken}\n` +
        `atau reply user lalu ketik:\n${usedPrefix}addprem ${durToken}`
      )
      return
    }

    const target = await getTargetJid(wafproject, m, args)
    if (!target) {
      await m.reply(
        `❌ Gagal membaca nomor asli dari mention.\n\n` +
        `Solusi:\n` +
        `1) Mention pakai popup yang benar\n` +
        `2) Atau reply pesan user lalu ketik: ${usedPrefix}addprem ${durToken}\n` +
        `3) Atau pakai nomor: ${usedPrefix}addprem 628xxxx ${durToken}`
      )
      return
    }

    const u = ensureUser(db, target)
    const now = Date.now()
    const base = (u.premiumTime > now) ? u.premiumTime : now

    u.premiumTime = base + durMs
    u.premium = true

    const number = target.split('@')[0]

    await wafproject.sendMessage(
      m.chat,
      {
        text:
          `✅ *Premium ditambahkan*\n` +
          `👤 User: @${number}\n` +
          `📱 Nomor: *${number}*\n` +
          `⏱️ Durasi: *${durToken}*\n` +
          `🗓️ Expired: *${new Date(u.premiumTime).toLocaleString()}*\n` +
          `⏳ Sisa: *${formatRemaining(u.premiumTime - now)}*`,
        mentions: [target]
      },
      { quote: m }
    )

    await db.save?.()
    return
  }

  // =====================
  // DELETE PREMIUM
  // =====================
  if (cmd === 'delprem') {
    const root = db?.list ? db.list() : {}
    root.user ||= {}

    // mode 1: delprem <index> berdasarkan listprem terakhir
    if (args[0] && /^\d+$/.test(args[0])) {
      const idx = parseInt(args[0], 10)
      const cache = getListCache(wafproject, m.chat)

      if (!cache || !Array.isArray(cache.list) || cache.list.length === 0) {
        await m.reply(`Tidak ada cache list premium.\nKetik dulu: *${usedPrefix}listprem*`)
        return
      }

      if (idx < 1 || idx > cache.list.length) {
        await m.reply(`Nomor urut tidak valid. Range: 1-${cache.list.length}`)
        return
      }

      const target = cache.list[idx - 1]
      const u = ensureUser(db, target)

      u.premiumTime = 0
      u.premium = false

      const number = target.split('@')[0]

      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `❌ *Premium dihapus*\n` +
            `👤 User: @${number}\n` +
            `📱 Nomor: *${number}*`,
          mentions: [target]
        },
        { quote: m }
      )

      await db.save?.()
      return
    }

    // mode 2: delprem nomor/@user/reply
    if (!args.length && !m.quoted && !(m.mentionedJid && m.mentionedJid.length)) {
      await m.reply(
        `❌ *Format salah*\n\n` +
        `Gunakan:\n` +
        `${usedPrefix}delprem 1 (pakai nomor urut dari listprem)\n` +
        `${usedPrefix}delprem 628xxxx\n` +
        `${usedPrefix}delprem @user\n` +
        `atau reply user: ${usedPrefix}delprem`
      )
      return
    }

    const target = await getTargetJid(wafproject, m, args)
    if (!target) {
      await m.reply(
        `❌ Gagal membaca nomor asli dari mention.\n\n` +
        `Solusi:\n` +
        `1) Mention pakai popup yang benar\n` +
        `2) Atau reply pesan user lalu ketik: ${usedPrefix}delprem\n` +
        `3) Atau pakai nomor: ${usedPrefix}delprem 628xxxx`
      )
      return
    }

    const u = ensureUser(db, target)
    u.premiumTime = 0
    u.premium = false

    const number = target.split('@')[0]

    await wafproject.sendMessage(
      m.chat,
      {
        text:
          `❌ *Premium dihapus*\n` +
          `👤 User: @${number}\n` +
          `📱 Nomor: *${number}*`,
        mentions: [target]
      },
      { quote: m }
    )

    await db.save?.()
    return
  }
}

handler.help = ['addprem nomor 30d', 'delprem 1', 'listprem']
handler.category = ['owner']
handler.command = /^(addprem|delprem|listprem)$/i
handler.rowner = true

module.exports = handler