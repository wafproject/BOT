/**
 * Plugin SEWA BOT — CJS
 * Penyimpanan tetap: database/sewa.json
 * Semua perubahan data melewati lib/sewa-store agar tidak saling menimpa.
 */

"use strict"

const {
  readSewaResult,
  updateSewa,
} = require("../../lib/sewa-store")

const linkRegex = /chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})(?:\?|$)/i
const groupJidRegex = /^\d+@g\.us$/i

function withTimeout(promise, timeoutMs, fallback = null) {
  let timer
  return Promise.race([
    Promise.resolve(promise),
    new Promise((resolve) => {
      timer = setTimeout(() => resolve(fallback), timeoutMs)
    }),
  ]).finally(() => clearTimeout(timer))
}

function setBypass(gid, durationMs = 90_000) {
  if (!gid) return
  global.__antiCulikBypass ||= {}
  global.__antiCulikBypass[gid] = Date.now() + durationMs
}

function clearBypass(gid) {
  if (!gid || !global.__antiCulikBypass) return
  delete global.__antiCulikBypass[gid]
}

async function getGroupName(wafproject, gid, fallback = "Unknown") {
  try {
    const meta = await withTimeout(wafproject.groupMetadata(gid), 2500, null)
    return meta?.subject || fallback
  } catch {
    return fallback
  }
}

function isTerminalLeaveError(error) {
  const text = String(
    error?.message || error?.output?.payload?.message || error || ""
  ).toLowerCase()
  return /not.?authorized|not.?a.?participant|forbidden|item.?not.?found|status.?code.?40[34]/i.test(text)
}

// Pemeriksa sewa habis. Socket selalu diambil saat interval berjalan,
// bukan menyimpan socket lama saat reconnect.
if (!global.__sewaIntervalStarted) {
  global.__sewaIntervalStarted = true
  global.__sewaExpiryRunning = false

  setInterval(async () => {
    if (global.__sewaExpiryRunning) return
    const wafproject = global.__sewaConn || global.wafproject || global.conn
    if (!wafproject) return

    global.__sewaExpiryRunning = true
    try {
      const read = readSewaResult({ allowCached: false })
      if (!read.ok) {
        console.error("[SEWA EXPIRED] database gagal dibaca; proses leave dibatalkan:", read.error?.message || read.error)
        return
      }

      const now = Date.now()
      const expiredGroups = Object.entries(read.data)
        .filter(([, row]) => Number(row?.expired || 0) > 0 && Number(row.expired) <= now)
        .map(([gid]) => gid)

      for (const gid of expiredGroups) {
        let mayDelete = false
        try {
          await wafproject.sendMessage(gid, {
            text: "⏰ *Waktu sewa bot habis!*\nBot akan keluar dari grup."
          })
          await wafproject.groupLeave(gid)
          mayDelete = true
          console.log(`[SEWA EXPIRED] ${gid} — bot berhasil keluar`)
        } catch (error) {
          mayDelete = isTerminalLeaveError(error)
          console.error(
            `[SEWA EXPIRED] ${gid} — gagal keluar${mayDelete ? " (record tetap dibersihkan karena bot bukan anggota)" : ", akan dicoba lagi"}:`,
            error?.message || error
          )
        }

        if (!mayDelete) continue

        try {
          await updateSewa((data) => {
            // Jangan menghapus bila owner/pembayaran sudah memperpanjang saat proses leave.
            if (Number(data?.[gid]?.expired || 0) <= Date.now()) delete data[gid]
          })
        } catch (error) {
          console.error(`[SEWA EXPIRED] ${gid} — gagal menghapus record:`, error?.message || error)
        }
      }
    } finally {
      global.__sewaExpiryRunning = false
    }
  }, 10_000)
}

let handler = async (m, { wafproject, command, args, groupMetadata, usedPrefix }) => {
  global.__sewaConn = wafproject
  const idChat = m.chat

  switch (command) {
    case "addsewa": {
      if (!args[0]) {
        return wafproject.sendMessage(idChat, {
          text:
            `❌ Format Salah!\n\n` +
            `Di grup target:\n${usedPrefix}addsewa 30d\n\n` +
            `Dari chat mana pun:\n${usedPrefix}addsewa <idgrup> 30d\n` +
            `${usedPrefix}addsewa <linkgc> 30d`
        })
      }

      let targetID = idChat
      let durasiArg = args[0]
      let namaGrup = groupMetadata?.subject || "Unknown"
      let bypassSetFor = null
      let inviteCode = null

      // Mode link undangan.
      const linkMatch = String(args[0]).match(linkRegex)
      if (linkMatch) {
        inviteCode = linkMatch[1]
        if (!args[1]) {
          return wafproject.sendMessage(idChat, {
            text: "❌ Durasi tidak ditemukan!\nContoh: 30d"
          })
        }
        durasiArg = args[1]

        let info
        try {
          info = await wafproject.groupGetInviteInfo(inviteCode)
        } catch (error) {
          console.error("[ADDSEWA INVITE ERROR]", error?.message || error)
          return wafproject.sendMessage(idChat, {
            text:
              `❌ Link tidak valid atau sudah kadaluarsa.\n\n` +
              `Error: ${error?.message || error?.output?.payload?.message || "Unknown Error"}`
          })
        }

        targetID = String(info?.id || "")
        namaGrup = info?.subject || namaGrup
        setBypass(targetID)
        bypassSetFor = targetID

        // Kalau bot belum menjadi anggota, join lebih dulu.
        let alreadyJoined = false
        try {
          const meta = await withTimeout(wafproject.groupMetadata(targetID), 2500, null)
          if (meta) {
            alreadyJoined = true
            namaGrup = meta.subject || namaGrup
          }
        } catch (_error) { console.error("[ERROR][commands/owner/setsewa.js]", _error?.message || _error) }

        if (!alreadyJoined) {
          try {
            const res = await wafproject.groupAcceptInvite(inviteCode)
            targetID = String(res).endsWith("@g.us") ? String(res) : `${res}@g.us`
            if (bypassSetFor !== targetID) {
              clearBypass(bypassSetFor)
              setBypass(targetID)
              bypassSetFor = targetID
            }
            namaGrup = await getGroupName(wafproject, targetID, namaGrup)
          } catch (error) {
            console.error("[ADDSEWA JOIN ERROR]", error?.message || error)
            clearBypass(bypassSetFor)

            const ms = parseDuration(durasiArg)
            if (!ms) {
              return wafproject.sendMessage(idChat, {
                text: "❌ Gagal join grup dan format durasi salah."
              })
            }

            const expired = Date.now() + ms
            try {
              await updateSewa((data) => {
                data[targetID] = {
                  name: namaGrup,
                  expired,
                  status: "pending_join",
                  inviteCode,
                  reason: error?.message || error?.output?.payload?.message || "Unknown Error",
                  createdAt: Date.now()
                }
              })
            } catch (dbError) {
              return wafproject.sendMessage(idChat, {
                text: `❌ Gagal mencatat sewa pending: ${dbError?.message || dbError}`
              })
            }

            return wafproject.sendMessage(idChat, {
              text:
                `⚠️ Bot gagal join grup, tapi sewa tetap dicatat.\n\n` +
                `👥 Grup: *${namaGrup}*\n` +
                `⏰ Durasi: *${durasiArg}*\n` +
                `📅 Expired: *${new Date(expired).toLocaleString()}*\n` +
                `📌 Status: *pending_join*\n\n` +
                `Error: ${error?.message || error?.output?.payload?.message || "Unknown Error"}`
            })
          }
        }
      } else if (groupJidRegex.test(String(args[0]))) {
        // Mode ID grup, digunakan juga oleh pesan peringatan anti-culik.
        if (!args[1]) {
          return wafproject.sendMessage(idChat, {
            text: "❌ Durasi tidak ditemukan!\nContoh: .addsewa 120363xxxx@g.us 30d"
          })
        }
        targetID = String(args[0])
        durasiArg = args[1]
        namaGrup = await getGroupName(wafproject, targetID, namaGrup)
      } else if (!String(idChat).endsWith("@g.us")) {
        return wafproject.sendMessage(idChat, {
          text:
            `❌ Dari private chat, gunakan ID atau link grup.\n\n` +
            `${usedPrefix}addsewa 120363xxxx@g.us 30d\n` +
            `${usedPrefix}addsewa https://chat.whatsapp.com/xxxx 30d`
        })
      }

      const ms = parseDuration(durasiArg)
      if (!ms) {
        clearBypass(bypassSetFor)
        return wafproject.sendMessage(idChat, { text: "❌ Format durasi salah!" })
      }

      const expired = Date.now() + ms
      try {
        await updateSewa((data) => {
          data[targetID] = {
            name: namaGrup,
            expired,
            status: "active",
            createdAt: Date.now()
          }
        })
      } catch (error) {
        clearBypass(bypassSetFor)
        return wafproject.sendMessage(idChat, {
          text: `❌ Gagal menyimpan sewa: ${error?.message || error}`
        })
      }

      clearBypass(bypassSetFor)

      return wafproject.sendMessage(idChat, {
        text:
          `✅ Sewa berhasil ditambahkan.\n\n` +
          `👥 Grup: *${namaGrup}*\n` +
          `🆔 ID: ${targetID}\n` +
          `⏰ Durasi: *${durasiArg}*\n` +
          `📅 Expired: *${new Date(expired).toLocaleString()}*`
      })
    }

    case "tambahsewa": {
      if (!args[0] || !args[1]) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Format salah!\n\nContoh:\n${usedPrefix}tambahsewa 1 30d`
        })
      }

      const read = readSewaResult({ allowCached: false })
      if (!read.ok) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Database sewa gagal dibaca: ${read.error?.message || read.error}`
        })
      }

      const index = parseInt(args[0], 10) - 1
      const tambahan = parseDuration(args[1])
      const gid = Object.keys(read.data)[index]
      if (!gid || !tambahan) {
        return wafproject.sendMessage(idChat, { text: "❌ Nomor atau durasi tidak valid!" })
      }

      let result
      try {
        result = await updateSewa((data) => {
          if (!data[gid]) throw new Error("Data grup berubah; silakan buka listsewa lagi")
          data[gid].expired = Number(data[gid].expired || Date.now()) + tambahan
          return {
            name: data[gid].name || gid,
            expired: data[gid].expired
          }
        })
      } catch (error) {
        return wafproject.sendMessage(idChat, { text: `❌ Gagal menambah sewa: ${error?.message || error}` })
      }

      const sisa = result.expired - Date.now()
      try {
        await wafproject.sendMessage(gid, {
          text:
            `📢 Masa sewa grup diperpanjang!\n\n` +
            `➕ Tambahan: *${args[1]}*\n` +
            `⏳ Sisa baru: *${formatDuration(sisa)}*`
        })
      } catch (error) {
        console.error(`[TAMBAHSEWA NOTIFY] ${gid}:`, error?.message || error)
      }

      return wafproject.sendMessage(idChat, {
        text:
          `✅ Berhasil menambah sewa.\n\n` +
          `Grup: *${result.name}*\n` +
          `Tambahan: *${args[1]}*\n` +
          `Sisa Baru: *${formatDuration(sisa)}*`
      })
    }

    case "delsewa": {
      if (!args[0]) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Gunakan: ${usedPrefix}delsewa <nomor> / <idgrup> / <link>`
        })
      }

      const read = readSewaResult({ allowCached: false })
      if (!read.ok) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Database sewa gagal dibaca: ${read.error?.message || read.error}`
        })
      }

      let targetID = null
      const linkMatch = String(args[0]).match(linkRegex)
      if (linkMatch) {
        try {
          const info = await wafproject.groupGetInviteInfo(linkMatch[1])
          targetID = info.id
        } catch (error) {
          console.error("[DELSEWA INVITE ERROR]", error?.message || error)
          return wafproject.sendMessage(idChat, {
            text: `❌ Link tidak valid.\n\nError: ${error?.message || error?.output?.payload?.message || "Unknown Error"}`
          })
        }
      } else if (groupJidRegex.test(String(args[0]))) {
        targetID = String(args[0])
      } else {
        targetID = Object.keys(read.data)[parseInt(args[0], 10) - 1]
      }

      if (!targetID || !read.data[targetID]) {
        return wafproject.sendMessage(idChat, { text: "❌ Grup tidak ada di listsewa." })
      }

      try {
        await wafproject.sendMessage(targetID, {
          text: "❌ Masa sewa dihapus oleh owner.\nBot akan keluar."
        })
        await wafproject.groupLeave(targetID)
      } catch (error) {
        console.error(`[DELSEWA LEAVE] ${targetID}:`, error?.message || error)
      }

      try {
        await updateSewa((data) => {
          delete data[targetID]
        })
      } catch (error) {
        return wafproject.sendMessage(idChat, { text: `❌ Gagal menghapus data sewa: ${error?.message || error}` })
      }

      return wafproject.sendMessage(idChat, {
        text: "✅ Grup berhasil dihapus dari daftar sewa."
      })
    }
  }
}

handler.help = ["addsewa", "tambahsewa", "delsewa"]
handler.category = ["owner"]
handler.command = ["addsewa", "tambahsewa", "delsewa"]
handler.owner = true

module.exports = handler

function parseDuration(str) {
  const input = String(str || "").trim().toLowerCase()
  if (!input) return null

  let total = 0
  let consumed = ""
  const regex = /(\d+)([dhms])/g
  let match

  while ((match = regex.exec(input)) !== null) {
    consumed += match[0]
    const num = parseInt(match[1], 10)
    const unit = match[2]
    if (unit === "d") total += num * 86400000
    if (unit === "h") total += num * 3600000
    if (unit === "m") total += num * 60000
    if (unit === "s") total += num * 1000
  }

  return consumed === input && total > 0 ? total : null
}

function formatDuration(ms) {
  ms = Math.max(0, Number(ms) || 0)
  const d = Math.floor(ms / 86400000)
  const h = Math.floor((ms % 86400000) / 3600000)
  const m = Math.floor((ms % 3600000) / 60000)
  const s = Math.floor((ms % 60000) / 1000)

  return [
    d ? `${d} Hari` : "",
    h ? `${h} Jam` : "",
    m ? `${m} Menit` : "",
    s ? `${s} Detik` : ""
  ].filter(Boolean).join(" ") || "0 Detik"
}
