/**
 * List GC (owner only) — Admin detector: SAMA PERSIS seperti Anti Foto
 */

const handler = async (m, { wafproject }) => {
  try {
    // Ambil semua group yang diikuti bot
    const groups = await wafproject.groupFetchAllParticipating()
    const groupList = Object.values(groups)

    if (groupList.length === 0) {
      return m.reply('🤖 Bot belum masuk ke grup manapun.')
    }

    // Format pesan
    let text = `📊 *DAFTAR GRUP*\n`
    text += `Total: ${groupList.length} grup\n\n`

    for (let i = 0; i < groupList.length; i++) {
      const group = groupList[i]
      const subject = group.subject || 'Tanpa Nama'
      const participants = group.participants?.length || 0
      const groupId = group.id

      // ✅ cek bot admin pakai getAdminStatus (SAMA PERSIS)
      let botAdmin = false
      try {
        const res = await getAdminStatus(wafproject, groupId, getBotJid(wafproject))
        botAdmin = !!res.isBotAdmin
      } catch {
        botAdmin = false
      }

      text += `*${i + 1}. ${subject}*\n`
      text += `   👥 Anggota: ${participants}\n`
      text += `   🆔 ID: ${groupId}\n`
      text += `   🤖 Bot Admin: ${botAdmin ? '✅' : '❌'}\n`
      text += `   ─────────────\n`
    }

    // Kirim pesan
    await m.reply(text)
  } catch (error) {
    console.error(error)
    m.reply('❌ Gagal mengambil daftar grup: ' + error.message)
  }
}

handler.command = ['listgc', 'daftargroup']
handler.category = 'owner'
handler.description = 'Melihat listgc'
handler.owner = true
handler.limit = false

module.exports = handler

// ======================================================================
// ===== ADMIN READER (SAMAKAN PERSIS SEPERTI PLUGIN ANTI FOTO) =====
// ======================================================================

const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

function getBotJid(wafproject) {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try { meta = await wafproject.groupMetadata(chatJid) } catch { meta = null }
    if (!meta) return { isAdmin: false, isBotAdmin: false, meta: null }

    const participants = meta.participants || []

    const botJid = getBotJid(wafproject)
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderFixed = resolveLidToJid(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, isBotAdmin, meta }
  } catch {
    return { isAdmin: false, isBotAdmin: false, meta: null }
  }
}