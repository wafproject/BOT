/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const fs = require('fs');
const path = require('path');
const { nativeFlowMessage, quickReplyButton } = require('../../lib/zapo-message');

// =======================
// Fetch resolver (no crash)
// =======================
function getFetch() {
  if (typeof fetch === 'function') return fetch;
  try {
    // optional kalau node-fetch terpasang
    // eslint-disable-next-line global-require
    return require('node-fetch');
  } catch {
    return null;
  }
}

// =======================
// Reply helper (wafproject only)
// =======================
async function replyText(m, wafproject, text, extra = {}) {
  try {
    if (typeof wafproject.reply === 'function') return await wafproject.reply(m.chat, String(text), m, extra);
    return await wafproject.sendMessage(m.chat, { text: String(text), ...extra }, { quote: m });
  } catch (_error) { console.error("[ERROR][commands/owner/listpanel.js]", _error?.message || _error) }
}

// =======================
// Role DB (FIX)
// =======================
const { databaseFile } = require('../../lib/project-paths');
const DATA_BASE = databaseFile('pterodactyl');
const rolesPath = path.join(DATA_BASE, 'roles.json');

function ensureDir(d) {
  try { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); } catch (_error) { console.error("[ERROR][commands/owner/listpanel.js]", _error?.message || _error) }
}
function ensureJson(f, init) {
  ensureDir(path.dirname(f));
  if (!fs.existsSync(f)) fs.writeFileSync(f, JSON.stringify(init, null, 2));
}
function readJson(f, fallback = {}) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fallback; }
}

ensureDir(DATA_BASE);
ensureJson(rolesPath, { partners: [], adminsPanel: [] });

// — Robust owner detection (selaras dengan cpanel.js)
function normalizeNum(s) {
  if (s == null) return null;
  let x = String(s).toLowerCase().trim();
  if (/@s\.whatsapp\.net$/.test(x)) x = x.split('@')[0];
  x = x.replace(/[^\d]/g, '');
  if (!x) return null;
  if (x.startsWith('0')) x = '62' + x.slice(1);
  return x;
}
function collectOwnerNumbers() {
  const set = new Set();
  const pushAny = (v) => {
    if (!v) return;
    if (Array.isArray(v)) {
      for (const it of v) pushAny(Array.isArray(it) ? it[0] : it);
      return;
    }
    if (typeof v === 'object') {
      for (const val of Object.values(v)) pushAny(val);
      return;
    }
    const n = normalizeNum(v);
    if (n) set.add(n);
  };
  pushAny(global.rowner);
  pushAny(global.owner);
  pushAny(global.ownerNumber);
  pushAny(global.nomorowner);
  pushAny(global.numberowner);
  return set;
}
function isRownerFn(jid) {
  const me = normalizeNum(String(jid || '').split('@')[0]);
  const owners = collectOwnerNumbers();
  return me && owners.has(me);
}

function getRole(jid) {
  const isRowner = isRownerFn(jid);
  if (isRowner) return 'rowner';

  const num = String(jid || '').split('@')[0];
  const roles = readJson(rolesPath, { partners: [], adminsPanel: [] });

  const partners = Array.isArray(roles.partners) ? roles.partners : [];
  const adminsPanel = Array.isArray(roles.adminsPanel) ? roles.adminsPanel : [];

  if (partners.includes(num)) return 'partner';
  if (adminsPanel.includes(num)) return 'adminPanel';
  return 'guest';
}

// =======================
// Versi config panel
// =======================
function versiConfig(versi) {
  const map = {
    v1: { domain: global.domain,   apikey: global.apikey },
    v2: { domain: global.domainV2, apikey: global.apikeyV2 },
    v3: { domain: global.domainV3, apikey: global.apikeyV3 },
    v4: { domain: global.domainV4, apikey: global.apikeyV4 },
    v5: { domain: global.domainV5, apikey: global.apikeyV5 }
  };
  const c = map[String(versi || '').toLowerCase()];
  if (!c?.domain || !c?.apikey) return null;
  return c;
}

// =======================
// HTTP helpers
// =======================
async function validateResponse(res, url) {
  if (res.ok) return res;
  let txt = '';
  try { txt = await res.text(); } catch (_error) { console.error("[ERROR][commands/owner/listpanel.js]", _error?.message || _error) }
  const err = new Error(`HTTP error ${res.status} at ${url}`);
  err.status = res.status;
  err.url = url;
  err.bodyText = txt;
  try { err.body = JSON.parse(txt); } catch (_error) { console.error("[ERROR][commands/owner/listpanel.js]", _error?.message || _error) }
  throw err;
}
async function validateDeleteResponse(res, url) {
  if ([200, 202, 204].includes(res.status)) return res;
  return validateResponse(res, url);
}

// =======================
// Ptero ops
// =======================
async function fetchAllServers(conf) {
  const $fetch = getFetch();
  if (!$fetch) throw new Error('Fetch tidak tersedia. Gunakan Node 18+ atau install node-fetch.');

  const perPage = 50;
  const firstUrl = `${conf.domain}/api/application/servers?page=1&per_page=${perPage}`;
  let res = await $fetch(firstUrl, {
    headers: { Accept: 'application/json', Authorization: `Bearer ${conf.apikey}` }
  });
  res = await validateResponse(res, firstUrl);
  const first = await res.json();

  const totalPages = first?.meta?.pagination?.total_pages || 1;
  const list = Array.isArray(first?.data) ? first.data.slice() : [];
  for (let p = 2; p <= totalPages; p++) {
    const url = `${conf.domain}/api/application/servers?page=${p}&per_page=${perPage}`;
    let r = await $fetch(url, {
      headers: { Accept: 'application/json', Authorization: `Bearer ${conf.apikey}` }
    });
    r = await validateResponse(r, url);
    const js = await r.json();
    if (Array.isArray(js?.data)) list.push(...js.data);
  }
  return list;
}

async function getServerDetail(conf, id) {
  const $fetch = getFetch();
  if (!$fetch) throw new Error('Fetch tidak tersedia. Gunakan Node 18+ atau install node-fetch.');

  const url = `${conf.domain}/api/application/servers/${id}`;
  let res = await $fetch(url, {
    headers: { Accept: 'application/json', Authorization: `Bearer ${conf.apikey}` }
  });
  if (!res.ok) return null;
  const js = await res.json().catch(() => null);
  return js?.attributes || null;
}

async function deleteServer(conf, id) {
  const $fetch = getFetch();
  if (!$fetch) throw new Error('Fetch tidak tersedia. Gunakan Node 18+ atau install node-fetch.');

  // coba force
  const urlForce = `${conf.domain}/api/application/servers/${id}?force=true`;
  let res = await $fetch(urlForce, {
    method: 'DELETE',
    headers: { Accept: 'application/json', Authorization: `Bearer ${conf.apikey}` }
  });
  if ([200, 202, 204].includes(res.status)) return true;

  // fallback tanpa force
  const url = `${conf.domain}/api/application/servers/${id}`;
  res = await $fetch(url, {
    method: 'DELETE',
    headers: { Accept: 'application/json', Authorization: `Bearer ${conf.apikey}` }
  });
  await validateDeleteResponse(res, url);
  return true;
}

async function deleteUser(conf, userId) {
  const $fetch = getFetch();
  if (!$fetch) throw new Error('Fetch tidak tersedia. Gunakan Node 18+ atau install node-fetch.');

  const url = `${conf.domain}/api/application/users/${userId}`;
  const res = await $fetch(url, {
    method: 'DELETE',
    headers: { Accept: 'application/json', Authorization: `Bearer ${conf.apikey}` }
  });
  await validateDeleteResponse(res, url);
  return true;
}

// =======================
// UI helpers
// =======================
async function sendChunked(wafproject, chat, quoted, header, lines, maxLen = 3500) {
  let buf = header ? header + '\n\n' : '';
  for (const ln of lines) {
    if ((buf + ln + '\n\n').length > maxLen) {
      await wafproject.sendMessage(chat, { text: buf.trim() }, { quoted });
      buf = '';
    }
    buf += ln + '\n\n';
  }
  if (buf.trim()) await wafproject.sendMessage(chat, { text: buf.trim() }, { quoted });
}

// Ambil selectedButtonId dari berbagai bentuk (payload WhatsApp varian)
function getSelectedButtonId(m) {
  return (
    m?.message?.buttonsResponseMessage?.selectedButtonId ||
    m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId ||
    m?.selectedButtonId ||
    m?.msg?.selectedButtonId ||
    null
  );
}

// Pending konfirmasi (bersih otomatis 3 menit)
const pendingDel = new Map(); // key: chat|sender → {versi, id, name, userId, t}
function setPending(chat, sender, data) {
  const key = `${chat}|${sender}`;
  pendingDel.set(key, { ...data, t: Date.now() });
  setTimeout(() => {
    const cur = pendingDel.get(key);
    if (cur && Date.now() - cur.t >= 180000) pendingDel.delete(key);
  }, 180000);
}
function getPending(chat, sender) {
  return pendingDel.get(`${chat}|${sender}`);
}
function clearPending(chat, sender) {
  pendingDel.delete(`${chat}|${sender}`);
}

// =======================
// Handler utama
// =======================
let handler = async (m, { wafproject, command, args }) => {
  const role = getRole(m.sender);
  if (!(role === 'adminPanel' || role === 'partner' || role === 'rowner')) {
    return replyText(m, wafproject, 'Perintah ini khusus *admin panel/partner/owner*.');
  }

  const cmd = String(command || '').toLowerCase();

  // ===== .listpanel [v1-v5] =====
  if (/^(listpanel|listp|listserver)$/.test(cmd)) {
    let versi = 'v1';
    const a0 = (args?.[0] || '').toLowerCase();
    if (/^v[1-5]$/.test(a0)) versi = a0;

    const conf = versiConfig(versi);
    if (!conf) return replyText(m, wafproject, 'Versi panel tidak valid. Gunakan v1 - v5.');

    try {
      const arr = await fetchAllServers(conf);
      if (!arr.length) return replyText(m, wafproject, `Tidak ada server pada ${versi.toUpperCase()}.`);

      const lines = arr.map((it, i) => {
        const a = it.attributes || {};
        const lim = a.limits || {};
        const name = a.name || '-';
        const id = a.id;
        const user = a.user ?? a.user_id ?? '-';
        const mem = lim.memory ?? 0;
        const disk = lim.disk ?? 0;
        const cpu = lim.cpu ?? 0;
        return `${i + 1}. *${name}* (ID: ${id})
   user: ${user} • mem: ${mem}MB • disk: ${disk}MB • cpu: ${cpu}%`;
      });

      const header = `🗂️ *List Server ${versi.toUpperCase()}* — Total: ${arr.length}`;
      await sendChunked(wafproject, m.chat, m, header, lines);
    } catch (e) {
      console.error('listpanel error:', e);
      return replyText(m, wafproject, e?.message?.includes('Fetch tidak tersedia')
        ? e.message
        : 'Gagal mengambil daftar server.'
      );
    }
    return;
  }

  // ===== .delpanel [v1-v5] <server_id> → tampilkan tombol =====
  if (/^(delpanel|delserver)$/.test(cmd)) {
    if (!args?.length) {
      return replyText(
        m, wafproject,
        'Format: *.delpanel [v1-v5] <server_id>*\nContoh: *.delpanel v2 36* atau *.delpanel 36*'
      );
    }

    let versi = 'v1';
    let idStr = args[0];

    if (/^v[1-5]$/i.test(args[0])) {
      versi = args[0].toLowerCase();
      idStr = args[1];
    }

    if (!idStr || !/^\d+$/.test(idStr)) return replyText(m, wafproject, 'ID server harus berupa angka.');

    const serverId = parseInt(idStr, 10);
    const conf = versiConfig(versi);
    if (!conf) return replyText(m, wafproject, 'Versi panel tidak valid. Gunakan v1 - v5.');

    try {
      const detail = await getServerDetail(conf, serverId);
      const name   = detail?.name || '-';
      const userId = detail?.user ?? detail?.user_id ?? null;

      setPending(m.chat, m.sender, { versi, id: serverId, name, userId });

      const text = `Konfirmasi hapus *${name}* (ID: ${serverId}) pada ${versi.toUpperCase()}.\nPilih salah satu:`;
      const buttons = [
        quickReplyButton('Hanya hapus server', `delpanel|server|${versi}|${serverId}`),
        quickReplyButton('Hapus users + server', `delpanel|full|${versi}|${serverId}`)
      ];

      await wafproject.sendMessage(m.chat, nativeFlowMessage({ text, buttons }), { quote: m });
    } catch (e) {
      console.error('delpanel prepare error:', e);
      return replyText(m, wafproject, e?.message?.includes('Fetch tidak tersedia')
        ? e.message
        : 'Gagal menyiapkan penghapusan (detail server tidak terbaca).'
      );
    }
    return;
  }
};

// =======================
// Listener tombol (before)
// =======================
handler.before = async (m, { wafproject }) => {
  const role = getRole(m.sender);
  if (!(role === 'adminPanel' || role === 'partner' || role === 'rowner')) return;

  const id = getSelectedButtonId(m);
  if (!id || !id.startsWith('delpanel|')) return;

  const parts = id.split('|'); // ["delpanel", mode, versi, serverId]
  const mode = parts[1];       // "server" | "full"
  const versi = parts[2];
  const serverId = parseInt(parts[3] || '0', 10);
  if (!/^v[1-5]$/.test(versi) || !serverId) return;

  const conf = versiConfig(versi);
  if (!conf) return replyText(m, wafproject, 'Konfigurasi versi panel tidak valid.');

  // ambil data pending
  const pending = getPending(m.chat, m.sender);
  let name = pending?.name || '-';
  let userId = pending?.userId || null;

  try {
    // kalau pending expired, ambil detail lagi
    if (!pending) {
      const detail = await getServerDetail(conf, serverId);
      name   = detail?.name || '-';
      userId = detail?.user ?? detail?.user_id ?? null;
    }

    if (mode === 'server') {
      await deleteServer(conf, serverId);
      await replyText(m, wafproject, `🗑️ Server *${name}* (ID: ${serverId}) pada ${versi.toUpperCase()} *berhasil dihapus*.`);
    } else if (mode === 'full') {
      await deleteServer(conf, serverId);

      let userMsg = '';
      if (userId) {
        try {
          await deleteUser(conf, userId);
          userMsg = `\n👤 User (ID: ${userId}) juga *berhasil dihapus*.`;
        } catch (e) {
          console.error('delete user error:', e);
          userMsg = `\n⚠️ Gagal menghapus user (ID: ${userId}). Mungkin masih punya server lain.`;
        }
      } else {
        userMsg = `\nℹ️ ID user tidak diketahui, hanya server yang dihapus.`;
      }

      await replyText(
        m, wafproject,
        `🗑️ Server *${name}* (ID: ${serverId}) pada ${versi.toUpperCase()} *berhasil dihapus*.${userMsg}`
      );
    }
  } catch (e) {
    console.error('delpanel action error:', e);
    let msg = 'Gagal mengeksekusi penghapusan.';
    if (e?.body?.errors && Array.isArray(e.body.errors) && e.body.errors.length) {
      const reason = e.body.errors.map(x => x?.detail).filter(Boolean).join(' | ');
      if (reason) msg += `\nAlasan: ${reason}`;
    } else if (e?.message?.includes('Fetch tidak tersedia')) {
      msg = e.message;
    }
    await replyText(m, wafproject, msg);
  } finally {
    clearPending(m.chat, m.sender);
  }
};

// =======================
// Metadata plugin
// =======================
handler.help = [
  'listpanel [v1-v5]',
  'delpanel [v1-v5] <server_id>  → muncul tombol'
];
handler.category = 'owner';
handler.description = 'List & delete server Pterodactyl + tombol konfirmasi (roles.json).';
handler.command = /^(listpanel|listp|listserver|delpanel|delserver)$/i;
handler.limit = false;

module.exports = handler;