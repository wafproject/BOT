// commands/owner/clear-lid.js
// ✅ CLEAR LID (SAFE) — hapus key/entry yang mengandung "@lid" dari database utama
// - Database aktif kamu: /database/database.json (bukan ./database.json)
// - Backup otomatis ke: /database/backup/database-YYYYMMDD-HHMMSS.json
// - Aman: hanya menghapus KEY yang mengandung "@lid" + array string yang mengandung "@lid"
// - Tidak mengubah struktur lain

const fs = require("fs")
const path = require("path")

function tsStamp() {
  const d = new Date()
  const pad = (n) => String(n).padStart(2, "0")
  return (
    d.getFullYear() +
    pad(d.getMonth() + 1) +
    pad(d.getDate()) +
    "-" +
    pad(d.getHours()) +
    pad(d.getMinutes()) +
    pad(d.getSeconds())
  )
}

function isObject(x) {
  return x && typeof x === "object" && !Array.isArray(x)
}

/**
 * Remove:
 * 1) object keys that contain "@lid"
 * 2) array elements that are string and contain "@lid"
 *
 * Returns { removedKeys, removedArrayItems }
 */
function deepCleanLid(node) {
  let removedKeys = 0
  let removedArrayItems = 0

  const walk = (cur) => {
    if (Array.isArray(cur)) {
      // remove string entries containing @lid
      for (let i = cur.length - 1; i >= 0; i--) {
        const v = cur[i]
        if (typeof v === "string" && v.includes("@lid")) {
          cur.splice(i, 1)
          removedArrayItems++
          continue
        }
        if (isObject(v) || Array.isArray(v)) walk(v)
      }
      return
    }

    if (isObject(cur)) {
      for (const k of Object.keys(cur)) {
        if (String(k).includes("@lid")) {
          delete cur[k]
          removedKeys++
          continue
        }
        const v = cur[k]
        if (isObject(v) || Array.isArray(v)) walk(v)
      }
      return
    }
  }

  walk(node)
  return { removedKeys, removedArrayItems }
}

let handler = async (m, { wafproject, usedPrefix, command }) => {
  // Lokasi database utama (sesuai info kamu)
  const DB_PATH = path.resolve(process.cwd(), "database", "database.json")
  const BACKUP_DIR = path.resolve(process.cwd(), "database", "backup")
  const BACKUP_PATH = path.resolve(BACKUP_DIR, `database-${tsStamp()}.json`)

  // Validasi file ada
  if (!fs.existsSync(DB_PATH)) {
    await m.reply(
      `❌ Database tidak ditemukan.\n\n` +
        `Aku cari di:\n` +
        `- ${DB_PATH}\n\n` +
        `Cek folder /database/database.json kamu.`
    )
    return
  }

  // Read + parse aman
  let raw
  let data
  try {
    raw = fs.readFileSync(DB_PATH, "utf-8")
    data = raw ? JSON.parse(raw) : {}
  } catch (e) {
    await m.reply(
      `❌ Gagal baca/parse database.\n\n` +
        `Path: ${DB_PATH}\n` +
        `Error: ${String(e?.message || e)}`
    )
    return
  }

  // Backup dulu (biar aman)
  let backupStatus = ""
  try {
    if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true })
    fs.writeFileSync(BACKUP_PATH, JSON.stringify(data, null, 2), "utf-8")
    backupStatus = `✅ ${BACKUP_PATH}`
  } catch (e) {
    backupStatus = `⚠️ (skip / gagal dibuat) — ${String(e?.message || e)}`
  }

  // Clean
  const beforeStr = JSON.stringify(data)
  const { removedKeys, removedArrayItems } = deepCleanLid(data)
  const afterStr = JSON.stringify(data)

  // Kalau tidak ada perubahan
  if (beforeStr === afterStr) {
    await m.reply(
      `✅ *CLEAR LID SELESAI*\n\n` +
        `Tidak ada data "@lid" yang perlu dihapus.\n\n` +
        `📌 Database: ${DB_PATH}\n` +
        `🗂️ Backup: ${backupStatus}`
    )
    return
  }

  // Save ke database utama yang benar
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8")
  } catch (e) {
    await m.reply(
      `❌ Gagal menyimpan database.\n\n` +
        `📌 Target save: ${DB_PATH}\n` +
        `🗂️ Backup: ${backupStatus}\n` +
        `Error: ${String(e?.message || e)}`
    )
    return
  }

  await m.reply(
    `✅ *CLEAR LID BERHASIL*\n\n` +
      `Terhapus:\n` +
      `- *${removedKeys}* key mengandung "@lid"\n` +
      `- *${removedArrayItems}* item array "@lid"\n\n` +
      `Save: *${DB_PATH}*\n` +
      `Backup: *${backupStatus}*`
  )
}

handler.help = ["clearlid"]
handler.category = ["owner"]
handler.command = /^(clearlid|clear-lid|hapuslid|hapus-lid)$/i
handler.rowner = true

module.exports = handler