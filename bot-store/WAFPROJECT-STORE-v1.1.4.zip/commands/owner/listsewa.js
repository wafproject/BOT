/**
 * Plugin LISTSEWA — CJS
 * Penyimpanan tetap: database/sewa.json
 */

"use strict"

const { readSewaResult, updateSewa } = require("../../lib/sewa-store")

function withTimeout(promise, timeoutMs, fallback = null) {
  let timer
  return Promise.race([
    Promise.resolve(promise),
    new Promise((resolve) => {
      timer = setTimeout(() => resolve(fallback), timeoutMs)
    }),
  ]).finally(() => clearTimeout(timer))
}

let handler = async (m, { wafproject }) => {
  try {
    const read = readSewaResult({ allowCached: false })
    if (!read.ok) {
      return wafproject.sendMessage(m.chat, {
        text: `❌ Database sewa gagal dibaca: ${read.error?.message || read.error}`
      })
    }

    const sewa = read.data
    const now = Date.now()
    const activeEntries = Object.entries(sewa).filter(([, row]) => {
      return Number(row?.expired || 0) > now
    })

    if (!activeEntries.length) {
      return wafproject.sendMessage(m.chat, { text: "❌ Tidak ada grup aktif dalam list sewa." })
    }

    let teks = "📋 *DAFTAR SEWA GRUP*\n\n"
    const nameUpdates = {}
    let i = 1

    for (const [gid, row] of activeEntries) {
      let name = row?.name || "Unknown"
      try {
        const meta = await withTimeout(wafproject.groupMetadata(gid), 2500, null)
        if (meta?.subject) {
          name = meta.subject
          if (row.name !== name) nameUpdates[gid] = name
        }
      } catch (error) {
        console.warn(`[LISTSEWA META] ${gid}: ${error?.message || error}`)
      }

      const sisa = Number(row.expired) - now
      teks +=
        `${i++}. *${name}*\n` +
        `ID: ${gid}\n` +
        `Expired: ${new Date(row.expired).toLocaleString()}\n` +
        `Sisa: ${formatDuration(sisa)}\n\n`
    }

    if (Object.keys(nameUpdates).length) {
      try {
        await updateSewa((data) => {
          for (const [gid, name] of Object.entries(nameUpdates)) {
            if (data[gid]) data[gid].name = name
          }
        })
      } catch (error) {
        console.error("[LISTSEWA UPDATE NAME]", error?.message || error)
      }
    }

    return wafproject.sendMessage(m.chat, { text: teks.trim() })
  } catch (error) {
    console.error("[LISTSEWA ERROR]", error?.message || error)
    return m.reply("❌ Gagal mengambil list sewa.")
  }
}

handler.help = ["listsewa"]
handler.category = ["owner"]
handler.command = ["listsewa"]
handler.owner = true

module.exports = handler

function formatDuration(ms) {
  ms = Math.max(0, Number(ms) || 0)
  const d = Math.floor(ms / 86400000)
  const h = Math.floor((ms % 86400000) / 3600000)
  const m = Math.floor((ms % 3600000) / 60000)
  const s = Math.floor((ms % 60000) / 1000)
  return [
    d ? `${d} Hari` : "",
    h ? `${h} Jam` : "",
    m ? `${m} Menit` : "",
    s ? `${s} Detik` : ""
  ].filter(Boolean).join(" ") || "0 Detik"
}
