/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

// commands/owner/setnamabot.js

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  const conn = wafproject

  try {
    const name = String(text || "").trim()

    if (!name) {
      return conn.sendMessage(
        m.chat,
        {
          text:
`❌ Masukkan nama bot.

Contoh:
${usedPrefix + command} WAF PROJECT BOT`
        },
        { quote: m }
      )
    }

    if (name.length > 25) {
      return conn.sendMessage(
        m.chat,
        { text: "❌ Nama terlalu panjang. Maksimal 25 karakter." },
        { quote: m }
      )
    }

    await conn.updateProfileName(name)

    return conn.sendMessage(
      m.chat,
      { text: `✅ Nama bot berhasil diubah menjadi *${name}*` },
      { quote: m }
    )
  } catch (e) {
    console.error("setnamabot error:", e)

    return wafproject.sendMessage(
      m.chat,
      {
        text: `❌ Gagal mengganti nama bot.\n${e.message || e}`
      },
      { quote: m }
    )
  }
}

handler.help = ["setnamabot"]
handler.tags = ["owner"]
handler.category = "owner"
handler.command = /^(setnamabot)$/i
handler.rowner = true
handler.owner = true

module.exports = handler