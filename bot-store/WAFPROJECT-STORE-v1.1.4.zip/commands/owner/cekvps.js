/**
========================
🚀 WAF PROJECT - CEK VPS
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const os = require('os')
const { execSync } = require('child_process')

function bytesToSize(bytes = 0) {
  const b = Number(bytes) || 0
  if (b <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.floor(Math.log(b) / Math.log(1024))
  const v = b / Math.pow(1024, i)
  return `${v.toFixed(i >= 3 ? 2 : 0)} ${units[i]}`
}

function formatUptime(sec = 0) {
  sec = Math.max(0, Math.floor(Number(sec) || 0))
  const d = Math.floor(sec / 86400)
  sec %= 86400
  const h = Math.floor(sec / 3600)
  sec %= 3600
  const m = Math.floor(sec / 60)
  const s = sec % 60
  const parts = []
  if (d) parts.push(`${d}d`)
  if (h) parts.push(`${h}h`)
  if (m) parts.push(`${m}m`)
  parts.push(`${s}s`)
  return parts.join(' ')
}

function safeExec(cmd) {
  try {
    return String(execSync(cmd, { stdio: ['ignore', 'pipe', 'ignore'] }) || '').trim()
  } catch {
    return ''
  }
}

function getOSPretty() {
  // coba linux release dulu
  const lsb = safeExec('cat /etc/os-release 2>/dev/null | grep -E "^PRETTY_NAME=" | cut -d= -f2- | tr -d \'"\'')
  if (lsb) return lsb
  return `${os.type()} ${os.release()}`
}

function getDiskRoot() {
  // output: "SIZE USED AVAIL USE% MOUNT"
  const out = safeExec('df -h / 2>/dev/null | tail -n 1')
  if (!out) return null
  const parts = out.split(/\s+/)
  // [Filesystem, Size, Used, Avail, Use%, Mounted]
  if (parts.length < 6) return null
  return {
    size: parts[1],
    used: parts[2],
    avail: parts[3],
    usep: parts[4],
    mount: parts[5],
  }
}

function getPublicIP() {
  // tanpa node-fetch: pakai curl / wget kalau ada
  let ip = safeExec('curl -s https://api.ipify.org 2>/dev/null')
  if (!ip) ip = safeExec('wget -qO- https://api.ipify.org 2>/dev/null')
  return ip || '-'
}

function getLocalIP() {
  const nets = os.networkInterfaces()
  for (const name of Object.keys(nets)) {
    for (const n of nets[name] || []) {
      if (!n.internal && n.family === 'IPv4') return n.address
    }
  }
  return '-'
}

const handler = async (m, { wafproject }) => {
  try {
    await wafproject.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {})

    const osPretty = getOSPretty()
    const kernel = os.release()
    const arch = os.arch()

    const cpu = os.cpus() || []
    const cpuModel = cpu[0]?.model || '-'
    const cores = cpu.length || '-'

    const totalMem = os.totalmem()
    const freeMem = os.freemem()
    const usedMem = totalMem - freeMem

    const load = os.loadavg() // [1,5,15] (linux)
    const uptime = os.uptime()

    const disk = getDiskRoot()
    const localIP = getLocalIP()
    const publicIP = getPublicIP()

    // CPU usage pendek (estimasi) pakai top kalau ada
    let cpuUse = ''
    const top = safeExec(`top -bn1 2>/dev/null | grep "Cpu(s)" | head -n 1`)
    if (top) cpuUse = top.replace(/\s+/g, ' ').trim()

    const text =
`🖥️ *CEK VPS / SERVER*

*OS*      : ${osPretty} (${arch})
*Kernel*  : ${kernel}
*Node*    : ${process.version}

*CPU*     : ${cpuModel}
*Cores*   : ${cores}
${cpuUse ? `*CPU Info*: ${cpuUse}\n` : ''}*Load*    : ${load.map(x => x.toFixed(2)).join(' / ')} (1m/5m/15m)

*RAM*     : ${bytesToSize(usedMem)} / ${bytesToSize(totalMem)} (free ${bytesToSize(freeMem)})
*Disk*    : ${
  disk
    ? `${disk.used} / ${disk.size} (free ${disk.avail}) [${disk.usep}] mount ${disk.mount}`
    : '-'
}

*Uptime*  : ${formatUptime(uptime)}
*IP Local*: ${localIP}
*IP Pub*  : ${publicIP}`

    await wafproject.sendMessage(m.chat, { text }, { quote: m })
    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {})
  } catch (e) {
    console.error('VPS ERROR:', e)
    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
    await wafproject.sendMessage(m.chat, { text: '❌ Gagal cek VPS. Coba lagi.' }, { quote: m })
  }
}

handler.help = ['vps', 'cekvps']
handler.category = ['owner']
handler.command = /^(vps|cekvps)$/i
handler.owner = true
handler.group = false
handler.private = false
handler.limit = false

module.exports = handler