// commands/owner/autobackup.js
// ✨ Plugin bot - autobackup (CommonJS) ✨
// FIX:
// ✅ scheduler pakai node-schedule (tiap menit) + moment-timezone
// ✅ anti double walau hot-reload: cancel job lama (global.__autoBackupJob)
// ✅ log harian per jam backup (anti spam / double kirim)
// ✅ owner jid diambil dari global.nomorown (settings kamu) → fallback global.owner/global.rowner/db
// ✅ tunggu wafproject siap (global.wafproject.user.id)

const fs = require('fs')
const path = require('path')
const schedule = require('node-schedule')
const moment = require('moment-timezone')
const zlib = require('zlib')

// ===== Config =====
const BOT_NAME = 'WAFPROJECT'
const TZ_OFFSET_MIN = 7 * 60 // WIB UTC+7 (dipakai untuk format caption yg udah ada)
const BACKUP_TIMES = ['00:00', '06:00', '12:00', '18:00']

// ================= ZONA WAKTU (samakan node-schedule style) =================
const TIMEZONE = (global.getZonaWaktu && global.getZonaWaktu()) || 'Asia/Jakarta'
if (!moment.tz.zone(TIMEZONE)) {
  throw new Error(`Zona waktu ${TIMEZONE} tidak valid`)
}

// Folder temp untuk zip
const TMP_DIR = path.join(__dirname, '../../backup')
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true })

// Whitelist yang ikut dibackup
const WHITELIST_DIRS = [
  'assets', 'container', 'data_antispam', 'database', 'function', 'lib',
  'media', 'plugins', 'pterodactyl', 'scrape', 'src', 'temp', 'commands', 'scripts'
]
const WHITELIST_FILES = [
  'database.json', 'index.js', 'package.json', 'package-lock.json',
  'settings.js', 'config.js'
]

// ===================== Format Indonesia =====================
const ID_MONTHS = [
  'Januari','Februari','Maret','April','Mei','Juni',
  'Juli','Agustus','September','Oktober','November','Desember'
]
const ID_DAYS = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu']
const pad2 = (n) => String(n).padStart(2, '0')

// Convert Date -> WIB Date object (manual offset)
function toWIBDate(date = new Date()) {
  const utc = date.getTime() + (date.getTimezoneOffset() * 60000)
  return new Date(utc + TZ_OFFSET_MIN * 60000)
}

function formatIndoDateTimeWIB(dateObj) {
  const d = dateObj
  const dayName = ID_DAYS[d.getDay()]
  const day = pad2(d.getDate())
  const month = ID_MONTHS[d.getMonth()]
  const year = d.getFullYear()
  const hh = pad2(d.getHours())
  const mm = pad2(d.getMinutes())
  return `${dayName}, ${day} ${month} ${year} • ${hh}:${mm} WIB`
}

function formatIndoDateWIB(dateObj) {
  const d = dateObj
  const day = pad2(d.getDate())
  const month = ID_MONTHS[d.getMonth()]
  const year = d.getFullYear()
  return `${day} ${month} ${year}`
}

function keyWIB(date = new Date()) {
  const d = toWIBDate(date)
  return `${d.getFullYear()}${pad2(d.getMonth()+1)}${pad2(d.getDate())}-${pad2(d.getHours())}:${pad2(d.getMinutes())}`
}

// ===================== ZIP (Deflate level 9, kompres maksimal) =====================
const CRC_TABLE = (() => {
  let c; const t = new Array(256)
  for (let n = 0; n < 256; n++) {
    c = n
    for (let k = 0; k < 8; k++)
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1)
    t[n] = c >>> 0
  }
  return t
})()

function crc32(buf) {
  let crc = 0 ^ (-1)
  for (let i = 0; i < buf.length; i++)
    crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ buf[i]) & 0xFF]
  return (crc ^ (-1)) >>> 0
}

function toDosDateTime(date = new Date()) {
  const y = Math.max(1980, date.getFullYear())
  const m = date.getMonth() + 1
  const d = date.getDate()
  const h = date.getHours()
  const min = date.getMinutes()
  const s = Math.floor(date.getSeconds() / 2)
  return {
    dosTime: (h << 11) | (min << 5) | s,
    dosDate: ((y - 1980) << 9) | (m << 5) | d
  }
}

function createZipFile(filesMap, outPath, modDate = new Date()) {
  const localParts = [], centralParts = []
  let offset = 0
  const { dosTime, dosDate } = toDosDateTime(modDate)
  const entries = []

  for (const [name, content] of Object.entries(filesMap)) {
    const nameBuf = Buffer.from(String(name))
    const data = Buffer.isBuffer(content) ? content : Buffer.from(String(content))
    const crc = crc32(data)

    // ✅ Kompres data pakai DEFLATE level 9 (raw) — sama seperti contoh kamu
    const compressed = zlib.deflateRawSync(data, { level: 9 })
    const size = data.length
    const csize = compressed.length

    // ---- local file header (30 bytes) ----
    const local = Buffer.alloc(30); let p = 0
    local.writeUInt32LE(0x04034b50, p); p += 4
    local.writeUInt16LE(20, p); p += 2            // version needed
    local.writeUInt16LE(0, p); p += 2             // general purpose bit flag
    local.writeUInt16LE(8, p); p += 2             // ✅ method: 8 = DEFLATE
    local.writeUInt16LE(dosTime, p); p += 2
    local.writeUInt16LE(dosDate, p); p += 2
    local.writeUInt32LE(crc, p); p += 4
    local.writeUInt32LE(csize, p); p += 4         // ✅ compressed size
    local.writeUInt32LE(size, p); p += 4          // ✅ uncompressed size
    local.writeUInt16LE(nameBuf.length, p); p += 2
    local.writeUInt16LE(0, p); p += 2             // extra length

    localParts.push(local, nameBuf, compressed)
    entries.push({ nameBuf, crc, size, csize, offset, dosTime, dosDate })
    offset += local.length + nameBuf.length + compressed.length
  }

  // ---- central directory ----
  const startCentral = offset
  for (const e of entries) {
    const central = Buffer.alloc(46); let p = 0
    central.writeUInt32LE(0x02014b50, p); p += 4   // signature
    central.writeUInt16LE(20, p); p += 2           // version made by
    central.writeUInt16LE(20, p); p += 2           // version needed
    central.writeUInt16LE(0, p); p += 2            // general purpose bit flag
    central.writeUInt16LE(8, p); p += 2            // ✅ method: 8 = DEFLATE
    central.writeUInt16LE(e.dosTime, p); p += 2
    central.writeUInt16LE(e.dosDate, p); p += 2
    central.writeUInt32LE(e.crc, p); p += 4
    central.writeUInt32LE(e.csize, p); p += 4
    central.writeUInt32LE(e.size, p); p += 4
    central.writeUInt16LE(e.nameBuf.length, p); p += 2
    central.writeUInt16LE(0, p); p += 2            // extra
    central.writeUInt16LE(0, p); p += 2            // comment
    central.writeUInt16LE(0, p); p += 2            // disk number start
    central.writeUInt16LE(0, p); p += 2            // internal attrs
    central.writeUInt32LE(0, p); p += 4            // external attrs
    central.writeUInt32LE(e.offset, p); p += 4     // relative offset

    centralParts.push(central, e.nameBuf)
    offset += central.length + e.nameBuf.length
  }

  // ---- end of central dir ----
  const sizeCentral = offset - startCentral
  const end = Buffer.alloc(22); let q = 0
  end.writeUInt32LE(0x06054b50, q); q += 4
  end.writeUInt16LE(0, q); q += 2
  end.writeUInt16LE(0, q); q += 2
  end.writeUInt16LE(entries.length, q); q += 2
  end.writeUInt16LE(entries.length, q); q += 2
  end.writeUInt32LE(sizeCentral, q); q += 4
  end.writeUInt32LE(startCentral, q); q += 4
  end.writeUInt16LE(0, q); q += 2

  const zip = Buffer.concat([...localParts, ...centralParts, end])
  fs.writeFileSync(outPath, zip)
  return outPath
}

// ===================== Util =====================
function safeStat(p) { try { return fs.statSync(p) } catch { return null } }
function safeReadDir(dir) { try { return fs.readdirSync(dir) } catch { return [] } }

function walk(dir, onFile) {
  for (const ent of safeReadDir(dir)) {
    const p = path.join(dir, ent)
    const st = safeStat(p)
    if (!st) continue
    if (st.isDirectory()) walk(p, onFile)
    else if (st.isFile()) onFile(p)
  }
}

function listAllFiles(projectRoot) {
  const out = {}
  const norm = p => p.split(path.sep).join('/')

  for (const dir of WHITELIST_DIRS) {
    const abs = path.join(projectRoot, dir)
    if (!fs.existsSync(abs)) continue
    const st = safeStat(abs)
    if (!st || !st.isDirectory()) continue
    walk(abs, (fileAbs) => {
      const rel = norm(path.relative(projectRoot, fileAbs))
      try { out[rel] = fs.readFileSync(fileAbs) } catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }
    })
  }

  for (const fname of WHITELIST_FILES) {
    const abs = path.join(projectRoot, fname)
    if (!fs.existsSync(abs)) continue
    try { out[fname] = fs.readFileSync(abs) } catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }
  }

  return out
}

function normalizeToJid(val) {
  if (!val) return null
  const s = String(val)
  if (s.includes('@s.whatsapp.net')) return s
  const digits = s.replace(/\D/g, '')
  return digits ? `${digits}@s.whatsapp.net` : null
}

function getOwnerJid(db) {
  // ✅ PRIORITAS: global.nomorown (sesuai settings kamu)
  const fromSetting = normalizeToJid(global.nomorown || global.nomorowner)
  if (fromSetting) return fromSetting

  // 1) db.list().owner[0]
  try {
    const owners = db?.list?.().owner || []
    if (owners && owners[0]) return normalizeToJid(owners[0])
  } catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }

  // 2) global.owner (kadang array)
  try {
    if (Array.isArray(global.owner)) {
      const first = global.owner?.[0]
      if (Array.isArray(first)) return normalizeToJid(first[0])
      return normalizeToJid(first)
    }
  } catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }

  // 3) global.rowner
  return normalizeToJid(global.rowner)
}

// ===================== Backup Pipeline =====================
function createBackupZip() {
  const root = path.join(__dirname, '../..') // project root
  const filesMap = listAllFiles(root)

  const now = new Date()
  const tmpName = `${BOT_NAME}-${keyWIB(now).replace(':','')}.zip`
  const tmpPath = path.join(TMP_DIR, tmpName)

  createZipFile(filesMap, tmpPath, now)

  return {
    tmpPath,
    displayName: `${BOT_NAME}.zip`,
    count: Object.keys(filesMap).length,
    createdAt: now
  }
}

async function sendZipToOwnerAndDelete(wafproject, ownerJid, tmpPath, displayName, isAuto, createdAtDate) {
  if (!ownerJid) throw new Error('Owner tidak ditemukan (global.nomorown/global.owner/global.rowner/db kosong)')

  const createdWIB = toWIBDate(createdAtDate)
  const tsFull = formatIndoDateTimeWIB(createdWIB)
  const tsDate = formatIndoDateWIB(createdWIB)
  const modeStr = isAuto ? 'OTOMATIS' : 'MANUAL'

  const caption =
`🗄️ *AUTO BACKUP ${BOT_NAME}*
Mode : *${modeStr}*
Tanggal : *${tsDate}*
Waktu : *${tsFull}*
Status : *SUKSES ✅*`

  const buffer = fs.readFileSync(tmpPath)
  try {
    await wafproject.sendMessage(ownerJid, {
      document: buffer,
      fileName: displayName,
      mimetype: 'application/zip',
      caption
    })
  } finally {
    try { fs.unlinkSync(tmpPath) } catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }
  }
}

// ===================== Scheduler (node-schedule style, anti double) =====================
function isConnReady(wafproject) {
  try {
    return !!(wafproject && wafproject.user && (wafproject.user.id || wafproject.user.jid))
  } catch {
    return false
  }
}

// cancel job lama kalau plugin reload (biar gak double)
try {
  if (global.__autoBackupJob && typeof global.__autoBackupJob.cancel === 'function') {
    global.__autoBackupJob.cancel()
    global.__autoBackupJob = null
  }
} catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }

global.__autoBackupLog = global.__autoBackupLog || {} // { "YYYY-MM-DD|HH:mm": true }

global.__autoBackupJob = schedule.scheduleJob({ rule: '* * * * *', tz: TIMEZONE }, async () => {
  const wafproject = global.wafproject
  if (!isConnReady(wafproject)) return

  // ambil jam menit sesuai timezone
  const nowTz = moment.tz(TIMEZONE)
  const hh = String(nowTz.hour()).padStart(2, '0')
  const mm = String(nowTz.minute()).padStart(2, '0')
  const hhmm = `${hh}:${mm}`

  // hanya jalan di jam yg ditentukan
  if (!BACKUP_TIMES.includes(hhmm)) return

  // anti double per hari per jam
  const today = nowTz.format('YYYY-MM-DD')
  const logKey = `${today}|${hhmm}`
  if (global.__autoBackupLog[logKey]) return
  global.__autoBackupLog[logKey] = true

  try {
    const { tmpPath, displayName, createdAt } = createBackupZip()
    const ownerJid = getOwnerJid(global.__dbForBackup)
    await sendZipToOwnerAndDelete(wafproject, ownerJid, tmpPath, displayName, true, createdAt)
  } catch (e) {
    console.error(`[${BOT_NAME} autobackup] gagal:`, e?.message || e)
  }
})

// ===================== Handler =====================
const handler = async (m, { command, wafproject, isOwner, isAdmin, db }) => {
  try {
    // simpan db buat scheduler (optional)
    if (db) global.__dbForBackup = db

    // manual backup
    if (command === 'backupnow' || command === 'bakcupnow') {
      if (!isOwner && !isAdmin) return

      try { await wafproject.sendMessage(m.chat, { react: { text: '🗂️', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }

      const { tmpPath, displayName, count, createdAt } = createBackupZip()
      const ownerJid = getOwnerJid(db)

      await sendZipToOwnerAndDelete(wafproject, ownerJid, tmpPath, displayName, false, createdAt)

      try { await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/owner/autobackup.js]", _error?.message || _error) }

      const createdWIB = toWIBDate(createdAt)
      return m.reply(
        `✅ *${BOT_NAME} BACKUP SELESAI*\n` +
        `📦 File: ${displayName}\n` +
        `📁 Total: ${count} file\n` +
        `🕒 WIB: ${formatIndoDateTimeWIB(createdWIB)}\n` +
        `📩 Dikirim ke: owner`
      )
    }

    // debug
    if (command === 'backupdebug') {
      const ownerJid = getOwnerJid(db) || '(tidak ada)'
      const nowWIB = toWIBDate(new Date())

      return m.reply(
`🧪 *DEBUG BACKUP — ${BOT_NAME}*
🕒 ${formatIndoDateTimeWIB(nowWIB)}

⏰ Jadwal Backup:
${BACKUP_TIMES.map(t => `• ${t} WIB`).join('\n')}

🎯 Target Owner:
• ${ownerJid}

📌 Conn Ready:
• ${global.wafproject && global.wafproject.user ? 'YES ✅' : 'NO ❌ (pastikan index.js set global.wafproject = wafproject)'}

🔁 Scheduler:
• node-schedule (tiap menit, tz=${TIMEZONE})`
      )
    }

  } catch (e) {
    console.error(`[${BOT_NAME} autobackup]`, e)
    return m.reply(`❌ *${BOT_NAME}*\nBackup gagal.\n${e?.message ? `Reason: ${e.message}` : ''}`)
  }
}

handler.command = ['backupnow', 'bakcupnow', 'backupdebug']
handler.category = 'owner'
handler.description = 'Auto backup project ke owner (WIB 00/06/12/18) + backup manual'
handler.owner = false
handler.limit = false
handler.group = false

module.exports = handler