/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const axios = require('axios')
const crypto = require('crypto')

/* =========================================================
   CONFIG MERZZ
   ========================================================= */

const MERZZ = {
  baseUrl: 'https://merzzmlbb.id',

  payloadApiPath:
    '/api/v3/free-fire',

  headerApiPath:
    '/api/v3/game/free-fire',

  tokenSecret:
    'PHK2VCVXspyqyg/MTMDaQ0jslAqujTl+BrKaity4mck=',

  tokenVersion:
    'v1.0.0'
}

/* =========================================================
   RETRY
   ========================================================= */

async function withRetry(
  fn,
  {
    retries = 2,
    baseDelay = 700
  } = {}
) {
  let lastErr

  for (
    let attempt = 0;
    attempt <= retries;
    attempt++
  ) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err

      const code =
        err?.code || ''

      const status =
        err?.response?.status || 0

      const msg =
        String(
          err?.message || ''
        ).toLowerCase()

      const retriable =
        code === 'ECONNRESET' ||
        code === 'ETIMEDOUT' ||
        code === 'EAI_AGAIN' ||
        msg.includes('socket hang up') ||
        msg.includes('timeout') ||
        status === 429 ||
        status >= 500

      if (
        !retriable ||
        attempt === retries
      ) {
        break
      }

      await new Promise(resolve =>
        setTimeout(
          resolve,
          baseDelay * (attempt + 1)
        )
      )
    }
  }

  throw lastErr
}

/* =========================================================
   CREATE TOKEN
   ========================================================= */

function createMerzzToken(uid) {
  const payload =
    JSON.stringify({
      id: String(uid),
      apipath:
        MERZZ.payloadApiPath
    })

  const key =
    crypto
      .createHash('sha256')
      .update(
        MERZZ.tokenSecret
      )
      .digest()

  const iv =
    crypto.randomBytes(12)

  const cipher =
    crypto.createCipheriv(
      'aes-256-gcm',
      key,
      iv
    )

  const encrypted =
    Buffer.concat([
      cipher.update(
        payload,
        'utf8'
      ),

      cipher.final()
    ])

  const authTag =
    cipher.getAuthTag()

  const xToken =
    Buffer.concat([
      iv,
      encrypted,
      authTag
    ]).toString('base64')

  return {
    xToken,

    xTokenVersion:
      MERZZ.tokenVersion
  }
}

/* =========================================================
   CHECK FREE FIRE
   ========================================================= */

async function fetchMerzzFF(uid) {
  const token =
    createMerzzToken(uid)

  const res =
    await withRetry(() =>
      axios.post(
        `${MERZZ.baseUrl}/api/pre-validate`,

        token,

        {
          headers: {
            'Content-Type':
              'application/json',

            /*
             * Header path berbeda
             * dari apipath dalam payload.
             */
            'path':
              MERZZ.headerApiPath,

            'Origin':
              MERZZ.baseUrl,

            'Referer':
              `${MERZZ.baseUrl}/id-id/cekff`,

            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36',

            'Accept':
              'application/json, text/plain, */*'
          },

          timeout: 20000,

          validateStatus:
            () => true
        }
      )
    )

  const body =
    res.data

  /* ================= HTTP ERROR ================= */

  if (
    res.status < 200 ||
    res.status >= 300
  ) {
    throw new Error(
      body?.message ||
      body?.error ||
      `Merzz HTTP ${res.status}`
    )
  }

  /* ================= INVALID ACCOUNT ================= */

  if (
    !body ||
    body.status !== true
  ) {
    throw new Error(
      body?.message ||
      'Player ID Free Fire tidak valid atau akun tidak ditemukan'
    )
  }

  const data =
    body.data || {}

  const nickname =
    String(
      body.nickname ||
      data.username ||
      ''
    ).trim()

  const country =
    String(
      body.country ||
      data.country ||
      ''
    )
      .trim()
      .toUpperCase()

  if (
    !nickname
  ) {
    throw new Error(
      'Nickname Free Fire tidak ditemukan'
    )
  }

  if (
    !/^[A-Z]{2}$/.test(
      country
    )
  ) {
    throw new Error(
      `Region Free Fire tidak valid: ${country || '-'}`
    )
  }

  return {
    uid:
      String(uid),

    nickname,

    country
  }
}

/* =========================================================
   PARSE UID
   ========================================================= */

function parseUid(
  input = ''
) {
  const uid =
    String(input || '')
      .trim()

  if (
    !/^\d{5,20}$/.test(
      uid
    )
  ) {
    return null
  }

  return uid
}

/* =========================================================
   COUNTRY -> FLAG
   ========================================================= */

function iso2ToFlagEmoji(
  iso2 = ''
) {
  const cc =
    String(
      iso2 || ''
    )
      .trim()
      .toUpperCase()

  if (
    !/^[A-Z]{2}$/.test(
      cc
    )
  ) {
    return ''
  }

  const A =
    0x1F1E6

  return String.fromCodePoint(
    ...[...cc].map(
      ch =>
        A +
        (
          ch.charCodeAt(0) -
          65
        )
    )
  )
}

/* =========================================================
   COUNTRY NAME
   ========================================================= */

function countryName(
  code = ''
) {
  const cc =
    String(
      code || ''
    )
      .trim()
      .toUpperCase()

  if (!cc) {
    return 'Tidak diketahui'
  }

  try {
    const names =
      new Intl.DisplayNames(
        ['id'],
        {
          type: 'region'
        }
      )

    return (
      names.of(cc) ||
      cc
    )
  } catch {
    return cc
  }
}

/* =========================================================
   WAKTU
   ========================================================= */

function waktu() {
  return new Date()
    .toLocaleString(
      'id-ID',
      {
        timeZone:
          'Asia/Jakarta'
      }
    )
}

/* =========================================================
   ERROR MESSAGE
   ========================================================= */

function getErrorMessage(err) {
  const data =
    err?.response?.data

  let message =
    data?.message ||
    data?.error ||
    err?.message ||
    'Terjadi kesalahan'

  if (
    typeof message !==
    'string'
  ) {
    try {
      message =
        JSON.stringify(
          message
        )
    } catch {
      message =
        'Terjadi kesalahan'
    }
  }

  if (
    message.length >
    300
  ) {
    message =
      `${message.slice(
        0,
        300
      )}...`
  }

  return message
}

/* =========================================================
   HANDLER
   ========================================================= */

async function plugin(
  m,
  {
    wafproject,
    args,
    text,
    usedPrefix,
    command
  }
) {
  if (
    !/^cekff$/i.test(
      command
    )
  ) {
    return
  }

  const raw =
    (
      args &&
      args.length
        ? args.join(' ')
        : text || ''
    ).trim()

  const uid =
    parseUid(raw)

  /* ================= FORMAT ERROR ================= */

  if (!uid) {
    const pfx =
      usedPrefix || '.'

    return wafproject.sendMessage(
      m.chat,

      {
        text:
`❓ Format tidak valid.

Gunakan format:
• ${pfx}cekff 11616942944`
      },

      {
        quote: m
      }
    )
  }

  try {
    /* ================= LOADING ================= */

    await wafproject
      .sendMessage(
        m.chat,

        {
          react: {
            text: '🔎',
            key: m.key
          }
        }
      )
      .catch(() => {})

    /* ================= MERZZ ================= */

    const account =
      await fetchMerzzFF(
        uid
      )

    const flag =
      iso2ToFlagEmoji(
        account.country
      )

    const region =
      countryName(
        account.country
      )

    /* ================= OUTPUT ================= */

    const teks =
`📊 *CHECK AKUN FREE FIRE*

🆔 *Player ID* : ${uid}
👤 *Nickname*  : ${account.nickname}
🌏 *Region*    : ${flag ? `${flag} ` : ''}${region}
━━━━━━━━━━━━━━━━━━━━━
🕒 *Waktu Cek:*
${waktu()}`

    await wafproject.sendMessage(
      m.chat,

      {
        text: teks
      },

      {
        quote: m
      }
    )

    /* ================= SUCCESS ================= */

    await wafproject
      .sendMessage(
        m.chat,

        {
          react: {
            text: '✅',
            key: m.key
          }
        }
      )
      .catch(() => {})

  } catch (err) {
    /* ================= ERROR ================= */

    await wafproject
      .sendMessage(
        m.chat,

        {
          react: {
            text: '❌',
            key: m.key
          }
        }
      )
      .catch(() => {})

    console.error(
      '[ERROR][commands/stalk/cekff.js]',
      err?.response?.status || '',
      err?.response?.data ||
      err?.message ||
      err
    )

    return wafproject.sendMessage(
      m.chat,

      {
        text:
          `❌ Error: ${getErrorMessage(err)}`
      },

      {
        quote: m
      }
    )
  }
}

/* =========================================================
   PLUGIN INFO
   ========================================================= */

plugin.command = [
  'cekff'
]

plugin.category =
  'stalk'

plugin.description =
  'Cek akun Free Fire via Merzz'

module.exports =
  plugin