/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const axios = require('axios')
const crypto = require('crypto')

/* =========================================================
   CONFIG MERZZ
   ========================================================= */

const MERZZ = {
  baseUrl: 'https://merzzmlbb.id',

  apiPath: '/api/v3/mobile-legends',

  tokenSecret:
    'PHK2VCVXspyqyg/MTMDaQ0jslAqujTl+BrKaity4mck=',

  tokenVersion: 'v1.0.0'
}

/* =========================================================
   RETRY
   ========================================================= */

async function withRetry(
  fn,
  {
    retries = 2,
    baseDelay = 700
  } = {}
) {
  let lastErr

  for (
    let attempt = 0;
    attempt <= retries;
    attempt++
  ) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err

      const code =
        err?.code || ''

      const status =
        err?.response?.status || 0

      const msg =
        String(
          err?.message || ''
        ).toLowerCase()

      const retriable =
        code === 'ECONNRESET' ||
        code === 'ETIMEDOUT' ||
        code === 'EAI_AGAIN' ||
        msg.includes('socket hang up') ||
        msg.includes('timeout') ||
        status === 429 ||
        status >= 500

      if (
        !retriable ||
        attempt === retries
      ) {
        break
      }

      await new Promise(resolve =>
        setTimeout(
          resolve,
          baseDelay * (attempt + 1)
        )
      )
    }
  }

  throw lastErr
}

/* =========================================================
   GENERATE TOKEN MERZZ
   ========================================================= */

function createMerzzToken(
  uid,
  zone
) {
  const payload =
    JSON.stringify({
      id: String(uid),
      server: String(zone),
      apipath: MERZZ.apiPath
    })

  /*
   * SHA256 secret
   * menghasilkan key 32 byte
   * untuk AES-256-GCM.
   */
  const key =
    crypto
      .createHash('sha256')
      .update(
        MERZZ.tokenSecret
      )
      .digest()

  /*
   * IV AES-GCM = 12 byte.
   */
  const iv =
    crypto.randomBytes(12)

  const cipher =
    crypto.createCipheriv(
      'aes-256-gcm',
      key,
      iv
    )

  const encrypted =
    Buffer.concat([
      cipher.update(
        payload,
        'utf8'
      ),

      cipher.final()
    ])

  const authTag =
    cipher.getAuthTag()

  /*
   * Format frontend:
   *
   * IV + encrypted + authTag
   *
   * kemudian Base64.
   */
  const xToken =
    Buffer.concat([
      iv,
      encrypted,
      authTag
    ]).toString('base64')

  return {
    xToken,
    xTokenVersion:
      MERZZ.tokenVersion
  }
}

/* =========================================================
   SCRAPE / CHECK MERZZ
   ========================================================= */

async function fetchMerzzML(
  uid,
  zone
) {
  const token =
    createMerzzToken(
      uid,
      zone
    )

  const res =
    await withRetry(() =>
      axios.post(
        `${MERZZ.baseUrl}/api/pre-validate`,

        token,

        {
          headers: {
            'Content-Type':
              'application/json',

            /*
             * Header path ini wajib
             * karena digunakan frontend Merzz.
             */
            'path':
              MERZZ.apiPath,

            'Origin':
              MERZZ.baseUrl,

            'Referer':
              `${MERZZ.baseUrl}/id-id/cekml`,

            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36',

            'Accept':
              'application/json, text/plain, */*'
          },

          timeout: 20000,

          validateStatus:
            () => true
        }
      )
    )

  const body =
    res.data

  /* ================= HTTP ERROR ================= */

  if (
    res.status < 200 ||
    res.status >= 300
  ) {
    throw new Error(
      body?.message ||
      body?.error ||
      `Merzz HTTP ${res.status}`
    )
  }

  /* ================= INVALID RESPONSE ================= */

  if (
    !body ||
    body.status !== true
  ) {
    throw new Error(
      body?.message ||
      'User ID / Zone ID tidak valid atau data akun tidak ditemukan'
    )
  }

  /* ================= ACCOUNT ================= */

  const data =
    body.data || {}

  const nickname =
    String(
      body.nickname ||
      data.username ||
      ''
    ).trim()

  const country =
    String(
      body.country ||
      data.country ||
      ''
    )
      .trim()
      .toUpperCase()

  if (
    !/^[A-Z]{2}$/.test(
      country
    )
  ) {
    throw new Error(
      `Region akun tidak valid: ${country || '-'}`
    )
  }

  /* ================= RECHARGE BONUS ================= */

  const rechargeBonus =
    Array.isArray(
      data.rechargeBonus
    )
      ? data.rechargeBonus
      : []

  return {
    uid:
      String(uid),

    zone:
      String(zone),

    nickname:
      nickname ||
      'Tidak diketahui',

    country,

    rechargeBonus
  }
}

/* =========================================================
   PARSE ID + ZONE
   ========================================================= */

function parseIdZone(
  input = ''
) {
  const s =
    String(input || '')
      .trim()

  /*
   * FORMAT:
   * 290188675 9507
   */
  let m =
    /^(\d{5,20})\s+(\d{1,10})$/.exec(
      s
    )

  if (m) {
    return {
      uid: m[1],
      zone: m[2]
    }
  }

  /*
   * FORMAT:
   * 290188675 (9507)
   */
  m =
    /^(\d{5,20})\s*\(\s*(\d{1,10})\s*\)$/.exec(
      s
    )

  if (m) {
    return {
      uid: m[1],
      zone: m[2]
    }
  }

  /*
   * FORMAT:
   * 290188675|9507
   */
  m =
    /^(\d{5,20})\|(\d{1,10})$/.exec(
      s
    )

  if (m) {
    return {
      uid: m[1],
      zone: m[2]
    }
  }

  return null
}

/* =========================================================
   COUNTRY CODE -> FLAG
   ========================================================= */

function iso2ToFlagEmoji(
  iso2 = ''
) {
  const cc =
    String(
      iso2 || ''
    )
      .trim()
      .toUpperCase()

  if (
    !/^[A-Z]{2}$/.test(
      cc
    )
  ) {
    return ''
  }

  const REGIONAL_A =
    0x1F1E6

  return String.fromCodePoint(
    ...[...cc].map(
      ch =>
        REGIONAL_A +
        (
          ch.charCodeAt(0) -
          65
        )
    )
  )
}

/* =========================================================
   COUNTRY CODE -> COUNTRY NAME
   ========================================================= */

function countryName(
  countryCode = ''
) {
  const code =
    String(
      countryCode || ''
    )
      .trim()
      .toUpperCase()

  if (!code) {
    return 'Tidak diketahui'
  }

  /*
   * Node modern sudah support Intl.DisplayNames.
   *
   * ID -> Indonesia
   * MY -> Malaysia
   * SG -> Singapura
   */
  try {
    const display =
      new Intl.DisplayNames(
        ['id'],
        {
          type: 'region'
        }
      )

    return (
      display.of(code) ||
      code
    )
  } catch {
    return code
  }
}

/* =========================================================
   BONUS UTIL
   ========================================================= */

function isAvailable(item) {
  if (!item) {
    return false
  }

  /*
   * Merzz memberikan:
   *
   * CanBuy: true / false
   *
   * dan:
   *
   * status: available / unavailable
   */

  if (
    item.CanBuy === true
  ) {
    return true
  }

  return (
    String(
      item.status || ''
    )
      .trim()
      .toLowerCase() ===
    'available'
  )
}

/* =========================================================
   WAKTU
   ========================================================= */

function waktu() {
  return new Date()
    .toLocaleString(
      'id-ID',
      {
        timeZone:
          'Asia/Jakarta'
      }
    )
}

/* =========================================================
   ERROR MESSAGE
   ========================================================= */

function getErrorMessage(err) {
  const response =
    err?.response?.data

  let msg =
    response?.message ||
    response?.error ||
    err?.message ||
    'Terjadi kesalahan'

  if (
    typeof msg !==
    'string'
  ) {
    try {
      msg =
        JSON.stringify(msg)
    } catch {
      msg =
        'Terjadi kesalahan'
    }
  }

  /*
   * Jangan kirim stack/error
   * panjang ke WhatsApp.
   */
  if (
    msg.length >
    300
  ) {
    msg =
      `${msg.slice(
        0,
        300
      )}...`
  }

  return msg
}

/* =========================================================
   HANDLER
   ========================================================= */

async function plugin(
  m,
  {
    wafproject,
    args,
    text,
    usedPrefix,
    command
  }
) {
  if (
    !/^cekml$/i.test(
      command
    )
  ) {
    return
  }

  const raw =
    (
      args &&
      args.length
        ? args.join(' ')
        : text || ''
    ).trim()

  const parsed =
    parseIdZone(raw)

  /* ================= INVALID FORMAT ================= */

  if (!parsed) {
    const pfx =
      usedPrefix || '.'

    return wafproject.sendMessage(
      m.chat,

      {
        text:
`❓ Format tidak valid.

Gunakan salah satu format berikut:
• ${pfx}cekml 290188675 9507
• ${pfx}cekml 290188675 (9507)
• ${pfx}cekml 290188675|9507`
      },

      {
        quote: m
      }
    )
  }

  const {
    uid,
    zone
  } = parsed

  try {
    /* ================= LOADING ================= */

    await wafproject
      .sendMessage(
        m.chat,

        {
          react: {
            text: '🔎',
            key: m.key
          }
        }
      )
      .catch(() => {})

    /* ================= MERZZ ================= */

    const ml =
      await fetchMerzzML(
        uid,
        zone
      )

    const flag =
      iso2ToFlagEmoji(
        ml.country
      )

    const region =
      countryName(
        ml.country
      )

    /* =================================================
       SPLIT DOUBLE DIAMOND / BUNDLE
       ================================================= */

    const allBonus =
      Array.isArray(
        ml.rechargeBonus
      )
        ? ml.rechargeBonus
        : []

    /*
     * Double Diamond:
     *
     * 50+50
     * 150+150
     * 250+250
     * 500+500
     */
    const doubleDiamond =
      allBonus.filter(item =>
        /^\d+\s*\+\s*\d+$/.test(
          String(
            item?.diamonds || ''
          ).trim()
        )
      )

    /*
     * Selain format angka+angka:
     *
     * Weekly Elite Bundle
     * Monthly Epic Bundle
     * Weekly Diamond Pass
     * dll.
     */
    const bundleList =
      allBonus.filter(item =>
        !/^\d+\s*\+\s*\d+$/.test(
          String(
            item?.diamonds || ''
          ).trim()
        )
      )

    /* =================================================
       DOUBLE DIAMOND TEXT
       ================================================= */

    let diamondText = ''

    if (
      doubleDiamond.length >
      0
    ) {
      diamondText +=
        '💎 *Status Double Diamond:*\n'

      for (
        const item
        of doubleDiamond
      ) {
        const available =
          isAvailable(item)

        const nominal =
          String(
            item?.diamonds || '-'
          ).trim()

        const lock =
          available
            ? '🔓'
            : '🔒'

        const status =
          available
            ? '✅ Tersedia'
            : '❌ Sudah Diambil'

        diamondText +=
          `${lock} ${nominal} ${status}\n`
      }

      diamondText += '\n'
    }

    /* =================================================
       BUNDLE / PASS TEXT
       ================================================= */

    let bundleText = ''

    if (
      bundleList.length >
      0
    ) {
      bundleText +=
        '🎁 *Status Bundle & Pass:*\n'

      for (
        const item
        of bundleList
      ) {
        const available =
          isAvailable(item)

        const name =
          String(
            item?.diamonds || '-'
          ).trim()

        const lock =
          available
            ? '🔓'
            : '🔒'

        const status =
          available
            ? '✅ Tersedia'
            : '❌ Sudah Diambil'

        bundleText +=
          `${lock} ${name} ${status}\n`
      }

      bundleText += '\n'
    }

    /* =================================================
       OUTPUT
       ================================================= */

    const teks =
`📊 *CHECK AKUN MOBILE LEGENDS*

🆔 *User ID*   : ${uid}
🌐 *Zone ID*   : ${zone}
👤 *Username*  : ${ml.nickname}
🌏 *Region*    : ${flag ? `${flag} ` : ''}${region}
━━━━━━━━━━━━━━━━━━━━━
${diamondText}${bundleText}🕒 *Waktu Cek:*
${waktu()}`

    /* ================= SEND ================= */

    await wafproject.sendMessage(
      m.chat,

      {
        text: teks
      },

      {
        quote: m
      }
    )

    /* ================= SUCCESS REACT ================= */

    await wafproject
      .sendMessage(
        m.chat,

        {
          react: {
            text: '✅',
            key: m.key
          }
        }
      )
      .catch(() => {})

  } catch (err) {
    /* ================= ERROR REACT ================= */

    await wafproject
      .sendMessage(
        m.chat,

        {
          react: {
            text: '❌',
            key: m.key
          }
        }
      )
      .catch(() => {})

    console.error(
      '[ERROR][commands/stalk/cekml.js]',
      err?.response?.status || '',
      err?.response?.data ||
      err?.message ||
      err
    )

    return wafproject.sendMessage(
      m.chat,

      {
        text:
          `❌ Error: ${getErrorMessage(err)}`
      },

      {
        quote: m
      }
    )
  }
}

/* =========================================================
   PLUGIN INFO
   ========================================================= */

plugin.command = [
  'cekml'
]

plugin.category =
  'stalk'

plugin.description =
  'Cek ML via Merzz + Double Diamond + Bundle'

module.exports =
  plugin