// ✨ Plugin cek PLN (Digiflazz) ✨
// Endpoint: https://api.digiflazz.com/v1/inquiry-pln
// Body: { username, customer_no, sign: md5(username + api_key + customer_no) }
// Response dibungkus: { data: {...} }

const axios = require('axios')
const crypto = require('crypto')

// ✅ pastikan settings.js keload (global terisi)
require('../../settings.js')

// =================== CONFIG (dari global settings) ===================
const DIGIFLAZZ_USERNAME = global.digiflazzUsername || ''
const DIGIFLAZZ_API_KEY = global.digiflazzApiKey || ''
const ENDPOINT = global.digiflazzPlnEndpoint || 'https://api.digiflazz.com/v1/inquiry-pln'

// =================== RETRY ===================
async function withRetry(fn, { retries = 2, baseDelay = 600 } = {}) {
  let lastErr
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn()
    } catch (e) {
      lastErr = e
      const code = e?.code || ''
      const msg = String(e?.message || '')
      const retriable =
        code === 'ECONNRESET' ||
        code === 'ETIMEDOUT' ||
        code === 'EAI_AGAIN' ||
        msg.includes('socket hang up') ||
        msg.toLowerCase().includes('timeout')

      if (!retriable || i === retries) break
      await new Promise(r => setTimeout(r, baseDelay * (i + 1)))
    }
  }
  throw lastErr
}

// =================== WIB FORMAT ===================
function waktuWIBString(d = new Date()) {
  const z = new Date(d.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }))
  const tgl = z.getDate()
  const bln = z.getMonth() + 1
  const thn = z.getFullYear()
  const HH = String(z.getHours()).padStart(2, '0')
  const MM = String(z.getMinutes()).padStart(2, '0')
  const SS = String(z.getSeconds()).padStart(2, '0')
  const namaBulan = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des']
  return `${tgl} ${namaBulan[bln - 1]} ${thn}, ${HH}.${MM}.${SS}`
}

// =================== SIGN ===================
function makeSign(username, apiKey, customerNo) {
  const raw = `${username}${apiKey}${customerNo}`
  return crypto.createHash('md5').update(raw).digest('hex')
}

// =================== DEBUG FORMATTER ===================
function fmtDebug(err, extra = {}) {
  const e = err || {}
  const lines = []
  lines.push('🧩 *DEBUG CEKPLN*')
  lines.push(`🕒 *Waktu:* ${waktuWIBString()}`)
  if (extra.url) lines.push(`🌐 *URL:* ${extra.url}`)
  if (extra.customer_no) lines.push(`🔢 *customer_no:* ${extra.customer_no}`)

  lines.push(`🧷 *code:* ${e.code || '-'}`)
  lines.push(`📌 *message:* ${String(e.message || e)}`)

  const status = e.response?.status
  if (status) lines.push(`📡 *http_status:* ${status}`)

  const data = e.response?.data
  if (data) {
    let body = ''
    try { body = typeof data === 'string' ? data : JSON.stringify(data) }
    catch { body = String(data) }
    if (body.length > 400) body = body.slice(0, 400) + '…'
    lines.push('🧾 *response_body:*')
    lines.push(body)
  }

  return lines.join('\n')
}

// =================== API CALL ===================
async function inquiryPLN(customerNo) {
  if (!DIGIFLAZZ_USERNAME || !DIGIFLAZZ_API_KEY) {
    throw new Error('Config Digiflazz belum di set (global.digiflazzUsername / global.digiflazzApiKey).')
  }

  const sign = makeSign(DIGIFLAZZ_USERNAME, DIGIFLAZZ_API_KEY, customerNo)

  const body = {
    username: DIGIFLAZZ_USERNAME,
    customer_no: customerNo,
    sign
  }

  const rsp = await withRetry(
    () =>
      axios.post(ENDPOINT, body, {
        timeout: 20000,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0'
        },
        validateStatus: () => true
      }),
    { retries: 2 }
  )

  if (rsp.status < 200 || rsp.status >= 300) {
    const er = new Error(`HTTP ${rsp.status}`)
    er.response = rsp
    throw er
  }

  // Response dibungkus "data"
  const payload = rsp.data
  const data = payload?.data
  if (!data) throw new Error('Response tidak valid: field "data" tidak ditemukan.')

  // rc "00" = sukses
  if (String(data.rc || '') !== '00') {
    throw new Error(`${data.message || 'Gagal'} (rc=${data.rc || '-'})`)
  }

  return data
}

// =================== HANDLER ===================
async function plugin(m, { wafproject, args, text, usedPrefix, command }) {
  if (!/^cekpln$/i.test(command)) return

  const input = (args?.length ? args.join(' ') : text || '').trim()

  if (!/^\d{6,}$/.test(input)) {
    return wafproject.sendMessage(
      m.chat,
      {
        text:
`❓ Format salah.

Gunakan:
${usedPrefix || '.'}cekpln 123456789012

Masukkan nomor pelanggan / meter PLN.`
      },
      { quote: m }
    )
  }

  try { await wafproject.sendMessage(m.chat, { react: { text: '🔎', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/stalk/cekpln.js]", _error?.message || _error) }

  try {
    const data = await inquiryPLN(input)

    const teks =
`⚡ *CEK PLN*

✅ *Status*       : ${data.status || 'Sukses'}
📝 *Message*      : ${data.message || '-'}
🧾 *RC*           : ${data.rc || '-'}

👤 *Nama*         : ${data.name || '-'}
🔢 *Customer No*  : ${data.customer_no || input}
🔌 *Meter No*     : ${data.meter_no || '-'}
🆔 *Subscriber ID*: ${data.subscriber_id || '-'}

⚡ *Segment/Daya*  : ${data.segment_power || '-'}

🕒 *Waktu Cek:*
${waktuWIBString()}`

    await wafproject.sendMessage(m.chat, { text: teks }, { quote: m })
    try { await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/stalk/cekpln.js]", _error?.message || _error) }
  } catch (err) {
    try { await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/stalk/cekpln.js]", _error?.message || _error) }
    const dbg = fmtDebug(err, { url: ENDPOINT, customer_no: input })
    return wafproject.sendMessage(m.chat, { text: dbg }, { quote: m })
  }
}

plugin.command = ['cekpln']
plugin.category = 'cek'
plugin.description = 'Cek PLN via Digiflazz inquiry-pln (dengan debug)'

module.exports = plugin
