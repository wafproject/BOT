/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const axios = require('axios')
const crypto = require('crypto')

/* =========================================================
   CONFIG MERZZ
   ========================================================= */

const MERZZ = {
  baseUrl: 'https://merzzmlbb.id',
  apiPath: '/api/v3/magic-chess-go-go',

  tokenSecret:
    'PHK2VCVXspyqyg/MTMDaQ0jslAqujTl+BrKaity4mck=',

  tokenVersion: 'v1.0.0'
}

/* =========================================================
   RETRY
   ========================================================= */

async function withRetry(
  fn,
  { retries = 2, baseDelay = 700 } = {}
) {
  let lastErr

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err

      const code = err?.code || ''
      const status = err?.response?.status || 0
      const msg = String(err?.message || '').toLowerCase()

      const retriable =
        code === 'ECONNRESET' ||
        code === 'ETIMEDOUT' ||
        code === 'EAI_AGAIN' ||
        msg.includes('socket hang up') ||
        msg.includes('timeout') ||
        status === 429 ||
        status >= 500

      if (!retriable || attempt === retries) break

      await new Promise(resolve =>
        setTimeout(resolve, baseDelay * (attempt + 1))
      )
    }
  }

  throw lastErr
}

/* =========================================================
   CREATE MERZZ TOKEN
   ========================================================= */

function createMerzzToken(uid, zone) {
  const payload = JSON.stringify({
    id: String(uid),
    server: String(zone),
    apipath: MERZZ.apiPath
  })

  const key = crypto
    .createHash('sha256')
    .update(MERZZ.tokenSecret)
    .digest()

  const iv = crypto.randomBytes(12)

  const cipher = crypto.createCipheriv(
    'aes-256-gcm',
    key,
    iv
  )

  const encrypted = Buffer.concat([
    cipher.update(payload, 'utf8'),
    cipher.final()
  ])

  const authTag = cipher.getAuthTag()

  const xToken = Buffer.concat([
    iv,
    encrypted,
    authTag
  ]).toString('base64')

  return {
    xToken,
    xTokenVersion: MERZZ.tokenVersion
  }
}

/* =========================================================
   CHECK MCGG VIA MERZZ
   ========================================================= */

async function fetchMerzzMCGG(uid, zone) {
  const token = createMerzzToken(uid, zone)

  const res = await withRetry(() =>
    axios.post(
      `${MERZZ.baseUrl}/api/pre-validate`,
      token,
      {
        headers: {
          'Content-Type': 'application/json',

          'path': MERZZ.apiPath,

          'Origin': MERZZ.baseUrl,

          'Referer':
            `${MERZZ.baseUrl}/id-id/cekmcgg`,

          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36',

          'Accept':
            'application/json, text/plain, */*'
        },

        timeout: 20000,

        validateStatus: () => true
      }
    )
  )

  const body = res.data

  /* ================= HTTP ERROR ================= */

  if (
    res.status < 200 ||
    res.status >= 300
  ) {
    throw new Error(
      body?.message ||
      body?.error ||
      `Merzz HTTP ${res.status}`
    )
  }

  /* ================= INVALID ACCOUNT ================= */

  if (
    !body ||
    body.status !== true
  ) {
    throw new Error(
      body?.message ||
      'User ID / Zone ID MCGG tidak valid atau akun tidak ditemukan'
    )
  }

  const data = body.data || {}

  const nickname = String(
    body.nickname ||
    data.username ||
    ''
  ).trim()

  const country = String(
    body.country ||
    data.country ||
    ''
  )
    .trim()
    .toUpperCase()

  if (!/^[A-Z]{2}$/.test(country)) {
    throw new Error(
      `Region MCGG tidak valid: ${country || '-'}`
    )
  }

  const rechargeBonus =
    Array.isArray(data.rechargeBonus)
      ? data.rechargeBonus
      : []

  return {
    uid: String(uid),
    zone: String(zone),

    nickname:
      nickname || 'Tidak diketahui',

    country,

    rechargeBonus
  }
}

/* =========================================================
   PARSE ID + ZONE
   ========================================================= */

function parseIdZone(input = '') {
  const s = String(input || '').trim()

  /*
   * 14080077 4155
   */
  let m =
    /^(\d{5,20})\s+(\d{1,10})$/.exec(s)

  if (m) {
    return {
      uid: m[1],
      zone: m[2]
    }
  }

  /*
   * 14080077 (4155)
   */
  m =
    /^(\d{5,20})\s*\(\s*(\d{1,10})\s*\)$/.exec(s)

  if (m) {
    return {
      uid: m[1],
      zone: m[2]
    }
  }

  /*
   * 14080077|4155
   */
  m =
    /^(\d{5,20})\|(\d{1,10})$/.exec(s)

  if (m) {
    return {
      uid: m[1],
      zone: m[2]
    }
  }

  return null
}

/* =========================================================
   COUNTRY -> FLAG
   ========================================================= */

function iso2ToFlagEmoji(iso2 = '') {
  const cc = String(iso2 || '')
    .trim()
    .toUpperCase()

  if (!/^[A-Z]{2}$/.test(cc)) {
    return ''
  }

  const A = 0x1F1E6

  return String.fromCodePoint(
    ...[...cc].map(
      ch =>
        A +
        (ch.charCodeAt(0) - 65)
    )
  )
}

/* =========================================================
   COUNTRY NAME
   ========================================================= */

function countryName(code = '') {
  const cc = String(code || '')
    .trim()
    .toUpperCase()

  if (!cc) {
    return 'Tidak diketahui'
  }

  try {
    const names = new Intl.DisplayNames(
      ['id'],
      {
        type: 'region'
      }
    )

    return names.of(cc) || cc
  } catch {
    return cc
  }
}

/* =========================================================
   BONUS STATUS
   ========================================================= */

function isAvailable(item) {
  if (!item) return false

  if (item.CanBuy === true) {
    return true
  }

  return (
    String(item.status || '')
      .trim()
      .toLowerCase() === 'available'
  )
}

/* =========================================================
   WAKTU
   ========================================================= */

function waktu() {
  return new Date().toLocaleString(
    'id-ID',
    {
      timeZone: 'Asia/Jakarta'
    }
  )
}

/* =========================================================
   ERROR
   ========================================================= */

function getErrorMessage(err) {
  const data =
    err?.response?.data

  let message =
    data?.message ||
    data?.error ||
    err?.message ||
    'Terjadi kesalahan'

  if (typeof message !== 'string') {
    try {
      message =
        JSON.stringify(message)
    } catch {
      message =
        'Terjadi kesalahan'
    }
  }

  if (message.length > 300) {
    message =
      `${message.slice(0, 300)}...`
  }

  return message
}

/* =========================================================
   HANDLER
   ========================================================= */

async function plugin(
  m,
  {
    wafproject,
    args,
    text,
    usedPrefix,
    command
  }
) {
  if (!/^cekmcgg$/i.test(command)) {
    return
  }

  const raw =
    (
      args && args.length
        ? args.join(' ')
        : text || ''
    ).trim()

  const parsed =
    parseIdZone(raw)

  /* ================= FORMAT ERROR ================= */

  if (!parsed) {
    const pfx =
      usedPrefix || '.'

    return wafproject.sendMessage(
      m.chat,
      {
        text:
`❓ Format tidak valid.

Gunakan salah satu format berikut:
• ${pfx}cekmcgg 14080077 4155
• ${pfx}cekmcgg 14080077 (4155)
• ${pfx}cekmcgg 14080077|4155`
      },
      {
        quote: m
      }
    )
  }

  const {
    uid,
    zone
  } = parsed

  try {
    /* ================= LOADING ================= */

    await wafproject
      .sendMessage(
        m.chat,
        {
          react: {
            text: '🔎',
            key: m.key
          }
        }
      )
      .catch(() => {})

    /* ================= MERZZ ================= */

    const account =
      await fetchMerzzMCGG(
        uid,
        zone
      )

    const flag =
      iso2ToFlagEmoji(
        account.country
      )

    const region =
      countryName(
        account.country
      )

    /* ================= DOUBLE DIAMOND ================= */

    const bonusList =
      Array.isArray(
        account.rechargeBonus
      )
        ? account.rechargeBonus
        : []

    let bonusText = ''

    if (bonusList.length > 0) {
      bonusText +=
        '💎 *Status Double Diamond:*\n'

      for (const item of bonusList) {
        const available =
          isAvailable(item)

        const nominal =
          String(
            item?.diamonds || '-'
          ).trim()

        const icon =
          available
            ? '🔓'
            : '🔒'

        const status =
          available
            ? '✅ Tersedia'
            : '❌ Sudah Diambil'

        bonusText +=
          `${icon} ${nominal} ${status}\n`
      }

      bonusText += '\n'
    }

    /* ================= OUTPUT ================= */

    const teks =
`📊 *CHECK AKUN MAGIC CHESS GO GO*

🆔 *User ID*   : ${uid}
🌐 *Zone ID*   : ${zone}
👤 *Username*  : ${account.nickname}
🌏 *Region*    : ${flag ? `${flag} ` : ''}${region}
━━━━━━━━━━━━━━━━━━━━━
${bonusText}🕒 *Waktu Cek:*
${waktu()}`

    await wafproject.sendMessage(
      m.chat,
      {
        text: teks
      },
      {
        quote: m
      }
    )

    /* ================= SUCCESS ================= */

    await wafproject
      .sendMessage(
        m.chat,
        {
          react: {
            text: '✅',
            key: m.key
          }
        }
      )
      .catch(() => {})

  } catch (err) {
    /* ================= ERROR ================= */

    await wafproject
      .sendMessage(
        m.chat,
        {
          react: {
            text: '❌',
            key: m.key
          }
        }
      )
      .catch(() => {})

    console.error(
      '[ERROR][commands/stalk/cekmcgg.js]',
      err?.response?.status || '',
      err?.response?.data ||
      err?.message ||
      err
    )

    return wafproject.sendMessage(
      m.chat,
      {
        text:
          `❌ Error: ${getErrorMessage(err)}`
      },
      {
        quote: m
      }
    )
  }
}

/* =========================================================
   PLUGIN INFO
   ========================================================= */

plugin.command = [
  'cekmcgg'
]

plugin.category =
  'stalk'

plugin.description =
  'Cek akun Magic Chess Go Go via Merzz'

module.exports =
  plugin