/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

// stalk/autocekregion.js
//
// ✅ Auto detect ID ML + Zone
// ✅ Cek region via MERZZ MLBB
// ✅ React bendera saja
// ✅ Tanpa command
// ✅ Tanpa reply
// ✅ Strict format
// ✅ Cache 10 menit
// ✅ Anti double process

const axios = require('axios')
const crypto = require('crypto')

/* =========================================================
   CONFIG MERZZ
   ========================================================= */

const MERZZ = {
  baseUrl: 'https://merzzmlbb.id',

  apiPath: '/api/v3/mobile-legends',

  /*
   * Key yang dipakai frontend Merzz.
   * Key final = SHA256 dari string ini.
   */
  tokenSecret:
    'PHK2VCVXspyqyg/MTMDaQ0jslAqujTl+BrKaity4mck=',

  tokenVersion: 'v1.0.0'
}

/* =========================================================
   RETRY
   ========================================================= */

async function withRetry(
  fn,
  {
    retries = 2,
    baseDelay = 700
  } = {}
) {
  let lastErr

  for (
    let attempt = 0;
    attempt <= retries;
    attempt++
  ) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err

      const code =
        err?.code || ''

      const status =
        err?.response?.status || 0

      const message =
        String(
          err?.message || ''
        ).toLowerCase()

      const retryable =
        code === 'ECONNRESET' ||
        code === 'ETIMEDOUT' ||
        code === 'EAI_AGAIN' ||
        message.includes('socket hang up') ||
        message.includes('timeout') ||
        status === 429 ||
        status >= 500

      if (
        !retryable ||
        attempt === retries
      ) {
        break
      }

      await new Promise(resolve =>
        setTimeout(
          resolve,
          baseDelay * (attempt + 1)
        )
      )
    }
  }

  throw lastErr
}

/* =========================================================
   GENERATE MERZZ TOKEN
   ========================================================= */

function createMerzzToken(
  uid,
  zone
) {
  /*
   * Payload harus sama dengan frontend:
   *
   * {
   *   id: "...",
   *   server: "...",
   *   apipath: "/api/v3/mobile-legends"
   * }
   */

  const payload =
    JSON.stringify({
      id: String(uid),
      server: String(zone),
      apipath: MERZZ.apiPath
    })

  /*
   * SHA256 secret -> 32 byte key
   * untuk AES-256-GCM.
   */
  const key =
    crypto
      .createHash('sha256')
      .update(
        MERZZ.tokenSecret
      )
      .digest()

  /*
   * AES-GCM memakai IV random 12 byte.
   */
  const iv =
    crypto.randomBytes(12)

  const cipher =
    crypto.createCipheriv(
      'aes-256-gcm',
      key,
      iv
    )

  const encrypted =
    Buffer.concat([
      cipher.update(
        payload,
        'utf8'
      ),

      cipher.final()
    ])

  const authTag =
    cipher.getAuthTag()

  /*
   * Format frontend:
   *
   * IV + ciphertext + authTag
   *
   * lalu Base64.
   */
  const xToken =
    Buffer.concat([
      iv,
      encrypted,
      authTag
    ]).toString('base64')

  return {
    xToken,
    xTokenVersion:
      MERZZ.tokenVersion
  }
}

/* =========================================================
   MERZZ CHECK ML
   ========================================================= */

async function checkMerzzML(
  uid,
  zone
) {
  const token =
    createMerzzToken(
      uid,
      zone
    )

  const response =
    await withRetry(() =>
      axios.post(
        `${MERZZ.baseUrl}/api/pre-validate`,

        token,

        {
          headers: {
            'Content-Type':
              'application/json',

            /*
             * Header ini WAJIB.
             */
            'path':
              MERZZ.apiPath,

            'Origin':
              MERZZ.baseUrl,

            'Referer':
              `${MERZZ.baseUrl}/id-id/cekml`,

            'User-Agent':
              'Mozilla/5.0'
          },

          timeout: 20000,

          /*
           * Biar response error
           * tetap bisa kita baca.
           */
          validateStatus:
            () => true
        }
      )
    )

  const body =
    response.data

  /* ================= HTTP ================= */

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    throw new Error(
      `Merzz HTTP ${response.status}: ${
        body?.message ||
        body?.error ||
        'Request gagal'
      }`
    )
  }

  /* ================= RESPONSE ================= */

  if (
    !body ||
    body.status !== true
  ) {
    throw new Error(
      body?.message ||
      'Akun ML tidak valid / region gagal ditemukan'
    )
  }

  /*
   * Response yang sudah kita tes:
   *
   * {
   *   status: true,
   *   country: 'ID',
   *   nickname: 'krokodil',
   *   data: {
   *     country: 'ID',
   *     username: 'krokodil'
   *   }
   * }
   */

  const countryCode =
    String(
      body.country ||
      body?.data?.country ||
      ''
    )
      .trim()
      .toUpperCase()

  const nickname =
    String(
      body.nickname ||
      body?.data?.username ||
      ''
    ).trim()

  if (
    !/^[A-Z]{2}$/.test(
      countryCode
    )
  ) {
    throw new Error(
      `Country code Merzz tidak valid: ${
        countryCode || '-'
      }`
    )
  }

  return {
    uid:
      String(uid),

    zone:
      String(zone),

    nickname,

    countryCode
  }
}

/* =========================================================
   MESSAGE TEXT
   ========================================================= */

function getMessageText(m) {
  return String(
    m?.text ??
    m?.body ??
    m?.message?.conversation ??
    m?.message
      ?.extendedTextMessage
      ?.text ??
    m?.msg?.text ??
    m?.msg?.conversation ??
    ''
  ).trim()
}

/* =========================================================
   STRICT ID + ZONE PARSER
   ========================================================= */

/*
 * DITERIMA:
 *
 * 757454413 12026
 *
 * 757454413 (12026)
 *
 *
 * DITOLAK:
 *
 * cek 757454413 12026
 *
 * ID: 757454413
 *
 * 757454413|12026
 *
 * hello
 */

function parseIdZoneStrict(
  input = ''
) {
  const text =
    String(input || '')
      .trim()

  if (!text) {
    return null
  }

  /*
   * Hanya boleh:
   *
   * angka
   * spasi
   * tab
   * newline
   * (
   * )
   */
  if (
    !/^[0-9()\s]+$/.test(
      text
    )
  ) {
    return null
  }

  /* ================= UID ZONE ================= */

  let match =
    /^(\d{5,20})\s+(\d{1,10})$/.exec(
      text
    )

  if (match) {
    return {
      uid: match[1],
      zone: match[2]
    }
  }

  /* ================= UID (ZONE) ================= */

  match =
    /^(\d{5,20})\s*\(\s*(\d{1,10})\s*\)$/.exec(
      text
    )

  if (match) {
    return {
      uid: match[1],
      zone: match[2]
    }
  }

  return null
}

/* =========================================================
   COUNTRY CODE -> FLAG
   ========================================================= */

function iso2ToFlagEmoji(
  countryCode = ''
) {
  const cc =
    String(
      countryCode || ''
    )
      .trim()
      .toUpperCase()

  if (
    !/^[A-Z]{2}$/.test(
      cc
    )
  ) {
    return ''
  }

  /*
   * 🇦 = U+1F1E6
   */
  const REGIONAL_A =
    0x1F1E6

  const codePoints =
    [...cc].map(
      character =>
        REGIONAL_A +
        (
          character.charCodeAt(0) -
          65
        )
    )

  return String.fromCodePoint(
    ...codePoints
  )
}

/* =========================================================
   CACHE
   ========================================================= */

const cache =
  new Map()

const CACHE_MS =
  10 * 60 * 1000

function cacheGet(key) {
  const item =
    cache.get(key)

  if (!item) {
    return null
  }

  if (
    Date.now() -
      item.time >
    CACHE_MS
  ) {
    cache.delete(key)

    return null
  }

  return item.data
}

function cacheSet(
  key,
  data
) {
  cache.set(
    key,
    {
      time:
        Date.now(),

      data
    }
  )
}

/* =========================================================
   ANTI DOUBLE PROCESS
   ========================================================= */

const processedMessages =
  new Map()

const PROCESS_TTL =
  60 * 1000

function cleanupProcessed() {
  const now =
    Date.now()

  for (
    const [
      id,
      time
    ]
    of processedMessages
  ) {
    if (
      now - time >
      PROCESS_TTL
    ) {
      processedMessages.delete(id)
    }
  }
}

function markMessageOnce(m) {
  cleanupProcessed()

  const messageId =
    String(
      m?.key?.id ||
      m?.id ||
      ''
    )

  /*
   * Kalau base tidak memberikan ID,
   * biarkan tetap jalan.
   */
  if (!messageId) {
    return true
  }

  if (
    processedMessages.has(
      messageId
    )
  ) {
    return false
  }

  processedMessages.set(
    messageId,
    Date.now()
  )

  return true
}

/* =========================================================
   REACTION
   ========================================================= */

async function react(
  wafproject,
  m,
  emoji
) {
  if (!emoji) {
    return
  }

  try {
    await wafproject.sendMessage(
      m.chat,

      {
        react: {
          text:
            emoji,

          key:
            m.key
        }
      }
    )
  } catch (err) {
    console.error(
      '[AUTO ML REGION][REACT ERROR]',
      err?.message ||
      err
    )
  }
}

/* =========================================================
   ERROR LOGGER
   ========================================================= */

function logError(err) {
  const status =
    err?.response?.status ||
    '-'

  const responseData =
    err?.response?.data

  let message =
    responseData?.message ||
    responseData?.error ||
    err?.message ||
    'Unknown error'

  if (
    typeof message !==
    'string'
  ) {
    try {
      message =
        JSON.stringify(
          message
        )
    } catch {
      message =
        'Unknown error'
    }
  }

  if (
    message.length >
    500
  ) {
    message =
      `${message.slice(
        0,
        500
      )}...`
  }

  console.error(
    '[AUTO ML REGION ERROR]',
    {
      status,
      message
    }
  )
}

/* =========================================================
   CORE
   ========================================================= */

async function core(
  m,
  {
    wafproject
  } = {}
) {
  try {
    if (
      !m ||
      !wafproject
    ) {
      return
    }

    /* ================= BOT MESSAGE ================= */

    if (
      m.fromMe
    ) {
      return
    }

    /*
     * Jangan proses pesan dari
     * nomor session bot sendiri.
     */
    if (
      m.fromMe
    ) {
      return
    }

    /* ================= TEXT ================= */

    const text =
      getMessageText(m)

    if (!text) {
      return
    }

    /*
     * Jangan ganggu command.
     */
    const first =
      text.charAt(0)

    if (
      first === '.' ||
      first === '!' ||
      first === '/' ||
      first === '#'
    ) {
      return
    }

    /* ================= PARSE ================= */

    const parsed =
      parseIdZoneStrict(
        text
      )

    if (!parsed) {
      return
    }

    /* ================= ANTI DOUBLE ================= */

    if (
      !markMessageOnce(m)
    ) {
      return
    }

    const {
      uid,
      zone
    } = parsed

    console.log(
      `[AUTO ML REGION] Terdeteksi: ${uid} (${zone})`
    )

    /* ================= CACHE ================= */

    const cacheKey =
      `${uid}|${zone}`

    let result =
      cacheGet(
        cacheKey
      )

    if (result) {
      console.log(
        `[AUTO ML REGION] Cache: ${uid} (${zone})`
      )
    }

    /* ================= MERZZ ================= */

    if (!result) {
      result =
        await checkMerzzML(
          uid,
          zone
        )

      cacheSet(
        cacheKey,
        result
      )
    }

    /* ================= FLAG ================= */

    const flag =
      iso2ToFlagEmoji(
        result.countryCode
      )

    if (!flag) {
      console.log(
        `[AUTO ML REGION] Flag tidak valid: ${result.countryCode}`
      )

      return
    }

    console.log(
      '[AUTO ML REGION] RESULT',
      {
        uid,
        zone,

        nickname:
          result.nickname ||
          '-',

        country:
          result.countryCode,

        flag
      }
    )

    /* ================= REACT ================= */

    await react(
      wafproject,
      m,
      flag
    )

    console.log(
      `[AUTO ML REGION] React ${flag}: ${uid} (${zone})`
    )

  } catch (err) {
    /*
     * Tidak reply error ke WhatsApp.
     * Hanya terminal.
     */
    logError(err)
  }
}

/* =========================================================
   EXPORT
   ========================================================= */

const handler =
  async (
    m,
    ctx
  ) => {
    return core(
      m,
      ctx
    )
  }

handler.before =
  async (
    m,
    ctx
  ) => {
    return core(
      m,
      ctx
    )
  }

handler.all =
  async (
    m,
    ctx
  ) => {
    return core(
      m,
      ctx
    )
  }

/* =========================================================
   CUSTOM PREFIX
   ========================================================= */

/*
 * Hanya trigger pesan:
 *
 * angka
 * whitespace
 * (
 * )
 */

handler.customPrefix =
  /^[0-9()\s]+$/

/*
 * Dibutuhkan beberapa loader plugin.
 */
handler.command =
  new RegExp(
    '^$',
    'i'
  )

module.exports =
  handler