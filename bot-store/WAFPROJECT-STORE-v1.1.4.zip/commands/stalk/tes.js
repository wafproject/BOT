const axios = require('axios')

async function plugin(m, { wafproject, args, text, usedPrefix, command }) {
  if (!/^testcutiezy$/i.test(command)) return

  const input = (args && args.length ? args.join(' ') : text || '').trim()
  const match = /^(\d{5,20})\s+(\d{1,10})$/.exec(input)

  if (!match) {
    return wafproject.sendMessage(m.chat, {
      text: `Format:\n${usedPrefix || '.'}testcutiezy 1374117562 15661`
    }, { quote: m })
  }

  const user_id = match[1]
  const zone_id = match[2]

  if (!global.cutiezy || !global.cutiezykey) {
    return wafproject.sendMessage(m.chat, {
      text: '❌ global.cutiezy / global.cutiezykey belum diset di settings.js'
    }, { quote: m })
  }

  try {
    await wafproject.sendMessage(m.chat, { react: { text: '🔎', key: m.key } })

    const url = `${global.cutiezy}/api/check/games`

    const res = await axios.get(url, {
      timeout: 20000,
      params: {
        service: 'first-topup',
        user_id,
        zone_id
      },
      headers: {
        'X-API-Key': global.cutiezykey,
        'User-Agent': 'Mozilla/5.0'
      },
      validateStatus: () => true
    })

    const data = res.data

    const teks =
`🧪 *TEST API CUTIEZY*

📡 Status HTTP: ${res.status}
✅ Success: ${data?.success}
💬 Message: ${data?.message || '-'}

🆔 User ID: ${data?.data?.id || user_id}
🌐 Zone ID: ${data?.data?.zone || zone_id}
👤 Nickname: ${data?.data?.nickname || '-'}
🌏 Country: ${data?.data?.country_flag || ''} ${data?.data?.country || '-'}

💎 First Topup:
${Array.isArray(data?.data?.first_topup)
  ? data.data.first_topup.map(x => `• ${x.denom} = ${x.status}`).join('\n')
  : '-'}

📦 Raw:
${JSON.stringify(data, null, 2).slice(0, 2500)}`

    await wafproject.sendMessage(m.chat, { text: teks }, { quote: m })
    await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (err) {
    await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})

    return wafproject.sendMessage(m.chat, {
      text: `❌ Error: ${err?.message || err}`
    }, { quote: m })
  }
}

plugin.command = ['testcutiezy']
plugin.category = 'tools'
plugin.description = 'Test API Cutiezy first-topup ML'

module.exports = plugin