/* 🚀 WAF PROJECT - Anti Spam Command (WAF BOT CJS)
   Jangan hapus credit WAF PROJECT ya :)
*/

const spamUsers = Object.create(null)

// batas spam
const SPAM_MAX = 1              // maksimal command berturut-turut dalam window
const SPAM_DELAY = 4000         // window ms untuk ngitung spam
const WARN_LIMIT = 2            // total warn sebelum ban
const WARN_RESET_TIME = 420000  // 7 menit, warn turun 1
const BAN_DURATION = 10800000   // 3 jam

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    const meta = await wafproject.groupMetadata(chatJid)
    const participants = meta?.participants || []

    const isAdmin = participants.some(
      (p) =>
        (p.id === senderJid || p.jid === senderJid) &&
        (p.admin === 'admin' || p.admin === 'superadmin')
    )

    const botId = wafproject.user?.id || wafproject.user?.jid
    const isBotAdmin = participants.some(
      (p) =>
        (p.id === botId || p.jid === botId) &&
        (p.admin === 'admin' || p.admin === 'superadmin')
    )

    return { isAdmin, isBotAdmin }
  } catch {
    return { isAdmin: false, isBotAdmin: false }
  }
}

function getPrefixList() {
  // di bot kamu titik harus selalu ada
  const base = ['.']

  const gp = global.prefix
  if (Array.isArray(gp)) {
    for (const p of gp) {
      if (typeof p === 'string' && p) base.push(p)
    }
  } else if (typeof gp === 'string') {
    if (gp) base.push(gp)
  }

  return Array.from(new Set(base))
}

function isCommandText(text) {
  if (!text) return false
  const t = String(text).trim()
  if (!t) return false

  const prefixes = getPrefixList()
  const prefix = prefixes.find((p) => p && t.startsWith(p))
  if (!prefix) return false

  const after = t.slice(prefix.length).trim()
  if (!after) return false

  const cmd = after.split(/\s+/)[0]
  return /^[a-z0-9_]+$/i.test(cmd)
}

// helper save db (biar cocok sama sistem kamu yang autosave)
async function safeSaveDB(db) {
  try {
    if (typeof db?.save === 'function') return await db.save()
    // kalau db.save gak ada, biasanya root itu refer ke global.db dan autosave yang nulis
    return true
  } catch {
    return false
  }
}

const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner, isAdmin, isBotAdmin }) {
  try {
    if (!m) return

    // ambil text aman
    const rawText =
      m.text ||
      m.body ||
      m.message?.conversation ||
      m.message?.extendedTextMessage?.text ||
      m.message?.imageMessage?.caption ||
      m.message?.videoMessage?.caption ||
      ''

    if (!rawText) return

    // cek apakah ini command
    if (!isCommandText(rawText)) return

    // owner skip
    if (isOwner === true) return

    const botId = wafproject?.user?.id || wafproject?.user?.jid || ''
    if (botId && m.sender && String(botId) === String(m.sender)) return

    // jika grup: cek admin status
    let admin = !!isAdmin
    let botAdmin = !!isBotAdmin

    if (m.isGroup && (!isAdmin || !isBotAdmin)) {
      const st = await getAdminStatus(wafproject, m.chat, m.sender)
      admin = !!(isAdmin || st.isAdmin)
      botAdmin = !!(isBotAdmin || st.isBotAdmin)
    }

    // admin grup bebas anti spam
    if (m.isGroup && admin) return

    // init db schema bot kamu
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    root.user ||= {}

    // init chat setting
    const chat = root.group[m.chat] || (root.group[m.chat] = {})

    // ✅ FIX: nama toggle harus "antispamchat" sesuai fitur kamu
    if (typeof chat.antispamchat !== 'boolean') chat.antispamchat = false

    // antispamchat off
    if (!chat.antispamchat) return

    // init user
    const sender = m.sender
    root.user[sender] ||= {}
    const u = root.user[sender]

    if (typeof u.warnSpam !== 'number') u.warnSpam = 0
    if (typeof u.bannedSpam !== 'boolean') u.bannedSpam = false
    if (typeof u.bannedSpamProcessing !== 'boolean') u.bannedSpamProcessing = false

    // kalau lagi banned
    if (u.bannedSpam) return

    const now = Date.now()

    // hitung spam
    if (!spamUsers[sender]) {
      spamUsers[sender] = { count: 1, lastMessage: now }
    } else {
      const diff = now - spamUsers[sender].lastMessage
      if (diff < SPAM_DELAY) spamUsers[sender].count++
      else spamUsers[sender].count = 1
      spamUsers[sender].lastMessage = now
    }

    // kena spam
    if (spamUsers[sender].count > SPAM_MAX) {
      u.warnSpam += 1
      await safeSaveDB(db)

      if (u.warnSpam === 1) {
        await wafproject.sendMessage(
          m.chat,
          {
            text:
`⚠️ *PERINGATAN SPAM (1/${WARN_LIMIT})*
@${sender.split('@')[0]}, jangan spam command ya.
Jika sampai ${WARN_LIMIT} kali, kamu akan *dibanned 3 jam*.`,
            mentions: [sender]
          },
          { quote: m }
        )
      } else if (u.warnSpam === 2) {
        await wafproject.sendMessage(
          m.chat,
          {
            text:
`⚠️ *PERINGATAN SPAM (2/${WARN_LIMIT})*
@${sender.split('@')[0]}, sekali lagi spam bakal *auto banned*.`,
            mentions: [sender]
          },
          { quote: m }
        )
      }

      // auto ban
      if (u.warnSpam >= WARN_LIMIT && !u.bannedSpamProcessing) {
        u.bannedSpamProcessing = true
        u.bannedSpam = true
        await safeSaveDB(db)

        await wafproject.sendMessage(m.chat, {
          text:
`🚫 *ANDA TELAH DIBANNED OLEH WAF PROJECT* 🚫
@${sender.split('@')[0]} dibanned selama *3 jam* karena spam command.`,
          mentions: [sender]
        })

        setTimeout(async () => {
          try {
            const root2 = db?.list ? db.list() : root
            root2.user ||= {}
            root2.user[sender] ||= u

            root2.user[sender].bannedSpam = false
            root2.user[sender].warnSpam = 0
            root2.user[sender].bannedSpamProcessing = false
            await safeSaveDB(db)

            await wafproject.sendMessage(m.chat, {
              text:
`✅ @${sender.split('@')[0]} sudah di-unban otomatis.
> Jangan spam lagi ya.`,
              mentions: [sender]
            })
          } catch (_error) { console.error("[ERROR][commands/group/antispam.js]", _error?.message || _error) }
        }, BAN_DURATION)

        spamUsers[sender].count = 0
        return
      }

      // reset warn bertahap
      setTimeout(async () => {
        try {
          const root2 = db?.list ? db.list() : root
          root2.user ||= {}
          if (!root2.user[sender]) return

          if (root2.user[sender].warnSpam > 0) {
            root2.user[sender].warnSpam -= 1
            await safeSaveDB(db)
          }
        } catch (_error) { console.error("[ERROR][commands/group/antispam.js]", _error?.message || _error) }
      }, WARN_RESET_TIME)

      spamUsers[sender].count = 0
    }
  } catch (e) {
    console.error('antispam.before error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // hook only
module.exports = handler