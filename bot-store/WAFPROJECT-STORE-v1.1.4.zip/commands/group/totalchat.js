// ✨ Plugin group - totalchat (STYLE LIST + Global AntiLID) ✨
// Commands: .totalchat / .resetchat
//
// ✅ Count chat otomatis (handler.all)
// ✅ Global antiLID (pakai resolver global, tanpa mapping sendiri)
// ✅ Bot yang ter-connect TIDAK ditampilkan & TIDAK di-mention (safe)
//
// NOTE: kalau mau bot ikut tampil di ranking, ubah HIDE_BOT_FROM_LIST = false

const HIDE_BOT_FROM_LIST = true

let handler = async (m, { wafproject, command }) => {
  const chat = (db.data.chats[m.chat] = db.data.chats[m.chat] || {})
  chat.total = chat.total || {}

  // warmup mapping global (throttle) biar mention/lid makin stabil
  scheduleWarmupThrottled(wafproject, m.chat)

  // bot jid yang ter-connect
  const botJid = getConnectedBotJid(wafproject, m.chat)

  // ambil metadata grup
  let meta
  try {
    meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return m.reply('❌ Gagal mengambil data grup. Coba lagi nanti.')
  }

  const participants = meta?.participants || []

  // peserta aktif (key konsisten via resolver global)
  const pesertaAktifAll = participants
    .map(p => resolveJid(wafproject, m.chat, p?.jid || p?.id || p?.participant || p?.lid || ''))
    .filter(Boolean)

  const pesertaAktif = HIDE_BOT_FROM_LIST && botJid
    ? pesertaAktifAll.filter(j => j !== botJid)
    : pesertaAktifAll

  // reset
  if (command === 'resetchat') {
    if (!Object.keys(chat.total || {}).length) return m.reply('Belum ada data pesan untuk direset.')
    chat.total = {}
    db.data.chats[m.chat] = chat
    return m.reply('✅ Statistik total chat berhasil direset!')
  }

  // hydrate (biar semua member muncul walau 0)
  for (const jid of pesertaAktifAll) {
    if (typeof chat.total[jid] !== 'number') chat.total[jid] = 0
  }

  const aktifSet = new Set(pesertaAktifAll)

  // data valid: hanya member aktif grup
  let sortedData = Object.entries(chat.total)
    .filter(([jid]) => aktifSet.has(jid))
    .sort((a, b) => (b[1] || 0) - (a[1] || 0))

  // hide bot dari list ranking (kalau diaktifkan)
  if (HIDE_BOT_FROM_LIST && botJid) {
    sortedData = sortedData.filter(([jid]) => jid !== botJid)
  }

  const totalMessages = Object.entries(chat.total)
    .filter(([jid]) => aktifSet.has(jid))
    .reduce((acc, [, c]) => acc + (c || 0), 0)

  const totalMember = pesertaAktif.length

  // mention: hanya user manusia (exclude bot), supaya nomor bot gak ke-mention
  const mentions = pesertaAktif.filter(j => String(j).endsWith('@s.whatsapp.net'))

  // format list seperti screenshot
  const header =
    `📊 *STATISTIK CHAT GRUP*\n\n` +
    `📝  Total Pesan : *${totalMessages}*\n` +
    `👥  Total Member : *${totalMember}*\n\n` +
    `🔥 *MEMBER AKTIF*\n` +
    `───────────────\n`

  const rows = sortedData
    .map(([jid, count], i) => {
      const num = String(jid).split('@')[0]
      // medal icon mirip screenshot (1-3 special)
      const icon =
        i === 0 ? '🥇' :
        i === 1 ? '🥈' :
        i === 2 ? '🥉' :
        '🔹'

      return `${icon} *${i + 1}.* @${num}\n└ 💬 *${count || 0}* pesan`
    })
    .join('\n\n')

  const text = header + (rows || 'Belum ada data.')

  await wafproject.sendMessage(m.chat, { text, mentions }, { quote: m })
}

handler.help = ['totalchat', 'resetchat']
handler.category = ['group']
handler.command = /^(totalchat|resetchat)$/i
handler.group = true
handler.admin = true

// ✅ count pesan masuk grup (chat biasa juga kehitung)
handler.all = async function (m, { wafproject }) {
  try {
    if (!m?.isGroup) return
    if (!m?.chat) return

    const chat = (db.data.chats[m.chat] = db.data.chats[m.chat] || {})
    chat.total = chat.total || {}

    scheduleWarmupThrottled(wafproject, m.chat)

    const senderRaw = m.sender || m.participant || m.key?.participant || ''
    const senderKey = resolveJid(wafproject, m.chat, senderRaw)
    if (!senderKey) return

    // ✅ pesan bot juga harus kehitung → JANGAN skip fromMe
    // Tapi kalau nanti mau exclude bot dari hitungan, baru skip di sini.

    if (typeof chat.total[senderKey] !== 'number') chat.total[senderKey] = 0
    chat.total[senderKey] += 1

    db.data.chats[m.chat] = chat
  } catch (_error) { console.error("[ERROR][commands/group/totalchat.js]", _error?.message || _error) }
}

handler.register = true
module.exports = handler

// ===============================
// bot jid connected (pakai wafproject.decodeJid seperti index.js)
// ===============================
function getConnectedBotJid(wafproject, groupId) {
  try {
    const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
    if (!raw) return ''
    const decoded = typeof wafproject.decodeJid === 'function' ? wafproject.decodeJid(raw) : raw
    return resolveJid(wafproject, groupId, decoded)
  } catch {
    return ''
  }
}

// ===============================
// GLOBAL RESOLVER (AntiLID)
// ===============================
function resolveJid(wafproject, groupId, any) {
  const raw = String(any || '').trim()
  if (!raw) return ''
  try {
    if (global.JidNormalizer && typeof global.JidNormalizer.resolveToRealJidSync === 'function') {
      return String(global.JidNormalizer.resolveToRealJidSync(groupId, raw) || raw).trim()
    }
  } catch (_error) { console.error("[ERROR][commands/group/totalchat.js]", _error?.message || _error) }
  try {
    if (typeof global.normalizeJid === 'function') return String(global.normalizeJid(raw) || raw).trim()
    if (typeof global.jidNormalized === 'function') return String(global.jidNormalized(raw) || raw).trim()
    if (global.JidNormalizer && typeof global.JidNormalizer.normalize === 'function') {
      return String(global.JidNormalizer.normalize(raw) || raw).trim()
    }
  } catch (_error) { console.error("[ERROR][commands/group/totalchat.js]", _error?.message || _error) }
  return raw
}

// ===============================
// WARMUP THROTTLE (non-blocking)
// ===============================
function scheduleWarmupThrottled(wafproject, groupId) {
  try {
    if (!groupId || !String(groupId).endsWith('@g.us')) return
    if (!global.JidNormalizer || typeof global.JidNormalizer.warmupGroupCache !== 'function') return

    wafproject._tcWarm = wafproject._tcWarm || {}
    const last = wafproject._tcWarm[groupId] || 0
    if (Date.now() - last < 60 * 1000) return

    wafproject._tcWarm[groupId] = Date.now()
    void global.JidNormalizer.warmupGroupCache(wafproject, groupId)
  } catch (_error) { console.error("[ERROR][commands/group/totalchat.js]", _error?.message || _error) }
}