/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur : Anti Promo (HOOK ONLY) — STYLE ANTITOXIC
✅ Toggle: chat.antiPromo (sesuai menu on/off kamu)
✅ Skip admin & owner
✅ Delete pesan + warn + kick jika bot admin
========================
*/

const fs = require('fs')
const path = require('path')

// lokasi penyimpanan (tetap)
const promoDbPath = path.join(process.cwd(), 'lib', 'datapromo.json')

const defaultPromoWords = [
  '#WTS','buy pm','hub:','ingin order?','jual cepat','buy panel pm','buy? pm',
  'melayani :','melayani:','minat hub','minat?','need akun','need dana','open murbug',
  '#WTT','pm for price','fast order','hubungi wa:','ready stock','order sekarang',
  'promo hari ini','cek dm','langsung wa','murah meriah','stok terbatas','pm je','nego tipis',
  'wa.me','t.me','bit.ly','tinyurl','link wa','order','open','ready'
].map(v => String(v).toLowerCase())

const MAX_WARN = 3

// ===== DB WORDS =====
function ensurePromoDb() {
  try {
    const dir = path.dirname(promoDbPath)
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

    if (!fs.existsSync(promoDbPath)) {
      fs.writeFileSync(promoDbPath, JSON.stringify(defaultPromoWords, null, 2))
      return
    }

    const raw = fs.readFileSync(promoDbPath, 'utf8')
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed) || parsed.length === 0) {
      fs.writeFileSync(promoDbPath, JSON.stringify(defaultPromoWords, null, 2))
    }
  } catch {
    try { fs.writeFileSync(promoDbPath, JSON.stringify(defaultPromoWords, null, 2)) } catch (_error) { console.error("[ERROR][commands/group/antipromo.js]", _error?.message || _error) }
  }
}

function loadPromoWords() {
  ensurePromoDb()
  try {
    const raw = fs.readFileSync(promoDbPath, 'utf8')
    const arr = JSON.parse(raw)
    return Array.isArray(arr) ? arr.map(v => String(v).toLowerCase()) : [...defaultPromoWords]
  } catch {
    return [...defaultPromoWords]
  }
}

// ===== TEXT GETTER (SAMAKAN POLA ANTITOXIC) =====
function getBody(m) {
  return (
    m.text ||
    m.body ||
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.documentMessage?.caption ||
    ''
  )
}

// normalize biar "buy? pm" == "buy pm"
function normalizeText(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[\u200e\u200f\u202a-\u202e]/g, '')
    .replace(/https?:\/\/\S+/g, (u) => u) // biarin url tetap kebaca
    .replace(/[^a-z0-9]+/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function detectPromo(body, words) {
  const raw = String(body || '').toLowerCase()
  const norm = normalizeText(raw)

  for (const w of words) {
    const key = String(w || '').toLowerCase().trim()
    if (!key) continue

    // mode raw (buat yang butuh ":" "/" ".")
    if (raw.includes(key)) return key

    // mode normalized (buat yang ada simbol)
    const normKey = normalizeText(key)
    if (normKey && norm.includes(normKey)) return key
  }
  return null
}

const handler = (m) => m

// ✅ HOOK ONLY: jalan sebelum command lain
handler.before = async function (m, { wafproject, db, isOwner, isAdmin, isBotAdmin }) {
  try {
    if (!m || !wafproject || !db) return
    if (!m.isGroup) return
    if (!m.message) return
    if (m.fromMe) return

    // ===== init schema sesuai bot kamu =====
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    root.user ||= {}

    const chat = root.group[m.chat] || (root.group[m.chat] = {})
    // ✅ toggle harus ini (sesuai menu on/off kamu)
    if (!chat.antiPromo) return

    const body = getBody(m)
    if (!body) return

    // skip owner & admin
    if (isOwner) return
    if (m.isGroup && isAdmin) return

    // bot harus admin biar bisa delete/kick
    if (m.isGroup && !isBotAdmin) return

    const promoWords = loadPromoWords()
    const detected = detectPromo(body, promoWords)
    if (!detected) return

    const who = m.sender

    // init warn
    root.user[who] ||= {}
    if (typeof root.user[who].warnPromo !== 'number') root.user[who].warnPromo = 0

    // delete pesan promo
    try {
      if (m.key) await wafproject.sendMessage(m.chat, { delete: m.key })
    } catch (e) {
      console.error('[ANTIPROMO] gagal delete:', e)
    }

    // warn / kick
    root.user[who].warnPromo += 1
    await db.save?.()

    if (root.user[who].warnPromo < MAX_WARN) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `🚫 *ANTI PROMO AKTIF!*\n\n` +
            `👤 User: @${who.split('@')[0]}\n` +
            `🔎 Deteksi: *${detected}*\n` +
            `⚠️ Warning: ${root.user[who].warnPromo}/${MAX_WARN}\n\n` +
            `> Pesan dihapus karena terindikasi promosi.`,
          mentions: [who]
        },
        { quote: m }
      )
      return
    }

    // kick kalau sudah max warn
    root.user[who].warnPromo = 0
    await db.save?.()

    await wafproject.sendMessage(m.chat, {
      text: `⛔ *@${who.split('@')[0]} dikeluarkan karena promosi (melewati ${MAX_WARN} warning).*`,
      mentions: [who]
    })

    await new Promise((r) => setTimeout(r, 1500))
    await wafproject.groupParticipantsUpdate(m.chat, [who], 'remove').catch(() => {})

  } catch (e) {
    console.error('antipromo.before error:', e)
  }
}

handler.help = [''] // opsional buat menu
handler.category = ['group']
handler.command = [] // ✅ hook only
module.exports = handler