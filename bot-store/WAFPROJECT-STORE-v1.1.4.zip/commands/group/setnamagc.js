let handler = async (m, { wafproject, text, usedPrefix, command, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('❌ Command ini khusus grup.')
  if (!isAdmin && !isOwner) return m.reply('❌ Khusus admin grup.')

  const name = (text || '').trim()
  if (!name) {
    return m.reply(
      `Masukkan nama grup!\n\n` +
      `Contoh:\n${usedPrefix + command} WAFPROJECT Official`
    )
  }

  const react = async (emoji) => {
    try { await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/setnamagc.js]", _error?.message || _error) }
  }

  try {
    await react('🕒')

    // update nama grup
    await wafproject.groupUpdateSubject(m.chat, name)

    await react('✅')
    return m.reply('✅ Berhasil mengubah nama grup.')
  } catch (e) {
    console.error('SETNAMAGC ERROR:', e?.message || e)
    await react('❌')
    return m.reply(`❌ Error: ${e?.message || e}`)
  }
}

handler.help = ['setnamagc <nama>']
handler.category = ['admin']
handler.command = ['setnamagc', 'setnamegc']
handler.group = true
handler.admin = true
handler.register = true

module.exports = handler