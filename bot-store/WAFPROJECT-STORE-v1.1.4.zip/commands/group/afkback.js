// ✨ Plugin bot - AFK BACK ONLY (Humoris + Thumbnail) ✨
// - Auto hapus AFK saat user AFK ngomong lagi
// - LID SAFE: resolve sender @lid -> @s.whatsapp.net via groupMetadata
// - Skip jika pesan adalah command .afk

async function core(m, { wafproject }) {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (m.fromMe === true) return

    // anti double-run (kalau before + all kepanggil)
    if (m._afkBackDone) return
    m._afkBackDone = true

    const msgText = getText(m)
    if (/^\.?afk(\s+|$)/i.test(msgText)) return

    global.db = global.db || {}
    global.db.data = global.db.data || {}
    global.db.data.chats = global.db.data.chats || {}

    const chat = (global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {})
    chat.afk = chat.afk || {}

    // ambil sender raw dari message
    const senderRaw = extractSenderRaw(m)
    if (!senderRaw) return

    // normalize + resolve (LID -> real jid)
    const senderNorm = normJid(senderRaw)
    const senderReal = await resolveToRealJid(wafproject, m, senderNorm)

    // cari record AFK dengan beberapa kemungkinan key
    const keysToTry = [
      senderReal,
      senderNorm,
      senderRaw,
      normJid(senderRaw),
    ].filter(Boolean)

    let hitKey = keysToTry.find(k => chat.afk[k])
    if (!hitKey) return

    const info = chat.afk[hitKey]
    delete chat.afk[hitKey]

    const now = Date.now()
    const dur = formatDuration(now - (info.time || now))

    const userName = getNameSafe(wafproject, senderReal || hitKey, m)
    const alasan = info.reason?.trim() ? info.reason.trim() : "tanpa jejak, tanpa alasan 😭"

    // thumbnail: persis seperti AFK (pakai pp user real)
    let ppUrl = global.thumb
    try {
      if (typeof wafproject?.profilePictureUrl === "function") {
        const picJid = (senderReal && String(senderReal).endsWith("@s.whatsapp.net")) ? senderReal : hitKey
        ppUrl = await wafproject.profilePictureUrl(picJid, "image")
      }
    } catch (_error) { console.error("[ERROR][commands/group/afkback.js]", _error?.message || _error) }

    const msg =
      `✅ *${userName}* udah balik lagi!\n\n` +
      `AFK-nya selesai…\n` +
      `Tadi katanya: *${alasan}* 😹\n\n` +
      `– ⏱️ Durasi: ${dur}\n` +
      `– 🎭 Status: mode manusia aktif lagi`

    const mentions = [ (senderReal && String(senderReal).endsWith("@s.whatsapp.net")) ? senderReal : hitKey ].filter(Boolean)
    if (typeof wafproject.sendRichPreview === "function") {
      await wafproject.sendRichPreview(
        m.chat,
        {
          text: msg,
          title: "✅ PENGGUNA SUDAH KEMBALI",
          body: "Akhirnya kembali ke realita 😌",
          thumbnailUrl: ppUrl,
          mediaType: 1,
          renderLargerThumbnail: false,
        },
        { quote: m, mentions }
      )
    } else {
      await wafproject.sendMessage(m.chat, { text: msg, mentions }, { quote: m, mentions })
    }
  } catch (_error) { console.error("[ERROR][commands/group/afkback.js]", _error?.message || _error) }
}

const handler = async (m, ctx) => core(m, ctx)
handler.before = async (m, ctx) => core(m, ctx)
handler.all = async (m, ctx) => core(m, ctx)
handler.command = new RegExp("^$", "i")
module.exports = handler

// =================== HELPERS ===================

function extractSenderRaw(m) {
  return (
    m?.sender ||
    m?.participant ||
    m?.key?.participant ||
    m?.key?.fromMe && m?.key?.remoteJid || // fallback
    ""
  )
}

function normJid(id) {
  try {
    if (typeof global.normalizeJid === "function") return String(global.normalizeJid(id) || "")
    if (typeof global.jidNormalized === "function") return String(global.jidNormalized(id) || "")
    if (global.JidNormalizer && typeof global.JidNormalizer.normalize === "function") {
      return String(global.JidNormalizer.normalize(id) || "")
    }
  } catch (_error) { console.error("[ERROR][commands/group/afkback.js]", _error?.message || _error) }
  // fallback minimal: buang suffix device ":xx"
  return String(id || "").replace(/:.*@/, "@").trim()
}

// ✅ resolve seperti addprem (LID SAFE)
async function resolveToRealJid(wafproject, m, rawJid) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith("@s.whatsapp.net")) return s
  if (!m.isGroup) return s

  let meta
  try {
    meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const participants = meta?.participants || []
  const found = participants.find(p =>
    p?.lid === s ||
    p?.id === s ||
    p?.jid === s ||
    p?.participant === s
  )

  return found?.jid || found?.id || found?.participant || s
}

function getText(m) {
  return String(
    m?.text ??
      m?.body ??
      m?.message?.conversation ??
      m?.message?.extendedTextMessage?.text ??
      m?.message?.imageMessage?.caption ??
      m?.message?.videoMessage?.caption ??
      ""
  ).trim()
}

function getNameSafe(wafproject, jid, m) {
  try {
    if (wafproject && typeof wafproject.getName === "function") {
      const n = wafproject.getName(jid)
      if (n) return n
    }
  } catch (_error) { console.error("[ERROR][commands/group/afkback.js]", _error?.message || _error) }
  try {
    const c = wafproject?.contacts?.[jid]
    const n = c?.name || c?.notify || c?.verifiedName
    if (n) return n
  } catch (_error) { console.error("[ERROR][commands/group/afkback.js]", _error?.message || _error) }
  return m?.pushName || "Pengguna"
}

function formatDuration(ms) {
  if (!ms || ms < 0) ms = 0
  const s = Math.floor(ms / 1000)
  const m = Math.floor(s / 60)
  const h = Math.floor(m / 60)
  const d = Math.floor(h / 24)

  const hh = h % 24
  const mm = m % 60
  const ss = s % 60

  const out = []
  if (d) out.push(`${d} hari`)
  if (hh) out.push(`${hh} jam`)
  if (mm) out.push(`${mm} menit`)
  if (!out.length) out.push(`${ss} detik`)
  return out.join(" ")
}