
// CJS version for WAF PROJECT

let handler = async (m, { wafproject, text, participants, isAdmin, isOwner }) => {
  try {
    // khusus grup
    if (!m.isGroup) {
      return wafproject.sendMessage(m.chat, { text: '🚩 Fitur ini hanya untuk grup.' }, { quote: m })
    }

    // khusus admin/owner (mengikuti gaya plugin lain)
    if (!(isAdmin || isOwner)) {
      return wafproject.sendMessage(m.chat, { text: '🚫 Khusus admin/owner grup.' }, { quote: m })
    }

    // pastikan participants ada
    let members = Array.isArray(participants) && participants.length ? participants : []
    if (!members.length) {
      try {
        const meta = await wafproject.groupMetadata(m.chat)
        members = meta?.participants || []
      } catch {
        members = []
      }
    }

    const pesan = (text || '').trim()
    let teks =
`◇───── Tag All ─────◇
乂 *Pesan : ${pesan ? pesan : 'kosong'}*\n\n`

    for (let mem of members) {
      const jid = mem?.id || mem?.jid || mem?.participant || ''
      if (!jid) continue
      teks += `• @${jid.split('@')[0]}\n`
    }

    const mentions = members
      .map(a => a?.id || a?.jid || a?.participant)
      .filter(Boolean)

    await wafproject.sendMessage(
      m.chat,
      { text: teks, mentions },
      { quote: m }
    )
  } catch (e) {
    console.error('TAGALL ERROR:', e)
    await wafproject.sendMessage(m.chat, { text: '❌ Gagal menjalankan tagall.' }, { quote: m })
  }
}

handler.help = ['tagall']
handler.category = ['admin']
handler.command = ['tagall']
handler.admin = true
handler.group = true

module.exports = handler