// ✨ Plugin: Pengaturan fitur grup & bot (on/off + .oncek) — CJS WAF BOT (FIX: notif on/off)
let handler = async (m, { wafproject, text, usedPrefix, command, args, isOwner, isAdmin, isROwner, db }) => {
  if (!m) return

  // ===== helper reply aman =====
  const send = (txt) => wafproject.sendMessage(m.chat, { text: String(txt) }, { quote: m })

  // ===== init opts =====
  global.opts = global.opts || {}

  // ===== init database group/user =====
  const root = db?.list ? db.list() : {}
  root.group ||= {}
  root.user ||= {}

  // ===== init group default =====
  if (!root.group[m.chat]) {
    root.group[m.chat] = {
      welcome: false,
      textWelcome: 'Halo @user, selamat datang di grup @subject',
      textLeave: 'Selamat tinggal @user',

      antiLink: false,
      antiLinkAll: false,
      antiLinkOption: '',

      antiupsw: false,
      antiFoto: false,
      antiSticker: false,
      notifgempa: false,
      antisaluran: false,
      antiDelete: false,
      antiToxic: false,
      antiBot: false,
      antiEditChat: false,
      antiPromo: false,
      antispamchat: false
    }
  }

  if (!root.user[m.sender]) {
    root.user[m.sender] = { autolevelup: true }
  }

  const chat = root.group[m.chat]

  // =========================
  // .oncek
  // =========================
  if (/^oncek$/i.test(command)) {
    if (!m.isGroup) return send('⚠️ Perintah ini hanya bisa dipakai di *grup*.')

    const fiturGrup = {
      welcome: !!chat.welcome,
      antilink: !!chat.antiLink,
      antilinkall: !!chat.antiLinkAll,
      antiupsw: !!chat.antiupsw,
      antipoto: !!chat.antiFoto,
      antisticker: !!chat.antiSticker,
      notifgempa: !!chat.notifgempa,
      antisaluran: !!chat.antisaluran,
      antidelete: !!chat.antiDelete,
      antitoxic: !!chat.antiToxic,
      antibot: !!chat.antiBot,
      antieditchat: !!chat.antiEditChat,
      antipromo: !!chat.antiPromo,
      antispamchat: !!chat.antispamchat
    }

    const fiturBot = {
      autoreadgc: !!global.opts.autoreadgc,
      autoreadpc: !!global.opts.autoreadpc
    }

    const aktifGrup =
      Object.entries(fiturGrup).filter(([, v]) => v).map(([n]) => `✅ ${n}`).join('\n')
      || 'Tidak ada fitur grup yang aktif.'

    const nonaktifGrup =
      Object.entries(fiturGrup).filter(([, v]) => !v).map(([n]) => `❌ ${n}`).join('\n')
      || 'Semua fitur grup aktif.'

    const aktifBot =
      Object.entries(fiturBot).filter(([, v]) => v).map(([n]) => `✅ ${n}`).join('\n')
      || 'Tidak ada fitur bot yang aktif.'

    const nonaktifBot =
      Object.entries(fiturBot).filter(([, v]) => !v).map(([n]) => `❌ ${n}`).join('\n')
      || 'Semua fitur bot aktif.'

    let msg =
`⚙️ *STATUS PENGATURAN GRUP*

*🧩 Fitur grup aktif:*
${aktifGrup}

*🧩 Fitur grup nonaktif:*
${nonaktifGrup}

🤖 *STATUS PENGATURAN BOT*

*🧩 Fitur bot aktif:*
${aktifBot}

*🧩 Fitur bot nonaktif:*
${nonaktifBot}

📍*CONTOH PENGGUNAAN :*
• ${usedPrefix}on welcome
• ${usedPrefix}off welcome
• ${usedPrefix}on antilink
• ${usedPrefix}on antilink-hapus
• ${usedPrefix}on antilink-kick
• ${usedPrefix}on antilink-combo
• ${usedPrefix}off antilink
• ${usedPrefix}on all
• ${usedPrefix}off all
• ${usedPrefix}oncek`

    if (chat.antiLink) {
      msg += `\n\n🔗 *Antilink mode:* ${chat.antiLinkOption || '*belum dipilih*'}`
    }

    return send(msg)
  }

  // =========================
  // on/off TANPA ARGUMEN → DIAM
  // =========================
  if (!args || !args[0]) return

  const isEnable = /true|enable|(turn)?on|1/i.test(command)
  const type = (args[0] || '').toLowerCase()

  // =========================
  // Permission helpers
  // =========================
  const needGroupAdmin = () => {
    if (!m.isGroup) return send('⚠️ Perintah ini hanya bisa dipakai di *grup*.')
    if (!(isAdmin || isOwner)) return send('❌ Fitur ini khusus *Admin* (atau Owner).')
    return null
  }

  const needROwner = () => {
    if (!isROwner) return send('❌ Fitur ini khusus *Real Owner*.')
    return null
  }

  // =========================
  // on/off all
  // =========================
  if (type === 'all') {
    const perm = needGroupAdmin()
    if (perm) return

    const val = isEnable

    chat.welcome = val
    chat.antiLink = val
    chat.antiLinkAll = val
    chat.antiupsw = val
    chat.antiFoto = val
    chat.antiSticker = val
    chat.notifgempa = val
    chat.antisaluran = val
    chat.antiDelete = val
    chat.antiToxic = val
    chat.antiBot = val
    chat.antiEditChat = val
    chat.antiPromo = val
    chat.antispamchat = val

    if (!val) chat.antiLinkOption = ''

    await db.save?.()

    return send(
      val
        ? `✅ Semua fitur *grup* sudah diaktifkan.\nKetik *${usedPrefix}oncek* untuk melihat status.`
        : `⛔ Semua fitur *grup* dimatikan.\nKetik *${usedPrefix}oncek* untuk melihat status.`
    )
  }

  // =========================
  // SWITCH FITUR (ASLI, + FIX NOTIF)
  // =========================
  let changed = true // penanda: fitur valid & berubah

  switch (type) {
    case 'antispamchat': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antispamchat = isEnable
      break
    }

    case 'antipromo': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiPromo = isEnable
      break
    }

    case 'antilinkall': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiLinkAll = isEnable
      break
    }

    case 'antitoxic': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiToxic = isEnable
      break
    }

    case 'antidelete': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiDelete = isEnable
      break
    }

    case 'antiupsw': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiupsw = isEnable
      break
    }

    case 'antisaluran': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antisaluran = isEnable
      break
    }

    case 'welcome': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.welcome = isEnable
      break
    }

    case 'antilink': {
      const perm = needGroupAdmin()
      if (perm) return

      if (isEnable) {
        return send(
`🛡️ *SETTING ANTILINK*
• ${usedPrefix}on antilink-hapus
• ${usedPrefix}on antilink-kick
• ${usedPrefix}on antilink-combo`
        )
      } else {
        chat.antiLink = false
        chat.antiLinkOption = ''
        await db.save?.()
        return send('✅ Antilink dimatikan di grup ini.')
      }
    }

    case 'antilink-hapus': {
      const perm = needGroupAdmin()
      if (perm) return
      if (isEnable) {
        chat.antiLink = true
        chat.antiLinkOption = 'hapus'
      } else {
        chat.antiLink = false
        chat.antiLinkOption = ''
      }
      await db.save?.()
      return send(`✅ Mode antilink: *hapus* (${chat.antiLink ? 'aktif' : 'nonaktif'})`)
    }

    case 'antilink-kick': {
      const perm = needGroupAdmin()
      if (perm) return
      if (isEnable) {
        chat.antiLink = true
        chat.antiLinkOption = 'kick'
      } else {
        chat.antiLink = false
        chat.antiLinkOption = ''
      }
      await db.save?.()
      return send(`✅ Mode antilink: *kick* (${chat.antiLink ? 'aktif' : 'nonaktif'})`)
    }

    case 'antilink-combo': {
      const perm = needGroupAdmin()
      if (perm) return
      if (isEnable) {
        chat.antiLink = true
        chat.antiLinkOption = 'combo'
      } else {
        chat.antiLink = false
        chat.antiLinkOption = ''
      }
      await db.save?.()
      return send(`✅ Mode antilink: *combo* (${chat.antiLink ? 'aktif' : 'nonaktif'})`)
    }

    case 'antisticker': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiSticker = isEnable
      break
    }

    case 'antipoto': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiFoto = isEnable
      break
    }

    case 'antibot': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiBot = isEnable
      break
    }

    case 'antieditchat': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.antiEditChat = isEnable
      break
    }

    case 'notifgempa': {
      const perm = needGroupAdmin()
      if (perm) return
      chat.notifgempa = isEnable
      break
    }

    case 'autoreadgc': {
      const perm = needROwner()
      if (perm) return
      global.opts.autoreadgc = isEnable
      break
    }

    case 'autoreadpc': {
      const perm = needROwner()
      if (perm) return
      global.opts.autoreadpc = isEnable
      break
    }

    default:
      changed = false
      return
  }

  await db.save?.()

  // ===== FIX UTAMA: notif default untuk semua case yang cuma break =====
  if (changed) {
    return send(`✅ *${type}* ${isEnable ? 'diaktifkan' : 'dimatikan'} di grup ini.\nKetik *${usedPrefix}oncek* untuk cek status.`)
  }
}

handler.help = ['on <fitur>', 'off <fitur>', 'oncek']
handler.category = ['admin']
handler.command = ['enable', 'disable', 'on', 'off', 'oncek']
handler.register = false

module.exports = handler
