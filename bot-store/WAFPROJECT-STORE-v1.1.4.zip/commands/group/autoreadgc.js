/**
 * Fake Read GC/PC (HOOK)
 * - Kirim receipt "read" pakai sendReceipt (lebih keras)
 * - Fallback ke chatRead & readMessages
 */

let handler = (m) => m

handler.all = async function (m, { wafproject }) {
  try {
    if (!m || !wafproject) return
    global.opts = global.opts || {}

    // jangan read pesan bot sendiri
    if (m.key?.fromMe) return

    const id = m.key?.id || m.id
    const remoteJid = m.chat || m.key?.remoteJid
    if (!id || !remoteJid) return

    const isGroup = remoteJid.endsWith('@g.us')
    const isPc = remoteJid.endsWith('@s.whatsapp.net')

    // cek toggle
    if (isGroup && !global.opts.autoreadgc) return
    if (isPc && !global.opts.autoreadpc) return
    if (!isGroup && !isPc) return

    // participant WAJIB untuk group receipt
    const participant =
      isGroup
        ? (m.key?.participant || m.sender || m.participant)
        : undefined

    // 1) FAKE READ (receipt) - paling mirip "dibaca oleh"
    if (typeof wafproject.sendReceipt === 'function') {
      await wafproject.sendReceipt(remoteJid, participant, [id], 'read').catch(() => {})
    }

    // 2) fallback (kadang dibutuhkan di device tertentu)
    if (typeof wafproject.chatRead === 'function') {
      await wafproject.chatRead(remoteJid, participant, id).catch(() => {})
    }

    // 3) fallback terakhir
    if (typeof wafproject.readMessages === 'function' && m.key) {
      await wafproject.readMessages([m.key]).catch(() => {})
    }
  } catch (e) {
    console.error('fakeread error:', e)
  }
}

handler.command = [] // hook only
module.exports = handler