// commands/group/set-open-close.js
// 📝 Set & Reset pesan Open/Close (CJS)
// - .setopen   <teks>
// - .setclose  <teks>
// - .resetopen
// - .resetclose
// Data: database/databaseStore.json

const fs = require('fs')
const path = require('path')

const { databaseFile } = require('../../lib/project-paths')
const STORE_PATH = databaseFile('databaseStore.json')
const STORE_DIR = path.dirname(STORE_PATH)
if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true })

function readJsonSafe() {
  try {
    if (!fs.existsSync(STORE_PATH)) return {}
    return JSON.parse(fs.readFileSync(STORE_PATH, 'utf-8'))
  } catch {
    return {}
  }
}
function writeJsonSafe(data) {
  try {
    fs.writeFileSync(STORE_PATH, JSON.stringify(data, null, 2))
  } catch (_error) { console.error("[ERROR][commands/group/setopen-setclose.js]", _error?.message || _error) }
}

function ensureGroupNode(db, gid) {
  if (!db[gid]) db[gid] = {}
  db[gid].groupSettings ||= {}
  if (typeof db[gid].groupSettings.openText !== 'string') db[gid].groupSettings.openText = ''
  if (typeof db[gid].groupSettings.closeText !== 'string') db[gid].groupSettings.closeText = ''
  return db[gid]
}

const plugin = async (m, { wafproject, command, text = '', usedPrefix = '.', isAdmin, isOwner }) => {
  try {
    if (!m.isGroup) return

    const cmd = String(command || '').toLowerCase()
    if (!['setopen', 'setclose', 'resetopen', 'resetclose'].includes(cmd)) return

    // khusus admin / owner
    if (!(isAdmin || isOwner)) return m.reply('🚫 Khusus admin/owner grup.')

    const dbJson = readJsonSafe()
    const node = ensureGroupNode(dbJson, m.chat)

    // ================= RESET =================
    if (cmd === 'resetopen') {
      node.groupSettings.openText = ''
      writeJsonSafe(dbJson)
      return m.reply('♻️ Pesan *open* berhasil di-reset ke default.')
    }

    if (cmd === 'resetclose') {
      node.groupSettings.closeText = ''
      writeJsonSafe(dbJson)
      return m.reply('♻️ Pesan *close* berhasil di-reset ke default.')
    }

    // ================= SET =================
    const input = String(text || '').trim()
    if (!input) {
      return m.reply(
        `Format:\n` +
        `• ${usedPrefix}setopen <pesan>\n` +
        `• ${usedPrefix}setclose <pesan>\n\n` +
        `Reset:\n` +
        `• ${usedPrefix}resetopen\n` +
        `• ${usedPrefix}resetclose\n\n` +
        `Placeholder:\n` +
        `@name @user @group`
      )
    }

    if (input.length > 4000) {
      return m.reply('❌ Pesan terlalu panjang (maks 4000 karakter).')
    }

    if (cmd === 'setopen') {
      node.groupSettings.openText = input
      writeJsonSafe(dbJson)
      return m.reply('✅ Pesan *open* berhasil disimpan.')
    }

    if (cmd === 'setclose') {
      node.groupSettings.closeText = input
      writeJsonSafe(dbJson)
      return m.reply('✅ Pesan *close* berhasil disimpan.')
    }
  } catch (e) {
    console.error('set-open-close error:', e)
    return m.reply('❌ Gagal menyimpan pengaturan open/close.')
  }
}

plugin.help = [
  'setopen',
  'setclose',
  'resetopen',
  'resetclose'
]
plugin.category = ['admin']
plugin.command = ['setopen', 'setclose', 'resetopen', 'resetclose']
plugin.group = true
plugin.admin = true
plugin.limit = false

module.exports = plugin