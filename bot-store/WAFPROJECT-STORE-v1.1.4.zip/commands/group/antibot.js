/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur: Anti Bot (deteksi pola ID bot/selfbot) — FIX STYLE ANTITOXIC (CJS)
✅ Toggle: chat.antiBot (sesuai menu on/off kamu)
✅ Skip owner & admin
✅ Delete + warn + kick (butuh bot admin)
========================
*/

const delay = (ms) => new Promise((r) => setTimeout(r, ms))

// prefix yang sering muncul di selfbot / mod / library tidak resmi tertentu
const botIDs = ['B1EY', 'BAE5', 'BAE0', 'BAE', 'B1E', '3EB0', 'FTG']

// hex set
const validHex = '0123456789ABCDEF'

// panjang ID pesan normal (ini heuristik, bukan aturan mutlak)
const okLens = {
  ios: 18,
  desktop: 18,
  web: 20,
  androidMin: 21,
  androidMax: 32
}

function getMsgId(m) {
  return (
    m?.key?.id ||
    m?.id ||
    m?.msg?.key?.id ||
    m?.message?.key?.id ||
    ''
  )
}

// filter tipe pesan (biar gak ganggu event aneh)
function isAllowedType(m) {
  // kalau m.type gak ada, biarkan lewat
  if (!m) return false
  if (!m.type) return true
  return ['chat', 'image', 'video', 'sticker', 'audio', 'document', 'location'].includes(m.type)
}

function checkBotID(id) {
  id = String(id || '').toUpperCase()
  const reasons = []

  if (!id) return { isBot: false, reasons: [] }

  // prefix mencurigakan
  if (botIDs.some((p) => id.startsWith(p))) {
    reasons.push('- Prefix ID mencurigakan (indikasi bot/selfbot)')
  }

  // karakter non-HEX
  if ([...id].some((ch) => !validHex.includes(ch))) {
    reasons.push('- Mengandung karakter non-HEX (indikasi bot)')
  }

  // panjang tidak wajar
  const len = id.length
  const okLen =
    len === okLens.ios ||
    len === okLens.desktop ||
    len === okLens.web ||
    (len >= okLens.androidMin && len <= okLens.androidMax)

  if (!okLen) reasons.push('- Panjang ID tidak sesuai pola umum')

  return { isBot: reasons.length > 0, reasons }
}

const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner, isAdmin, isBotAdmin }) {
  try {
    if (!m || !wafproject || !db) return
    if (!m.isGroup) return
    if (m.fromMe) return
    if (m.messageStubType) return
    if (!m.message) return
    if (!isAllowedType(m)) return

    // ===== schema db bot kamu =====
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    root.user ||= {}

    const chat = root.group[m.chat] || (root.group[m.chat] = {})
    if (!chat.antiBot) return // ✅ toggle sesuai menu kamu: chat.antiBot

    // skip owner/admin
    if (isOwner) return
    if (isAdmin) return

    // butuh bot admin
    if (!isBotAdmin) return

    const who = m.sender
    if (!who) return

    // ✅ ambil ID pesan yang benar
    const msgId = getMsgId(m)

    // deteksi
    const { isBot, reasons } = checkBotID(msgId)
    if (!isBot) return

    // init warn user khusus antibot
    root.user[who] ||= {}
    const user = root.user[who]
    if (typeof user.warnAntiBot !== 'number') user.warnAntiBot = 0

    const maxWarnings = 3
    user.warnAntiBot += 1

    const reasonText = reasons.join('\n')
    const remain = Math.max(0, maxWarnings - user.warnAntiBot)

    // delete pesan
    try {
      await wafproject.sendMessage(m.chat, { delete: m.key })
    } catch (_error) { console.error("[ERROR][commands/group/antibot.js]", _error?.message || _error) }

    // warning
    if (user.warnAntiBot < maxWarnings) {
      await db.save?.()
      return await wafproject.sendMessage(
        m.chat,
        {
          text:
            `⚠️ *「 ANTI BOT 」* ⚠️\n\n` +
            `*Pengirim:* @${who.split('@')[0]}\n` +
            `_Terdeteksi sebagai bot/selfbot_ 😤\n\n` +
            `💳 *MsgID:* ${msgId}\n` +
            `📌 *Peringatan:* ${user.warnAntiBot}/${maxWarnings}\n` +
            `📥 *Sisa:* ${remain}\n\n` +
            `*Alasan Deteksi:*\n${reasonText}\n\n` +
            `> Jika peringatan habis, kamu akan di-kick dari grup ini`,
          mentions: [who]
        },
        { quote: m }
      )
    }

    // kick
    user.warnAntiBot = 0
    await db.save?.()

    await wafproject.sendMessage(m.chat, {
      text:
        `⛔ @${who.split('@')[0]} telah melampaui batas *${maxWarnings}* peringatan!\n\n` +
        `*Alasan Deteksi:*\n${reasonText}\n\n` +
        `User akan dikeluarkan dari grup.`,
      mentions: [who]
    })

    await delay(1500)
    await wafproject.groupParticipantsUpdate(m.chat, [who], 'remove').catch(() => {})

    // opsional DM
    await wafproject.sendMessage(who, {
      text: `♻️ Kamu dikeluarkan dari grup karena terdeteksi bot/selfbot dan melampaui ${maxWarnings} peringatan.`
    }).catch(() => {})

  } catch (e) {
    console.error('antiBot.before error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // ✅ hook only
module.exports = handler