// commands/group/setbye.js

const handler = async (m, { text, db }) => {
  if (!m.isGroup) return m.reply("Fitur ini hanya untuk grup!")

  if (!text) {
    return m.reply(
      "Contoh:\n" +
        ".setbye Selamat tinggal @user 👋\n\n" +
        "Placeholder yang bisa dipakai:\n" +
        "@user = mention user\n" +
        "@group / @subject = nama grup\n" +
        "@desc / @desk = deskripsi grup\n" +
        "@admin = list admin\n" +
        "@membercount = jumlah member\n" +
        "@date = tanggal\n" +
        "@time = jam\n" +
        "@link = link invite grup"
    )
  }

  let group = db.list().group[m.chat] ||= {}

  // Simpan ke dua field agar kompatibel dengan sistem lama
  group.textBye = text
  group.textLeave = text

  if (typeof group.welcome !== "boolean") group.welcome = true
  if (typeof group.textWelcome !== "string")
    group.textWelcome = "Halo @user, selamat datang di @subject"

  await db.save()

  m.reply("✅ Pesan bye (leave) berhasil diubah!")
}

handler.command = ["setbye"]
handler.category = "admin"
handler.description =
  "Atur pesan bye/leave grup (placeholder lengkap: @user @group/@subject @desc/@desk @admin @membercount @date @time @link)"
handler.group = true
handler.admin = true
handler.limit = false

module.exports = handler
