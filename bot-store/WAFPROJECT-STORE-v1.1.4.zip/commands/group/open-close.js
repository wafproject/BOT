// commands/group/open-close.js
// 🔐 Group Open/Close (CJS)

const fs = require('fs')
const path = require('path')

const { databaseFile } = require('../../lib/project-paths')
const STORE_PATH = databaseFile('databaseStore.json')
const STORE_DIR = path.dirname(STORE_PATH)
if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true })

function readJsonSafe() {
  try {
    if (!fs.existsSync(STORE_PATH)) return {}
    return JSON.parse(fs.readFileSync(STORE_PATH, 'utf-8'))
  } catch {
    return {}
  }
}

function ensureGroupNode(db, gid) {
  if (!db[gid]) db[gid] = {}
  db[gid].groupSettings ||= {}
  if (typeof db[gid].groupSettings.openText !== 'string') db[gid].groupSettings.openText = ''
  if (typeof db[gid].groupSettings.closeText !== 'string') db[gid].groupSettings.closeText = ''
  return db[gid]
}

// ================= FORMAT WIB =================
function formatNowWIB() {
  const now = new Date()

  const date = new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    weekday: 'long',
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(now)

  const time = new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit'
  }).format(now)

  return { date, time }
}

function renderText(tpl, m, wafproject) {
  const { date, time } = formatNowWIB()

  // 🔥 Samakan dengan cara .p resolve JID
  const jid = wafproject?.decodeJid ? wafproject.decodeJid(m.sender) : m.sender
  const number = String(jid || '').split('@')[0] || 'admin'

  return String(tpl || '')
    .replace(/@name/g, number)
    .replace(/@date/g, date)
    .replace(/@time/g, time)
}

const plugin = async (m, { wafproject, command, isAdmin, isOwner, text, args }) => {
  try {
    if (!m.isGroup) return
    const cmd = String(command || '').toLowerCase()
    if (cmd !== 'open' && cmd !== 'close') return

    const hasText =
      (typeof text === 'string' && text.trim().length > 0) ||
      (Array.isArray(args) && args.length > 0)

    const isPrivileged = !!(isAdmin || isOwner)
    if (!isPrivileged) {
      if (hasText) return
      return m.reply('⛔ Fitur ini khusus *Admin* grup.')
    }

    const dbJson = readJsonSafe()
    const node = ensureGroupNode(dbJson, m.chat)

    const defaultClose =
`───〔 🔒 *GROUP CLOSE* 〕───

*Group Ditutup Oleh*
👤 @${'@name'}

📆 @date
⏰ @time WIB

اَلْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ

Terima kasih atas orderan dan kepercayaannya hari ini.
Mohon maaf apabila ada kekurangan dalam pelayanan.

Semoga besok lebih lancar dan berkah. Aamiin ✨`

    const defaultOpen =
`───〔 🔓 *GROUP OPEN* 〕───

*Group Dibuka Oleh*
👤 @${'@name'}

📆 @date
⏰ @time WIB

بِسْــــــــــــــــــمِ اللهِ الرَّحْمَنِ الرَّحِيْمِ

Selamat pagi, group resmi dibuka.
Silakan kirim orderan, admin siap melayani.

Semoga hari ini lancar, dan penuh berkah. Aamiin ✨`

    const openText = node.groupSettings.openText?.trim() || defaultOpen
    const closeText = node.groupSettings.closeText?.trim() || defaultClose

    // 🔥 decode JID biar sama seperti .p
    const jidTag = wafproject?.decodeJid ? wafproject.decodeJid(m.sender) : m.sender

    if (cmd === 'open') {
      await wafproject.groupSettingUpdate(m.chat, 'not_announcement')
      await wafproject.sendMessage(
        m.chat,
        {
          text: renderText(openText, m, wafproject),
          mentions: [jidTag]
        },
        { quote: m }
      )
      return
    }

    if (cmd === 'close') {
      await wafproject.groupSettingUpdate(m.chat, 'announcement')
      await wafproject.sendMessage(
        m.chat,
        {
          text: renderText(closeText, m, wafproject),
          mentions: [jidTag]
        },
        { quote: m }
      )
      return
    }

  } catch (e) {
    console.error('open-close error:', e)
    return m.reply('❌ Gagal ubah pengaturan grup. Pastikan bot jadi admin.')
  }
}

plugin.help = ['open', 'close']
plugin.category = ['admin']
plugin.command = ['open', 'close']
plugin.group = true
plugin.admin = false
plugin.limit = false

module.exports = plugin
