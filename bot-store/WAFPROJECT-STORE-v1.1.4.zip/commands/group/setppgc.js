const { downloadContentFromMessage } = require('../../lib/zapo-adapter.js')

// unwrap wrapper umum (ephemeral/view once)
function unwrapMessage(obj) {
  let msg =
    obj?.message ||
    obj?.msg?.message ||
    obj?.msg ||
    obj

  if (!msg) return { inner: null, type: null, node: null }
  if (msg?.message) msg = msg.message

  if (msg.ephemeralMessage?.message) msg = msg.ephemeralMessage.message
  if (msg.viewOnceMessageV2?.message) msg = msg.viewOnceMessageV2.message
  if (msg.viewOnceMessage?.message) msg = msg.viewOnceMessage.message

  const type = msg && Object.keys(msg)[0]
  const node = type ? msg[type] : null
  return { inner: msg, type, node }
}

function toDlType(type) {
  if (type === 'imageMessage') return 'image'
  if (type === 'videoMessage') return 'video'
  if (type === 'audioMessage') return 'audio'
  if (type === 'documentMessage') return 'document'
  if (type === 'stickerMessage') return 'sticker'
  return null
}

async function downloadMediaAny(obj) {
  // 1) kalau base punya .download()
  try {
    if (typeof obj?.download === 'function') {
      const b = await obj.download()
      if (b) return b
    }
  } catch (_error) { console.error("[ERROR][commands/group/setppgc.js]", _error?.message || _error) }

  // 2) stream media dari WhatsApp Proto
  const { type, node } = unwrapMessage(obj)
  const dlType = toDlType(type)
  if (!node || !dlType) return null

  const stream = await downloadContentFromMessage(node, dlType)
  let buf = Buffer.alloc(0)
  for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
  return buf.length ? buf : null
}

function getMimeAny(obj) {
  const { node } = unwrapMessage(obj)
  return node?.mimetype || ''
}

let handler = async (m, { wafproject, usedPrefix, command, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('❌ Command ini khusus grup.')
  if (!isAdmin && !isOwner) return m.reply('❌ Khusus admin grup.')

  const react = async (emoji) => {
    try { await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/setppgc.js]", _error?.message || _error) }
  }

  // sumber: reply dulu, kalau tidak ada reply pakai pesan sendiri (send+caption)
  const q = m.quoted ? m.quoted : m

  // deteksi mime kebal
  const mime = getMimeAny(q) || q.mimetype || q.msg?.mimetype || ''

  // WAJIB image
  if (!mime || !/^image\//i.test(mime)) {
    await react('❗')
    return wafproject.sendMessage(
      m.chat,
      { text: `Kirim atau *balas gambar* dengan perintah:\n*${usedPrefix + command}*` },
      { quote: m }
    )
  }

  try {
    await react('🕒')

    const img = await downloadMediaAny(q)
    if (!img) throw new Error('Gagal download gambar dari WhatsApp.')

    // set pp grup
    if (typeof wafproject.updateProfilePicture === 'function') {
      await wafproject.updateProfilePicture(m.chat, img)
    } else if (typeof wafproject.groupUpdateProfilePicture === 'function') {
      await wafproject.groupUpdateProfilePicture(m.chat, img)
    } else {
      throw new Error('Fungsi update foto grup tidak tersedia di base (updateProfilePicture/groupUpdateProfilePicture).')
    }

    await react('✅')
    return wafproject.sendMessage(m.chat, { text: '✅ Berhasil mengubah foto grup.' }, { quote: m })
  } catch (err) {
    console.error('SETPPGC ERROR:', err?.message || err)
    await react('❌')
    return wafproject.sendMessage(
      m.chat,
      { text: `❌ Gagal set foto grup:\n${err?.message || String(err)}` },
      { quote: m }
    )
  }
}

handler.help = ['setppgc (reply/kirim gambar)']
handler.category = ['admin']
handler.command = ['setppgc']
handler.group = true
handler.admin = true
handler.register = true

module.exports = handler
