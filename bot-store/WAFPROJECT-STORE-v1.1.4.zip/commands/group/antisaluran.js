/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur: Anti Saluran (blokir pesan dari channel/newsletter) — WAF CJS
========================
*/

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    const meta = await wafproject.groupMetadata(chatJid)
    const participants = meta?.participants || []

    const isAdmin = participants.some(
      (p) =>
        (p.id === senderJid || p.jid === senderJid) &&
        (p.admin === 'admin' || p.admin === 'superadmin')
    )

    const botId = wafproject.user?.id || wafproject.user?.jid
    const isBotAdmin = participants.some(
      (p) =>
        (p.id === botId || p.jid === botId) &&
        (p.admin === 'admin' || p.admin === 'superadmin')
    )

    return { isAdmin, isBotAdmin }
  } catch {
    return { isAdmin: false, isBotAdmin: false }
  }
}

function findNewsletterJid(m) {
  try {
    const msgObj = m?.message || {}
    for (const msg of Object.values(msgObj)) {
      const info = msg?.contextInfo?.forwardedNewsletterMessageInfo
      if (info?.newsletterJid) return info.newsletterJid
    }
  } catch (_error) { console.error("[ERROR][commands/group/antisaluran.js]", _error?.message || _error) }
  return null
}

const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner }) {
  try {
    if (!m?.isGroup) return
    if (m.fromMe) return
    if (!m.message) return

    // ambil setting grup dari db bot kamu
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    const chat = root.group[m.chat] || (root.group[m.chat] = {})

    if (!chat.antisaluran) return

    // deteksi pesan dari channel/newsletter
    const newsletterJid = findNewsletterJid(m)
    if (!newsletterJid) return

    const sender = m.sender
    const { isAdmin, isBotAdmin } = await getAdminStatus(wafproject, m.chat, sender)

    // admin/owner bebas
    if (isOwner || isAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '📣 *ANTI SALURAN (ADMIN/OWNER)*\n\n' +
            `Pesan dari saluran terdeteksi, dikirim oleh @${sender.split('@')[0]}.\n` +
            'Karena kamu admin/owner, tidak ada tindakan.',
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // bot bukan admin
    if (!isBotAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '⚠️ *ANTI SALURAN AKTIF*\n\n' +
            `Pesan dari saluran terdeteksi, dikirim oleh @${sender.split('@')[0]}.\n` +
            'Namun bot *bukan admin*, jadi tidak bisa menghapus.',
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // member biasa + bot admin → delete + warning
    try {
      await wafproject.sendMessage(m.chat, { delete: m.key })
    } catch (e) {
      console.error('Gagal delete pesan saluran:', e)
    }

    await wafproject.sendMessage(
      m.chat,
      {
        text:
          '🚫 *ANTI SALURAN*\n\n' +
          `Pesan dari saluran / channel tidak diperbolehkan di grup ini.\n` +
          `Pesan dari @${sender.split('@')[0]} sudah *dihapus*.`,
        mentions: [sender]
      },
      { quote: m }
    )
  } catch (e) {
    console.error('antisaluran.before error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // hook only
module.exports = handler