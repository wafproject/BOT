// ✨ LISTENER AFK (REPLY + MENTION) - TARGET FIX HARD ✨
// NOTE: Nama AFK diambil dari @jid (bukan getName) biar gak ketuker kontak random.

const COOLDOWN_MS = 2500

async function core(m, { wafproject }) {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (m.fromMe) return
    if (m.fromMe === true) return

    // DB
    global.db = global.db || {}
    global.db.data = global.db.data || {}
    global.db.data.chats = global.db.data.chats || {}
    const chat = global.db.data.chats[m.chat] || {}
    chat.afk = chat.afk || {}
    global.db.data.chats[m.chat] = chat

    // cooldown
    wafproject._afkCd = wafproject._afkCd || {}
    const last = wafproject._afkCd[m.chat] || 0
    if (Date.now() - last < COOLDOWN_MS) return

    const senderRaw = getSenderRaw(m)
    const senderReal = await resolveToRealJid(wafproject, m, senderRaw)
    if (!senderReal || !String(senderReal).endsWith("@s.whatsapp.net")) return
    const sender = normJid(senderReal)

    // ============ 1) REPLY ============
    const quotedOwnerRaw = getQuotedOwnerFromContext(m)
    if (quotedOwnerRaw) {
      const targetReal = await resolveToRealJid(wafproject, m, quotedOwnerRaw)
      const target = (targetReal && String(targetReal).endsWith("@s.whatsapp.net"))
        ? normJid(targetReal)
        : null

      if (target && target !== sender && chat.afk[target]) {
        await sendAfkReply(wafproject, m, chat, sender, target)
        wafproject._afkCd[m.chat] = Date.now()
        return
      }
    }

    // ============ 2) MENTION (POPUP ASLI) ============
    const mentionsRaw = getMentionedJidFromContext(m)
    if (mentionsRaw.length) {
      for (const raw of mentionsRaw) {
        const targetReal = await resolveToRealJid(wafproject, m, raw)
        const target = (targetReal && String(targetReal).endsWith("@s.whatsapp.net"))
          ? normJid(targetReal)
          : null

        if (!target) continue
        if (target === sender) continue

        if (chat.afk[target]) {
          await sendAfkMention(wafproject, m, chat, sender, target)
          wafproject._afkCd[m.chat] = Date.now()
          return
        }
      }
    }
  } catch (e) { console.error("[ERROR][commands/group/afk-listener.js]", e?.message || e) }
}

const handler = async (m, ctx) => core(m, ctx)
handler.before = async (m, ctx) => core(m, ctx)
handler.all = async (m, ctx) => core(m, ctx)
handler.command = new RegExp("^$", "i")
module.exports = handler

// =================== OUTPUT (HARD TARGET) ===================
async function sendAfkReply(wafproject, m, chat, sender, target) {
  const afk = chat.afk[target]
  const alasan = afk?.reason?.trim() ? afk.reason.trim() : "ngilang tanpa kabar 😭"
  const durText = formatDur(Date.now() - (Number(afk?.time) || Date.now()))

  const senderTag = `@${sender.split("@")[0]}`
  const targetTag = `@${target.split("@")[0]}`

  const out =
    `🧾 *REPLY KE ORANG AFK NIH?!*\n\n` +
    `${senderTag}, kamu nge-reply ${targetTag}...\n` +
    `Padahal dia AFK sejak *${durText}* 😴\n\n` +
    `📝 Alasan: ${alasan}\n` +
    `📌 Saran: tinggalin pesan baik-baik, jangan spam wkwk 😭`

  await wafproject.sendMessage(
    m.chat,
    { text: out, mentions: [sender, target] },
    { quote: m }
  )
}

async function sendAfkMention(wafproject, m, chat, sender, target) {
  const afk = chat.afk[target]
  const alasan = afk?.reason?.trim() ? afk.reason.trim() : "ngilang tanpa kabar 😭"
  const durText = formatDur(Date.now() - (Number(afk?.time) || Date.now()))

  const senderTag = `@${sender.split("@")[0]}`
  const targetTag = `@${target.split("@")[0]}`

  const out =
    `📣 *MENTION ORANG AFK?!* 🤨\n\n` +
    `${senderTag}, jangan panggil ${targetTag} dulu 😤\n` +
    `Dia lagi AFK sejak *${durText}*.\n\n` +
    `📝 Alasan: ${alasan}\n` +
    `✨ Sabar… nanti juga balik (kalau inget) 😭`

  await wafproject.sendMessage(
    m.chat,
    { text: out, mentions: [sender, target] },
    { quote: m }
  )
}

// =================== HELPERS ===================
function normJid(id) {
  return String(id || "").replace(/:.*@/, "@").trim()
}

function getSenderRaw(m) {
  return m?.key?.participant || m?.participant || m?.sender || ""
}

function unwrapMessage(msg) {
  let x = msg
  for (let i = 0; i < 6; i++) {
    if (!x) break
    if (x.ephemeralMessage?.message) x = x.ephemeralMessage.message
    else if (x.viewOnceMessage?.message) x = x.viewOnceMessage.message
    else if (x.viewOnceMessageV2?.message) x = x.viewOnceMessageV2.message
    else if (x.editedMessage?.message) x = x.editedMessage.message
    else if (x.protocolMessage?.editedMessage) x = x.protocolMessage.editedMessage
    else break
  }
  return x
}

function getQuotedOwnerFromContext(m) {
  try {
    const mm = unwrapMessage(m?.message || m?.msg || m)
    const ctx =
      mm?.extendedTextMessage?.contextInfo ||
      mm?.imageMessage?.contextInfo ||
      mm?.videoMessage?.contextInfo ||
      mm?.documentMessage?.contextInfo ||
      mm?.buttonsResponseMessage?.contextInfo ||
      mm?.templateButtonReplyMessage?.contextInfo ||
      mm?.listResponseMessage?.contextInfo ||
      mm?.interactiveResponseMessage?.contextInfo ||
      mm?.messageContextInfo ||
      mm?.contextInfo

    if (!ctx?.quotedMessage) return null
    return ctx?.participant ? String(ctx.participant) : null
  } catch {
    return null
  }
}

function getMentionedJidFromContext(m) {
  const out = []
  try {
    const mm = unwrapMessage(m?.message || m?.msg || m)
    const ctxs = [
      mm?.extendedTextMessage?.contextInfo,
      mm?.imageMessage?.contextInfo,
      mm?.videoMessage?.contextInfo,
      mm?.documentMessage?.contextInfo,
      mm?.buttonsResponseMessage?.contextInfo,
      mm?.templateButtonReplyMessage?.contextInfo,
      mm?.listResponseMessage?.contextInfo,
      mm?.interactiveResponseMessage?.contextInfo,
      mm?.interactiveResponseMessage?.body?.contextInfo,
      mm?.interactiveResponseMessage?.nativeFlowResponseMessage?.contextInfo,
      mm?.messageContextInfo,
      mm?.contextInfo,
    ].filter(Boolean)

    for (const c of ctxs) {
      if (Array.isArray(c?.mentionedJid)) {
        for (const j of c.mentionedJid) out.push(String(j || ""))
      }
    }
  } catch (_error) { console.error("[ERROR][commands/group/afk-listener.js]", _error?.message || _error) }
  return [...new Set(out.filter(Boolean))]
}

async function resolveToRealJid(wafproject, m, rawJid) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith("@s.whatsapp.net")) return s
  if (!m.isGroup) return s

  let meta
  try {
    meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const participants = meta?.participants || []
  const found = participants.find(p =>
    p?.lid === s ||
    p?.id === s ||
    p?.jid === s ||
    p?.participant === s
  )

  return found?.jid || found?.id || found?.participant || s
}

function formatDur(ms) {
  const sec = Math.max(0, Math.floor(ms / 1000))
  const min = Math.floor(sec / 60)
  if (min > 0) return `${min} menit`
  return `${sec} detik`
}