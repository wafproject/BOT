// plugins/setwelcome.js
// Set template welcome grup (dipakai oleh /lib/group-participants.js)
//
// Placeholder tersedia:
// @user = mention user baru
// @group / @subject = nama grup
// @desc / @desk = deskripsi grup
// @admin = list admin
// @membercount = jumlah member
// @date = tanggal (Asia/Jakarta)
// @time = jam (Asia/Jakarta)
// @link = link invite grup (jika bisa)

const handler = async (m, { text, db }) => {
  if (!m.isGroup) return m.reply("Fitur ini hanya untuk grup!")

  if (!text) {
    return m.reply(
      "Contoh:\n" +
        "!setwelcome Halo @user, selamat datang di @group\n\n" +
        "Placeholder:\n" +
        "@user = mention user baru\n" +
        "@group / @subject = nama grup\n" +
        "@desc / @desk = deskripsi grup\n" +
        "@admin = list admin\n" +
        "@membercount = jumlah member\n" +
        "@date = tanggal\n" +
        "@time = jam\n" +
        "@link = link invite grup"
    )
  }

  let group = db.list().group[m.chat] ||= {}

  // simpan template
  group.textWelcome = text

  // kalau struktur lamanya belum ada, tetap aman
  if (typeof group.welcome !== "boolean") group.welcome = true
  if (typeof group.textBye !== "string") group.textBye = "Selamat tinggal @user"
  if (typeof group.textLeave !== "string") group.textLeave = "Selamat tinggal @user"

  await db.save()

  m.reply("✅ Pesan welcome berhasil diubah!")
}

handler.command = ["setwelcome"]
handler.category = "admin"
handler.description =
  "Atur pesan welcome grup (placeholder: @user @group/@subject @desc/@desk @admin @membercount @date @time @link)"
handler.group = true
handler.admin = true

module.exports = handler
