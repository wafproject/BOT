/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒

Fitur: Anti Link (khusus link WhatsApp Group)
Mode diatur dari:
- .on antilink-hapus
- .on antilink-kick
- .on antilink-combo
========================
*/

// hanya link grup WhatsApp
const LINK_REGEX = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i

const getMaxWarning = () => {
  const n = parseInt(global.maxwarn)
  return Number.isFinite(n) && n > 0 ? n : 5
}

// ===== ADMIN READER (SAMAKAN PERSIS SEPERTI ANTI FOTO) =====
const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try { meta = await wafproject.groupMetadata(chatJid) } catch { meta = null }
    if (!meta) return { isAdmin: false, isBotAdmin: false, meta: null }

    const participants = meta.participants || []

    const botJid = getBotJid(wafproject)
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderFixed = resolveLidToJid(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, isBotAdmin, meta }
  } catch {
    return { isAdmin: false, isBotAdmin: false, meta: null }
  }
}

const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner }) {
  try {
    if (!m?.isGroup) return
    if (m.fromMe) return
    if (!m.message) return

    const root = db?.list ? db.list() : {}
    root.group ||= {}
    root.user ||= {}

    const chat = root.group[m.chat] || (root.group[m.chat] = {})
    const users = root.user

    // antilink OFF
    if (!chat.antiLink) return

    // ambil teks aman
    const text =
      m.text ||
      m.message?.conversation ||
      m.message?.extendedTextMessage?.text ||
      m.message?.imageMessage?.caption ||
      m.message?.videoMessage?.caption ||
      (m.quoted && (m.quoted.text || m.quoted.caption)) ||
      ''

    if (!text) return

    // cek link grup
    if (!LINK_REGEX.test(text)) return

    const sender = m.sender
    const { isAdmin, isBotAdmin } = await getAdminStatus(wafproject, m.chat, sender)

    // OWNER / ADMIN → hanya notif
    if (isOwner || isAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '🛡️ *ANTILINK (ADMIN / OWNER)*\n\n' +
            `@${sender.split('@')[0]} terdeteksi mengirim link grup.\n` +
            'Karena kamu *admin/owner*, tidak ada tindakan.',
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // bot bukan admin
    if (!isBotAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '⚠️ *ANTILINK AKTIF*\n\n' +
            `@${sender.split('@')[0]} mengirim link grup.\n` +
            'Namun bot *bukan admin*, jadi tidak bisa hapus/kick.',
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // cek link grup sendiri (kalau link grup ini, skip)
    try {
      const invite = 'https://chat.whatsapp.com/' + (await wafproject.groupInviteCode(m.chat))
      const selfRegex = new RegExp(invite.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i')
      if (selfRegex.test(text)) return
    } catch {
      // lanjut saja
    }

    // hapus pesan
    try {
      await wafproject.sendMessage(m.chat, { delete: m.key })
    } catch (_error) { console.error("[ERROR][commands/group/antilink.js]", _error?.message || _error) }

    const mode = chat.antiLinkOption || 'hapus'

    users[sender] ||= {}
    users[sender].linkWarn ||= 0

    // ================= MODE HAPUS =================
    if (mode === 'hapus') {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '🚫 *ANTILINK (HAPUS)*\n\n' +
            `Link grup WhatsApp dari @${sender.split('@')[0]} telah dihapus.`,
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // ================= MODE KICK =================
    if (mode === 'kick') {
      try {
        await wafproject.groupParticipantsUpdate(m.chat, [sender], 'remove')
      } catch (_error) { console.error("[ERROR][commands/group/antilink.js]", _error?.message || _error) }

      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '🚫 *ANTILINK (KICK)*\n\n' +
            `@${sender.split('@')[0]} mengirim link grup dan telah dikeluarkan.`,
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // ================= MODE COMBO =================
    if (mode === 'combo') {
      const maxwarning = getMaxWarning()
      users[sender].linkWarn += 1

      if (users[sender].linkWarn < maxwarning) {
        await wafproject.sendMessage(
          m.chat,
          {
            text:
              '⚠️ *PERINGATAN ANTILINK*\n\n' +
              `@${sender.split('@')[0]} terdeteksi mengirim link grup.\n\n` +
              `• Peringatan: ${users[sender].linkWarn}/${maxwarning}\n` +
              `• Jika mencapai ${maxwarning}, kamu akan di-kick.`,
            mentions: [sender]
          },
          { quote: m }
        )
      } else {
        users[sender].linkWarn = 0

        await wafproject.sendMessage(
          m.chat,
          {
            text:
              '⛔ *BANNED ANTILINK*\n\n' +
              `@${sender.split('@')[0]} telah melampaui batas peringatan.\n` +
              'Pengguna akan dikeluarkan dari grup.',
            mentions: [sender]
          },
          { quote: m }
        )

        try {
          await wafproject.groupParticipantsUpdate(m.chat, [sender], 'remove')
        } catch (_error) { console.error("[ERROR][commands/group/antilink.js]", _error?.message || _error) }
      }
    }
  } catch (e) {
    console.error('antilink.before error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // hook only
module.exports = handler