let handler = async (m, { wafproject, text, usedPrefix, command, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('❌ Command ini khusus grup.')
  if (!isAdmin && !isOwner) return m.reply('❌ Khusus admin grup.')

  const desk = (text || '').trim()
  if (!desk) {
    return m.reply(
      `Masukkan deskripsi grup!\n\n` +
      `Contoh:\n${usedPrefix + command} Selamat datang di grup ini ✨`
    )
  }

  const react = async (emoji) => {
    try { await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/setdeskripsi.js]", _error?.message || _error) }
  }

  try {
    await react('🕒')

    // update deskripsi grup
    await wafproject.groupUpdateDescription(m.chat, desk)

    await react('✅')
    return m.reply('✅ Berhasil mengubah deskripsi grup.')
  } catch (e) {
    console.error('SETDESK ERROR:', e?.message || e)
    await react('❌')
    return m.reply(`❌ Error: ${e?.message || e}`)
  }
}

handler.help = ['setdesk <teks>']
handler.category = ['admin']
handler.command = ['setdesk']
handler.group = true
handler.admin = true
handler.register = true

module.exports = handler