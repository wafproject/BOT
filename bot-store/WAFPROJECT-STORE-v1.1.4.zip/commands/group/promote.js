// ✨ Plugin Promote (FINAL - Instant, Mention/Reply, Global AntiLID Safe) ✨
// Cmd: .promote @mention  / (reply) .promote
// ✅ Support reply target (m.quoted.sender / m.quoted.key.participant)
// ✅ Instant: force refresh metadata + retry 1x kalau WA belum sinkron
// ✅ Cache RAM + invalidate cache setelah update
// ✅ Tidak mapping/replace @lid di plugin
// ✅ Compare pakai normJid() global
// ✅ Update pakai raw participant id dari metadata (p.id/p.lid/participant/jid)

const META_CACHE_TTL_MS = 60 * 1000 // 60 detik
const RETRY_DELAY_MS = 1500

const handler = async (m, { wafproject, groupMetadata }) => {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return m.reply?.("Khusus grup ya.")
    if (m.fromMe === true) return

    // force refresh metadata biar status terbaru
    const meta = await getGroupMetaFast(wafproject, m, groupMetadata, true)
    if (!meta) return m.reply?.("Gagal ambil data grup.")

    const sender = normJid(m?.sender || m?.participant || m?.key?.participant || "")
    const adminsNorm = new Set(getAdminsNorm(meta))
    if (!adminsNorm.has(sender)) return m.reply?.("Fitur ini khusus Admin grup.")

    // ✅ target: reply > mention
    const targetsRaw = getTargetsRaw(m)
    if (!targetsRaw.length) {
      return m.reply?.("Tag atau reply targetnya.\nContoh: .promote @user atau reply pesan lalu ketik: .promote")
    }

    const targets = resolveTargetsFromMeta(meta, targetsRaw)

    // hanya promote non-admin (hindari 500 random)
    const toPromote = targets.filter(
      (t) => t && t.rawUpdateId && t.normId && !adminsNorm.has(t.normId)
    )
    if (!toPromote.length) return m.reply?.("Target sudah admin / tidak valid.")

    const rawIds = [...new Set(toPromote.map((t) => t.rawUpdateId).filter(Boolean))]

    // try promote + retry 1x jika WA belum sinkron
    try {
      await wafproject.groupParticipantsUpdate(m.chat, rawIds, "promote")
    } catch (e) {
      const status = e?.output?.statusCode ?? e?.statusCode ?? e?.status ?? ""
      if (String(status) === "500") {
        await delay(RETRY_DELAY_MS)
        await wafproject.groupParticipantsUpdate(m.chat, rawIds, "promote")
      } else {
        throw e
      }
    }

    invalidateMetaCache(wafproject, m.chat)

    const normMentions = [...new Set(toPromote.map((t) => t.normId).filter(Boolean))]
    const mentionText = normMentions.map((j) => `@${String(j).split("@")[0]}`).join(" ")

    await wafproject.sendMessage(
      m.chat,
      { text: `✅ Berhasil promote: ${mentionText}`, mentions: normMentions },
      { quote: m }
    )
  } catch (e) {
    const status = e?.output?.statusCode ?? e?.statusCode ?? e?.status ?? ""
    const reason = e?.data?.message ?? e?.output?.payload?.message ?? e?.message ?? "Unknown error"
    const low = String(reason || "").toLowerCase()

    if (
      low.includes("not-authorized") ||
      low.includes("forbidden") ||
      low.includes("unauthorized") ||
      low.includes("not allowed") ||
      low.includes("permission") ||
      low.includes("admin")
    ) {
      return m.reply?.("Bot harus jadi admin dulu.")
    }

    if (String(status) === "500") {
      return m.reply?.("Gagal promote (server WA error). Pastikan target valid & bukan admin.")
    }

    return m.reply?.(`Gagal promote${status ? ` (code: ${status})` : ""}.`)
  }
}

handler.help = ["promote"]
handler.category = ["admin"]
handler.command = /^(\.?(promote))$/i
handler.group = true
handler.admin = true

module.exports = handler

// =================== FAST META CACHE ===================
function getMetaCache(wafproject) {
  wafproject._metaCacheFast = wafproject._metaCacheFast || {}
  return wafproject._metaCacheFast
}

function invalidateMetaCache(wafproject, chatId) {
  try {
    const root = getMetaCache(wafproject)
    delete root[String(chatId)]
  } catch (_error) { console.error("[ERROR][commands/group/promote.js]", _error?.message || _error) }
}

async function getGroupMetaFast(wafproject, m, ctxMeta, forceFresh = false) {
  if (forceFresh) {
    try {
      if (typeof wafproject.groupMetadata === "function") {
        const meta = await wafproject.groupMetadata(m.chat)
        if (meta?.participants) {
          const root = getMetaCache(wafproject)
          root[m.chat] = { ts: Date.now(), meta }
          return meta
        }
      }
    } catch (_error) { console.error("[ERROR][commands/group/promote.js]", _error?.message || _error) }
  }

  if (ctxMeta?.participants) {
    const root = getMetaCache(wafproject)
    root[m.chat] = { ts: Date.now(), meta: ctxMeta }
    return ctxMeta
  }

  const root = getMetaCache(wafproject)
  const cached = root[m.chat]
  if (cached?.meta?.participants && Date.now() - (cached.ts || 0) < META_CACHE_TTL_MS) {
    return cached.meta
  }

  try {
    if (typeof wafproject.groupMetadata === "function") {
      const meta = await wafproject.groupMetadata(m.chat)
      if (meta?.participants) root[m.chat] = { ts: Date.now(), meta }
      return meta?.participants ? meta : null
    }
  } catch (_error) { console.error("[ERROR][commands/group/promote.js]", _error?.message || _error) }

  return null
}

// =================== HELPERS (ANTI-LID SAFE) ===================
function normJid(id) {
  try {
    if (typeof global.normalizeJid === "function") return String(global.normalizeJid(id) || "")
    if (typeof global.jidNormalized === "function") return String(global.jidNormalized(id) || "")
    if (global.JidNormalizer && typeof global.JidNormalizer.normalize === "function") {
      return String(global.JidNormalizer.normalize(id) || "")
    }
  } catch (_error) { console.error("[ERROR][commands/group/promote.js]", _error?.message || _error) }
  return String(id || "").trim()
}

function delay(ms) {
  return new Promise((res) => setTimeout(res, ms))
}

function scanMentionedJidDeep(obj, outArr) {
  try {
    if (!obj || typeof obj !== "object") return
    if (Array.isArray(obj)) {
      for (const v of obj) scanMentionedJidDeep(v, outArr)
      return
    }
    if (Array.isArray(obj.mentionedJid)) {
      for (const raw of obj.mentionedJid) outArr.push(raw)
    }
    for (const k of Object.keys(obj)) {
      const v = obj[k]
      if (v && typeof v === "object") scanMentionedJidDeep(v, outArr)
    }
  } catch (_error) { console.error("[ERROR][commands/group/promote.js]", _error?.message || _error) }
}

function getMentionsRaw(m) {
  const raw = []
  if (Array.isArray(m?.mentionedJid)) raw.push(...m.mentionedJid)
  if (Array.isArray(m?.mentions)) raw.push(...m.mentions)
  scanMentionedJidDeep(m?.message, raw)
  return [...new Set(raw.map((x) => String(x || "")).filter(Boolean))]
}

function getReplyTargetRaw(m) {
  const a = m?.quoted?.sender
  if (a) return String(a)
  const b = m?.quoted?.key?.participant
  if (b) return String(b)
  const c = m?.quoted?.participant
  if (c) return String(c)
  return ""
}

// ✅ target priority: reply > mentions
function getTargetsRaw(m) {
  const out = []
  const rep = getReplyTargetRaw(m)
  if (rep) out.push(rep)
  const ment = getMentionsRaw(m)
  if (ment.length) out.push(...ment)
  return [...new Set(out.map((x) => String(x || "")).filter(Boolean))]
}

function getAdminsNorm(meta) {
  const parts = meta?.participants || []
  const out = []
  for (const p of parts) {
    const isAdmin =
      p?.admin === "admin" ||
      p?.admin === "superadmin" ||
      p?.isAdmin === true ||
      p?.isSuperAdmin === true
    if (!isAdmin) continue
    const id = String(p?.jid || p?.participant || p?.id || p?.lid || "")
    const n = normJid(id)
    if (n) out.push(n)
  }
  return [...new Set(out)]
}

function resolveTargetsFromMeta(meta, mentionsRaw) {
  const parts = meta?.participants || []
  const out = []

  for (const rawMention of mentionsRaw) {
    const rawStr = String(rawMention || "")
    if (!rawStr) continue

    let found =
      parts.find((p) =>
        String(p?.lid || "") === rawStr ||
        String(p?.id || "") === rawStr ||
        String(p?.jid || "") === rawStr ||
        String(p?.participant || "") === rawStr
      ) || null

    if (!found) {
      const nM = normJid(rawStr)
      if (nM) {
        found =
          parts.find((p) => {
            const keys = [p?.jid, p?.participant, p?.id, p?.lid].filter(Boolean)
            return keys.some((k) => normJid(k) === nM)
          }) || null
      }
    }

    if (!found) continue

    const rawUpdateId = String(found?.id || found?.lid || found?.participant || found?.jid || "")
    const normId = normJid(found?.jid || found?.participant || found?.id || found?.lid || "")
    if (rawUpdateId && normId) out.push({ rawUpdateId, normId })
  }

  const seen = new Set()
  return out.filter((v) => {
    if (!v?.normId || seen.has(v.normId)) return false
    seen.add(v.normId)
    return true
  })
}