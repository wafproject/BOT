// ✨ Plugin group - cekwarn (CJS + LID SAFE) ✨
// Usage:
// .cekwarn @user
// .cekwarn 628xxxx
// (reply) .cekwarn

async function resolveToRealJid(wafproject, m, rawJid, ctxMeta) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith('@s.whatsapp.net')) return s
  if (!m.isGroup) return s

  let meta = null
  try {
    meta = ctxMeta?.participants?.length ? ctxMeta : await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const parts = meta?.participants || []
  const found = parts.find(p =>
    p?.lid === s || p?.id === s || p?.jid === s || p?.participant === s
  )
  return found?.jid || found?.id || found?.participant || s
}

function normalizeJidFromNumber(input) {
  const num = String(input || '').replace(/[^0-9]/g, '')
  if (!num) return null
  return num + '@s.whatsapp.net'
}

async function getTargetJid(wafproject, m, args, ctxMeta) {
  let raw = null

  // reply
  if (m.quoted?.sender) raw = m.quoted.sender
  else if (m.quoted?.key?.participant) raw = m.quoted.key.participant

  // mention popup
  else if (m.mentionedJid?.length) raw = m.mentionedJid[0]
  else if (m?.mentions?.length) raw = m.mentions[0]

  // nomor manual
  if (!raw && args?.[0]) {
    const n = String(args[0]).replace(/[^0-9]/g, '')
    if (n.length >= 8) return normalizeJidFromNumber(n)
  }

  const real = await resolveToRealJid(wafproject, m, raw, ctxMeta)
  if (!real) return null
  if (!String(real).endsWith('@s.whatsapp.net')) return null
  return real
}

function pickNameFromDB(jid) {
  const u = global.db?.data?.users?.[jid]
  if (!u) return null
  return u.name || u.nama || u.pushName || u.registeredName || u.profileName || u.username || null
}

let handler = async (m, { wafproject, args, usedPrefix, command, groupMetadata }) => {
  try {
    if (!global.db?.data?.users) return m.reply('❌ Database tidak tersedia.')

    const target = await getTargetJid(wafproject, m, args, groupMetadata)
    if (!target) {
      const txt =
        "❗ Tag/reply/nomor target dulu.\n\n" +
        "Contoh:\n" +
        (usedPrefix + command) + " @user\n" +
        (usedPrefix + command) + " 628xxxx\n" +
        "(reply chat user) " + (usedPrefix + command)
      return m.reply(txt)
    }

    const user = global.db.data.users[target]
    if (!user) return m.reply('Pengguna tidak ditemukan di database.')

    const war = Number(global.maxwarn || 3)
    const warn = Number(user.warn || 0)
    const reasons = Array.isArray(user.warnReasons) ? user.warnReasons : []

    const num = target.split('@')[0].replace(/[^0-9]/g, '')
    const nameDb = pickNameFromDB(target)
    const nameConn = (typeof wafproject.getName === 'function') ? wafproject.getName(target) : null
    const display = nameDb || nameConn || num

    let out = "📌 *CEK WARN USER*\n\n"
    out += "👤 User: *" + display + "* (@" + num + ")\n"
    out += "⚠️ Warn: *" + warn + "/" + war + "*\n"

    if (reasons.length) {
      out += "\n🧾 *Alasan:*\n"
      out += reasons.map((r, i) => (i + 1) + ". " + r).join("\n")
    } else {
      out += "\n🧾 Alasan: *- (belum ada catatan)*"
    }

    await wafproject.sendMessage(
      m.chat,
      { text: out, mentions: [target] },
      { quote: m }
    )
  } catch (e) {
    console.error('CEKWARN ERROR:', e?.message || e)
    return m.reply("❌ Error: " + (e?.message || e))
  }
}

handler.help = ['cekwarn <reply/mention/628..>']
handler.category = ['admin']
handler.command = ['cekwarn', 'checkwarn']
handler.group = false
handler.admin = true
handler.botAdmin = false
handler.register = true
handler.limit = false

module.exports = handler