/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur: Anti Foto (blokir imageMessage) — WAF CJS
========================
*/

// ===== ADMIN READER (SAMAKAN PERSIS) =====
const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try { meta = await wafproject.groupMetadata(chatJid) } catch { meta = null }
    if (!meta) return { isAdmin: false, isBotAdmin: false, meta: null }

    const participants = meta.participants || []

    const botJid = getBotJid(wafproject)
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderFixed = resolveLidToJid(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, isBotAdmin, meta }
  } catch {
    return { isAdmin: false, isBotAdmin: false, meta: null }
  }
}

function isImageMessage(m) {
  // beberapa base bot pakai m.mtype, ada juga yang tidak
  if (m?.mtype) return m.mtype === 'imageMessage'
  if (m?.message && typeof m.message === 'object') return 'imageMessage' in m.message
  return false
}

const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner }) {
  try {
    if (!m?.isGroup) return
    if (m.fromMe) return
    if (!m.message) return

    // DB bot kamu
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    const chat = root.group[m.chat] || (root.group[m.chat] = {})

    // fitur OFF
    if (!chat.antiFoto) return

    // hanya gambar
    if (!isImageMessage(m)) return

    const sender = m.sender
    const { isAdmin, isBotAdmin } = await getAdminStatus(wafproject, m.chat, sender)

    // admin/owner boleh
    if (isOwner || isAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `🖼️ *ANTI-FOTO (ADMIN / OWNER)*\n\n` +
            `@${sender.split('@')[0]} mengirim gambar.\n` +
            `Karena kamu admin/owner, tidak ada tindakan.`,
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // bot bukan admin
    if (!isBotAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `⚠️ *ANTI-FOTO AKTIF*\n\n` +
            `@${sender.split('@')[0]} mengirim gambar.\n` +
            `Namun bot *bukan admin*, jadi tidak bisa menghapus.`,
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // member kirim foto → delete + warning
    try {
      await wafproject.sendMessage(m.chat, { delete: m.key })
    } catch (e) {
      console.error('Gagal menghapus foto:', e)
    }

    await wafproject.sendMessage(
      m.chat,
      {
        text:
          `🚫 *ANTI-FOTO*\n\n` +
          `@${sender.split('@')[0]} tidak diperbolehkan mengirim gambar di grup ini.`,
        mentions: [sender]
      },
      { quote: m }
    )
  } catch (e) {
    console.error('antiFoto.before error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // hook only
module.exports = handler