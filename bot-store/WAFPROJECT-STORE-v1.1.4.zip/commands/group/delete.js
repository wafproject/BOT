/**
 * ==============================
 * 🗑️ REACT DELETE MESSAGE (HOOK) + CMD .del
 * 👮‍♂️ Admin react ❌ → pesan terhapus
 * 👮‍♂️ Cmd .del (reply pesan) → pesan terhapus (tanpa react bot)
 * ==============================
 * • Hanya admin / owner / rowner
 * • Bot wajib admin
 * • Support LID (participant @lid)
 * • Hook: processReactionFromUpsert(wafproject, db, m)
 * ==============================
 */

// ===== ADMIN READER (SAMAIN PERSIS STYLE) =====
const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try { meta = await wafproject.groupMetadata(chatJid) } catch { meta = null }
    if (!meta) return { isAdmin: false, isBotAdmin: false, meta: null }

    const participants = meta.participants || []

    const botJid = normalizeJid(getBotJid(wafproject))
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderFixed = resolveLidToJid(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, isBotAdmin, meta }
  } catch {
    return { isAdmin: false, isBotAdmin: false, meta: null }
  }
}

// ===== EMOJI NORMALIZER (SUPPORT ❌️) =====
function cleanEmoji(s = '') {
  return String(s || '').replace(/\uFE0F/g, '').trim() // ❌️ -> ❌
}

// ==============================
// CMD: .del (reply pesan)
// ==============================
const handler = async (m, { wafproject, usedPrefix, command }) => {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (!m.quoted) {
      return m.reply(`Reply pesan yang mau dihapus.\nContoh: reply pesan lalu ketik *${usedPrefix + command}*`)
    }

    const { isAdmin, isBotAdmin } = await getAdminStatus(wafproject, m.chat, m.sender)
    if (!isAdmin) return
    if (!isBotAdmin) return m.reply('Bot harus jadi admin untuk menghapus pesan di grup.')

    const qk = m.quoted?.key
    if (!qk?.id) return

    await wafproject.sendMessage(qk.remoteJid || m.chat, { delete: qk }).catch(() => {})
  } catch (e) {
    console.error('del cmd error:', e)
  }
}

handler.help = ['del (reply pesan)']
handler.category = ['admin']
handler.command = /^del$/i
handler.group = true
handler.admin = true
handler.limit = false
handler.register = false

// ==============================
// HOOK: Admin react ❌ hapus pesan
// ==============================
handler.processReactionFromUpsert = async function (wafproject, db, m) {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (!m.message) return

    const r = m.message?.reactionMessage
    if (!r) return

    const emoji = cleanEmoji(r.text)
    if (emoji !== '❌') return

    const who = m.sender // reactor
    if (!who) return

    const { isAdmin, isBotAdmin } = await getAdminStatus(wafproject, m.chat, who)
    if (!isAdmin) return
    if (!isBotAdmin) return

    const key = r.key
    if (!key || !key.id) return

    await wafproject.sendMessage(key.remoteJid || m.chat, { delete: key }).catch(() => {})
  } catch (e) {
    console.error('react-delete error:', e)
  }
}

module.exports = handler