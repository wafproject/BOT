/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur: Anti UpSW (Status Mention Grup)
========================
*/

// ===== ADMIN READER (SAMAKAN PERSIS) =====
const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try { meta = await wafproject.groupMetadata(chatJid) } catch { meta = null }
    if (!meta) return { isAdmin: false, isBotAdmin: false, meta: null }

    const participants = meta.participants || []

    const botJid = getBotJid(wafproject)
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderFixed = resolveLidToJid(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, isBotAdmin, meta }
  } catch {
    return { isAdmin: false, isBotAdmin: false, meta: null }
  }
}

// ===== DETECTOR UPSW =====
function isUpSWMessage(m) {
  return Boolean(
    m?.message?.groupStatusMentionMessage ||
    m?.type === 'groupStatusMentionMessage' ||
    m?.message?.extendedTextMessage?.contextInfo?.isGroupStatusMention
  )
}

const MAX_WARN = 3

const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner }) {
  try {
    if (!m?.isGroup) return
    if (m.fromMe) return
    if (!m.message) return

    // ===== DB WAF =====
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    root.user ||= {}

    const chat = root.group[m.chat] || (root.group[m.chat] = {})

    // fitur OFF
    if (!chat.antiupsw) return

    // bukan UpSW
    if (!isUpSWMessage(m)) return

    const sender = m.sender
    const { isAdmin, isBotAdmin } = await getAdminStatus(wafproject, m.chat, sender)

    // OWNER / ADMIN bebas
    if (isOwner || isAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `ℹ️ *UPSW TERDETEKSI (ADMIN / OWNER)*\n\n` +
            `@${sender.split('@')[0]} mengirim status yang mention grup.\n` +
            `Tidak ada tindakan karena kamu admin/owner.`,
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // BOT bukan admin
    if (!isBotAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `⚠️ *ANTI-UPSW AKTIF*\n\n` +
            `@${sender.split('@')[0]} mengirim UpSW mention grup.\n` +
            `Namun bot *bukan admin*, jadi tidak bisa menghapus atau kick.`,
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // ===== MEMBER BIASA =====
    root.user[sender] ||= {}
    if (typeof root.user[sender].warnUpSW !== 'number') {
      root.user[sender].warnUpSW = 0
    }

    root.user[sender].warnUpSW += 1
    const warnNow = root.user[sender].warnUpSW

    // simpan warning biar persist (kalau bot restart ga reset)
    await db.save?.()

    // hapus pesan UpSW
    try {
      await wafproject.sendMessage(m.chat, { delete: m.key })
    } catch (_error) { console.error("[ERROR][commands/group/antiupsw.js]", _error?.message || _error) }

    // ===== PERINGATAN =====
    if (warnNow < MAX_WARN) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `⚠️ *PERINGATAN UPSW*\n\n` +
            `👤 Pelanggar: @${sender.split('@')[0]}\n` +
            `📌 Pelanggaran: Status mention grup\n` +
            `⚠️ Warning: *${warnNow}/${MAX_WARN}*\n\n` +
            `Jika mencapai ${MAX_WARN}, kamu akan dikeluarkan dari grup.`,
          mentions: [sender]
        },
        { quote: m }
      )
      return
    }

    // ===== KICK =====
    root.user[sender].warnUpSW = 0
    await db.save?.()

    await wafproject.sendMessage(
      m.chat,
      {
        text:
          `⛔ *PENGGUNA DIKELUARKAN*\n\n` +
          `@${sender.split('@')[0]} telah mencapai batas *${MAX_WARN}* peringatan.\n` +
          `Pelanggaran: UpSW mention grup.`,
        mentions: [sender]
      },
      { quote: m }
    )

    await new Promise((r) => setTimeout(r, 1200))
    await wafproject.groupParticipantsUpdate(m.chat, [sender], 'remove').catch(() => {})
  } catch (e) {
    console.error('antiUpSW.before error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // hook only
module.exports = handler