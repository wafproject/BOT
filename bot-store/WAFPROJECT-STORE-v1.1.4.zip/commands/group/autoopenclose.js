// commands/group/auto-openclose.js
// ✨ Auto Open/Close Group FINAL (clean, no debug log) ✨

const schedule = require('node-schedule')
const moment = require('moment-timezone')

/* ================= TIMEZONE ================= */
let TIMEZONE = (global.getZonaWaktu && global.getZonaWaktu()) || 'Asia/Jakarta'
if (!moment.tz.zone(TIMEZONE)) {
  TIMEZONE = 'Asia/Jakarta'
}
const TIMEZONE_LABEL = TIMEZONE === 'Asia/Jakarta' ? 'WIB' : TIMEZONE

/* ================= ADMIN DETECTOR ================= */
const norm = (j) => String(j || '').replace(/:[0-9]+/g, '').trim()
const same = (a, b) => norm(a) === norm(b)

function getPid(p) {
  return norm(p?.id || p?.jid || p?.participant || p?.user || '')
}
function isAdminFlag(p) {
  const role = (p?.role || p?.admin || '').toString().toLowerCase()
  if (role === 'admin' || role === 'superadmin') return true
  if (p?.isAdmin === true || p?.isSuperAdmin === true) return true
  if (p?.admin === true) return true
  return false
}
async function ensureMeta(wafproject, chatId, meta) {
  if (meta?.participants?.length) return meta
  try { return await wafproject.groupMetadata(chatId) } catch { return meta || null }
}
async function isSenderAdmin(wafproject, chatId, senderJid, meta) {
  const m2 = await ensureMeta(wafproject, chatId, meta)
  if (!m2) return { ok: false, meta: null }
  const me = m2.participants.find(p => same(getPid(p), senderJid))
  return { ok: !!(me && isAdminFlag(me)), meta: m2 }
}

/* ================= HELPERS ================= */
async function safeReply(wafproject, m, text) {
  try { if (typeof m.reply === 'function') return await m.reply(String(text)) } catch (_error) { console.error("[ERROR][commands/group/autoopenclose.js]", _error?.message || _error) }
  try { return await wafproject.sendMessage(m.chat, { text: String(text) }, { quote: m }) } catch (_error) { console.error("[ERROR][commands/group/autoopenclose.js]", _error?.message || _error) }
}

function parseSetArg(raw = '') {
  const s = String(raw).trim()
  if (!s) return { error: 'Format kosong.' }

  const idx = s.indexOf('|')
  let timePart = s
  let msgPart = ''
  if (idx !== -1) {
    timePart = s.slice(0, idx).trim()
    msgPart = s.slice(idx + 1).trim()
  }

  const m = timePart.match(/^([01]?\d|2[0-3]):([0-5]\d)$/)
  if (!m) return { error: 'Format jam salah. Gunakan HH:mm (contoh: 06:00)' }

  return {
    hhmm: `${String(m[1]).padStart(2, '0')}:${m[2]}`,
    message: msgPart
  }
}

function ensureDB() {
  global.db ||= {}
  global.db.data ||= {}
  global.db.data.chats ||= {}
  global.db.data.groups ||= {}
}

function getConn() {
  return global.wafproject || global.jagoanproject || null
}

async function setGroupMode(wafproject, jid, mode) {
  if (typeof wafproject.groupSettingUpdate === 'function') {
    return wafproject.groupSettingUpdate(jid, mode)
  }
  if (typeof wafproject.groupUpdateSetting === 'function') {
    return wafproject.groupUpdateSetting(jid, mode)
  }
}

function getAllGroupsMerged() {
  const d = global.db?.data || {}
  return { ...(d.chats || {}), ...(d.groups || {}) }
}

/* ================= SCHEDULER ================= */
try {
  if (global.__autoOCJob?.cancel) global.__autoOCJob.cancel()
} catch (_error) { console.error("[ERROR][commands/group/autoopenclose.js]", _error?.message || _error) }

global.__autoOCJob = schedule.scheduleJob('* * * * *', async () => {
  const wafproject = getConn()
  if (!wafproject || !global.db?.data) return

  const now = moment.tz(TIMEZONE)
  const hour = now.hour()
  const minute = now.minute()
  const today = now.format('YYYY-MM-DD')

  const all = getAllGroupsMerged()

  for (const id in all) {
    if (!id.endsWith('@g.us')) continue
    const chat = all[id]
    if (!chat?.autoOpenClose) continue
    if (chat.autoOpenClose.enabled === false) continue

    chat.autoOCLog ||= { open: null, close: null }

    const { open, close } = chat.autoOpenClose

    if (
      open &&
      open.hour === hour &&
      open.minute === minute &&
      chat.autoOCLog.open !== today
    ) {
      chat.autoOCLog.open = today
      try { await setGroupMode(wafproject, id, 'not_announcement') } catch (_error) { console.error("[ERROR][commands/group/autoopenclose.js]", _error?.message || _error) }
      if (open.message) {
        try { await wafproject.sendMessage(id, { text: open.message }) } catch (_error) { console.error("[ERROR][commands/group/autoopenclose.js]", _error?.message || _error) }
      }
    }

    if (
      close &&
      close.hour === hour &&
      close.minute === minute &&
      chat.autoOCLog.close !== today
    ) {
      chat.autoOCLog.close = today
      try { await setGroupMode(wafproject, id, 'announcement') } catch (_error) { console.error("[ERROR][commands/group/autoopenclose.js]", _error?.message || _error) }
      if (close.message) {
        try { await wafproject.sendMessage(id, { text: close.message }) } catch (_error) { console.error("[ERROR][commands/group/autoopenclose.js]", _error?.message || _error) }
      }
    }
  }
})

/* ================= COMMAND HANDLER ================= */
const handler = async (m, { wafproject, command, text, isAdmin, groupMetadata, usedPrefix }) => {
  if (!m.isGroup) return

  const sender = norm(m.sender)
  let adminOK = !!isAdmin
  if (!adminOK) {
    const res = await isSenderAdmin(wafproject, m.chat, sender, groupMetadata)
    adminOK = res.ok
  }
  if (!adminOK) return

  ensureDB()

  const chat = (global.db.data.groups[m.chat] ||= {})
  chat.autoOpenClose ||= { enabled: true, open: null, close: null }

  /* ===== .autooc ===== */
  if (command === 'autooc') {
    const arg = text.trim().toLowerCase()

    if (arg === 'on') {
      chat.autoOpenClose.enabled = true
      return safeReply(wafproject, m, '✅ Auto Open/Close *AKTIF*')
    }

    if (arg === 'off') {
      chat.autoOpenClose.enabled = false
      return safeReply(wafproject, m, '⛔ Auto Open/Close *NONAKTIF*')
    }

    const st = chat.autoOpenClose
    const fmt = (x) =>
      x ? `${String(x.hour).padStart(2, '0')}:${String(x.minute).padStart(2, '0')} ${TIMEZONE_LABEL}` : '-'

    return safeReply(
      wafproject,
      m,
      `📌 *AUTO OPEN/CLOSE STATUS*\n\n` +
      `Status : *${st.enabled === false ? 'OFF' : 'ON'}*\n` +
      `Open   : ${fmt(st.open)}\n` +
      `Close  : ${fmt(st.close)}`
    )
  }

  /* ===== setautoopen / setautoclose ===== */
  if (command !== 'setautoopen' && command !== 'setautoclose') return

  const parsed = parseSetArg(text)
  if (parsed.error) {
    return safeReply(
      wafproject,
      m,
      `❌ ${parsed.error}\nContoh:\n${usedPrefix}setautoopen 06:00 | Grup dibuka`
    )
  }

  const [hh, mm] = parsed.hhmm.split(':').map(Number)

  if (command === 'setautoopen') {
    chat.autoOpenClose.open = { hour: hh, minute: mm, message: parsed.message }
    chat.autoOpenClose.enabled = true
    chat.autoOCLog ||= { open: null, close: null }
    chat.autoOCLog.open = null
    return safeReply(wafproject, m, `✅ Auto Open disimpan (${parsed.hhmm} ${TIMEZONE_LABEL})`)
  }

  chat.autoOpenClose.close = { hour: hh, minute: mm, message: parsed.message }
  chat.autoOpenClose.enabled = true
  chat.autoOCLog ||= { open: null, close: null }
  chat.autoOCLog.close = null
  return safeReply(wafproject, m, `✅ Auto Close disimpan (${parsed.hhmm} ${TIMEZONE_LABEL})`)
}

handler.help = ['autooc', 'setautoopen', 'setautoclose']
handler.command = ['autooc', 'setautoopen', 'setautoclose']
handler.category = ['admin']
handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler