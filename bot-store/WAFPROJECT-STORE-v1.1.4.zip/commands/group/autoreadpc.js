/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur : Auto Read Private Chat (AUTO FALLBACK)
========================
*/

const handler = (m) => m

handler.all = async function (m, { wafproject }) {
  try {
    if (!m || !wafproject) return

    global.opts = global.opts || {}
    if (!global.opts.autoreadpc) return

    const key = m.key || {}
    const chat = key.remoteJid || m.chat
    const id = key.id

    // PC only
    if (!chat || !chat.endsWith("@s.whatsapp.net")) return

    // jangan baca pesan sendiri
    if (key.fromMe || m.fromMe) return

    // minimal harus ada id + remoteJid
    if (!id || !key.remoteJid) return

    // ==============
    // 1) Cara paling ngaruh ke centang biru (umumnya)
    // ==============
    if (typeof wafproject.readMessages === "function") {
      try {
        await wafproject.readMessages([key])
        return
      } catch (e) {
        // lanjut fallback
      }
    }

    // ==============
    // 2) Fallback: sendReceipt read (kadang cuma server-side)
    // ==============
    if (typeof wafproject.sendReceipt === "function") {
      try {
        await wafproject.sendReceipt(chat, undefined, [id], "read")
        return
      } catch (e) {
        // lanjut fallback
      }
    }

    // ==============
    // 3) Fallback terakhir: chatModify markRead (sering error incomplete key, tapi biarin)
    // ==============
    if (typeof wafproject.chatModify === "function") {
      try {
        await wafproject.chatModify(
          { markRead: true, lastMessages: [key] },
          chat
        )
      } catch (e) { console.error("[ERROR][commands/group/autoreadpc.js]", e?.message || e) }
    }
  } catch (e) {
    console.error("autoreadpc error:", e?.message || e)
  }
}

handler.help = ["autoreadpc"]
handler.category = ["owner"]
handler.command = [] // hook only

module.exports = handler