// ✨ Plugin group - delwarn (CJS + LID SAFE) ✨
// Usage:
// .delwarn @user
// .delwarn 628xxxx
// (reply) .delwarn
// .delwarn @user 2   (hapus reason ke-2)
// .delwarn @user all (hapus semua warn)

async function resolveToRealJid(wafproject, m, rawJid, ctxMeta) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith('@s.whatsapp.net')) return s
  if (!m.isGroup) return s

  let meta = null
  try {
    meta = ctxMeta?.participants?.length ? ctxMeta : await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const parts = meta?.participants || []
  const found = parts.find(p =>
    p?.lid === s || p?.id === s || p?.jid === s || p?.participant === s
  )
  return found?.jid || found?.id || found?.participant || s
}

function normalizeJidFromNumber(input) {
  const num = String(input || '').replace(/[^0-9]/g, '')
  if (!num) return null
  return num + '@s.whatsapp.net'
}

async function getTargetJid(wafproject, m, args, ctxMeta) {
  let raw = null

  // reply
  if (m.quoted?.sender) raw = m.quoted.sender
  else if (m.quoted?.key?.participant) raw = m.quoted.key.participant

  // mention popup / mention biasa
  else if (m.mentionedJid?.length) raw = m.mentionedJid[0]
  else if (m?.mentions?.length) raw = m.mentions[0]

  // nomor manual
  if (!raw && args?.[0]) {
    const n = String(args[0]).replace(/[^0-9]/g, '')
    if (n.length >= 8) return normalizeJidFromNumber(n)
  }

  const real = await resolveToRealJid(wafproject, m, raw, ctxMeta)
  if (!real) return null
  if (!String(real).endsWith('@s.whatsapp.net')) return null
  return real
}

function pickNameFromDB(jid) {
  const u = global.db?.data?.users?.[jid]
  if (!u) return null
  return u.name || u.nama || u.pushName || u.registeredName || u.profileName || u.username || null
}

let handler = async (m, { wafproject, text, args, usedPrefix, command, groupMetadata }) => {
  try {
    if (!m.isGroup) return m.reply('Khusus grup ya.')
    if (!global.db?.data?.users) return m.reply('❌ Database tidak tersedia.')
    const war = Number(global.maxwarn || 3)

    const tokens = String(text || '').trim().split(/\s+/).filter(Boolean)

    // target wajib: mention/reply/nomor
    const target = await getTargetJid(wafproject, m, args || tokens, groupMetadata)
    if (!target) {
      return m.reply(
        `❗ Tag/reply/nomor target dulu.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} @user\n` +
        `${usedPrefix + command} 628xxxx\n` +
        `(reply chat user) ${usedPrefix + command}\n` +
        `Opsional:\n` +
        `${usedPrefix + command} @user 2 (hapus reason ke-2)\n` +
        `${usedPrefix + command} @user all (hapus semua warn)`
      )
    }

    const user = global.db.data.users[target]
    if (!user) return m.reply('Pengguna tidak ditemukan di database.')

    const curWarn = Number(user.warn || 0)
    const reasons = Array.isArray(user.warnReasons) ? user.warnReasons : []

    if (curWarn <= 0) {
      return wafproject.sendMessage(
        m.chat,
        { text: `✅ @${target.split('@')[0]} tidak punya warn.`, mentions: [target] },
        { quote: m }
      )
    }

    // token sesudah target: "all" / angka index reason
    // NOTE: kalau target dari reply/mention, tokens[0] bisa durasi/apa pun,
    // jadi kita ambil arg terakhir yang meaningful
    const last = String(tokens[tokens.length - 1] || '').toLowerCase()

    let mode = 'dec' // default: kurangi 1 warn
    let removeIndex = -1

    if (last === 'all' || last === 'reset') {
      mode = 'all'
    } else if (/^\d+$/.test(last)) {
      mode = 'idx'
      removeIndex = parseInt(last, 10) - 1
      if (removeIndex < 0) removeIndex = -1
    }

    // reaksi proses
    try { await wafproject.sendMessage(m.chat, { react: { text: '🕒', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/warningdel.js]", _error?.message || _error) }

    if (mode === 'all') {
      user.warn = 0
      user.warnReasons = []
    } else if (mode === 'idx') {
      // hapus reason tertentu, warn ikut berkurang 1 (jika masih ada)
      if (!reasons.length) {
        // kalau gak ada reasons, fallback kurangi warn biasa
        user.warn = Math.max(0, curWarn - 1)
      } else {
        if (removeIndex >= reasons.length) {
          return m.reply(`Index alasan tidak valid. Range: 1-${reasons.length}`)
        }
        reasons.splice(removeIndex, 1)
        user.warnReasons = reasons
        user.warn = Math.max(0, curWarn - 1)
      }
    } else {
      // default: kurangi 1 warn + pop last reason kalau ada
      user.warn = Math.max(0, curWarn - 1)
      if (reasons.length) {
        reasons.pop()
        user.warnReasons = reasons
      }
    }

    const newWarn = Number(user.warn || 0)
    const num = target.split('@')[0].replace(/[^0-9]/g, '')
    const nameDb = pickNameFromDB(target)
    const nameConn = (typeof wafproject.getName === 'function') ? wafproject.getName(target) : null
    const display = nameDb || nameConn || num

    let info = `✅ *DELWARN BERHASIL*\n\n`
    info += `👤 User: *${display}* (@${num})\n`
    info += `⚠️ Warn: *${newWarn}/${war}*\n`

    if (mode === 'all') info += `🧹 Mode: *RESET ALL*\n`
    else if (mode === 'idx') info += `🧾 Mode: *HAPUS ALASAN #${removeIndex + 1}*\n`
    else info += `➖ Mode: *KURANGI 1 WARN*\n`

    // tampilkan reasons tersisa
    const left = Array.isArray(user.warnReasons) ? user.warnReasons : []
    if (left.length) {
      info += `\n📌 Alasan tersisa:\n`
      left.forEach((r, i) => (info += `${i + 1}. ${r}\n`))
    } else {
      info += `\n📌 Alasan tersisa: -`
    }

    await wafproject.sendMessage(
      m.chat,
      { text: info, mentions: [target] },
      { quote: m }
    )

    try { await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/warningdel.js]", _error?.message || _error) }
  } catch (e) {
    console.error('DELWARN ERROR:', e?.message || e)
    try { await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/warningdel.js]", _error?.message || _error) }
    return m.reply(`❌ Error: ${e?.message || e}`)
  }
}

handler.help = ['delwarn <reply/mention/628..> [all/nomor_alasan]']
handler.category = ['admin']
handler.command = ['delwarn']
handler.group = true
handler.admin = true
handler.botAdmin = false
handler.register = true
handler.limit = false

module.exports = handler