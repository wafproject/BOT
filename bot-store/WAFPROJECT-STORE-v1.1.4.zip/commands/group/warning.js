// ✨ WARN (LID SAFE, ikut gaya plugin premium) ✨

const time = async (ms) => new Promise(resolve => setTimeout(resolve, ms))

function normalizeJidFromNumber(input) {
  const num = String(input || '').replace(/[^0-9]/g, '')
  if (!num) return null
  return num + '@s.whatsapp.net'
}

// ================================
// ✅ LID SAFE RESOLVER (sama kayak premium)
// ================================
async function resolveToRealJid(wafproject, m, rawJid, ctxMeta) {
  if (!rawJid) return null
  const s = String(rawJid)

  if (s.endsWith('@s.whatsapp.net')) return s
  if (!m.isGroup) return s

  let meta = null
  try {
    if (ctxMeta?.participants?.length) meta = ctxMeta
    else if (typeof wafproject.groupMetadata === 'function') meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const participants = meta?.participants || []
  const found = participants.find(p =>
    p?.lid === s ||
    p?.id === s ||
    p?.jid === s ||
    p?.participant === s
  )

  return found?.jid || found?.id || found?.participant || s
}

async function getTargetJid(wafproject, m, args, ctxMeta) {
  let raw = null

  // reply
  if (m.quoted?.sender) raw = m.quoted.sender
  else if (m.quoted?.key?.participant) raw = m.quoted.key.participant

  // mention
  else if (m.mentionedJid?.length) raw = m.mentionedJid[0]

  // nomor manual
  else if (args[0]) {
    const n = String(args[0]).replace(/[^0-9]/g, '')
    if (n.length >= 8) return normalizeJidFromNumber(n)
  }

  const real = await resolveToRealJid(wafproject, m, raw, ctxMeta)
  if (!real) return null
  if (!String(real).endsWith('@s.whatsapp.net')) return null
  return real
}

function pickReason(m, text, args) {
  const t = String(text || '').trim()
  if (t.includes('|')) return t.split('|').slice(1).join('|').trim()
  if (m.quoted && t && !t.includes('@') && !t.match(/\d{10,}/)) return t.trim()
  return args.slice(1).join(' ').trim()
}

let handler = async (m, { wafproject, text, args, usedPrefix, command, groupMetadata }) => {
  if (!m.isGroup) return m.reply('❌ Khusus grup.')
  if (!global.db?.data?.users) return m.reply('❌ Database user tidak tersedia.')

  const war = Number(global.maxwarn || 3)

  const target = await getTargetJid(wafproject, m, args || [], groupMetadata)
  if (!target) {
    return m.reply(
      `❗ Target tidak valid / masih terbaca LID.\n\n` +
      `📌 Contoh:\n` +
      `- ${usedPrefix + command} @user|Spam\n` +
      `- ${usedPrefix + command} 628123456789|Iklan\n` +
      `- reply pesan user lalu ketik: ${usedPrefix + command} Toxic`
    )
  }

  const reason = pickReason(m, text, args || [])
  if (!reason) {
    return m.reply(
      `⚠️ Harap tulis alasannya!\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} @user|Spam\n` +
      `${usedPrefix + command} 628xxxx|Iklan\n` +
      `atau reply user: ${usedPrefix + command} Toxic`
    )
  }

  // init DB
  global.db.data.users[target] ||= {}
  const user = global.db.data.users[target]
  if (typeof user.warn !== 'number') user.warn = 0
  if (!Array.isArray(user.warnReasons)) user.warnReasons = []

  const number = target.split('@')[0]

  const react = async (emoji) => {
    try { await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/warning.js]", _error?.message || _error) }
  }

  try {
    await react('⚠️')

    if (user.warn < war) {
      user.warn += 1
      user.warnReasons.push(reason)

      const adminName = (typeof wafproject.getName === 'function' ? wafproject.getName(m.sender) : null) || 'Admin'

      await wafproject.sendMessage(
        m.chat,
        {
          text:
`⚠️ *Pengguna yang Diperingatkan* ⚠️

✧ *Admin:* ${adminName}
✧ *Pengguna:* @${number}
✧ *Peringatan:* ${user.warn}/${war}
✧ *Alasan:* ${reason}`,
          mentions: [target]
        },
        { quote: m.quoted || m }
      )

      await react('✅')
      return
    }

    // kick
    user.warn = 0
    user.warnReasons = []

    await wafproject.sendMessage(
      m.chat,
      { text: `⛔ Melebihi batas *${war}* peringatan. Mengeluarkan @${number}...`, mentions: [target] },
      { quote: m }
    )

    await time(1500)
    await wafproject.groupParticipantsUpdate(m.chat, [target], 'remove')

    await wafproject.sendMessage(
      m.chat,
      {
        text: `♻️ @${number} dikeluarkan dari grup *${groupMetadata?.subject || 'Group'}* karena telah diperingatkan *${war}* kali.`,
        mentions: [target]
      },
      { quote: m }
    )

    await react('✅')
  } catch (e) {
    console.error('WARN ERROR:', e?.message || e)
    await react('❌')
    return m.reply(`❌ Error: ${e?.message || e}`)
  }
}

handler.help = ['warn <reply/mention/nomor>|<alasan>']
handler.category = ['admin']
handler.command = ['warn']
handler.group = true
handler.admin = true
handler.botAdmin = true
handler.register = true
handler.limit = false

module.exports = handler