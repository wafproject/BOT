/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

// CommonJS plugin (module.exports), cocok untuk base CJS kamu.

const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

const pickOwnerJid = (meta) => {
  if (meta?.owner) return meta.owner
  const sup = (meta?.participants || []).find((p) => p.admin === 'superadmin')
  return sup?.id || sup?.jid || ''
}

async function replyText(m, wafproject, text, extra = {}) {
  try {
    return await wafproject.sendMessage(m.chat, { text: String(text), ...extra }, { quote: m })
  } catch (_error) { console.error("[ERROR][commands/group/add-kick.js]", _error?.message || _error) }
}

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

// ===== unwrap message (ephemeral/viewonce dll) =====
function unwrapMessage(m) {
  let msg = m?.message || m?.msg || null
  if (!msg) return null

  for (let i = 0; i < 6; i++) {
    if (msg?.ephemeralMessage?.message) { msg = msg.ephemeralMessage.message; continue }
    if (msg?.viewOnceMessage?.message) { msg = msg.viewOnceMessage.message; continue }
    if (msg?.viewOnceMessageV2?.message) { msg = msg.viewOnceMessageV2.message; continue }
    if (msg?.editedMessage?.message) { msg = msg.editedMessage.message; continue }
    if (msg?.protocolMessage?.editedMessage) { msg = msg.protocolMessage.editedMessage; continue }
    break
  }
  return msg
}

function getContextInfo(innerMsg) {
  if (!innerMsg) return null
  const types = [
    'extendedTextMessage',
    'imageMessage',
    'videoMessage',
    'documentMessage',
    'buttonsResponseMessage',
    'listResponseMessage',
    'templateButtonReplyMessage'
  ]
  for (const t of types) {
    const node = innerMsg?.[t]
    if (node?.contextInfo) return node.contextInfo
  }
  return innerMsg?.contextInfo || null
}

// ===== ambil mentioned jid robust =====
function extractMentionedJids(m) {
  const out = new Set()

  if (Array.isArray(m?.mentionedJid)) {
    for (const j of m.mentionedJid) if (j) out.add(j)
  }

  const inner = unwrapMessage(m)
  const ctx = getContextInfo(inner)
  const arr = ctx?.mentionedJid || ctx?.mentionedJids || []
  if (Array.isArray(arr)) for (const j of arr) if (j) out.add(j)

  const ctx2 = m?.msg?.contextInfo
  const arr2 = ctx2?.mentionedJid || []
  if (Array.isArray(arr2)) for (const j of arr2) if (j) out.add(j)

  return [...out]
}

function parseNumbersToJids(text = '') {
  const raw = String(text || '')
  const nums = raw.match(/[0-9]{5,16}/g) || []
  const out = []
  for (let n of nums) {
    n = String(n).replace(/[^0-9]/g, '')
    if (!n) continue
    if (n.startsWith('0')) n = '62' + n.slice(1)
    if (!n.startsWith('62')) n = '62' + n
    out.push(n + '@s.whatsapp.net')
  }
  return [...new Set(out)]
}

async function handler(m, { wafproject, isOwner, isAdmin, groupMetadata, text, command }) {
  if (!m.isGroup) return replyText(m, wafproject, 'Fitur ini hanya di grup.')

  const meta = groupMetadata || (await wafproject.groupMetadata(m.chat).catch(() => null))
  if (!meta) return replyText(m, wafproject, 'Tidak bisa mengambil data grup.')

  const botJid = getBotJid(wafproject)
  const botPart = (meta.participants || []).find((p) => sameJid(resolveParticipantJid(p), botJid))
  const botIsAdmin = isAdminFlag(botPart)

  if (!(isAdmin || isOwner)) {
    if (typeof global.dfail === 'function') global.dfail('admin', m, wafproject)
    return
  }

  const cmd = String(command || '').toLowerCase()
  const argText = String(text || m.text || '').trim()

  const ownerGroup = pickOwnerJid(meta) || (m.chat.split`-`[0] + '@s.whatsapp.net')
  const participantSet = new Set((meta.participants || []).map(p => normalizeJid(resolveParticipantJid(p))))

  // ============ KICK ============
  if (['kick', 'dor', 'cilukbaa'].includes(cmd)) {
    // NOTE: KICK masih support reply/mention/nomor (sesuai plugin kamu sebelumnya)
    const qSender = (() => {
      const inner = unwrapMessage(m)
      const ctx = getContextInfo(inner)
      return ctx?.participant || m?.msg?.contextInfo?.participant || ''
    })()

    const hasReply = !!qSender
    const hasMention = extractMentionedJids(m).length > 0
    const hasNumber = parseNumbersToJids(argText).length > 0

    if (!hasReply && !hasMention && !hasNumber) {
      return replyText(
        m, wafproject,
        `❌ Target tidak ditemukan.\n\nContoh:\n` +
        `• .kick (reply pesan user)\n` +
        `• .kick @user (mention beneran)\n` +
        `• .kick 628xxxx`
      )
    }

    if (!botIsAdmin) return replyText(m, wafproject, '❌ Bot belum jadi *admin*. Jadikan bot admin dulu ya.')

    let targets = []

    // 1) reply
    if (hasReply) targets = [qSender]

    // 2) mention
    if (!targets.length && hasMention) targets = extractMentionedJids(m)

    // 3) nomor
    if (!targets.length && hasNumber) targets = parseNumbersToJids(argText)

    // resolve lid -> jid dan filter valid
    targets = (targets || [])
      .filter(Boolean)
      .map(j => resolveLidToJid(j, meta))
      .filter(j => /@s\.whatsapp\.net$/.test(j))
      .filter(j => !sameJid(j, ownerGroup))
      .filter(j => !sameJid(j, botJid))
      .filter(j => participantSet.has(normalizeJid(j))) // harus member grup

    if (!targets.length) {
      return replyText(
        m, wafproject,
        `❌ Target tidak valid / bukan member grup.\n\nContoh:\n` +
        `• reply pesan target lalu .kick\n` +
        `• .kick @user\n` +
        `• .kick 628xxxx`
      )
    }

    const ok = []
    const fail = []

    for (const jid of targets) {
      try {
        await wafproject.groupParticipantsUpdate(m.chat, [jid], 'remove')
        ok.push(jid)
      } catch (e) {
        fail.push({ jid, msg: e?.message || String(e) })
      }
    }

    if (fail.length) {
      await replyText(
        m, wafproject,
        fail.map(x => `❌ Gagal kick @${x.jid.split('@')[0]}: ${x.msg}`).join('\n'),
        { mentions: fail.map(x => x.jid) }
      )
    }
    if (ok.length) {
      await replyText(
        m, wafproject,
        `✅ Berhasil kick: ${ok.map(j => '@' + j.split('@')[0]).join(', ')}`,
        { mentions: ok }
      )
    }
    return
  }

  // ============ ADD (NO REPLY MODE) ============
  if (cmd === 'add') {
    if (!botIsAdmin) return replyText(m, wafproject, '❌ Bot belum jadi *admin*. Jadikan bot admin dulu ya.')

    let targets = []

    // ✅ 1) mention beneran
    const mentions = extractMentionedJids(m).map(j => resolveLidToJid(j, meta))
    if (mentions.length) targets = mentions.filter(j => !sameJid(j, botJid))

    // ✅ 2) nomor
    if (!targets.length) targets = parseNumbersToJids(argText).filter(j => !sameJid(j, botJid))

    if (!targets.length) {
      return replyText(
        m,
        wafproject,
        `Contoh:\n` +
        `• .add 628123456789\n` +
        `• .add @user (mention beneran)`
      )
    }

    // filter final: harus jid normal
    targets = targets
      .filter(Boolean)
      .map(j => resolveLidToJid(j, meta))
      .filter(j => /@s\.whatsapp\.net$/.test(j))
      .filter(j => !sameJid(j, botJid))
      .filter(j => !sameJid(j, ownerGroup))

    if (!targets.length) return replyText(m, wafproject, '❌ Target tidak valid. Pakai nomor/mention yang benar.')

    const added = [], invited = [], failed = []
    for (const jid of targets) {
      try {
        await wafproject.groupParticipantsUpdate(m.chat, [jid], 'add')
        added.push(jid)
      } catch {
        try {
          const code = await wafproject.groupInviteCode(m.chat)
          const link = `https://chat.whatsapp.com/${code}`
          invited.push(jid)
          await replyText(
            m, wafproject,
            `Tidak bisa add langsung, diundang via link:\n${link}\n@${jid.split('@')[0]}`,
            { mentions: [jid] }
          )
        } catch {
          failed.push(jid)
        }
      }
    }

    const parts = []
    if (added.length) parts.push('✅ Ditambahkan: ' + added.map(v => '@' + v.split('@')[0]).join(', '))
    if (invited.length) parts.push('✉️ Diundang: ' + invited.map(v => '@' + v.split('@')[0]).join(', '))
    if (failed.length) parts.push('❌ Gagal: ' + failed.map(v => '@' + v.split('@')[0]).join(', '))

    await replyText(m, wafproject, parts.join('\n') || 'Tidak ada perubahan.', {
      mentions: [...added, ...invited, ...failed]
    })
    return
  }
}

handler.help = ['add', 'kick']
handler.command = ['add', 'kick', 'dor', 'cilukbaa']
handler.category = 'admin'
handler.description = 'Add/Kick member (admin/owner). Bot harus admin.'
handler.group = true
handler.owner = false
handler.limit = false

module.exports = handler