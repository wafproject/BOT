/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur: Anti Toxic (HOOK ONLY) — FINAL FIX
========================
*/

const fs = require('fs')
const path = require('path')

// lokasi penyimpanan (TIDAK DIUBAH)
const toxicDbPath = path.join(process.cwd(), 'lib', 'datatoxic.json')

// Maksimum peringatan sebelum kick
const maxWarn = 7

// ===== init file =====
function ensureToxicDb() {
  try {
    const dir = path.dirname(toxicDbPath)
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

    if (!fs.existsSync(toxicDbPath)) {
      fs.writeFileSync(toxicDbPath, JSON.stringify([], null, 2))
      return
    }

    const raw = fs.readFileSync(toxicDbPath, 'utf8')
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) fs.writeFileSync(toxicDbPath, JSON.stringify([], null, 2))
  } catch {
    try { fs.writeFileSync(toxicDbPath, JSON.stringify([], null, 2)) } catch (_error) { console.error("[ERROR][commands/group/antitoxic.js]", _error?.message || _error) }
  }
}

function loadToxicWords() {
  ensureToxicDb()
  try {
    const raw = fs.readFileSync(toxicDbPath, 'utf8')
    const arr = JSON.parse(raw)
    return Array.isArray(arr) ? arr.map(v => String(v).toLowerCase()).filter(Boolean) : []
  } catch {
    return []
  }
}

function escapeRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function getBodyText(m) {
  return (
    m.text ||
    m.body ||
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    ''
  )
}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// ===== ADMIN READER (SAMAIN PERSIS STYLE) =====
const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try { meta = await wafproject.groupMetadata(chatJid) } catch { meta = null }
    if (!meta) return { isAdmin: false, isBotAdmin: false, meta: null }

    const participants = meta.participants || []

    const botJid = normalizeJid(getBotJid(wafproject))
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderFixed = resolveLidToJid(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, isBotAdmin, meta }
  } catch {
    return { isAdmin: false, isBotAdmin: false, meta: null }
  }
}

// ========== PLUGIN HOOK ==========
const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner }) {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (m.fromMe) return
    if (!m.message) return

    const root = db?.list ? db.list() : {}
    root.group ||= {}
    root.user ||= {}

    const chat = root.group[m.chat] || (root.group[m.chat] = {})
    if (!chat.antiToxic) return

    // owner bebas
    if (isOwner) return

    const body = getBodyText(m)
    if (!body) return

    const toxicWords = loadToxicWords()
    if (!toxicWords.length) return

    const who = m.sender
    const { isAdmin, isBotAdmin } = await getAdminStatus(wafproject, m.chat, who)
    if (isAdmin) return

    const textLower = body.toLowerCase()

    // cari kata toxic (boundary)
    let found = null
    for (const w of toxicWords) {
      const re = new RegExp(`\\b${escapeRegex(w)}\\b`, 'i')
      if (re.test(textLower)) { found = w; break }
    }
    if (!found) return

    // init warn
    root.user[who] ||= {}
    if (typeof root.user[who].warnToxic !== 'number') root.user[who].warnToxic = 0

    // bot bukan admin
    if (!isBotAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `⚠️ *ANTI TOXIC AKTIF*\n\n` +
            `👤 @${who.split('@')[0]} terdeteksi kata toxic.\n` +
            `🧨 Kata: *${found}*\n\n` +
            `Bot bukan admin, jadi tidak bisa hapus/kick.`,
          mentions: [who]
        },
        { quote: m }
      )
      return
    }

    // hapus pesan
    await wafproject.sendMessage(m.chat, { delete: m.key }).catch(() => {})

    // warn/kick
    if (root.user[who].warnToxic < (maxWarn - 1)) {
      root.user[who].warnToxic += 1
      await db.save?.()

      const warnNow = root.user[who].warnToxic

      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `🚨 *PERINGATAN TOXIC*\n\n` +
            `👤 Pengguna: @${who.split('@')[0]}\n` +
            `🧨 Kata: *${found}*\n` +
            `⚠️ Warning: *${warnNow}/${maxWarn}*\n\n` +
            `Pesan sudah dihapus.\n` +
            `> Jika mencapai ${maxWarn}, kamu akan di-kick.`,
          mentions: [who]
        },
        { quote: m }
      )
    } else {
      root.user[who].warnToxic = 0
      await db.save?.()

      await wafproject.sendMessage(
        m.chat,
        {
          text:
            `⛔ @${who.split('@')[0]} sudah melewati batas *${maxWarn}* warning toxic.\n` +
            `Akan dikeluarkan dari grup.`,
          mentions: [who]
        },
        { quote: m }
      )

      await delay(1500)
      await wafproject.groupParticipantsUpdate(m.chat, [who], 'remove').catch(() => {})
    }
  } catch (e) {
    console.error('antitoxic.before error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // ✅ HOOK ONLY BIAR JALAN DI PESAN BIASA
module.exports = handler