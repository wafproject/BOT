// ✨ WARNLIST (LID SAFE + ambil nama dari DB) ✨

async function resolveToRealJid(wafproject, m, rawJid, ctxMeta) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith('@s.whatsapp.net')) return s
  if (!m.isGroup) return s

  let meta = null
  try {
    meta = ctxMeta?.participants?.length ? ctxMeta : await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const parts = meta?.participants || []
  const found = parts.find(p =>
    p?.lid === s || p?.id === s || p?.jid === s || p?.participant === s
  )
  return found?.jid || found?.id || found?.participant || s
}

function pickNameFromDB(jid) {
  const u = global.db?.data?.users?.[jid]
  if (!u) return null
  return (
    u.name ||
    u.nama ||
    u.pushName ||
    u.registeredName ||
    u.profileName ||
    u.username ||
    null
  )
}

let handler = async (m, { wafproject, groupMetadata }) => {
  try {
    const war = Number(global.maxwarn || 3)
    const meta = groupMetadata?.participants?.length ? groupMetadata : await wafproject.groupMetadata(m.chat).catch(() => groupMetadata)

    // set member jid asli grup
    const memberReal = new Set()
    for (const p of (meta?.participants || [])) {
      const raw = p?.jid || p?.id || p?.participant || p?.lid
      const real = await resolveToRealJid(wafproject, m, raw, meta)
      if (real && String(real).endsWith('@s.whatsapp.net')) memberReal.add(real)
    }

    // ambil warn dari DB
    const all = Object.entries(global.db?.data?.users || {})
      .filter(([_, u]) => Number(u?.warn || 0) > 0)

    // filter hanya yg ada di grup ini
    let users = []
    for (const [jidRaw, u] of all) {
      const jid = await resolveToRealJid(wafproject, m, jidRaw, meta) || jidRaw
      if (!String(jid).endsWith('@s.whatsapp.net')) continue
      if (m.isGroup && memberReal.size && !memberReal.has(jid)) continue

      const number = jid.split('@')[0].replace(/[^0-9]/g, '')
      const nameDb = pickNameFromDB(jid) // ✅ prioritas DB
      const nameConn = (typeof wafproject.getName === 'function') ? wafproject.getName(jid) : null

      users.push({
        jid,
        number,
        name: nameDb || nameConn || number,
        warn: Number(u.warn || 0),
        reasons: Array.isArray(u.warnReasons) && u.warnReasons.length ? u.warnReasons : ['Tidak ada alasan yang dicatat']
      })
    }

    users.sort((a, b) => (b.warn - a.warn) || a.number.localeCompare(b.number))

    if (!users.length) return m.reply('Tidak ada pengguna yang memiliki peringatan di grup ini.')

    let msg = `📋 *Daftar Pengguna yang Diperingatkan* 📋\n\n`
    msg += `Grup: *${meta?.subject || groupMetadata?.subject || 'Group'}*\n\n`

    users.forEach((u, i) => {
      msg += `${i + 1}. *${u.name}* (@${u.number})\n`
      msg += `   Peringatan: ${u.warn}/${war}\n`
      msg += `   Alasan:\n`
      u.reasons.forEach((r, idx) => (msg += `     ${idx + 1}. ${r}\n`))
      msg += `\n`
    })

    await wafproject.sendMessage(
      m.chat,
      { text: msg, mentions: users.map(u => u.jid) },
      { quote: m }
    )
  } catch (e) {
    console.error('WARNLIST ERROR:', e?.message || e)
    return m.reply(`❌ Error: ${e?.message || e}`)
  }
}

handler.help = ['listwarn', 'warnlist']
handler.category = ['admin']
handler.command = ['listwarn', 'warnlist']
handler.group = true
handler.admin = true
handler.register = true
handler.limit = false

module.exports = handler