// ✨ Plugin Tag Admin (.tagmin / .tagadmin) + Nama Pemanggil + Cooldown 10 Menit (FINAL) ✨
// Global AntiLID / JidNormalizer

const COOLDOWN_MS = 10 * 60 * 1000 // 10 menit

const phrases = [
  "woi min, {name} ada yang cariin 😤",
  "admin sayang, {name} ada yang nyariin nih 😚",
  "min, {name} butuh bantuan nih 😭",
  "permisi admin, {name} manggil 🙏",
  "minnn, {name} minta merapat bentar 😅",
  "admin, {name} ngehubungin kalian nih 👀",
  "min, {name} urgent dikit boleh? 🥺",
  "admin baik, {name} nyariin 😄",
  "woi admin, {name} minta tolong 😤",
  "min, {name} nungguin respon 😭"
]

const cooldownReplies = [
  "Udah tunggu aja ya, jangan spam tag. Nanti admin marah 😤",
  "Sabar dikit, jangan di-tag terus. Admin bisa kesel 😅",
  "Pelan-pelan dong, jangan spam tag admin 😤",
  "Tunggu ya, admin pasti respon. Jangan diburu-buru 😄"
]

const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)]

// =================== NORMALIZER (FULL pakai global antiLID) ===================
function normJid(jid) {
  try {
    if (typeof global.normalizeJid === "function") return String(global.normalizeJid(jid) || "")
    if (typeof global.jidNormalized === "function") return String(global.jidNormalized(jid) || "")
    if (global.JidNormalizer && typeof global.JidNormalizer.normalize === "function") {
      return String(global.JidNormalizer.normalize(jid) || "")
    }
  } catch (_error) { console.error("[ERROR][commands/group/tagadmin.js]", _error?.message || _error) }
  return String(jid || "").replace(/:[0-9]+/g, "").trim()
}

function cleanName(name) {
  return String(name || "Seseorang")
    .replace(/[*_`~]/g, "")
    .replace(/\s+/g, " ")
    .trim() || "Seseorang"
}

async function getSenderName(wafproject, m) {
  const sender = normJid(m?.sender || m?.participant || m?.key?.participant || "")

  const local = m?.pushName || m?.name || m?.notify || ""
  if (local && String(local).trim()) return cleanName(local)

  try {
    if (sender && typeof wafproject.getName === "function") {
      const n = await wafproject.getName(sender)
      if (n && String(n).trim()) return cleanName(n)
    }
  } catch (_error) { console.error("[ERROR][commands/group/tagadmin.js]", _error?.message || _error) }

  const num = sender ? sender.split("@")[0] : ""
  return cleanName(num || "Seseorang")
}

async function getGroupMeta(wafproject, m, ctxMeta) {
  if (ctxMeta?.participants?.length) return ctxMeta
  try {
    if (typeof wafproject.groupMetadata === "function") {
      const meta = await wafproject.groupMetadata(m.chat)
      if (meta?.participants?.length) return meta
    }
  } catch (_error) { console.error("[ERROR][commands/group/tagadmin.js]", _error?.message || _error) }
  return null
}

function getAdminJidsFromMeta(groupMetadata) {
  const parts = groupMetadata?.participants || []
  const set = new Set()

  for (const p of parts) {
    const isAdmin =
      p?.admin === "admin" ||
      p?.admin === "superadmin" ||
      p?.isAdmin === true ||
      p?.isSuperAdmin === true

    if (!isAdmin) continue
    const jid = normJid(p?.id || p?.jid || p?.participant || "")
    if (jid) set.add(jid)
  }
  return [...set]
}

function getCmdName(m) {
  const t = String(m?.text || "").trim()
  const first = t.split(/\s+/)[0] || ""
  return first.toLowerCase()
}

const handler = async (m, { wafproject, groupMetadata }) => {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return m.reply?.("Khusus grup ya.")

    const cmd = getCmdName(m)
    const cmdKey =
      cmd === ".tagadmin" || cmd === "tagadmin"
        ? "tagadmin"
        : cmd === ".tagmin" || cmd === "tagmin"
          ? "tagmin"
          : "tagadmin"

    // =================== COOLDOWN (per chat per cmd) ===================
    wafproject._tagAdminCooldown = wafproject._tagAdminCooldown || {}
    wafproject._tagAdminCooldown[m.chat] = wafproject._tagAdminCooldown[m.chat] || {}
    const last = wafproject._tagAdminCooldown[m.chat][cmdKey] || 0

    const now = Date.now()
    if (now - last < COOLDOWN_MS) {
      return m.reply?.(pickRandom(cooldownReplies))
    }

    const meta = await getGroupMeta(wafproject, m, groupMetadata)
    if (!meta) return m.reply?.("Gagal ambil data grup.")

    const admins = getAdminJidsFromMeta(meta)
    if (!admins.length) return m.reply?.("Admin grup tidak ditemukan.")

    const senderName = await getSenderName(wafproject, m)

    // optional alasan: .tagmin ada yang spam
    const reason = String((m.text || "").trim()).split(/\s+/).slice(1).join(" ").trim()

    const header = pickRandom(phrases).replaceAll("{name}", senderName)
    const adminMentions = admins.map((jid) => `@${jid.split("@")[0]}`).join(" ")

    const text = reason
      ? `${header}\nAlasan: ${reason}\n${adminMentions}`
      : `${header}\n${adminMentions}`

    await wafproject.sendMessage(
      m.chat,
      { text, mentions: admins },
      { quote: m }
    )

    // set cooldown setelah sukses kirim
    wafproject._tagAdminCooldown[m.chat][cmdKey] = now
  } catch {
    try { m.reply?.("Error.") } catch (_error) { console.error("[ERROR][commands/group/tagadmin.js]", _error?.message || _error) }
  }
}

handler.help = ["tagmin", "tagadmin"]
handler.category = ["group"]
handler.command = /^(\.?(tagmin|tagadmin))$/i
handler.group = true

module.exports = handler