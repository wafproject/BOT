let handler = async (m, { wafproject, usedPrefix, command, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('❌ Command ini khusus grup.')
  if (!isAdmin && !isOwner) return m.reply('❌ Khusus admin grup.')

  const react = async (emoji) => {
    try { await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch (_error) { console.error("[ERROR][commands/group/getppgc.js]", _error?.message || _error) }
  }

  try {
    await react('🕒')

    // ambil URL pp grup (Zapo)
    let ppUrl = null
    try {
      ppUrl = await wafproject.profilePictureUrl(m.chat, 'image')
    } catch {
      // fallback: beberapa base cukup tanpa type
      ppUrl = await wafproject.profilePictureUrl(m.chat).catch(() => null)
    }

    if (!ppUrl) {
      await react('❌')
      return m.reply('❌ Foto grup tidak ditemukan / belum ada.')
    }

    await wafproject.sendMessage(
      m.chat,
      { image: { url: ppUrl }, caption: `✅ Foto profil grup\n${m.chat}` },
      { quote: m }
    )

    await react('✅')
  } catch (e) {
    console.error('GETPPGC ERROR:', e?.message || e)
    await react('❌')
    return m.reply(`❌ Error: ${e?.message || e}`)
  }
}

handler.help = ['getppgc']
handler.category = ['admin']
handler.command = ['getppgc']
handler.group = true
handler.admin = true
handler.register = true

module.exports = handler
