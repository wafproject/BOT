/**
 * Anti Delete dengan cache pesan di ./temp
 * FINAL FIX:
 * - Mention/tag FIX: resolve @lid/internal -> jid asli (clickable)
 * - Media format sama
 * - Hanya berlaku jika penghapus NON-ADMIN
 * - Auto clear cache (hapus cache setelah dipakai) + cleanup berkala
 * - Tampilan rapi (Pesan : sebaris, tanpa enter)
 *
 * Tampilan:
 * ⚠️ *Pesan Dihapus Terdeteksi!*
 * • Pengirim : 62xxxx
 * • Nama : ...
 * • Pesan : ...
 * > Fitur antidelete aktif! .off antidelete untuk mematikan (Admin Only)
 */

const fs = require('fs')
const fsPromises = require('fs/promises')
const path = require('path')
const { downloadContentFromMessage } = require('../../lib/zapo-adapter.js')

const { TEMP_DIR: TMP_DIR } = require('../../lib/project-paths')

// ================== INIT TEMP DIR ==================
async function ensureTmpDir() {
  await fsPromises.mkdir(TMP_DIR, { recursive: true })
  await fsPromises.access(TMP_DIR, fs.constants.W_OK | fs.constants.R_OK)
}

// override: global.antidel_keep_days = 7
function getKeepDays() {
  const n = parseInt(global.antidel_keep_days)
  return Number.isFinite(n) && n > 0 ? n : 2
}

function startCleanupJob() {
  if (global.__antidel_cleanup_started) return
  global.__antidel_cleanup_started = true

  setInterval(async () => {
    try {
      const keepMs = getKeepDays() * 24 * 60 * 60 * 1000
      const files = await fsPromises.readdir(TMP_DIR)
      const now = Date.now()

      for (const file of files) {
        if (!file.startsWith('pesan_sementara_')) continue
        const filePath = path.join(TMP_DIR, file)

        let data
        try {
          data = JSON.parse(await fsPromises.readFile(filePath, 'utf8'))
        } catch {
          continue
        }

        if (!data?.timestamp) continue
        if (now - data.timestamp <= keepMs) continue

        await fsPromises.unlink(filePath).catch(() => {})
        if (data.mediaFilePath) await fsPromises.unlink(data.mediaFilePath).catch(() => {})
      }
    } catch (e) {
      console.error('Gagal membersihkan temp:', e)
    }
  }, 6 * 60 * 60 * 1000)
}

if (!global.__antidel_init_promise) {
  global.__antidel_init_promise = (async () => {
    try {
      await ensureTmpDir()
      startCleanupJob()
      return true
    } catch (e) {
      console.error('AntiDelete init error:', e)
      return false
    }
  })()
}

// ================== helper (file naming) ==================
const safeName = (s) => String(s || '').replace(/[^0-9A-Za-z_.-]/g, '_')

function cacheJsonPath(chatId, messageId) {
  const safeChatId = safeName(chatId)
  const safeMsgId = safeName(messageId)
  const fileName = `pesan_sementara_${safeChatId}_${safeMsgId}.json`
  return path.join(TMP_DIR, fileName)
}

async function deleteCache(chatId, messageId) {
  try {
    const filePath = cacheJsonPath(chatId, messageId)
    let data = null
    try {
      data = JSON.parse(await fsPromises.readFile(filePath, 'utf8'))
    } catch {
      data = null
    }

    await fsPromises.unlink(filePath).catch(() => {})
    if (data?.mediaFilePath) await fsPromises.unlink(data.mediaFilePath).catch(() => {})
  } catch (_error) { console.error("[ERROR][commands/group/antidelete.js]", _error?.message || _error) }
}

function getMsgId(m) {
  return m?.key?.id || m?.id || ''
}

// ================== ADMIN/ID NORMALIZER (SAMAIN STYLE) ==================
const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function jidNum(j = '') {
  return String(j || '').split('@')[0].replace(/\D/g, '')
}

/**
 * Resolver: handle
 * - jid normal
 * - @lid
 * - internal numeric id (mis: 1203...) dicocokkan ke participants[].lid
 */
function resolveToRealJidFromMeta(inputJid, meta) {
  if (!inputJid || !meta?.participants) return inputJid

  const inStr = String(inputJid)
  const inNorm = normalizeJid(inStr)
  const inNum = jidNum(inStr)
  const parts = meta.participants || []

  // 1) match langsung ke participant jid/id
  const direct = parts.find((p) => sameJid(resolveParticipantJid(p), inNorm))
  if (direct) return resolveParticipantJid(direct) || inputJid

  // 2) kalau @lid
  if (inStr.endsWith('@lid')) {
    const hit = parts.find((p) => String(p.lid || p.id || '') === inStr)
    if (hit) return resolveParticipantJid(hit) || inputJid
  }

  // 3) numeric match ke LID (fix utama 1203... => 62...)
  const byLidNum = parts.find((p) => {
    const lid = p.lid || ''
    const lidNum = jidNum(lid)
    return lidNum && lidNum === inNum
  })
  if (byLidNum) return resolveParticipantJid(byLidNum) || inputJid

  // 4) fallback: numeric match ke jid/id participant
  const byIdNum = parts.find((p) => {
    const pj = resolveParticipantJid(p)
    const pjNum = jidNum(pj)
    return pjNum && pjNum === inNum
  })
  if (byIdNum) return resolveParticipantJid(byIdNum) || inputJid

  return inputJid
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try { meta = await wafproject.groupMetadata(chatJid) } catch { meta = null }
    if (!meta) return { isAdmin: false, meta: null }

    const participants = meta.participants || []
    const senderFixed = resolveToRealJidFromMeta(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, meta }
  } catch {
    return { isAdmin: false, meta: null }
  }
}

// ================== MENTION HELPER (FIX CLICKABLE) ==================
function toRealMentionJid(jid, meta) {
  if (!jid) return ''

  let j = String(jid)
  j = resolveToRealJidFromMeta(j, meta) // lid/internal -> jid asli
  j = normalizeJid(j) // normalize device suffix

  if (!j.includes('@')) j = j + '@s.whatsapp.net'
  if (j.endsWith('@g.us')) return ''
  return j
}

function buildUserTag(jid, meta) {
  const real = toRealMentionJid(jid, meta)
  if (!real) return { tag: '@user', mentions: [], real: '' }
  return { tag: '@' + real.split('@')[0], mentions: [real], real }
}

function numberOnly(jid = '') {
  return String(jid || '').split('@')[0]
}

// ================== cache save/load ==================
async function saveMessageToTmp(chatId, messageId, messageData) {
  try {
    const safeChatId = safeName(chatId)
    const safeMsgId = safeName(messageId)
    if (!safeChatId || !safeMsgId) return

    const filePath = cacheJsonPath(chatId, messageId)
    let mediaFilePath = null

    const messageType = Object.keys(messageData.message || {})[0]

    if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(messageType)) {
      const mediaMsg = messageData.message[messageType]
      try {
        const stream = await downloadContentFromMessage(mediaMsg, messageType.replace('Message', ''))
        const chunks = []
        for await (const chunk of stream) chunks.push(chunk)
        const buffer = Buffer.concat(chunks)

        const ext =
          messageType === 'stickerMessage'
            ? 'webp'
            : (mediaMsg.mimetype?.split('/')[1] || 'bin')

        mediaFilePath = path.join(TMP_DIR, `media_${safeChatId}_${safeMsgId}.${ext}`)
        await fsPromises.writeFile(mediaFilePath, buffer)
      } catch {
        mediaFilePath = null
      }
    }

    const safeMessage = JSON.parse(
      JSON.stringify(messageData, (key, value) => {
        if (key === 'buffer' || key === 'stream') return undefined
        return value
      })
    )

    await fsPromises.writeFile(
      filePath,
      JSON.stringify({ ...safeMessage, mediaFilePath, timestamp: Date.now() }, null, 2)
    )
  } catch (e) {
    console.error('Gagal menyimpan pesan ke temp:', e)
  }
}

async function getMessageFromTmp(chatId, messageId) {
  try {
    const filePath = cacheJsonPath(chatId, messageId)
    const data = await fsPromises.readFile(filePath, 'utf8')
    return JSON.parse(data)
  } catch {
    return null
  }
}

async function fileExists(p) {
  if (!p) return false
  try {
    await fsPromises.access(p)
    return true
  } catch {
    return false
  }
}

// ================== output helpers ==================
function buildHeaderClassic(pengirimNumber, nama) {
  return (
    `⚠️ *Pesan Dihapus Terdeteksi!*\n` +
    `• Pengirim : ${pengirimNumber || '-'}\n` +
    `• Nama : ${nama || '-'}\n` +
    `• Pesan : `
  )
}

function buildFooter() {
  return `\n> Fitur antidelete aktif! .off antidelete untuk mematikan (Admin Only)`
}

function cleanOneLineText(t = '') {
  return String(t || '').replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim()
}

// ========== PLUGIN HOOK ==========
const handler = (m) => m

handler.before = async function (m, { wafproject, db, isOwner }) {
  try {
    if (!m || !wafproject) return
    if (m.fromMe) return
    if (!m.isGroup) return
    if (!m.message) return
    if (m.messageStubType) return

    const ok = await global.__antidel_init_promise
    if (!ok) return

    const root = db?.list ? db.list() : {}
    root.group ||= {}
    const chat = root.group[m.chat] || (root.group[m.chat] = {})

    // 1) cache semua pesan saat ON
    if (chat.antiDelete) {
      if (!m.message.protocolMessage) {
        const msgId = getMsgId(m)
        if (msgId) await saveMessageToTmp(m.chat, msgId, m)
      }
    }

    // 2) deteksi revoke
    if (!chat.antiDelete) return
    const pm = m.message?.protocolMessage
    if (!pm || pm.type !== 0) return

    const key = pm.key || {}
    const deletedMsgId = key.id
    if (!deletedMsgId) return

    // actor penghapus = m.sender
    const deleter = m.sender

    // owner delete => bot diam
    if (isOwner) return

    // ambil meta + cek admin deleter
    const { isAdmin: isDeleterAdmin, meta } = await getAdminStatus(wafproject, m.chat, deleter)
    if (isDeleterAdmin) return

    // original sender (yang punya pesan)
    const originalSenderRaw = key.participant || deleter
    const { mentions, real: originalRealJid } = buildUserTag(originalSenderRaw, meta)

    // nomor pengirim: selalu dari jid asli kalau kebaca
    const pengirimNumber = originalRealJid ? numberOnly(originalRealJid) : numberOnly(originalSenderRaw)

    // ambil cache
    const cachedMsg = await getMessageFromTmp(m.chat, deletedMsgId)

    // ambil nama (kalau ada)
    const nama = cachedMsg?.pushName || ''

    // cache kosong
    if (!cachedMsg || !cachedMsg.message) {
      const msgText =
        buildHeaderClassic(pengirimNumber, nama) +
        `⚠️ Pesan tidak ditemukan di cache (mungkin bot restart / cache dibersihkan).` +
        buildFooter()

      await wafproject.sendMessage(m.chat, { text: msgText, mentions }, { quote: m })
      await deleteCache(m.chat, deletedMsgId)
      return
    }

    const messageType = Object.keys(cachedMsg.message)[0] || ''

    // ===== TEXT =====
    if (messageType === 'conversation' || messageType === 'extendedTextMessage') {
      const rawText =
        cachedMsg.message.conversation ||
        cachedMsg.message.extendedTextMessage?.text ||
        ''

      const txt = cleanOneLineText(rawText) || '(teks kosong / tidak terbaca)'

      const pretty =
        buildHeaderClassic(pengirimNumber, nama) +
        txt +
        buildFooter()

      await wafproject.sendMessage(
        m.chat,
        { text: pretty, mentions },
        { quote: m, mentions, forward: { score: 500 } }
      )

      await deleteCache(m.chat, deletedMsgId)
      return
    }

    // ===== MEDIA =====
    if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(messageType)) {
      const mediaMsg = cachedMsg.message[messageType] || {}
      const mediaPath = cachedMsg.mediaFilePath
      const exist = await fileExists(mediaPath)

      const mediaLabel = `[MEDIA: ${messageType.replace('Message', '').toUpperCase()}]`
      const headerLine = buildHeaderClassic(pengirimNumber, nama) + mediaLabel + buildFooter()

      if (!exist) {
        await wafproject.sendMessage(
          m.chat,
          { text: buildHeaderClassic(pengirimNumber, nama) + `⚠️ Media tidak dapat diteruskan (file tidak ditemukan).` + buildFooter(), mentions },
          { quote: m }
        )
        await deleteCache(m.chat, deletedMsgId)
        return
      }

      const stream = fs.createReadStream(mediaPath)

      if (messageType === 'imageMessage') {
        const cap = mediaMsg.caption ? `\n\n${cleanOneLineText(mediaMsg.caption)}` : ''
        await wafproject.sendMessage(
          m.chat,
          { image: stream, caption: headerLine + cap, mentions },
          { quote: m, mentions, forward: { score: 500 } }
        )
      } else if (messageType === 'videoMessage') {
        const cap = mediaMsg.caption ? `\n\n${cleanOneLineText(mediaMsg.caption)}` : ''
        await wafproject.sendMessage(
          m.chat,
          { video: stream, caption: headerLine + cap, mentions },
          { quote: m, mentions, forward: { score: 500 } }
        )
      } else if (messageType === 'documentMessage') {
        const cap = mediaMsg.caption ? `\n\n${cleanOneLineText(mediaMsg.caption)}` : ''
        await wafproject.sendMessage(
          m.chat,
          {
            document: stream,
            mimetype: mediaMsg.mimetype,
            fileName: mediaMsg.fileName || 'file',
            caption: headerLine + cap,
            mentions
          },
          { quote: m, mentions, forward: { score: 500 } }
        )
      } else if (messageType === 'audioMessage') {
        await wafproject.sendMessage(m.chat, { text: headerLine, mentions }, { quote: m })
        await wafproject.sendMessage(
          m.chat,
          { audio: stream, mimetype: mediaMsg.mimetype || 'audio/mpeg', ptt: !!mediaMsg.ptt },
          { quote: m, forward: { score: 500 } }
        )
      } else if (messageType === 'stickerMessage') {
        await wafproject.sendMessage(m.chat, { text: headerLine, mentions }, { quote: m })
        await wafproject.sendMessage(
          m.chat,
          { sticker: stream },
          { quote: m, forward: { score: 500 } }
        )
      }

      await deleteCache(m.chat, deletedMsgId)
      return
    }

    // ===== UNSUPPORTED =====
    await wafproject.sendMessage(
      m.chat,
      {
        text:
          buildHeaderClassic(pengirimNumber, nama) +
          `⚠️ Jenis pesan tidak didukung (Tipe: ${messageType}).` +
          buildFooter(),
        mentions
      },
      { quote: m }
    )

    await deleteCache(m.chat, deletedMsgId)
  } catch (e) {
    console.error('Error in antidelete:', e)
    try {
      await wafproject.sendMessage(m.chat, { text: `⚠️ *Error AntiDelete* ⚠️\n${e.message}` })
    } catch (_error) { console.error("[ERROR][commands/group/antidelete.js]", _error?.message || _error) }
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // hook only
module.exports = handler