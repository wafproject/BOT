// ✨ Plugin bot - AFK (Canonical JID, LID SAFE, anti spam) ✨

let handler = async (m, { text, wafproject }) => {
  global.db = global.db || {}
  global.db.data = global.db.data || {}
  global.db.data.chats = global.db.data.chats || {}

  let chat = global.db.data.chats[m.chat] || {}
  chat.afk = chat.afk || {}
  global.db.data.chats[m.chat] = chat

  // ✅ resolve sender ke JID asli (biar key AFK selalu benar)
  const senderReal = await resolveToRealJid(wafproject, m, m.sender)
  if (!senderReal || !String(senderReal).endsWith("@s.whatsapp.net")) return

  const sender = normJid(senderReal)

  // kalau sudah AFK, jangan spam (jangan kirim lagi)
  if (chat.afk[sender]) return

  chat.afk[sender] = {
    time: Date.now(),
    reason: text || "",
  }

  let ppUrl = global.thumb
  try {
    if (typeof wafproject?.profilePictureUrl === "function") {
      ppUrl = await wafproject.profilePictureUrl(sender, "image")
    }
  } catch (_error) { console.error("[ERROR][commands/group/afk.js]", _error?.message || _error) }

  const userName = getNameSafe(wafproject, sender, m)
  const alasan = text?.trim() ? text.trim() : "nggak ada alasan… mysteriooo~"

  const msg =
    `🚧 *${userName} MODE HILANG* 🚧\n\n` +
    `Ssst… dia AFK dulu ya.\n` +
    `Jangan dipanggil, nanti dia tambah hilang 🫠\n\n` +
    `– 👤 Nama: ${userName}\n` +
    `– 📝 Alasan: ${alasan}`

  if (typeof wafproject.sendRichPreview === "function") {
    await wafproject.sendRichPreview(
      m.chat,
      {
        text: msg,
        title: "🚫 PENGGUNA SEDANG AFK",
        body: "Ssst… jangan dipanggil dulu 🥷",
        thumbnailUrl: ppUrl,
        mediaType: 1,
        renderLargerThumbnail: false,
      },
      { quote: m, mentions: [sender] }
    )
  } else {
    await wafproject.sendMessage(m.chat, { text: msg, mentions: [sender] }, { quote: m, mentions: [sender] })
  }
}

handler.help = ["afk <alasan>"]
handler.category = ["group"]
handler.command = /^afk$/i
handler.group = true
handler.register = true

module.exports = handler

// =================== HELPERS ===================
function normJid(id) {
  return String(id || "").replace(/:.*@/, "@").trim()
}

function getNameSafe(wafproject, jid, m) {
  try {
    if (wafproject && typeof wafproject.getName === "function") {
      const n = wafproject.getName(jid)
      if (n) return n
    }
  } catch (_error) { console.error("[ERROR][commands/group/afk.js]", _error?.message || _error) }
  try {
    const c = wafproject?.contacts?.[jid]
    const n = c?.name || c?.notify || c?.verifiedName
    if (n) return n
  } catch (_error) { console.error("[ERROR][commands/group/afk.js]", _error?.message || _error) }
  return m?.pushName || "Pengguna"
}

// ✅ LID -> JID asli (persis gaya addprem)
async function resolveToRealJid(wafproject, m, rawJid) {
  if (!rawJid) return null
  const s = String(rawJid)
  if (s.endsWith("@s.whatsapp.net")) return s
  if (!m.isGroup) return s

  let meta
  try {
    meta = await wafproject.groupMetadata(m.chat)
  } catch {
    return s
  }

  const participants = meta?.participants || []
  const found = participants.find(p =>
    p?.lid === s ||
    p?.id === s ||
    p?.jid === s ||
    p?.participant === s
  )

  return found?.jid || found?.id || found?.participant || s
}