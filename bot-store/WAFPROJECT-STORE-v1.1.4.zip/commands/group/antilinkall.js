/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur: Anti Link All (blokir semua link)
📌 Toggle via: .on antilinkall / .off antilinkall
========================
*/

const LINK_ALL_REGEX = /(https?:\/\/[^\s]+|www\.[^\s]+)/i
const WA_GROUP_REGEX = /chat\.whatsapp\.com\/[0-9A-Za-z]{20,24}/i

// ===== ADMIN READER (SAMAKAN PERSIS) =====
const normalizeJid = (j = '') => String(j || '').replace(/:.*@/, '@').trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ''
  try { return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw } catch { return raw }
}

const isAdminFlag = (p) =>
  !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || ''
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith('@lid') && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? (p.jid || p.id) : id
  }
  return id
}

const handler = (m) => m

handler.all = async function (m, { wafproject, db, isOwner }) {
  try {
    if (!m || !m.chat) return
    if (!m.isGroup) return
    if (m.fromMe) return

    // Ambil text (caption juga biar tembus link di foto/video)
    const text =
      (m.text ||
        m.message?.conversation ||
        m.message?.extendedTextMessage?.text ||
        m.message?.imageMessage?.caption ||
        m.message?.videoMessage?.caption ||
        '').trim()

    if (!text) return

    // DB WAF
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    const chat = root.group[m.chat] || (root.group[m.chat] = {})

    // fitur aktif?
    if (!chat.antiLinkAll) return

    // kalau ga ada link, skip
    if (!LINK_ALL_REGEX.test(text)) return

    // kalau link grup WA & antilink khusus aktif -> biarin antilink.js
    if (WA_GROUP_REGEX.test(text) && chat.antiLink) return

    // ==== CEK ADMIN/BOT ADMIN (PERSIS GAYA KAMU) ====
    let meta = null
    try { meta = await wafproject.groupMetadata(m.chat) } catch { meta = null }
    if (!meta) return

    const participants = meta.participants || []

    const botJid = getBotJid(wafproject)
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderJid = resolveLidToJid(m.sender, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderJid))
    const isAdmin = isAdminFlag(senderPart)

    // owner/admin bebas
    if (isOwner || isAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '🛡️ *ANTILINKALL (ADMIN/OWNER)*\n' +
            `@${m.sender.split('@')[0]} mengirim link.\n` +
            'Karena kamu admin/owner, link dibiarkan.',
          mentions: [m.sender]
        },
        { quote: m }
      )
      return
    }

    // bot bukan admin
    if (!isBotAdmin) {
      await wafproject.sendMessage(
        m.chat,
        {
          text:
            '⚠️ *ANTILINKALL AKTIF*\n' +
            `@${m.sender.split('@')[0]} mengirim link.\n` +
            'Tapi bot bukan admin, jadi tidak bisa hapus.',
          mentions: [m.sender]
        },
        { quote: m }
      )
      return
    }

    // delete pesan
    try {
      // paling aman pake delete m.key
      await wafproject.sendMessage(m.chat, { delete: m.key })
    } catch (_error) { console.error("[ERROR][commands/group/antilinkall.js]", _error?.message || _error) }

    // warning
    await wafproject.sendMessage(
      m.chat,
      {
        text:
          '🚫 *ANTILINKALL*\n' +
          `Link dari @${m.sender.split('@')[0]} sudah dihapus.\n` +
          'Semua link tidak diperbolehkan di grup ini.',
        mentions: [m.sender]
      },
      { quote: m }
    )
  } catch (e) {
    console.error('antilinkall error:', e)
  }
}

handler.help = []
handler.tags = []
handler.command = [] // bukan command
module.exports = handler