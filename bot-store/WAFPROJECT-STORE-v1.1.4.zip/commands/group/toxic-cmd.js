/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Command Toxic: addtoxic / deltoxic / listtoxic
========================
*/

const fs = require('fs')
const path = require('path')

// lokasi penyimpanan (TIDAK DIUBAH)
const toxicDbPath = path.join(process.cwd(), 'lib', 'datatoxic.json')

// ===== init file =====
function ensureToxicDb() {
  try {
    const dir = path.dirname(toxicDbPath)
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

    if (!fs.existsSync(toxicDbPath)) {
      fs.writeFileSync(toxicDbPath, JSON.stringify([], null, 2))
      return
    }

    const raw = fs.readFileSync(toxicDbPath, 'utf8')
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) fs.writeFileSync(toxicDbPath, JSON.stringify([], null, 2))
  } catch {
    try { fs.writeFileSync(toxicDbPath, JSON.stringify([], null, 2)) } catch (_error) { console.error("[ERROR][commands/group/toxic-cmd.js]", _error?.message || _error) }
  }
}

function loadToxicWords() {
  ensureToxicDb()
  try {
    const raw = fs.readFileSync(toxicDbPath, 'utf8')
    const arr = JSON.parse(raw)
    return Array.isArray(arr) ? arr.map(v => String(v).toLowerCase()).filter(Boolean) : []
  } catch {
    return []
  }
}

function saveToxicWords(words) {
  ensureToxicDb()
  fs.writeFileSync(toxicDbPath, JSON.stringify(words, null, 2))
}

// =================== COMMAND HANDLER ===================
let handler = async (m, { wafproject, usedPrefix, text, command, isOwner }) => {
  const cmd = String(command || '').toLowerCase()
  let toxicWords = loadToxicWords()

  const send = (txt) => wafproject.sendMessage(m.chat, { text: String(txt) }, { quote: m })

  // ===== LIST =====
  if (cmd === 'listtoxic') {
    if (!toxicWords.length) {
      return send(`⚠️ Belum ada kata toxic di database.\nTambah pakai *${usedPrefix}addtoxic* dulu.`)
    }
    const list = toxicWords.slice().sort((a, b) => a.localeCompare(b)).map(w => `• ${w}`).join('\n')
    return send(`📜 *Daftar kata toxic:*\n\n${list}`)
  }

  // ===== ADD =====
  if (cmd === 'addtoxic') {
    if (!isOwner) return send('🚫 Maaf, cuma *Owner* yang bisa nambah kata toxic!')
    if (!text) return send(`Masukkan kata.\nContoh: *${usedPrefix}${cmd} jelek*`)

    const newWord = text.trim().toLowerCase()
    if (!newWord) return send('❌ Kata tidak boleh kosong.')
    if (toxicWords.includes(newWord)) return send(`⚠️ Kata *${newWord}* sudah ada.`)

    toxicWords.push(newWord)
    saveToxicWords(toxicWords)
    return send(`✅ Kata *${newWord}* berhasil ditambah!`)
  }

  // ===== DEL =====
  if (cmd === 'deltoxic') {
    if (!isOwner) return send('🚫 Maaf, cuma *Owner* yang bisa hapus kata toxic!')
    if (!text) return send(`Masukkan kata.\nContoh: *${usedPrefix}${cmd} jelek*`)

    const wordToDelete = text.trim().toLowerCase()
    const idx = toxicWords.indexOf(wordToDelete)
    if (idx === -1) return send(`❌ Kata *${wordToDelete}* tidak ada.\nCek: *${usedPrefix}listtoxic*`)

    toxicWords.splice(idx, 1)
    saveToxicWords(toxicWords)
    return send(`🗑️ Kata *${wordToDelete}* berhasil dihapus!`)
  }
}

handler.help = ['listtoxic', 'addtoxic', 'deltoxic']
handler.category = ['admin']
handler.command = /^(listtoxic|addtoxic|deltoxic)$/i
handler.group = true

module.exports = handler