// ✨ Plugin group - listafk (LID SAFE) ✨
// - .listafk -> list user yang sedang AFK di grup ini

let handler = async (m, { wafproject }) => {
  try {
    if (!m.isGroup) return

    global.db = global.db || {}
    global.db.data = global.db.data || {}
    global.db.data.chats = global.db.data.chats || {}

    const chat = (global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {})
    chat.afk = chat.afk || {}

    const entries = Object.entries(chat.afk || {})
      .filter(([jid, v]) => jid && v && typeof v === "object" && v.time)

    if (!entries.length) return m.reply("😴 Lagi sepi... *gak ada yang AFK* di grup ini.")

    // urutkan paling lama AFK dulu
    entries.sort((a, b) => (a[1].time || 0) - (b[1].time || 0))

    // cache list biar .delafk nomor bisa akurat
    setAfkListCache(wafproject, m.chat, entries.map(v => v[0]))

    const now = Date.now()
    const mentions = []
    let out = `📋 *LIST AFK (${entries.length})*\n`
    out += `_(ketik .delafk nomor untuk hapus)_\n\n`

    out += entries.map(([jid, info], i) => {
      const real = String(jid)
      const num = (real.includes("@") ? real.split("@")[0] : real).replace(/[^0-9]/g, "") || real
      const name = getNameSafe(wafproject, real, num)
      const since = formatDuration(now - (info.time || now))
      const reason = info.reason?.trim() ? info.reason.trim() : "tanpa alasan… sok misterius 😶‍🌫️"

      if (real.endsWith("@s.whatsapp.net")) mentions.push(real)

      return (
        `${i + 1}. *${name}* ${real.endsWith("@s.whatsapp.net") ? `(@${num})` : ""}\n` +
        `   ⏱️ AFK: *${since}*\n` +
        `   📝 Alasan: _${reason}_`
      )
    }).join("\n\n")

    await wafproject.sendMessage(
      m.chat,
      { text: out.trim(), mentions },
      { quote: m }
    )
  } catch (e) {
    return m.reply("❌ Gagal ambil list AFK.")
  }
}

handler.help = ["listafk"]
handler.category = ["group"]
handler.command = /^listafk$/i
handler.group = true
handler.register = true
handler.limit = false

module.exports = handler

// =================== CACHE (RAM) ===================
function getCacheRoot(wafproject) {
  wafproject._afkListCache = wafproject._afkListCache || {}
  return wafproject._afkListCache
}
function setAfkListCache(wafproject, chatId, arr) {
  const root = getCacheRoot(wafproject)
  root[chatId] = { ts: Date.now(), list: Array.isArray(arr) ? arr : [] }
}

function getNameSafe(wafproject, jid, fallbackNum) {
  try {
    if (wafproject && typeof wafproject.getName === "function") {
      const n = wafproject.getName(jid)
      if (n) return n
    }
  } catch (_error) { console.error("[ERROR][commands/group/listafk.js]", _error?.message || _error) }
  try {
    const c = wafproject?.contacts?.[jid]
    const n = c?.name || c?.notify || c?.verifiedName
    if (n) return n
  } catch (_error) { console.error("[ERROR][commands/group/listafk.js]", _error?.message || _error) }
  return fallbackNum ? `User ${fallbackNum}` : "Pengguna"
}

function formatDuration(ms) {
  if (!ms || ms < 0) ms = 0
  const s = Math.floor(ms / 1000)
  const m = Math.floor(s / 60)
  const h = Math.floor(m / 60)
  const d = Math.floor(h / 24)

  const hh = h % 24
  const mm = m % 60
  const ss = s % 60

  const out = []
  if (d) out.push(`${d} hari`)
  if (hh) out.push(`${hh} jam`)
  if (mm) out.push(`${mm} menit`)
  if (!out.length) out.push(`${ss} detik`)
  return out.join(" ")
}