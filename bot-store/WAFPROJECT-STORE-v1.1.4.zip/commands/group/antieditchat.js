/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 Fitur: Anti Edit Chat (Anti-Edit) — WAF CJS (FINAL FIX)
✅ FIX UTAMA:
- Base kamu TIDAK memanggil handler.before untuk hook-only (command = [])
- Jadi cache HARUS pakai handler.all (dipanggil untuk semua pesan)
- Deteksi edit tetap lewat router: messages.upsert -> processEditFromUpsert
========================
*/

const fs = require('fs')
const fsPromises = require('fs/promises')
const path = require('path')
const { downloadContentFromMessage } = require('../../lib/zapo-adapter.js')

const { TEMP_DIR: TMP_DIR } = require('../../lib/project-paths')

// ===== utils =====
const safeName = (s) => String(s || '').replace(/[^0-9A-Za-z_.-]/g, '_')
const delay = (ms) => new Promise((r) => setTimeout(r, ms))

function getMsgId(m) {
  return m?.key?.id || m?.id || ''
}

function cachePath(chatId, msgId) {
  return path.join(TMP_DIR, `edit_${safeName(chatId)}_${safeName(msgId)}.json`)
}

async function ensureDir() {
  await fsPromises.mkdir(TMP_DIR, { recursive: true })
  await fsPromises.access(TMP_DIR, fs.constants.W_OK | fs.constants.R_OK)
}

function startCleaner() {
  if (global.__antiedit_cleaner_started) return
  global.__antiedit_cleaner_started = true

  const maxAge = 2 * 24 * 60 * 60 * 1000 // 2 hari

  setInterval(async () => {
    try {
      const files = await fsPromises.readdir(TMP_DIR)
      const now = Date.now()

      for (const f of files) {
        if (!f.startsWith('edit_')) continue
        const fp = path.join(TMP_DIR, f)

        let data
        try { data = JSON.parse(await fsPromises.readFile(fp, 'utf8')) } catch { continue }
        if (!data?.timestamp) continue
        if (now - data.timestamp <= maxAge) continue

        await fsPromises.unlink(fp).catch(() => {})
        if (data.mediaPath) await fsPromises.unlink(data.mediaPath).catch(() => {})
      }
    } catch (e) {
      console.error('Cleaner antiedit error:', e)
    }
  }, 6 * 60 * 60 * 1000)
}

if (!global.__antiedit_init_promise) {
  global.__antiedit_init_promise = (async () => {
    try {
      await ensureDir()
      startCleaner()
      return true
    } catch (e) {
      console.error('AntiEdit init error:', e)
      return false
    }
  })()
}

// ===== unwrap message (ephemeral/viewonce/etc) =====
function unwrapMessage(message) {
  let m = message
  for (let i = 0; i < 6; i++) {
    if (!m) break
    if (m.ephemeralMessage?.message) m = m.ephemeralMessage.message
    else if (m.viewOnceMessage?.message) m = m.viewOnceMessage.message
    else if (m.viewOnceMessageV2?.message) m = m.viewOnceMessageV2.message
    else if (m.editedMessage?.message) m = m.editedMessage.message
    else if (m.protocolMessage?.editedMessage) m = m.protocolMessage.editedMessage
    else break
  }
  return m
}

function pickInnerMessage(msg = {}) {
  return unwrapMessage(msg) || msg
}

// ===== save/load/delete cache =====
async function saveMessage(chatId, msgId, msg) {
  try {
    if (!chatId || !msgId) return

    const filePath = cachePath(chatId, msgId)
    let mediaPath = null

    const inner = pickInnerMessage(msg.message || {})
    const type = Object.keys(inner || {})[0]

    if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(type)) {
      const media = inner[type]
      try {
        const stream = await downloadContentFromMessage(media, type.replace('Message', ''))
        const chunks = []
        for await (const ch of stream) chunks.push(ch)
        const buffer = Buffer.concat(chunks)

        const ext =
          type === 'stickerMessage'
            ? 'webp'
            : (media?.mimetype?.split('/')[1] || 'bin')

        mediaPath = path.join(TMP_DIR, `media_${safeName(chatId)}_${safeName(msgId)}.${ext}`)
        await fsPromises.writeFile(mediaPath, buffer)
      } catch {
        mediaPath = null
      }
    }

    const safe = JSON.parse(
      JSON.stringify(msg, (k, v) => {
        if (k === 'buffer' || k === 'stream') return undefined
        return v
      })
    )

    await fsPromises.writeFile(
      filePath,
      JSON.stringify({ ...safe, mediaPath, timestamp: Date.now() }, null, 2)
    )
  } catch (e) {
    console.error('Gagal simpan pesan sebelum edit:', e)
  }
}

async function getOld(chatId, msgId) {
  try {
    const fp = cachePath(chatId, msgId)
    return JSON.parse(await fsPromises.readFile(fp, 'utf8'))
  } catch {
    return null
  }
}

async function deleteCache(chatId, msgId) {
  try {
    const fp = cachePath(chatId, msgId)

    let data = null
    try { data = JSON.parse(await fsPromises.readFile(fp, 'utf8')) } catch { data = null }

    await fsPromises.unlink(fp).catch(() => {})
    if (data?.mediaPath) await fsPromises.unlink(data.mediaPath).catch(() => {})
  } catch (_error) { console.error("[ERROR][commands/group/antieditchat.js]", _error?.message || _error) }
}

function readText(msg = {}) {
  const inner = pickInnerMessage(msg)
  const t = Object.keys(inner || {})[0]
  if (!t) return ''
  if (t === 'conversation') return inner.conversation || ''
  if (t === 'extendedTextMessage') return inner.extendedTextMessage?.text || ''
  if (t === 'imageMessage') return inner.imageMessage?.caption || ''
  if (t === 'videoMessage') return inner.videoMessage?.caption || ''
  if (t === 'documentMessage') return inner.documentMessage?.caption || ''
  return ''
}

function describe(msg = {}) {
  const inner = pickInnerMessage(msg)
  const t = Object.keys(inner || {})[0]
  if (!t) return '(tidak terbaca)'

  const txt = readText(inner)
  if (t === 'conversation' || t === 'extendedTextMessage') return txt || '(teks kosong)'

  if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(t)) {
    const cap = txt ? ` | caption: ${txt}` : ''
    return `[Media: ${t.replace('Message', '').toUpperCase()}]${cap}`
  }

  return `[${t}]`
}

/**
 * ✅ Processor edit: dipanggil dari router (messages.upsert)
 * @param {object} wafproject
 * @param {object} db
 * @param {object} m  -> pesan dari messages.upsert
 */
async function processEditFromUpsert(wafproject, db, m) {
  try {
    if (!m?.message?.protocolMessage) return
    const pm = m.message.protocolMessage

    // WhatsApp protocol edit: type 14
    if (pm.type !== 14) return

    const key = pm.key || {}
    const chatId = key.remoteJid || m.key?.remoteJid
    if (!chatId || !String(chatId).endsWith('@g.us')) return

    // cek toggle
    const root = db?.list ? db.list() : {}
    root.group ||= {}
    const chat = root.group[chatId] || (root.group[chatId] = {})
    if (!chat.antiEditChat) return

    const msgId = key.id
    if (!msgId) return

    // siapa yang edit
    const editor = key.participant || m.key?.participant || m.participant || m.key?.remoteJid

    // konten baru (struktur beda-beda tergantung payload WhatsApp)
    let newContent = null
    if (pm.editedMessage?.message) newContent = pm.editedMessage.message
    else if (pm.editedMessage) newContent = pm.editedMessage
    else if (m.message?.editedMessage?.message) newContent = m.message.editedMessage.message
    else if (m.message?.editedMessage) newContent = m.message.editedMessage
    else newContent = null

    const old = await getOld(chatId, msgId)
    const before = old?.message ? describe(old.message) : 'Tidak ditemukan (cache kosong / bot restart)'
    const after = newContent ? describe(newContent) : 'Konten baru tidak terbaca (struktur berbeda)'

    const text =
      `‼️ *PESAN DIEDIT TERDETEKSI!*\n` +
      `• Pengirim: @${String(editor || '').split('@')[0]}\n` +
      `• Sebelum: ${before}\n` +
      `• Sesudah: ${after}\n\n` +
      `> Anti edit chat aktif! .off antieditchat untuk mematikan (Admin Only)`

    await wafproject.sendMessage(chatId, { text, mentions: editor ? [editor] : [] })

    // auto clear cache pesan itu
    await deleteCache(chatId, msgId)
    await delay(50)
  } catch (e) {
    console.error('processEditFromUpsert error:', e)
  }
}

// =========================
// HANDLER (cache only)
// ✅ PENTING: base kamu panggil plugin.all untuk semua pesan,
// jadi caching HARUS di all, bukan before.
// =========================
const handler = (m) => m

handler.all = async function (m, { wafproject, db }) {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (!m.message) return
    if (m.messageStubType) return

    const ok = await global.__antiedit_init_promise
    if (!ok) return

    const root = db?.list ? db.list() : {}
    root.group ||= {}
    const chat = root.group[m.chat] || (root.group[m.chat] = {})
    if (!chat.antiEditChat) return

    // cache pesan normal (bukan protocol)
    if (!m.message.protocolMessage) {
      const id = getMsgId(m)
      if (id) await saveMessage(m.chat, id, m)
    }
  } catch (e) {
    console.error('antiedit.all error:', e)
  }
}

handler.help = ['']
handler.category = ['group']
handler.command = [] // hook only

// ✅ export processor untuk router
handler.processEditFromUpsert = processEditFromUpsert

module.exports = handler