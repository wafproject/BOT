/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
 */

/*
plugins/group - hidetag.js (CJS)
✨ Hidetag (mention semua member) + dukung media

Aturan caption:
1) Kirim media dengan perintah (.h) TANPA teks  → media-only.
2) Reply ke media yang ada caption, kirim .h TANPA teks → pakai caption aslinya.
3) Kirim .h diikuti teks → teks itu dipakai sebagai caption.
*/

const { downloadContentFromMessage } = require('../../lib/zapo-adapter.js')

async function plugin(m, { wafproject, text, participants, isAdmin, isOwner }) {
  // Hanya di grup & admin/owner
  if (!m.isGroup) return wafproject.sendMessage(m.chat, { text: 'Fitur ini khusus di grup.' }, { quote: m })
  if (!(isAdmin || isOwner)) return wafproject.sendMessage(m.chat, { text: 'Hanya admin/owner yang bisa memakai perintah ini.' }, { quote: m })

  // ====== kumpulkan target mention (PASTIKAN JID) ======
  let targets = []
  try {
    if (Array.isArray(participants) && participants.length) {
      targets = participants
        .map(p => p?.id || p?.jid) // JANGAN p.user
        .filter(Boolean)
    } else {
      const meta = await wafproject.groupMetadata(m.chat)
      targets = (meta?.participants || []).map(p => p?.id || p?.jid).filter(Boolean)
    }
  } catch {
    targets = []
  }

  const argText = String(text || '').trim()

  // ====== helper unwrap wrapper (ephemeral/view once) ======
  const unwrap = (obj) => {
    // obj bisa: wrapper message / m / m.quoted / raw
    let msg = obj?.message || obj?.msg || obj

    // kalau masih ada .message di dalam (beberapa base nyelip)
    if (msg?.message) msg = msg.message

    if (!msg) return { inner: null, type: null }

    // unwrap wrapper WhatsApp Proto
    if (msg.ephemeralMessage?.message) msg = msg.ephemeralMessage.message
    if (msg.viewOnceMessageV2?.message) msg = msg.viewOnceMessageV2.message
    if (msg.viewOnceMessage?.message) msg = msg.viewOnceMessage.message

    const type = msg && Object.keys(msg)[0]
    return { inner: msg, type }
  }

  const mediaTypeMap = (type) => {
    if (type === 'imageMessage') return 'image'
    if (type === 'videoMessage') return 'video'
    if (type === 'audioMessage') return 'audio'
    if (type === 'documentMessage') return 'document'
    if (type === 'stickerMessage') return 'sticker'
    return null
  }

  const hasMedia = (obj) => {
    const { type } = unwrap(obj)
    return !!mediaTypeMap(type)
  }

  // download media paling kompatibel
  const downloadMedia = async (src) => {
    // 1) kalau base punya src.download()
    try {
      if (typeof src?.download === 'function') {
        const b = await src.download()
        if (b) return b
      }
    } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }

    // 2) stream media Zapo
    try {
      const { inner, type } = unwrap(src)
      const mt = mediaTypeMap(type)
      if (!inner || !type || !mt) return null

      const node = inner[type]
      if (!node) return null

      const stream = await downloadContentFromMessage(node, mt)
      let buf = Buffer.alloc(0)
      for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
      return buf.length ? buf : null
    } catch {
      return null
    }
  }

  const getMime = (src) => {
    const { inner, type } = unwrap(src)
    const node = inner?.[type] || {}
    return node?.mimetype || ''
  }

  const getDocMeta = (src) => {
    const { inner, type } = unwrap(src)
    const node = inner?.[type] || {}
    return {
      mimetype: node?.mimetype,
      fileName: node?.fileName,
      ptt: node?.ptt
    }
  }

  // ====== pilih sumber media: reply > pesan sendiri ======
  const fromQuoted = !!(m.quoted && hasMedia(m.quoted))
  const fromSelf = !fromQuoted && hasMedia(m)
  const src = fromQuoted ? m.quoted : (fromSelf ? m : null)

  // ====== caption sesuai aturan ======
  let caption = ''
  if (fromQuoted) {
    caption = argText || (m.quoted?.text || m.quoted?.caption || '')
  } else if (fromSelf) {
    caption = argText || '' // kosong → media-only
  } else {
    caption = argText || (m.quoted?.text || m.quoted?.caption || '')
  }

  // Zapo: mention dikirim lewat send options, bukan contextInfo legacy.
  const sendOpts = { quote: m, mentions: targets }

  try {
    // ========= ada media =========
    if (src) {
      const { type } = unwrap(src)
      const mime = getMime(src)

      // IMAGE
      if (type === 'imageMessage' || /image\//i.test(mime)) {
        const buf = await downloadMedia(src)
        if (!buf) return wafproject.sendMessage(m.chat, { text: 'Gagal mengambil gambar.' }, { quote: m })

        const sent = await wafproject.sendMessage(
          m.chat,
          { image: buf, ...(caption ? { caption } : {}) },
          sendOpts
        )
        try { if (sent?.key) await wafproject.sendMessage(m.chat, { react: { text: '📢', key: sent.key } }) } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }
        return
      }

      // VIDEO
      if (type === 'videoMessage' || /video\//i.test(mime)) {
        const buf = await downloadMedia(src)
        if (!buf) return wafproject.sendMessage(m.chat, { text: 'Gagal mengambil video.' }, { quote: m })

        const sent = await wafproject.sendMessage(
          m.chat,
          { video: buf, ...(caption ? { caption } : {}) },
          sendOpts
        )
        try { if (sent?.key) await wafproject.sendMessage(m.chat, { react: { text: '📢', key: sent.key } }) } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }
        return
      }

      // STICKER
      if (type === 'stickerMessage') {
        const buf = await downloadMedia(src)
        if (!buf) return wafproject.sendMessage(m.chat, { text: 'Gagal mengambil stiker.' }, { quote: m })

        const sent = await wafproject.sendMessage(
          m.chat,
          { sticker: buf },
          sendOpts
        )
        try { if (sent?.key) await wafproject.sendMessage(m.chat, { react: { text: '📢', key: sent.key } }) } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }
        return
      }

      // DOCUMENT
      if (type === 'documentMessage' || /application\//i.test(mime)) {
        const buf = await downloadMedia(src)
        if (!buf) return wafproject.sendMessage(m.chat, { text: 'Gagal mengambil dokumen.' }, { quote: m })

        const meta = getDocMeta(src)
        const sent = await wafproject.sendMessage(
          m.chat,
          {
            document: buf,
            mimetype: meta?.mimetype || 'application/octet-stream',
            fileName: meta?.fileName || 'file',
            ...(caption ? { caption } : {})
          },
          sendOpts
        )
        try { if (sent?.key) await wafproject.sendMessage(m.chat, { react: { text: '📢', key: sent.key } }) } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }
        return
      }

      // AUDIO
      if (type === 'audioMessage' || /audio\//i.test(mime)) {
        const buf = await downloadMedia(src)
        if (!buf) return wafproject.sendMessage(m.chat, { text: 'Gagal mengambil audio.' }, { quote: m })

        const meta = getDocMeta(src)
        const sent = await wafproject.sendMessage(
          m.chat,
          {
            audio: buf,
            mimetype: meta?.mimetype || 'audio/mpeg',
            ptt: !!meta?.ptt
          },
          sendOpts
        )
        try { if (sent?.key) await wafproject.sendMessage(m.chat, { react: { text: '📢', key: sent.key } }) } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }
        return
      }

      // fallback → kirim teks saja
      const sent = await wafproject.sendMessage(m.chat, { text: caption || ' ' }, sendOpts)
      try { if (sent?.key) await wafproject.sendMessage(m.chat, { react: { text: '📢', key: sent.key } }) } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }
      return
    }

    // ========= tidak ada media =========
    if (!caption) {
      return wafproject.sendMessage(
        m.chat,
        { text: 'Ketik teks setelah perintah, atau reply/kirim media lalu ketik .h' },
        { quote: m }
      )
    }

    const sent = await wafproject.sendMessage(m.chat, { text: caption }, sendOpts)
    try { if (sent?.key) await wafproject.sendMessage(m.chat, { react: { text: '📢', key: sent.key } }) } catch (_error) { console.error("[ERROR][commands/group/hidetag.js]", _error?.message || _error) }
  } catch (e) {
    console.error('hidetag error:', e)
    return wafproject.sendMessage(m.chat, { text: 'Gagal mengirim hidetag.' }, { quote: m })
  }
}

plugin.help = ['h', 'hidetag']
plugin.category = ['admin']
plugin.command = /^(h|hidetag)$/i
plugin.group = true
plugin.admin = true
plugin.limit = false

module.exports = plugin