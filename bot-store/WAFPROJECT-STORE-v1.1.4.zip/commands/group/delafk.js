// ✨ Plugin group - delafk nomor (LID SAFE + via cache listafk) ✨
// - .delafk 1  -> hapus AFK sesuai urutan listafk terakhir di chat ini

let handler = async (m, { wafproject, text, isAdmin, isOwner }) => {
  try {
    if (!m.isGroup) return

    // ✅ keamanan: hanya admin/owner
    if (!(isAdmin || isOwner)) return

    const idx = parseInt(String(text || "").trim(), 10)
    if (!Number.isFinite(idx) || idx < 1) {
      return m.reply("📌 Format: *.delafk nomor*\nContoh: *.delafk 1*")
    }

    global.db = global.db || {}
    global.db.data = global.db.data || {}
    global.db.data.chats = global.db.data.chats || {}

    const chat = (global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {})
    chat.afk = chat.afk || {}

    const cache = getAfkListCache(wafproject, m.chat)
    if (!cache || !Array.isArray(cache.list) || cache.list.length === 0) {
      return m.reply("⚠️ Cache kosong.\nKetik dulu: *.listafk*")
    }

    if (idx > cache.list.length) {
      return m.reply(`⚠️ Nomor tidak valid.\nRange: 1-${cache.list.length}`)
    }

    const targetKey = cache.list[idx - 1]
    const info = chat.afk[targetKey]
    if (!info) {
      return m.reply("⚠️ Data AFK target sudah hilang / berubah.\nCoba *.listafk* lagi.")
    }

    delete chat.afk[targetKey]

    const num = String(targetKey).split("@")[0].replace(/[^0-9]/g, "") || String(targetKey)
    const alasan = info.reason?.trim() ? info.reason.trim() : "tanpa alasan"

    await wafproject.sendMessage(
      m.chat,
      {
        text:
          `🧹 *AFK dihapus!*\n\n` +
          `Target: ${String(targetKey).endsWith("@s.whatsapp.net") ? `@${num}` : `*${num}*`}\n` +
          `Alasan AFK tadi: _${alasan}_\n\n` +
          `Sekarang dia dianggap *sudah waras* lagi 😌`,
        mentions: String(targetKey).endsWith("@s.whatsapp.net") ? [targetKey] : []
      },
      { quote: m }
    )
  } catch (e) {
    return m.reply("❌ Gagal hapus AFK.")
  }
}

handler.help = ["delafk <nomor>"]
handler.category = ["admin"]
handler.command = /^delafk$/i
handler.group = true
handler.admin = true
handler.register = true
handler.limit = false

module.exports = handler

// =================== CACHE (RAM) ===================
function getCacheRoot(wafproject) {
  wafproject._afkListCache = wafproject._afkListCache || {}
  return wafproject._afkListCache
}
function getAfkListCache(wafproject, chatId) {
  const root = getCacheRoot(wafproject)
  return root[chatId] || null
}