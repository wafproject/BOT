// commands/group/ceksewa.js
// ✨ Plugin group - ceksewa ✨ (CJS)
// - Hanya bisa dipakai di DALAM GRUP
// - Hanya ADMIN GRUP yang boleh pakai (user biasa bot DIAM)
// - Baca DB sewa: database/sewa.json
// - Tampilkan habis (WIB) + sisa (hari, jam, menit)

const { readSewaResult, updateSewa } = require('../../lib/sewa-store')

// ---------- util ----------
const norm = j => String(j || '').replace(/:[0-9]+/g, '').trim()
const same = (a, b) => norm(a) === norm(b)

// ---------- deteksi admin ----------
function getPid(p) {
  return norm(p?.id || p?.jid || p?.participant || p?.user || '')
}
function isAdminFlag(p) {
  const role = (p?.role || p?.admin || '').toString().toLowerCase()
  if (role === 'admin' || role === 'superadmin') return true
  if (p?.isAdmin === true || p?.isSuperAdmin === true) return true
  if (p?.admin === true) return true
  return false
}

function withTimeout(promise, timeoutMs, fallback = null) {
  let timer
  return Promise.race([
    Promise.resolve(promise),
    new Promise(resolve => { timer = setTimeout(() => resolve(fallback), timeoutMs) })
  ]).finally(() => clearTimeout(timer))
}

async function ensureMeta(wafproject, chatId, meta) {
  if (meta && Array.isArray(meta.participants) && meta.participants.length) return meta
  try { return await withTimeout(wafproject.groupMetadata(chatId), 2500, meta || null) } catch { return meta || null }
}

async function isSenderAdmin(wafproject, chatId, senderJid, meta) {
  const m2 = await ensureMeta(wafproject, chatId, meta)
  if (!m2) return { ok: false, meta: null }
  const parts = m2.participants || []
  const me = parts.find(p => same(getPid(p), senderJid))
  return { ok: !!(me && isAdminFlag(me)), meta: m2 }
}

// ---------- format ----------
function formatTanggalWIB(ms) {
  const d = new Date(ms)
  const opt = {
    timeZone: 'Asia/Jakarta',
    weekday: 'long',
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  }
  return new Intl.DateTimeFormat('id-ID', opt).format(d)
}

function formatJamWIB(ms) {
  const d = new Date(ms)
  const opt = {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }
  return new Intl.DateTimeFormat('id-ID', opt).format(d).replace(':', '.')
}

function dhm(ms) {
  const dMs = 24 * 60 * 60 * 1000
  const hMs = 60 * 60 * 1000
  const mMs = 60 * 1000
  const d = Math.floor(ms / dMs)
  const h = Math.floor((ms % dMs) / hMs)
  const m = Math.floor((ms % hMs) / mMs)
  return { d, h, m }
}

// reply aman
async function safeReply(wafproject, m, text) {
  try {
    if (typeof m.reply === 'function') return await m.reply(text)
  } catch (_error) { console.error("[ERROR][commands/group/ceksewa.js]", _error?.message || _error) }
  try {
    return await wafproject.sendMessage(m.chat, { text: String(text) }, { quote: m })
  } catch (_error) { console.error("[ERROR][commands/group/ceksewa.js]", _error?.message || _error) }
}

// ---------- cari data grup di DB (FIX UTAMA) ----------
function findGroupKey(dbObj, chatId) {
  const keys = Object.keys(dbObj || {})
  if (!keys.length) return null

  // 1) coba exact
  if (dbObj[chatId]) return chatId

  // 2) coba norm exact
  const n = norm(chatId)
  if (dbObj[n]) return n

  // 3) scan key yang match (paling aman)
  return keys.find(k => same(k, chatId)) || keys.find(k => same(k, n)) || null
}

// ---------- handler ----------
const handler = async (m, { wafproject, isAdmin, groupMetadata }) => {
  try {
    if (!m?.isGroup) return // kalau bukan grup: DIAM

    const sender = norm(m.sender || m.participant || m.key?.participant || '')
    let adminOK = !!isAdmin

    if (!adminOK) {
      const res = await isSenderAdmin(wafproject, m.chat, sender, groupMetadata)
      adminOK = res.ok
      groupMetadata = res.meta || groupMetadata
    }

    // user biasa: bot DIAM
    if (!adminOK) return

    const read = readSewaResult({ allowCached: false })
    if (!read.ok) {
      console.error('[ceksewa] database read error:', read.error?.message || read.error)
      return safeReply(wafproject, m, '❌ Database sewa sedang bermasalah. Coba lagi nanti.')
    }
    const dbSewa = read.data

    // ✅ FIX: cari key yang cocok, bukan db[m.chat] doang
    const gidKey = findGroupKey(dbSewa, m.chat)
    const info = gidKey ? dbSewa[gidKey] : null

    if (!info) return safeReply(wafproject, m, '❌ Grup ini *tidak terdaftar* dalam sewa bot.')

    const now = Date.now()
    const expired = Number(info.expired || 0)
    const sisa = expired - now

    if (!expired || sisa <= 0) {
      if (gidKey) {
        try {
          await updateSewa((data) => {
            if (Number(data?.[gidKey]?.expired || 0) <= Date.now()) delete data[gidKey]
          })
        } catch (error) {
          console.error('[ceksewa] cleanup expired error:', error?.message || error)
        }
      }
      return safeReply(wafproject, m, '⏰ Masa sewa untuk grup ini *sudah habis*.')
    }

    // nama grup
    let subject = info.name || 'Unknown'
    try {
      const meta = await ensureMeta(wafproject, m.chat, groupMetadata)
      subject = meta?.subject || subject
    } catch (_error) { console.error("[ERROR][commands/group/ceksewa.js]", _error?.message || _error) }

    const { d, h, m: mm } = dhm(sisa)
    const tgl = formatTanggalWIB(expired)
    const jam = formatJamWIB(expired)

    const garis = '──────────────────'
    const teks =
`⏱️ *STATUS SEWA BOT*
${garis}
📌 *Grup:* ${subject}
📅 *Habis pada:* ${tgl}
🕒 *Pukul:* ${jam} WIB
⌛ *Sisa:* ${d} hari, ${h} jam, ${mm} menit
${garis}
😇 *Terima kasih telah menggunakan layanan bot kami!*`

    return safeReply(wafproject, m, teks)
  } catch (e) {
    console.error('[ceksewa] error:', e)
    try {
      if (m?.isGroup && (isAdmin === true)) await safeReply(wafproject, m, '❌ Terjadi kesalahan di fitur *ceksewa*.')
    } catch (_error) { console.error("[ERROR][commands/group/ceksewa.js]", _error?.message || _error) }
  }
}

handler.help = ['ceksewa']
handler.category = 'group'
handler.command = ['ceksewa']
handler.group = true
handler.admin = false
handler.owner = false
handler.limit = false

module.exports = handler