/**
========================
🚀 WAF PROJECT - LINK GC
========================
 */

let handler = async (m, { wafproject }) => {
  try {
    if (!m.isGroup) {
      return wafproject.sendMessage(m.chat, { text: '🚩 Fitur ini hanya untuk grup.' })
    }

    // Ambil metadata grup
    let meta = await wafproject.groupMetadata(m.chat).catch(() => null)
    let subject = meta?.subject || 'Grup Ini'

    // Ambil kode invite
    let code = await wafproject.groupInviteCode(m.chat)
    let link = 'https://chat.whatsapp.com/' + code

    // Kirim pesan TANPA m.reply untuk menghindari contextInfo error
    await wafproject.sendMessage(m.chat, {
      text:
`🔗 *LINK GRUP*

🏷 Nama : *${subject}*
🌐 Link : ${link}`
    })

  } catch (e) {
    console.error('ERROR LINKGC:', e)
    await wafproject.sendMessage(m.chat, { text: '⚠️ Gagal mengambil link grup!' })
  }
}

handler.help = ['linkgc', 'linkgroup', 'invite']
handler.category = ['admin']
handler.command = /^(linkgc?|linkgroup|invite)$/i

handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler