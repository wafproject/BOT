const { nativeFlowMessage, quickReplyButton } = require('../../lib/zapo-message')
// plugins/register.js
// .daftar -> kirim konfirmasi + tombol Setuju/Batal
// tombol: .daftar_acc / .daftar_cancel

function waNumber(jid = "") {
  return String(jid || "").split("@")[0]
}

module.exports = async function (m, { wafproject, db, command, usedPrefix }) {
  if (!["daftar", "daftar_acc", "daftar_cancel"].includes(command)) return

  const root = db.list()
  root.user ||= {}

  const prefix = usedPrefix || "."

  const user = (root.user[m.sender] ||= {
    exp: 0,
    limit: 20,
    lastLimitReset: "",
    money: 0,
    premium: false,
    registered: false,
    regDate: 0,
    name: m.pushName || "Unknown",
  })

  if (typeof user.pendingRegister === "undefined") user.pendingRegister = null
  if (typeof user.registered === "undefined") user.registered = false
  if (typeof user.regDate === "undefined") user.regDate = 0
  if (typeof user.name === "undefined") user.name = m.pushName || "Unknown"

  // =========================
  // .daftar
  // =========================
  if (command === "daftar") {
    if (user.registered) {
      const t = user.regDate
        ? new Date(user.regDate).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
        : "-"
      return m.reply(
        `✅ Kamu sudah terdaftar.\n` +
        `• Username: ${user.name || "-"}\n` +
        `• Tanggal: ${t}`
      )
    }

    user.pendingRegister = {
      nomor: waNumber(m.sender),
      jid: m.sender,
      username: m.pushName || "Unknown",
      ts: Date.now(),
    }
    await db.save()

    // ✅ TEMPLATE REGISTER (STYLE TEMPLATE 2)
    const textMsg =
      `✅ *KONFIRMASI PENDAFTARAN*\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `📱 *Informasi Akun*\n` +
      `• Nomor WA : ${user.pendingRegister.nomor}\n` +
      `• JID      : ${user.pendingRegister.jid}\n` +
      `• Username : ${user.pendingRegister.username}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📌 *Catatan*\n` +
      `• Dengan mendaftar, kamu bisa memakai fitur yang membutuhkan akun\n` +
      `• Data pendaftaran akan tersimpan di sistem bot\n` +
      `• Kamu bisa unreg kapan saja jika ingin berhenti\n\n` +
      `👉 Silakan pilih:`

    return wafproject.sendMessage(
      m.chat,
      nativeFlowMessage({
        text: textMsg,
        footer: "Konfirmasi tindakan kamu",
        buttons: [
          quickReplyButton("✅ Setuju", `${prefix}daftar_acc`),
          quickReplyButton("❌ Batal", `${prefix}daftar_cancel`),
        ],
      }),
      { quote: m }
    )
  }

  // =========================
  // .daftar_acc
  // =========================
  if (command === "daftar_acc") {
    if (user.registered) return m.reply("✅ Kamu sudah terdaftar.")
    if (!user.pendingRegister) {
      return m.reply(`⚠️ Tidak ada pendaftaran yang pending.\nKetik ${prefix}daftar dulu.`)
    }

    user.registered = true
    user.regDate = Date.now()
    user.name = user.pendingRegister.username || (m.pushName || "Unknown")
    user.pendingRegister = null

    await db.save()
    return m.reply("✅ Pendaftaran berhasil. Selamat datang!")
  }

  // =========================
  // .daftar_cancel
  // =========================
  if (command === "daftar_cancel") {
    if (!user.pendingRegister) return m.reply("⚠️ Tidak ada pendaftaran yang pending.")
    user.pendingRegister = null
    await db.save()
    return m.reply("❌ Pendaftaran dibatalkan.")
  }
}

// MENU: karena menu.js kamu ambil dari help, cukup tampilkan "daftar"
module.exports.help = ["daftar"]
module.exports.category = "main"
module.exports.description = "Daftar akun bot (dengan konfirmasi)"

// command internal tetap ada, tapi tidak akan muncul di menu (karena help cuma 'daftar')
module.exports.command = ["daftar", "daftar_acc", "daftar_cancel"]