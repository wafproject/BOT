// ✨ Plugin Anti Tag Owner (FINAL - Pakai Global AntiLID / JidNormalizer) ✨

/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const COOLDOWN_MS = 25 * 1000

// Template harus nyambung setelah: "Woiii *Nama*, ..."
const replies = [
  "jangan seenaknya tag ownerku 😡",
  "kalau mau tag owner, sopan dulu. Jangan asal 😠",
  "owner lagi sibuk. Kalau perlu, chat baik-baik 😤",
  "jangan cuma tag doang. Izin dulu sebelum panggil owner 😡",
  "jangan sembarangan tag ownerku 😠",
  "tag owner itu pakai etika. Jangan bikin rame 😤",
  "kalau ada urusan, jelasin baik-baik. Jangan main tag 😡",
  "minimal salam dan izin dulu kalau mau tag owner 😠",
  "sekali lagi ya, jangan asal tag owner. Paham? 😤",
  "butuh bantuan? Tulis yang jelas. Jangan langsung tag owner 😡"
]

const openers = ["Woiii", "Woy", "Oi", "Eh", "Heh", "Bro", "Bang", "Kak", "Hallo", "Sini"]

const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)]

// =================== NORMALIZER (FULL pakai global antiLID) ===================
// Plugin ini akan pakai normalizer global kamu kalau tersedia.
// Urutan fallback (biar kompatibel dengan berbagai base):
// 1) global.normalizeJid(jid)
// 2) global.jidNormalized(jid)
// 3) global.JidNormalizer.normalize(jid)
// 4) fallback lokal: hapus device id ":1234" + trim
function normJid(jid) {
  try {
    if (typeof global.normalizeJid === 'function') return String(global.normalizeJid(jid) || '')
    if (typeof global.jidNormalized === 'function') return String(global.jidNormalized(jid) || '')
    if (global.JidNormalizer && typeof global.JidNormalizer.normalize === 'function') {
      return String(global.JidNormalizer.normalize(jid) || '')
    }
  } catch (_error) { console.error("[ERROR][commands/main/antitagowner.js]", _error?.message || _error) }
  return String(jid || '').replace(/:[0-9]+/g, '').trim()
}

function toJid(numOrJid) {
  const x = String(numOrJid || '').trim()
  if (!x) return ''
  if (x.includes('@')) return normJid(x)
  const num = x.replace(/\D/g, '')
  return num ? normJid(`${num}@s.whatsapp.net`) : ''
}

// =================== OWNER LIST ===================
function getOwnerJids() {
  const owners = global.owner || global.owners || []
  const set = new Set()
  for (const o of owners) {
    const v = Array.isArray(o) ? o[0] : o
    const jid = toJid(v)
    if (jid) set.add(jid)
  }
  return [...set]
}

// =================== GET TEXT ===================
function getText(m) {
  return String(
    m?.text ??
      m?.body ??
      m?.message?.conversation ??
      m?.message?.extendedTextMessage?.text ??
      ''
  ).trim()
}

// =================== GET MENTIONS (jid/lid/anything -> normalize global) ===================
function getMentionsAny(m) {
  const set = new Set()

  const ctx =
    m?.message?.extendedTextMessage?.contextInfo ||
    m?.message?.imageMessage?.caption?.contextInfo ||
    m?.message?.videoMessage?.caption?.contextInfo ||
    null

  const a = ctx?.mentionedJid || []
  for (const j of a) {
    const nj = normJid(j)
    if (nj) set.add(nj)
  }

  const b = m?.mentionedJid || m?.mentions || []
  for (const j of b) {
    const nj = normJid(j)
    if (nj) set.add(nj)
  }

  // kalau ngetik @628xxx (bukan mention)
  const text = getText(m)
  const reg = /@(\d{5,20})/g
  let mm
  while ((mm = reg.exec(text))) {
    const nj = normJid(`${mm[1]}@s.whatsapp.net`)
    if (nj) set.add(nj)
  }

  return [...set]
}

// =================== @Nama TEXT DETECTOR ===================
function extractAtTokens(text) {
  const set = new Set()
  const reg = /@([A-Za-z0-9._-]{2,32})/g
  let m
  while ((m = reg.exec(text))) {
    const t = String(m[1] || '').replace(/\s+/g, '').trim().toLowerCase()
    if (t) set.add(t)
  }
  return [...set]
}

function cleanName(name) {
  return String(name || 'Seseorang')
    .replace(/[*_`~]/g, '')
    .replace(/\s+/g, ' ')
    .trim() || 'Seseorang'
}

async function getSenderName(conn, m) {
  const sender = normJid(m?.sender || m?.participant || m?.key?.participant || '')

  const local = m?.pushName || m?.name || m?.notify || ''
  if (local && String(local).trim()) return cleanName(local)

  try {
    if (sender && typeof conn.getName === 'function') {
      const n = await conn.getName(sender)
      if (n && String(n).trim()) return cleanName(n)
    }
  } catch (_error) { console.error("[ERROR][commands/main/antitagowner.js]", _error?.message || _error) }

  const num = sender ? sender.split('@')[0] : ''
  return cleanName(num || 'Seseorang')
}

// =================== MAIN ===================
async function core(m, { conn, groupMetadata }) {
  try {
    if (!m || !conn) return
    if (!m.isGroup) return
    if (m.fromMe) return
    if (m.fromMe) return

    const ownerJids = getOwnerJids().map(normJid).filter(Boolean)
    if (!ownerJids.length) return

    // cooldown per chat
    conn._antiTagOwner = conn._antiTagOwner || {}
    const last = conn._antiTagOwner[m.chat] || 0
    if (Date.now() - last < COOLDOWN_MS) return

    const ownersSet = new Set(ownerJids)

    // 1) Mention beneran (sudah dinormalize global)
    const mentions = getMentionsAny(m)
    let hit = mentions.find(j => ownersSet.has(j))

    // 2) Kalau cuma ngetik "@Nama ..." (tanpa mention)
    if (!hit) {
      const text = getText(m)
      if (text) {
        const tokens = extractAtTokens(text)
        if (tokens.length) {
          // ambil alias nama owner dari metadata participant
          const metaParts = groupMetadata?.participants || []
          const aliasSet = new Set()

          for (const p of metaParts) {
            const pid = normJid(p?.id || p?.jid || p?.participant || '')
            if (!pid || !ownersSet.has(pid)) continue

            const nm =
              p?.notify ||
              p?.name ||
              p?.pushName ||
              p?.verifiedName ||
              p?.displayName ||
              ''

            const clean = String(nm || '')
              .replace(/\s+/g, '')
              .replace(/^@+/, '')
              .trim()
              .toLowerCase()

            if (clean) aliasSet.add(clean)
          }

          if (aliasSet.size) {
            const found = tokens.find(t => aliasSet.has(t))
            if (found) hit = found
          }
        }
      }
    }

    if (!hit) return

    // set cooldown
    conn._antiTagOwner[m.chat] = Date.now()

    const senderName = await getSenderName(conn, m)
    const msg = `${pickRandom(openers)} ${senderName}, ${pickRandom(replies)}`

    await conn.sendMessage(m.chat, { text: msg }, { quote: m })
  } catch (_error) { console.error("[ERROR][commands/main/antitagowner.js]", _error?.message || _error) }
}

// supaya jalan di berbagai loader
const handler = async (m, ctx) => core(m, ctx)
handler.before = async (m, ctx) => core(m, ctx)
handler.all = async (m, ctx) => core(m, ctx)
handler.command = new RegExp('^$', 'i')

module.exports = handler