// commands/store/store-status.js
// ✨ Store - status transaksi (proses/done) + REACT ✅/⏳ ✨ (CommonJS)
// RULES:
// ✅ .p/.proses & .d/.done WAJIB reply pesan
// ✅ Jika tidak reply → BOT DIAM
// ✅ Jika bukan admin/owner → BOT DIAM
// ✅ Mention target = user pemilik pesan target (quoted / reacted message)
// ✅ Bot mengirim status dengan mereply pesan target (pakai contextInfo quotedMessage, BUKAN quoted:key)
// ✅ Cache max 200 pesan / grup untuk fitur react ambil "Pesanan"

const fs = require("fs")
const fsp = fs.promises
const path = require("path")

// ===================== DB PATH =====================
const { databaseFile } = require('../../lib/project-paths')
const STORE_PATH = databaseFile('databaseStore.json')
const DB_DIR = path.dirname(STORE_PATH)
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true })

async function readJsonSafe(p) {
  try {
    await fsp.mkdir(path.dirname(p), { recursive: true })
    return JSON.parse(await fsp.readFile(p, "utf8"))
  } catch (error) {
    if (error?.code !== "ENOENT") console.error("[STORE-STATUS DB] read:", error?.message || error)
    return {}
  }
}
async function writeJsonSafe(p, data) {
  try {
    await fsp.mkdir(path.dirname(p), { recursive: true })
    await fsp.writeFile(p, JSON.stringify(data, null, 2), "utf8")
    return true
  } catch (error) {
    console.error("[STORE-STATUS DB] write:", error?.message || error)
    return false
  }
}

let storeDatabase = {}
const saveStoreDatabase = () => writeJsonSafe(STORE_PATH, storeDatabase)

// ===================== DEFAULT TEMPLATE =====================
const DEFAULT_PROSES = [
  "「 *TRANSAKSI DI PROSES* 」",
  "",
  "📅 *TANGGAL :* {tanggal}",
  "⌚ *JAM     :* {jam}",
  "✨ *STATUS  :* {status}",
  "",
  "📝 *Pesanan:*",
  "{pesanan}",
  "",
  "📝 *Note :*",
  "{note}",
  "",
  "Pesanan {tag} lagi di proses, mohon bersabar ya 👨🏼‍💻",
].join("\n")

const DEFAULT_DONE = [
  "「 *TRANSAKSI BERHASIL* 」",
  "",
  "📅 *TANGGAL :* {tanggal}",
  "⌚ *JAM     :* {jam}",
  "✨ *STATUS  :* {status}",
  "",
  "📝 *Pesanan:*",
  "{pesanan}",
  "",
  "📝 *Note :*",
  "{note}",
  "",
  "Terima kasih kak {tag}! Jangan lupa order lagi ya! 🙂",
].join("\n")

// ===================== INIT GROUP NODE =====================
function ensureGroupNode(gid) {
  if (!storeDatabase[gid]) storeDatabase[gid] = {}
  if (typeof storeDatabase[gid] !== "object") storeDatabase[gid] = {}
  if (!storeDatabase[gid].statusTemplates || typeof storeDatabase[gid].statusTemplates !== "object") {
    storeDatabase[gid].statusTemplates = {}
  }
  return storeDatabase[gid]
}

// ===================== CACHE (MAX 200 / GRUP) =====================
const MAX_CACHE_PER_GROUP = 200
function getCacheRoot(wafproject) {
  wafproject._storeStatusCache = wafproject._storeStatusCache || {}
  return wafproject._storeStatusCache
}
function putCache(wafproject, chatId, msgId, text) {
  if (!chatId || !msgId) return
  const root = getCacheRoot(wafproject)
  root[chatId] = root[chatId] || { order: [], map: {} }

  const bucket = root[chatId]
  const id = String(msgId)
  const val = String(text || "").trim()
  if (!val) return

  if (!bucket.map[id]) {
    bucket.order.push(id)
    while (bucket.order.length > MAX_CACHE_PER_GROUP) {
      const old = bucket.order.shift()
      if (old) delete bucket.map[old]
    }
  }
  bucket.map[id] = val
}
function getCache(wafproject, chatId, msgId) {
  try {
    const root = getCacheRoot(wafproject)
    const bucket = root?.[chatId]
    if (!bucket) return ""
    return String(bucket.map?.[String(msgId)] || "")
  } catch {
    return ""
  }
}

// ===================== ADMIN CHECK (UNTUK REACT) =====================
const normalizeJid = (j = "") => String(j || "").replace(/:.*@/, "@").trim()
const sameJid = (a, b) => normalizeJid(a) === normalizeJid(b)

const getBotJid = (wafproject) => {
  const raw = wafproject?.user?.id || wafproject?.user?.jid || ""
  try {
    return wafproject.decodeJid ? wafproject.decodeJid(raw) : raw
  } catch {
    return raw
  }
}

const isAdminFlag = (p) => !!(p && (p.admin === "admin" || p.admin === "superadmin" || p.isAdmin))

function resolveParticipantJid(p) {
  return p?.jid || p?.id || p?.user || p?.participant || ""
}

function resolveLidToJid(id, meta) {
  if (!id) return id
  const s = String(id)
  if (s.endsWith("@lid") && meta?.participants) {
    const p = meta.participants.find((x) => x.lid === id || x.id === id)
    return p ? p.jid || p.id : id
  }
  return id
}

async function getAdminStatus(wafproject, chatJid, senderJid) {
  try {
    let meta = null
    try {
      meta = await wafproject.groupMetadata(chatJid)
    } catch {
      meta = null
    }
    if (!meta) return { isAdmin: false, isBotAdmin: false, meta: null }

    const participants = meta.participants || []

    const botJid = normalizeJid(getBotJid(wafproject))
    const botPart = participants.find((p) => sameJid(resolveParticipantJid(p), botJid))
    const isBotAdmin = isAdminFlag(botPart)

    const senderFixed = resolveLidToJid(senderJid, meta)
    const senderPart = participants.find((p) => sameJid(resolveParticipantJid(p), senderFixed))
    const isAdmin = isAdminFlag(senderPart)

    return { isAdmin, isBotAdmin, meta }
  } catch {
    return { isAdmin: false, isBotAdmin: false, meta: null }
  }
}

// ===== EMOJI NORMALIZER =====
function cleanEmoji(s = "") {
  return String(s || "").replace(/\uFE0F/g, "").trim()
}

// ===================== FORMAT WAKTU WIB =====================
function formatDateWIB(date = new Date()) {
  return new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date)
}

function formatTimeWIB(date = new Date()) {
  return new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(date).replace(/\./g, ":") + " WIB"
}

// ===================== HELPERS =====================
function getContextInfo(m) {
  try {
    const mm =
      m?.message?.ephemeralMessage?.message ||
      m?.message?.viewOnceMessage?.message ||
      m?.message?.viewOnceMessageV2?.message ||
      m?.message

    return (
      mm?.extendedTextMessage?.contextInfo ||
      mm?.imageMessage?.contextInfo ||
      mm?.videoMessage?.contextInfo ||
      mm?.documentMessage?.contextInfo ||
      mm?.buttonsResponseMessage?.contextInfo ||
      mm?.templateButtonReplyMessage?.contextInfo ||
      mm?.listResponseMessage?.contextInfo ||
      mm?.interactiveResponseMessage?.contextInfo ||
      mm?.messageContextInfo ||
      mm?.contextInfo ||
      null
    )
  } catch (error) {
    console.error("[STORE-STATUS] getContextInfo:", error?.message || error)
    return null
  }
}

function extractQuotedText(m) {
  try {
    if (m?.quoted) return String(m.quoted.text || m.quoted.caption || "").trim()

    const ctx = getContextInfo(m)
    if (ctx?.quotedMessage) {
      const q = ctx.quotedMessage
      const text =
        q.conversation ||
        q.extendedTextMessage?.text ||
        q.imageMessage?.caption ||
        q.videoMessage?.caption ||
        ""
      return String(text || "").trim()
    }
  } catch (error) {
    console.error("[STORE-STATUS] extractQuotedText:", error?.message || error)
  }
  return ""
}

function hasQuoted(m) {
  try {
    if (m?.quoted) return true
    const ctx = getContextInfo(m)
    return !!ctx?.quotedMessage
  } catch (error) {
    console.error("[STORE-STATUS] hasQuoted:", error?.message || error)
    return false
  }
}

function getMentionTargetsFromQuoted(m) {
  try {
    if (Array.isArray(m?.mentionedJid) && m.mentionedJid.length) return m.mentionedJid
    if (m?.quoted?.sender) return [m.quoted.sender]
    const ctx = getContextInfo(m)
    const participant = ctx?.participant
    if (participant) return [participant]
  } catch (error) {
    console.error("[STORE-STATUS] getMentionTargetsFromQuoted:", error?.message || error)
  }
  return []
}

function getReplyContextFromQuoted(m) {
  try {
    const ctx = getContextInfo(m)
    if (ctx?.quotedMessage && ctx?.stanzaId) {
      return {
        stanzaId: ctx.stanzaId,
        participant: ctx.participant || undefined,
        quotedMessage: ctx.quotedMessage,
        remoteJid: m.chat,
      }
    }

    if (m?.quoted?.key?.id && m?.quoted?.message) {
      return {
        stanzaId: m.quoted.key.id,
        participant: m.quoted.key.participant || undefined,
        quotedMessage: m.quoted.message,
        remoteJid: m.chat,
      }
    }
  } catch (error) {
    console.error("[STORE-STATUS] getReplyContextFromQuoted:", error?.message || error)
  }
  return null
}

function buildReplyPayload(text, mentions, replyCtx) {
  if (!replyCtx?.quotedMessage || !replyCtx?.stanzaId) {
    return { text, mentions: mentions || [] }
  }

  return {
    text,
    contextInfo: {
      stanzaId: replyCtx.stanzaId,
      participant: replyCtx.participant,
      quotedMessage: replyCtx.quotedMessage,
    },
  }
}

function renderTemplate(template, vars) {
  return String(template || "")
    .replace(/\{tanggal\}/g, vars.tanggal)
    .replace(/\{jam\}/g, vars.jam)
    .replace(/\{status\}/g, vars.status)
    .replace(/\{pesanan\}/g, vars.pesanan || "-")
    .replace(/\{note\}/g, vars.note || "-")
    .replace(/\{tag\}/g, vars.tag || "@user")
}

// ===================== MAIN PLUGIN =====================
async function plugin(message, ctx = {}) {
  const {
    usedPrefix = ".",
    text,
    command,
    wafproject,
    isAdmin = false,
    isOwner = false,
    args = [],
  } = ctx

  try {
    if (!wafproject) return
    if (!message?.chat) return

    storeDatabase = await readJsonSafe(STORE_PATH)

    const gid = message.chat
    const node = ensureGroupNode(gid)
    const tpl = node.statusTemplates || {}

    const cmd = String(command || "").toLowerCase()
    const isPrivileged = !!(isAdmin || isOwner)

    // ✅ non admin/owner → DIAM
    const allowedCmds = ["proses", "p", "done", "d", "setproses", "setdone", "resetproses", "resetdone"]
    if (allowedCmds.includes(cmd) && !isPrivileged) return

    const argText = (typeof text === "string" && text.length ? text : (args || []).join(" ")).trim()

    // ===================== SET TEMPLATE (admin only) =====================
    if (cmd === "setproses" || cmd === "setdone") {
      const fromQuoted = extractQuotedText(message)
      const body = (argText || "").trim() || fromQuoted

      if (!body) {
        return wafproject.sendMessage(
          message.chat,
          {
            text:
              `❌ Format:\n` +
              `• ${usedPrefix}${cmd} <template>\n` +
              `atau reply pesan multi-line lalu ketik ${usedPrefix}${cmd}\n\n` +
              `Placeholder:\n{tanggal}, {jam}, {status}, {pesanan}, {note}, {tag}`,
          },
          { quote: message }
        )
      }

      if (cmd === "setproses") node.statusTemplates.proses = body
      if (cmd === "setdone") node.statusTemplates.done = body

      await saveStoreDatabase()
      return wafproject.sendMessage(
        message.chat,
        { text: `✅ Template *${cmd.replace("set", "")}* berhasil disimpan untuk grup ini.` },
        { quote: message }
      )
    }

    // ===================== RESET TEMPLATE =====================
    if (cmd === "resetproses" || cmd === "resetdone") {
      if (cmd === "resetproses") delete node.statusTemplates.proses
      if (cmd === "resetdone") delete node.statusTemplates.done

      await saveStoreDatabase()
      return wafproject.sendMessage(
        message.chat,
        { text: `🧹 Template *${cmd.replace("reset", "")}* berhasil direset ke *default*.` },
        { quote: message }
      )
    }

    // ===================== WAJIB REPLY UNTUK .p/.proses/.d/.done =====================
    if (cmd === "proses" || cmd === "p" || cmd === "done" || cmd === "d") {
      if (!hasQuoted(message)) return // ✅ DIAM jika tidak reply

      const pesanan = extractQuotedText(message)
      const note = (argText || "").trim()

      const now = new Date()
      const tanggal = formatDateWIB(now)
      const jam = formatTimeWIB(now)

      // mention = pemilik pesan target (quoted)
      const targetsRaw = getMentionTargetsFromQuoted(message)
      const targets = Array.isArray(targetsRaw) ? targetsRaw.filter(Boolean) : []
      const tagText = targets.length ? "@" + String(targets[0]).split("@")[0] : "@user"

      const isProses = cmd === "proses" || cmd === "p"
      const template = isProses ? tpl.proses || DEFAULT_PROSES : tpl.done || DEFAULT_DONE

      const msg = renderTemplate(template, {
        tanggal,
        jam,
        status: isProses ? "Pending ⏳" : "Berhasil ✅",
        pesanan: pesanan || "-",
        note: note || "-",
        tag: tagText,
      })

      // ✅ reply ke pesan target (via contextInfo)
      const replyCtx = getReplyContextFromQuoted(message)
      const payload = buildReplyPayload(msg, targets, replyCtx)

      // Reply manual tetap raw WhatsApp Proto, tetapi mention memakai Zapo send option.
      return wafproject.sendMessage(message.chat, payload, { mentions: targets })
    }
  } catch (e) {
    console.error("store-status error:", e)
    try {
      if (ctx?.wafproject && message?.chat) {
        await ctx.wafproject.sendMessage(
          message.chat,
          { text: "❌ Terjadi kesalahan di plugin *store-status*. Cek console." },
          { quote: message }
        )
      }
    } catch (_error) { console.error("[ERROR][commands/store/store-status.js]", _error?.message || _error) }
  }
}

// ===================== ✅ LISTENER: cache semua pesan masuk (biar react bisa ambil {pesanan}) =====================
plugin.all = async function (m, ctx = {}) {
  try {
    const wafproject = ctx.wafproject
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (m.fromMe) return
    if (m.fromMe === true) return

    const id = m?.key?.id
    if (!id) return

    const txt =
      m?.text ||
      m?.message?.conversation ||
      m?.message?.extendedTextMessage?.text ||
      m?.message?.imageMessage?.caption ||
      m?.message?.videoMessage?.caption ||
      ""

    if (!txt) return
    putCache(wafproject, m.chat, id, String(txt).trim())
  } catch (_error) { console.error("[ERROR][commands/store/store-status.js]", _error?.message || _error) }
}

// ===================== ✅ REACT HOOK: ✅ = done, ⏳ = proses =====================
plugin.processReactionFromUpsert = async function (wafproject, db, m) {
  try {
    if (!m || !wafproject) return
    if (!m.isGroup) return
    if (!m.message) return

    const r = m.message?.reactionMessage
    if (!r) return

    const emoji = cleanEmoji(r.text)
    const isDone = emoji === "✅"
    const isProses = emoji === "⏳"
    if (!isDone && !isProses) return

    const who = m.sender
    if (!who) return

    const { isAdmin } = await getAdminStatus(wafproject, m.chat, who)
    if (!isAdmin) return

    const key = r.key // pesan yang direact
    if (!key || !key.id) return

    const now = new Date()
    const tanggal = formatDateWIB(now)
    const jam = formatTimeWIB(now)

    // mention target = pemilik pesan yang direact
    let targets = []
    let participantForReply = null
    try {
      const meta = await wafproject.groupMetadata(m.chat).catch(() => null)
      participantForReply = key.participant || null
      if (participantForReply && meta) participantForReply = resolveLidToJid(participantForReply, meta)
      if (participantForReply) targets = [participantForReply]
    } catch (_error) { console.error("[ERROR][commands/store/store-status.js]", _error?.message || _error) }

    const tagText = targets.length ? "@" + String(targets[0]).split("@")[0] : "@user"

    // ambil pesanan dari cache berdasarkan ID pesan target
    const pesanan = getCache(wafproject, m.chat, key.id) || "-"

    // note react default "-"
    const note = "-"

    storeDatabase = await readJsonSafe(STORE_PATH)
    const node = ensureGroupNode(m.chat)
    const tpl = node.statusTemplates || {}

    const template = isProses ? tpl.proses || DEFAULT_PROSES : tpl.done || DEFAULT_DONE

    const msg = renderTemplate(template, {
      tanggal,
      jam,
      status: isProses ? "Pending ⏳" : "Berhasil ✅",
      pesanan: pesanan || "-",
      note,
      tag: tagText,
    })

    // ✅ reply ke pesan yang direact (pakai contextInfo reply manual)
    // quotedMessage minimal conversation text biar aman
    const payload = {
      text: msg,
      contextInfo: {
        stanzaId: key.id,
        participant: participantForReply || undefined,
        quotedMessage: { conversation: pesanan || "" },
      },
    }

    // Reply manual tetap raw WhatsApp Proto, mention memakai Zapo send option.
    await wafproject.sendMessage(m.chat, payload, { mentions: targets }).catch(() => {})
  } catch (e) {
    console.error("store-status react error:", e)
  }
}

// ===================== METADATA =====================
plugin.help = [
  "p (reply pesanan)",
  "proses (reply pesanan)",
  "d (reply pesanan)",
  "done (reply pesanan)",
  "setproses",
  "setdone",
  "resetproses",
  "resetdone",
]
plugin.command = ["proses", "p", "done", "d", "setproses", "setdone", "resetproses", "resetdone"]
plugin.category = "store"
plugin.description = "Status transaksi: proses/done + set/reset template per grup + react ✅/⏳"
plugin.group = true
plugin.owner = false
plugin.limit = false

module.exports = plugin