// commands/store/store-menu.js
// ✨ Store - menu (CommonJS) ✨
// SAVE: database/databaseStore.json

const fs = require('fs')
const fsp = fs.promises
const path = require('path')
const crypto = require('crypto')
const { downloadMediaMessage } = require('../../lib/zapo-adapter.js')

// ===== PATH DB (ABSOLUTE) =====
const { databaseFile } = require('../../lib/project-paths')
const STORE_PATH = databaseFile('databaseStore.json')
const STORE_DIR = path.dirname(STORE_PATH)


async function readJsonSafe() {
  try {
    await fsp.mkdir(STORE_DIR, { recursive: true })
    return JSON.parse(await fsp.readFile(STORE_PATH, 'utf8'))
  } catch (error) {
    if (error?.code !== 'ENOENT') console.error('[STORE DB] read:', error?.message || error)
    return {}
  }
}
async function writeJsonSafe(data) {
  try {
    await fsp.mkdir(STORE_DIR, { recursive: true })
    await fsp.writeFile(STORE_PATH, JSON.stringify(data, null, 2), 'utf8')
    return true
  } catch (error) {
    console.error('[STORE DB] write:', error?.message || error)
    return false
  }
}

// ───────────────────────────── Helpers ─────────────────────────────
const toUpper = s => String(s || '').trim().toUpperCase()

const kosongMessage = (name) => `🚫 *Produk Sedang Tidak Tersedia* 🚫

Maaf, produk ${toUpper(name)} saat ini tidak dapat diakses untuk sementara waktu.

🔄 *Status :* Kosong
⏰ *Keterangan :* Silakan coba kembali nanti
💡 *Tips  :* Intip dulu produk lain yang masih aktif!

Ketik *list* buat lihat produk yang lagi ready.`

function normalizeKey(input = '') {
  return String(input)
    .normalize('NFKC')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, '')
    .replace(/\s+/g, ' ')
    .trim()
}

async function sendReply(m, wafproject, text, extra = {}) {
  try {
    return await wafproject.sendMessage(m.chat, { text: String(text), ...extra }, { quote: m })
  } catch (_error) { console.error("[ERROR][commands/store/store-menu.js]", _error?.message || _error) }
}

async function deleteAdminCommand(wafproject, m) {
  try {
    const key = m?.key || {}
    const delKey = {
      remoteJid: m.chat,
      id: key.id,
      fromMe: !!key.fromMe,
      participant: key.participant || m.participant || m.sender
    }
    if (!delKey.id) return
    await wafproject.sendMessage(m.chat, { delete: delKey })
  } catch (_error) { console.error("[ERROR][commands/store/store-menu.js]", _error?.message || _error) }
}

// ───────────────────────────── DB per group ─────────────────────────────
function ensureGroupNode(db, gid) {
  if (!db[gid]) db[gid] = {}
  db[gid].items ||= {}
  db[gid].notes ||= {}
  if (typeof db[gid].templateIndex !== 'number') db[gid].templateIndex = 1
  if (typeof db[gid].manualTemplate !== 'string') db[gid].manualTemplate = ''
  return db[gid]
}

function migrateGroupDbIfNeeded(node) {
  if (node.__migrated_v2) return
  const items = node.items || {}
  const notes = node.notes || {}

  const newItems = {}
  const newNotes = {}

  for (const [oldKey, val] of Object.entries(items)) {
    if (!val) continue
    const shown = val.key || oldKey
    const nk = normalizeKey(val.normalized || shown || oldKey)
    if (!nk) continue
    newItems[nk] = { ...val, key: shown, normalized: nk }
  }

  for (const [oldKey, note] of Object.entries(notes)) {
    const nk = normalizeKey(oldKey)
    if (!nk) continue
    newNotes[nk] = note
  }

  node.items = newItems
  node.notes = newNotes
  node.__migrated_v2 = true
}

function findItemByAnyKey(items, queryRaw) {
  const qk = normalizeKey(queryRaw)
  if (!qk) return { k: null, item: null }
  if (items[qk]) return { k: qk, item: items[qk] }

  for (const [k, it] of Object.entries(items)) {
    const shown = it?.key || k
    if (normalizeKey(shown) === qk) return { k, item: it }
  }
  return { k: null, item: null }
}

// ───────────────────────────── Reset Pending ─────────────────────────────
const pendingReset = new Map()
const RESET_TTL = 60 * 1000

function setPendingReset(chat, sender, gid) {
  pendingReset.set(`${chat}|${sender}`, { gid, ts: Date.now() })
}
function getPendingReset(chat, sender) {
  const key = `${chat}|${sender}`
  const data = pendingReset.get(key)
  if (!data) return null
  if (Date.now() - data.ts > RESET_TTL) {
    pendingReset.delete(key)
    return null
  }
  return data
}
function clearPendingReset(chat, sender) {
  pendingReset.delete(`${chat}|${sender}`)
}

// ───────────────────────────── Media helper ─────────────────────────────
async function downloadImageFromMessage(m, wafproject) {
  if (m?.quoted?.download) {
    try { return await m.quoted.download() } catch (_error) { console.error("[ERROR][commands/store/store-menu.js]", _error?.message || _error) }
  }

  const msg = m?.message
  const hasImage =
    msg?.imageMessage ||
    msg?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage

  if (!hasImage) return null

  try {
    return await downloadMediaMessage(
      m,
      'buffer',
      {},
      { logger: console, reuploadRequest: wafproject.updateMediaMessage }
    )
  } catch {
    return null
  }
}

// ───────────────────────────── Plugin main ─────────────────────────────
async function plugin(m, ctx = {}) {
  const { usedPrefix = '.', text, command, wafproject, isAdmin = false, isOwner = false, args = [] } = ctx
  try {
    if (!wafproject) return
    if (!m.isGroup) return

    const gid = m.chat
    const dbJson = await readJsonSafe()
    const node = ensureGroupNode(dbJson, gid)
    migrateGroupDbIfNeeded(node)

    const items = node.items
    const notes = node.notes

    const cmdLower = String(command || '').toLowerCase()
    const needAdmin = ['addlist','dellist','updatelist','editlist','renamelist','setket','resetlist']
    if (!isAdmin && !isOwner && needAdmin.includes(cmdLower)) {
      return sendReply(m, wafproject, `🚫 Maaf, hanya admin/owner yang bisa memakai perintah *${command}*!`)
    }

    const argText = (typeof text === 'string' && text.length ? text : (args || []).join(' ')).trim()

    if (cmdLower === 'resetlist') {
      setPendingReset(m.chat, m.sender, gid)
      return sendReply(
        m, wafproject,
        `⚠️ *Konfirmasi Reset List*\n\nIni akan menghapus *SEMUA* item & keterangan di grup ini.\n\nKetik:\n• *Y* = Setuju\n• *N* = Batal\n\n⏳ Timeout: 60 detik`
      )
    }

    if (cmdLower === 'setket') {
      if (!argText || !argText.includes('|'))
        return sendReply(m, wafproject, `❌ Format: *${usedPrefix}setket <nama>|<keterangan>*`)

      const [nameRaw, ...noteParts] = argText.split('|').map(s => s.trim())
      const noteRaw = noteParts.join('|').trim()
      const nk = normalizeKey(nameRaw)

      if (!nk) return sendReply(m, wafproject, '❌ Nama item tidak valid!')
      if (!noteRaw || noteRaw === '-' || noteRaw.toLowerCase() === 'clear') {
        delete notes[nk]
        await writeJsonSafe(dbJson)
        return sendReply(m, wafproject, `🧹 Keterangan untuk *${nameRaw}* dihapus.`)
      }

      notes[nk] = noteRaw
      await writeJsonSafe(dbJson)
      return sendReply(m, wafproject, `✅ Keterangan untuk *${nameRaw}* disimpan.`)
    }

    if (cmdLower === 'addlist') {
      const media = await downloadImageFromMessage(m, wafproject)
      if (media) {
        if (!argText) return sendReply(m, wafproject, `❌ Format: *${usedPrefix}addlist <nama>|<caption>* (reply/kirim gambar)`)

        const [rawKey, ...cap] = argText.split('|').map(s => s.trim())
        const caption = cap.join('|') || rawKey
        const nk = normalizeKey(rawKey)
        if (!nk) return sendReply(m, wafproject, '❌ Nama item tidak valid!')

        const hash = crypto.createHash('sha256').update(media).digest('hex')
        items[nk] = {
          type: 'image',
          key: rawKey,
          normalized: nk,
          caption,
          hash,
          image: media.toString('base64'),
          createdAt: new Date().toISOString()
        }

        await writeJsonSafe(dbJson)
        await sendReply(m, wafproject, `✅ Item gambar *${rawKey}* berhasil ditambahkan!`)
        await deleteAdminCommand(wafproject, m)
        return
      }

      if (!argText || !argText.includes('|'))
        return sendReply(m, wafproject, `❌ Format: *${usedPrefix}addlist <nama>|<respon>*`)

      const [rawKey, ...resp] = argText.split('|').map(s => s.trim())
      const response = resp.join('|')
      const nk = normalizeKey(rawKey)
      if (!nk || !response) return sendReply(m, wafproject, '❌ Format tidak valid!')

      items[nk] = {
        type: 'text',
        key: rawKey,
        normalized: nk,
        response,
        createdAt: new Date().toISOString()
      }

      await writeJsonSafe(dbJson)
      await sendReply(m, wafproject, `✅ Item *${rawKey}* berhasil ditambahkan!`)
      await deleteAdminCommand(wafproject, m)
      return
    }

    // ✅ UPDATED: dellist bisa banyak item pakai pemisah "|"
    if (cmdLower === 'dellist') {
      if (!argText) return sendReply(m, wafproject, `❌ Format: *${usedPrefix}dellist <nama>|<nama2>|...*`)

      const targets = argText
        .split('|')
        .map(s => s.trim())
        .filter(Boolean)

      if (!targets.length) return sendReply(m, wafproject, `❌ Tidak ada nama item yang valid.`)

      const deleted = []
      const notFound = []

      for (const t of targets) {
        const { k, item } = findItemByAnyKey(items, t)
        if (!k || !item) {
          notFound.push(t)
          continue
        }

        const shownName = item?.key || t
        delete items[k]
        if (notes[k]) delete notes[k]
        deleted.push(shownName)
      }

      await writeJsonSafe(dbJson)

      const lines = []
      if (deleted.length) lines.push(`🗑 *Dihapus (${deleted.length})*:\n• ${deleted.join('\n• ')}`)
      if (notFound.length) lines.push(`🔍 *Tidak ditemukan (${notFound.length})*:\n• ${notFound.join('\n• ')}`)

      return sendReply(m, wafproject, lines.join('\n\n'))
    }

    if (cmdLower === 'renamelist') {
      if (!argText || !argText.includes('|'))
        return sendReply(m, wafproject, `❌ Format: *${usedPrefix}renamelist <lama>|<baru>*`)

      const [oldRaw, newRaw] = argText.split('|').map(s => s.trim())
      const oldFind = findItemByAnyKey(items, oldRaw)
      const newKey = normalizeKey(newRaw)

      if (!oldFind.item) return sendReply(m, wafproject, `🔍 Item *${oldRaw}* tidak ditemukan.`)
      if (!newKey) return sendReply(m, wafproject, `❌ Nama baru tidak valid.`)
      if (items[newKey]) return sendReply(m, wafproject, `⚠ Nama baru *${newRaw}* sudah digunakan.`)

      const data = oldFind.item
      delete items[oldFind.k]
      items[newKey] = { ...data, key: newRaw, normalized: newKey }

      if (notes[oldFind.k]) {
        notes[newKey] = notes[oldFind.k]
        delete notes[oldFind.k]
      }

      await writeJsonSafe(dbJson)
      return sendReply(m, wafproject, `✅ Rename berhasil.\n• Dari: *${data?.key || oldRaw}*\n• Ke: *${newRaw}*`)
    }

    if (cmdLower === 'updatelist' || cmdLower === 'editlist') {
      const media = await downloadImageFromMessage(m, wafproject)
      if (media) {
        if (!argText) return sendReply(m, wafproject, `❌ Format: *${usedPrefix}updatelist <nama>|<caption>* (reply/kirim gambar)`)

        const [rawKey, ...cap] = argText.split('|').map(s => s.trim())
        const caption = cap.join('|') || rawKey

        const found = findItemByAnyKey(items, rawKey)
        if (!found.item) return sendReply(m, wafproject, `🔍 Item *${rawKey}* tidak ditemukan.`)

        const hash = crypto.createHash('sha256').update(media).digest('hex')
        items[found.k] = { ...found.item, type: 'image', caption, hash, image: media.toString('base64') }

        await writeJsonSafe(dbJson)
        await sendReply(m, wafproject, `✏ Item gambar *${items[found.k].key}* diperbarui!`)
        await deleteAdminCommand(wafproject, m)
        return
      }

      if (!argText || !argText.includes('|'))
        return sendReply(m, wafproject, `❌ Format: *${usedPrefix}updatelist <nama>|<respon baru>*`)

      const [rawKey, ...resp] = argText.split('|').map(s => s.trim())
      const newResponse = resp.join('|')

      const found = findItemByAnyKey(items, rawKey)
      if (!found.item) return sendReply(m, wafproject, `🔍 Item *${rawKey}* tidak ditemukan.`)

      items[found.k] = { ...found.item, type: 'text', response: newResponse }
      await writeJsonSafe(dbJson)

      await sendReply(m, wafproject, `✏ Item *${items[found.k].key}* berhasil diedit!`)
      await deleteAdminCommand(wafproject, m)
      return
    }

  } catch (e) {
    console.error('store-menu error:', e)
  }
}

// keyword + reset confirm
plugin.all = async (m, { wafproject, isAdmin = false, isOwner = false } = {}) => {
  try {
    if (!wafproject) return
    if (!m.isGroup) return
    if (m?.key?.fromMe) return

    const gid = m.chat
    const dbJson = await readJsonSafe()
    const node = ensureGroupNode(dbJson, gid)
    migrateGroupDbIfNeeded(node)

    const items = node.items
    const notes = node.notes

    const pending = getPendingReset(m.chat, m.sender)
    if (pending && (isAdmin || isOwner)) {
      const rawTxt = String(m.text || '').trim().toLowerCase()

      if (rawTxt === 'y' || rawTxt === 'yes') {
        node.items = {}
        node.notes = {}
        await writeJsonSafe(dbJson)
        clearPendingReset(m.chat, m.sender)
        return wafproject.sendMessage(gid, { text: '✅ *Resetlist berhasil!* Semua item & keterangan dihapus.' }, { quote: m })
      }

      if (rawTxt === 'n' || rawTxt === 'no') {
        clearPendingReset(m.chat, m.sender)
        return wafproject.sendMessage(gid, { text: '❎ Resetlist dibatalkan.' }, { quote: m })
      }

      return wafproject.sendMessage(gid, { text: 'Ketik *Y* untuk setuju atau *N* untuk batal.' }, { quote: m })
    }

    const raw = String(m.text || '').trim()
    if (!raw) return

    const k = normalizeKey(raw)
    if (!k) return

    if ((notes[k] || '').toLowerCase() === 'kosong') {
      return wafproject.sendMessage(gid, { text: kosongMessage(raw) }, { quote: m })
    }

    const found = findItemByAnyKey(items, raw)
    if (!found.item) return

    if (found.item.type === 'text') {
      return wafproject.sendMessage(gid, { text: found.item.response || '' }, { quote: m })
    }

    if (found.item.type === 'image' && found.item.image) {
      const buffer = Buffer.from(found.item.image, 'base64')
      return wafproject.sendMessage(gid, { image: buffer, caption: found.item.caption || found.item.key || '' }, { quote: m })
    }
  } catch (e) {
    console.error('store-menu all error:', e)
  }
}

plugin.help = ['addlist','dellist','updatelist','editlist','renamelist','setket','resetlist']
plugin.tags = ['store']
plugin.command = ['addlist','dellist','updatelist','editlist','renamelist','setket','resetlist']
plugin.category = 'store'
plugin.group = true
plugin.owner = false
plugin.limit = false

module.exports = plugin