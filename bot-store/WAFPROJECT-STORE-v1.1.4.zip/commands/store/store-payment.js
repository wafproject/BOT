// commands/store/store-pay.js
// ✨ Store - payment per grup (CommonJS) ✨
// ✅ Cocok untuk BASE kamu:
// - Database path: database/paymentStore.json
// - plugin.command pakai ARRAY (bukan regex) biar kebaca handler
// - Support gambar: reply gambar ATAU kirim gambar langsung
// - Command: pay/bayar/payment + setpay/updatepay (admin/owner)
// - Penyimpanan per grup: { text, image: {hash,image,createdAt} }

const fs = require('fs')
const fsp = fs.promises
const path = require('path')
const crypto = require('crypto')
const { downloadMediaMessage } = require('../../lib/zapo-adapter.js')

// ===================== DB PATH FIX =====================
const { databaseFile } = require('../../lib/project-paths')
const PAYMENT_PATH = databaseFile('paymentStore.json')
const DB_DIR = path.dirname(PAYMENT_PATH)


async function readJsonSafe(p) {
  try {
    await fsp.mkdir(path.dirname(p), { recursive: true })
    return JSON.parse(await fsp.readFile(p, 'utf8'))
  } catch (error) {
    if (error?.code !== 'ENOENT') console.error('[STORE-PAY DB] read:', error?.message || error)
    return {}
  }
}
async function writeJsonSafe(p, data) {
  try {
    await fsp.mkdir(path.dirname(p), { recursive: true })
    await fsp.writeFile(p, JSON.stringify(data, null, 2), 'utf8')
    return true
  } catch (error) {
    console.error('[STORE-PAY DB] write:', error?.message || error)
    return false
  }
}

let paymentDatabase = {}
const savePaymentDatabase = () => writeJsonSafe(PAYMENT_PATH, paymentDatabase)

// ===================== HELPERS =====================
async function sendReply(m, wafproject, text, extra = {}) {
  try {
    return await wafproject.sendMessage(m.chat, { text: String(text), ...extra }, { quote: m })
  } catch (e) {
    console.log('[STORE-PAY] sendReply error:', e?.message || e)
  }
}

function ensureGroupNode(gid) {
  if (!paymentDatabase[gid] || typeof paymentDatabase[gid] !== 'object') {
    paymentDatabase[gid] = { text: '', image: null }
  }
  if (typeof paymentDatabase[gid].text !== 'string') paymentDatabase[gid].text = ''
  if (paymentDatabase[gid].image && typeof paymentDatabase[gid].image !== 'object') paymentDatabase[gid].image = null
  return paymentDatabase[gid]
}

async function downloadImageFromMessage(m, wafproject) {
  // 1) kalau quoted punya download()
  if (m?.quoted?.download) {
    try { return await m.quoted.download() } catch (_error) { console.error("[ERROR][commands/store/store-payment.js]", _error?.message || _error) }
  }

  // 2) kalau message ini gambar
  const msg = m?.message
  const hasImage =
    msg?.imageMessage ||
    msg?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage

  if (!hasImage) return null

  try {
    return await downloadMediaMessage(
      m,
      'buffer',
      {},
      { logger: console, reuploadRequest: wafproject.updateMediaMessage }
    )
  } catch {
    return null
  }
}

// ===================== MAIN PLUGIN =====================
async function plugin(message, ctx = {}) {
  const {
    usedPrefix = '.',
    text,
    command,
    wafproject,
    isAdmin = false,
    isOwner = false,
    args = []
  } = ctx

  try {
    if (!wafproject) return
    if (!message?.chat) return

    // refresh biar sync (aman)
    paymentDatabase = await readJsonSafe(PAYMENT_PATH)

    const gid = message.chat
    const cmd = String(command || '').toLowerCase()
    const argText = (typeof text === 'string' && text.length ? text : (args || []).join(' ')).trim()

    const node = ensureGroupNode(gid)

    // ===================== setpay / updatepay =====================
    if (cmd === 'setpay' || cmd === 'updatepay') {
      if (!isAdmin && !isOwner) {
        return sendReply(message, wafproject, `🚫 Maaf, hanya admin/owner yang bisa memakai perintah *${usedPrefix}${cmd}*!`)
      }

      if (!argText) {
        return sendReply(
          message,
          wafproject,
          `❌ Format:\n• Reply gambar QR: *${usedPrefix}${cmd} <teks>*\n• Tanpa gambar: *${usedPrefix}${cmd} <teks>*`
        )
      }

      // ambil gambar jika ada (reply/kirim)
      const media = await downloadImageFromMessage(message, wafproject)

      // default: keep gambar lama kalau tidak ada media baru
      let imageData = node.image || null

      if (media) {
        const hash = crypto.createHash('sha256').update(media).digest('hex')
        imageData = {
          hash,
          image: media.toString('base64'),
          createdAt: new Date().toISOString()
        }
      }

      paymentDatabase[gid] = { text: argText, image: imageData }
      await savePaymentDatabase()

      const verb = cmd === 'setpay' ? 'diset' : 'diperbarui'
      return sendReply(
        message,
        wafproject,
        `✅ Info payment untuk grup ini berhasil *${verb}*.\n\n• Teks: ${argText}\n• Gambar: ${imageData ? '✅ Disimpan' : '❌ Tidak ada / tetap yang lama'}`
      )
    }

    // ===================== pay / bayar / payment =====================
    if (cmd === 'pay' || cmd === 'bayar' || cmd === 'payment') {
      const data = ensureGroupNode(gid)

      if (!data.text && !data.image) {
        return sendReply(
          message,
          wafproject,
          `⚠ Belum ada info pembayaran untuk grup ini.\n\nSet dulu dengan:\n*${usedPrefix}setpay <teks>* (boleh reply gambar QR).`
        )
      }

      if (data.image && data.image.image) {
        const buffer = Buffer.from(data.image.image, 'base64')
        return wafproject.sendMessage(
          message.chat,
          { image: buffer, caption: data.text || 'PAYMENT' },
          { quote: message }
        )
      }

      return sendReply(message, wafproject, data.text || 'PAYMENT')
    }

  } catch (e) {
    console.error('store-pay error:', e)
    try {
      if (wafproject && message?.chat) {
        await wafproject.sendMessage(
          message.chat,
          { text: '❌ Terjadi kesalahan di plugin payment. Cek console.' },
          { quote: message }
        )
      }
    } catch (_error) { console.error("[ERROR][commands/store/store-payment.js]", _error?.message || _error) }
  }
}

// ===================== METADATA (BASE KAMU) =====================
plugin.help = ['pay', 'payment', 'setpay', 'updatepay']
plugin.tags = ['store']
plugin.command = ['pay', 'payment', 'setpay', 'updatepay']
plugin.category = 'store'
plugin.description = 'Payment per grup: set/update + tampilkan (support QR image)'
plugin.group = true
plugin.owner = false
plugin.limit = false

module.exports = plugin