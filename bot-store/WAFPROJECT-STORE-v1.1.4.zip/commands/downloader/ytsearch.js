/**
 * YouTube Search - JagoanProject
 *
 * Command:
 * .ytsearch <query>
 * .yts <query>
 *
 * Endpoint:
 * GET /api/search/yts?q=<query>
 */

const axios = require("axios");

function cleanText(v, fallback = "") {
  if (typeof v !== "string" || !v.trim()) return fallback;
  return v.replace(/[\r\n]+/g, " ").replace(/\s+/g, " ").trim();
}

function isValidUrl(v) {
  return typeof v === "string" && /^https?:\/\//i.test(v.trim());
}

async function fetchYouTubeSearch(query) {
  if (!global.jagoanApi) throw new Error("global.jagoanApi belum di-set.");
  if (!global.jagoanKey) throw new Error("global.jagoanKey belum di-set.");

  const baseUrl = String(global.jagoanApi).trim().replace(/\/+$/, "");
  const apiKey = String(global.jagoanKey).trim();

  const res = await axios({
    method: "get",
    url: `${baseUrl}/api/search/yts`,
    params: { q: query },
    headers: { Authorization: `Bearer ${apiKey}` },
    timeout: 120000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = res.data;

  console.log("[YTSEARCH] HTTP:", res.status);

  if (res.status < 200 || res.status >= 300) {
    console.error("[YTSEARCH API ERROR]",
      typeof data === "string" ? data : JSON.stringify(data, null, 2)
    );

    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      `JagoanProject HTTP ${res.status}`
    );
  }

  if (data?.status === false || data?.success === false) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      "Pencarian YouTube gagal."
    );
  }

  const results = Array.isArray(data?.result) ? data.result : [];

  if (!results.length) {
    throw new Error("Video YouTube tidak ditemukan.");
  }

  return results.map((item, index) => ({
    index: index + 1,
    title: cleanText(item?.title || "Tanpa judul"),
    thumbnail: isValidUrl(item?.thumbnail) ? item.thumbnail : "",
    duration: cleanText(item?.duration || "-"),
    uploaded: cleanText(item?.uploaded || "-"),
    views: cleanText(item?.views || "-"),
    url: isValidUrl(item?.url) ? item.url : "",
    videoId: cleanText(item?.videoId || "")
  })).filter(item => item.url);
}

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  const query = cleanText(text, "");

  if (!query) {
    return m.reply(
      "🔎 *YOUTUBE SEARCH*\n\n" +
      `${usedPrefix + command} <judul / kata kunci>\n\n` +
      `Contoh:\n${usedPrefix + command} Mangu Fourtwnty`
    );
  }

  if (!global.jagoanApi || !global.jagoanKey) {
    return m.reply(
      "❌ Konfigurasi JagoanProject belum lengkap.\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_KAMU";'
    );
  }

  const react = async emoji => {
    try {
      await wafproject.sendMessage(
        m.chat,
        { react: { text: emoji, key: m.key } }
      );
    } catch {}
  };

  let statusMessage = null;

  const sendStatus = async text => {
    try {
      statusMessage = await wafproject.sendMessage(
        m.chat,
        { text },
        { quoted: m }
      );
      return statusMessage;
    } catch {
      return null;
    }
  };

  const editStatus = async text => {
    if (!statusMessage?.key) return null;

    try {
      return await wafproject.sendMessage(
        m.chat,
        { text, edit: statusMessage.key }
      );
    } catch {
      return null;
    }
  };

  try {
    await react("🕒");

    await sendStatus(
      "🔎 *YouTube Search*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `📝 Mencari: *${query.slice(0, 120)}*\n` +
      "⏳ Mohon tunggu...\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    const results = await fetchYouTubeSearch(query);
    const shown = results.slice(0, 10);

    let caption =
      "🔎 *YOUTUBE SEARCH*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `📝 Query: *${query.slice(0, 100)}*\n` +
      `📊 Ditemukan: *${results.length} hasil*\n` +
      "━━━━━━━━━━━━━━━━━━\n\n";

    shown.forEach((item, i) => {
      caption +=
        `*${i + 1}. ${item.title}*\n` +
        `⏱ ${item.duration}\n` +
        `👁 ${item.views}\n` +
        `📅 ${item.uploaded}\n` +
        `🔗 ${item.url}\n`;

      if (i !== shown.length - 1) caption += "\n";
    });

    caption +=
      "\n━━━━━━━━━━━━━━━━━━\n" +
      "💡 Download audio: *.play <judul>*\n" +
      "🎬 Download video: *.ytmp4 <link>*";

    const first = shown[0];

    if (first?.thumbnail) {
      try {
        await wafproject.sendMessage(
          m.chat,
          {
            image: { url: first.thumbnail },
            caption
          },
          { quoted: m }
        );
      } catch {
        await wafproject.sendMessage(
          m.chat,
          { text: caption },
          { quoted: m }
        );
      }
    } else {
      await wafproject.sendMessage(
        m.chat,
        { text: caption },
        { quoted: m }
      );
    }

    await editStatus(
      "🔎 *YouTube Search*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Pencarian selesai!\n" +
      `📊 Ditemukan: *${results.length} hasil*\n` +
      "━━━━━━━━━━━━━━━━━━"
    );

    await react("✅");
  } catch (error) {
    console.error("[YTSEARCH ERROR]", error);
    await react("❌");

    let msg = cleanText(
      error?.message || String(error),
      "Terjadi kesalahan."
    );

    if (global.jagoanKey) {
      msg = msg.replaceAll(
        String(global.jagoanKey),
        "[API_KEY]"
      );
    }

    msg = msg.slice(0, 500);

    const errorText =
      "🔎 *YouTube Search*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "❌ Pencarian gagal!\n\n" +
      `📌 ${msg}\n` +
      "━━━━━━━━━━━━━━━━━━";

    const edited = await editStatus(errorText);
    if (!edited) return m.reply(errorText);
  }
};

handler.help = [
  "ytsearch <query>",
  "yts <query>"
];

handler.tags = ["downloader"];
handler.category = ["downloader"];
handler.command = ["ytsearch", "yts"];

handler.limit = true;
handler.premium = false;
handler.register = true;

module.exports = handler;