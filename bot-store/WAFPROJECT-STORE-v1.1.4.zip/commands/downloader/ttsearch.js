/**
 * Plugin: TikTok Search (BOTCAHX)
 * Command: .ttsearch <query>
 *
 * Settings (settings.js):
 *   global.apibtc = "https://api.botcahx.eu.org"
 *   global.btc    = "APIKEY_KAMU"
 *
 * Endpoint:
 *   GET ${global.apibtc}/api/search/tiktoks?q=<query>&apikey=<key>
 *
 * Response:
 *   { status:true, result:{ data:[ ... ] } }
 */

const axios = require("axios");

function n(num) {
  const x = Number(num || 0);
  return Number.isFinite(x) ? x.toLocaleString("id-ID") : "0";
}

async function fetchTTSearch(query) {
  const base = String(global.apibtc || "").replace(/\/+$/, "");
  const apikey = String(global.btc || "").trim();

  if (!base) throw new Error("global.apibtc belum di set di settings.js");
  if (!apikey) throw new Error("global.btc belum di set di settings.js");

  const apiUrl = `${base}/api/search/tiktoks`;

  const rsp = await axios.get(apiUrl, {
    // beberapa API pakai 'q', ada juga yang pakai 'query' / 'search'
    // kita kirim q + query biar aman
    params: { q: query, query, apikey },
    timeout: 45000,
    validateStatus: () => true,
    headers: { "User-Agent": "Mozilla/5.0" },
  });

  if (rsp.status < 200 || rsp.status >= 300) throw new Error(`HTTP ${rsp.status}`);

  const json = rsp.data;
  if (!json || json.status !== true) {
    throw new Error(json?.message || json?.msg || "Gagal dari BOTCAHX API");
  }

  const data = json.result?.data;
  const list = Array.isArray(data) ? data : [];
  return list;
}

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  const q = (text || "").trim();
  if (!q) {
    return m.reply(`Contoh:\n${usedPrefix + command} perfect world episode 255`);
  }

  const react = async (emoji) => {
    try {
      await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
    } catch (_error) { console.error("[ERROR][commands/downloader/ttsearch.js]", _error?.message || _error) }
  };

  try {
    await react("🕒");

    const list = await fetchTTSearch(q);
    if (!list.length) {
      await react("❌");
      return m.reply("Hasil tidak ditemukan. Coba kata kunci lain.");
    }

    // tampilkan max 10 biar tidak kepanjangan
    const max = 10;
    const items = list.slice(0, max);

    let out =
      `乂  *T I K T O K  S E A R C H*\n\n` +
      `∘ *Query* : ${q}\n` +
      `∘ *Result* : ${items.length}${list.length > max ? ` (dari ${list.length})` : ""}\n\n`;

    for (let i = 0; i < items.length; i++) {
      const v = items[i] || {};
      const title = (v.title || "").trim() || "-";
      const author = v.author?.nickname || v.author?.unique_id || "-";
      const dur = v.duration ? `${Math.floor(v.duration / 60)}:${String(v.duration % 60).padStart(2, "0")}` : "-";

      out +=
        `*${i + 1}.* ${title}\n` +
        `• Author: ${author}\n` +
        `• Views: ${n(v.play_count)} | Likes: ${n(v.digg_count)} | Com: ${n(v.comment_count)}\n` +
        `• Dur: ${dur}\n` +
        `• Video: ${v.play || "-"}\n` +
        (v.music ? `• Music: ${v.music}\n` : "") +
        `\n`;
    }

    await wafproject.sendMessage(m.chat, { text: out.trim() }, { quote: m });
    await react("✅");
  } catch (e) {
    console.error("TTSEARCH ERROR:", e?.message || e);
    await react("❌");
    return m.reply(`Error: ${e?.message || e}`);
  }
};

handler.command = ["ttsearch"];
handler.help = ["ttsearch <query>"];
handler.category = ["downloader"];
handler.limit = true;
handler.register = true;

module.exports = handler;
