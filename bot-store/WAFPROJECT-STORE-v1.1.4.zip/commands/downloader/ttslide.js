
/**
 * TikTok Slide Downloader - JagoanProject
 *
 * Command:
 * .ttslide <url>
 * .tiktokslide <url>
 *
 * Endpoint:
 * GET https://api.jagoanproject.com/api/downloader/tiktok?url=<tiktok_url>
 *
 * Header:
 * Authorization: Bearer APIKEY
 *
 * config.js / settings.js:
 * global.jagoanApi = "https://api.jagoanproject.com";
 * global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";
 */

const axios = require("axios");
const { fromBuffer } = require("../../lib/file-type.js");

////////////////////////////
// Validasi TikTok URL
////////////////////////////
function isTikTokUrl(url = "") {
  const value = String(url || "").trim();

  if (!value) return false;

  try {
    const parsed = new URL(value);
    const hostname = parsed.hostname.toLowerCase();

    return (
      hostname === "tiktok.com" ||
      hostname.endsWith(".tiktok.com")
    );
  } catch {
    return false;
  }
}

////////////////////////////
// Validasi URL umum
////////////////////////////
function isValidUrl(value) {
  return (
    typeof value === "string" &&
    /^https?:\/\//i.test(value)
  );
}

////////////////////////////
// Bersihkan teks
////////////////////////////
function cleanText(value, fallback = "") {
  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    return fallback;
  }

  return value
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

////////////////////////////
// Format angka
////////////////////////////
function formatNumber(value) {
  const number = Number(value || 0);

  return Number.isFinite(number)
    ? number.toLocaleString("id-ID")
    : "0";
}

////////////////////////////
// Hapus URL duplikat
////////////////////////////
function uniqueUrls(urls) {
  const result = [];
  const seen = new Set();

  for (const url of urls) {
    if (!isValidUrl(url)) continue;

    const normalized = String(url).trim();

    if (seen.has(normalized)) {
      continue;
    }

    seen.add(normalized);
    result.push(normalized);
  }

  return result;
}

////////////////////////////
// Ambil URL dari item
////////////////////////////
function getUrlFromItem(item) {
  if (!item) return null;

  if (
    typeof item === "string" &&
    isValidUrl(item)
  ) {
    return item;
  }

  if (typeof item !== "object") {
    return null;
  }

  const possibleUrls = [
    item?.url,
    item?.download,
    item?.download_url,
    item?.downloadUrl,
    item?.sourceUrl,
    item?.source_url,
    item?.src,
    item?.link,
    item?.play,
    item?.play_url,
    item?.playUrl,
  ];

  return possibleUrls.find(isValidUrl) || null;
}

////////////////////////////
// Ambil slide dari data.downloads
////////////////////////////
function extractImages(data) {
  const downloads = Array.isArray(data?.data?.downloads)
    ? data.data.downloads
    : [];

  if (downloads.length) {
    const images = downloads
      .filter((item) => {
        const type = String(
          item?.type || ""
        ).toLowerCase();

        return (
          type === "image" ||
          type === "photo" ||
          type.includes("image") ||
          type.includes("photo")
        );
      })
      .map((item) => {
        return (
          item?.url ||
          item?.download ||
          item?.download_url ||
          item?.downloadUrl ||
          item?.sourceUrl ||
          null
        );
      })
      .filter(isValidUrl);

    if (images.length) {
      return uniqueUrls(images);
    }
  }

  // Fallback format API lain
  const fallbackContainers = [
    data?.data?.images,
    data?.data?.photos,
    data?.data?.slides,
    data?.data?.pictures,

    data?.data?.media?.images,
    data?.data?.media?.photos,
    data?.data?.media?.slides,

    data?.result?.images,
    data?.result?.photos,
    data?.result?.slides,

    data?.images,
    data?.photos,
    data?.slides,
  ];

  for (const container of fallbackContainers) {
    if (!container) continue;

    const values = Array.isArray(container)
      ? container
      : [container];

    const images = values
      .map(getUrlFromItem)
      .filter(isValidUrl);

    if (images.length) {
      return uniqueUrls(images);
    }
  }

  return [];
}

////////////////////////////
// Ambil audio dari data.music
////////////////////////////
function extractAudio(data) {
  const music =
    data?.data?.music ||
    data?.result?.music ||
    data?.music ||
    null;

  if (!music) {
    return null;
  }

  if (
    typeof music === "string" &&
    isValidUrl(music)
  ) {
    return {
      url: music,
      title: "TikTok Slide Audio",
      author: "",
    };
  }

  if (typeof music === "object") {
    const url =
      music?.url ||
      music?.play ||
      music?.play_url ||
      music?.download ||
      music?.download_url ||
      null;

    if (isValidUrl(url)) {
      return {
        url,
        title: cleanText(
          music?.title ||
          music?.name ||
          "TikTok Slide Audio"
        ),
        author: cleanText(
          music?.author ||
          music?.artist ||
          ""
        ),
      };
    }
  }

  return null;
}

////////////////////////////
// Ambil title
////////////////////////////
function extractTitle(data) {
  return cleanText(
    data?.data?.title ||
    data?.data?.caption ||
    data?.result?.title ||
    data?.result?.caption ||
    data?.title ||
    "TikTok Slide"
  );
}

////////////////////////////
// Ambil author
////////////////////////////
function extractAuthor(data) {
  return cleanText(
    data?.data?.author?.username ||
    data?.data?.author?.nickname ||
    data?.result?.author?.username ||
    data?.result?.author?.nickname ||
    ""
  );
}

////////////////////////////
// Ambil statistik
////////////////////////////
function extractStats(data) {
  const stats =
    data?.data?.stats ||
    data?.result?.stats ||
    {};

  return {
    likes:
      stats?.like ||
      stats?.likes ||
      stats?.likeCount ||
      0,

    views:
      stats?.views ||
      stats?.view ||
      stats?.playCount ||
      0,

    shares:
      stats?.share ||
      stats?.shares ||
      stats?.shareCount ||
      0,

    comments:
      stats?.comment ||
      stats?.comments ||
      stats?.commentCount ||
      0,
  };
}

////////////////////////////
// Request API
////////////////////////////
async function fetchTikTokSlide(url) {
  if (!global.jagoanApi) {
    throw new Error(
      "global.jagoanApi belum di-set."
    );
  }

  if (!global.jagoanKey) {
    throw new Error(
      "global.jagoanKey belum di-set."
    );
  }

  const baseUrl = String(global.jagoanApi)
    .trim()
    .replace(/\/+$/, "");

  const apiKey = String(global.jagoanKey).trim();

  if (!apiKey) {
    throw new Error(
      "API key JagoanProject kosong."
    );
  }

  if (!isTikTokUrl(url)) {
    throw new Error(
      "URL TikTok tidak valid."
    );
  }

  const endpoint =
    `${baseUrl}/api/downloader/tiktok` +
    `?url=${encodeURIComponent(url)}`;

  const response = await axios.get(endpoint, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0",
    },
    timeout: 120000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });

  const data = response.data;

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    const errorData =
      typeof data === "string"
        ? data
        : JSON.stringify(data);

    throw new Error(
      `JagoanProject HTTP ${response.status}: ` +
      errorData.slice(0, 500)
    );
  }

  if (
    data?.status === false ||
    data?.success === false
  ) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      "Request TikTok gagal."
    );
  }

  const isVideo =
    data?.data?.isVideo === true ||
    data?.data?.is_video === true;

  const isPhoto =
    data?.data?.isPhoto === true ||
    data?.data?.is_photo === true;

  if (isVideo && !isPhoto) {
    throw new Error(
      "Link tersebut adalah video TikTok. Gunakan command .tt"
    );
  }

  const images = extractImages(data);

  if (!images.length) {
    console.log(
      "[TikTok Slide API Response]",
      JSON.stringify(data, null, 2)
    );

    throw new Error(
      "Slide TikTok tidak ditemukan: " +
      JSON.stringify(data).slice(0, 1200)
    );
  }

  return {
    images,
    audio: extractAudio(data),
    title: extractTitle(data),
    author: extractAuthor(data),
    stats: extractStats(data),
    creator:
      data?.creator ||
      "Jagoan Project",
  };
}

////////////////////////////
// Download media ke buffer
////////////////////////////
async function downloadMediaBuffer(
  url,
  expectedType = ""
) {
  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 180000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    maxRedirects: 10,
    headers: {
      Accept: "*/*",
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      Referer: "https://www.tiktok.com/",
    },
  });

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    throw new Error(
      `Gagal download media HTTP ${response.status}`
    );
  }

  const buffer = Buffer.from(response.data);

  if (!buffer.length) {
    throw new Error(
      "File hasil download kosong."
    );
  }

  const fileType =
    (await fromBuffer(buffer)) || {};

  const mime = String(
    fileType?.mime ||
    response.headers?.["content-type"] ||
    ""
  )
    .split(";")[0]
    .trim()
    .toLowerCase();

  if (
    expectedType === "image" &&
    mime &&
    !mime.startsWith("image/")
  ) {
    throw new Error(
      `Hasil bukan gambar. MIME: ${mime}`
    );
  }

  if (
    expectedType === "audio" &&
    mime &&
    !mime.startsWith("audio/") &&
    !mime.startsWith("video/")
  ) {
    throw new Error(
      `Hasil bukan audio. MIME: ${mime}`
    );
  }

  return {
    buffer,
    mime,
    ext: fileType?.ext || "",
  };
}

////////////////////////////
// Kirim gambar
////////////////////////////
async function sendImage(
  wafproject,
  chat,
  url,
  caption,
  quoted
) {
  try {
    return await wafproject.sendMessage(
      chat,
      {
        image: { url },
        caption,
      },
      {
        quoted,
      }
    );
  } catch (error) {
    console.log(
      "[TikTok Slide] Kirim URL gagal, mencoba buffer:",
      error?.message || error
    );

    const media =
      await downloadMediaBuffer(
        url,
        "image"
      );

    return wafproject.sendMessage(
      chat,
      {
        image: media.buffer,
        mimetype:
          media.mime.startsWith("image/")
            ? media.mime
            : undefined,
        caption,
      },
      {
        quoted,
      }
    );
  }
}

////////////////////////////
// Kirim audio
////////////////////////////
async function sendAudio(
  wafproject,
  chat,
  url,
  fileName,
  quoted
) {
  try {
    return await wafproject.sendMessage(
      chat,
      {
        audio: { url },
        mimetype: "audio/mpeg",
        fileName,
      },
      {
        quoted,
      }
    );
  } catch (error) {
    console.log(
      "[TikTok Slide] Kirim audio URL gagal, mencoba buffer:",
      error?.message || error
    );

    const media =
      await downloadMediaBuffer(
        url,
        "audio"
      );

    return wafproject.sendMessage(
      chat,
      {
        audio: media.buffer,
        mimetype:
          media.mime.startsWith("audio/")
            ? media.mime
            : "audio/mpeg",
        fileName,
      },
      {
        quoted,
      }
    );
  }
}

////////////////////////////
// Handler
////////////////////////////
let handler = async (
  m,
  {
    wafproject,
    text,
    usedPrefix,
    command,
  }
) => {
  const input = String(text || "").trim();

  if (!input) {
    return m.reply(
      "📌 *Cara pakai:*\n" +
      `${usedPrefix + command} <link TikTok Slide>\n\n` +
      "Contoh:\n" +
      `${usedPrefix + command} https://www.tiktok.com/@user/photo/7403392690823433478`
    );
  }

  if (!isTikTokUrl(input)) {
    return m.reply(
      "❌ Itu bukan link TikTok yang valid."
    );
  }

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Tambahkan konfigurasi berikut:\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";'
    );
  }

  const react = async (emoji) => {
    try {
      await wafproject.sendMessage(
        m.chat,
        {
          react: {
            text: emoji,
            key: m.key,
          },
        }
      );
    } catch (_error) { console.error("[ERROR][commands/downloader/ttslide.js]", _error?.message || _error) }
  };

  let statusMessage;

  const sendStatus = async (message) => {
    try {
      statusMessage =
        await wafproject.sendMessage(
          m.chat,
          {
            text: message,
          },
          {
            quote: m,
          }
        );

      return statusMessage;
    } catch {
      return null;
    }
  };

  const editStatus = async (message) => {
    if (!statusMessage?.key) {
      return null;
    }

    try {
      return await wafproject.sendMessage(
        m.chat,
        {
          text: message,
          edit: statusMessage.key,
        }
      );
    } catch {
      return null;
    }
  };

  try {
    await react("🕒");

    await sendStatus(
      "🖼️ *TikTok Slide Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "🔗 Link diterima ✅\n" +
      "⚙️ Source: *JagoanProject TikTok*\n" +
      "🔎 Mengambil data slide... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    const result =
      await fetchTikTokSlide(input);

    const images =
      result.images.slice(0, 35);

    await editStatus(
      "🖼️ *TikTok Slide Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `✅ Terdeteksi: *${images.length} slide*\n` +
      "📤 Mengirim gambar... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    let sent = 0;
    let failed = 0;

    for (
      let index = 0;
      index < images.length;
      index++
    ) {
      const imageUrl = images[index];

      try {
        await editStatus(
          "🖼️ *TikTok Slide Downloader*\n" +
          "━━━━━━━━━━━━━━━━━━\n" +
          `📤 Mengirim slide *${index + 1}/${images.length}*... ⏳\n` +
          `✅ Terkirim: *${sent}*\n` +
          `❌ Gagal: *${failed}*\n` +
          "━━━━━━━━━━━━━━━━━━"
        );

        const authorText =
          result.author
            ? `\n👤 Author: *@${result.author}*`
            : "";

        const stats = result.stats || {};

        const statsText =
          index === 0 &&
          (
            stats.likes ||
            stats.views ||
            stats.comments ||
            stats.shares
          )
            ? "\n\n" +
              `▶️ Views: ${formatNumber(stats.views)}\n` +
              `❤️ Likes: ${formatNumber(stats.likes)}\n` +
              `💬 Comments: ${formatNumber(stats.comments)}\n` +
              `🔁 Shares: ${formatNumber(stats.shares)}`
            : "";

        const caption =
          index === 0
            ? "🖼️ *TikTok Slide*\n" +
              "━━━━━━━━━━━━━━━━━━\n" +
              `📝 ${result.title.slice(0, 700)}` +
              authorText +
              statsText +
              `\n\n📦 Slide: *${index + 1}/${images.length}*` +
              "\n⚙️ Source: *JagoanProject TikTok*"
            : `🖼️ Slide *${index + 1}/${images.length}*`;

        await sendImage(
          wafproject,
          m.chat,
          imageUrl,
          caption,
          m
        );

        sent++;
      } catch (itemError) {
        failed++;

        console.error(
          `[TikTok slide ${index + 1} error]`,
          itemError?.message ||
          itemError
        );
      }
    }

    if (!sent) {
      throw new Error(
        "Tidak ada slide yang berhasil dikirim."
      );
    }

    let audioSent = false;

    if (result.audio?.url) {
      try {
        await editStatus(
          "🖼️ *TikTok Slide Downloader*\n" +
          "━━━━━━━━━━━━━━━━━━\n" +
          `✅ Slide terkirim: *${sent}*\n` +
          "🎵 Mengirim audio... ⏳\n" +
          "━━━━━━━━━━━━━━━━━━"
        );

        const audioTitle =
          cleanText(
            result.audio.title ||
            result.title ||
            "tiktok-slide"
          )
            .replace(/[\\/:*?"<>|]/g, "")
            .slice(0, 80) ||
          "tiktok-slide";

        await sendAudio(
          wafproject,
          m.chat,
          result.audio.url,
          `${audioTitle}.mp3`,
          m
        );

        audioSent = true;
      } catch (audioError) {
        console.error(
          "[TikTok Slide Audio Error]",
          audioError?.message ||
          audioError
        );
      }
    }

    await editStatus(
      "🖼️ *TikTok Slide Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Proses selesai!\n" +
      `📤 Slide terkirim: *${sent}*\n` +
      `❌ Slide gagal: *${failed}*\n` +
      `🎵 Audio: *${audioSent ? "Terkirim" : result.audio?.url ? "Gagal dikirim" : "Tidak tersedia"}*\n` +
      "━━━━━━━━━━━━━━━━━━"
    );

    await react("✅");
  } catch (error) {
    console.error(
      "[JagoanProject TikTok Slide Error]",
      error
    );

    await react("❌");

    const errorMessage = String(
      error?.message || error
    )
      .replace(
        String(global.jagoanKey || ""),
        "[API_KEY]"
      )
      .slice(0, 800);

    const edited =
      await editStatus(
        "🖼️ *TikTok Slide Downloader*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "❌ Proses gagal!\n" +
        `📌 ${errorMessage}\n` +
        "━━━━━━━━━━━━━━━━━━"
      );

    if (!edited) {
      return m.reply(
        "❌ *TikTok Slide gagal:*\n" +
        errorMessage
      );
    }
  }
};

handler.command = [
  "ttslide",
  "tiktokslide",
];

handler.help = [
  "ttslide <url>",
  "tiktokslide <url>",
];

handler.tags = [
  "downloader",
];

handler.category = [
  "downloader",
];

handler.limit = true;
handler.register = true;

module.exports = handler;