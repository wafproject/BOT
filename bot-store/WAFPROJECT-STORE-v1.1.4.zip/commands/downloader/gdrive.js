// ✨ Plugin Google Drive Downloader - JagoanProject ✨
//
// Command:
// .gdrive <url>
//
// Endpoint:
// GET https://api.jagoanproject.com/api/downloader/gdrivedl?q=<googleDriveUrl>
//
// Header:
// Authorization: Bearer APIKEY
//
// config.js / settings.js:
// global.jagoanApi = "https://api.jagoanproject.com";
// global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";

const axios = require("axios");

////////////////////////////
// Validasi URL Google Drive
////////////////////////////
function isGDriveUrl(url = "") {
  const value = String(url || "").trim();

  if (!value) return false;

  try {
    const parsed = new URL(value);
    const hostname = parsed.hostname.toLowerCase();

    return (
      hostname === "drive.google.com" ||
      hostname.endsWith(".drive.google.com") ||
      hostname === "docs.google.com" ||
      hostname.endsWith(".docs.google.com")
    );
  } catch {
    return false;
  }
}

////////////////////////////
// Validasi URL biasa
////////////////////////////
function isValidUrl(value) {
  return (
    typeof value === "string" &&
    /^https?:\/\//i.test(value)
  );
}

////////////////////////////
// Format ukuran file
////////////////////////////
function formatFileSize(value) {
  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return "-";
  }

  if (typeof value === "string") {
    const trimmed = value.trim();

    if (!trimmed) return "-";

    // Jika sudah memiliki satuan
    if (
      /(?:bytes?|kb|mb|gb|tb)$/i.test(trimmed)
    ) {
      return trimmed;
    }

    const numeric = Number(trimmed);

    if (!Number.isNaN(numeric)) {
      value = numeric;
    } else {
      return trimmed;
    }
  }

  const bytes = Number(value);

  if (
    Number.isNaN(bytes) ||
    bytes < 0
  ) {
    return String(value);
  }

  if (bytes === 0) {
    return "0 B";
  }

  const units = [
    "B",
    "KB",
    "MB",
    "GB",
    "TB",
  ];

  const index = Math.min(
    Math.floor(
      Math.log(bytes) /
      Math.log(1024)
    ),
    units.length - 1
  );

  const size =
    bytes /
    Math.pow(1024, index);

  return (
    `${size.toFixed(index === 0 ? 0 : 2)} ` +
    units[index]
  );
}

////////////////////////////
// Ambil URL dari object
////////////////////////////
function getUrlFromObject(obj) {
  if (!obj) return null;

  if (
    typeof obj === "string" &&
    isValidUrl(obj)
  ) {
    return obj;
  }

  const possibleUrls = [
    obj?.url,
    obj?.download,
    obj?.download_url,
    obj?.downloadUrl,
    obj?.dl,
    obj?.link,
    obj?.direct_url,
    obj?.directUrl,
    obj?.file_url,
    obj?.fileUrl,
    obj?.data,
  ];

  return (
    possibleUrls.find(isValidUrl) ||
    null
  );
}

////////////////////////////
// Cari URL download rekursif
////////////////////////////
function findDownloadUrl(
  value,
  depth = 0
) {
  if (
    value === null ||
    value === undefined ||
    depth > 6
  ) {
    return null;
  }

  if (
    typeof value === "string"
  ) {
    return isValidUrl(value)
      ? value
      : null;
  }

  if (
    Array.isArray(value)
  ) {
    for (const item of value) {
      const found =
        findDownloadUrl(
          item,
          depth + 1
        );

      if (found) return found;
    }

    return null;
  }

  if (
    typeof value === "object"
  ) {
    const direct =
      getUrlFromObject(value);

    if (direct) {
      return direct;
    }

    for (
      const child of
      Object.values(value)
    ) {
      const found =
        findDownloadUrl(
          child,
          depth + 1
        );

      if (found) return found;
    }
  }

  return null;
}

////////////////////////////
// Ambil nama file
////////////////////////////
function getFilename(data) {
  const possibleNames = [
    data?.fileName,
    data?.filename,
    data?.name,
    data?.title,

    data?.data?.fileName,
    data?.data?.filename,
    data?.data?.name,
    data?.data?.title,

    data?.result?.fileName,
    data?.result?.filename,
    data?.result?.name,
    data?.result?.title,

    data?.data?.result?.fileName,
    data?.data?.result?.filename,
    data?.data?.result?.name,
    data?.data?.result?.title,
  ];

  const filename =
    possibleNames.find(
      (value) =>
        typeof value === "string" &&
        value.trim()
    );

  return filename
    ? filename.trim()
    : "gdrive.file";
}

////////////////////////////
// Ambil MIME type
////////////////////////////
function getMimeType(data) {
  const possibleMimes = [
    data?.mimetype,
    data?.mime,
    data?.mimeType,
    data?.content_type,
    data?.contentType,

    data?.data?.mimetype,
    data?.data?.mime,
    data?.data?.mimeType,
    data?.data?.content_type,
    data?.data?.contentType,

    data?.result?.mimetype,
    data?.result?.mime,
    data?.result?.mimeType,
    data?.result?.content_type,
    data?.result?.contentType,

    data?.data?.result?.mimetype,
    data?.data?.result?.mime,
    data?.data?.result?.mimeType,
  ];

  const mime =
    possibleMimes.find(
      (value) =>
        typeof value === "string" &&
        value.trim()
    );

  return mime
    ? mime.trim()
    : "application/octet-stream";
}

////////////////////////////
// Ambil ukuran file
////////////////////////////
function getFileSize(data) {
  const possibleSizes = [
    data?.fileSize,
    data?.filesize,
    data?.size,
    data?.size_bytes,
    data?.sizeBytes,

    data?.data?.fileSize,
    data?.data?.filesize,
    data?.data?.size,
    data?.data?.size_bytes,
    data?.data?.sizeBytes,

    data?.result?.fileSize,
    data?.result?.filesize,
    data?.result?.size,
    data?.result?.size_bytes,
    data?.result?.sizeBytes,

    data?.data?.result?.fileSize,
    data?.data?.result?.filesize,
    data?.data?.result?.size,
  ];

  const size =
    possibleSizes.find(
      (value) =>
        value !== null &&
        value !== undefined &&
        value !== ""
    );

  return formatFileSize(size);
}

////////////////////////////
// Ambil URL hasil API
////////////////////////////
function getDownloadUrl(data) {
  const knownValues = [
    data?.url,
    data?.download,
    data?.download_url,
    data?.downloadUrl,
    data?.dl,
    data?.link,

    data?.data,
    data?.data?.url,
    data?.data?.download,
    data?.data?.download_url,
    data?.data?.downloadUrl,
    data?.data?.dl,
    data?.data?.link,

    data?.result,
    data?.result?.url,
    data?.result?.download,
    data?.result?.download_url,
    data?.result?.downloadUrl,
    data?.result?.dl,
    data?.result?.link,

    data?.data?.result,
    data?.data?.result?.url,
    data?.data?.result?.download,
    data?.data?.result?.download_url,
    data?.data?.result?.downloadUrl,
    data?.data?.result?.dl,
  ];

  for (
    const value of knownValues
  ) {
    const found =
      findDownloadUrl(value);

    if (found) return found;
  }

  return findDownloadUrl(data);
}

////////////////////////////
// JagoanProject GDrive DL
////////////////////////////
async function fetchGDrive(url) {
  if (!global.jagoanApi) {
    throw new Error(
      "Config belum lengkap: global.jagoanApi belum di-set."
    );
  }

  if (!global.jagoanKey) {
    throw new Error(
      "Config belum lengkap: global.jagoanKey belum di-set."
    );
  }

  const baseUrl =
    String(global.jagoanApi)
      .trim()
      .replace(/\/+$/, "");

  const apiKey =
    String(global.jagoanKey)
      .trim();

  if (!apiKey) {
    throw new Error(
      "API key JagoanProject kosong."
    );
  }

  if (!isGDriveUrl(url)) {
    throw new Error(
      "URL Google Drive tidak valid."
    );
  }

  const endpoint =
    `${baseUrl}/api/downloader/gdrivedl` +
    `?q=${encodeURIComponent(url)}`;

  const response =
    await axios.get(
      endpoint,
      {
        headers: {
          Authorization:
            `Bearer ${apiKey}`,
          Accept:
            "application/json",
          "User-Agent":
            "Mozilla/5.0",
        },
        timeout: 120000,
        validateStatus: () => true,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
      }
    );

  const data =
    response.data;

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    const errorData =
      typeof data === "string"
        ? data
        : JSON.stringify(data);

    throw new Error(
      `JagoanProject HTTP ${response.status}: ` +
      errorData.slice(0, 500)
    );
  }

  if (
    data?.status === false ||
    data?.success === false
  ) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      "Gagal mengambil data Google Drive."
    );
  }

  const downloadUrl =
    getDownloadUrl(data);

  if (!downloadUrl) {
    throw new Error(
      "Link download tidak ditemukan: " +
      JSON.stringify(data).slice(0, 700)
    );
  }

  const filename =
    getFilename(data);

  const size =
    getFileSize(data);

  const mime =
    getMimeType(data);

  console.log(
    "[JagoanProject GDrive] Berhasil:",
    {
      filename,
      size,
      mime,
      downloadUrl,
    }
  );

  return {
    dl: downloadUrl,
    filename,
    size,
    mime,
  };
}

////////////////////////////
// Download file ke buffer
////////////////////////////
async function downloadFileBuffer(
  url
) {
  const response =
    await axios.get(
      url,
      {
        responseType:
          "arraybuffer",
        timeout: 300000,
        validateStatus:
          () => true,
        maxBodyLength:
          Infinity,
        maxContentLength:
          Infinity,
        maxRedirects: 10,
        headers: {
          Accept: "*/*",
          "User-Agent":
            "Mozilla/5.0",
        },
      }
    );

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    throw new Error(
      `Gagal download file HTTP ${response.status}`
    );
  }

  const buffer =
    Buffer.from(response.data);

  if (!buffer.length) {
    throw new Error(
      "File hasil download kosong."
    );
  }

  return buffer;
}

////////////////////////////
// Kirim file sesuai MIME
////////////////////////////
async function sendGDriveFile({
  wafproject,
  chat,
  downloadUrl,
  filename,
  mime,
  caption,
  quoted,
}) {
  const messageOptions = {
    quoted,
  };

  try {
    if (
      /^video\//i.test(mime)
    ) {
      return await wafproject.sendMessage(
        chat,
        {
          video: {
            url: downloadUrl,
          },
          mimetype: mime,
          fileName: filename,
          caption,
        },
        messageOptions
      );
    }

    if (
      /^image\//i.test(mime)
    ) {
      return await wafproject.sendMessage(
        chat,
        {
          image: {
            url: downloadUrl,
          },
          mimetype: mime,
          fileName: filename,
          caption,
        },
        messageOptions
      );
    }

    if (
      /^audio\//i.test(mime)
    ) {
      return await wafproject.sendMessage(
        chat,
        {
          audio: {
            url: downloadUrl,
          },
          mimetype: mime,
          fileName: filename,
        },
        messageOptions
      );
    }

    return await wafproject.sendMessage(
      chat,
      {
        document: {
          url: downloadUrl,
        },
        mimetype: mime,
        fileName: filename,
        caption,
      },
      messageOptions
    );
  } catch (error) {
    console.log(
      "[GDrive] Kirim via URL gagal, mencoba buffer:",
      error?.message || error
    );

    const buffer =
      await downloadFileBuffer(
        downloadUrl
      );

    if (
      /^video\//i.test(mime)
    ) {
      return wafproject.sendMessage(
        chat,
        {
          video: buffer,
          mimetype: mime,
          fileName: filename,
          caption,
        },
        messageOptions
      );
    }

    if (
      /^image\//i.test(mime)
    ) {
      return wafproject.sendMessage(
        chat,
        {
          image: buffer,
          mimetype: mime,
          fileName: filename,
          caption,
        },
        messageOptions
      );
    }

    if (
      /^audio\//i.test(mime)
    ) {
      return wafproject.sendMessage(
        chat,
        {
          audio: buffer,
          mimetype: mime,
          fileName: filename,
        },
        messageOptions
      );
    }

    return wafproject.sendMessage(
      chat,
      {
        document: buffer,
        mimetype: mime,
        fileName: filename,
        caption,
      },
      messageOptions
    );
  }
}

////////////////////////////
// Handler
////////////////////////////
let handler = async (
  m,
  {
    wafproject,
    command,
    text,
    usedPrefix,
  }
) => {
  const url =
    String(text || "").trim();

  if (!url) {
    return m.reply(
      "📌 *Cara pakai:*\n" +
      `${usedPrefix + command} <link Google Drive>\n\n` +
      "Contoh:\n" +
      `${usedPrefix + command} https://drive.google.com/file/d/xxxx/view`
    );
  }

  if (!isGDriveUrl(url)) {
    return m.reply(
      "❌ Link tidak valid. Kirim link Google Drive."
    );
  }

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Tambahkan konfigurasi berikut di config.js:\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";'
    );
  }

  const react =
    async (emoji) => {
      try {
        await wafproject.sendMessage(
          m.chat,
          {
            react: {
              text: emoji,
              key: m.key,
            },
          }
        );
      } catch (_error) { console.error("[ERROR][commands/downloader/gdrive.js]", _error?.message || _error) }
    };

  let statusMessage;

  const sendStatus =
    async (message) => {
      try {
        statusMessage =
          await wafproject.sendMessage(
            m.chat,
            {
              text: message,
            },
            {
              quote: m,
            }
          );

        return statusMessage;
      } catch {
        return null;
      }
    };

  const editStatus =
    async (message) => {
      if (!statusMessage?.key) {
        return null;
      }

      try {
        return await wafproject.sendMessage(
          m.chat,
          {
            text: message,
            edit:
              statusMessage.key,
          }
        );
      } catch {
        return null;
      }
    };

  try {
    await react("🕒");

    await sendStatus(
      "☁️ *Google Drive Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "🔗 Link diterima ✅\n" +
      "⚙️ Source: *JagoanProject GDrive DL*\n" +
      "🔎 Mengambil informasi file... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    const {
      dl,
      filename,
      size,
      mime,
    } = await fetchGDrive(url);

    await editStatus(
      "☁️ *Google Drive Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ File ditemukan!\n" +
      `📄 File: *${filename}*\n` +
      `📦 Size: *${size}*\n` +
      "📤 Mengirim file... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    const safeFilename =
      String(filename)
        .replace(/[\r\n]+/g, " ")
        .trim()
        .slice(0, 200);

    const safeMime =
      String(mime)
        .replace(/[\r\n]+/g, " ")
        .trim()
        .slice(0, 100);

    const caption =
      "乂  *G D R I V E*\n\n" +
      `∘ *File* : ${safeFilename}\n` +
      `∘ *Size* : ${size}\n` +
      `∘ *Mime* : ${safeMime}\n` +
      "∘ *Source* : JagoanProject\n" +
      `∘ *URL* : ${url}`;

    await sendGDriveFile({
      wafproject,
      chat: m.chat,
      downloadUrl: dl,
      filename: safeFilename,
      mime: safeMime,
      caption,
      quoted: m,
    });

    await editStatus(
      "☁️ *Google Drive Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ File berhasil dikirim!\n" +
      `📄 File: *${safeFilename}*\n` +
      `📦 Size: *${size}*\n` +
      "━━━━━━━━━━━━━━━━━━"
    );

    await react("✅");
  } catch (error) {
    console.error(
      "[JagoanProject GDrive Error]",
      error
    );

    await react("❌");

    const errorMessage =
      String(
        error?.message ||
        error
      )
        .replace(
          String(
            global.jagoanKey ||
            ""
          ),
          "[API_KEY]"
        )
        .slice(0, 500);

    const edited =
      await editStatus(
        "☁️ *Google Drive Downloader*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "❌ Download gagal!\n" +
        `📌 ${errorMessage}\n` +
        "━━━━━━━━━━━━━━━━━━"
      );

    if (!edited) {
      return m.reply(
        "❌ *GDrive Downloader gagal:*\n" +
        errorMessage
      );
    }
  }
};

handler.help = [
  "gdrive <url>",
];

handler.tags = [
  "downloader",
];

handler.category = [
  "downloader",
];

handler.command = [
  "gdrive",
];

handler.limit = true;
handler.register = true;

module.exports = handler;