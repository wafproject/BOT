/**
 * Spotify Downloader - JagoanProject
 *
 * Endpoint:
 * GET https://api.jagoanproject.com/api/downloader/spotifydl?q=<query>
 *
 * Header:
 * Authorization: Bearer APIKEY
 *
 * config.js / settings.js:
 * global.jagoanApi = "https://api.jagoanproject.com";
 * global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";
 *
 * Command:
 * .spotify <judul / query / link>
 * .spotifydl <judul / query / link>
 * .spdl <judul / query / link>
 */

const axios = require("axios");
const { fromBuffer } = require("../../lib/file-type.js");

//////////////////////////////////////////////////
// VALIDASI URL UMUM
//////////////////////////////////////////////////

function isValidUrl(value) {
  return (
    typeof value === "string" &&
    /^https?:\/\//i.test(value.trim())
  );
}

//////////////////////////////////////////////////
// URL SPOTIFY
//////////////////////////////////////////////////

function isSpotifyUrl(value = "") {
  if (!isValidUrl(value)) {
    return false;
  }

  try {
    const parsed = new URL(value);

    const host = parsed.hostname
      .toLowerCase()
      .replace(/^www\./, "");

    return (
      host === "spotify.com" ||
      host.endsWith(".spotify.com") ||
      host === "open.spotify.com"
    );
  } catch {
    return false;
  }
}

//////////////////////////////////////////////////
// BERSIHKAN TEXT
//////////////////////////////////////////////////

function cleanText(value, fallback = "") {
  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    return fallback;
  }

  return value
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

//////////////////////////////////////////////////
// SAFE FILENAME
//////////////////////////////////////////////////

function safeFileName(value = "") {
  const result = cleanText(
    value,
    "spotify"
  )
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 100);

  return result || "spotify";
}

//////////////////////////////////////////////////
// FORMAT DURASI
//////////////////////////////////////////////////

function formatDuration(value) {
  if (
    value === undefined ||
    value === null ||
    value === ""
  ) {
    return "";
  }

  let number = Number(value);

  if (!Number.isFinite(number)) {
    return cleanText(
      String(value),
      ""
    );
  }

  /*
   * Spotify sering memakai duration_ms.
   */
  if (number > 10000) {
    number =
      Math.floor(number / 1000);
  }

  number =
    Math.floor(number);

  const hours =
    Math.floor(number / 3600);

  const minutes =
    Math.floor(
      (number % 3600) / 60
    );

  const seconds =
    number % 60;

  if (hours > 0) {
    return (
      `${hours}:` +
      `${String(minutes).padStart(2, "0")}:` +
      `${String(seconds).padStart(2, "0")}`
    );
  }

  return (
    `${minutes}:` +
    `${String(seconds).padStart(2, "0")}`
  );
}

//////////////////////////////////////////////////
// AMBIL URL AUDIO DARI OBJECT
//////////////////////////////////////////////////

function getAudioUrlFromItem(item) {
  if (!item) {
    return null;
  }

  /*
   * String URL langsung.
   * Jangan anggap open.spotify.com sebagai
   * file audio.
   */
  if (
    typeof item === "string" &&
    isValidUrl(item) &&
    !isSpotifyUrl(item)
  ) {
    return item;
  }

  if (typeof item !== "object") {
    return null;
  }

  /*
   * Urutan sangat penting.
   * Field download/audio didahulukan sebelum url.
   */
  const possibleUrls = [
    item?.download,
    item?.download_url,
    item?.downloadUrl,
    item?.downloadURL,

    item?.audio,
    item?.audio_url,
    item?.audioUrl,
    item?.audioURL,

    item?.mp3,
    item?.mp3_url,
    item?.mp3Url,

    item?.music,
    item?.music_url,
    item?.musicUrl,

    item?.play,
    item?.play_url,
    item?.playUrl,

    item?.stream,
    item?.stream_url,
    item?.streamUrl,

    item?.file,
    item?.file_url,
    item?.fileUrl,

    item?.link,
    item?.src,

    item?.url,
  ];

  for (const url of possibleUrls) {
    if (
      isValidUrl(url) &&
      !isSpotifyUrl(url)
    ) {
      return url;
    }
  }

  return null;
}

//////////////////////////////////////////////////
// COVER / THUMBNAIL
//////////////////////////////////////////////////

function getCoverFromItem(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return null;
  }

  const possibleUrls = [
    item?.thumbnail,
    item?.thumbnail_url,
    item?.thumbnailUrl,

    item?.cover,
    item?.cover_url,
    item?.coverUrl,

    item?.image,
    item?.image_url,
    item?.imageUrl,

    item?.artwork,
    item?.artwork_url,
    item?.artworkUrl,

    item?.album_image,
    item?.albumImage,
  ];

  return (
    possibleUrls.find(
      isValidUrl
    ) ||
    null
  );
}

//////////////////////////////////////////////////
// TITLE
//////////////////////////////////////////////////

function getTitleFromItem(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return cleanText(
    item?.title ||
    item?.name ||
    item?.track ||
    item?.track_name ||
    item?.trackName ||
    item?.song ||
    item?.song_name ||
    item?.songName ||
    ""
  );
}

//////////////////////////////////////////////////
// ARTIST
//////////////////////////////////////////////////

function getArtistFromItem(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  const artist =
    item?.artist ||
    item?.artists ||
    item?.author ||
    item?.singer ||
    item?.creator ||
    item?.artist_name ||
    item?.artistName ||
    "";

  if (Array.isArray(artist)) {
    return artist
      .map((value) => {
        if (
          typeof value === "string"
        ) {
          return cleanText(
            value,
            ""
          );
        }

        if (
          value &&
          typeof value === "object"
        ) {
          return cleanText(
            value?.name ||
            value?.artist ||
            "",
            ""
          );
        }

        return "";
      })
      .filter(Boolean)
      .join(", ");
  }

  if (
    artist &&
    typeof artist === "object"
  ) {
    return cleanText(
      artist?.name ||
      artist?.artist ||
      ""
    );
  }

  return cleanText(
    String(artist || ""),
    ""
  );
}

//////////////////////////////////////////////////
// ALBUM
//////////////////////////////////////////////////

function getAlbumFromItem(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  const album =
    item?.album ||
    item?.album_name ||
    item?.albumName ||
    "";

  if (
    album &&
    typeof album === "object"
  ) {
    return cleanText(
      album?.name ||
      album?.title ||
      ""
    );
  }

  return cleanText(
    String(album || ""),
    ""
  );
}

//////////////////////////////////////////////////
// DURASI
//////////////////////////////////////////////////

function getDurationFromItem(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return formatDuration(
    item?.duration_ms ??
    item?.durationMs ??
    item?.duration ??
    item?.length ??
    ""
  );
}

//////////////////////////////////////////////////
// NORMALISASI TRACK
//////////////////////////////////////////////////

function normalizeTrack(item) {
  if (!item) {
    return null;
  }

  if (typeof item === "string") {
    const audioUrl =
      getAudioUrlFromItem(item);

    if (!audioUrl) {
      return null;
    }

    return {
      audioUrl,
      title: "",
      artist: "",
      album: "",
      duration: "",
      cover: null,
      raw: item,
    };
  }

  if (typeof item !== "object") {
    return null;
  }

  const audioUrl =
    getAudioUrlFromItem(item);

  if (!audioUrl) {
    return null;
  }

  return {
    audioUrl,

    title:
      getTitleFromItem(item),

    artist:
      getArtistFromItem(item),

    album:
      getAlbumFromItem(item),

    duration:
      getDurationFromItem(item),

    cover:
      getCoverFromItem(item),

    raw:
      item,
  };
}

//////////////////////////////////////////////////
// CARI TRACK DI ARRAY
//////////////////////////////////////////////////

function extractFromArray(items) {
  if (
    !Array.isArray(items) ||
    !items.length
  ) {
    return null;
  }

  for (const item of items) {
    const track =
      normalizeTrack(item);

    if (track?.audioUrl) {
      return track;
    }
  }

  return null;
}

//////////////////////////////////////////////////
// EXTRACT TRACK DARI RESPONSE
//////////////////////////////////////////////////

function extractSpotifyTrack(data) {
  /*
   * Struktur yang paling umum.
   */
  const knownArrays = [
    data?.data?.results,
    data?.data?.tracks,
    data?.data?.songs,
    data?.data?.items,
    data?.data?.downloads,

    data?.result?.results,
    data?.result?.tracks,
    data?.result?.songs,
    data?.result?.items,
    data?.result?.downloads,

    data?.results,
    data?.tracks,
    data?.songs,
    data?.items,
    data?.downloads,
  ];

  for (const items of knownArrays) {
    const track =
      extractFromArray(items);

    if (track?.audioUrl) {
      return track;
    }
  }

  /*
   * Object langsung.
   */
  const knownObjects = [
    data?.data?.result,
    data?.data?.track,
    data?.data?.song,
    data?.data,

    data?.result?.track,
    data?.result?.song,
    data?.result,

    data?.track,
    data?.song,

    data,
  ];

  for (const item of knownObjects) {
    const track =
      normalizeTrack(item);

    if (track?.audioUrl) {
      return track;
    }
  }

  return null;
}

//////////////////////////////////////////////////
// METADATA FALLBACK
//////////////////////////////////////////////////

function mergeMetadata(track, data) {
  const possibleObjects = [
    data?.data?.result,
    data?.data?.track,
    data?.data?.song,
    data?.data,

    data?.result?.track,
    data?.result?.song,
    data?.result,

    data?.track,
    data?.song,

    data,
  ].filter(
    (item) =>
      item &&
      typeof item === "object"
  );

  for (const item of possibleObjects) {
    if (!track.title) {
      track.title =
        getTitleFromItem(item);
    }

    if (!track.artist) {
      track.artist =
        getArtistFromItem(item);
    }

    if (!track.album) {
      track.album =
        getAlbumFromItem(item);
    }

    if (!track.duration) {
      track.duration =
        getDurationFromItem(item);
    }

    if (!track.cover) {
      track.cover =
        getCoverFromItem(item);
    }
  }

  return track;
}

//////////////////////////////////////////////////
// REQUEST JAGOANPROJECT
//////////////////////////////////////////////////

async function fetchSpotify(query) {
  if (!global.jagoanApi) {
    throw new Error(
      "Config belum lengkap: global.jagoanApi belum di-set."
    );
  }

  if (!global.jagoanKey) {
    throw new Error(
      "Config belum lengkap: global.jagoanKey belum di-set."
    );
  }

  const baseUrl =
    String(global.jagoanApi)
      .trim()
      .replace(/\/+$/, "");

  const apiKey =
    String(global.jagoanKey)
      .trim();

  if (!apiKey) {
    throw new Error(
      "API key JagoanProject kosong."
    );
  }

  const search =
    cleanText(
      query,
      ""
    );

  if (!search) {
    throw new Error(
      "Judul lagu / query Spotify kosong."
    );
  }

  /*
   * Endpoint sesuai contoh dashboard:
   *
   * /api/downloader/spotifydl?q=
   */

  const endpoint =
    `${baseUrl}/api/downloader/spotifydl` +
    `?q=${encodeURIComponent(search)}`;

  console.log(
    "[Spotify Downloader] Query:",
    search
  );

  console.log(
    "[Spotify Downloader] Endpoint:",
    `${baseUrl}/api/downloader/spotifydl`
  );

  /*
   * Request sengaja dibuat mengikuti contoh
   * Axios dari dashboard JagoanProject.
   */

  const response =
    await axios({
      method:
        "get",

      url:
        endpoint,

      headers: {
        Authorization:
          `Bearer ${apiKey}`,
      },

      timeout:
        180000,

      validateStatus:
        () => true,

      maxBodyLength:
        Infinity,

      maxContentLength:
        Infinity,
    });

  const data =
    response.data;

  console.log(
    "[Spotify Downloader] HTTP:",
    response.status
  );

  //////////////////////////////////////////////////
  // HTTP ERROR
  //////////////////////////////////////////////////

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    console.error(
      "[Spotify Downloader] API HTTP ERROR:",
      JSON.stringify(
        data,
        null,
        2
      )
    );

    throw new Error(
      cleanText(
        data?.message ||
        data?.msg ||
        data?.error ||
        `JagoanProject HTTP ${response.status}`
      )
    );
  }

  //////////////////////////////////////////////////
  // API ERROR
  //////////////////////////////////////////////////

  if (
    data?.status === false ||
    data?.success === false
  ) {
    console.error(
      "[Spotify Downloader] API FAILED:",
      JSON.stringify(
        data,
        null,
        2
      )
    );

    throw new Error(
      cleanText(
        data?.message ||
        data?.msg ||
        data?.error ||
        "Gagal mengambil lagu Spotify."
      )
    );
  }

  //////////////////////////////////////////////////
  // EXTRACT TRACK
  //////////////////////////////////////////////////

  let track =
    extractSpotifyTrack(
      data
    );

  if (!track?.audioUrl) {
    console.error(
      "[Spotify Downloader] AUDIO TIDAK DITEMUKAN:"
    );

    console.error(
      JSON.stringify(
        data,
        null,
        2
      )
    );

    throw new Error(
      "URL audio tidak ditemukan dari response JagoanProject."
    );
  }

  track =
    mergeMetadata(
      track,
      data
    );

  if (!track.title) {
    track.title =
      search;
  }

  console.log(
    "[Spotify Downloader] SUCCESS:",
    {
      title:
        track.title,

      artist:
        track.artist,

      album:
        track.album,

      duration:
        track.duration,

      hasCover:
        Boolean(track.cover),

      audioUrl:
        track.audioUrl,
    }
  );

  return {
    ...track,

    creator:
      data?.creator ||
      "Jagoan Project",
  };
}

//////////////////////////////////////////////////
// DOWNLOAD AUDIO KE BUFFER
//////////////////////////////////////////////////

async function downloadAudioBuffer(url) {
  if (!isValidUrl(url)) {
    throw new Error(
      "URL audio tidak valid."
    );
  }

  const response =
    await axios.get(
      url,
      {
        responseType:
          "arraybuffer",

        timeout:
          180000,

        validateStatus:
          () => true,

        maxBodyLength:
          Infinity,

        maxContentLength:
          Infinity,

        maxRedirects:
          10,

        headers: {
          Accept:
            "audio/*,*/*",

          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        },
      }
    );

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    throw new Error(
      `Server audio HTTP ${response.status}`
    );
  }

  const buffer =
    Buffer.from(
      response.data
    );

  if (!buffer.length) {
    throw new Error(
      "File audio kosong."
    );
  }

  const fileType =
    (await fromBuffer(buffer)) ||
    {};

  const contentType =
    String(
      response.headers?.["content-type"] ||
      ""
    )
      .split(";")[0]
      .trim()
      .toLowerCase();

  const mime =
    String(
      fileType?.mime ||
      contentType ||
      ""
    ).toLowerCase();

  const ext =
    String(
      fileType?.ext ||
      ""
    ).toLowerCase();

  /*
   * Hindari HTML error page dikirim sebagai lagu.
   */
  if (
    mime.includes("text/html") ||
    mime.includes(
      "application/json"
    )
  ) {
    throw new Error(
      `Server mengembalikan ${mime}, bukan audio.`
    );
  }

  return {
    buffer,

    mime:
      mime.startsWith("audio/")
        ? mime
        : "audio/mpeg",

    ext:
      ext || "mp3",

    sizeMb:
      (
        buffer.length /
        1024 /
        1024
      ).toFixed(2),
  };
}

//////////////////////////////////////////////////
// KIRIM COVER + INFO
//////////////////////////////////////////////////

async function sendTrackInfo({
  wafproject,
  chat,
  result,
  quoted,
}) {
  const title =
    cleanText(
      result.title,
      "Spotify Track"
    );

  const artist =
    cleanText(
      result.artist,
      ""
    );

  const album =
    cleanText(
      result.album,
      ""
    );

  const duration =
    cleanText(
      result.duration,
      ""
    );

  let caption =
    "🎧 *Spotify Downloader*\n" +
    "━━━━━━━━━━━━━━━━━━\n" +
    `🎵 *Judul:* ${title}`;

  if (artist) {
    caption +=
      `\n👤 *Artist:* ${artist}`;
  }

  if (album) {
    caption +=
      `\n💿 *Album:* ${album}`;
  }

  if (duration) {
    caption +=
      `\n⏱️ *Durasi:* ${duration}`;
  }

  caption +=
    "\n━━━━━━━━━━━━━━━━━━";

  /*
   * Kalau ada cover, kirim cover.
   * Kalau tidak, info cukup ikut caption audio.
   */

  if (
    result.cover &&
    isValidUrl(result.cover)
  ) {
    try {
      await wafproject.sendMessage(
        chat,
        {
          image: {
            url:
              result.cover,
          },

          caption,
        },
        {
          quoted,
        }
      );

      return true;
    } catch (error) {
      console.error(
        "[Spotify Downloader] Cover gagal:",
        error?.message ||
        error
      );
    }
  }

  return false;
}

//////////////////////////////////////////////////
// KIRIM AUDIO
//////////////////////////////////////////////////

async function sendAudio({
  wafproject,
  chat,
  result,
  media,
  quoted,
  includeCaption = false,
}) {
  const baseName =
    safeFileName(
      result.artist
        ? `${result.artist} - ${result.title}`
        : result.title
    );

  let caption =
    "";

  if (includeCaption) {
    caption =
      "🎧 *Spotify Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `🎵 *Judul:* ${result.title || "Spotify Track"}`;

    if (result.artist) {
      caption +=
        `\n👤 *Artist:* ${result.artist}`;
    }

    if (result.album) {
      caption +=
        `\n💿 *Album:* ${result.album}`;
    }

    if (result.duration) {
      caption +=
        `\n⏱️ *Durasi:* ${result.duration}`;
    }
  }

  /*
   * ptt: false supaya menjadi audio/music,
   * bukan voice note.
   */

  return wafproject.sendMessage(
    chat,
    {
      audio:
        media.buffer,

      mimetype:
        media.mime ||
        "audio/mpeg",

      fileName:
        `${baseName}.${media.ext || "mp3"}`,

      ptt:
        false,

      ...(caption
        ? {
            caption,
          }
        : {}),
    },
    {
      quoted,
    }
  );
}

//////////////////////////////////////////////////
// REACTION
//////////////////////////////////////////////////

async function react(
  wafproject,
  m,
  emoji
) {
  try {
    await wafproject.sendMessage(
      m.chat,
      {
        react: {
          text:
            emoji,

          key:
            m.key,
        },
      }
    );
  } catch {
    // Reaction gagal tidak menggagalkan downloader
  }
}

//////////////////////////////////////////////////
// SAFE ERROR
//////////////////////////////////////////////////

function safeErrorMessage(error) {
  let message =
    cleanText(
      error?.message ||
      String(error || "") ||
      "Terjadi kesalahan."
    );

  /*
   * Jangan bocorkan API key.
   */
  if (global.jagoanKey) {
    message =
      message.replaceAll(
        String(
          global.jagoanKey
        ),
        "[API_KEY]"
      );
  }

  const lower =
    message.toLowerCase();

  if (
    lower.includes("not found") ||
    lower.includes(
      "tidak ditemukan"
    )
  ) {
    return (
      "Lagu tidak ditemukan. " +
      "Coba gunakan judul lagu dan nama artist yang lebih lengkap."
    );
  }

  if (
    lower.includes("limit") &&
    lower.includes(
      "dikembalikan"
    )
  ) {
    return (
      "Request gagal diproses JagoanProject, " +
      "tetapi limit sudah dikembalikan."
    );
  }

  return message.slice(
    0,
    400
  );
}

//////////////////////////////////////////////////
// HANDLER
//////////////////////////////////////////////////

let handler = async (
  m,
  {
    wafproject,
    command,
    text,
    usedPrefix,
  }
) => {
  const query =
    cleanText(
      text,
      ""
    );

  //////////////////////////////////////////////////
  // QUERY KOSONG
  //////////////////////////////////////////////////

  if (!query) {
    return m.reply(
      "🎧 *SPOTIFY DOWNLOADER*\n\n" +
      "Cari dan download lagu Spotify.\n\n" +
      "*Contoh:*\n" +
      `${usedPrefix + command} jagoan project\n\n` +
      `${usedPrefix + command} Bruno Mars Die With A Smile`
    );
  }

  //////////////////////////////////////////////////
  // CONFIG
  //////////////////////////////////////////////////

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Konfigurasi JagoanProject belum lengkap.\n\n" +
      "Tambahkan di config.js / settings.js:\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";'
    );
  }

  //////////////////////////////////////////////////
  // STATUS MESSAGE
  //////////////////////////////////////////////////

  let statusMessage =
    null;

  const sendStatus =
    async (message) => {
      try {
        statusMessage =
          await wafproject.sendMessage(
            m.chat,
            {
              text:
                message,
            },
            {
              quoted:
                m,
            }
          );

        return statusMessage;
      } catch (error) {
        console.error(
          "[Spotify Downloader] sendStatus:",
          error?.message ||
          error
        );

        return null;
      }
    };

  const editStatus =
    async (message) => {
      if (
        !statusMessage?.key
      ) {
        return null;
      }

      try {
        return await wafproject.sendMessage(
          m.chat,
          {
            text:
              message,

            edit:
              statusMessage.key,
          }
        );
      } catch (error) {
        console.error(
          "[Spotify Downloader] editStatus:",
          error?.message ||
          error
        );

        return null;
      }
    };

  //////////////////////////////////////////////////
  // PROCESS
  //////////////////////////////////////////////////

  try {
    await react(
      wafproject,
      m,
      "🕒"
    );

    await sendStatus(
      "🎧 *Spotify Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `🔎 Mencari: *${query.slice(0, 100)}*\n` +
      "🎵 Mengambil informasi lagu... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    //////////////////////////////////////////////////
    // REQUEST API
    //////////////////////////////////////////////////

    const result =
      await fetchSpotify(
        query
      );

    await editStatus(
      "🎧 *Spotify Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Lagu ditemukan!\n" +
      `🎵 *${result.title || "Spotify Track"}*\n` +
      (
        result.artist
          ? `👤 ${result.artist}\n`
          : ""
      ) +
      "⬇️ Mengunduh audio... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    //////////////////////////////////////////////////
    // DOWNLOAD AUDIO
    //////////////////////////////////////////////////

    const media =
      await downloadAudioBuffer(
        result.audioUrl
      );

    await editStatus(
      "🎧 *Spotify Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Audio berhasil diunduh!\n" +
      `📦 Ukuran: *${media.sizeMb} MB*\n` +
      "📤 Mengirim lagu... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    //////////////////////////////////////////////////
    // TRACK INFO / COVER
    //////////////////////////////////////////////////

    const coverSent =
      await sendTrackInfo({
        wafproject,

        chat:
          m.chat,

        result,

        quoted:
          m,
      });

    //////////////////////////////////////////////////
    // SEND AUDIO
    //////////////////////////////////////////////////

    await sendAudio({
      wafproject,

      chat:
        m.chat,

      result,

      media,

      quoted:
        coverSent
          ? undefined
          : m,

      includeCaption:
        !coverSent,
    });

    //////////////////////////////////////////////////
    // DONE
    //////////////////////////////////////////////////

    await editStatus(
      "🎧 *Spotify Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Lagu berhasil dikirim!\n" +
      `🎵 *${result.title || "Spotify Track"}*\n` +
      (
        result.artist
          ? `👤 *${result.artist}*\n`
          : ""
      ) +
      `📦 Ukuran: *${media.sizeMb} MB*\n` +
      "━━━━━━━━━━━━━━━━━━"
    );

    await react(
      wafproject,
      m,
      "✅"
    );
  } catch (error) {
    console.error(
      "[JagoanProject Spotify Error]",
      error
    );

    await react(
      wafproject,
      m,
      "❌"
    );

    const errorMessage =
      safeErrorMessage(
        error
      );

    const message =
      "🎧 *Spotify Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "❌ Download gagal!\n\n" +
      `📌 ${errorMessage}\n` +
      "━━━━━━━━━━━━━━━━━━";

    const edited =
      await editStatus(
        message
      );

    if (!edited) {
      return m.reply(
        message
      );
    }
  }
};

//////////////////////////////////////////////////
// PLUGIN INFO
//////////////////////////////////////////////////

handler.help = [
  "spotify <judul>",
  "spotifydl <judul>",
  "spdl <judul>",
];

handler.tags = [
  "downloader",
];

handler.category = [
  "downloader",
];

handler.command = [
  "spotify",
  "spotifydl",
  "spdl",
];

handler.limit = true;
handler.register = true;

module.exports = handler;