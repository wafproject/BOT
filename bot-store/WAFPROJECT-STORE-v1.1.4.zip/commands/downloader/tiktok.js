
/**
 * TikTok Downloader - JagoanProject
 *
 * Endpoint:
 * GET https://api.jagoanproject.com/api/downloader/tiktokdl?q=<tiktokUrl>
 *
 * Header:
 * Authorization: Bearer APIKEY
 *
 * config.js / settings.js:
 * global.jagoanApi = "https://api.jagoanproject.com";
 * global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";
 *
 * Command:
 * .tt <url>
 * .tikmp3 <url>
 */

const axios = require("axios");
const { fromBuffer } = require("../../lib/file-type.js");

////////////////////////////
// Validasi URL TikTok
////////////////////////////
function isTikTokUrl(url = "") {
  const value = String(url || "").trim();

  if (!value) return false;

  try {
    const parsed = new URL(value);
    const hostname = parsed.hostname.toLowerCase();

    return (
      hostname === "tiktok.com" ||
      hostname.endsWith(".tiktok.com") ||
      hostname === "vt.tiktok.com" ||
      hostname === "vm.tiktok.com"
    );
  } catch {
    return false;
  }
}

////////////////////////////
// Validasi URL umum
////////////////////////////
function isValidUrl(value) {
  return (
    typeof value === "string" &&
    /^https?:\/\//i.test(value)
  );
}

////////////////////////////
// Format angka
////////////////////////////
function formatNumber(value) {
  const number = Number(value || 0);

  return Number.isFinite(number)
    ? number.toLocaleString("id-ID")
    : "0";
}

////////////////////////////
// Bersihkan teks
////////////////////////////
function cleanText(value, fallback = "") {
  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    return fallback;
  }

  return value
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

////////////////////////////
// Ambil URL dari object
////////////////////////////
function getUrlFromItem(item) {
  if (!item) return null;

  if (
    typeof item === "string" &&
    isValidUrl(item)
  ) {
    return item;
  }

  if (typeof item !== "object") {
    return null;
  }

  const possibleUrls = [
    item?.url,
    item?.download,
    item?.download_url,
    item?.downloadUrl,
    item?.link,
    item?.src,
    item?.play,
    item?.play_url,
    item?.playUrl,
    item?.video,
    item?.video_url,
    item?.videoUrl,
    item?.audio,
    item?.audio_url,
    item?.audioUrl,
    item?.music,
    item?.music_url,
    item?.musicUrl,
  ];

  return possibleUrls.find(isValidUrl) || null;
}

////////////////////////////
// Ambil kualitas
////////////////////////////
function getQuality(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return cleanText(
    item?.quality ||
    item?.resolution ||
    item?.label ||
    item?.type ||
    ""
  );
}

////////////////////////////
// Pilih video terbaik
////////////////////////////
function pickBestVideo(items) {
  if (!Array.isArray(items)) {
    return null;
  }

  const videos = items
    .map((item) => {
      const url = getUrlFromItem(item);

      if (!url) return null;

      return {
        url,
        quality: getQuality(item),
        raw: item,
      };
    })
    .filter(Boolean);

  if (!videos.length) {
    return null;
  }

  const noWatermark = videos.find((item) => {
    const text = JSON.stringify(item.raw).toLowerCase();

    return (
      text.includes("nowm") ||
      text.includes("no_watermark") ||
      text.includes("no watermark") ||
      text.includes("without watermark")
    );
  });

  if (noWatermark) {
    return noWatermark;
  }

  const hd = videos.find((item) => {
    const quality = String(item.quality).toLowerCase();

    return (
      quality.includes("1080") ||
      quality.includes("720") ||
      quality.includes("hd")
    );
  });

  if (hd) {
    return hd;
  }

  return videos[0];
}

////////////////////////////
// Cari video dari respons API
////////////////////////////
function extractVideo(data) {
  const knownArrays = [
    data?.result?.video,
    data?.result?.videos,
    data?.result?.data?.video,
    data?.result?.data?.videos,

    data?.data?.video,
    data?.data?.videos,

    data?.video,
    data?.videos,
  ];

  for (const items of knownArrays) {
    if (Array.isArray(items)) {
      const picked = pickBestVideo(items);

      if (picked?.url) {
        return picked;
      }
    }
  }

  const knownObjects = [
    data?.result?.video,
    data?.result?.data,
    data?.result,

    data?.data?.video,
    data?.data,

    data?.video,
    data,
  ];

  for (const item of knownObjects) {
    if (!item) continue;

    if (typeof item === "string" && isValidUrl(item)) {
      return {
        url: item,
        quality: "",
        raw: item,
      };
    }

    if (typeof item !== "object") {
      continue;
    }

    const possibleUrls = [
      item?.nowm,
      item?.no_watermark,
      item?.noWatermark,
      item?.play,
      item?.play_url,
      item?.video,
      item?.video_url,
      item?.videoUrl,
      item?.url,
      item?.download,
      item?.download_url,
      item?.downloadUrl,
      item?.hd,
      item?.sd,
    ];

    const url = possibleUrls.find(isValidUrl);

    if (url) {
      return {
        url,
        quality: getQuality(item),
        raw: item,
      };
    }
  }

  return null;
}

////////////////////////////
// Cari audio dari respons API
////////////////////////////
function extractAudio(data) {
  const knownValues = [
    data?.result?.audio,
    data?.result?.music,
    data?.result?.music_info?.play,
    data?.result?.musicInfo?.play,
    data?.result?.data?.audio,
    data?.result?.data?.music,

    data?.data?.audio,
    data?.data?.music,
    data?.data?.music_info?.play,
    data?.data?.musicInfo?.play,

    data?.audio,
    data?.music,
  ];

  for (const value of knownValues) {
    if (Array.isArray(value)) {
      for (const item of value) {
        const url = getUrlFromItem(item);

        if (url) {
          return {
            url,
            title:
              cleanText(
                item?.title ||
                item?.name ||
                ""
              ),
          };
        }
      }
    }

    if (typeof value === "string" && isValidUrl(value)) {
      return {
        url: value,
        title: "",
      };
    }

    if (value && typeof value === "object") {
      const url = getUrlFromItem(value);

      if (url) {
        return {
          url,
          title:
            cleanText(
              value?.title ||
              value?.name ||
              ""
            ),
        };
      }
    }
  }

  return null;
}

////////////////////////////
// Ambil caption / title
////////////////////////////
function getTitle(data) {
  const possibleTitles = [
    data?.result?.title,
    data?.result?.caption,
    data?.result?.description,
    data?.result?.data?.title,
    data?.result?.data?.caption,

    data?.data?.title,
    data?.data?.caption,
    data?.data?.description,

    data?.title,
    data?.caption,
    data?.description,
  ];

  const title = possibleTitles.find(
    (value) =>
      typeof value === "string" &&
      value.trim()
  );

  return cleanText(title, "-");
}

////////////////////////////
// Ambil author
////////////////////////////
function getAuthor(data) {
  const possibleAuthors = [
    data?.result?.author?.nickname,
    data?.result?.author?.username,
    data?.result?.author?.unique_id,
    data?.result?.author?.uniqueId,
    data?.result?.nickname,
    data?.result?.username,

    data?.data?.author?.nickname,
    data?.data?.author?.username,
    data?.data?.author?.unique_id,
    data?.data?.nickname,
    data?.data?.username,

    data?.author?.nickname,
    data?.author?.username,
    data?.username,
  ];

  const author = possibleAuthors.find(
    (value) =>
      typeof value === "string" &&
      value.trim()
  );

  return cleanText(author, "");
}

////////////////////////////
// Ambil statistik
////////////////////////////
function getStats(data) {
  const source =
    data?.result?.stats ||
    data?.result?.statistics ||
    data?.result ||
    data?.data?.stats ||
    data?.data?.statistics ||
    data?.data ||
    data ||
    {};

  return {
    views:
      source?.play_count ||
      source?.playCount ||
      source?.views ||
      source?.view_count ||
      0,

    likes:
      source?.digg_count ||
      source?.diggCount ||
      source?.likes ||
      source?.like_count ||
      0,

    comments:
      source?.comment_count ||
      source?.commentCount ||
      source?.comments ||
      0,

    shares:
      source?.share_count ||
      source?.shareCount ||
      source?.shares ||
      0,
  };
}

////////////////////////////
// Request JagoanProject
////////////////////////////
async function fetchTikTok(url) {
  if (!global.jagoanApi) {
    throw new Error(
      "Config belum lengkap: global.jagoanApi belum di-set."
    );
  }

  if (!global.jagoanKey) {
    throw new Error(
      "Config belum lengkap: global.jagoanKey belum di-set."
    );
  }

  const baseUrl = String(global.jagoanApi)
    .trim()
    .replace(/\/+$/, "");

  const apiKey = String(global.jagoanKey).trim();

  if (!apiKey) {
    throw new Error(
      "API key JagoanProject kosong."
    );
  }

  if (!isTikTokUrl(url)) {
    throw new Error(
      "URL TikTok tidak valid."
    );
  }

  const endpoint =
    `${baseUrl}/api/downloader/tiktokdl` +
    `?q=${encodeURIComponent(url)}`;

  const response = await axios.get(endpoint, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0",
    },
    timeout: 120000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });

  const data = response.data;

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    const errorData =
      typeof data === "string"
        ? data
        : JSON.stringify(data);

    throw new Error(
      `JagoanProject HTTP ${response.status}: ` +
      errorData.slice(0, 500)
    );
  }

  if (
    data?.status === false ||
    data?.success === false
  ) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      "Gagal mengambil data TikTok."
    );
  }

  const video = extractVideo(data);
  const audio = extractAudio(data);

  if (!video?.url && !audio?.url) {
    throw new Error(
      "Video dan audio tidak ditemukan: " +
      JSON.stringify(data).slice(0, 800)
    );
  }

  return {
    video,
    audio,
    title: getTitle(data),
    author: getAuthor(data),
    stats: getStats(data),
    creator:
      data?.creator ||
      "Jagoan Project",
  };
}

////////////////////////////
// Download file ke buffer
////////////////////////////
async function downloadMediaBuffer(
  url,
  expectedType = ""
) {
  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 180000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    maxRedirects: 10,
    headers: {
      Accept: "*/*",
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      Referer: "https://www.tiktok.com/",
    },
  });

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    throw new Error(
      `Gagal download media HTTP ${response.status}`
    );
  }

  const buffer = Buffer.from(response.data);

  if (!buffer.length) {
    throw new Error(
      "File hasil download kosong."
    );
  }

  const fileType =
    (await fromBuffer(buffer)) ||
    {};

  const mime =
    String(
      fileType?.mime ||
      response.headers?.["content-type"] ||
      ""
    )
      .split(";")[0]
      .trim()
      .toLowerCase();

  if (
    expectedType === "video" &&
    mime &&
    !mime.startsWith("video/")
  ) {
    throw new Error(
      `Hasil bukan video. MIME: ${mime}`
    );
  }

  if (
    expectedType === "audio" &&
    mime &&
    !mime.startsWith("audio/") &&
    !mime.startsWith("video/")
  ) {
    throw new Error(
      `Hasil bukan audio. MIME: ${mime}`
    );
  }

  return {
    buffer,
    mime,
    ext:
      fileType?.ext ||
      "",
  };
}

////////////////////////////
// Kirim video
////////////////////////////
async function sendVideo(
  wafproject,
  chat,
  url,
  caption,
  quoted
) {
  try {
    return await wafproject.sendMessage(
      chat,
      {
        video: {
          url,
        },
        caption,
      },
      {
        quoted,
      }
    );
  } catch (error) {
    console.log(
      "[TikTok] Kirim video via URL gagal, mencoba buffer:",
      error?.message || error
    );

    const media =
      await downloadMediaBuffer(
        url,
        "video"
      );

    return wafproject.sendMessage(
      chat,
      {
        video: media.buffer,
        mimetype:
          media.mime.startsWith("video/")
            ? media.mime
            : "video/mp4",
        caption,
      },
      {
        quoted,
      }
    );
  }
}

////////////////////////////
// Kirim audio
////////////////////////////
async function sendAudio(
  wafproject,
  chat,
  url,
  fileName,
  quoted
) {
  try {
    return await wafproject.sendMessage(
      chat,
      {
        audio: {
          url,
        },
        mimetype: "audio/mpeg",
        fileName,
      },
      {
        quoted,
      }
    );
  } catch (error) {
    console.log(
      "[TikTok] Kirim audio via URL gagal, mencoba buffer:",
      error?.message || error
    );

    const media =
      await downloadMediaBuffer(
        url,
        "audio"
      );

    return wafproject.sendMessage(
      chat,
      {
        audio: media.buffer,
        mimetype:
          media.mime.startsWith("audio/")
            ? media.mime
            : "audio/mpeg",
        fileName,
      },
      {
        quoted,
      }
    );
  }
}

////////////////////////////
// Handler
////////////////////////////
let handler = async (
  m,
  {
    wafproject,
    command,
    text,
    usedPrefix,
  }
) => {
  const input =
    String(text || "").trim();

  if (!input) {
    return m.reply(
      "📌 *Cara pakai:*\n" +
      `${usedPrefix + command} <link TikTok>\n\n` +
      "Contoh:\n" +
      `${usedPrefix + command} https://www.tiktok.com/@user/video/xxxx`
    );
  }

  if (!isTikTokUrl(input)) {
    return m.reply(
      "❌ Link tidak valid. Kirim link TikTok."
    );
  }

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Tambahkan konfigurasi berikut di config.js:\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";'
    );
  }

  const react = async (emoji) => {
    try {
      await wafproject.sendMessage(
        m.chat,
        {
          react: {
            text: emoji,
            key: m.key,
          },
        }
      );
    } catch (_error) { console.error("[ERROR][commands/downloader/tiktok.js]", _error?.message || _error) }
  };

  let statusMessage;

  const sendStatus = async (message) => {
    try {
      statusMessage =
        await wafproject.sendMessage(
          m.chat,
          {
            text: message,
          },
          {
            quote: m,
          }
        );

      return statusMessage;
    } catch {
      return null;
    }
  };

  const editStatus = async (message) => {
    if (!statusMessage?.key) {
      return null;
    }

    try {
      return await wafproject.sendMessage(
        m.chat,
        {
          text: message,
          edit: statusMessage.key,
        }
      );
    } catch {
      return null;
    }
  };

  try {
    await react("🕒");

    await sendStatus(
      "🎵 *TikTok Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "🔗 Link diterima ✅\n" +
      "⚙️ Source: *JagoanProject TikTok DL*\n" +
      "🔎 Mengambil informasi media... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    const result =
      await fetchTikTok(input);

    const cmd =
      String(command || "")
        .toLowerCase();

    ////////////////////////////
    // TikTok MP3
    ////////////////////////////
    if (cmd === "tikmp3") {
      if (!result.audio?.url) {
        throw new Error(
          "Audio tidak ditemukan dari API."
        );
      }

      await editStatus(
        "🎵 *TikTok MP3*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "✅ Audio ditemukan!\n" +
        "📤 Mengirim audio... ⏳\n" +
        "━━━━━━━━━━━━━━━━━━"
      );

      const audioName =
        cleanText(
          result.audio?.title ||
          result.title ||
          "tiktok"
        )
          .replace(/[\\/:*?"<>|]/g, "")
          .slice(0, 80) ||
        "tiktok";

      await sendAudio(
        wafproject,
        m.chat,
        result.audio.url,
        `${audioName}.mp3`,
        m
      );

      await editStatus(
        "🎵 *TikTok MP3*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "✅ Audio berhasil dikirim!\n" +
        "━━━━━━━━━━━━━━━━━━"
      );

      await react("✅");
      return;
    }

    ////////////////////////////
    // TikTok Video
    ////////////////////////////
    if (!result.video?.url) {
      throw new Error(
        "Video tidak ditemukan dari API."
      );
    }

    await editStatus(
      "🎵 *TikTok Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Video ditemukan!\n" +
      `🎞 Kualitas: *${result.video.quality || "Default"}*\n` +
      "📤 Mengirim video... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    const authorText =
      result.author
        ? `\n∘ *Author* : ${result.author}`
        : "";

    const stats = result.stats || {};

    const statsText =
      stats.views ||
      stats.likes ||
      stats.comments ||
      stats.shares
        ? "\n\n" +
          `▶️ Views: ${formatNumber(stats.views)}\n` +
          `❤️ Likes: ${formatNumber(stats.likes)}\n` +
          `💬 Comments: ${formatNumber(stats.comments)}\n` +
          `🔁 Shares: ${formatNumber(stats.shares)}`
        : "";

    const caption =
      "乂  *T I K T O K*\n\n" +
      `∘ *Caption* :\n${result.title}` +
      authorText +
      statsText +
      "\n\n⚙️ Source: *JagoanProject TikTok DL*";

    await sendVideo(
      wafproject,
      m.chat,
      result.video.url,
      caption,
      m
    );

    await editStatus(
      "🎵 *TikTok Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Video berhasil dikirim!\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    await react("✅");
  } catch (error) {
    console.error(
      "[JagoanProject TikTok Error]",
      error
    );

    await react("❌");

    const errorMessage =
      String(
        error?.message ||
        error
      )
        .replace(
          String(global.jagoanKey || ""),
          "[API_KEY]"
        )
        .slice(0, 500);

    const edited =
      await editStatus(
        "🎵 *TikTok Downloader*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "❌ Download gagal!\n" +
        `📌 ${errorMessage}\n` +
        "━━━━━━━━━━━━━━━━━━"
      );

    if (!edited) {
      return m.reply(
        "❌ *TikTok Downloader gagal:*\n" +
        errorMessage
      );
    }
  }
};

handler.help = [
  "tt <url>",
  "tikmp3 <url>",
];

handler.tags = [
  "downloader",
];

handler.category = [
  "downloader",
];

handler.command = [
  "tt",
  "tikmp3",
];

handler.limit = true;
handler.register = true;

module.exports = handler;