/**
 * Interactive Play - JagoanProject
 *
 * Flow:
 * .play mangu
 * -> bot search 10 hasil
 * -> user kirim 1-10 TANPA reply
 * -> bot tampilkan tombol MP3 / MP4
 * -> user pilih format
 * -> download
 *
 * API:
 * GET /api/search/yts?q=
 * GET /api/downloader/youtube-download
 *     ?url=...&format=mp3|mp4&raw=1
 */

const axios = require("axios");

global.__playSearch ||= new Map();
global.__playDownload ||= new Map();

const TTL = 5 * 60 * 1000;

function clean(v, fallback = "") {
  if (typeof v !== "string" || !v.trim()) return fallback;
  return v.replace(/[\r\n]+/g, " ").replace(/\s+/g, " ").trim();
}

function validUrl(v) {
  return typeof v === "string" && /^https?:\/\//i.test(v.trim());
}

function safeFileName(v, fallback = "youtube") {
  return clean(v, fallback)
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\.+$/g, "")
    .slice(0, 120) || fallback;
}

function makeToken() {
  return (
    Date.now().toString(36) +
    Math.random().toString(36).slice(2, 10)
  );
}

function isGroup(m) {
  return String(m?.chat || "").endsWith("@g.us");
}

function normalizeJid(jid = "") {
  jid = String(jid || "").trim().toLowerCase();
  if (!jid) return "";

  const [user, server] = jid.split("@");
  if (!server) return jid;

  return `${user.replace(/:\d+$/, "")}@${server}`;
}

function getSenderIds(m) {
  return [
    m?.sender,
    m?.participant,
    m?.author,
    m?.key?.participant,
    m?.key?.remoteJid
  ]
    .map(normalizeJid)
    .filter(Boolean);
}

function getBody(m) {
  return clean(
    m?.text ||
    m?.body ||
    m?.msg?.text ||
    m?.message?.conversation ||
    m?.message?.extendedTextMessage?.text ||
    m?.message?.imageMessage?.caption ||
    m?.message?.videoMessage?.caption ||
    ""
  );
}

function cleanupSessions() {
  const now = Date.now();

  for (const [id, s] of global.__playSearch) {
    if (!s || s.expiresAt <= now) {
      global.__playSearch.delete(id);
    }
  }

  for (const [id, s] of global.__playDownload) {
    if (!s || s.expiresAt <= now) {
      global.__playDownload.delete(id);
    }
  }
}

function createSearchSession(m, data) {
  const id = makeToken();

  global.__playSearch.set(id, {
    id,
    ...data,
    chat: String(m.chat || ""),
    senderIds: getSenderIds(m),
    expiresAt: Date.now() + TTL
  });

  return id;
}

function findSearchSession(m) {
  cleanupSessions();

  const chat = String(m.chat || "");
  const senderIds = getSenderIds(m);

  const sessions = [...global.__playSearch.values()]
    .filter(s =>
      s.chat === chat &&
      s.expiresAt > Date.now()
    )
    .sort((a, b) => b.createdAt - a.createdAt);

  if (!sessions.length) return null;

  // Private chat: chat ID sudah cukup
  if (!isGroup(m)) {
    return sessions[0];
  }

  // Group: harus user yang menjalankan .play
  return sessions.find(s =>
    s.senderIds?.some(id =>
      senderIds.includes(id)
    )
  ) || null;
}

async function searchYT(query) {
  const base = String(global.jagoanApi)
    .trim()
    .replace(/\/+$/, "");

  const key = String(global.jagoanKey).trim();

  const res = await axios({
    method: "get",
    url: `${base}/api/search/yts`,
    params: { q: query },
    headers: {
      Authorization: `Bearer ${key}`
    },
    timeout: 120000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = res.data;

  console.log("[PLAY SEARCH] HTTP:", res.status);

  if (res.status < 200 || res.status >= 300) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      `JagoanProject HTTP ${res.status}`
    );
  }

  if (
    data?.status === false ||
    data?.success === false
  ) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      "Pencarian YouTube gagal."
    );
  }

  const items = Array.isArray(data?.result)
    ? data.result
    : [];

  const results = items
    .filter(x => validUrl(x?.url))
    .slice(0, 10)
    .map((x, i) => ({
      no: i + 1,
      title: clean(x?.title, "YouTube Video"),
      thumbnail: validUrl(x?.thumbnail)
        ? x.thumbnail
        : "",
      duration: clean(x?.duration, "-"),
      uploaded: clean(x?.uploaded, "-"),
      views: clean(x?.views, "-"),
      url: x.url,
      videoId: clean(x?.videoId)
    }));

  if (!results.length) {
    throw new Error(
      "Hasil pencarian YouTube tidak ditemukan."
    );
  }

  return results;
}

async function downloadYT(url, format) {
  const base = String(global.jagoanApi)
    .trim()
    .replace(/\/+$/, "");

  const key = String(global.jagoanKey).trim();

  const res = await axios({
    method: "get",
    url: `${base}/api/downloader/youtube-download`,
    params: {
      url,
      format,
      raw: 1
    },
    headers: {
      Authorization: `Bearer ${key}`
    },
    timeout: 300000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = res.data;

  console.log(
    `[PLAY ${format.toUpperCase()}] HTTP:`,
    res.status
  );

  if (res.status < 200 || res.status >= 300) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      `JagoanProject HTTP ${res.status}`
    );
  }

  if (
    data?.status === false ||
    data?.success === false
  ) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      "Download YouTube gagal."
    );
  }

  const n = data?.data?.normalized || {};
  const d = data?.data?.data || {};

  const directUrl =
    n?.url ||
    d?.downloadUrl ||
    d?.download_url ||
    d?.url ||
    "";

  if (!validUrl(directUrl)) {
    console.error(
      "[PLAY DOWNLOAD RESPONSE]",
      JSON.stringify(data, null, 2)
    );

    throw new Error(
      "URL download tidak ditemukan."
    );
  }

  return {
    url: directUrl,

    title: clean(
      n?.title ||
      d?.title ||
      "YouTube Media"
    ),

    thumbnail:
      validUrl(n?.thumbnail)
        ? n.thumbnail
        : validUrl(d?.thumbnail)
          ? d.thumbnail
          : "",

    duration: clean(
      n?.duration ||
      d?.duration ||
      ""
    ),

    quality:
      clean(
        n?.quality ||
        d?.selected?.label ||
        ""
      ) ||
      (
        d?.selected?.quality
          ? `${d.selected.quality}${format === "mp3" ? "kbps" : "p"}`
          : ""
      ),

    filename: clean(
      n?.filename ||
      ""
    ),

    ext: clean(
      n?.ext ||
      format
    ),

    contentType: clean(
      n?.contentType ||
      (
        format === "mp3"
          ? "audio/mpeg"
          : "video/mp4"
      )
    ),

    provider: clean(
      data?.data?.provider ||
      "JagoanProject"
    )
  };
}

async function getBuffer(url, format) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 300000,
    validateStatus: () => true,
    maxRedirects: 10,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    headers: {
      Accept:
        format === "mp3"
          ? "audio/*,*/*"
          : "video/*,*/*",

      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }
  });

  if (res.status < 200 || res.status >= 300) {
    throw new Error(
      `CDN HTTP ${res.status}`
    );
  }

  const buffer = Buffer.from(res.data);

  if (!buffer.length) {
    throw new Error(
      "File hasil download kosong."
    );
  }

  const contentType = String(
    res.headers?.["content-type"] || ""
  )
    .split(";")[0]
    .trim()
    .toLowerCase();

  if (
    contentType.includes("text/html") ||
    contentType.includes("application/json")
  ) {
    throw new Error(
      `CDN mengembalikan ${contentType}, bukan media.`
    );
  }

  return {
    buffer,
    contentType
  };
}

async function sendAudio(
  conn,
  chat,
  result,
  quoted
) {
  const fileName =
    result.filename ||
    `${safeFileName(result.title)}.mp3`;

  try {
    return await conn.sendMessage(
      chat,
      {
        audio: {
          url: result.url
        },

        mimetype:
          result.contentType ||
          "audio/mpeg",

        fileName,
        ptt: false
      },
      { quoted }
    );
  } catch (e) {
    console.log(
      "[PLAY MP3] Direct URL gagal:",
      e?.message || e
    );
  }

  const media = await getBuffer(
    result.url,
    "mp3"
  );

  return conn.sendMessage(
    chat,
    {
      audio: media.buffer,

      mimetype:
        media.contentType.startsWith("audio/")
          ? media.contentType
          : "audio/mpeg",

      fileName,
      ptt: false
    },
    { quoted }
  );
}

async function sendVideo(
  conn,
  chat,
  result,
  quoted
) {
  let caption =
    "🎬 *YouTube Video*\n" +
    "━━━━━━━━━━━━━━━━━━\n" +
    `🎵 *${result.title}*`;

  if (result.duration) {
    caption +=
      `\n⏱ Durasi: *${result.duration}*`;
  }

  if (result.quality) {
    caption +=
      `\n🎞 Kualitas: *${result.quality}*`;
  }

  caption +=
    `\n⚙️ Provider: *${result.provider}*`;

  try {
    return await conn.sendMessage(
      chat,
      {
        video: {
          url: result.url
        },

        mimetype:
          result.contentType ||
          "video/mp4",

        caption
      },
      { quoted }
    );
  } catch (e) {
    console.log(
      "[PLAY MP4] Direct URL gagal:",
      e?.message || e
    );
  }

  const media = await getBuffer(
    result.url,
    "mp4"
  );

  return conn.sendMessage(
    chat,
    {
      video: media.buffer,

      mimetype:
        media.contentType.startsWith("video/")
          ? media.contentType
          : "video/mp4",

      caption
    },
    { quoted }
  );
}

async function sendFormatButtons(
  conn,
  m,
  item,
  token,
  prefix = "."
) {
  const text =
    "🎵 *LAGU DIPILIH*\n" +
    "━━━━━━━━━━━━━━━━━━\n" +
    `🎶 *${item.title}*\n` +
    `⏱ ${item.duration}\n` +
    `👁 ${item.views}\n\n` +
    "Pilih format download:";

  try {
    return await conn.sendMessage(
      m.chat,
      {
        text,
        footer: "WAF PROJECT",

        buttons: [
          {
            buttonId:
              `${prefix}playdl ${token} mp3`,

            buttonText: {
              displayText:
                "🎵 MP3"
            },

            type: 1
          },
          {
            buttonId:
              `${prefix}playdl ${token} mp4`,

            buttonText: {
              displayText:
                "🎬 MP4"
            },

            type: 1
          }
        ],

        headerType: 1
      },
      { quoted: m }
    );
  } catch (e) {
    console.log(
      "[PLAY BUTTON ERROR]",
      e?.message || e
    );

    return conn.sendMessage(
      m.chat,
      {
        text:
          text +
          "\n\n" +
          `🎵 *MP3*\n${prefix}playdl ${token} mp3\n\n` +
          `🎬 *MP4*\n${prefix}playdl ${token} mp4`
      },
      { quoted: m }
    );
  }
}

let handler = async (
  m,
  {
    wafproject,
    text,
    command,
    usedPrefix
  }
) => {
  cleanupSessions();

  const cmd = String(
    command || ""
  ).toLowerCase();

  // =========================================
  // PLAYDL - PILIH MP3 / MP4
  // =========================================

  if (cmd === "playdl") {
    const args = String(
      text || ""
    )
      .trim()
      .split(/\s+/);

    const token = args[0];
    const format = String(
      args[1] || ""
    ).toLowerCase();

    if (
      !token ||
      !["mp3", "mp4"].includes(format)
    ) {
      return m.reply(
        "❌ Pilihan download tidak valid."
      );
    }

    const session =
      global.__playDownload.get(token);

    if (
      !session ||
      session.expiresAt <= Date.now()
    ) {
      global.__playDownload.delete(token);

      return m.reply(
        "⌛ Pilihan sudah kedaluwarsa. Jalankan *.play* lagi."
      );
    }

    if (session.chat !== m.chat) {
      return;
    }

    // Di grup, tombol hanya untuk pemilik session
    if (isGroup(m)) {
      const currentIds =
        getSenderIds(m);

      const allowed =
        session.senderIds?.some(id =>
          currentIds.includes(id)
        );

      if (!allowed) {
        return m.reply(
          "❌ Tombol ini bukan untuk kamu."
        );
      }
    }

    // Hapus agar tidak double download
    global.__playDownload.delete(token);

    try {
      await wafproject.sendMessage(
        m.chat,
        {
          react: {
            text: "🕒",
            key: m.key
          }
        }
      ).catch(() => {});

      const status =
        await wafproject.sendMessage(
          m.chat,
          {
            text:
              `⬇️ *Mengunduh ${format.toUpperCase()}*\n` +
              "━━━━━━━━━━━━━━━━━━\n" +
              `🎵 ${session.item.title}\n` +
              "⏳ Mohon tunggu..."
          },
          { quoted: m }
        );

      const result =
        await downloadYT(
          session.item.url,
          format
        );

      if (format === "mp3") {
        await sendAudio(
          wafproject,
          m.chat,
          result,
          m
        );
      } else {
        await sendVideo(
          wafproject,
          m.chat,
          result,
          m
        );
      }

      if (status?.key) {
        await wafproject.sendMessage(
          m.chat,
          {
            text:
              `✅ *${format.toUpperCase()} berhasil dikirim!*\n` +
              `🎵 ${result.title}`,

            edit:
              status.key
          }
        ).catch(() => {});
      }

      await wafproject.sendMessage(
        m.chat,
        {
          react: {
            text: "✅",
            key: m.key
          }
        }
      ).catch(() => {});

      return;
    } catch (error) {
      console.error(
        "[PLAYDL ERROR]",
        error
      );

      return m.reply(
        "❌ Download gagal.\n" +
        clean(
          error?.message ||
          String(error)
        ).slice(0, 400)
      );
    }
  }

  // =========================================
  // PLAY SEARCH
  // =========================================

  const query = clean(text);

  if (!query) {
    return m.reply(
      "🎵 *PLAY MUSIC*\n\n" +
      `${usedPrefix}play <judul lagu>\n\n` +
      `Contoh:\n${usedPrefix}play Mangu Fourtwnty`
    );
  }

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Konfigurasi JagoanProject belum lengkap."
    );
  }

  try {
    await wafproject.sendMessage(
      m.chat,
      {
        react: {
          text: "🕒",
          key: m.key
        }
      }
    ).catch(() => {});

    const results =
      await searchYT(query);

    let caption =
      "🔎 *PILIH LAGU*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `📝 Pencarian: *${query.slice(0, 100)}*\n\n`;

    results.forEach(x => {
      caption +=
        `*${x.no}. ${x.title}*\n` +
        `⏱ ${x.duration}  •  👁 ${x.views}\n\n`;
    });

    caption +=
      "━━━━━━━━━━━━━━━━━━\n" +
      "🔢 *Kirim nomor lagu yang kamu pilih.*\n" +
      "Contoh: *2*\n\n" +
      "✅ Tidak perlu reply pesan bot.\n" +
      "⌛ Berlaku 5 menit.";

    let sent = null;

    if (results[0]?.thumbnail) {
      try {
        sent =
          await wafproject.sendMessage(
            m.chat,
            {
              image: {
                url:
                  results[0].thumbnail
              },

              caption
            },
            { quoted: m }
          );
      } catch {}
    }

    if (!sent) {
      sent =
        await wafproject.sendMessage(
          m.chat,
          { text: caption },
          { quoted: m }
        );
    }

    // Hapus session lama user/chat ini
    for (const [id, s] of global.__playSearch) {
      if (s.chat !== m.chat) continue;

      if (!isGroup(m)) {
        global.__playSearch.delete(id);
        continue;
      }

      const currentIds =
        getSenderIds(m);

      if (
        s.senderIds?.some(id =>
          currentIds.includes(id)
        )
      ) {
        global.__playSearch.delete(id);
      }
    }

    createSearchSession(
      m,
      {
        prefix:
          usedPrefix || ".",

        query,

        results,

        createdAt:
          Date.now()
      }
    );

    console.log(
      "[PLAY] Search session created:",
      {
        chat:
          m.chat,

        sender:
          m.sender,

        total:
          results.length
      }
    );

    await wafproject.sendMessage(
      m.chat,
      {
        react: {
          text: "✅",
          key: m.key
        }
      }
    ).catch(() => {});
  } catch (error) {
    console.error(
      "[PLAY SEARCH ERROR]",
      error
    );

    return m.reply(
      "❌ Pencarian gagal.\n" +
      clean(
        error?.message ||
        String(error)
      ).slice(0, 400)
    );
  }
};

// ===============================================
// TANGKAP PESAN ANGKA BIASA TANPA REPLY
// ===============================================

handler.before = async (
  m,
  {
    wafproject
  }
) => {
  cleanupSessions();

  const body =
    getBody(m);

  /*
   * Debug.
   * Kalau kamu kirim "1", ini harus muncul
   * di console/PM2.
   */
  if (/^(10|[1-9])$/.test(body)) {
    console.log(
      "[PLAY BEFORE]",
      {
        body,
        chat:
          m?.chat,
        sender:
          m?.sender
      }
    );
  }

  // Hanya angka 1-10
  if (
    !/^(10|[1-9])$/.test(body)
  ) {
    return false;
  }

  const session =
    findSearchSession(m);

  if (!session) {
    console.log(
      "[PLAY] Tidak ada session aktif untuk:",
      {
        chat:
          m?.chat,
        sender:
          m?.sender
      }
    );

    return false;
  }

  const number =
    Number(body);

  if (
    number < 1 ||
    number > session.results.length
  ) {
    await m.reply(
      `❌ Pilih nomor 1-${session.results.length}.`
    );

    return true;
  }

  const selected =
    session.results[
      number - 1
    ];

  global.__playSearch.delete(
    session.id
  );

  const token =
    makeToken();

  global.__playDownload.set(
    token,
    {
      chat:
        m.chat,

      senderIds:
        getSenderIds(m),

      item:
        selected,

      expiresAt:
        Date.now() + TTL
    }
  );

  console.log(
    "[PLAY] Selected:",
    {
      number,
      title:
        selected.title
    }
  );

  await sendFormatButtons(
    wafproject,
    m,
    selected,
    token,
    session.prefix || "."
  );

  return true;
};

handler.help = [
  "play <judul lagu>"
];

handler.tags = [
  "downloader"
];

handler.category = [
  "downloader"
];

handler.command = [
  "play",
  "playdl"
];

handler.limit = true;
handler.premium = false;
handler.register = true;

module.exports = handler;