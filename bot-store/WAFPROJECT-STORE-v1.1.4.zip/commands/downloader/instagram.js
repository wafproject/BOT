/**
 * Instagram Downloader - JagoanProject
 *
 * Support:
 * - Instagram Reel / video tunggal
 * - Instagram foto tunggal
 * - Instagram carousel foto/video
 * - result.media.slides
 * - result.media.videos / images
 * - result.media direct object
 * - Beberapa variasi response API
 * - Pilih resolusi terbaik
 * - Deteksi tipe file dari buffer asli
 * - Tidak mengirim resolusi yang sama berulang kali
 * - Error JSON API tidak dikirim mentah ke WhatsApp
 *
 * Endpoint:
 * GET /api/downloader/instagram?url=<instagramUrl>
 *
 * Header:
 * Authorization: Bearer APIKEY
 *
 * config.js / settings.js:
 *
 * global.jagoanApi = "https://api.jagoanproject.com";
 * global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";
 */

const axios = require("axios");
const { fromBuffer } = require("../../lib/file-type.js");

//////////////////////////////////////////////////
// URL INSTAGRAM
//////////////////////////////////////////////////

function isIGUrl(url = "") {
  const value = String(url || "").trim();

  if (!value) return false;

  try {
    const parsed = new URL(value);
    const hostname = parsed.hostname.toLowerCase();

    return (
      hostname === "instagram.com" ||
      hostname.endsWith(".instagram.com")
    );
  } catch {
    return false;
  }
}

//////////////////////////////////////////////////
// URL UMUM
//////////////////////////////////////////////////

function isValidUrl(value) {
  return (
    typeof value === "string" &&
    /^https?:\/\//i.test(value.trim())
  );
}

//////////////////////////////////////////////////
// AMBIL LINK INSTAGRAM DARI INPUT
//////////////////////////////////////////////////

function extractInstagramUrl(text = "") {
  const input = String(text || "").trim();

  if (!input) return null;

  if (isIGUrl(input)) {
    return input;
  }

  const matches =
    input.match(/https?:\/\/[^\s]+/gi) || [];

  for (const match of matches) {
    const cleaned = match
      .replace(/[)\],.]+$/g, "")
      .trim();

    if (isIGUrl(cleaned)) {
      return cleaned;
    }
  }

  return null;
}

//////////////////////////////////////////////////
// BERSIHKAN TEXT
//////////////////////////////////////////////////

function cleanText(value, fallback = "") {
  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    return fallback;
  }

  return value
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

//////////////////////////////////////////////////
// ARRAY HELPER
//////////////////////////////////////////////////

function toArray(value) {
  if (
    value === undefined ||
    value === null
  ) {
    return [];
  }

  return Array.isArray(value)
    ? value
    : [value];
}

//////////////////////////////////////////////////
// DL PARAM
//////////////////////////////////////////////////

function ensureDl(url) {
  const value = String(url || "").trim();

  if (!value) return value;

  try {
    const parsed = new URL(value);

    if (
      parsed.searchParams.get("dl") === "1"
    ) {
      return value;
    }

    parsed.searchParams.set("dl", "1");

    return parsed.toString();
  } catch {
    return value;
  }
}

//////////////////////////////////////////////////
// RESOLUTION SCORE
//////////////////////////////////////////////////

function getResolutionScore(item) {
  if (!item) {
    return 0;
  }

  if (typeof item === "string") {
    return 0;
  }

  if (typeof item !== "object") {
    return 0;
  }

  const width =
    Number(
      item?.width ||
      item?.w ||
      item?.video_width ||
      item?.image_width ||
      0
    ) || 0;

  const height =
    Number(
      item?.height ||
      item?.h ||
      item?.video_height ||
      item?.image_height ||
      0
    ) || 0;

  if (width && height) {
    return width * height;
  }

  const resolution =
    String(
      item?.resolution ||
      item?.quality ||
      item?.label ||
      item?.size ||
      ""
    );

  const match =
    resolution.match(
      /(\d{2,5})\s*[x×]\s*(\d{2,5})/i
    );

  if (match) {
    return (
      Number(match[1]) *
      Number(match[2])
    );
  }

  const qualityMatch =
    resolution.match(
      /(\d{3,4})p/i
    );

  if (qualityMatch) {
    return Number(
      qualityMatch[1]
    );
  }

  return 0;
}

//////////////////////////////////////////////////
// GET URL DARI ITEM
//////////////////////////////////////////////////

function getUrlFromItem(item) {
  if (!item) {
    return null;
  }

  if (
    typeof item === "string" &&
    isValidUrl(item)
  ) {
    return item.trim();
  }

  if (typeof item !== "object") {
    return null;
  }

  const possibleUrls = [
    item?.download,
    item?.download_url,
    item?.downloadUrl,
    item?.downloadURL,

    item?.video,
    item?.video_url,
    item?.videoUrl,
    item?.videoURL,

    item?.media,
    item?.media_url,
    item?.mediaUrl,
    item?.mediaURL,

    item?.play,
    item?.play_url,
    item?.playUrl,

    item?.file,
    item?.file_url,
    item?.fileUrl,

    item?.src,
    item?.source,

    item?.url,
    item?.link,

    item?.hd,
    item?.sd,

    item?.uri,
  ];

  return (
    possibleUrls.find(
      (value) =>
        isValidUrl(value)
    ) || null
  );
}

//////////////////////////////////////////////////
// GET THUMBNAIL
//////////////////////////////////////////////////

function getThumbnailFromItem(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return null;
  }

  const possibleUrls = [
    item?.thumbnail,
    item?.thumbnail_url,
    item?.thumbnailUrl,

    item?.cover,
    item?.cover_url,
    item?.coverUrl,

    item?.poster,
    item?.poster_url,
    item?.posterUrl,

    item?.preview,
    item?.preview_url,
    item?.previewUrl,

    item?.image,
    item?.image_url,
    item?.imageUrl,
  ];

  return (
    possibleUrls.find(
      (value) =>
        isValidUrl(value)
    ) || null
  );
}

//////////////////////////////////////////////////
// QUALITY
//////////////////////////////////////////////////

function getMediaQuality(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  const width =
    Number(
      item?.width ||
      item?.w ||
      0
    );

  const height =
    Number(
      item?.height ||
      item?.h ||
      0
    );

  if (width && height) {
    return `${width}x${height}`;
  }

  return cleanText(
    item?.quality ||
    item?.resolution ||
    item?.label ||
    ""
  );
}

//////////////////////////////////////////////////
// NORMALIZE MEDIA
//////////////////////////////////////////////////

function normalizeMediaItem(
  item,
  forcedType = ""
) {
  if (!item) {
    return null;
  }

  if (typeof item === "string") {
    if (!isValidUrl(item)) {
      return null;
    }

    return {
      url: item.trim(),
      thumbnail: null,
      type:
        String(
          forcedType || ""
        ).toLowerCase(),
      quality: "",
      headers: {},
      raw: item,
    };
  }

  if (typeof item !== "object") {
    return null;
  }

  const url =
    getUrlFromItem(item);

  if (!url) {
    return null;
  }

  const declaredType =
    cleanText(
      forcedType ||
      item?.type ||
      item?.media_type ||
      item?.mediaType ||
      item?.content_type ||
      item?.contentType ||
      item?.format ||
      item?.mime ||
      item?.mimetype ||
      ""
    ).toLowerCase();

  return {
    url,
    thumbnail:
      getThumbnailFromItem(item),
    type:
      declaredType,
    quality:
      getMediaQuality(item),
    headers:
      item?.headers &&
      typeof item.headers === "object"
        ? item.headers
        : {},
    raw:
      item,
  };
}

//////////////////////////////////////////////////
// UNIQUE MEDIA
//////////////////////////////////////////////////

function uniqueMediaItems(items = []) {
  const result = [];
  const seen = new Set();

  for (const item of items) {
    if (
      !item?.url ||
      !isValidUrl(item.url)
    ) {
      continue;
    }

    let key =
      String(item.url)
        .trim();

    try {
      const parsed =
        new URL(key);

      /*
       * Parameter URL CDN bisa beda walaupun
       * file yang sama. Untuk sekarang URL asli
       * tetap digunakan sebagai key agar tidak
       * merusak signed URL.
       */

      key =
        parsed.toString();
    } catch {}

    if (seen.has(key)) {
      continue;
    }

    seen.add(key);
    result.push(item);
  }

  return result;
}

//////////////////////////////////////////////////
// BEST IMAGE
//////////////////////////////////////////////////

function pickBestImage(images) {
  if (
    !Array.isArray(images) ||
    !images.length
  ) {
    return null;
  }

  const validImages =
    images
      .filter((item) => {
        const url =
          getUrlFromItem(item);

        return isValidUrl(url);
      })
      .sort(
        (a, b) =>
          getResolutionScore(b) -
          getResolutionScore(a)
      );

  return validImages[0] || null;
}

//////////////////////////////////////////////////
// BEST VIDEO
//////////////////////////////////////////////////

function pickBestVideo(videos) {
  if (
    !Array.isArray(videos) ||
    !videos.length
  ) {
    return null;
  }

  const validVideos =
    videos
      .filter((item) => {
        const url =
          getUrlFromItem(item);

        return isValidUrl(url);
      })
      .sort(
        (a, b) =>
          getResolutionScore(b) -
          getResolutionScore(a)
      );

  return validVideos[0] || null;
}

//////////////////////////////////////////////////
// EXTRACT SLIDES / CAROUSEL
//////////////////////////////////////////////////

function extractFromSlides(data) {
  const possibleSlides = [
    data?.result?.media?.slides,
    data?.result?.slides,
    data?.data?.media?.slides,
    data?.data?.slides,
  ];

  const slides =
    possibleSlides.find(
      (value) =>
        Array.isArray(value) &&
        value.length
    );

  if (!slides) {
    return [];
  }

  const items = [];

  for (const slide of slides) {
    if (!slide) {
      continue;
    }

    /*
     * Jika slide langsung URL
     */
    if (
      typeof slide === "string"
    ) {
      const normalized =
        normalizeMediaItem(slide);

      if (normalized) {
        items.push(normalized);
      }

      continue;
    }

    /*
     * VIDEO
     */

    const videos = [
      ...toArray(slide?.videos),
      ...toArray(slide?.video),
      ...toArray(slide?.video_url),
      ...toArray(slide?.videoUrl),
      ...toArray(slide?.video_versions),
      ...toArray(slide?.videoVersions),
    ];

    if (videos.length) {
      const bestVideo =
        pickBestVideo(videos);

      if (bestVideo) {
        const normalized =
          normalizeMediaItem(
            bestVideo,
            "video"
          );

        if (normalized) {
          const images = [
            ...toArray(slide?.images),
            ...toArray(slide?.image),
            ...toArray(slide?.image_url),
            ...toArray(slide?.imageUrl),

            ...toArray(slide?.thumbnail),
            ...toArray(slide?.thumbnail_url),
            ...toArray(slide?.thumbnailUrl),

            ...toArray(slide?.cover),
            ...toArray(slide?.poster),
          ];

          const bestThumb =
            pickBestImage(images);

          if (bestThumb) {
            normalized.thumbnail =
              getUrlFromItem(
                bestThumb
              );
          }

          items.push(normalized);
        }
      }

      continue;
    }

    /*
     * IMAGE
     */

    const images = [
      ...toArray(slide?.images),
      ...toArray(slide?.image),
      ...toArray(slide?.image_url),
      ...toArray(slide?.imageUrl),
      ...toArray(slide?.display_url),
      ...toArray(slide?.displayUrl),
    ];

    if (images.length) {
      const bestImage =
        pickBestImage(images);

      if (bestImage) {
        const normalized =
          normalizeMediaItem(
            bestImage,
            "image"
          );

        if (normalized) {
          normalized.thumbnail =
            null;

          items.push(normalized);
        }
      }

      continue;
    }

    /*
     * DIRECT SLIDE
     */

    const declaredType =
      String(
        slide?.type ||
        slide?.media_type ||
        slide?.mediaType ||
        ""
      ).toLowerCase();

    const normalized =
      normalizeMediaItem(
        slide,
        declaredType
      );

    if (normalized) {
      items.push(normalized);
    }
  }

  return uniqueMediaItems(items);
}

//////////////////////////////////////////////////
// RESULT.MEDIA
//////////////////////////////////////////////////

function extractFromResultMedia(data) {
  const media =
    data?.result?.media;

  if (!media) {
    return [];
  }

  /*
   * result.media = array
   */

  if (Array.isArray(media)) {
    const result = [];

    for (const item of media) {
      const normalized =
        normalizeMediaItem(item);

      if (normalized) {
        result.push(normalized);
      }
    }

    return uniqueMediaItems(result);
  }

  if (typeof media !== "object") {
    return [];
  }

  const metadata =
    data?.result?.metadata || {};

  const items = [];

  //////////////////////////////////////////////////
  // VIDEO
  //////////////////////////////////////////////////

  const videos = [
    ...toArray(media?.videos),
    ...toArray(media?.video),
    ...toArray(media?.video_url),
    ...toArray(media?.videoUrl),

    ...toArray(media?.video_versions),
    ...toArray(media?.videoVersions),

    ...toArray(media?.download_video),
    ...toArray(media?.downloadVideo),
  ];

  if (videos.length) {
    const bestVideo =
      pickBestVideo(videos);

    if (bestVideo) {
      const normalized =
        normalizeMediaItem(
          bestVideo,
          "video"
        );

      if (normalized) {
        const images = [
          ...toArray(media?.images),
          ...toArray(media?.image),

          ...toArray(media?.thumbnail),
          ...toArray(media?.thumbnail_url),
          ...toArray(media?.thumbnailUrl),

          ...toArray(media?.cover),
          ...toArray(media?.cover_url),
          ...toArray(media?.coverUrl),

          ...toArray(media?.poster),
        ];

        const bestThumb =
          pickBestImage(images);

        if (bestThumb) {
          normalized.thumbnail =
            getUrlFromItem(
              bestThumb
            );
        }

        items.push(normalized);
      }
    }
  }

  //////////////////////////////////////////////////
  // IMAGE
  //////////////////////////////////////////////////

  if (!items.length) {
    const images = [
      ...toArray(media?.images),
      ...toArray(media?.image),
      ...toArray(media?.image_url),
      ...toArray(media?.imageUrl),

      ...toArray(media?.display_url),
      ...toArray(media?.displayUrl),

      ...toArray(media?.photo),
      ...toArray(media?.photo_url),
      ...toArray(media?.photoUrl),
    ];

    if (images.length) {
      const bestImage =
        pickBestImage(images);

      if (bestImage) {
        const normalized =
          normalizeMediaItem(
            bestImage,
            "image"
          );

        if (normalized) {
          items.push(normalized);
        }
      }
    }
  }

  //////////////////////////////////////////////////
  // DIRECT MEDIA OBJECT
  //////////////////////////////////////////////////

  if (!items.length) {
    let forcedType = "";

    if (
      metadata?.isVideo === true ||
      metadata?.is_video === true ||
      metadata?.type === "video"
    ) {
      forcedType = "video";
    }

    if (
      metadata?.isVideo === false ||
      metadata?.is_video === false ||
      metadata?.type === "image"
    ) {
      forcedType = "image";
    }

    const direct =
      normalizeMediaItem(
        media,
        forcedType
      );

    if (direct) {
      items.push(direct);
    }
  }

  //////////////////////////////////////////////////
  // CONTAINERS
  //////////////////////////////////////////////////

  if (!items.length) {
    const containers = [
      media?.items,
      media?.results,
      media?.resources,
      media?.downloads,
      media?.files,
    ];

    for (const container of containers) {
      if (!container) {
        continue;
      }

      const normalized =
        toArray(container)
          .map((item) =>
            normalizeMediaItem(item)
          )
          .filter(Boolean);

      if (normalized.length) {
        items.push(
          ...normalized
        );

        break;
      }
    }
  }

  return uniqueMediaItems(items);
}

//////////////////////////////////////////////////
// FALLBACK MEDIA
//////////////////////////////////////////////////

function extractFallbackMedia(data) {
  const containers = [
    data?.data?.results,
    data?.data?.result,
    data?.data?.items,
    data?.data?.media,
    data?.data?.downloads,

    data?.result?.results,
    data?.result?.items,
    data?.result?.downloads,
    data?.result?.resources,
    data?.result?.files,

    data?.results,
    data?.items,
    data?.media,
    data?.downloads,

    data?.data,
  ];

  for (const container of containers) {
    if (
      container === null ||
      container === undefined
    ) {
      continue;
    }

    const rawItems =
      Array.isArray(container)
        ? container
        : [container];

    const items =
      rawItems
        .map((item) =>
          normalizeMediaItem(item)
        )
        .filter(Boolean);

    if (items.length) {
      return uniqueMediaItems(
        items
      );
    }
  }

  return [];
}

//////////////////////////////////////////////////
// RECURSIVE FALLBACK
//////////////////////////////////////////////////

function recursiveMediaSearch(
  value,
  depth = 0,
  seen = new WeakSet()
) {
  if (
    value === null ||
    value === undefined ||
    depth > 6
  ) {
    return [];
  }

  if (typeof value === "string") {
    return [];
  }

  if (typeof value !== "object") {
    return [];
  }

  if (seen.has(value)) {
    return [];
  }

  seen.add(value);

  const items = [];

  /*
   * Jangan langsung mengambil objek metadata/author
   * agar foto profil tidak dianggap media post.
   */

  const direct =
    normalizeMediaItem(value);

  const keys =
    Object.keys(value);

  const mediaLikeKeys = [
    "video",
    "videos",
    "image",
    "images",
    "media",
    "download",
    "downloads",
    "resource",
    "resources",
    "slide",
    "slides",
    "file",
    "files",
    "play",
  ];

  const looksLikeMedia =
    keys.some((key) =>
      mediaLikeKeys.some(
        (word) =>
          key
            .toLowerCase()
            .includes(word)
      )
    );

  if (
    direct &&
    looksLikeMedia
  ) {
    items.push(direct);
  }

  for (
    const [key, child]
    of Object.entries(value)
  ) {
    const lowerKey =
      String(key).toLowerCase();

    /*
     * Skip metadata yang berisiko berisi avatar
     */

    if (
      [
        "author",
        "owner",
        "user",
        "profile",
        "avatar",
        "profile_pic_url",
        "profilepicurl",
      ].includes(lowerKey)
    ) {
      continue;
    }

    if (
      child &&
      typeof child === "object"
    ) {
      items.push(
        ...recursiveMediaSearch(
          child,
          depth + 1,
          seen
        )
      );
    }
  }

  return uniqueMediaItems(items);
}

//////////////////////////////////////////////////
// EXTRACT MEDIA UTAMA
//////////////////////////////////////////////////

function extractMediaItems(data) {
  /*
   * 1. Carousel
   */

  const slideItems =
    extractFromSlides(data);

  if (slideItems.length) {
    return slideItems;
  }

  /*
   * 2. Reel / Post tunggal
   */

  const resultMedia =
    extractFromResultMedia(data);

  if (resultMedia.length) {
    return resultMedia;
  }

  /*
   * 3. Struktur API lain
   */

  const fallback =
    extractFallbackMedia(data);

  if (fallback.length) {
    return fallback;
  }

  /*
   * 4. Last fallback
   */

  const recursive =
    recursiveMediaSearch(
      data?.result?.media ||
      data?.result ||
      data?.data ||
      data
    );

  if (recursive.length) {
    return recursive;
  }

  return [];
}

//////////////////////////////////////////////////
// CAPTION
//////////////////////////////////////////////////

function getCaption(data) {
  const possibleCaptions = [
    data?.result?.metadata?.caption,
    data?.result?.caption,

    data?.data?.metadata?.caption,
    data?.data?.caption,

    data?.caption,

    data?.result?.metadata?.title,
    data?.result?.title,
    data?.data?.title,
    data?.title,
  ];

  const caption =
    possibleCaptions.find(
      (value) =>
        typeof value === "string" &&
        value.trim()
    );

  return cleanText(
    caption,
    "Instagram Downloader"
  );
}

//////////////////////////////////////////////////
// USERNAME
//////////////////////////////////////////////////

function getUsername(data) {
  const possibleNames = [
    data?.result?.metadata?.author?.username,
    data?.result?.metadata?.username,

    data?.result?.author?.username,
    data?.result?.username,

    data?.data?.metadata?.author?.username,
    data?.data?.author?.username,
    data?.data?.username,

    data?.author?.username,
    data?.username,
  ];

  const username =
    possibleNames.find(
      (value) =>
        typeof value === "string" &&
        value.trim()
    );

  return cleanText(
    username,
    ""
  );
}

//////////////////////////////////////////////////
// FETCH JAGOANPROJECT
//////////////////////////////////////////////////

async function fetchInstagram(url) {
  if (!global.jagoanApi) {
    throw new Error(
      "Config belum lengkap: global.jagoanApi belum di-set."
    );
  }

  if (!global.jagoanKey) {
    throw new Error(
      "Config belum lengkap: global.jagoanKey belum di-set."
    );
  }

  const baseUrl =
    String(global.jagoanApi)
      .trim()
      .replace(/\/+$/, "");

  const apiKey =
    String(global.jagoanKey)
      .trim();

  if (!apiKey) {
    throw new Error(
      "API key JagoanProject kosong."
    );
  }

  if (!isIGUrl(url)) {
    throw new Error(
      "URL Instagram tidak valid."
    );
  }

  const endpoint =
    `${baseUrl}/api/downloader/instagram` +
    `?url=${encodeURIComponent(url)}`;

  const response =
    await axios.get(
      endpoint,
      {
        headers: {
          Authorization:
            `Bearer ${apiKey}`,

          Accept:
            "application/json",

          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36",
        },

        timeout:
          120000,

        validateStatus:
          () => true,

        maxBodyLength:
          Infinity,

        maxContentLength:
          Infinity,
      }
    );

  const data =
    response.data;

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    const errorData =
      typeof data === "string"
        ? data
        : JSON.stringify(data);

    throw new Error(
      `JagoanProject HTTP ${response.status}: ` +
      errorData.slice(0, 500)
    );
  }

  if (
    data?.status === false ||
    data?.success === false
  ) {
    throw new Error(
      data?.message ||
      data?.msg ||
      data?.error ||
      "Gagal mengambil media Instagram."
    );
  }

  const items =
    extractMediaItems(data);

  /*
   * Debug response API ke console,
   * bukan WhatsApp.
   */

  if (!items.length) {
    console.error(
      "[JagoanProject Instagram] MEDIA TIDAK DITEMUKAN"
    );

    console.error(
      JSON.stringify(
        data,
        null,
        2
      )
    );

    throw new Error(
      "Media Instagram tidak ditemukan dari response API."
    );
  }

  console.log(
    "[JagoanProject Instagram] Media ditemukan:",
    items.map(
      (item, index) => ({
        index:
          index + 1,

        type:
          item.type,

        quality:
          item.quality,

        url:
          item.url,
      })
    )
  );

  return {
    items,

    caption:
      getCaption(data),

    username:
      getUsername(data),

    creator:
      data?.creator ||
      "Jagoan Project",

    totalSlides:
      Number(
        data?.result?.media?.total_slides ||
        data?.result?.media?.totalSlides ||
        data?.result?.total_slides ||
        data?.result?.totalSlides
      ) ||
      items.length,

    raw:
      data,
  };
}

//////////////////////////////////////////////////
// DOWNLOAD BUFFER
//////////////////////////////////////////////////

async function downloadBuffer(
  url,
  extraHeaders = {}
) {
  if (!isValidUrl(url)) {
    throw new Error(
      "URL media tidak valid."
    );
  }

  const headers = {
    "User-Agent":
      extraHeaders["user-agent"] ||
      extraHeaders["User-Agent"] ||
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36",

    Accept:
      "*/*",

    Referer:
      "https://www.instagram.com/",

    ...extraHeaders,
  };

  /*
   * Hindari undefined/null header.
   */

  for (
    const key
    of Object.keys(headers)
  ) {
    if (
      headers[key] === undefined ||
      headers[key] === null
    ) {
      delete headers[key];
    }
  }

  const response =
    await axios.get(
      url,
      {
        responseType:
          "arraybuffer",

        timeout:
          120000,

        maxBodyLength:
          Infinity,

        maxContentLength:
          Infinity,

        maxRedirects:
          10,

        validateStatus:
          () => true,

        headers,
      }
    );

  if (
    response.status < 200 ||
    response.status >= 300 ||
    !response.data
  ) {
    throw new Error(
      `Gagal download media HTTP ${response.status}`
    );
  }

  const buffer =
    Buffer.from(
      response.data
    );

  if (!buffer.length) {
    throw new Error(
      "File media kosong."
    );
  }

  const fileType =
    (await fromBuffer(buffer)) ||
    {};

  const contentType =
    String(
      response.headers?.["content-type"] ||
      ""
    )
      .split(";")[0]
      .trim()
      .toLowerCase();

  return {
    buffer,

    fileType,

    contentType,

    finalUrl:
      response?.request?.res?.responseUrl ||
      url,
  };
}

//////////////////////////////////////////////////
// DETEKSI MEDIA ASLI
//////////////////////////////////////////////////

function detectMediaKind({
  fileType,
  contentType,
  declaredType,
}) {
  const mime =
    String(
      fileType?.mime ||
      contentType ||
      ""
    ).toLowerCase();

  const ext =
    String(
      fileType?.ext ||
      ""
    ).toLowerCase();

  const type =
    String(
      declaredType ||
      ""
    ).toLowerCase();

  /*
   * VIDEO
   */

  if (
    mime.startsWith("video/") ||
    [
      "mp4",
      "mov",
      "webm",
      "mkv",
      "m4v",
      "3gp",
    ].includes(ext)
  ) {
    return "video";
  }

  /*
   * IMAGE
   */

  if (
    mime.startsWith("image/") ||
    [
      "jpg",
      "jpeg",
      "png",
      "webp",
      "gif",
      "avif",
      "heic",
    ].includes(ext)
  ) {
    return "image";
  }

  /*
   * AUDIO
   */

  if (
    mime.startsWith("audio/") ||
    [
      "mp3",
      "m4a",
      "ogg",
      "wav",
      "aac",
      "opus",
    ].includes(ext)
  ) {
    return "audio";
  }

  /*
   * Declared type fallback
   */

  if (
    type.includes("video") ||
    type.includes("reel")
  ) {
    return "video";
  }

  if (
    type.includes("image") ||
    type.includes("photo") ||
    type.includes("picture")
  ) {
    return "image";
  }

  if (
    type.includes("audio")
  ) {
    return "audio";
  }

  return "document";
}

//////////////////////////////////////////////////
// GET REAL MEDIA
//////////////////////////////////////////////////

async function getRealMedia(item) {
  const url =
    String(
      item?.url || ""
    ).trim();

  if (!url) {
    throw new Error(
      "URL media kosong dari API."
    );
  }

  const headers =
    item?.headers &&
    typeof item.headers === "object"
      ? item.headers
      : {};

  /*
   * Original URL dicoba pertama.
   * ?dl=1 hanya fallback karena signed URL
   * terkadang sensitif terhadap perubahan query.
   */

  const attempts = [
    url,
  ];

  const dlUrl =
    ensureDl(url);

  if (
    dlUrl &&
    dlUrl !== url
  ) {
    attempts.push(dlUrl);
  }

  let lastResult =
    null;

  let lastError =
    null;

  for (const attemptUrl of attempts) {
    try {
      const result =
        await downloadBuffer(
          attemptUrl,
          headers
        );

      const kind =
        detectMediaKind({
          fileType:
            result.fileType,

          contentType:
            result.contentType,

          declaredType:
            item.type,
        });

      lastResult = {
        ...result,

        kind,

        usedUrl:
          attemptUrl,

        forcedThumbnail:
          false,
      };

      if (
        kind === "video" ||
        kind === "image" ||
        kind === "audio"
      ) {
        return lastResult;
      }
    } catch (error) {
      lastError =
        error;

      console.error(
        "[Instagram] Download attempt gagal:",
        attemptUrl,
        error?.message
      );
    }
  }

  /*
   * Thumbnail hanya fallback terakhir.
   */

  if (
    item?.thumbnail &&
    isValidUrl(item.thumbnail)
  ) {
    try {
      const thumbnail =
        await downloadBuffer(
          item.thumbnail,
          headers
        );

      return {
        ...thumbnail,

        kind:
          "image",

        usedUrl:
          item.thumbnail,

        forcedThumbnail:
          true,
      };
    } catch (error) {
      lastError =
        error;
    }
  }

  if (lastResult?.buffer) {
    return lastResult;
  }

  throw new Error(
    lastError?.message ||
    "Tidak bisa mendapatkan media dari server."
  );
}

//////////////////////////////////////////////////
// SEND MEDIA
//////////////////////////////////////////////////

async function sendMedia({
  wafproject,
  chat,
  media,
  item,
  caption,
  quoted,
  index,
}) {
  const mime =
    String(
      media?.fileType?.mime ||
      media?.contentType ||
      ""
    ).toLowerCase();

  const ext =
    String(
      media?.fileType?.ext ||
      ""
    ).toLowerCase();

  const qualityText =
    item?.quality
      ? `\n🎞️ Kualitas: *${item.quality}*`
      : "";

  //////////////////////////////////////////////////
  // VIDEO
  //////////////////////////////////////////////////

  if (media.kind === "video") {
    return wafproject.sendMessage(
      chat,
      {
        video:
          media.buffer,

        mimetype:
          mime.startsWith("video/")
            ? mime
            : "video/mp4",

        caption:
          caption +
          qualityText,
      },
      {
        quoted,
      }
    );
  }

  //////////////////////////////////////////////////
  // IMAGE
  //////////////////////////////////////////////////

  if (media.kind === "image") {
    const fallbackNotice =
      media.forcedThumbnail
        ? "\n\n⚠️ _Video utama gagal diambil. Thumbnail dikirim sebagai fallback._"
        : "";

    return wafproject.sendMessage(
      chat,
      {
        image:
          media.buffer,

        mimetype:
          mime.startsWith("image/")
            ? mime
            : undefined,

        caption:
          caption +
          qualityText +
          fallbackNotice,
      },
      {
        quoted,
      }
    );
  }

  //////////////////////////////////////////////////
  // AUDIO
  //////////////////////////////////////////////////

  if (media.kind === "audio") {
    return wafproject.sendMessage(
      chat,
      {
        audio:
          media.buffer,

        mimetype:
          mime.startsWith("audio/")
            ? mime
            : "audio/mpeg",

        fileName:
          `instagram-${index}.${ext || "mp3"}`,
      },
      {
        quoted,
      }
    );
  }

  //////////////////////////////////////////////////
  // DOCUMENT
  //////////////////////////////////////////////////

  return wafproject.sendMessage(
    chat,
    {
      document:
        media.buffer,

      mimetype:
        mime ||
        "application/octet-stream",

      fileName:
        `instagram-${index}.${ext || "bin"}`,

      caption:
        caption +
        "\n\n⚠️ Format file tidak dikenali. File dikirim sebagai dokumen.",
    },
    {
      quoted,
    }
  );
}

//////////////////////////////////////////////////
// REACTION
//////////////////////////////////////////////////

async function sendReaction(
  wafproject,
  m,
  emoji
) {
  try {
    await wafproject.sendMessage(
      m.chat,
      {
        react: {
          text:
            emoji,

          key:
            m.key,
        },
      }
    );
  } catch {}
}

//////////////////////////////////////////////////
// HANDLER
//////////////////////////////////////////////////

let handler = async (
  m,
  {
    wafproject,
    text,
    usedPrefix,
    command,
  }
) => {
  const input =
    String(
      text || ""
    ).trim();

  //////////////////////////////////////////////////
  // INPUT
  //////////////////////////////////////////////////

  if (!input) {
    return m.reply(
      "📸 *INSTAGRAM DOWNLOADER*\n\n" +
      "Kirim link Instagram setelah command.\n\n" +
      `*Contoh:*\n` +
      `${usedPrefix + command} https://www.instagram.com/reel/xxxxxxxx/`
    );
  }

  const instagramUrl =
    extractInstagramUrl(input);

  if (!instagramUrl) {
    return m.reply(
      "❌ Link Instagram tidak valid.\n\n" +
      `Contoh:\n` +
      `${usedPrefix + command} https://www.instagram.com/reel/xxxxxxxx/`
    );
  }

  //////////////////////////////////////////////////
  // CONFIG
  //////////////////////////////////////////////////

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Konfigurasi JagoanProject belum lengkap.\n\n" +
      "Tambahkan di config.js / settings.js:\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";'
    );
  }

  //////////////////////////////////////////////////
  // PROCESS
  //////////////////////////////////////////////////

  await sendReaction(
    wafproject,
    m,
    "⏳"
  );

  try {
    const result =
      await fetchInstagram(
        instagramUrl
      );

    const {
      items,
      caption,
      username,
    } = result;

    //////////////////////////////////////////////////
    // CAPTION
    //////////////////////////////////////////////////

    const authorText =
      username
        ? `👤 *@${username}*\n`
        : "";

    const maxCaptionLength =
      2800;

    const safeCaption =
      cleanText(
        caption,
        "Instagram Downloader"
      ).slice(
        0,
        maxCaptionLength
      );

    //////////////////////////////////////////////////
    // DOWNLOAD & SEND
    //////////////////////////////////////////////////

    let successCount =
      0;

    let failedCount =
      0;

    for (
      let i = 0;
      i < items.length;
      i++
    ) {
      const item =
        items[i];

      try {
        console.log(
          `[Instagram] Memproses media ${i + 1}/${items.length}`,
          {
            type:
              item.type,

            quality:
              item.quality,

            url:
              item.url,
          }
        );

        const media =
          await getRealMedia(
            item
          );

        /*
         * Caption hanya dibuat lengkap pada
         * media pertama supaya carousel
         * tidak memenuhi chat.
         */

        let mediaCaption =
          "";

        if (i === 0) {
          mediaCaption =
            "📸 *Instagram Downloader*\n" +
            "━━━━━━━━━━━━━━━━━━\n" +
            authorText +
            `📝 ${safeCaption}`;
        } else {
          mediaCaption =
            `📸 *Instagram Downloader*\n` +
            `📂 Media ${i + 1}/${items.length}`;
        }

        await sendMedia({
          wafproject,

          chat:
            m.chat,

          media,

          item,

          caption:
            mediaCaption,

          quoted:
            i === 0
              ? m
              : undefined,

          index:
            i + 1,
        });

        successCount++;
      } catch (error) {
        failedCount++;

        console.error(
          `[Instagram] Media ${i + 1} gagal:`,
          error
        );
      }
    }

    //////////////////////////////////////////////////
    // HASIL
    //////////////////////////////////////////////////

    if (!successCount) {
      throw new Error(
        "Semua media gagal didownload."
      );
    }

    if (failedCount) {
      await m.reply(
        `⚠️ ${failedCount} media gagal didownload dari ${items.length} media.`
      );
    }

    await sendReaction(
      wafproject,
      m,
      "✅"
    );
  } catch (error) {
    console.error(
      "[Instagram Downloader Error]",
      error
    );

    await sendReaction(
      wafproject,
      m,
      "❌"
    );

    let message =
      String(
        error?.message ||
        "Terjadi kesalahan."
      );

    /*
     * Jangan bocorkan raw response API panjang
     * ke WhatsApp.
     */

    if (
      message.length > 500
    ) {
      message =
        message.slice(
          0,
          500
        ) + "...";
    }

    return m.reply(
      "📸 *Instagram Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "❌ Download gagal!\n\n" +
      `📌 ${message}`
    );
  }
};

//////////////////////////////////////////////////
// PLUGIN INFO
//////////////////////////////////////////////////

handler.help = [
  "ig <url>",
  "instagram <url>",
];

handler.tags = [
  "downloader",
];

handler.command =
  /^(ig|igdl|instagram|instagramdl)$/i;

handler.limit = false;

module.exports = handler;