/**
 * YouTube MP3/MP4 Downloader - JagoanProject
 *
 * Command:
 * .ytmp3 <judul / URL>
 * .ytmp4 <judul / URL>
 *
 * Endpoint:
 * GET /api/downloader/youtube-download
 *
 * Params:
 * url=<youtubeUrl>
 * format=mp3|mp4
 * raw=1
 */

const axios = require("axios");
const search = require("yt-search");

function cleanText(v, fallback = "") {
  if (typeof v !== "string" || !v.trim()) return fallback;
  return v.replace(/[\r\n]+/g, " ").replace(/\s+/g, " ").trim();
}

function isValidUrl(v) {
  return typeof v === "string" && /^https?:\/\//i.test(v.trim());
}

function isYouTubeUrl(url = "") {
  try {
    const h = new URL(String(url).trim()).hostname.toLowerCase().replace(/^www\./, "");
    return h === "youtube.com" || h.endsWith(".youtube.com") ||
           h === "youtu.be" || h.endsWith(".youtu.be") ||
           h === "youtube-nocookie.com" || h.endsWith(".youtube-nocookie.com");
  } catch {
    return false;
  }
}

function safeFileName(v, fallback = "youtube") {
  return cleanText(v, fallback)
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\.+$/g, "")
    .slice(0, 120) || fallback;
}

function formatNumber(v) {
  const n = Number(v || 0);
  return Number.isFinite(n) ? n.toLocaleString("id-ID") : "0";
}

async function searchYouTube(query) {
  const result = await search(query);
  const video = result?.videos?.[0];
  if (!video) throw new Error("Video YouTube tidak ditemukan.");

  return {
    url: video.url,
    title: cleanText(video.title, "YouTube Video"),
    thumbnail: video.thumbnail || video.image || "",
    duration: video.timestamp || "",
    views: video.views || 0,
    author: cleanText(video?.author?.name || "")
  };
}

async function fetchYouTube(youtubeUrl, format) {
  if (!global.jagoanApi) throw new Error("global.jagoanApi belum di-set.");
  if (!global.jagoanKey) throw new Error("global.jagoanKey belum di-set.");
  if (!isYouTubeUrl(youtubeUrl)) throw new Error("URL YouTube tidak valid.");
  if (!["mp3", "mp4"].includes(format)) throw new Error("Format tidak valid.");

  const baseUrl = String(global.jagoanApi).trim().replace(/\/+$/, "");
  const apiKey = String(global.jagoanKey).trim();

  console.log(`[YT${format.toUpperCase()}] Input:`, youtubeUrl);

  const res = await axios({
    method: "get",
    url: `${baseUrl}/api/downloader/youtube-download`,
    params: { url: youtubeUrl, format, raw: 1 },
    headers: { Authorization: `Bearer ${apiKey}` },
    timeout: 300000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = res.data;
  console.log(`[YT${format.toUpperCase()}] HTTP:`, res.status);

  if (res.status < 200 || res.status >= 300) {
    console.error(`[YT${format.toUpperCase()} API ERROR]`,
      typeof data === "string" ? data : JSON.stringify(data, null, 2)
    );

    throw new Error(
      data?.message || data?.msg || data?.error ||
      `JagoanProject HTTP ${res.status}`
    );
  }

  if (data?.status === false || data?.success === false) {
    throw new Error(
      data?.message || data?.msg || data?.error ||
      "Download YouTube gagal."
    );
  }

  const n = data?.data?.normalized || {};
  const d = data?.data?.data || {};

  const downloadUrl =
    n?.url ||
    d?.downloadUrl ||
    d?.download_url ||
    d?.url ||
    "";

  if (!isValidUrl(downloadUrl)) {
    console.error("[YT] URL DOWNLOAD TIDAK DITEMUKAN:", JSON.stringify(data, null, 2));
    throw new Error("URL download tidak ditemukan dari JagoanProject.");
  }

  const quality =
    cleanText(n?.quality || d?.selected?.label || "") ||
    (d?.selected?.quality ? `${d.selected.quality}${format === "mp3" ? "kbps" : "p"}` : "");

  const result = {
    url: downloadUrl,
    title: cleanText(n?.title || d?.title || "YouTube Media"),
    thumbnail: [n?.thumbnail, d?.thumbnail].find(isValidUrl) || "",
    duration: cleanText(n?.duration || d?.duration || ""),
    author: cleanText(n?.author || d?.author || ""),
    quality,
    size: n?.size ? String(n.size) : "",
    filename: cleanText(n?.filename || ""),
    ext: cleanText(n?.ext || format),
    contentType: cleanText(
      n?.contentType || (format === "mp3" ? "audio/mpeg" : "video/mp4")
    ),
    provider: cleanText(data?.data?.provider || "JagoanProject"),
    format
  };

  console.log(`[YT${format.toUpperCase()}] SUCCESS:`, {
    title: result.title,
    quality: result.quality,
    duration: result.duration,
    ext: result.ext,
    provider: result.provider
  });

  return result;
}

async function downloadBuffer(url, format) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 300000,
    validateStatus: () => true,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    maxRedirects: 10,
    headers: {
      Accept: format === "mp3" ? "audio/*,*/*" : "video/*,*/*",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }
  });

  if (res.status < 200 || res.status >= 300) {
    throw new Error(`CDN HTTP ${res.status}`);
  }

  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File hasil download kosong.");

  const contentType = String(res.headers?.["content-type"] || "")
    .split(";")[0].trim().toLowerCase();

  if (contentType.includes("text/html") || contentType.includes("application/json")) {
    throw new Error(`CDN mengembalikan ${contentType}, bukan media.`);
  }

  return { buffer, contentType };
}

async function sendAudio(wafproject, chat, result, quoted) {
  const fileName = result.filename ||
    `${safeFileName(result.title, "youtube-audio")}.${result.ext || "mp3"}`;

  try {
    return await wafproject.sendMessage(
      chat,
      {
        audio: { url: result.url },
        mimetype: result.contentType || "audio/mpeg",
        fileName,
        ptt: false
      },
      { quoted }
    );
  } catch (e) {
    console.log("[YTMP3] Direct URL gagal, fallback buffer:", e?.message || e);
  }

  const media = await downloadBuffer(result.url, "mp3");

  return wafproject.sendMessage(
    chat,
    {
      audio: media.buffer,
      mimetype: media.contentType.startsWith("audio/")
        ? media.contentType
        : "audio/mpeg",
      fileName,
      ptt: false
    },
    { quoted }
  );
}

async function sendVideo(wafproject, chat, result, caption, quoted) {
  try {
    return await wafproject.sendMessage(
      chat,
      {
        video: { url: result.url },
        mimetype: result.contentType || "video/mp4",
        caption
      },
      { quoted }
    );
  } catch (e) {
    console.log("[YTMP4] Direct URL gagal, fallback buffer:", e?.message || e);
  }

  const media = await downloadBuffer(result.url, "mp4");

  return wafproject.sendMessage(
    chat,
    {
      video: media.buffer,
      mimetype: media.contentType.startsWith("video/")
        ? media.contentType
        : "video/mp4",
      caption
    },
    { quoted }
  );
}

let handler = async (m, { wafproject, text, usedPrefix, command }) => {
  const input = String(text || "").trim();
  const cmd = String(command || "").toLowerCase();
  const format = cmd === "ytmp3" ? "mp3" : "mp4";
  const label = format === "mp3" ? "MP3" : "MP4";

  if (!input) {
    return m.reply(
      `📥 *YOUTUBE ${label} DOWNLOADER*\n\n` +
      `${usedPrefix + command} <judul / link YouTube>\n\n` +
      `Contoh:\n${usedPrefix + command} Mangu Fourtwnty\n` +
      `${usedPrefix + command} https://youtu.be/xxxxxxxx`
    );
  }

  if (!global.jagoanApi || !global.jagoanKey) {
    return m.reply(
      "❌ Konfigurasi JagoanProject belum lengkap.\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_KAMU";'
    );
  }

  const react = async emoji => {
    try {
      await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
    } catch {}
  };

  let statusMessage = null;

  const sendStatus = async text => {
    try {
      statusMessage = await wafproject.sendMessage(m.chat, { text }, { quoted: m });
      return statusMessage;
    } catch {
      return null;
    }
  };

  const editStatus = async text => {
    if (!statusMessage?.key) return null;

    try {
      return await wafproject.sendMessage(
        m.chat,
        { text, edit: statusMessage.key }
      );
    } catch {
      return null;
    }
  };

  try {
    await react("🕒");

    let info, youtubeUrl;

    if (isYouTubeUrl(input)) {
      youtubeUrl = input;

      info = {
        title: "YouTube Media",
        author: "",
        duration: "",
        views: 0,
        thumbnail: ""
      };

      await sendStatus(
        `📥 *YouTube ${label} Downloader*\n` +
        "━━━━━━━━━━━━━━━━━━\n" +
        "🔗 Link diterima ✅\n" +
        `📦 Format: *${label}*\n` +
        "⏳ Memproses media...\n" +
        "━━━━━━━━━━━━━━━━━━"
      );
    } else {
      await sendStatus(
        "🔎 *YouTube Search*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        `📝 Mencari: *${input.slice(0, 150)}*\n` +
        "⏳ Mohon tunggu...\n" +
        "━━━━━━━━━━━━━━━━━━"
      );

      info = await searchYouTube(input);
      youtubeUrl = info.url;

      await editStatus(
        `📥 *YouTube ${label} Downloader*\n` +
        "━━━━━━━━━━━━━━━━━━\n" +
        `🎬 ${info.title.slice(0, 150)}\n` +
        `📦 Format: *${label}*\n` +
        "⏳ Memproses media...\n" +
        "━━━━━━━━━━━━━━━━━━"
      );
    }

    const result = await fetchYouTube(youtubeUrl, format);

    const title =
      result.title && result.title !== "YouTube Media"
        ? result.title
        : info.title;

    const author = result.author || info.author || "";
    const duration = result.duration || info.duration || "";

    await editStatus(
      `📥 *YouTube ${label} Downloader*\n` +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Media ditemukan!\n" +
      `🎵 Judul: *${title.slice(0, 120)}*\n` +
      `🎚 Kualitas: *${result.quality || "Default"}*\n` +
      "📤 Mengirim media... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    if (format === "mp3") {
      await sendAudio(wafproject, m.chat, { ...result, title }, m);

      await editStatus(
        "🎵 *YouTube MP3 Downloader*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "✅ Audio berhasil dikirim!\n" +
        `🎵 *${title.slice(0, 150)}*\n` +
        `🎚 Kualitas: *${result.quality || "128kbps"}*\n` +
        "━━━━━━━━━━━━━━━━━━"
      );
    } else {
      let caption =
        "📥 *YouTube Downloader*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        `🎬 *${title.slice(0, 500)}*`;

      if (author) caption += `\n👤 Channel: *${author}*`;
      if (duration) caption += `\n⏱ Durasi: *${duration}*`;
      if (info.views) caption += `\n👁 Views: *${formatNumber(info.views)}*`;
      if (result.quality) caption += `\n🎞 Kualitas: *${result.quality}*`;

      caption += `\n⚙️ Provider: *${result.provider}*`;

      await sendVideo(
        wafproject,
        m.chat,
        { ...result, title },
        caption,
        m
      );

      await editStatus(
        "🎬 *YouTube MP4 Downloader*\n" +
        "━━━━━━━━━━━━━━━━━━\n" +
        "✅ Video berhasil dikirim!\n" +
        `🎞 Kualitas: *${result.quality || "Default"}*\n` +
        "━━━━━━━━━━━━━━━━━━"
      );
    }

    await react("✅");
  } catch (error) {
    console.error(`[YT${format.toUpperCase()} ERROR]`, error);
    await react("❌");

    let msg = cleanText(error?.message || String(error), "Terjadi kesalahan.");

    if (global.jagoanKey) {
      msg = msg.replaceAll(String(global.jagoanKey), "[API_KEY]");
    }

    msg = msg.slice(0, 500);

    const text =
      `📥 *YouTube ${label} Downloader*\n` +
      "━━━━━━━━━━━━━━━━━━\n" +
      "❌ Proses gagal!\n\n" +
      `📌 ${msg}\n` +
      "━━━━━━━━━━━━━━━━━━";

    const edited = await editStatus(text);
    if (!edited) return m.reply(text);
  }
};

handler.help = [
  "ytmp3 <judul/url>",
  "ytmp4 <judul/url>"
];

handler.tags = ["downloader"];
handler.category = ["downloader"];
handler.command = ["ytmp3", "ytmp4"];

handler.limit = true;
handler.premium = false;
handler.register = true;

module.exports = handler;