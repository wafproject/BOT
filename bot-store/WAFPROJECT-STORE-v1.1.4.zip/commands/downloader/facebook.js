/**
 * Facebook Downloader - JagoanProject
 *
 * Support:
 * - facebook.com/share/v/...
 * - facebook.com/share/r/...
 * - facebook.com/reel/...
 * - facebook.com/watch/?v=...
 * - fb.watch/...
 *
 * Endpoint:
 * GET https://api.jagoanproject.com/api/downloader/facebook?url=<facebookUrl>
 *
 * Header:
 * Authorization: Bearer APIKEY
 *
 * config.js / settings.js:
 *
 * global.jagoanApi = "https://api.jagoanproject.com";
 * global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";
 */

const axios = require("axios");

//////////////////////////////////////////////////
// VALIDASI URL FACEBOOK
//////////////////////////////////////////////////

function isFBUrl(url = "") {
  const value = String(url || "").trim();

  if (!value) {
    return false;
  }

  try {
    const parsed = new URL(value);

    const hostname = parsed.hostname
      .toLowerCase()
      .replace(/^www\./, "");

    return (
      hostname === "facebook.com" ||
      hostname.endsWith(".facebook.com") ||
      hostname === "fb.watch" ||
      hostname.endsWith(".fb.watch")
    );
  } catch {
    return false;
  }
}

//////////////////////////////////////////////////
// VALIDASI URL UMUM
//////////////////////////////////////////////////

function isValidUrl(value) {
  return (
    typeof value === "string" &&
    /^https?:\/\//i.test(value.trim())
  );
}

//////////////////////////////////////////////////
// AMBIL LINK FACEBOOK DARI INPUT
//////////////////////////////////////////////////

function extractFacebookUrl(text = "") {
  const input = String(text || "").trim();

  if (!input) {
    return null;
  }

  if (isFBUrl(input)) {
    return input;
  }

  const matches =
    input.match(/https?:\/\/[^\s]+/gi) || [];

  for (let match of matches) {
    match = match
      .replace(/[)\],}>.,]+$/g, "")
      .trim();

    if (isFBUrl(match)) {
      return match;
    }
  }

  return null;
}

//////////////////////////////////////////////////
// CLEAN TEXT
//////////////////////////////////////////////////

function cleanText(value, fallback = "") {
  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    return fallback;
  }

  return value
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

//////////////////////////////////////////////////
// NORMALIZE QUALITY
//////////////////////////////////////////////////

function normalizeQuality(value = "") {
  const quality =
    String(value || "").trim();

  if (!quality) {
    return "UNKNOWN";
  }

  const lower =
    quality.toLowerCase();

  if (
    lower.includes("2160") ||
    lower.includes("4k")
  ) {
    return "4K";
  }

  if (
    lower.includes("1440") ||
    lower.includes("2k")
  ) {
    return "2K";
  }

  if (
    lower.includes("1080") ||
    lower.includes("fhd") ||
    lower.includes("full hd")
  ) {
    return "FHD";
  }

  if (
    lower.includes("720") ||
    lower === "hd" ||
    lower.includes("high")
  ) {
    return "HD";
  }

  if (lower.includes("480")) {
    return "480P";
  }

  if (
    lower.includes("360") ||
    lower === "sd" ||
    lower.includes("standard")
  ) {
    return "SD";
  }

  return quality.toUpperCase();
}

//////////////////////////////////////////////////
// QUALITY SCORE
//////////////////////////////////////////////////

function qualityScore(value = "") {
  const quality =
    String(value || "")
      .trim()
      .toLowerCase();

  if (
    quality.includes("2160") ||
    quality.includes("4k")
  ) {
    return 600;
  }

  if (
    quality.includes("1440") ||
    quality.includes("2k")
  ) {
    return 500;
  }

  if (
    quality.includes("1080") ||
    quality.includes("fhd") ||
    quality.includes("full hd")
  ) {
    return 400;
  }

  if (
    quality.includes("720") ||
    quality === "hd" ||
    quality.includes("high")
  ) {
    return 300;
  }

  if (quality.includes("480")) {
    return 200;
  }

  if (
    quality.includes("360") ||
    quality === "sd" ||
    quality.includes("standard")
  ) {
    return 100;
  }

  return 0;
}

//////////////////////////////////////////////////
// AMBIL SEMUA VIDEO DARI RESPONSE
//////////////////////////////////////////////////

function getVideoCandidates(data) {
  const result = data?.data;

  if (
    !result ||
    typeof result !== "object"
  ) {
    return [];
  }

  const candidates = [];
  const seen = new Set();

  function addCandidate(
    url,
    quality = "UNKNOWN",
    source = ""
  ) {
    if (!isValidUrl(url)) {
      return;
    }

    const cleanUrl =
      String(url).trim();

    if (seen.has(cleanUrl)) {
      return;
    }

    seen.add(cleanUrl);

    candidates.push({
      url: cleanUrl,
      quality:
        normalizeQuality(quality),
      source,
    });
  }

  //////////////////////////////////////////////////
  // PRIORITAS DATA.HD
  //////////////////////////////////////////////////

  addCandidate(
    result?.hd,
    "HD",
    "data.hd"
  );

  //////////////////////////////////////////////////
  // DOWNLOADS[]
  //////////////////////////////////////////////////

  if (
    Array.isArray(result?.downloads)
  ) {
    for (const item of result.downloads) {
      if (!item) {
        continue;
      }

      const url =
        item?.url ||
        item?.download ||
        item?.download_url ||
        item?.downloadUrl ||
        item?.video ||
        item?.video_url ||
        item?.link;

      const quality =
        item?.quality ||
        item?.label ||
        item?.resolution ||
        "UNKNOWN";

      addCandidate(
        url,
        quality,
        "data.downloads"
      );
    }
  }

  //////////////////////////////////////////////////
  // SD
  //////////////////////////////////////////////////

  addCandidate(
    result?.sd,
    "SD",
    "data.sd"
  );

  //////////////////////////////////////////////////
  // FALLBACK FORMAT LAIN
  //////////////////////////////////////////////////

  addCandidate(
    result?.video,
    result?.quality || "UNKNOWN",
    "data.video"
  );

  addCandidate(
    result?.video_url,
    result?.quality || "UNKNOWN",
    "data.video_url"
  );

  addCandidate(
    result?.videoUrl,
    result?.quality || "UNKNOWN",
    "data.videoUrl"
  );

  addCandidate(
    result?.url,
    result?.quality || "UNKNOWN",
    "data.url"
  );

  //////////////////////////////////////////////////
  // URUTKAN KUALITAS
  //////////////////////////////////////////////////

  candidates.sort(
    (a, b) =>
      qualityScore(b.quality) -
      qualityScore(a.quality)
  );

  return candidates;
}

//////////////////////////////////////////////////
// TITLE
//////////////////////////////////////////////////

function getTitle(data) {
  return cleanText(
    data?.data?.title ||
    data?.data?.description ||
    data?.title ||
    "Facebook Video",
    "Facebook Video"
  );
}

//////////////////////////////////////////////////
// DESCRIPTION
//////////////////////////////////////////////////

function getDescription(data) {
  return cleanText(
    data?.data?.description ||
    "",
    ""
  );
}

//////////////////////////////////////////////////
// REQUEST JAGOANPROJECT
//////////////////////////////////////////////////

async function fetchFacebook(url) {
  if (!global.jagoanApi) {
    throw new Error(
      "Config belum lengkap: global.jagoanApi belum di-set."
    );
  }

  if (!global.jagoanKey) {
    throw new Error(
      "Config belum lengkap: global.jagoanKey belum di-set."
    );
  }

  const baseUrl =
    String(global.jagoanApi)
      .trim()
      .replace(/\/+$/, "");

  const apiKey =
    String(global.jagoanKey)
      .trim();

  if (!apiKey) {
    throw new Error(
      "API key JagoanProject kosong."
    );
  }

  if (!isFBUrl(url)) {
    throw new Error(
      "URL Facebook tidak valid."
    );
  }

  const originalUrl =
    String(url).trim();

  //////////////////////////////////////////////////
  // ENDPOINT YANG BENAR
  //////////////////////////////////////////////////

  const endpoint =
    `${baseUrl}/api/downloader/facebook` +
    `?url=${encodeURIComponent(originalUrl)}`;

  console.log(
    "[Facebook Downloader] Input:",
    originalUrl
  );

  console.log(
    "[Facebook Downloader] Endpoint:",
    `${baseUrl}/api/downloader/facebook`
  );

  //////////////////////////////////////////////////
  // REQUEST SESUAI CONTOH DASHBOARD
  //////////////////////////////////////////////////

  const response =
    await axios({
      method: "get",

      url: endpoint,

      headers: {
        Authorization:
          `Bearer ${apiKey}`,
      },

      timeout:
        120000,

      validateStatus:
        () => true,

      maxBodyLength:
        Infinity,

      maxContentLength:
        Infinity,
    });

  const data =
    response.data;

  console.log(
    "[Facebook Downloader] HTTP:",
    response.status
  );

  //////////////////////////////////////////////////
  // HTTP ERROR
  //////////////////////////////////////////////////

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    console.error(
      "[Facebook Downloader] API HTTP ERROR:",
      JSON.stringify(
        data,
        null,
        2
      )
    );

    const message =
      cleanText(
        data?.message ||
        data?.msg ||
        data?.error ||
        ""
      );

    throw new Error(
      message ||
      `JagoanProject HTTP ${response.status}`
    );
  }

  //////////////////////////////////////////////////
  // STATUS FALSE
  //////////////////////////////////////////////////

  if (
    data?.status === false ||
    data?.success === false
  ) {
    console.error(
      "[Facebook Downloader] API FAILED:",
      JSON.stringify(
        data,
        null,
        2
      )
    );

    throw new Error(
      cleanText(
        data?.message ||
        data?.msg ||
        data?.error ||
        "Gagal mengambil video Facebook."
      )
    );
  }

  //////////////////////////////////////////////////
  // DATA
  //////////////////////////////////////////////////

  if (
    !data?.data ||
    typeof data.data !== "object"
  ) {
    console.error(
      "[Facebook Downloader] DATA KOSONG:",
      JSON.stringify(
        data,
        null,
        2
      )
    );

    throw new Error(
      "Data video Facebook tidak ditemukan."
    );
  }

  //////////////////////////////////////////////////
  // VIDEO CANDIDATES
  //////////////////////////////////////////////////

  const candidates =
    getVideoCandidates(data);

  if (!candidates.length) {
    console.error(
      "[Facebook Downloader] VIDEO URL TIDAK DITEMUKAN:"
    );

    console.error(
      JSON.stringify(
        data,
        null,
        2
      )
    );

    throw new Error(
      "URL download video tidak ditemukan dari response JagoanProject."
    );
  }

  const title =
    getTitle(data);

  const description =
    getDescription(data);

  const thumbnail =
    data?.data?.thumbnail ||
    data?.data?.thumb ||
    null;

  console.log(
    "[Facebook Downloader] API SUCCESS:",
    {
      title,

      candidates:
        candidates.map(
          (item) => ({
            quality:
              item.quality,

            source:
              item.source,
          })
        ),
    }
  );

  return {
    title,

    description,

    thumbnail,

    candidates,

    creator:
      data?.creator ||
      "Jagoan Project",

    input:
      data?.input ||
      originalUrl,
  };
}

//////////////////////////////////////////////////
// DOWNLOAD VIDEO BUFFER
//////////////////////////////////////////////////

async function downloadVideoBuffer(url) {
  if (!isValidUrl(url)) {
    throw new Error(
      "URL video tidak valid."
    );
  }

  const response =
    await axios.get(
      url,
      {
        responseType:
          "arraybuffer",

        timeout:
          180000,

        validateStatus:
          () => true,

        maxBodyLength:
          Infinity,

        maxContentLength:
          Infinity,

        maxRedirects:
          10,

        headers: {
          Accept:
            "video/mp4,video/*,*/*",

          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36",

          Referer:
            "https://www.facebook.com/",
        },
      }
    );

  //////////////////////////////////////////////////
  // STATUS CDN
  //////////////////////////////////////////////////

  if (
    response.status < 200 ||
    response.status >= 300
  ) {
    throw new Error(
      `CDN Facebook HTTP ${response.status}`
    );
  }

  const contentType =
    String(
      response.headers?.["content-type"] ||
      ""
    )
      .split(";")[0]
      .trim()
      .toLowerCase();

  const buffer =
    Buffer.from(
      response.data
    );

  if (!buffer.length) {
    throw new Error(
      "File video kosong."
    );
  }

  //////////////////////////////////////////////////
  // CEGAH HTML / JSON DIANGGAP VIDEO
  //////////////////////////////////////////////////

  if (
    contentType.includes(
      "text/html"
    ) ||
    contentType.includes(
      "application/json"
    )
  ) {
    throw new Error(
      `CDN mengembalikan ${contentType}, bukan video.`
    );
  }

  return {
    buffer,
    contentType,
  };
}

//////////////////////////////////////////////////
// DOWNLOAD VIDEO
//
// HD gagal -> coba candidate berikutnya -> SD
//////////////////////////////////////////////////

async function getDownloadableVideo(
  candidates
) {
  if (
    !Array.isArray(candidates) ||
    !candidates.length
  ) {
    throw new Error(
      "Daftar video kosong."
    );
  }

  let lastError =
    null;

  for (
    let i = 0;
    i < candidates.length;
    i++
  ) {
    const candidate =
      candidates[i];

    console.log(
      `[Facebook Downloader] Mencoba ${candidate.quality} (${i + 1}/${candidates.length})`
    );

    try {
      const result =
        await downloadVideoBuffer(
          candidate.url
        );

      const sizeMb =
        (
          result.buffer.length /
          1024 /
          1024
        ).toFixed(2);

      console.log(
        "[Facebook Downloader] Download berhasil:",
        {
          quality:
            candidate.quality,

          source:
            candidate.source,

          size:
            `${sizeMb} MB`,

          contentType:
            result.contentType,
        }
      );

      return {
        ...candidate,

        buffer:
          result.buffer,

        contentType:
          result.contentType,

        sizeMb,
      };
    } catch (error) {
      lastError =
        error;

      console.error(
        `[Facebook Downloader] ${candidate.quality} gagal:`,
        error?.message ||
        error
      );
    }
  }

  throw new Error(
    lastError?.message ||
    "Semua kualitas video gagal didownload."
  );
}

//////////////////////////////////////////////////
// SEND VIDEO
//////////////////////////////////////////////////

async function sendVideo({
  wafproject,
  chat,
  video,
  caption,
  quoted,
}) {
  const mimetype =
    video?.contentType &&
    video.contentType.startsWith(
      "video/"
    )
      ? video.contentType
      : "video/mp4";

  return wafproject.sendMessage(
    chat,
    {
      video:
        video.buffer,

      mimetype,

      caption,
    },
    {
      quoted,
    }
  );
}

//////////////////////////////////////////////////
// REACTION
//////////////////////////////////////////////////

async function react(
  wafproject,
  m,
  emoji
) {
  try {
    await wafproject.sendMessage(
      m.chat,
      {
        react: {
          text:
            emoji,

          key:
            m.key,
        },
      }
    );
  } catch {
    // Reaction gagal tidak perlu menggagalkan downloader
  }
}

//////////////////////////////////////////////////
// FRIENDLY ERROR
//////////////////////////////////////////////////

function safeErrorMessage(error) {
  let message =
    cleanText(
      error?.message ||
      String(error || "") ||
      "Terjadi kesalahan."
    );

  //////////////////////////////////////////////////
  // SEMBUNYIKAN API KEY
  //////////////////////////////////////////////////

  if (global.jagoanKey) {
    message =
      message.replaceAll(
        String(global.jagoanKey),
        "[API_KEY]"
      );
  }

  const lower =
    message.toLowerCase();

  //////////////////////////////////////////////////
  // LIMIT REFUND
  //////////////////////////////////////////////////

  if (
    lower.includes("limit") &&
    lower.includes("dikembalikan")
  ) {
    return (
      "JagoanProject gagal memproses request, " +
      "tetapi limit sudah dikembalikan."
    );
  }

  //////////////////////////////////////////////////
  // PRIVATE / INVALID
  //////////////////////////////////////////////////

  if (
    lower.includes(
      "video private"
    ) ||
    lower.includes(
      "url tidak valid"
    )
  ) {
    return (
      "Video Facebook gagal diproses oleh JagoanProject. " +
      "Pastikan link masih aktif dan postingan dapat diakses."
    );
  }

  //////////////////////////////////////////////////
  // CDN
  //////////////////////////////////////////////////

  if (
    lower.includes(
      "cdn facebook"
    )
  ) {
    return (
      "Video ditemukan, tetapi file dari CDN Facebook gagal diunduh. " +
      "Silakan coba ulang beberapa saat lagi."
    );
  }

  return message.slice(
    0,
    400
  );
}

//////////////////////////////////////////////////
// HANDLER
//////////////////////////////////////////////////

let handler = async (
  m,
  {
    wafproject,
    text,
    usedPrefix,
    command,
  }
) => {
  const input =
    String(
      text || ""
    ).trim();

  //////////////////////////////////////////////////
  // INPUT KOSONG
  //////////////////////////////////////////////////

  if (!input) {
    return m.reply(
      "📘 *FACEBOOK DOWNLOADER*\n\n" +
      "Kirim link Facebook setelah command.\n\n" +
      "*Contoh:*\n" +
      `${usedPrefix + command} https://www.facebook.com/share/v/xxxxxxxx/`
    );
  }

  //////////////////////////////////////////////////
  // URL FACEBOOK
  //////////////////////////////////////////////////

  const facebookUrl =
    extractFacebookUrl(
      input
    );

  if (!facebookUrl) {
    return m.reply(
      "❌ Link Facebook tidak valid.\n\n" +
      "*Contoh:*\n" +
      `${usedPrefix + command} https://www.facebook.com/share/v/xxxxxxxx/`
    );
  }

  //////////////////////////////////////////////////
  // CONFIG
  //////////////////////////////////////////////////

  if (
    !global.jagoanApi ||
    !global.jagoanKey
  ) {
    return m.reply(
      "❌ Konfigurasi JagoanProject belum lengkap.\n\n" +
      "Tambahkan di config.js / settings.js:\n\n" +
      'global.jagoanApi = "https://api.jagoanproject.com";\n' +
      'global.jagoanKey = "API_KEY_JAGOANPROJECT_KAMU";'
    );
  }

  //////////////////////////////////////////////////
  // STATUS MESSAGE
  //////////////////////////////////////////////////

  let statusMessage =
    null;

  const sendStatus =
    async (message) => {
      try {
        statusMessage =
          await wafproject.sendMessage(
            m.chat,
            {
              text:
                message,
            },
            {
              quoted:
                m,
            }
          );

        return statusMessage;
      } catch (error) {
        console.error(
          "[Facebook Downloader] sendStatus:",
          error?.message ||
          error
        );

        return null;
      }
    };

  const editStatus =
    async (message) => {
      if (
        !statusMessage?.key
      ) {
        return null;
      }

      try {
        return await wafproject.sendMessage(
          m.chat,
          {
            text:
              message,

            edit:
              statusMessage.key,
          }
        );
      } catch (error) {
        console.error(
          "[Facebook Downloader] editStatus:",
          error?.message ||
          error
        );

        return null;
      }
    };

  //////////////////////////////////////////////////
  // START
  //////////////////////////////////////////////////

  try {
    await react(
      wafproject,
      m,
      "🕒"
    );

    await sendStatus(
      "📘 *Facebook Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "🔗 Link diterima ✅\n" +
      "🔎 Mengambil informasi video... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    //////////////////////////////////////////////////
    // REQUEST API
    //////////////////////////////////////////////////

    const result =
      await fetchFacebook(
        facebookUrl
      );

    const bestCandidate =
      result.candidates[0];

    await editStatus(
      "📘 *Facebook Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Video ditemukan!\n" +
      `🎞 Kualitas: *${bestCandidate?.quality || "UNKNOWN"}*\n` +
      "⬇️ Mengunduh video... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    //////////////////////////////////////////////////
    // DOWNLOAD VIDEO
    //////////////////////////////////////////////////

    const video =
      await getDownloadableVideo(
        result.candidates
      );

    await editStatus(
      "📘 *Facebook Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Video berhasil diunduh!\n" +
      `🎞 Kualitas: *${video.quality}*\n` +
      `📦 Ukuran: *${video.sizeMb} MB*\n` +
      "📤 Mengirim ke WhatsApp... ⏳\n" +
      "━━━━━━━━━━━━━━━━━━"
    );

    //////////////////////////////////////////////////
    // CAPTION
    //////////////////////////////////////////////////

    const title =
      cleanText(
        result.title,
        "Facebook Video"
      ).slice(
        0,
        700
      );

    const description =
      cleanText(
        result.description,
        ""
      ).slice(
        0,
        700
      );

    let caption =
      "📘 *Facebook Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      `📝 ${title}`;

    if (
      description &&
      description !== title
    ) {
      caption +=
        `\n\n💬 ${description}`;
    }

    caption +=
      `\n\n🎞 Kualitas: *${video.quality}*`;

    //////////////////////////////////////////////////
    // SEND
    //////////////////////////////////////////////////

    await sendVideo({
      wafproject,

      chat:
        m.chat,

      video,

      caption,

      quoted:
        m,
    });

    //////////////////////////////////////////////////
    // DONE
    //////////////////////////////////////////////////

    await editStatus(
      "📘 *Facebook Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "✅ Video berhasil dikirim!\n" +
      `🎞 Kualitas: *${video.quality}*\n` +
      `📦 Ukuran: *${video.sizeMb} MB*\n` +
      "━━━━━━━━━━━━━━━━━━"
    );

    await react(
      wafproject,
      m,
      "✅"
    );
  } catch (error) {
    console.error(
      "[Facebook Downloader Error]",
      error
    );

    await react(
      wafproject,
      m,
      "❌"
    );

    const errorMessage =
      safeErrorMessage(
        error
      );

    const message =
      "📘 *Facebook Downloader*\n" +
      "━━━━━━━━━━━━━━━━━━\n" +
      "❌ Download gagal!\n\n" +
      `📌 ${errorMessage}\n` +
      "━━━━━━━━━━━━━━━━━━";

    const edited =
      await editStatus(
        message
      );

    if (!edited) {
      return m.reply(
        message
      );
    }
  }
};

//////////////////////////////////////////////////
// PLUGIN INFO
//////////////////////////////////////////////////

handler.command =
  /^(fb|fbdl)$/i;

handler.help = [
  "fb <url>",
  "fbdl <url>",
];

handler.tags = [
  "downloader",
];

handler.category = [
  "downloader",
];

handler.limit = true;
handler.register = true;

module.exports = handler;