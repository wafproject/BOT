#!/usr/bin/env node

async function main() {
  function ok(name, detail = '') {
    console.log(`✅ ${name}${detail ? `: ${detail}` : ''}`)
  }

  try {
    const Database = require('better-sqlite3')
    const db = new Database(':memory:')
    db.exec('CREATE TABLE t (id INTEGER)')
    db.close()
    ok('better-sqlite3 native', require('better-sqlite3/package.json').version)
  } catch (error) {
    console.error('❌ better-sqlite3 gagal dimuat:', error?.message || error)
    process.exit(1)
  }

  try {
    const sharp = require('sharp')
    await sharp({ create: { width: 2, height: 2, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } })
      .webp()
      .toBuffer()
    ok('sharp native', sharp.versions?.sharp || require('sharp/package.json').version)
  } catch (error) {
    console.error('❌ sharp gagal dimuat:', error?.message || error)
    process.exit(1)
  }

  try {
    require('node-webpmux')
    ok('node-webpmux')
  } catch (error) {
    console.error('❌ node-webpmux gagal dimuat:', error?.message || error)
    process.exit(1)
  }

  try {
    require('zapo-js')
    require('@zapo-js/store-sqlite')
    require('@zapo-js/media-utils')
    ok('Zapo runtime')
  } catch (error) {
    console.error('❌ Zapo runtime gagal dimuat:', error?.message || error)
    process.exit(1)
  }

  console.log(`✅ Runtime check selesai — Node ${process.version} ${process.platform}/${process.arch}`)
}

main().catch((error) => {
  console.error('❌ Runtime check fatal:', error)
  process.exit(1)
})
