/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
📦 FINAL INDEX.JS
========================
*/

require("./settings")

const fs = require("fs")
const os = require("os")
const path = require("path")
const axios = require("axios")
const chalk = require("chalk")
const readline = require("readline")
const { Boom } = require("@hapi/boom")
const qrcode = require("qrcode-terminal")
const NodeCache = require("node-cache")
const { toBuffer } = require("qrcode")
const { exec } = require("child_process")
const { parsePhoneNumber } = require("awesome-phonenumber")

const {
  createZapoAuthState,
  ZapoDisconnectReason,
  decodeJid,
  normalizeUserJid,
  createZapoSocket,
  downloadMediaMessage,
} = require("./lib/zapo-adapter.js")

const { app, server, PORT } = require("./lib/server")
const { dataBase } = require("./lib/database")

const {
  ROOT_DIR,
  SESSION_DIR,
  LEGACY_AUTH_DIR,
  TEMP_DIR,
} = require("./lib/project-paths")

const { printIncomingChat } = require("./lib/printchat")
const log = require("./lib/consoleLog")

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

const question = (text) =>
  new Promise((resolve) => rl.question(text, resolve))

let usePairingCode = null
let pairingPhoneNumber = ""
let loginMethodConfigured = false
let loginFlow = null
let reconnectTimer = null
let startInProgress = false
let activeSocketGeneration = 0
let pluginsBootstrapped = false
let verifiedLicenseNumber = ""

let commandWatcher = null
let commandReloadTimer = null
let commandReloadRunning = false
let commandReloadPending = false
let commandReloadPendingFile = ""

const sleep = (ms) =>
  new Promise((resolve) => setTimeout(resolve, ms))

function withTimeout(promise, timeoutMs, fallback = null) {
  let timer

  return Promise.race([
    Promise.resolve(promise),

    new Promise((resolve) => {
      timer = setTimeout(
        () => resolve(fallback),
        timeoutMs
      )
    }),
  ]).finally(() => clearTimeout(timer))
}

function getDisconnectStatusCode(error) {
  try {
    return (
      error?.output?.statusCode ||
      error?.data?.statusCode ||
      error?.statusCode ||
      new Boom(error)?.output?.statusCode ||
      0
    )
  } catch {
    return 0
  }
}

function sanitizePhoneNumber(value) {
  let number = String(value || "").replace(/\D/g, "")

  if (number.startsWith("0")) {
    number = "62" + number.slice(1)
  }

  return number
}

function getConnectedPhoneNumber(wafproject, state) {
  const candidates = [
    wafproject?.user?.id,
    wafproject?.user?.jid,
    state?.creds?.me?.id,
    state?.creds?.me?.jid,
  ]

  for (const candidate of candidates) {
    const jid = String(candidate || "")
    const localPart = jid.split("@")[0].split(":")[0]
    const number = sanitizePhoneNumber(localPart)

    if (/^\d{8,15}$/.test(number)) {
      return number
    }
  }

  return ""
}

function printLicenseRejected(number = "") {
  console.log("")

  console.log(
    chalk.red.bold(
      `⛔ Licence tidak valid${
        number ? ` untuk nomor ${number}` : ""
      }!`
    )
  )

  console.log(
    chalk.yellow.bold(
      "Login dibatalkan dan plugin tidak akan dimuat."
    )
  )

  console.log(
    chalk.blue.bold(
      "Enzi WAF Project — 0877 3128 2876"
    )
  )

  console.log("")
}

async function verifyLicenseNumber(
  number,
  { silent = false } = {}
) {
  const normalized = sanitizePhoneNumber(number)

  if (!/^\d{8,15}$/.test(normalized)) {
    if (!silent) {
      console.log(
        chalk.red(
          "✗ Nomor licence tidak valid."
        )
      )
    }

    return false
  }

  if (!silent) {
    console.log(
      chalk.hex("#45B7D1")(
        `\n🔐 Memeriksa licence nomor: ${normalized}`
      )
    )
  }

  const valid = await checkLicense(normalized)

  if (!valid) {
    return false
  }

  verifiedLicenseNumber = normalized

  if (!silent) {
    console.log(
      chalk.hex("#00FF7F").bold(
        "✅ Licence terverifikasi."
      )
    )
  }

  return true
}

async function rejectAndExitForInvalidLicense(
  number = ""
) {
  printLicenseRejected(number)

  try {
    rl.close()
  } catch {}

  process.exit(1)
}

function purgeWhatsAppSession() {
  for (const dir of [
    SESSION_DIR,
    LEGACY_AUTH_DIR,
  ]) {
    try {
      fs.rmSync(
        dir,
        {
          recursive: true,
          force: true,
        }
      )
    } catch {}
  }
}

// ==============================
// DATABASE FILES
// ==============================

const legacyStoreFile =
  path.join(
    ROOT_DIR,
    "database",
    "baileys_store.json"
  )

const zapoStoreFile =
  path.join(
    ROOT_DIR,
    "database",
    "zapo_store.json"
  )

if (
  !fs.existsSync(zapoStoreFile) &&
  fs.existsSync(legacyStoreFile)
) {
  try {
    fs.copyFileSync(
      legacyStoreFile,
      zapoStoreFile
    )
  } catch (error) {
    console.warn(
      "[ZAPO STORE MIGRATION]",
      error?.message || error
    )
  }
}

const storeDB =
  dataBase("zapo_store.json")

const database =
  dataBase("database.json")

global.dbAdapter = database

const db = require("./lib/db")
const handleMessage = require("./lib/handler")
const groupParticipantsUpdate = require("./lib/group-participants")
const antiCallHandler = require("./lib/anticall")
const { checkLicense } = require("./lib/sticker")

const JidNormalizer =
  require("./lib/JidNormalizer")

global.plugins = []

// ======================================================
// PLAY INTERACTIVE ROUTER
// ======================================================
//
// Ini dipanggil LANGSUNG dari messages.upsert.
//
// Tujuan:
// .play mangu
// -> plugin menyimpan session
// -> user kirim "1" sebagai pesan biasa
// -> index.js langsung panggil before() milik plugin play
//
// Tidak bergantung lagi pada apakah lib/handler.js
// menjalankan before() untuk pesan non-command.
// ======================================================

function pluginHasCommand(plugin, wanted) {
  const target =
    String(wanted || "")
      .trim()
      .toLowerCase()

  if (!plugin || !target) {
    return false
  }

  if (typeof plugin.command === "string") {
    return (
      plugin.command
        .trim()
        .toLowerCase() === target
    )
  }

  if (Array.isArray(plugin.command)) {
    return plugin.command.some((cmd) => {
      if (typeof cmd === "string") {
        return (
          cmd.trim().toLowerCase() ===
          target
        )
      }

      if (cmd instanceof RegExp) {
        try {
          const flags =
            cmd.flags.replace(/g/g, "")

          return new RegExp(
            cmd.source,
            flags
          ).test(target)
        } catch {
          return false
        }
      }

      return false
    })
  }

  if (plugin.command instanceof RegExp) {
    try {
      const flags =
        plugin.command.flags.replace(
          /g/g,
          ""
        )

      return new RegExp(
        plugin.command.source,
        flags
      ).test(target)
    } catch {
      return false
    }
  }

  return false
}

function unwrapIncomingMessage(message) {
  let current = message || {}
  for (let i = 0; i < 8; i++) {
    if (current?.ephemeralMessage?.message) current = current.ephemeralMessage.message
    else if (current?.viewOnceMessage?.message) current = current.viewOnceMessage.message
    else if (current?.viewOnceMessageV2?.message) current = current.viewOnceMessageV2.message
    else if (current?.viewOnceMessageV2Extension?.message) current = current.viewOnceMessageV2Extension.message
    else if (current?.documentWithCaptionMessage?.message) current = current.documentWithCaptionMessage.message
    else if (current?.editedMessage?.message) current = current.editedMessage.message
    else break
  }
  return current || {}
}

function getIncomingText(message) {
  const msg = unwrapIncomingMessage(message)
  let body =
    msg?.buttonsResponseMessage?.selectedButtonId ||
    msg?.buttonsResponseMessage?.selectedDisplayText ||
    msg?.listResponseMessage?.singleSelectReply?.selectedRowId ||
    msg?.templateButtonReplyMessage?.selectedId ||
    msg?.templateButtonReplyMessage?.selectedDisplayText ||
    msg?.conversation ||
    msg?.extendedTextMessage?.text ||
    msg?.imageMessage?.caption ||
    msg?.videoMessage?.caption ||
    msg?.documentMessage?.caption ||
    ""

  if (!body && msg?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson) {
    try {
      const parsed = JSON.parse(msg.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson)
      body = parsed?.id || parsed?.selectedId || parsed?.buttonId || ""
    } catch {}
  }
  return String(body || "")
}

function recoverIncomingMessage(raw) {
  if (raw?.message && typeof raw.message === "object") return raw.message

  const event = raw?.__zapoEvent || raw || {}
  const candidates = [
    event?.message,
    event?.content?.message,
    event?.decrypted?.message,
    event?.payload?.message,
    event?.content,
    event?.decrypted,
    event?.payload,
  ]

  const knownKeys = new Set([
    "conversation", "extendedTextMessage", "imageMessage", "videoMessage",
    "documentMessage", "audioMessage", "stickerMessage", "buttonsResponseMessage",
    "listResponseMessage", "templateButtonReplyMessage", "interactiveResponseMessage",
    "reactionMessage", "protocolMessage", "pollUpdateMessage", "ephemeralMessage",
    "viewOnceMessage", "viewOnceMessageV2", "viewOnceMessageV2Extension",
    "documentWithCaptionMessage", "editedMessage",
  ])

  for (const candidate of candidates) {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue
    if (Object.keys(candidate).some((key) => knownKeys.has(key))) return candidate
  }
  return null
}

function ensureIncomingTimestamp(raw) {
  if (!raw || raw.messageTimestamp != null) return
  const event = raw?.__zapoEvent || raw || {}
  const ts =
    event?.messageTimestamp ??
    event?.timestamp ??
    event?.serverTimestamp ??
    event?.time ??
    Date.now()
  raw.messageTimestamp = ts
}

async function routePlaySelection(
  m,
  wafproject
) {
  const body = String(
    m?.text ||
    m?.message
      ?.buttonsResponseMessage
      ?.selectedButtonId ||
    m?.message
      ?.listResponseMessage
      ?.singleSelectReply
      ?.selectedRowId ||
    m?.message?.conversation ||
    m?.message
      ?.extendedTextMessage
      ?.text ||
    ""
  ).trim()

  // Hanya angka pilihan play
  if (!/^(?:[1-9]|10)$/.test(body)) {
    return false
  }

  const playPlugin =
    (global.plugins || []).find(
      (plugin) =>
        typeof plugin?.before ===
          "function" &&
        pluginHasCommand(
          plugin,
          "play"
        )
    )

  if (!playPlugin) {
    console.log(
      "[PLAY ROUTER] Plugin play dengan before() tidak ditemukan"
    )

    return false
  }

  try {
    console.log(
      "[PLAY ROUTER] Angka diterima:",
      {
        body,
        chat: m?.chat,
        sender: m?.sender,
        plugin:
          playPlugin.__file ||
          "play",
      }
    )

    const result =
      await playPlugin.before(
        m,
        {
          wafproject,
        }
      )

    if (result === true) {
      console.log(
        "[PLAY ROUTER] Pilihan berhasil ditangani:",
        body
      )

      return true
    }

    console.log(
      "[PLAY ROUTER] Plugin play tidak mengambil pesan:",
      body
    )

    return false
  } catch (error) {
    console.error(
      "[PLAY ROUTER ERROR]",
      error?.stack ||
      error?.message ||
      error
    )

    return false
  }
}

let autosaveStarted = false

const upsertDedupe =
  new NodeCache({
    stdTTL: 15,
    checkperiod: 30,
    maxKeys: 5000,
  })

const groupMetaCache =
  new NodeCache({
    stdTTL: 60,
    checkperiod: 120,
    maxKeys: 2000,
  })

async function getGroupMetadataCached(
  wafproject,
  jid
) {
  const key =
    String(jid || "")

  const cached =
    groupMetaCache.get(key)

  if (cached) {
    return cached
  }

  const meta =
    await wafproject.groupMetadata(
      key
    )

  groupMetaCache.set(
    key,
    meta
  )

  return meta
}

// Cache metadata yang sama dipakai handler supaya command grup tidak melakukan
// request groupMetadata kedua pada hot path. Peek tidak melakukan network I/O.
global.__wafPeekGroupMetadata = (jid) =>
  groupMetaCache.get(String(jid || "")) || null

global.__wafGetGroupMetadataCached = (wafproject, jid) =>
  getGroupMetadataCached(wafproject, jid)

async function warmupAllGroupsNoUI(
  wafproject,
  opts = {}
) {
  const concurrency = Math.max(
    1,
    Number(opts.concurrency || 3)
  )

  console.log(
    chalk.hex("#FFD93D").bold(
      "\n📚 Sedang membaca metadata group..."
    )
  )

  let groupsObj = {}

  try {
    groupsObj =
      await wafproject.groupFetchAllParticipating()
  } catch (error) {
    console.log(
      chalk.red(
        "❌ Gagal mengambil daftar grup (groupFetchAllParticipating)."
      )
    )

    console.error(
      "[GROUP WARMUP LIST ERROR]",
      error?.message || error
    )

    return {
      total: 0,
      ok: 0,
      fail: 0,
    }
  }

  const gids =
    Object.keys(groupsObj || {})
      .filter((jid) =>
        String(jid).endsWith("@g.us")
      )

  const total =
    gids.length

  if (!total) {
    console.log(
      chalk.yellow(
        "⚠️ Tidak ada grup terdeteksi untuk warmup."
      )
    )

    return {
      total: 0,
      ok: 0,
      fail: 0,
    }
  }

  let ok = 0
  let fail = 0
  let idx = 0

  async function worker() {
    while (idx < total) {
      const currentIndex =
        idx++

      const gid =
        gids[currentIndex]

      try {
        const meta =
          await JidNormalizer.warmupGroupCache(
            wafproject,
            gid
          )

        if (meta) {
          ok++
        } else {
          fail++
        }
      } catch {
        fail++
      }
    }
  }

  const workers =
    Array.from(
      {
        length: concurrency,
      },
      () => worker()
    )

  await Promise.allSettled(
    workers
  )

  console.log(
    chalk.hex("#00FF7F")(
      `✅ Warmup selesai: ${ok}/${total} sukses`
    ) +
      chalk.hex("#FF6B6B")(
        ` | ${fail} gagal`
      )
  )

  return {
    total,
    ok,
    fail,
  }
}

// ==============================
// LOAD COMMANDS
// ==============================

function formatPluginCategory(category) {
  const labels = {
    ai: "AI",
    downloader: "Downloader",
    group: "Group",
    main: "Main",
    owner: "Owner",
    pribadi: "Pribadi",
    search: "Search",
    stalk: "Stalk",
    sticker: "Sticker",
    store: "Store",
    tools: "Tools",
  }

  const key =
    String(
      category || "lainnya"
    ).toLowerCase()

  return (
    labels[key] ||
    key.charAt(0).toUpperCase() +
      key.slice(1)
  )
}

function loadCommands(
  dir = path.join(
    __dirname,
    "./commands"
  )
) {
  const startedAt =
    process.hrtime.bigint()

  const categoryStats =
    new Map()

  const failedPlugins = []

  global.plugins = []

  const ensureCategory =
    (category) => {
      if (
        !categoryStats.has(
          category
        )
      ) {
        categoryStats.set(
          category,
          {
            success: 0,
            failed: 0,
          }
        )
      }

      return categoryStats.get(
        category
      )
    }

  const walk = (folder) => {
    const entries =
      fs.readdirSync(folder)

    for (const file of entries) {
      const filepath =
        path.join(
          folder,
          file
        )

      const stat =
        fs.lstatSync(filepath)

      if (stat.isDirectory()) {
        walk(filepath)
        continue
      }

      if (!file.endsWith(".js")) {
        continue
      }

      const relativePath =
        path.relative(
          dir,
          filepath
        )

      const parts =
        relativePath.split(
          path.sep
        )

      const category =
        parts.length > 1
          ? parts[0]
          : "lainnya"

      const stats =
        ensureCategory(category)

      try {
        delete require.cache[
          require.resolve(
            filepath
          )
        ]

        const cmd =
          require(filepath)

        if (
          typeof cmd !==
          "function"
        ) {
          throw new TypeError(
            "Plugin wajib mengekspor function handler"
          )
        }

        const commands =
          Array.isArray(
            cmd.command
          )
            ? cmd.command
            : cmd.command instanceof
                RegExp
              ? [cmd.command]
              : typeof cmd.command ===
                  "string"
                ? [cmd.command]
                : []

        if (
          commands.length === 0 &&
          typeof cmd.all !==
            "function" &&
          typeof cmd.before !==
            "function"
        ) {
          console.warn(
            chalk.yellow(
              `  ⚠ Plugin tanpa command/hook: ${relativePath}`
            )
          )
        }

        cmd.__file =
          relativePath

        global.plugins.push(
          cmd
        )

        stats.success += 1
      } catch (error) {
        stats.failed += 1

        failedPlugins.push({
          file:
            relativePath,

          message:
            String(
              error?.message ||
              error ||
              "Unknown error"
            ).split("\n")[0],
        })
      }
    }
  }

  console.log(
    chalk
      .hex("#45B7D1")
      .bold(
        "\n📦 Memuat Plugin...\n"
      )
  )

  try {
    walk(dir)
  } catch (error) {
    failedPlugins.push({
      file:
        path.relative(
          __dirname,
          dir
        ) ||
        "commands",

      message:
        String(
          error?.message ||
          error ||
          "Gagal membaca folder plugin"
        ).split("\n")[0],
    })
  }

  const rows =
    [...categoryStats.entries()]
      .sort(
        ([a], [b]) =>
          a.localeCompare(b)
      )
      .map(
        ([category, stats]) => ({
          label:
            formatPluginCategory(
              category
            ),

          success:
            stats.success,

          failed:
            stats.failed,

          total:
            stats.success +
            stats.failed,
        })
      )

  const longestLabel =
    Math.max(
      10,
      ...rows.map(
        (row) =>
          row.label.length
      )
    )

  for (const row of rows) {
    const label =
      row.label.padEnd(
        longestLabel,
        " "
      )

    if (row.failed > 0) {
      console.log(
        "  " +
          chalk.yellow("⚠") +
          " " +
          chalk.white(label) +
          "  " +
          chalk.yellow(
            `${row.success}/${row.total} plugin`
          )
      )
    } else {
      console.log(
        "  " +
          chalk.hex(
            "#00FF7F"
          )("✓") +
          " " +
          chalk.white(label) +
          "  " +
          chalk.hex(
            "#96CEB4"
          )(
            `${row.success} plugin`
          )
      )
    }
  }

  if (
    failedPlugins.length > 0
  ) {
    console.log(
      chalk.yellow.bold(
        "\n⚠️ Plugin gagal dimuat:\n"
      )
    )

    for (
      const failure
      of failedPlugins
    ) {
      console.log(
        chalk.red(
          `  • ${failure.file}`
        )
      )

      console.log(
        chalk.gray(
          `    Error: ${failure.message}`
        )
      )
    }
  }

  const commandOwners =
    new Map()

  for (
    const plugin
    of global.plugins
  ) {
    const values =
      Array.isArray(
        plugin.command
      )
        ? plugin.command
        : typeof plugin.command ===
            "string"
          ? [plugin.command]
          : []

    for (
      const value
      of values
    ) {
      const key =
        String(value || "")
          .trim()
          .toLowerCase()

      if (!key) {
        continue
      }

      const owners =
        commandOwners.get(
          key
        ) || []

      owners.push(
        plugin.__file ||
        "unknown"
      )

      commandOwners.set(
        key,
        owners
      )
    }
  }

  const duplicateCommands =
    [...commandOwners.entries()]
      .filter(
        ([, owners]) =>
          owners.length > 1
      )

  if (
    duplicateCommands.length
  ) {
    console.log(
      chalk.yellow.bold(
        "\n⚠️ Command duplikat terdeteksi:"
      )
    )

    for (
      const [
        name,
        owners,
      ]
      of duplicateCommands
    ) {
      console.log(
        chalk.yellow(
          `  • ${name}: ${owners.join(
            " | "
          )}`
        )
      )
    }
  }

  const elapsedMs =
    Number(
      process.hrtime.bigint() -
      startedAt
    ) / 1_000_000

  const divider =
    "─".repeat(40)

  console.log(
    chalk.gray(
      `\n${divider}`
    )
  )

  console.log(
    chalk.hex("#00FF7F")(
      `✅ ${global.plugins.length} plugin berhasil dimuat`
    )
  )

  if (
    failedPlugins.length > 0
  ) {
    console.log(
      chalk.red(
        `❌ ${failedPlugins.length} plugin gagal dimuat`
      )
    )
  }

  console.log(
    chalk.hex("#45B7D1")(
      `⏱️ Proses selesai dalam ${elapsedMs.toFixed(
        0
      )} ms`
    )
  )

  console.log(
    failedPlugins.length >
      0
      ? chalk.yellow(
          "🟡 Bot tetap dijalankan dengan plugin yang berhasil"
        )
      : chalk.hex(
          "#00FF7F"
        )(
          "🟢 Semua plugin siap digunakan"
        )
  )

  console.log(
    chalk.gray(divider)
  )

  return {
    loaded:
      global.plugins.length,

    failed:
      failedPlugins.length,

    categories:
      rows,

    elapsedMs,
  }
}

function bootstrapPluginsAfterPairing() {
  if (pluginsBootstrapped) {
    return {
      loaded:
        global.plugins.length,

      skipped:
        true,
    }
  }

  console.log(
    chalk.hex("#45B7D1").bold(
      "\n🔓 Pairing/login sukses — baru memuat plugin..."
    )
  )

  const result =
    loadCommands()

  watchCommands()

  pluginsBootstrapped =
    true

  return result
}

function watchCommands(
  dir = path.join(
    __dirname,
    "./commands"
  )
) {
  if (commandWatcher) {
    return commandWatcher
  }

  const DEBOUNCE_MS =
    800

  const reloadPlugins =
    async (
      filename = "commands"
    ) => {
      if (
        commandReloadRunning
      ) {
        commandReloadPending =
          true

        commandReloadPendingFile =
          filename ||
          commandReloadPendingFile

        return
      }

      commandReloadRunning =
        true

      try {
        console.log(
          chalk.yellow(
            `\n♻️ Plugin ${filename} berubah, memuat ulang...`
          )
        )

        loadCommands(dir)
      } catch (error) {
        console.error(
          chalk.red(
            "[PLUGIN RELOAD ERROR]"
          ),
          error?.message ||
          error
        )
      } finally {
        commandReloadRunning =
          false

        if (
          commandReloadPending
        ) {
          const pendingFilename =
            commandReloadPendingFile ||
            filename

          commandReloadPending =
            false

          commandReloadPendingFile =
            ""

          clearTimeout(
            commandReloadTimer
          )

          commandReloadTimer =
            setTimeout(
              () => {
                void reloadPlugins(
                  pendingFilename
                )
              },
              DEBOUNCE_MS
            )
        }
      }
    }

  try {
    commandWatcher =
      fs.watch(
        dir,
        {
          recursive: true,
        },
        (
          eventType,
          filename
        ) => {
          if (!filename) {
            return
          }

          const normalizedFilename =
            String(filename)
              .replace(
                /\\/g,
                "/"
              )
              .trim()

          if (
            !normalizedFilename
              .toLowerCase()
              .endsWith(".js")
          ) {
            return
          }

          const basename =
            path.basename(
              normalizedFilename
            )

          if (
            basename.startsWith(
              "."
            ) ||
            basename.startsWith(
              "#"
            ) ||
            basename.endsWith(
              "~"
            ) ||
            basename.endsWith(
              ".tmp"
            ) ||
            basename.endsWith(
              ".temp"
            ) ||
            basename.endsWith(
              ".swp"
            ) ||
            basename.endsWith(
              ".swo"
            ) ||
            basename.endsWith(
              ".bak"
            )
          ) {
            return
          }

          clearTimeout(
            commandReloadTimer
          )

          commandReloadTimer =
            setTimeout(
              () => {
                void reloadPlugins(
                  normalizedFilename
                )
              },
              DEBOUNCE_MS
            )
        }
      )

    commandWatcher.on(
      "error",
      (error) => {
        console.error(
          chalk.red(
            "[PLUGIN WATCHER ERROR]"
          ),
          error?.message ||
          error
        )
      }
    )

    console.log(
      chalk.green(
        "✅ Watcher plugin aktif"
      )
    )

    return commandWatcher
  } catch (error) {
    console.error(
      chalk.red(
        "[PLUGIN WATCHER START ERROR]"
      ),
      error?.message ||
      error
    )

    commandWatcher =
      null

    return null
  }
}

// ==============================
// SESSION CHECK
// ==============================

function readSessionCreds(dir) {
  try {
    const credsPath =
      path.join(
        dir,
        "creds.json"
      )

    if (
      !fs.existsSync(
        credsPath
      )
    ) {
      return null
    }

    return JSON.parse(
      fs.readFileSync(
        credsPath,
        "utf8"
      )
    )
  } catch (error) {
    console.error(
      "[SESSION] Gagal membaca creds:",
      error?.message || error
    )

    return null
  }
}

function isUsableSessionCreds(
  creds
) {
  return Boolean(
    creds &&
      (
        creds.registered ===
          true ||
        creds.registered ===
          "true" ||
        creds.me?.id ||
        creds.me?.jid
      )
  )
}

function prepareSessionDirectory() {
  try {
    const sessionCreds =
      readSessionCreds(
        SESSION_DIR
      )

    const legacyCreds =
      readSessionCreds(
        LEGACY_AUTH_DIR
      )

    if (
      !fs.existsSync(
        SESSION_DIR
      ) &&
      fs.existsSync(
        LEGACY_AUTH_DIR
      )
    ) {
      try {
        fs.renameSync(
          LEGACY_AUTH_DIR,
          SESSION_DIR
        )

        console.log(
          chalk.green(
            "✅ Folder auth berhasil diganti menjadi session."
          )
        )
      } catch (
        renameError
      ) {
        fs.cpSync(
          LEGACY_AUTH_DIR,
          SESSION_DIR,
          {
            recursive: true,
            force: true,
          }
        )

        if (
          !isUsableSessionCreds(
            readSessionCreds(
              SESSION_DIR
            )
          )
        ) {
          throw renameError
        }

        fs.rmSync(
          LEGACY_AUTH_DIR,
          {
            recursive: true,
            force: true,
          }
        )

        console.log(
          chalk.green(
            "✅ Data auth berhasil dipindahkan ke folder session."
          )
        )
      }

      return
    }

    fs.mkdirSync(
      SESSION_DIR,
      {
        recursive: true,
      }
    )

    if (
      !isUsableSessionCreds(
        sessionCreds
      ) &&
      isUsableSessionCreds(
        legacyCreds
      )
    ) {
      fs.cpSync(
        LEGACY_AUTH_DIR,
        SESSION_DIR,
        {
          recursive: true,
          force: true,
        }
      )

      console.log(
        chalk.green(
          "✅ Session dipulihkan dari folder auth lama."
        )
      )
    }

    if (
      fs.existsSync(
        LEGACY_AUTH_DIR
      ) &&
      isUsableSessionCreds(
        readSessionCreds(
          SESSION_DIR
        )
      )
    ) {
      fs.rmSync(
        LEGACY_AUTH_DIR,
        {
          recursive: true,
          force: true,
        }
      )

      console.log(
        chalk.gray(
          "🧹 Folder auth lama sudah dibersihkan."
        )
      )
    }
  } catch (error) {
    console.error(
      "[SESSION] Gagal menyiapkan folder session:",
      error?.message || error
    )

    fs.mkdirSync(
      SESSION_DIR,
      {
        recursive: true,
      }
    )
  }
}

function moveLegacyTempContents(
  sourceDir
) {
  if (
    !fs.existsSync(
      sourceDir
    )
  ) {
    return
  }

  const sourceName =
    path.basename(
      sourceDir
    )

  const entries =
    fs.readdirSync(
      sourceDir,
      {
        withFileTypes: true,
      }
    )

  for (
    const entry
    of entries
  ) {
    const sourcePath =
      path.join(
        sourceDir,
        entry.name
      )

    let targetPath =
      path.join(
        TEMP_DIR,
        entry.name
      )

    if (
      fs.existsSync(
        targetPath
      )
    ) {
      targetPath =
        path.join(
          TEMP_DIR,
          `${sourceName}-${Date.now()}-${entry.name}`
        )
    }

    try {
      fs.renameSync(
        sourcePath,
        targetPath
      )
    } catch {
      fs.cpSync(
        sourcePath,
        targetPath,
        {
          recursive: true,
          force: true,
        }
      )

      fs.rmSync(
        sourcePath,
        {
          recursive: true,
          force: true,
        }
      )
    }
  }

  fs.rmSync(
    sourceDir,
    {
      recursive: true,
      force: true,
    }
  )
}

function prepareTempDirectory() {
  try {
    fs.mkdirSync(
      TEMP_DIR,
      {
        recursive: true,
      }
    )

    moveLegacyTempContents(
      path.join(
        ROOT_DIR,
        "tmp"
      )
    )

    moveLegacyTempContents(
      path.join(
        ROOT_DIR,
        "temp-edit"
      )
    )
  } catch (error) {
    console.error(
      "[TEMP] Gagal menyatukan folder sementara:",
      error?.message || error
    )
  }
}

function checkSessionExists() {
  try {
    const marker =
      path.join(
        SESSION_DIR,
        ".zapo-paired.json"
      )

    const sqlite =
      path.join(
        SESSION_DIR,
        "zapo-state.sqlite"
      )

    if (
      !fs.existsSync(sqlite)
    ) {
      return false
    }

    const parsed =
      JSON.parse(
        fs.readFileSync(
          marker,
          "utf8"
        )
      )

    if (
      parsed?.registered ===
      true
    ) {
      return true
    }
  } catch {}

  return false
}

function formatWIBDateTime(
  date = new Date()
) {
  try {
    return new Intl.DateTimeFormat(
      "id-ID",
      {
        timeZone:
          "Asia/Jakarta",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      }
    ).format(date)
  } catch {
    return String(
      date?.toLocaleString?.() ||
      new Date().toLocaleString()
    )
  }
}

// ==============================
// BANNER / LOGIN METHOD
// ==============================

async function showBannerAndDetectMethod() {
  console.clear()

  try {
    log.header({
      version:
        String(
          global.version ||
          "2.0.0"
        ),

      engine:
        "Zapo",
    })
  } catch {
    console.log(
      chalk
        .hex("#FFD93D")
        .bold(
          "WhatsApp Bot"
        )
    )
  }

  const sessionExists =
    checkSessionExists()

  if (sessionExists) {
    console.log(
      chalk
        .hex("#00FF7F")
        .bold(
          "\n✅ Session ditemukan!"
        )
    )

    console.log(
      chalk.hex("#45B7D1")(
        "📱 Mode: Auto Login"
      )
    )

    console.log(
      chalk.hex("#96CEB4")(
        "🔐 Licence akan diperiksa dari nomor WhatsApp yang terhubung sebelum plugin dimuat."
      )
    )

    console.log(
      chalk
        .hex("#FFD93D")
        .bold(
          "=".repeat(40)
        )
    )

    usePairingCode =
      false

    loginFlow =
      "auto"

    return usePairingCode
  }

  console.log(
    chalk
      .hex("#FF6B6B")
      .bold(
        "\n⚠️  Session tidak ditemukan"
      )
  )

  console.log(
    chalk
      .hex("#45B7D1")
      .bold(
        "📱 Pilih Metode Login:"
      )
  )

  console.log(
    chalk
      .hex("#FFEAA7")
      .bold("  [1] ") +
      chalk.white(
        "Pairing Code (No HP)"
      )
  )

  console.log(
    chalk
      .hex("#FFEAA7")
      .bold("  [2] ") +
      chalk.white(
        "QR Code"
      )
  )

  console.log(
    chalk
      .hex("#FFD93D")
      .bold(
        "=".repeat(40)
      )
  )

  let choice = ""

  while (
    !["1", "2"].includes(
      choice
    )
  ) {
    choice =
      String(
        await question(
          chalk.hex(
            "#4ECDC4"
          )(
            "Pilihan Anda (1/2): "
          )
        )
      ).trim()

    if (
      !["1", "2"].includes(
        choice
      )
    ) {
      console.log(
        chalk.red(
          "✗ Pilihan tidak valid. Masukkan 1 atau 2."
        )
      )
    }
  }

  usePairingCode =
    choice === "1"

  loginFlow =
    usePairingCode
      ? "pairing"
      : "qr"

  console.log(
    chalk.hex("#96CEB4")(
      usePairingCode
        ? "✓ Mode: Pairing Code dipilih"
        : "✓ Mode: QR Code dipilih"
    )
  )

  if (usePairingCode) {
    while (
      !pairingPhoneNumber
    ) {
      console.log(
        chalk
          .hex("#4ECDC4")
          .bold(
            "\n📞 Masukkan nomor WhatsApp yang akan dipairing"
          )
      )

      console.log(
        chalk.white(
          "   Contoh: 6281234567890 (tanpa tanda +)"
        )
      )

      const rawNumber =
        await question(
          chalk.hex(
            "#4ECDC4"
          )(
            "Nomor: "
          )
        )

      const normalized =
        sanitizePhoneNumber(
          rawNumber
        )

      if (
        /^\d{8,15}$/.test(
          normalized
        )
      ) {
        pairingPhoneNumber =
          normalized
      } else {
        console.log(
          chalk.red(
            "✗ Format nomor tidak valid. Gunakan kode negara, tanpa tanda +."
          )
        )
      }
    }

    let valid = false

    try {
      valid =
        await verifyLicenseNumber(
          pairingPhoneNumber
        )
    } catch (error) {
      console.error(
        chalk.red(
          `✗ Gagal memeriksa licence: ${
            error?.message ||
            error
          }`
        )
      )
    }

    if (!valid) {
      await rejectAndExitForInvalidLicense(
        pairingPhoneNumber
      )
    }

    console.log(
      chalk.hex("#96CEB4")(
        "🔓 Licence valid. Pairing Code akan diminta setelah koneksi pairing siap."
      )
    )
  } else {
    console.log(
      chalk.hex("#96CEB4")(
        "📷 QR akan ditampilkan setelah koneksi siap. Licence baru diperiksa setelah QR berhasil discan."
      )
    )
  }

  console.log(
    chalk
      .hex("#FFD93D")
      .bold(
        "=".repeat(40)
      )
  )

  return usePairingCode
}

function scheduleReconnect(
  delayMs = 5000,
  label =
    "Mencoba menghubungkan ulang..."
) {
  if (reconnectTimer) {
    return
  }

  console.log(
    chalk.yellow(
      `🔁 ${label}`
    )
  )

  reconnectTimer =
    setTimeout(
      () => {
        reconnectTimer =
          null

        void start({
          reconnect: true,
        })
      },
      delayMs
    )
}

// ==============================
// START BOT
// ==============================

async function start({
  reconnect = false,
} = {}) {
  if (startInProgress) {
    return
  }

  startInProgress = true

  try {
    if (
      !loginMethodConfigured
    ) {
      await showBannerAndDetectMethod()

      loginMethodConfigured =
        true
    } else if (reconnect) {
      console.log(
        chalk.cyan(
          "🔄 Membuat socket WhatsApp baru..."
        )
      )
    }

    const {
      state,
      saveCreds,
    } =
      await createZapoAuthState(
        SESSION_DIR
      )

    const socketGeneration =
      ++activeSocketGeneration

    let socketClosed =
      false

    let pairingRequested =
      false

    let latestQr =
      null

    let qrRouteMounted =
      false

    const socketConfig = {
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      nodeQueryTimeoutMs: 60000,
      keepAliveIntervalMs: 30000,
      historyEnabled: true,
      historyRequireFullSync: false,
      linkPreviewHq: true,
    }

    const wafproject =
      createZapoSocket(
        socketConfig
      )

    global.wafproject =
      wafproject

    global.__sewaConn =
      wafproject

    global.conn =
      wafproject

    wafproject.decodeJid =
      (jid) => {
        if (!jid) {
          return jid
        }

        const rawJid =
          String(jid).trim()

        try {
          const decode =
            decodeJid(
              rawJid
            ) || {}

          if (
            decode.user &&
            decode.server
          ) {
            return JidNormalizer.normalizeJid(
              `${decode.user}@${decode.server}`
            )
          }
        } catch (error) {
          console.error(
            "[ERROR][index.js]",
            error?.message ||
            error
          )
        }

        return JidNormalizer.normalizeJid(
          rawJid
        )
      }

    // ==============================
    // GROUP UPSERT
    // ==============================

    wafproject.ev.on(
      "groups.upsert",
      (groups) => {
        try {
          void Promise.resolve(
            groupParticipantsUpdate.onGroupsUpsert?.(
              wafproject,
              groups
            )
          ).catch((error) => {
            console.error(
              "[GROUPS UPSERT ANTI-CULIK ERROR]",
              error?.message ||
              error
            )
          })

          for (
            const group
            of groups || []
          ) {
            const gid =
              String(
                group?.id ||
                ""
              )

            if (
              gid.endsWith(
                "@g.us"
              )
            ) {
              void JidNormalizer.warmupGroupCache(
                wafproject,
                gid
              )
            }
          }
        } catch (error) {
          console.error(
            "[GROUPS UPSERT ERROR]",
            error?.message ||
            error
          )
        }
      }
    )

    // ==============================
    // MESSAGE HANDLER
    // ==============================

    wafproject.ev.on(
      "messages.upsert",
      async ({
        messages,
        type,
      }) => {
        const incomingMessages =
          Array.isArray(
            messages
          )
            ? messages
            : []

        for (
          const incoming
          of incomingMessages
        ) {
          let raw =
            incoming

          // Zapo dapat mengirim payload bertahap. Recover dari content/decrypted/payload
          // sebelum event dinilai kosong, supaya event lengkap tidak hilang.
          if (!raw?.message) {
            const recoveredMessage = recoverIncomingMessage(raw)
            if (recoveredMessage) raw = { ...raw, message: recoveredMessage }
          }

          if (!raw?.message) {
            continue
          }

          ensureIncomingTimestamp(raw)

          try {
            try {
              JidNormalizer.normalizeAllFromUpsert(
                wafproject,
                raw
              )
            } catch (error) {
              console.error(
                "[ERROR][index.js]",
                error?.message ||
                error
              )
            }

            // ==============================
            // DEDUPE
            // ==============================

            try {
              const norm =
                (jid = "") =>
                  String(
                    jid || ""
                  ).replace(
                    /:.*@/,
                    "@"
                  )

              const chat =
                norm(
                  raw.key
                    ?.remoteJid ||
                    ""
                )

              const sender =
                norm(
                  raw.key
                    ?.participant ||
                  raw.key
                    ?.senderPn ||
                  raw.key
                    ?.remoteJid ||
                  ""
                )

              const body = getIncomingText(raw.message)
              const id = raw.key?.id || ""
              const bodyTrim = String(body || "").trim()
              const unwrapped = unwrapIncomingMessage(raw.message)
              const messageKind =
                unwrapped?.protocolMessage ? "protocol" :
                unwrapped?.reactionMessage ? "reaction" :
                unwrapped?.pollUpdateMessage ? "poll-update" :
                unwrapped?.imageMessage ? "image" :
                unwrapped?.videoMessage ? "video" :
                unwrapped?.documentMessage ? "document" :
                unwrapped?.audioMessage ? "audio" :
                unwrapped?.stickerMessage ? "sticker" :
                Object.keys(unwrapped || {})[0] || "empty"

              // Jangan dedupe hanya berdasarkan ID. Event kosong pertama dan event
              // lengkap berikutnya dapat memakai ID yang sama. Bedakan berdasarkan
              // apakah body sudah tersedia / jenis message agar command lengkap lolos.
              if (id || bodyTrim) {
                const fingerprint = id
                  ? `id:${chat}|${id}|${bodyTrim ? "text:" + bodyTrim.slice(0, 120) : `kind:${messageKind}`}`
                  : `fp:${chat}|${sender}|${bodyTrim.slice(0, 120)}`

                if (upsertDedupe.get(fingerprint)) {
                  continue
                }
                upsertDedupe.set(fingerprint, true)
              }
            } catch (error) {
              console.error(
                "[ERROR][index.js]",
                error?.message ||
                error
              )
            }

            if (
              raw.message
                ?.editedMessage
                ?.message
                ?.protocolMessage
            ) {
              raw.message.protocolMessage =
                raw.message.editedMessage.message.protocolMessage
            }

            const isEdit =
              raw.message
                ?.protocolMessage
                ?.type === 14 ||
              raw.message
                ?.protocolMessage
                ?.type ===
                "MESSAGE_EDIT"

            if (
              raw.key?.fromMe &&
              !isEdit
            ) {
              continue
            }

            const getCorrectRemoteJid =
              (key = {}) => {
                const decoded =
                  [
                    key.senderPn,
                    key.participant,
                    key.remoteJid,
                  ]
                    .filter(
                      Boolean
                    )
                    .map(
                      (jid) =>
                        wafproject.decodeJid(
                          jid
                        )
                    )

                return (
                  decoded.find(
                    (jid) =>
                      String(
                        jid ||
                        ""
                      ).endsWith(
                        "@s.whatsapp.net"
                      )
                  ) ||
                  decoded.find(
                    Boolean
                  ) ||
                  ""
                )
              }

            raw.chat =
              wafproject.decodeJid(
                raw.key.remoteJid
              )

            raw.sender =
              getCorrectRemoteJid(
                raw.key
              )

            raw.fromMe =
              Boolean(
                raw.key?.fromMe
              )

            raw.key.remoteJid =
              raw.chat

            if (
              raw.key.participant
            ) {
              raw.key.participant =
                wafproject.decodeJid(
                  raw.key.participant
                )
            }

            if (
              raw.key.senderPn
            ) {
              raw.key.senderPn =
                wafproject.decodeJid(
                  raw.key.senderPn
                )
            }

            raw.isGroup =
              String(
                raw.chat ||
                ""
              ).endsWith(
                "@g.us"
              )

            raw.pushName =
              raw.pushName ||
              "User"

            raw.text = getIncomingText(raw.message)

            raw.download =
              () =>
                downloadMediaMessage(
                  raw,
                  "buffer",
                  {},
                  {
                    logger:
                      console,

                    reuploadRequest:
                      wafproject.updateMediaMessage,
                  }
                )

            // ==============================
            // QUOTED MESSAGE
            // ==============================

            if (
              raw?.message
                ?.extendedTextMessage
                ?.contextInfo
                ?.quotedMessage
            ) {
              const ctx =
                raw.message.extendedTextMessage.contextInfo

              const quoted =
                ctx.quotedMessage

              const quotedType =
                Object.keys(
                  quoted
                )[0]

              const quotedMessage =
                quoted[
                  quotedType
                ]

              const quotedParticipant =
                wafproject.decodeJid(
                  ctx.participant
                )

              raw.quoted = {
                key: {
                  remoteJid:
                    wafproject.decodeJid(
                      ctx.remoteJid ||
                      raw.chat
                    ),

                  fromMe:
                    quotedParticipant
                      ? normalizeUserJid(
                          quotedParticipant
                        ) ===
                        normalizeUserJid(
                          wafproject.decodeJid(
                            wafproject
                              .user.id
                          )
                        )
                      : false,

                  id:
                    ctx.stanzaId,

                  participant:
                    quotedParticipant,
                },

                sender:
                  quotedParticipant,

                message:
                  quoted,

                type:
                  quotedType,

                msg:
                  quotedMessage,

                text:
                  quotedMessage
                    ?.text ||
                  quotedMessage
                    ?.conversation ||
                  quotedMessage
                    ?.caption ||
                  quotedMessage
                    ?.contentText ||
                  quotedMessage
                    ?.selectedDisplayText ||
                  quotedMessage
                    ?.title ||
                  (
                    typeof quotedMessage ===
                    "string"
                      ? quotedMessage
                      : ""
                  ) ||
                  "",

                isMedia:
                  Boolean(
                    quotedMessage
                      ?.mimetype ||
                    quotedMessage
                      ?.thumbnailDirectPath
                  ),

                download:
                  () =>
                    downloadMediaMessage(
                      {
                        message:
                          quoted,
                      },
                      "buffer",
                      {},
                      {
                        logger:
                          console,

                        reuploadRequest:
                          wafproject.updateMediaMessage,
                      }
                    ),
              }
            }

            raw.reply =
              (text) =>
                wafproject.sendMessage(
                  raw.chat,
                  {
                    text:
                      String(text),
                  },
                  {
                    quote:
                      raw,
                  }
                )

            try {
              printIncomingChat(
                raw,
                wafproject
              )
            } catch (error) {
              console.error(
                "[ERROR][index.js]",
                error?.message ||
                error
              )
            }

            // ==============================
            // GROUP ADMIN CACHE
            // ==============================

            if (raw.isGroup) {
              void getGroupMetadataCached(
                wafproject,
                raw.chat
              )
                .then(
                  (metadata) => {
                    const participants =
                      Array.isArray(
                        metadata
                          ?.participants
                      )
                        ? metadata.participants
                        : []

                    const norm =
                      (
                        jid = ""
                      ) =>
                        String(
                          jid ||
                          ""
                        ).replace(
                          /:.*@/,
                          "@"
                        )

                    const sender =
                      norm(
                        raw.sender
                      )

                    const bot =
                      norm(
                        wafproject
                          .user
                          ?.id ||
                        ""
                      )

                    raw.isAdmin =
                      participants.some(
                        (
                          participant
                        ) =>
                          norm(
                            participant
                              ?.id ||
                            participant
                              ?.jid ||
                            participant
                              ?.participant
                          ) ===
                            sender &&
                          participant
                            ?.admin !=
                            null
                      )

                    raw.isBotAdmin =
                      participants.some(
                        (
                          participant
                        ) =>
                          norm(
                            participant
                              ?.id ||
                            participant
                              ?.jid ||
                            participant
                              ?.participant
                          ) ===
                            bot &&
                          participant
                            ?.admin !=
                            null
                      )
                  }
                )
                .catch(
                  () => {}
                )
            }

            // ==============================
            // EDIT PROCESSORS
            // ==============================

            if (
              raw.message
                ?.protocolMessage
            ) {
              try {
                const tasks = []

                for (
                  const plugin
                  of global.plugins ||
                  []
                ) {
                  if (
                    typeof plugin
                      ?.processEditFromUpsert ===
                    "function"
                  ) {
                    tasks.push(
                      Promise.resolve()
                        .then(
                          () =>
                            plugin.processEditFromUpsert(
                              wafproject,
                              db,
                              raw
                            )
                        )
                        .catch(
                          (
                            error
                          ) => {
                            console.error(
                              chalk.red(
                                "Error processEditFromUpsert:"
                              ),
                              error
                            )
                          }
                        )
                    )
                  }
                }

                void Promise.allSettled(
                  tasks
                )
              } catch (error) {
                console.error(
                  chalk.red(
                    "Error route processEditFromUpsert:"
                  ),
                  error
                )
              }
            }

            // ==============================
            // REACTION PROCESSORS
            // ==============================

            if (
              raw.message
                ?.reactionMessage
            ) {
              try {
                const tasks = []

                for (
                  const plugin
                  of global.plugins ||
                  []
                ) {
                  if (
                    typeof plugin
                      ?.processReactionFromUpsert ===
                    "function"
                  ) {
                    tasks.push(
                      Promise.resolve()
                        .then(
                          () =>
                            plugin.processReactionFromUpsert(
                              wafproject,
                              db,
                              raw
                            )
                        )
                        .catch(
                          (
                            error
                          ) => {
                            console.error(
                              chalk.red(
                                "Error processReactionFromUpsert:"
                              ),
                              error
                            )
                          }
                        )
                    )
                  }
                }

                void Promise.allSettled(
                  tasks
                )
              } catch (error) {
                console.error(
                  chalk.red(
                    "Error route processReactionFromUpsert:"
                  ),
                  error
                )
              }
            }

            // ==================================================
            // PLAY INTERACTIVE ROUTER
            // ==================================================
            //
            // Wajib sebelum handleMessage().
            //
            // Kalau user punya session .play aktif dan kirim
            // "1", "2", dst, plugin play.before() langsung
            // dieksekusi dari index.js.
            // ==================================================

            const handledByPlay =
              await routePlaySelection(
                raw,
                wafproject
              )

            if (handledByPlay) {
              continue
            }

            // ==============================
            // NORMAL PLUGIN HANDLER
            // ==============================

            await handleMessage(
              raw,
              {
                wafproject,

                usedPrefixList:
                  Array.isArray(
                    global.prefix
                  )
                    ? global.prefix
                    : [
                        ".",
                        "!",
                        "/",
                      ],
              }
            )
          } catch (error) {
            console.error(
              chalk.red(
                "Error memproses pesan masuk:"
              ),
              raw?.key
                ?.remoteJid ||
                "-",
              error
            )
          }
        }
      }
    )

    // ==============================
    // GROUP UPDATE
    // ==============================

    wafproject.ev.on(
      "group-participants.update",
      async (update) => {
        try {
          try {
            const normalized =
              await withTimeout(
                JidNormalizer.normalizeGroupUpdate(
                  wafproject,
                  update
                ),
                2500,
                null
              )

            if (!normalized) {
              console.warn(
                `[GROUP UPDATE NORMALIZE TIMEOUT] ${
                  update?.id ||
                  "-"
                } — lanjut dengan payload asli`
              )
            }
          } catch (error) {
            console.warn(
              `[GROUP UPDATE NORMALIZE ERROR] ${
                update?.id ||
                "-"
              }: ${
                error?.message ||
                error
              }`
            )
          }

          try {
            const gid =
              String(
                update?.id ||
                ""
              )

            if (
              gid.endsWith(
                "@g.us"
              )
            ) {
              void JidNormalizer.warmupGroupCache(
                wafproject,
                gid
              )
            }
          } catch (error) {
            console.error(
              "[ERROR][index.js]",
              error?.message ||
              error
            )
          }

          await groupParticipantsUpdate(
            wafproject,
            update
          )
        } catch (error) {
          console.error(
            chalk.red(
              "Error group-participants.update:"
            ),
            error
          )
        }
      }
    )

    // ==============================
    // CALL
    // ==============================

    wafproject.ev.on(
      "call",
      async (call) => {
        try {
          await antiCallHandler(
            wafproject,
            call
          )
        } catch (error) {
          console.error(
            chalk.red(
              "Error antiCall:"
            ),
            error
          )
        }
      }
    )

    // ==============================
    // CREDS UPDATE
    // ==============================

    wafproject.ev.on(
      "creds.update",
      saveCreds
    )

    // ==============================
    // CONNECTION UPDATE
    // ==============================

    wafproject.ev.on(
      "connection.update",
      async (update) => {
        const {
          qr,
          pairingRequired,
          pairingCode,
          passkeyRequired,
          hasPasskeySigner,
          connection,
          lastDisconnect,
          isNewLogin,
          receivedPendingNotifications,
        } = update

        try {
          const loadData =
            await database.read()

          const storeLoadData =
            await storeDB.read()

          if (
            !loadData ||
            Object.keys(
              loadData
            ).length === 0
          ) {
            global.db = {
              data: {
                settings: {},
              },
            }

            await database.write(
              global.db
            )
          } else {
            global.db =
              loadData

            if (
              !global.db.data
            ) {
              global.db.data =
                {}
            }

            if (
              !global.db.data
                .settings
            ) {
              global.db.data.settings =
                {}
            }
          }

          if (
            !storeLoadData ||
            Object.keys(
              storeLoadData
            ).length === 0
          ) {
            global.store = {
              contacts: {},
              presences: {},
              messages: {},
              groupMetadata: {},
              ...(storeLoadData ||
                {}),
            }

            await storeDB.write(
              global.store
            )
          } else {
            global.store =
              storeLoadData
          }
        } catch (error) {
          console.error(
            chalk.red(
              "Database Error:"
            ),
            error
          )

          process.exit(1)
        }

        if (
          !autosaveStarted
        ) {
          autosaveStarted =
            true

          setInterval(
            async () => {
              try {
                if (
                  global.db
                ) {
                  await database.write(
                    global.db
                  )
                }

                if (
                  global.store
                ) {
                  await storeDB.write(
                    global.store
                  )
                }
              } catch (error) {
                console.error(
                  "[ERROR][index.js]",
                  error?.message ||
                  error
                )
              }
            },
            30_000
          )
        }

        if (connection) {
          console.log(
            chalk.hex(
              "#45B7D1"
            )(
              `📡 Status: ${connection}`
            )
          )
        }

        if (qr) {
          latestQr =
            qr
        }

        if (
          passkeyRequired &&
          !hasPasskeySigner
        ) {
          console.log(
            chalk.yellow(
              "⚠️ WhatsApp meminta passkey untuk menautkan perangkat. Akun ini tidak bisa menyelesaikan pairing headless tanpa passkey signer."
            )
          )
        }

        if (
          pairingCode &&
          usePairingCode &&
          !pairingRequested
        ) {
          const formatted =
            String(
              pairingCode
            )
              .match(
                /.{1,4}/g
              )
              ?.join("-") ||
            pairingCode

          console.log(
            chalk
              .hex("#00FF7F")
              .bold(
                `\n>>> ${formatted} <<<\n`
              )
          )
        }

        // ==============================
        // PAIRING CODE MODE
        // ==============================

        if (
          (
            pairingRequired ||
            qr
          ) &&
          !state.creds.registered &&
          usePairingCode &&
          !pairingRequested &&
          !socketClosed &&
          socketGeneration ===
            activeSocketGeneration
        ) {
          pairingRequested =
            true

          console.log(
            chalk.gray(
              `🔑 Meminta pairing code via ${
                pairingRequired
                  ? "auth_pairing_required"
                  : "auth_qr fallback"
              }...`
            )
          )

          try {
            await sleep(
              1200
            )

            if (
              socketClosed ||
              socketGeneration !==
                activeSocketGeneration
            ) {
              pairingRequested =
                false

              return
            }

            console.log(
              chalk
                .hex(
                  "#45B7D1"
                )
                .bold(
                  "\n📲 Pairing Code"
                )
            )

            console.log(
              chalk.hex(
                "#96CEB4"
              )(
                `Nomor: ${pairingPhoneNumber}`
              )
            )

            const code =
              await wafproject.requestPairingCode(
                pairingPhoneNumber
              )

            const formattedCode =
              code
                ?.match(
                  /.{1,4}/g
                )
                ?.join(
                  "-"
                ) ||
              code

            console.log(
              chalk
                .hex(
                  "#00FF7F"
                )
                .bold(
                  `\n>>> ${formattedCode} <<<\n`
                )
            )

            console.log(
              chalk.hex(
                "#96CEB4"
              )(
                "Masukkan kode di WhatsApp → Perangkat tertaut"
              )
            )
          } catch (error) {
            pairingRequested =
              false

            const status =
              getDisconnectStatusCode(
                error
              )

            console.log(
              chalk.red(
                `\n✗ Gagal meminta pairing code: ${error.message}`
              )
            )

            console.log(
              chalk.yellow(
                `Detail status: ${
                  status ||
                  "tidak tersedia"
                }`
              )
            )

            if (
              status === 428 ||
              /connection closed/i.test(
                String(
                  error.message ||
                  ""
                )
              )
            ) {
              scheduleReconnect(
                2500,
                "Socket tertutup sebelum pairing. Mengulang dengan socket baru..."
              )
            }
          }
        }

        // ==============================
        // QR MODE
        // ==============================

        if (
          qr &&
          !state.creds.registered &&
          !usePairingCode &&
          !socketClosed
        ) {
          console.log(
            chalk
              .hex(
                "#FF6B6B"
              )
              .bold(
                "\n📷 QR CODE MODE"
              )
          )

          console.log(
            chalk.hex(
              "#96CEB4"
            )(
              "Scan QR code di bawah ini:"
            )
          )

          console.log(
            chalk
              .hex(
                "#FFD93D"
              )
              .bold(
                "─".repeat(
                  40
                )
              )
          )

          qrcode.generate(
            qr,
            {
              small: true,
            }
          )

          console.log(
            chalk
              .hex(
                "#FFD93D"
              )
              .bold(
                "─".repeat(
                  40
                )
              )
          )

          console.log(
            chalk.yellow(
              "atau buka: "
            ) +
              chalk.white(
                `http://localhost:${
                  PORT ||
                  3000
                }/qr`
              )
          )

          if (
            !qrRouteMounted
          ) {
            qrRouteMounted =
              true

            app.get(
              "/qr",
              async (
                req,
                res
              ) => {
                try {
                  if (
                    !latestQr
                  ) {
                    return res
                      .status(
                        503
                      )
                      .send(
                        "QR belum tersedia"
                      )
                  }

                  res.setHeader(
                    "content-type",
                    "image/png"
                  )

                  res.end(
                    await toBuffer(
                      latestQr
                    )
                  )
                } catch {
                  res
                    .status(
                      500
                    )
                    .send(
                      "Gagal membuat QR"
                    )
                }
              }
            )
          }
        }

        // ==============================
        // CONNECTION OPEN
        // ==============================

        if (
          connection ===
          "open"
        ) {
          const connectedNumber =
            getConnectedPhoneNumber(
              wafproject,
              state
            )

          if (
            loginFlow ===
            "pairing"
          ) {
            if (
              connectedNumber &&
              pairingPhoneNumber &&
              connectedNumber !==
                pairingPhoneNumber
            ) {
              console.log(
                chalk.red.bold(
                  `⛔ Nomor yang terhubung (${connectedNumber}) berbeda dari nomor licence/pairing (${pairingPhoneNumber}).`
                )
              )

              try {
                await wafproject.logout?.()
              } catch {}

              purgeWhatsAppSession()

              process.exit(
                1
              )
            }

            console.log(
              chalk
                .hex(
                  "#00FF7F"
                )
                .bold(
                  `✅ Pairing sukses. Licence ${
                    verifiedLicenseNumber ||
                    pairingPhoneNumber
                  } aktif.`
                )
            )
          } else {
            if (
              !connectedNumber
            ) {
              console.log(
                chalk.red.bold(
                  "⛔ Nomor WhatsApp yang terhubung tidak dapat dibaca. Licence tidak bisa diverifikasi."
                )
              )

              try {
                await wafproject.logout?.()
              } catch {}

              purgeWhatsAppSession()

              process.exit(
                1
              )
            }

            let licenceValid =
              false

            try {
              licenceValid =
                await verifyLicenseNumber(
                  connectedNumber
                )
            } catch (error) {
              console.error(
                chalk.red(
                  `✗ Gagal memeriksa licence setelah login: ${
                    error?.message ||
                    error
                  }`
                )
              )
            }

            if (
              !licenceValid
            ) {
              printLicenseRejected(
                connectedNumber
              )

              try {
                await wafproject.logout?.()
              } catch {}

              purgeWhatsAppSession()

              process.exit(
                1
              )
            }

            console.log(
              chalk
                .hex(
                  "#00FF7F"
                )
                .bold(
                  `✅ Licence ${connectedNumber} aktif.`
                )
            )
          }

          bootstrapPluginsAfterPairing()

          global.wafproject =
            wafproject

          global.conn =
            wafproject

          global.__sewaConn =
            wafproject

          void Promise.resolve(
            groupParticipantsUpdate.initializeKnownGroups?.(
              wafproject
            )
          ).catch((error) => {
            console.error(
              "[ANTI-CULIK INIT ERROR]",
              error?.message ||
              error
            )
          })

          console.log(
            chalk.green(
              "🤖 BOT CONNECTED"
            )
          )

          void warmupAllGroupsNoUI(
            wafproject,
            {
              concurrency:
                3,
            }
          )
            .then(() => {
              console.log(
                chalk.hex(
                  "#45B7D1"
                )(
                  "💬 Menunggu pesan masuk dari chat.."
                )
              )
            })
            .catch(() => {
              console.log(
                chalk.hex(
                  "#45B7D1"
                )(
                  "💬 Menunggu pesan masuk dari chat.."
                )
              )
            })

          try {
            const jid =
              wafproject
                .user?.jid ||
              wafproject
                .user?.id ||
              "bot"

            const savedPrefix =
              global.db?.data
                ?.settings?.[
                  jid
                ]?.prefix

            if (
              savedPrefix !==
              undefined &&
              savedPrefix !==
              null
            ) {
              wafproject.prefix =
                savedPrefix

              console.log(
                chalk.hex(
                  "#DDA0DD"
                )(
                  "🎯 Prefix loaded: "
                ) +
                  chalk.white(
                    savedPrefix ===
                      ""
                      ? "OFF (no prefix)"
                      : Array.isArray(
                            savedPrefix
                          )
                        ? savedPrefix.join(
                            " , "
                          )
                        : String(
                            savedPrefix
                          )
                  )
              )
            } else {
              // Default Bot Store: tanpa prefix. Prefix "." tetap diterima oleh handler.
              wafproject.prefix =
                ""

              console.log(
                chalk.hex(
                  "#DDA0DD"
                )(
                  "🎯 Prefix: OFF (default, no prefix)"
                )
              )
            }
          } catch (error) {
            console.error(
              "Failed load prefix:",
              error
            )
          }

          const user =
            wafproject.user ||
            {}

          const jidStr =
            user.id ||
            user.jid ||
            "-"

          const loginWIB =
            formatWIBDateTime(
              new Date()
            )

          const sessionExists2 =
            checkSessionExists()

          let method =
            "QR Code"

          if (
            sessionExists2
          ) {
            method =
              "Auto Login (Session)"
          } else if (
            usePairingCode
          ) {
            method =
              "Pairing Code"
          }

          try {
            log.connected({
              user:
                (
                  user.name ||
                  "Unknown"
                ) + "",

              jid:
                jidStr + "",

              loginTimeWIB:
                loginWIB + "",

              method:
                method + "",

              plugins:
                Number(
                  global.plugins
                    .length ||
                    0
                ),
            })
          } catch {
            console.log(
              chalk.green(
                "CONNECTED SUCCESSFULLY"
              )
            )

            console.log(
              "User:",
              user.name ||
              "Unknown"
            )

            console.log(
              "JID:",
              jidStr
            )

            console.log(
              "Login:",
              loginWIB
            )

            console.log(
              "Method:",
              method
            )

            console.log(
              "Plugins:",
              global.plugins.length
            )
          }

          console.log(
            chalk
              .hex(
                "#FFD93D"
              )
              .bold(
                "=".repeat(
                  40
                )
              )
          )

          console.log(
            chalk.hex(
              "#FF6B6B"
            )(
              "🤖 Bot Status: "
            ) +
              chalk.green(
                "ONLINE"
              )
          )

          console.log(
            chalk.hex(
              "#96CEB4"
            )(
              "📁 Plugins: "
            ) +
              chalk.white(
                global.plugins.length +
                " loaded"
              )
          )

          console.log(
            chalk
              .hex(
                "#FFD93D"
              )
              .bold(
                "=".repeat(
                  40
                )
              )
          )
        }

        // ==============================
        // CONNECTION CLOSE
        // ==============================

        if (
          connection ===
          "close"
        ) {
          socketClosed =
            true

          if (
            shutdownStarted
          ) {
            return
          }

          try {
            groupParticipantsUpdate.resetKnownGroups?.()
          } catch (error) {
            console.error(
              "[ERROR][index.js]",
              error?.message ||
              error
            )
          }

          if (
            global.__sewaConn ===
            wafproject
          ) {
            global.__sewaConn =
              null
          }

          const rawError =
            lastDisconnect?.error

          const reason =
            getDisconnectStatusCode(
              rawError
            )

          const errorMessage =
            rawError?.message ||
            rawError?.output
              ?.payload
              ?.message ||
            "Unknown"

          const messages = {
            [ZapoDisconnectReason.connectionLost]:
              chalk.yellow(
                "📡 Koneksi terputus."
              ),

            [ZapoDisconnectReason.connectionClosed]:
              chalk.yellow(
                "🔒 Koneksi ditutup."
              ),

            [ZapoDisconnectReason.restartRequired]:
              chalk.cyan(
                "🔄 Restart socket diperlukan."
              ),

            [ZapoDisconnectReason.timedOut]:
              chalk.yellow(
                "⏰ Koneksi timeout."
              ),

            [ZapoDisconnectReason.badSession]:
              chalk.red(
                "🗑️ Session rusak."
              ),

            [ZapoDisconnectReason.connectionReplaced]:
              chalk.red(
                "⚠️ Koneksi diganti oleh perangkat lain."
              ),

            [ZapoDisconnectReason.loggedOut]:
              chalk.red(
                "🚪 Akun sudah logout."
              ),

            [ZapoDisconnectReason.forbidden]:
              chalk.red(
                "⛔ Koneksi ditolak/forbidden."
              ),

            [ZapoDisconnectReason.multideviceMismatch]:
              chalk.red(
                "📱 Multi-device mismatch."
              ),
          }

          console.log(
            messages[
              reason
            ] ||
              chalk.red(
                `❌ Koneksi tertutup: ${
                  reason ||
                  "unknown"
                }`
              )
          )

          console.log(
            chalk.gray(
              `   Detail: ${errorMessage} | status=${
                reason ||
                "-"
              }`
            )
          )

          if (
            socketGeneration !==
            activeSocketGeneration
          ) {
            return
          }

          await wafproject.closeStore?.()

          const zapoLogout =
            rawError?.isLogout ===
            true

          if (
            zapoLogout ||
            reason ===
              ZapoDisconnectReason.loggedOut
          ) {
            try {
              fs.rmSync(
                SESSION_DIR,
                {
                  recursive: true,
                  force: true,
                }
              )

              fs.mkdirSync(
                SESSION_DIR,
                {
                  recursive: true,
                }
              )
            } catch (error) {
              console.error(
                "[ERROR][index.js]",
                error?.message ||
                error
              )
            }

            loginMethodConfigured =
              false

            usePairingCode =
              null

            pairingPhoneNumber =
              ""

            console.log(
              chalk.yellow(
                "🗑️ Session dihapus. Jalankan ulang bot untuk login kembali."
              )
            )

            process.exit(
              1
            )
          }

          if (
            reason ===
            ZapoDisconnectReason.connectionReplaced
          ) {
            console.log(
              chalk.red(
                "Bot tidak melakukan reconnect agar tidak terjadi loop dua perangkat."
              )
            )

            return
          }

          const waitMs =
            reason ===
              ZapoDisconnectReason.restartRequired ||
            reason === 515
              ? 1200
              : 3500

          scheduleReconnect(
            waitMs
          )
        }

        if (
          isNewLogin
        ) {
          console.log(
            chalk.cyan(
              "\n🆕 New device login detected!"
            )
          )
        }

        if (
          receivedPendingNotifications ===
          true
        ) {
          console.log(
            chalk.yellow(
              "\n⏳ Please wait, syncing messages..."
            )
          )

          if (
            typeof wafproject
              .ev.flush ===
            "function"
          ) {
            wafproject.ev.flush()
          }
        }
      }
    )

    // ==============================
    // CONTACTS UPDATE
    // ==============================

    wafproject.ev.on(
      "contacts.update",
      (update) => {
        for (
          const contact
          of update ||
          []
        ) {
          const id =
            wafproject.decodeJid(
              contact.id
            )

          if (
            _toggleStoreContacts() &&
            global.store &&
            global.store.contacts
          ) {
            global.store.contacts[
              id
            ] = {
              id,

              name:
                contact.notify,
            }
          }
        }
      }
    )
  } finally {
    startInProgress =
      false
  }
}

function _toggleStoreContacts() {
  try {
    return true
  } catch {
    return false
  }
}

// ==============================
// RUN
// ==============================

prepareSessionDirectory()
prepareTempDirectory()

console.log(
  chalk.hex("#45B7D1")(
    "\n🚀 Starting WhatsApp Bot..."
  )
)

start().catch(
  (error) => {
    console.error(
      chalk.red(
        "Fatal error:"
      ),
      error
    )

    process.exit(
      1
    )
  }
)

// ==============================
// GRACEFUL SHUTDOWN
// ==============================

let shutdownStarted =
  false

async function gracefulShutdown(
  signal
) {
  if (
    shutdownStarted
  ) {
    return
  }

  shutdownStarted =
    true

  console.log(
    chalk.yellow(
      `\n\n👋 Shutting down bot (${signal})...`
    )
  )

  const forceTimer =
    setTimeout(
      () => {
        console.error(
          chalk.red(
            "Shutdown timeout, proses dihentikan paksa."
          )
        )

        process.exit(
          1
        )
      },
      8000
    )

  forceTimer.unref?.()

  try {
    if (
      reconnectTimer
    ) {
      clearTimeout(
        reconnectTimer
      )

      reconnectTimer =
        null
    }

    if (
      commandReloadTimer
    ) {
      clearTimeout(
        commandReloadTimer
      )

      commandReloadTimer =
        null
    }

    if (
      commandWatcher
    ) {
      try {
        commandWatcher.close()
      } catch (error) {
        console.error(
          "[PLUGIN WATCHER CLOSE ERROR]",
          error?.message ||
          error
        )
      }

      commandWatcher =
        null
    }

    upsertDedupe.flushAll()
    groupMetaCache.flushAll()

    try {
      await global.wafproject?.disconnect?.()
    } catch (error) {
      console.error(
        "[ZAPO DISCONNECT ERROR]",
        error?.message ||
        error
      )
    }

    await db.flush?.()

    rl.close()

    server?.close?.()
  } catch (error) {
    console.error(
      "Shutdown error:",
      error?.message ||
      error
    )
  } finally {
    clearTimeout(
      forceTimer
    )

    process.exit(
      0
    )
  }
}

process.once(
  "SIGINT",
  () =>
    gracefulShutdown(
      "SIGINT"
    )
)

process.once(
  "SIGTERM",
  () =>
    gracefulShutdown(
      "SIGTERM"
    )
)