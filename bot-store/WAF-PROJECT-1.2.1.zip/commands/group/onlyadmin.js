/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - onlyadmin.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_onlyadmin_exports = {};
__export(group_onlyadmin_exports, {
  default: () => group_onlyadmin_default
});
module.exports = __toCommonJS(group_onlyadmin_exports);
let handler = async (m, { jagoanproject, isOwner, isAdmin, text, command, usedPrefix }) => {
  let chat = global.db.data.chats[m.chat];
  if (!(isAdmin || isOwner)) {
    global.jpDfail("admin", m, jagoanproject);
    throw false;
  }
  if (!text) {
    return jagoanproject.reply(
      m.chat,
      `*\u{1F4DD} Contoh penggunaan:*

\u2013 ${usedPrefix + command} on
\u2013 ${usedPrefix + command} off`,
      m
    );
  }
  text = text.toLowerCase().trim();
  if (text === "on") {
    if (chat.onlyAdmin) {
      return jagoanproject.reply(m.chat, `\u26D4 Fitur onlyadmin sudah aktif di grup ini!`, m);
    }
    chat.onlyAdmin = true;
    return jagoanproject.reply(
      m.chat,
      `*\u2705 ONLYADMIN DI AKTIFKAN*
\u2013 Grup ini sekarang hanya admin yang bisa pakai bot.`,
      m
    );
  }
  if (text === "off") {
    if (!chat.onlyAdmin) {
      return jagoanproject.reply(m.chat, `\u26D4 Fitur onlyadmin sudah nonaktif di grup ini!`, m);
    }
    chat.onlyAdmin = false;
    return jagoanproject.reply(
      m.chat,
      `*\u2705 ONLYADMIN DI NONAKTIFKAN*
\u2013 Grup ini sekarang bisa dipakai semua member.`,
      m
    );
  }
  return jagoanproject.reply(
    m.chat,
    `*\u203C\uFE0F Format salah!*

\u{1F4DD} Gunakan contoh:

\u2013 ${usedPrefix + command} on
\u2013 ${usedPrefix + command} off`,
    m
  );
};
handler.help = ["onlyadmin on", "onlyadmin off"];
handler.tags = ["group"];
handler.command = /^onlyadmin$/i;
handler.group = true;
handler.register = true;
var group_onlyadmin_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
