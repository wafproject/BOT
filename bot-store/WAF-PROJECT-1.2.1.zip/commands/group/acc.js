/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - acc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_acc_exports = {};
__export(group_acc_exports, {
  default: () => group_acc_default
});
module.exports = __toCommonJS(group_acc_exports);
let handler = async (m, { jagoanproject, args }) => {
  const groupId = m.chat;
  const [subCommand, optionsRaw] = args;
  const options = (optionsRaw || "").trim();
  const { reply } = m;
  const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
  const BATCH_SIZE = 5;
  const COOLDOWN_MS = 1e4;
  const PER_REQUEST_DELAY_MS = 0;
  const joinRequestList = await jagoanproject.groupRequestParticipantsList(groupId);
  const formatDate = (timestamp) => new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric"
  }).format(new Date(timestamp * 1e3));
  switch (subCommand) {
    case "list": {
      const formattedList = joinRequestList.length > 0 ? joinRequestList.map((request, i) => {
        const jid = request.jid;
        const [user, server] = jid.split("@");
        const tampilId = server === "s.whatsapp.net" ? user : `LID: ${user}`;
        return `*${i + 1}.*
\u2022 ID: ${tampilId}
\u2022 JID: ${jid}
\u2022 Metode Permintaan: ${request.request_method}
\u2022 Waktu Permintaan: ${formatDate(request.request_time)}

`;
      }).join("") : "Tidak ada permintaan bergabung yang tertunda.";
      reply(`*Daftar Permintaan Bergabung:*

${formattedList}`);
      break;
    }
    case "reject":
    case "approve": {
      if (!options) {
        reply(
          "*Perintah kurang lengkap.*\nGunakan:\n- *acc list*\n- *acc approve 1|2|3*\n- *acc reject 1|2|3*\n- *acc reject/approve all*"
        );
        break;
      }
      if (joinRequestList.length === 0) {
        reply("Tidak ada permintaan bergabung yang tertunda.");
        break;
      }
      if (options === "all") {
        let done = 0;
        for (let i = 0; i < joinRequestList.length; i += BATCH_SIZE) {
          const batch = joinRequestList.slice(i, i + BATCH_SIZE);
          for (const request of batch) {
            try {
              await jagoanproject.groupRequestParticipantsUpdate(groupId, [request.jid], subCommand);
              console.log(`Meng-${subCommand} participant dengan JID: ${request.jid}`);
            } catch (e) {
              console.log(`Gagal meng-${subCommand} JID: ${request.jid}`, e);
            }
            done++;
            if (PER_REQUEST_DELAY_MS > 0) await sleep(PER_REQUEST_DELAY_MS);
          }
          const remaining = joinRequestList.length - done;
          if (remaining > 0) {
            reply(`\u2705 Batch selesai (${done}/${joinRequestList.length}). Cooldown 10 detik...`);
            await sleep(COOLDOWN_MS);
          }
        }
        reply(
          `*${subCommand === "approve" ? "Menyetujui" : "Menolak"} semua permintaan bergabung (batch ${BATCH_SIZE} + cooldown 10 detik).*`
        );
        break;
      }
      const actions = options.split("|").map((x) => x.trim()).filter(Boolean);
      const participants = actions.map((action) => joinRequestList[parseInt(action) - 1]).filter((req) => req);
      if (participants.length === 0) {
        reply("Tidak ada anggota yang cocok untuk reject/approve.");
        break;
      }
      let formattedResponse = "";
      let idx = 0;
      for (const request of participants) {
        idx++;
        try {
          const response = await jagoanproject.groupRequestParticipantsUpdate(groupId, [request.jid], subCommand);
          const statusRaw = response?.[0]?.status || response?.status;
          const status = statusRaw === "success" ? "Berhasil" : statusRaw || "Unknown";
          formattedResponse += `*${idx}.*
\u2022 Status: ${status}
\u2022 ID: ${request.jid.split("@")[0]}
\u2022 JID: ${request.jid}

`;
          console.log(`Meng-${subCommand} participant dengan JID: ${request.jid}`);
        } catch (e) {
          formattedResponse += `*${idx}.*
\u2022 Status: Gagal
\u2022 ID: ${request.jid.split("@")[0]}
\u2022 JID: ${request.jid}

`;
          console.log(`Gagal meng-${subCommand} participant dengan JID: ${request.jid}`, e);
        }
        if (PER_REQUEST_DELAY_MS > 0) await sleep(PER_REQUEST_DELAY_MS);
      }
      reply(
        `*${subCommand === "approve" ? "Menyetujui" : "Menolak"} Permintaan Bergabung:*

${formattedResponse}`
      );
      break;
    }
    default:
      reply(
        "*Perintah tidak valid.*\nGunakan:\n- *acc list*\n- *acc approve [number]*\n- *acc reject [number]*\n- *acc reject/approve all* untuk menolak/menyetujui semua permintaan bergabung."
      );
  }
};
handler.help = ["acc *[options]*"];
handler.tags = ["group"];
handler.command = /^(acc)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
handler.fail = null;
handler.register = true;
var group_acc_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
