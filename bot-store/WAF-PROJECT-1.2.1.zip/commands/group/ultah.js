/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - ultah.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_ultah_exports = {};
__export(group_ultah_exports, {
  default: () => group_ultah_default
});
module.exports = __toCommonJS(group_ultah_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = import_path.default.dirname(__filename);
const DB_DIR = import_path.default.join(__dirname, "../../database");
const DB_FILE = import_path.default.join(DB_DIR, "ultah.json");
const MONTHS = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember"
];
function ensureDbFile() {
  if (!import_fs.default.existsSync(DB_DIR)) import_fs.default.mkdirSync(DB_DIR, { recursive: true });
  if (!import_fs.default.existsSync(DB_FILE)) import_fs.default.writeFileSync(DB_FILE, JSON.stringify({}, null, 2));
}
ensureDbFile();
function loadDb() {
  ensureDbFile();
  try {
    const json = JSON.parse(import_fs.default.readFileSync(DB_FILE, "utf8"));
    return json && typeof json === "object" ? json : {};
  } catch {
    return {};
  }
}
function saveDb(db) {
  ensureDbFile();
  import_fs.default.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
function normalizeJid(jid = "") {
  const s = String(jid || "").trim();
  if (!s) return "";
  if (s.endsWith("@s.whatsapp.net") || s.endsWith("@g.us")) return s;
  const num = s.replace(/[^0-9]/g, "");
  return num ? `${num}@s.whatsapp.net` : "";
}
function getZone() {
  try {
    return typeof global.getZonaWaktu === "function" ? global.getZonaWaktu() : "Asia/Makassar";
  } catch {
    return "Asia/Makassar";
  }
}
function getNowParts() {
  const zone = getZone();
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: zone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).formatToParts(/* @__PURE__ */ new Date());
  const map = {};
  for (const p of parts) map[p.type] = p.value;
  return {
    zone,
    year: Number(map.year),
    month: Number(map.month),
    day: Number(map.day),
    hour: Number(map.hour),
    minute: Number(map.minute),
    second: Number(map.second),
    ymd: `${map.year}-${map.month}-${map.day}`
  };
}
function isLeapYear(year) {
  return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
}
function getMaxDay(month, year) {
  if (month === 2) return isLeapYear(year) ? 29 : 28;
  return new Date(year, month, 0).getDate();
}
function parseBirthday(input = "") {
  const raw = String(input || "").trim();
  const m = raw.match(/^(\d{1,2})[\/-](\d{1,2})(?:[\/-](\d{4}))?$/);
  if (!m) return null;
  const day = Number(m[1]);
  const month = Number(m[2]);
  const year = m[3] ? Number(m[3]) : null;
  if (month < 1 || month > 12) return null;
  if (day < 1 || day > getMaxDay(month, year || 2024)) return null;
  if (year !== null) {
    const now = getNowParts();
    if (year < 1900 || year > now.year) return null;
  }
  return {
    day,
    month,
    year,
    hasYear: year !== null,
    display: year !== null ? `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}` : `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}`
  };
}
function formatDate(day, month, year) {
  return `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}`;
}
function ensureGroup(db, gid) {
  if (!db[gid]) db[gid] = [];
  if (!Array.isArray(db[gid])) db[gid] = [];
  return db[gid];
}
function sortEntries(entries = []) {
  return [...entries].sort((a, b) => {
    if (a.month !== b.month) return a.month - b.month;
    if (a.day !== b.day) return a.day - b.day;
    return String(a.name || "").localeCompare(String(b.name || ""));
  });
}
function getTargetJidFromAdd(m) {
  if (m.mentionedJid && m.mentionedJid[0]) return normalizeJid(m.mentionedJid[0]);
  if (m.quoted?.sender) return normalizeJid(m.quoted.sender);
  return "";
}
function getTargetJidForCheck(m) {
  if (m.mentionedJid && m.mentionedJid[0]) return normalizeJid(m.mentionedJid[0]);
  if (m.quoted?.sender) return normalizeJid(m.quoted.sender);
  return normalizeJid(m.sender);
}
function getDateArg(text = "") {
  const match = String(text || "").match(/(\d{1,2}[\/-]\d{1,2}(?:[\/-]\d{4})?)/);
  return match ? match[1] : "";
}
function getOccurrence(entry, fromNow = getNowParts()) {
  let year = fromNow.year;
  if (entry.month < fromNow.month || entry.month === fromNow.month && entry.day < fromNow.day) {
    year += 1;
  }
  if (entry.month === 2 && entry.day === 29) {
    while (!isLeapYear(year)) year += 1;
  }
  const target = new Date(Date.UTC(year, entry.month - 1, entry.day, 0, 1, 0));
  const current = new Date(Date.UTC(fromNow.year, fromNow.month - 1, fromNow.day, fromNow.hour, fromNow.minute, fromNow.second));
  const diffMs = target - current;
  const diffDays = Math.max(0, Math.ceil(diffMs / 864e5));
  return {
    year,
    diffDays,
    display: formatDate(entry.day, entry.month, year)
  };
}
function getCurrentAge(entry, fromNow = getNowParts()) {
  if (!entry.birthYear) return null;
  let age = fromNow.year - Number(entry.birthYear);
  if (fromNow.month < entry.month || fromNow.month === entry.month && fromNow.day < entry.day) {
    age -= 1;
  }
  return age >= 0 ? age : null;
}
function getNextBirthdayAge(entry, fromNow = getNowParts()) {
  if (!entry.birthYear) return null;
  const next = getOccurrence(entry, fromNow);
  return next.year - Number(entry.birthYear);
}
function formatCountdown(days) {
  if (days <= 0) return "Hari ini \u{1F389}";
  if (days === 1) return "1 hari lagi";
  return `${days} hari lagi`;
}
async function resolveUserName(conn, jid, fallback = "") {
  try {
    const name = await conn.getName(jid);
    if (name) return name;
  } catch {
  }
  return fallback || `@${jid.split("@")[0]}`;
}
function buildList(entries) {
  const sorted = sortEntries(entries);
  if (!sorted.length) return "*Daftar ultah di grup ini masih kosong.*";
  let text = "\u{1F382} *Daftar Ulang Tahun Grup*\n\n";
  let no = 1;
  const now = getNowParts();
  for (let month = 1; month <= 12; month++) {
    const items = sorted.filter((v) => v.month === month);
    text += `*${MONTHS[month - 1]}*
`;
    if (!items.length) {
      text += "_Belum ada data_\n\n";
      continue;
    }
    for (const item of items) {
      const next = getOccurrence(item, now);
      const ageText = item.birthYear ? ` \u2022 ultah ke-${getNextBirthdayAge(item, now)}` : "";
      const birthText = item.birthYear ? `/${item.birthYear}` : "";
      text += `${no}. @${item.jid.split("@")[0]} \u2014 ${String(item.day).padStart(2, "0")}/${String(item.month).padStart(2, "0")}${birthText} (${next.display} \u2022 ${formatCountdown(next.diffDays)}${ageText})
`;
      no += 1;
    }
    text += "\n";
  }
  return text.trim();
}
function getFlattened(entries) {
  return sortEntries(entries).map((item, idx) => ({ no: idx + 1, ...item }));
}
async function getGroupMentions(conn, gid) {
  try {
    const meta = await conn.groupMetadata(gid);
    return (meta.participants || []).map((v) => v.id);
  } catch {
    return [];
  }
}
async function sendBirthdayBroadcasts(conn) {
  const now = getNowParts();
  if (!(now.hour === 0 && now.minute === 1)) return;
  const db = loadDb();
  let changed = false;
  for (const [gid, list] of Object.entries(db)) {
    if (!gid.endsWith("@g.us") || !Array.isArray(list) || !list.length) continue;
    const mentionsAll = await getGroupMentions(conn, gid);
    for (const item of list) {
      if (!item || !item.jid || !item.day || !item.month) continue;
      const todayHit = Number(item.day) === now.day && Number(item.month) === now.month;
      const next = getOccurrence(item, now);
      const isHMin1 = next.diffDays === 1;
      const ageNow = getCurrentAge(item, now);
      const nextAge = getNextBirthdayAge(item, now);
      if (todayHit) {
        const key = `ulang|${now.ymd}|${gid}|${item.jid}`;
        if (item.lastUcapanKey === key) continue;
        const ageLine = ageNow !== null ? `Hari ini genap *${ageNow} tahun* nih \u{1F973}\u{1F382}

` : "";
        const text = `\u{1F389} *Selamat Ulang Tahun!* \u{1F389}

Selamat ulang tahun @${item.jid.split("@")[0]}
${ageLine}Semoga panjang umur, sehat selalu, dilancarkan segala urusannya, dan makin banyak rezekinya yaa \u{1F973}\u{1F382}`;
        try {
          await conn.sendMessage(gid, { text, mentions: [item.jid] });
          item.lastUcapanKey = key;
          changed = true;
        } catch (e) {
          console.log("AUTO ULTAH ERROR:", gid, item.jid, e?.message || e);
        }
        continue;
      }
      if (isHMin1) {
        const key = `ingat|${now.ymd}|${gid}|${item.jid}`;
        if (item.lastReminderKey === key) continue;
        const ageLine = nextAge !== null ? `Besok @${item.jid.split("@")[0]} ulang tahun yang ke-*${nextAge}* nih, kita kasih apa yaa....` : `Wahh sepertinya besok @${item.jid.split("@")[0]} berulang tahun nih, kita kasih apa yaa....`;
        const text = `\u{1F381} *Pengingat Ulang Tahun*

${ageLine}`;
        try {
          const mentions = [.../* @__PURE__ */ new Set([...mentionsAll, item.jid])];
          await conn.sendMessage(gid, { text, mentions });
          item.lastReminderKey = key;
          changed = true;
        } catch (e) {
          console.log("AUTO PENGINGAT ULTAH ERROR:", gid, item.jid, e?.message || e);
        }
      }
    }
  }
  if (changed) saveDb(db);
}
function startBirthdayScheduler(conn) {
  if (global.__ultahSchedulerStarted) {
    global.__ultahConn = conn || global.__ultahConn;
    return;
  }
  global.__ultahSchedulerStarted = true;
  global.__ultahConn = conn;
  const runner = async () => {
    const sock = global.__ultahConn || global.jagoanproject || global.conn;
    if (!sock) return;
    try {
      await sendBirthdayBroadcasts(sock);
    } catch (e) {
      console.log("ULTAH SCHEDULER ERROR:", e?.message || e);
    }
  };
  runner();
  global.__ultahScheduler = setInterval(runner, 3e4);
}
let handler = async (m, { jagoanproject, command, text }) => {
  startBirthdayScheduler(jagoanproject);
  if (!m.isGroup) return m.reply("\u274C Fitur ultah hanya bisa dipakai di dalam grup.");
  const db = loadDb();
  const gid = m.chat;
  const list = ensureGroup(db, gid);
  const cmd = (command || "").toLowerCase();
  if (cmd === "addultah") {
    const targetJid = getTargetJidFromAdd(m);
    if (!targetJid) {
      return m.reply("Format salah.\n\nContoh:\n.addultah @ferdy 12/04/2003\nAtau reply pesan user lalu ketik:\n.addultah 12/04/2003");
    }
    const dateArg = getDateArg(text);
    const parsed = parseBirthday(dateArg);
    if (!parsed) {
      return m.reply("Format tanggal salah. Gunakan format *dd/mm/yyyy*\n\nContoh:\n.addultah @ferdy 12/04/2003");
    }
    const name = await resolveUserName(jagoanproject, targetJid);
    const existingIndex = list.findIndex((v) => normalizeJid(v.jid) === targetJid);
    const old = existingIndex >= 0 ? list[existingIndex] : {};
    const payload = {
      jid: targetJid,
      name,
      day: parsed.day,
      month: parsed.month,
      birthYear: parsed.year,
      addedBy: normalizeJid(m.sender),
      addedAt: (/* @__PURE__ */ new Date()).toISOString(),
      lastUcapanKey: old.lastUcapanKey || "",
      lastReminderKey: old.lastReminderKey || ""
    };
    if (existingIndex >= 0) list[existingIndex] = payload;
    else list.push(payload);
    db[gid] = sortEntries(list);
    saveDb(db);
    const next = getOccurrence(payload);
    const nextAge = getNextBirthdayAge(payload);
    const ageLine = nextAge !== null ? `
\u{1F389} Ulang tahun berikutnya: ke-${nextAge}` : "";
    return jagoanproject.sendMessage(m.chat, {
      text: `\u2705 Sukses menyimpan data @${targetJid.split("@")[0]}
\u{1F4C5} Tanggal lahir: ${parsed.display}
\u{1F382} Akan ulang tahun pada ${next.display}${ageLine}
\u23F3 ${formatCountdown(next.diffDays)} menuju ulang tahun`,
      mentions: [targetJid]
    }, { quoted: m });
  }
  if (cmd === "listultah") {
    const textList = buildList(list);
    const mentions = sortEntries(list).map((v) => v.jid);
    return jagoanproject.sendMessage(m.chat, { text: textList, mentions }, { quoted: m });
  }
  if (cmd === "delultah") {
    if (!list.length) return m.reply("\u274C Daftar ultah di grup ini masih kosong.");
    const arg = String(text || "").trim().toLowerCase();
    if (!arg) return m.reply("Masukkan nomor dari list atau ketik *.delultah all*");
    if (arg === "all") {
      db[gid] = [];
      saveDb(db);
      return m.reply("\u2705 Semua data ultah di grup ini berhasil dihapus.");
    }
    const nums = [...new Set(arg.split(",").map((v) => Number(v.trim())).filter((v) => Number.isInteger(v) && v > 0))];
    if (!nums.length) return m.reply("Nomor tidak valid. Contoh: *.delultah 3* atau *.delultah 1,2*");
    const flat = getFlattened(list);
    const removed = [];
    const remain = flat.filter((item) => {
      const hit = nums.includes(item.no);
      if (hit) removed.push(item);
      return !hit;
    }).map(({ no, ...rest }) => rest);
    if (!removed.length) return m.reply("Nomor tidak ditemukan di daftar ultah.");
    db[gid] = remain;
    saveDb(db);
    const out = removed.map((v) => {
      const birthText = v.birthYear ? `/${v.birthYear}` : "";
      return `\u2022 @${v.jid.split("@")[0]} \u2014 ${String(v.day).padStart(2, "0")}/${String(v.month).padStart(2, "0")}${birthText}`;
    }).join("\n");
    return jagoanproject.sendMessage(m.chat, {
      text: `\u2705 Berhasil menghapus data ultah:
${out}`,
      mentions: removed.map((v) => v.jid)
    }, { quoted: m });
  }
  if (cmd === "cekultah") {
    const targetJid = getTargetJidForCheck(m);
    const entry = list.find((v) => normalizeJid(v.jid) === targetJid);
    if (!entry) {
      return jagoanproject.sendMessage(m.chat, {
        text: `\u274C Data ultah untuk @${targetJid.split("@")[0]} belum ada di grup ini.`,
        mentions: [targetJid]
      }, { quoted: m });
    }
    const next = getOccurrence(entry);
    const currentAge = getCurrentAge(entry);
    const nextAge = getNextBirthdayAge(entry);
    const birthText = entry.birthYear ? `\u{1F4C5} Tanggal lahir: ${String(entry.day).padStart(2, "0")}/${String(entry.month).padStart(2, "0")}/${entry.birthYear}
\u{1F9EE} Umur sekarang: ${currentAge} tahun
\u{1F389} Ulang tahun berikutnya: ke-${nextAge}
` : `\u{1F4C5} Tanggal ultah: ${String(entry.day).padStart(2, "0")}/${String(entry.month).padStart(2, "0")}
`;
    return jagoanproject.sendMessage(m.chat, {
      text: `\u{1F382} *Cek Ulang Tahun*

\u{1F464} User: @${targetJid.split("@")[0]}
${birthText}\u{1F389} Ulang tahun terdekat: ${next.display}
\u23F3 ${formatCountdown(next.diffDays)} menuju ulang tahun`,
      mentions: [targetJid]
    }, { quoted: m });
  }
};
handler.before = async function() {
  const conn = this || global.jagoanproject || global.conn;
  if (conn) startBirthdayScheduler(conn);
};
handler.help = ["addultah", "delultah", "listultah", "cekultah"];
handler.tags = ["group"];
handler.command = /^(addultah|delultah|listultah|cekultah)$/i;
handler.group = true;
handler.register = true;
var group_ultah_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
