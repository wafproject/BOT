/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - hidetag_polling.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_hidetag_polling_exports = {};
__export(group_hidetag_polling_exports, {
  default: () => group_hidetag_polling_default
});
module.exports = __toCommonJS(group_hidetag_polling_exports);
var import_node_crypto = __toESM(require("node:crypto"));
var import_jid = require("../../lib/jagoan/function/jid.js");
const handler = async (m, { jagoanproject, text }) => {
  if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan di grup.");
  if (!text) return m.reply("Format:\n.htpoll Judul | opsi1 | opsi2 | opsi3");
  const groupMetadata = await jagoanproject.groupMetadata(m.chat).catch(() => null);
  if (!Array.isArray(groupMetadata?.participants)) {
    return m.reply("Bot tidak bisa mengambil data member.");
  }
  const mentions = [];
  for (const participant of groupMetadata.participants) {
    const normalized = await (0, import_jid.normalizeParticipant)(jagoanproject, participant, {
      groupJid: m.chat,
      groupMetadata
    });
    if ((0, import_jid.isPhoneJid)(normalized.id) && !mentions.includes(normalized.id)) mentions.push(normalized.id);
  }
  if (!mentions.length) {
    return m.reply("Tidak ada JID nomor anggota yang berhasil dipetakan. Coba lagi setelah bot menerima aktivitas anggota di grup.");
  }
  const input = text.split("|").map((v) => v.trim()).filter(Boolean);
  const title = input[0];
  const optionsInput = input.slice(1);
  if (!title) return m.reply("Judul polling tidak boleh kosong.");
  if (optionsInput.length < 2) {
    return m.reply("Minimal harus ada 2 opsi.\nContoh:\n.htpoll Judul | opsi1 | opsi2");
  }
  await jagoanproject.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        messageSecret: import_node_crypto.default.randomBytes(32).toString("base64")
      },
      pollCreationMessageV3: {
        contextInfo: { mentionedJid: mentions },
        options: optionsInput.map((optionName) => ({ optionName })),
        name: title,
        selectableOptionsCount: 1
      }
    },
    {
      additionalNodes: [{ tag: "meta", attrs: { polltype: "creation" } }]
    }
  );
};
handler.help = ["htpoll Judul | opsi1 | opsi2"];
handler.tags = ["group"];
handler.command = /^(htpoll|pollht|htpolling|pollinght|pollinghidetag|hidetagpolling)$/i;
handler.group = true;
handler.register = true;
var group_hidetag_polling_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
