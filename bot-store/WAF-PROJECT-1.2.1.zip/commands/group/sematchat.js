/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - sematchat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_sematchat_exports = {};
__export(group_sematchat_exports, {
  default: () => group_sematchat_default
});
module.exports = __toCommonJS(group_sematchat_exports);
const storeMessages = {};
async function saveMessageToStore(message) {
  const messageData = {
    id: message.key.id,
    chat: message.key.remoteJid,
    sender: message.key.participant || message.key.remoteJid,
    fromMe: message.key.fromMe,
    timestamp: message.messageTimestamp,
    isPinned: false
    // Flag untuk status pin
  };
  storeMessages[message.key.id] = messageData;
}
async function savePinnedMessage(messageId, time) {
  if (storeMessages[messageId]) {
    storeMessages[messageId].isPinned = true;
    storeMessages[messageId].pinDuration = time;
  }
}
async function readMessageFromStore(messageId) {
  return storeMessages[messageId] || null;
}
const handler = async (m, { jagoanproject, command, args }, { store } = {}) => {
  if (m.isGroup && m.key && m.key.id) {
    await saveMessageToStore(m);
  }
  if (!m.quoted) return m.reply("\u{1F4CC} Balas pesan yang ingin di-pin!");
  const groupMetadata = await jagoanproject.groupMetadata(m.chat);
  const isAdmin = groupMetadata.participants.find((p) => p.id === jagoanproject.user.jid)?.admin;
  if (!isAdmin) return m.reply("\u274C Bot harus menjadi admin untuk mem-pin pesan!");
  let key = m.quoted.key || m.quoted.fakeObj?.key;
  if (!key || !key.id || !key.remoteJid) {
    console.log("Key tidak valid, mencoba mengambil dari storeMessages...");
    const storedMessage = await readMessageFromStore(m.quoted.id);
    if (storedMessage) {
      key = {
        id: storedMessage.id,
        remoteJid: storedMessage.chat,
        fromMe: storedMessage.fromMe,
        participant: storedMessage.sender
      };
      console.log("Key dari storeMessages:", JSON.stringify(key, null, 2));
    } else if (store && store.messages && store.messages[m.chat]) {
      console.log("Mencoba mengambil dari store.messages...");
      const messages = store.messages[m.chat].all() || [];
      const quotedMsg = messages.find((msg) => msg.key.id === m.quoted.id);
      if (quotedMsg) {
        key = quotedMsg.key;
        console.log("Key dari store:", JSON.stringify(key, null, 2));
      }
    }
    if (!key || !key.id || !key.remoteJid) {
      return m.reply("\u274C Gagal mendapatkan ID pesan yang di-reply. Pastikan kamu membalas pesan yang valid!");
    }
  }
  let time = 86400;
  let timeInput = "24h";
  if (args[0]) {
    timeInput = args[0].toLowerCase();
    if (timeInput === "7d") {
      time = 604800;
    } else if (timeInput === "30d") {
      time = 2592e3;
    } else if (timeInput !== "24h") {
      return m.reply("\u23F3 Durasi tidak valid! Gunakan: 24h, 7d, atau 30d. Contoh: .semat 7d");
    }
  } else {
    m.reply("\u2139\uFE0F Tidak ada durasi yang ditentukan. Menggunakan default 24 jam.\nIngin mengguankan Durasi lain? :\nketik .semat <24h, 7d, 30d>\n> 24h = 24 jam\n> 7d = 7 hari\n> 30d = 30 hari");
  }
  try {
    console.log("Sending pin request:", { type: 1, time, key });
    await jagoanproject.sendMessage(m.chat, {
      pin: {
        type: 1,
        // Hanya pin
        time,
        // Durasi dalam detik
        key
        // Key pesan yang di-pin
      }
    });
    console.log("Pin request sent successfully");
    await savePinnedMessage(m.quoted.id, time);
    m.reply(`\u2705 Pesan berhasil di-pin selama ${timeInput}!`);
  } catch (err) {
    console.error("Pin Error:", err);
    m.reply(`\u274C Gagal memproses pin pesan: ${err.message}`);
  }
};
handler.tags = ["group"];
handler.help = ["semat <24h|7d|30d> (balas pesan)"];
handler.command = ["semat"];
handler.group = true;
handler.register = true;
handler.limit = true;
var group_sematchat_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
