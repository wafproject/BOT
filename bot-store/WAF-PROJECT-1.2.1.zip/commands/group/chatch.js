/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - chatch.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_chatch_exports = {};
__export(group_chatch_exports, {
  default: () => group_chatch_default
});
module.exports = __toCommonJS(group_chatch_exports);
var import_axios = __toESM(require("axios"));
let idch = salurandaftar;
const saluran = `https://whatsapp.com/channel/0029Vb3pLfFEawdyEy1WTj1F`;
let handler = async (m, { jagoanproject, text }) => {
  try {
    let user = m.sender;
    let name = await jagoanproject.getName(user) || "No Name";
    let ppUrl = "https://github.com/ChandraGO/Data-Jagoan-Project/blob/master/src/avatar_contact.png";
    try {
      ppUrl = await jagoanproject.profilePictureUrl(user, "image");
    } catch (e) {
    }
    let date = /* @__PURE__ */ new Date();
    let sendTime = new Intl.DateTimeFormat("id-ID", {
      timeZone: "Asia/Jakarta",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      day: "2-digit",
      month: "2-digit",
      year: "2-digit"
    }).format(date).replace(/\//g, "-").replace(/, /g, " || ") + " WIB";
    let channelMessage = text || "no caption";
    let channelContextInfo = {
      mentionedJid: [user],
      groupMentions: [],
      isForwarded: true,
      forwardingScore: 256,
      forwardedNewsletterMessageInfo: {
        newsletterJid: idch,
        newsletterName: "PESAN TERKIRIM DARI GROUP",
        serverMessageId: -1
      },
      extendedPreview: {
        title: `Pengirim : ${name}`,
        body: sendTime,
        thumbnailUrl: ppUrl,
        sourceUrl: saluran,
        mediaType: 1,
        renderLargerThumbnail: false,
        showAdAttribution: true
      }
    };
    if (m.quoted && m.quoted.fileSha256) {
      let quoted = m.quoted;
      let mime = quoted.mimetype || "";
      let media = await quoted.download();
      if (mime.includes("image")) {
        await jagoanproject.sendMessage(idch, { image: media, caption: channelMessage, contextInfo: channelContextInfo });
      } else if (mime.includes("video")) {
        await jagoanproject.sendMessage(idch, { video: media, caption: channelMessage, contextInfo: channelContextInfo });
      } else if (mime.includes("audio")) {
        await jagoanproject.sendMessage(idch, { audio: media, ptt: true, mimetype: mime, contextInfo: channelContextInfo });
      } else {
        return m.reply("\u203C\uFE0F *MEDIA TIDAK DIDUKUNG*\n\n- hanya gambar, video, audio.");
      }
    } else if (text) {
      await jagoanproject.sendMessage(idch, { text: channelMessage, contextInfo: channelContextInfo });
    } else {
      return m.reply("\u203C\uFE0F *FORMAT TIDAK LENGKAP*\n\n> harap masukkan teks atau media untuk dikirim ke saluran.");
    }
    await jagoanproject.sendMessage(m.chat, {
      text: "\u2705 Berhasil mengirim ke saluran!",
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        isForwarded: true,
        forwardingScore: 256,
        forwardedNewsletterMessageInfo: {
          newsletterJid: idch,
          newsletterName: "PESAN TERKIRIM KE SALURAN",
          serverMessageId: -1
        },
        extendedPreview: {
          title: `Pengirim: ${name}`,
          body: sendTime,
          thumbnailUrl: ppUrl,
          sourceUrl: saluran,
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  } catch (err) {
    console.error(err);
    m.reply(`\u274C Gagal mengirim ke saluran.

\u{1F4C4} *Logs error:* 
\`\`\`${err.message}\`\`\``);
  }
};
handler.tags = ["owner"];
handler.help = ["chatch <teks>"];
handler.command = /^(chatch|upch)$/i;
handler.group = true;
handler.owner = false;
handler.register = true;
handler.limit = true;
var group_chatch_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
