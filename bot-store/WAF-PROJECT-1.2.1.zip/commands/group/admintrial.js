/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - admintrial.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_admintrial_exports = {};
__export(group_admintrial_exports, {
  default: () => group_admintrial_default
});
module.exports = __toCommonJS(group_admintrial_exports);
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
let schedule = require2("node-schedule");
let handler = async (m, { jagoanproject, args, command, participants }) => {
  if (!m.isGroup) throw "Perintah ini hanya bisa digunakan di grup!";
  let target = m.mentionedJid ? m.mentionedJid[0] : args[0];
  if (!target) throw "Tag pengguna atau masukkan nomor target!";
  let time = args[1];
  if (!time) throw "Masukkan waktu dengan format yang benar! (misal: 10s, 5m, 2h, 1d, atau 2024-12-31 23:59:59)";
  let executeTime;
  if (/^\d+[smhd]$/.test(time)) {
    let value = parseInt(time);
    let unit = time.slice(-1);
    let multiplier = { s: 1e3, m: 6e4, h: 36e5, d: 864e5 };
    executeTime = new Date(Date.now() + value * multiplier[unit]);
  } else if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(time)) {
    executeTime = new Date(time);
    if (isNaN(executeTime)) throw "Format waktu tidak valid!";
  } else {
    throw "Format waktu tidak valid! Gunakan format seperti 10s, 5m, 2h, 1d, atau 2024-12-31 23:59:59";
  }
  let targetName = participants.find((p) => p.id === target)?.id || target;
  let action;
  let timerName;
  if (command === "jadiadmin") {
    await jagoanproject.groupParticipantsUpdate(m.chat, [target], "promote");
    action = "promote";
    timerName = "unadmin";
  } else if (command === "unadmin") {
    await jagoanproject.groupParticipantsUpdate(m.chat, [target], "demote");
    action = "demote";
    timerName = "jadiadmin";
  } else if (command === "kick") {
    await jagoanproject.groupParticipantsUpdate(m.chat, [target], "remove");
    action = "kick";
  } else {
    throw "Perintah tidak dikenali!";
  }
  m.reply(`Perintah "${command}" berhasil. Target: @${target.split("@")[0]}
Durasi: ${time}.
Perintah akan dijalankan pada ${executeTime.toLocaleString()}.`, null, {
    mentions: [target]
  });
  if (command !== "kick") {
    schedule.scheduleJob(executeTime, async () => {
      if (timerName === "unadmin") {
        await jagoanproject.groupParticipantsUpdate(m.chat, [target], "demote");
        m.reply(`Target @${target.split("@")[0]} telah di *demote* karena waktu habis.`, null, { mentions: [target] });
      } else if (timerName === "jadiadmin") {
        await jagoanproject.groupParticipantsUpdate(m.chat, [target], "promote");
        m.reply(`Target @${target.split("@")[0]} telah di *promote* kembali karena waktu habis.`, null, { mentions: [target] });
      }
    });
  }
};
handler.help = ["jadiadmin @user <waktu>", "unadmin @user <waktu>", "kick2 @user <waktu>"];
handler.command = /^(jadiadmin|unadmin|kick2)$/i;
handler.tags = ["group"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
handler.register = true;
handler.limit = true;
var group_admintrial_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
