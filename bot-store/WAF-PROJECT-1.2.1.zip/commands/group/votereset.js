/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - votereset.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_votereset_exports = {};
__export(group_votereset_exports, {
  default: () => group_votereset_default
});
module.exports = __toCommonJS(group_votereset_exports);
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const fs = require2("fs").promises;
const voteFile = import_path.default.join(__dirname, "../database/votekick.json");
async function loadVoteData() {
  try {
    const data = await fs.readFile(voteFile, "utf8");
    return JSON.parse(data);
  } catch {
    return {};
  }
}
async function saveVoteData(data) {
  await fs.writeFile(voteFile, JSON.stringify(data, null, 4));
}
let handler = async (m, { isAdmin }) => {
  if (!m.isGroup) return m.reply(`*[ ! ] Perintah ini hanya bisa digunakan di grup.*`);
  if (!isAdmin) return m.reply("\u{1F6A9} Hanya admin yang bisa mereset voting!");
  const voteData = await loadVoteData();
  const groupId = m.chat;
  if (!voteData[groupId] || Object.keys(voteData[groupId]).length === 0) {
    return m.reply("\u2705 Tidak ada voting yang berlangsung di grup ini.");
  }
  delete voteData[groupId];
  await saveVoteData(voteData);
  m.reply("\u267B\uFE0F Voting berhasil direset.");
};
handler.help = ["votereset"];
handler.tags = ["group"];
handler.command = ["votereset"];
handler.botAdmin = true;
handler.group = true;
handler.register = true;
handler.limit = true;
var group_votereset_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
