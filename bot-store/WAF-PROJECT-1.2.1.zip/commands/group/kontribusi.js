/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - kontribusi.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_kontribusi_exports = {};
__export(group_kontribusi_exports, {
  default: () => group_kontribusi_default
});
module.exports = __toCommonJS(group_kontribusi_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const DB_PATH = import_path.default.join(__dirname, "../../database/kontribusiGC.json");
if (!import_fs.default.existsSync(import_path.default.dirname(DB_PATH))) import_fs.default.mkdirSync(import_path.default.dirname(DB_PATH), { recursive: true });
let DB = {};
try {
  DB = JSON.parse(import_fs.default.readFileSync(DB_PATH, "utf8"));
} catch {
  DB = {};
}
const saveDB = () => import_fs.default.writeFileSync(DB_PATH, JSON.stringify(DB, null, 2));
function normalizeJid(jid = "") {
  return String(jid).replace(/[^0-9]/g, "") + "@s.whatsapp.net";
}
function ensure(gid, uid) {
  uid = normalizeJid(uid);
  if (!DB[gid]) DB[gid] = {};
  if (!DB[gid][uid]) DB[gid][uid] = { pesan: 0, kata: 0, media: 0, stiker: 0, tambah: 0, kick: 0 };
  return DB[gid][uid];
}
function getOwnerJids() {
  const raw = global.jpOwner || [];
  let nums = [];
  for (const v of raw) {
    if (!v) continue;
    if (Array.isArray(v)) nums.push(v[0]);
    else nums.push(v);
  }
  nums = nums.map((n) => String(n).replace(/[^0-9]/g, "")).filter(Boolean);
  return nums.map((n) => n + "@s.whatsapp.net");
}
function score(d) {
  return d.pesan * 1 + d.kata * 0.1 + d.media * 5 + d.stiker * 3 + d.tambah * 15 + d.kick * 10;
}
let handler = async (m, { jagoanproject, command, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply("\u274C Khusus grup.");
  const gid = m.chat;
  const cmd = (command || "").toLowerCase();
  if (cmd === "resetkontribusi") {
    const ownerJids = getOwnerJids();
    const allowed = isAdmin || isOwner || ownerJids.includes(normalizeJid(m.sender));
    if (!allowed) return m.reply("\u274C Hanya admin atau owner bot yang bisa mereset.");
    DB[gid] = {};
    saveDB();
    return m.reply("\u2705 Data kontribusi grup ini sudah direset.");
  }
  if (!DB[gid] || !Object.keys(DB[gid]).length) return m.reply("\u2139\uFE0F Belum ada data kontribusi di grup ini.");
  const merged = {};
  for (const [id, data] of Object.entries(DB[gid])) {
    const normId = normalizeJid(id);
    if (!merged[normId]) merged[normId] = { ...data };
    else {
      merged[normId].pesan += data.pesan;
      merged[normId].kata += data.kata;
      merged[normId].media += data.media;
      merged[normId].stiker += data.stiker;
      merged[normId].tambah += data.tambah;
      merged[normId].kick += data.kick;
    }
  }
  DB[gid] = merged;
  saveDB();
  const rows = Object.entries(merged).map(([id, d]) => ({ id, ...d, skor: score(d) })).sort((a, b) => b.skor - a.skor);
  let txt = `\u{1F451} *Papan Peringkat Kontribusi Admin* \u{1F451}

`;
  txt += `Berikut adalah peringkat kontribusi para admin di grup ini:

`;
  for (let i = 0; i < rows.length; i++) {
    const u = rows[i];
    txt += `*${i + 1}.* @${u.id.split("@")[0]}
`;
    txt += `   \u2728 *Skor Kontribusi: ${u.skor.toFixed(1)}*
`;
    txt += `   --------------------
`;
    txt += `   \u{1F4AC} Pesan: *${u.pesan}*
`;
    txt += `   \u270D\uFE0F Kata: *${u.kata}*
`;
    txt += `   \u{1F5BC}\uFE0F Media: *${u.media}*
`;
    txt += `   \u{1F9E9} Stiker: *${u.stiker}*
`;
    txt += `   \u2795 Tambah Anggota: *${u.tambah}*
`;
    txt += `   \u2796 Keluarkan Anggota: *${u.kick}*

`;
  }
  txt += `_Skor: Pesan (1), Kata (0.1), Media (5), Stiker (3), Tambah (15), Kick (10)_`;
  await jagoanproject.sendMessage(m.chat, { text: txt, mentions: rows.map((u) => u.id) }, { quoted: m });
};
handler.help = ["kontribusi", "resetkontribusi"];
handler.tags = ["group"];
handler.command = /^(kontribusi|resetkontribusi)$/i;
handler.group = true;
handler.all = async function(m) {
  if (!m.isGroup) return;
  let meta;
  try {
    meta = await this.groupMetadata(m.chat);
  } catch {
    return;
  }
  if (!meta?.participants) return;
  const ownerJids = new Set(getOwnerJids());
  const botJid = normalizeJid(this.user?.id);
  const adminSet = new Set(
    meta.participants.filter((p) => p.admin).map((p) => normalizeJid(p.jid || p.id))
  );
  for (const o of ownerJids) adminSet.add(o);
  if (botJid) adminSet.add(botJid);
  let actor = m.sender;
  if ([27, 28].includes(m.messageStubType)) {
    actor = m.participant || m.key?.participant || m.sender;
  }
  const partData = meta.participants.find((p) => p.id === actor || p.jid === actor || p.lid === actor);
  if (partData) actor = partData.jid || partData.id;
  actor = normalizeJid(actor);
  if (!adminSet.has(actor)) return;
  const d = ensure(m.chat, actor);
  const text = (m.text || m.msg?.text || "").toString();
  if (text) {
    d.pesan += 1;
    const wc = text.trim().split(/\s+/).filter(Boolean).length;
    d.kata += wc;
  }
  if (m.mtype === "stickerMessage") {
    d.stiker += 1;
  }
  if (["imageMessage", "videoMessage", "audioMessage", "documentMessage"].includes(m.mtype)) {
    d.media += 1;
  }
  if (m.messageStubType === 27) {
    d.tambah += 1;
  } else if (m.messageStubType === 28) {
    d.kick += 1;
  }
  saveDB();
};
handler.register = true;
var group_kontribusi_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
