/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - setlabel.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_setlabel_exports = {};
__export(group_setlabel_exports, {
  default: () => group_setlabel_default
});
module.exports = __toCommonJS(group_setlabel_exports);
let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `\u274C Teksnya mana?

Contoh:
${usedPrefix + command} Hai @user baru saja ganti label!`;
  global.db.data.chats[m.chat].sTagLabel = text.trim();
  m.reply(`\u2705 Pesan deteksi label berhasil diatur.`);
};
handler.help = ["setlabel <teks>"];
handler.tags = ["group"];
handler.command = /^(setlabel|settaglabel)$/i;
handler.group = true;
handler.admin = true;
var group_setlabel_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
