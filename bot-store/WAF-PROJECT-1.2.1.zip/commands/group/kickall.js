/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - kickall.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_kickall_exports = {};
__export(group_kickall_exports, {
  default: () => group_kickall_default
});
module.exports = __toCommonJS(group_kickall_exports);
let handler = async (m, { jagoanproject, isOwner, isAdmin, participants = [] }) => {
  if (!(isAdmin || isOwner)) {
    global.jpDfail("admin", m, jagoanproject);
    throw false;
  }
  const memberList = Array.isArray(participants) ? participants : [];
  const admins = memberList.filter((p) => p.admin).map((p) => p.id || p.jid);
  const membersToKick = memberList.map((p) => p.id || p.jid).filter((id) => id && !admins.includes(id) && id !== jagoanproject.user.jid);
  if (membersToKick.length === 0) return m.reply("Tidak ada member yang bisa dikick.");
  for (let user of membersToKick) {
    await jagoanproject.groupParticipantsUpdate(m.chat, [user], "remove");
    await new Promise((resolve) => setTimeout(resolve, 5e3));
  }
  await jagoanproject.sendMessage(m.chat, { text: "Berhasil mengeluarkan semua member." });
};
handler.help = ["kickall"];
handler.tags = ["group", "owner"];
handler.command = /^(kickall)$/i;
handler.group = true;
handler.botAdmin = true;
handler.owner = true;
handler.register = true;
handler.limit = true;
var group_kickall_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
