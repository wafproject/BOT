/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - votekick.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_votekick_exports = {};
__export(group_votekick_exports, {
  default: () => group_votekick_default
});
module.exports = __toCommonJS(group_votekick_exports);
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const fs = require2("fs").promises;
const voteFile = import_path.default.join(__dirname, "../../database/votekick.json");
const storeVote = {};
async function loadVoteData() {
  try {
    const data = await fs.readFile(voteFile, "utf8");
    return JSON.parse(data);
  } catch {
    return {};
  }
}
async function saveVoteData(data) {
  await fs.writeFile(voteFile, JSON.stringify(data, null, 5));
}
const pertahankanEmoji = ["\u2764", "\u2764\uFE0F"];
const kickEmoji = ["\u{1F44D}", "\u{1F44D}\u{1F3FB}", "\u{1F44D}\u{1F3FC}", "\u{1F44D}\u{1F3FD}", "\u{1F44D}\u{1F3FE}", "\u{1F44D}\u{1F3FF}"];
let handler = async (m, { jagoanproject, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply(`*[ ! ] Perintah ini hanya bisa digunakan di grup.*`);
  if (!isAdmin) return m.reply("\u{1F6A9} Hanya admin yang bisa memulai voting!");
  if (!isBotAdmin) return m.reply("\u{1F6A9} Bot bukan admin!");
  let who = m.mentionedJid?.[0] || (m.quoted ? m.quoted.sender : null);
  if (!who) throw `*\u2022 Contoh :* ${usedPrefix}${command} *[@user]*`;
  const metadata = jagoanproject?.chats?.[m.chat]?.metadata || await jagoanproject.groupMetadata(m.chat);
  const pesertaTarget = metadata.participants.find((p) => p.id === who) || {};
  const targetIsAdmin = pesertaTarget?.admin === "admin" || pesertaTarget?.admin === "superadmin" || pesertaTarget?.isAdmin === true;
  if (targetIsAdmin || who === jagoanproject.user.id)
    return m.reply("*[ ! ] Tidak bisa vote kick admin/bot.*");
  const voteData = await loadVoteData();
  const groupId = m.chat;
  if (!voteData[groupId]) voteData[groupId] = {};
  let voteAktif = null;
  for (const [jid, data] of Object.entries(voteData[groupId])) {
    if (data && typeof data === "object") {
      voteAktif = data;
      break;
    }
  }
  if (voteAktif) {
    if (voteAktif.target === who) {
      return m.reply(
        `\u26A0\uFE0F Voting untuk @${who.split("@")[0]} sudah berlangsung.
Selesaikan vote ini atau reset dengan *.votereset*.`,
        { mentions: [who] }
      );
    } else {
      return m.reply(
        `\u26A0\uFE0F Sedang ada voting lain di grup ini untuk @${voteAktif.target.split("@")[0]}.
Gunakan *.votereset* untuk membatalkan vote sebelumnya.`,
        { mentions: [voteAktif.target] }
      );
    }
  }
  const allMembers = metadata.participants.map((p) => p.id);
  const voteMsg = await jagoanproject.sendMessage(
    m.chat,
    {
      text: `Silahkan *React pesan ini* untuk voting.
${pertahankanEmoji[1]} = Pertahankan
\u{1F44D}\u{1F3FB} = Kick

Target: @${who.split("@")[0]}
> Jika bot tidak merespon, artinya sedang ada vote berlangsung, pilihannya dua, selesaikan voting atau .resetvote
> Vote per orang hanya sekali react, pertahankan atau kick
> jika mencapai 5 vote maka user target akan di kick`,
      mentions: [...allMembers, who]
    },
    { quoted: m }
  );
  voteData[groupId][who] = {
    message_id: voteMsg.key.id,
    target: who,
    kick_votes: 0,
    voters: []
  };
  await saveVoteData(voteData);
  storeVote[voteMsg.key.id] = {
    chatId: m.chat,
    target: who,
    kick_votes: 0,
    voters: []
  };
};
handler.before = async function(m, { jagoanproject }) {
  if (m.mtype !== "reactionMessage") return;
  if (!m.isGroup) return;
  const emoji = m.msg.text;
  const reactedToId = m.msg.key.id;
  if (![...pertahankanEmoji, ...kickEmoji].includes(emoji)) return;
  const info = storeVote[reactedToId];
  if (!info) return;
  const voter = m.key.participant || m.key.remoteJid;
  if (info.voters.includes(voter)) {
    return jagoanproject.sendMessage(info.chatId, {
      text: `*[ ! ] @${voter.split("@")[0]} sudah vote untuk @${info.target.split("@")[0]}. dan hanya bisa sekali vote*`,
      mentions: [voter, info.target]
    });
  }
  if (kickEmoji.includes(emoji)) {
    info.kick_votes += 1;
    info.voters.push(voter);
    if (info.kick_votes >= 5) {
      try {
        await jagoanproject.groupParticipantsUpdate(info.chatId, [info.target], "remove");
        await jagoanproject.sendMessage(info.chatId, {
          text: `*[ VOTE KICK MEMBER @${info.target.split("@")[0]} ]*
SUKSES DIKICK (mencapai 5 vote).`,
          mentions: [info.target]
        });
      } finally {
        delete storeVote[reactedToId];
        const voteData = await loadVoteData();
        if (voteData[info.chatId]) delete voteData[info.chatId][info.target];
        await saveVoteData(voteData);
      }
    } else {
      await jagoanproject.sendMessage(info.chatId, {
        text: `*[ KICK MEMBER ]*
@${voter.split("@")[0]} memilih untuk *kick* @${info.target.split("@")[0]}
> Tersisa*(${info.kick_votes}/5)* Vote lagi untuk kick.`,
        mentions: [info.target]
      });
    }
  } else if (pertahankanEmoji.includes(emoji)) {
    info.voters.push(voter);
    await jagoanproject.sendMessage(info.chatId, {
      text: `*[ PERTAHANKAN MEMBER ]* @${voter.split("@")[0]} memilih untuk *Mempertahankan* @${info.target.split("@")[0]}.`,
      mentions: [voter, info.target]
    });
  }
};
handler.help = ["votekick *[@user]*"];
handler.tags = ["group"];
handler.command = ["votekick"];
handler.botAdmin = true;
handler.group = true;
handler.register = true;
handler.limit = true;
var group_votekick_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
