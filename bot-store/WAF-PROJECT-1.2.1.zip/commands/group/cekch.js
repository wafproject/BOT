/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - cekch.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_cekch_exports = {};
__export(group_cekch_exports, {
  default: () => group_cekch_default
});
module.exports = __toCommonJS(group_cekch_exports);
let handler = async (m, { jagoanproject, text }) => {
  if (!text) return m.reply("\u26A0\uFE0F *Gunakan perintah dengan link channel!*\n\u{1F4CC} Contoh: !cekidch https://whatsapp.com/channel/example");
  if (!text.includes("https://whatsapp.com/channel/")) return m.reply("\u274C *Link tautan tidak valid!* Pastikan menggunakan link yang benar.");
  let result = text.split("https://whatsapp.com/channel/")[1];
  try {
    let res = await jagoanproject.newsletterMetadata("invite", result);
    console.log("Respons API:", res);
    if (!res || !res.id) {
      return m.reply("\u26A0\uFE0F *Data tidak ditemukan!* Mungkin channel tidak publik atau API mengalami perubahan.");
    }
    let channelLink = `https://whatsapp.com/channel/${result}`;
    let teks = `
\u{1F539} *Nama:* ${res.name}
\u{1F194} *ID:* ${res.id}
\u{1F465} *Total Pengikut:* ${res.subscribers.toLocaleString()}
\u2705 *Verified:* ${res.verification === "VERIFIED" ? "Terverifikasi" : "Tidak"}
        `;
    let interactiveButtons = [
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "\u{1F4CB} Salin ID",
          id: res.id,
          copy_code: res.id
        })
      },
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "\u{1F517} Kunjungi Channel",
          url: channelLink
        })
      }
    ];
    let interactiveMessage = {
      text: teks,
      title: "\u{1F4E2} Informasi Channel WhatsApp",
      footer: "Jagoan Project",
      viewOnce: true,
      interactiveButtons
    };
    return jagoanproject.sendMessage(m.chat, interactiveMessage, { quoted: m });
  } catch (e) {
    console.error("Error:", e);
    return m.reply("\u274C *Terjadi kesalahan!* Pastikan bot memiliki akses dan coba lagi.");
  }
};
handler.help = ["cekidch"].map((a) => a + " *[Cek ID Channel WhatsApp]*");
handler.tags = ["tools"];
handler.command = /^(cekidch|idch)$/i;
var group_cekch_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
