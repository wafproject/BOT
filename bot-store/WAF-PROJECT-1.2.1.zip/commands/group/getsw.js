/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - getsw.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_getsw_exports = {};
__export(group_getsw_exports, {
  default: () => group_getsw_default
});
module.exports = __toCommonJS(group_getsw_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  try {
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u23F3", key: m.key } });
    if (!m.quoted) throw `Reply status grup (foto/video/teks) dengan:
${usedPrefix + command}`;
    const q = m.quoted;
    if (!q.chat || !q.chat.startsWith("120363") || !q.chat.endsWith("@g.us")) {
      throw `Bukan status grup!
Hanya bisa ambil dari tab Updates \u2192 Status grup manapun.`;
    }
    const mediaMsg = q.message?.imageMessage || q.message?.videoMessage || q.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage || q.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage;
    if (mediaMsg) {
      const { downloadContentFromMessage } = __zapo_1;
      const stream = await downloadContentFromMessage(mediaMsg, mediaMsg.mimetype.startsWith("image") ? "image" : "video");
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      const caption = mediaMsg.caption || "";
      const isGif = mediaMsg.seconds < 11 && mediaMsg.gifPlayback;
      if (mediaMsg.mimetype.startsWith("image/")) {
        await jagoanproject.sendFile(m.chat, buffer, "", caption || "Dari Status Grup", m);
      } else {
        if (isGif) {
          await jagoanproject.sendVideoAsSticker(m.chat, buffer, m, {
            packname: global.packname || "Jagoan Project",
            author: global.author || "GetSW"
          });
        } else {
          await jagoanproject.sendFile(m.chat, buffer, "", caption || "Video dari Status Grup", m);
        }
      }
    } else {
      let text = q.message?.conversation || q.message?.extendedTextMessage?.text || q.message?.imageMessage?.caption || q.message?.videoMessage?.caption || "Status tanpa teks.";
      if (text.trim() === "") text = "_Status kosong atau hanya emoji_";
      await m.reply(`\u{1F4E2} *Status Grup Teks*

${text}`);
    }
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } });
  } catch (e) {
    console.error("GetSW Error:", e);
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } });
    m.reply(`Gagal ambil status!
${e.message || e}

Tips:
\u2022 Reply langsung status di tab Updates
\u2022 Bisa foto, video, atau teks doang
\u2022 Bot harus bisa lihat statusnya`);
  }
};
handler.help = ["getsw"];
handler.tags = ["tools"];
handler.command = /^(getsw|ambilsw|getstatus)$/i;
handler.limit = false;
handler.group = true;
handler.register = true;
var group_getsw_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
