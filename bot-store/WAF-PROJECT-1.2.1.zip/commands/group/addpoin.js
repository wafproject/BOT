/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - addpoin.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_addpoin_exports = {};
__export(group_addpoin_exports, {
  default: () => group_addpoin_default
});
module.exports = __toCommonJS(group_addpoin_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const libDir = import_path.default.join(__dirname, "../../database");
const poinFile = import_path.default.join(libDir, "data_poin.json");
if (!import_fs.default.existsSync(libDir)) import_fs.default.mkdirSync(libDir, { recursive: true });
if (!import_fs.default.existsSync(poinFile)) import_fs.default.writeFileSync(poinFile, JSON.stringify({}));
function loadPoin() {
  return JSON.parse(import_fs.default.readFileSync(poinFile));
}
function savePoin(data) {
  import_fs.default.writeFileSync(poinFile, JSON.stringify(data, null, 2));
}
let handler = async (m, { jagoanproject, text, args, command }) => {
  const data = loadPoin();
  const groupId = m.chat;
  data[groupId] = data[groupId] || {};
  const mention = m.mentionedJid[0];
  const jumlah = parseInt(args[1]);
  if (command === "addpoin") {
    if (!mention) return m.reply("*\u274C Format salah!*\n\n\u{1F4DD} Contoh:\n.addpoin @user 10");
    if (isNaN(jumlah)) return m.reply("\u{1F614} Jumlah poin tidak valid!");
    const userId = mention;
    data[groupId][userId] = (data[groupId][userId] || 0) + jumlah;
    savePoin(data);
    return m.reply(`\u2705 Poin ditambahkan

\u{1FAAA} Nama: ${await jagoanproject.getName(userId)}
\u{1FA99} Poin: +${jumlah} poin`);
  }
  if (command === "rempoin") {
    if (!mention) return m.reply("*\u274C Format salah!*\n\n\u{1F4DD} Contoh:\n.rempoin @user 5");
    if (isNaN(jumlah)) return m.reply("\u{1F614} Jumlah poin tidak valid!");
    const userId = mention;
    data[groupId][userId] = Math.max((data[groupId][userId] || 0) - jumlah, 0);
    savePoin(data);
    return m.reply(`\u2705 Poin dikurangi

\u{1FAAA} Nama: ${await jagoanproject.getName(userId)}
\u{1FA99} Poin: -${jumlah} poin`);
  }
  if (command === "toppoin") {
    const poinList = Object.entries(data[groupId]).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([user, poin], i) => `${i + 1}. @${user.split("@")[0]} *${poin} poin* \u{1FA99}`).join("\n");
    if (!poinList) return m.reply("\u{1F614} Belum ada data poin di grup ini.");
    return m.reply(`\u{1FAC5}\u{1F3FB} LIST TOP POIN :

${poinList}`, null, {
      mentions: Object.keys(data[groupId])
    });
  }
  if (command === "delpoin") {
    if (mention) {
      const userId = mention;
      if (!data[groupId][userId]) return m.reply("\u{1F614} User belum memiliki poin.");
      delete data[groupId][userId];
      savePoin(data);
      return m.reply(`\u{1F5D1}\uFE0F Poin untuk ${await jagoanproject.getName(userId)} berhasil direset!`);
    } else {
      data[groupId] = {};
      savePoin(data);
      return m.reply("\u{1F5D1}\uFE0F Semua poin di grup ini telah dihapus!");
    }
  }
  if (command === "poin") {
    if (args[0] === "info") {
      return m.reply(`\u{1F4D8} *TUTORIAL FITUR POIN* \u{1FA99}

Berikut daftar perintah yang bisa digunakan:

\u{1F4CC} *.addpoin @user <jumlah>*
\u27A0 Menambahkan poin ke user.
\u{1F9E9} Contoh: *.addpoin @andi 10*

\u{1F4CC} *.rempoin @user <jumlah>*
\u27A0 Mengurangi poin dari user.
\u{1F9E9} Contoh: *.rempoin @andi 5*

\u{1F4CC} *.delpoin @user*
\u27A0 Reset poin user jadi 0.
\u{1F9E9} Contoh: *.delpoin @andi*

\u{1F4CC} *.delpoin*
\u27A0 Hapus semua data poin grup.

\u{1F4CC} *.toppoin*
\u27A0 Melihat 10 besar user dengan poin tertinggi.

\u{1F4CC} *.poin @user*
\u27A0 Melihat jumlah poin user.

\u{1F4CC} *.poin info*
\u27A0 Menampilkan tutorial ini. \u{1F970}

\u{1F510} *Hanya admin yang bisa menggunakan perintah-perintah ini.*
`);
    }
    if (mention) {
      const userId = mention;
      const poin = data[groupId][userId] || 0;
      return m.reply(`\u{1F4CA} Poin untuk *${await jagoanproject.getName(userId)}* adalah: *${poin} poin* \u{1FA99}`);
    }
    return m.reply("\u274C Format salah!\n\n\u{1F4DD} Contoh:\n.poin @user\n.poin info");
  }
};
handler.help = ["addpoin <@user> <jumlah>", "rempoin <@user> <jumlah>", "delpoin [@user]", "toppoin", "poin @user/info"];
handler.tags = ["group"];
handler.command = /^addpoin|rempoin|delpoin|toppoin|poin$/i;
handler.group = true;
handler.admin = true;
handler.register = true;
handler.limit = true;
var group_addpoin_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
