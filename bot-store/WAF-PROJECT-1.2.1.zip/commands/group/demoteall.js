/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - demoteall.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_demoteall_exports = {};
__export(group_demoteall_exports, {
  default: () => group_demoteall_default
});
module.exports = __toCommonJS(group_demoteall_exports);
let handler = async (m, { jagoanproject, participants = [] }) => {
  jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F552}", key: m.key } });
  let memberList = Array.isArray(participants) ? participants : [];
  let groupAdmins = m.isGroup ? memberList.filter((v) => v.admin !== null).map((i) => i.id || i.jid) : [];
  let data = groupAdmins.splice(m.sender, groupAdmins.length - 1);
  await jagoanproject.groupParticipantsUpdate(m.chat, data, "demote");
  m.reply("Done");
};
handler.tags = ["owner"];
handler.help = ["demoteall"];
handler.command = ["demoteall"];
handler.group = true;
handler.owner = true;
handler.register = true;
handler.limit = true;
var group_demoteall_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
