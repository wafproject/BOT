/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - intro.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_intro_exports = {};
__export(group_intro_exports, {
  default: () => group_intro_default
});
module.exports = __toCommonJS(group_intro_exports);
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const fs = require2("fs").promises;
const dbPath = import_path.default.join(__dirname, "../../database/intro.json");
async function ensureDbFile() {
  try {
    await fs.access(dbPath);
    const data = await fs.readFile(dbPath, "utf8");
    if (!data || data.trim() === "") {
      await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
      return;
    }
    JSON.parse(data);
  } catch {
    await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
  }
}
async function loadDb() {
  await ensureDbFile();
  try {
    const data = await fs.readFile(dbPath, "utf8");
    return JSON.parse(data);
  } catch {
    return {};
  }
}
async function saveDb(data) {
  try {
    await fs.writeFile(dbPath, JSON.stringify(data, null, 2));
  } catch {
  }
}
function cleanVal(v) {
  if (v == null) return "";
  return String(v).replace(/[│]/g, "").replace(/[ ]{2,}/g, " ").trim();
}
function pick(text, keys) {
  for (const k of keys) {
    const re = new RegExp(`${k}\\s*[:\uFF1A]\\s*(.*)$`, "im");
    const m = String(text || "").match(re);
    if (m) return cleanVal(m[1] ?? "");
  }
  return "";
}
function isDeleteKeyword(v) {
  const s = (v || "").toLowerCase().trim();
  return ["-", "hapus", "delete", "remove", "gaada", "gak ada", "tidak ada", "none", "null"].includes(s);
}
function normalizeField(v) {
  let s = cleanVal(v || "");
  if (!s) return "";
  if (isDeleteKeyword(s)) return "__DELETE__";
  return s;
}
function normalizeGender(v) {
  let s = cleanVal(v || "");
  if (!s) return "";
  if (isDeleteKeyword(s)) return "__DELETE__";
  const low = s.toLowerCase();
  if (["l", "lk", "laki", "laki-laki", "cowok", "pria"].includes(low)) return "Laki-laki";
  if (["p", "pr", "perempuan", "cewek", "wanita"].includes(low)) return "Perempuan";
  return s;
}
function normalizeAge(v) {
  let s = cleanVal(v || "");
  if (!s) return "";
  if (isDeleteKeyword(s)) return "__DELETE__";
  const num = s.replace(/[^0-9]/g, "");
  if (!num) return "";
  return num;
}
function parseIntroProfile(text) {
  const t = String(text || "");
  const nama = pick(t, ["Nama"]);
  const umur = pick(t, ["Umur"]);
  const tgl = pick(t, ["Tanggal\\s*Lahir", "Tanggal\\s*Lahir\\s*\\(DD-MM-YYYY\\)", "Tanggal\\s*Lahir\\s*\\(YYYY-MM-DD\\)"]);
  const jk = pick(t, ["Jenis\\s*Kelamin"]);
  const agama = pick(t, ["Agama"]);
  const hobi = pick(t, ["Hobi"]);
  const kota = pick(t, ["Kota"]);
  const facebook = pick(t, ["Facebook"]);
  const instagram = pick(t, ["Instagram"]);
  const tiktok = pick(t, ["TikTok"]);
  return {
    nama: normalizeField(nama),
    umur: normalizeAge(umur),
    birth: normalizeField(tgl),
    gender: normalizeGender(jk),
    religion: normalizeField(agama),
    hobby: normalizeField(hobi),
    city: normalizeField(kota),
    facebook: normalizeField(facebook),
    instagram: normalizeField(instagram),
    tiktok: normalizeField(tiktok)
  };
}
function hasAnyMeaningful(obj) {
  return Object.values(obj).some((v) => v && String(v).trim() !== "");
}
function safeStr(v) {
  if (v == null) return "";
  const s = String(v).trim();
  if (!s || s === "-" || s === "undefined" || s === "null") return "";
  return s;
}
function buildAutoTemplateFromUser(u = {}) {
  const nama = safeStr(u.realName || u.nama);
  const umur = safeStr(u.age);
  const ttl = safeStr(u.birth || u.tglLahir || u.birthday);
  const jk = safeStr(u.gender || u.jk);
  const agama = safeStr(u.religion || u.agama);
  const hobi = safeStr(u.hobby || u.hobi);
  const kota = safeStr(u.city || u.kota);
  const fb = safeStr(u.facebook || u.fb);
  const ig = safeStr(u.instagram || u.ig);
  const tt = safeStr(u.tiktok || u.tt);
  return `.intro Nama: ${nama}
Umur: ${umur}
Tanggal Lahir: ${ttl}
Jenis Kelamin: ${jk}
Agama: ${agama}
Hobi: ${hobi}
Kota: ${kota}

Facebook: ${fb}
Instagram: ${ig}
TikTok: ${tt}`;
}
let handler = async (m, { text, command, jagoanproject, isAdmin }) => {
  const cmd = (command || "").toLowerCase();
  const arg = (text || "").trim();
  const admin = !!isAdmin;
  global.db = global.db || {};
  global.db.data = global.db.data || {};
  global.db.data.users = global.db.data.users || {};
  const groupId = m.chat;
  if (cmd === "setintro") {
    if (!admin) return jagoanproject.reply(m.chat, "\u274C Khusus admin untuk mengubah template intro.", m);
    if (!arg) {
      return jagoanproject.reply(
        m.chat,
        "Contoh:\n.setintro Nama:\nUmur:\nTanggal Lahir:\nJenis Kelamin:\nAgama:\nHobi:\nKota:\n\nFacebook:\nInstagram:\nTikTok:",
        m
      );
    }
    const db = await loadDb();
    db[groupId] = arg;
    await saveDb(db);
    return jagoanproject.reply(m.chat, "\u2705 Template intro grup berhasil diubah (khusus template yang di-copy).", m);
  }
  if (cmd === "intro") {
    if (arg.toLowerCase() === "reset") {
      const u2 = global.db.data.users[m.sender] || (global.db.data.users[m.sender] = {});
      delete u2.realName;
      delete u2.age;
      delete u2.birth;
      delete u2.gender;
      delete u2.religion;
      delete u2.hobby;
      delete u2.city;
      delete u2.facebook;
      delete u2.instagram;
      delete u2.tiktok;
      u2.introUpdatedAt = Date.now();
      return jagoanproject.reply(m.chat, "\u2705 Data profil (dari .intro) berhasil direset.", m);
    }
    if (arg) {
      const parsed = parseIntroProfile(arg);
      if (!hasAnyMeaningful(parsed)) {
        return jagoanproject.reply(
          m.chat,
          `\u274C Format tidak terbaca.

Ketik *.intro* lalu klik tombol *Copy Template*, isi datanya, lalu kirim:
.intro <paste template>`,
          m
        );
      }
      const u2 = global.db.data.users[m.sender] || (global.db.data.users[m.sender] = {});
      if (parsed.nama === "__DELETE__") delete u2.realName;
      else if (parsed.nama) u2.realName = parsed.nama;
      if (parsed.umur === "__DELETE__") delete u2.age;
      else if (parsed.umur) u2.age = Number(parsed.umur) || parsed.umur;
      if (parsed.birth === "__DELETE__") delete u2.birth;
      else if (parsed.birth) u2.birth = parsed.birth;
      if (parsed.gender === "__DELETE__") delete u2.gender;
      else if (parsed.gender) u2.gender = parsed.gender;
      if (parsed.religion === "__DELETE__") delete u2.religion;
      else if (parsed.religion) u2.religion = parsed.religion;
      if (parsed.hobby === "__DELETE__") delete u2.hobby;
      else if (parsed.hobby) u2.hobby = parsed.hobby;
      if (parsed.city === "__DELETE__") delete u2.city;
      else if (parsed.city) u2.city = parsed.city;
      if (parsed.facebook === "__DELETE__") delete u2.facebook;
      else if (parsed.facebook) u2.facebook = parsed.facebook;
      if (parsed.instagram === "__DELETE__") delete u2.instagram;
      else if (parsed.instagram) u2.instagram = parsed.instagram;
      if (parsed.tiktok === "__DELETE__") delete u2.tiktok;
      else if (parsed.tiktok) u2.tiktok = parsed.tiktok;
      u2.introUpdatedAt = Date.now();
      return jagoanproject.reply(
        m.chat,
        `\u2705 Profil berhasil diperbarui!

Catatan:
\u2022 Field yang kamu kosongkan \u2192 tidak diubah.
\u2022 Isi "-" atau "hapus" \u2192 menghapus field.

Sekarang cek: *.profile*`,
        m
      );
    }
    const db = await loadDb();
    const u = global.db.data.users[m.sender] || {};
    const autoTemplate = buildAutoTemplateFromUser(u);
    const templateFromGroup = db[groupId] && String(db[groupId]).trim();
    const copyCode = templateFromGroup ? templateFromGroup : autoTemplate;
    const msg = {
      text: `EDIT PROFIL

Klik tombol "Copy Template" \u2192 paste \u2192 edit \u2192 kirim:
.intro <paste>

Catatan:
- Kosongkan field kalau tidak mau mengubah
- Isi "-" atau "hapus" untuk menghapus field

Reset: .intro reset`,
      footer: "Template akan terisi otomatis sesuai data profil kamu saat ini.",
      interactiveButtons: [
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "Copy Template",
            id: "INTRO_COPY_TEMPLATE",
            copy_code: copyCode
          })
        }
      ]
    };
    return await jagoanproject.sendMessage(m.chat, msg, { quoted: m });
  }
};
handler.command = /^(intro|setintro)$/i;
handler.register = true;
handler.limit = true;
var group_intro_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
