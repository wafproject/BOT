/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - promoteme.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_promoteme_exports = {};
__export(group_promoteme_exports, {
  default: () => group_promoteme_default
});
module.exports = __toCommonJS(group_promoteme_exports);
let handler = async (m, { jagoanproject, isOwner }) => {
  if (!m.isGroup) return m.reply("\u26A0\uFE0F Hanya bisa dipakai di group.");
  if (!isOwner) return m.reply("\u26A0\uFE0F Hanya *Owner Bot* yang bisa pakai perintah ini.");
  const groupMetadata = await jagoanproject.groupMetadata(m.chat);
  const me = groupMetadata.participants.find((p) => p.jid === jagoanproject.user.jid);
  if (!me?.admin) return m.reply("\u26A0\uFE0F Bot harus admin dulu agar bisa promote.");
  try {
    await jagoanproject.groupParticipantsUpdate(m.chat, [m.sender], "promote");
    await m.reply(`\u2705 @${m.sender.split("@")[0]} berhasil dipromote jadi admin!`, null, { mentions: [m.sender] });
  } catch (e) {
    console.error(e);
    await m.reply("\u274C Gagal promote, pastikan bot admin.");
  }
};
handler.help = ["promoteme"];
handler.tags = ["group"];
handler.command = /^promoteme$/i;
handler.group = true;
handler.botAdmin = true;
handler.owner = true;
handler.register = true;
handler.limit = true;
var group_promoteme_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
