/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - spamtag.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_spamtag_exports = {};
__export(group_spamtag_exports, {
  default: () => group_spamtag_default
});
module.exports = __toCommonJS(group_spamtag_exports);
const handler = async (m, { jagoanproject, text, args, participants }) => {
  try {
    if (!text) return m.reply("\u274C Tag orangnya dulu bang, contoh: .spamtag @user");
    const mention = m.mentionedJid && m.mentionedJid.length > 0 ? m.mentionedJid[0] : "";
    if (!mention) return m.reply("\u274C Tag yang bener bang, harus pakai @user");
    const ownerNumber = "6287823745178";
    const user = db.data.users[m.sender];
    const isOwner = m.sender.includes(ownerNumber);
    const limit = isOwner ? 10 : user?.premium ? 5 : 3;
    for (let i = 0; i < limit; i++) {
      await delay(700);
      await jagoanproject.sendMessage(m.chat, {
        text: `@${mention.split("@")[0]}`,
        mentions: [mention]
      }, { quoted: m });
    }
    await jagoanproject.sendMessage(m.chat, { text: "\u2705 Dah tu spam tag" }, { quoted: m });
  } catch (e) {
    m.reply(`\u274C Error
Logs error : ${e.message}`);
  }
};
handler.command = ["spamtag"];
handler.help = ["spamtag @user"];
handler.tags = ["group"];
handler.group = true;
handler.admin = true;
handler.botAdmin = false;
handler.register = true;
handler.limit = true;
var group_spamtag_default = handler;
function delay(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
