/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - resettotal.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_resettotal_exports = {};
__export(group_resettotal_exports, {
  default: () => group_resettotal_default
});
module.exports = __toCommonJS(group_resettotal_exports);
let resetHandler = async (m, { jagoanproject, isAdmin, isBotAdmin, args }) => {
  if (!m.isGroup) throw "*Perintah ini hanya bisa digunakan di grup.*";
  if (!isAdmin) throw "*Hanya admin grup yang bisa mereset data total pesan.*";
  if (!db.data.chats[m.chat]?.total) {
    db.data.chats[m.chat].total = {};
  }
  if (args[0] === "all") {
    db.data.chats[m.chat].total = {};
    await m.reply("*\u2705 Data total pesan untuk semua pengguna telah direset.*");
  } else if (args[0]) {
    const target = args[0].replace(/@|[^\d]/g, "") + "@s.whatsapp.net";
    if (db.data.chats[m.chat].total[target]) {
      delete db.data.chats[m.chat].total[target];
      await m.reply(`*\u2705 Data total pesan untuk pengguna @${args[0]} telah direset.*`, null, {
        contextInfo: {
          mentionedJid: [target]
        }
      });
    } else {
      await m.reply(`*\u274C Tidak ada data pesan untuk pengguna @${args[0]}.*`, null, {
        contextInfo: {
          mentionedJid: [target]
        }
      });
    }
  } else {
    throw "*Gunakan format:* `.resettotal @tag` atau `.resettotal all`";
  }
};
resetHandler.help = ["resettotal @tag", "resettotal all"];
resetHandler.tags = ["group"];
resetHandler.command = /^(resettotal)$/i;
resetHandler.admin = true;
resetHandler.group = true;
var group_resettotal_default = resetHandler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
