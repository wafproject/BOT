/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - polling.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_polling_exports = {};
__export(group_polling_exports, {
  default: () => group_polling_default
});
module.exports = __toCommonJS(group_polling_exports);
let handler = async (m, { jagoanproject, text, command, prefix }) => {
  if (!text || !text.includes("|")) {
    return m.reply(`Contoh:
.Siapa presiden RI?|Jokowi|Prabowo|Anies`);
  }
  let [question, ...options] = text.split("|").map((v) => v.trim());
  if (options.length < 2) {
    return m.reply("Minimal 2 opsi diperlukan untuk membuat polling.");
  }
  let sentMessage = await jagoanproject.sendMessage(m.chat, {
    poll: {
      name: question,
      values: options,
      selectableCount: 1
      // 🔒 hanya bisa memilih satu jawaban
    }
  }, { quoted: m });
  if (handler.deleteUserMessage && m.key) {
    await jagoanproject.sendMessage(m.chat, { delete: m.key });
  }
};
handler.help = ["createpolling <pertanyaan>|<opsi1>|<opsi2>|..."];
handler.tags = ["tools"];
handler.command = /^(createpolling|poll|polling|cpoll)$/i;
handler.group = true;
handler.admin = true;
handler.deleteUserMessage = false;
handler.register = true;
handler.limit = true;
var group_polling_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
