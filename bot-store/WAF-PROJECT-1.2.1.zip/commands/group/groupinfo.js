/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - groupinfo.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_groupinfo_exports = {};
__export(group_groupinfo_exports, {
  default: () => group_groupinfo_default
});
module.exports = __toCommonJS(group_groupinfo_exports);
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
let handler = async (m, { jagoanproject, participants, groupMetadata }) => {
  let latestMetadata = groupMetadata || {};
  try {
    const getFreshMetadata = jagoanproject.__groupMetadataOriginal || jagoanproject.groupMetadata;
    const fresh = await getFreshMetadata.call(jagoanproject, m.chat);
    if (fresh) {
      latestMetadata = {
        ...latestMetadata,
        ...fresh,
        desc: fresh.desc ?? latestMetadata.desc,
        participants: Array.isArray(fresh.participants) && fresh.participants.length ? fresh.participants : latestMetadata.participants || participants || []
      };
    }
  } catch {
  }
  participants = Array.isArray(latestMetadata.participants) && latestMetadata.participants.length ? latestMetadata.participants : participants || [];
  groupMetadata = latestMetadata;
  const sewaData = require2("../../database/sewa.json");
  let pp = "./media/avatar_contact.png";
  try {
    pp = await jagoanproject.profilePictureUrl(m.chat, "image");
  } catch (e) {
  }
  let inviteLink = "";
  try {
    inviteLink = await jagoanproject.groupInviteCode(m.chat);
    inviteLink = `https://chat.whatsapp.com/${inviteLink}`;
  } catch (e) {
    inviteLink = "Tidak dapat mengambil link grup (pastikan admin)";
  }
  const groupAdmins = participants.filter((p) => p.admin);
  const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${String(v.phoneNumber || v.jid || v.id || v.lid || "").split("@")[0]}`).join("\n");
  const owner = groupMetadata.owner || m.chat.split`-`[0] + "@s.whatsapp.net";
  let now = /* @__PURE__ */ new Date() * 1;
  let { viewonce, antiSticker, antiBadword, isBanned, welcome, detect, sWelcome, sBye, sPromote, sDemote, antiLink } = global.db.data.chats[m.chat];
  let expired = sewaData[m.chat]?.expired || 0;
  let expiredText = expired - now > 1 ? msToDate(expired - now) : "*TIDAK DI SETEL EXPIRED*";
  let text = `\u{1F423} \u{1D408}\u{1D40D}\u{1D405}\u{1D40E}\u{1D411}\u{1D40C}\u{1D400}\u{1D412}\u{1D408} \u{1D406}\u{1D411}\u{1D40E}\u{1D414}\u{1D40F} \u{1F423}

*ID:* 
${groupMetadata.id}

*NAMA:* 
${groupMetadata.subject}

*DESKRIPSI:* 
${groupMetadata.desc?.toString() || "Tidak ada deskripsi"}

*TOTAL MEMBER:*
${participants.length} Members

*LINK GRUP:*
${inviteLink}

*PEMILIK GROUP:* 
@${owner.split("@")[0]}

*ADMIN GROUP:*
${listAdmin || "Tidak ada admin"}

*EXPIRED:*
${expiredText}

*PENGATURAN GROUP:*
${isBanned ? "\u2705" : "\u274C"} *BANNED*
${welcome ? "\u2705" : "\u274C"} *WELCOME*
${detect ? "\u2705" : "\u274C"} *DETECT*
${antiLink ? "\u2705" : "\u274C"} *ANTILINK*
`.trim();
  let mentionedJid = [.../* @__PURE__ */ new Set([owner, ...groupAdmins.map((v) => v.id)])];
  jagoanproject.sendFile(m.chat, pp, "pp.jpg", text, m, false, {
    contextInfo: {
      mentionedJid,
      extendedPreview: {
        title: groupMetadata.subject,
        body: "Informasi Grup",
        thumbnail: await (await jagoanproject.getFile(pp)).data,
        sourceUrl: inviteLink
      }
    }
  });
};
handler.help = ["infogrup"];
handler.tags = ["group"];
handler.command = /^(gro?upinfo|info(gro?up|gc))$/i;
handler.group = true;
handler.register = true;
handler.limit = true;
var group_groupinfo_default = handler;
function msToDate(ms) {
  let days = Math.floor(ms / (24 * 60 * 60 * 1e3));
  let daysms = ms % (24 * 60 * 60 * 1e3);
  let hours = Math.floor(daysms / (60 * 60 * 1e3));
  let hoursms = ms % (60 * 60 * 1e3);
  let minutes = Math.floor(hoursms / (60 * 1e3));
  return days + " Hari " + hours + " Jam " + minutes + " Menit";
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
