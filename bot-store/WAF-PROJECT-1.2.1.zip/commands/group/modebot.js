/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group -  modebot.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_modebot_exports = {};
__export(group_modebot_exports, {
  default: () => group_modebot_default
});
module.exports = __toCommonJS(group_modebot_exports);
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  let chat = global.db.data.chats[m.chat];
  if (m.isGroup) {
    switch (text) {
      case "off":
      case "mute":
        if (chat.mute) return m.reply("[ NOTICE ] Jagpro telah di mute dan sekarang offline");
        chat.mute = true;
        jagoanproject.reply(m.chat, "S u k s e s", m);
        break;
      case "on":
      case "unmute":
        if (!chat.mute) return m.reply("[ NOTICE ] Jagpro sudah di online kan :)");
        chat.mute = false;
        jagoanproject.reply(m.chat, "S u k s e s", m);
        break;
      default: {
        m.reply(
          `Format Salah!

Contoh:
${usedPrefix + command} on
${usedPrefix + command} off`
        );
      }
    }
  }
};
handler.help = ["botmode"];
handler.tags = ["group"];
handler.command = /^(bot(mode)?)$/i;
handler.group = true;
handler.admin = true;
handler.register = true;
handler.limit = true;
var group_modebot_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
