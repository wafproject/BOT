/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - getpp.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_getpp_exports = {};
__export(group_getpp_exports, {
  default: () => group_getpp_default
});
module.exports = __toCommonJS(group_getpp_exports);
var import_fs = __toESM(require("fs"));
let handler = async (m, { jagoanproject, args }) => {
  try {
    let who;
    if (m.isGroup) {
      if (m.mentionedJid.length > 0) {
        who = m.mentionedJid[0];
      } else if (args[0]) {
        let input = args[0].replace(/[^0-9]/g, "");
        who = input + "@s.whatsapp.net";
      } else {
        return m.reply("\u203C\uFE0F Harap tag pengguna atau masukkan nomornya.\nContoh: .getpp 628xxxxxxxxxx");
      }
    } else {
      if (args[0]) {
        let input = args[0].replace(/[^0-9]/g, "");
        who = input + "@s.whatsapp.net";
      } else {
        who = m.sender;
      }
    }
    let pp = await jagoanproject.profilePictureUrl(who, "image").catch((_) => import_fs.default.readFileSync("./media/avatar_contact.png"));
    await jagoanproject.sendFile(m.chat, pp, "profile.jpg", `@${who.split`@`[0]} keren amat pp lu..`, m, null, { mentions: [who] });
  } catch (e) {
    console.error(e);
    m.reply("\u203C\uFE0F Tidak dapat mengambil foto profile");
  }
};
handler.help = ["getppusr", "getprofileuser"];
handler.tags = ["owner"];
handler.command = /^(get(pp|profile|user))$/i;
handler.limit = true;
handler.register = true;
var group_getpp_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
