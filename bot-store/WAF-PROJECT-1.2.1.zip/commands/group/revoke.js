/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - revoke.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_revoke_exports = {};
__export(group_revoke_exports, {
  default: () => group_revoke_default
});
module.exports = __toCommonJS(group_revoke_exports);
let handler = async (m, { isAdmin, isOwner, jagoanproject, command }) => {
  if (!(isAdmin || isOwner)) {
    global.jpDfail("admin", m, jagoanproject);
    throw false;
  }
  jagoanproject.groupRevokeInvite(m.chat);
  jagoanproject.reply(m.chat, `Sukses ${command} link grup, link telah di kirim ke chat pribadi`, m);
  await delay(1e3);
  let linknya = await jagoanproject.groupInviteCode(m.chat);
  jagoanproject.reply(m.sender, "https://chat.whatsapp.com/" + linknya, m);
};
handler.help = ["revoke"];
handler.tags = ["group"];
handler.command = /^revoke$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
handler.owner = true;
handler.register = true;
handler.limit = true;
var group_revoke_default = handler;
const delay = (time) => new Promise((res) => setTimeout(res, time));

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
