/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - reqfitur.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_reqfitur_exports = {};
__export(group_reqfitur_exports, {
  default: () => group_reqfitur_default
});
module.exports = __toCommonJS(group_reqfitur_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const { generateWAMessageFromContent, proto } = __zapo_1;
const OWNER_NUMBER = "6282252509320";
const WAITING_TTL_MS = 12 * 60 * 60 * 1e3;
const REJECT_REASON_TTL_MS = 3 * 60 * 1e3;
const databaseDir = import_path.default.resolve(__dirname, "../../database");
const dataRequestPath = import_path.default.resolve(databaseDir, "datarequest.json");
const dataAksesPath = import_path.default.resolve(databaseDir, "DataAksesRequest.json");
const dataErrorPath = import_path.default.resolve(databaseDir, "dataError.json");
const waitingDir = import_path.default.resolve(__dirname, "../../database");
const waitingPath = import_path.default.resolve(waitingDir, "waiting room.json");
function ensureDir(dir) {
  if (!import_fs.default.existsSync(dir)) import_fs.default.mkdirSync(dir, { recursive: true });
}
function safeWrite(file, obj) {
  import_fs.default.writeFileSync(file, JSON.stringify(obj, null, 2));
}
function initializeFiles() {
  ensureDir(databaseDir);
  if (!import_fs.default.existsSync(dataRequestPath)) safeWrite(dataRequestPath, { requests: [] });
  if (!import_fs.default.existsSync(dataAksesPath)) safeWrite(dataAksesPath, { groups: [] });
  if (!import_fs.default.existsSync(dataErrorPath)) safeWrite(dataErrorPath, { errors: [] });
  ensureDir(waitingDir);
  if (!import_fs.default.existsSync(waitingPath)) {
    safeWrite(waitingPath, {
      waiting: [],
      rejectReasonSessions: []
    });
  }
}
initializeFiles();
function mentionUser(jid) {
  return `@${jid.split("@")[0]}`;
}
function readJsonSafe(file, fallback) {
  try {
    const raw = import_fs.default.readFileSync(file);
    const data = JSON.parse(raw);
    return data && typeof data === "object" ? data : fallback;
  } catch {
    return fallback;
  }
}
let dataRequest = readJsonSafe(dataRequestPath, { requests: [] });
let dataAkses = readJsonSafe(dataAksesPath, { groups: [] });
let dataError = readJsonSafe(dataErrorPath, { errors: [] });
let waitingRoom = readJsonSafe(waitingPath, { waiting: [], rejectReasonSessions: [] });
if (!Array.isArray(dataRequest.requests)) dataRequest.requests = [];
if (!Array.isArray(dataAkses.groups)) dataAkses.groups = [];
if (!Array.isArray(dataError.errors)) dataError.errors = [];
if (!Array.isArray(waitingRoom.waiting)) waitingRoom.waiting = [];
if (!Array.isArray(waitingRoom.rejectReasonSessions)) waitingRoom.rejectReasonSessions = [];
function saveDataRequest() {
  safeWrite(dataRequestPath, dataRequest);
}
function saveDataAkses() {
  safeWrite(dataAksesPath, dataAkses);
}
function saveDataError() {
  safeWrite(dataErrorPath, dataError);
}
function saveWaitingRoom() {
  safeWrite(waitingPath, waitingRoom);
}
function ownerJid() {
  return `${OWNER_NUMBER}@s.whatsapp.net`;
}
function isGroupAllowed(chatId) {
  return dataAkses.groups.includes(chatId);
}
function parseIdList(input) {
  if (!input) return [];
  const ids = input.split(",").map((s) => s.trim()).filter(Boolean).map((s) => Number(s)).filter((n) => Number.isInteger(n) && n > 0);
  return [...new Set(ids)];
}
function cleanupExpiredWaiting() {
  const now = Date.now();
  const before = waitingRoom.waiting.length;
  waitingRoom.waiting = waitingRoom.waiting.filter((w) => now - (w.createdAt || 0) <= WAITING_TTL_MS);
  const after = waitingRoom.waiting.length;
  if (after !== before) saveWaitingRoom();
}
function cleanupBrokenRejectSessions() {
  const waitingIds = new Set(waitingRoom.waiting.map((w) => w.sessionId));
  const before = waitingRoom.rejectReasonSessions.length;
  waitingRoom.rejectReasonSessions = waitingRoom.rejectReasonSessions.filter((s) => waitingIds.has(s.sessionId));
  if (before !== waitingRoom.rejectReasonSessions.length) saveWaitingRoom();
}
function makeSessionId(m) {
  const base = `${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
  const sender = (m.sender || "").split("@")[0] || "user";
  return `${sender}-${base}`.slice(0, 80);
}
function isOwnerNumber(senderJid) {
  const num = (senderJid || "").split("@")[0];
  return num === OWNER_NUMBER;
}
function getMessageText(m) {
  return (m?.text || m?.body || m?.message?.conversation || m?.message?.extendedTextMessage?.text || m?.message?.imageMessage?.caption || m?.message?.videoMessage?.caption || "").trim();
}
function getWaitingBySessionId(sessionId) {
  return waitingRoom.waiting.find((w) => w.sessionId === sessionId);
}
function getRejectReasonSession(sessionId) {
  return waitingRoom.rejectReasonSessions.find((s) => s.sessionId === sessionId);
}
function removeRejectReasonSession(sessionId) {
  const before = waitingRoom.rejectReasonSessions.length;
  waitingRoom.rejectReasonSessions = waitingRoom.rejectReasonSessions.filter((s) => s.sessionId !== sessionId);
  if (before !== waitingRoom.rejectReasonSessions.length) saveWaitingRoom();
}
const rejectReasonTimers = /* @__PURE__ */ new Map();
function clearRejectReasonTimer(sessionId) {
  const timer = rejectReasonTimers.get(sessionId);
  if (timer) {
    clearTimeout(timer);
    rejectReasonTimers.delete(sessionId);
  }
}
async function sendLihatListButton(jagoanproject, m, caption, listCmd = ".reqlist") {
  const btn = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: "Klik untuk lihat list terbaru" }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "LIHAT LIST",
                    id: listCmd
                  })
                }
              ]
            })
          })
        }
      }
    },
    { userJid: m.chat, quoted: m }
  );
  await jagoanproject.relayMessage(btn.key.remoteJid, btn.message, { messageId: btn.key.id });
}
async function sendOwnerConfirmList(jagoanproject, m, targetJid, sessionId, typeLabel, extraInfo = "") {
  const listMessage = {
    title: "Pilih Aksi Owner",
    sections: [
      {
        title: "Konfirmasi",
        rows: [
          {
            title: "\u2705 Terima",
            id: `.wracc ${sessionId}`,
            description: `Terima ${typeLabel} & masukkan ke list`
          },
          {
            title: "\u274C Tolak",
            id: `.wrrej ${sessionId}`,
            description: `Tolak ${typeLabel} & beri alasan opsional 3 menit`
          }
        ]
      }
    ]
  };
  const msg = generateWAMessageFromContent(
    targetJid,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `\u{1F4E9} *${typeLabel} Masuk (Waiting Room)*

${extraInfo}
*ID Sesi:* ${sessionId}

Pilih aksi di bawah:`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: "Waiting Room (12 Jam)"
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              title: "Owner Confirmation",
              subtitle: "ACC/TOLAK via private chat",
              hasMediaAttachment: false
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify(listMessage)
                }
              ]
            })
          })
        }
      }
    },
    { userJid: targetJid }
  );
  await jagoanproject.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
function buildRejectGroupText(w, reason = "") {
  const tagUser = mentionUser(w.userJid);
  const alasanText = reason ? `

\u2022 Alasan owner: ${reason}` : "\n\n\u2022 Alasan owner: -";
  return {
    text: `\u274C *DITOLAK OWNER*
\u2013 ${w.type === "req" ? "Request" : "Error"} tidak diterima & tidak masuk list.

\u2022 Dari: ${tagUser}
\u2022 Isi: ${w.text}` + alasanText,
    mentions: [w.userJid]
  };
}
async function finalizeRejectSession(jagoanproject, sessionId, reason = "") {
  clearRejectReasonTimer(sessionId);
  const rejectSession = getRejectReasonSession(sessionId);
  const idx = waitingRoom.waiting.findIndex((w2) => w2.sessionId === sessionId);
  removeRejectReasonSession(sessionId);
  if (idx === -1) return false;
  const w = waitingRoom.waiting[idx];
  waitingRoom.waiting.splice(idx, 1);
  saveWaitingRoom();
  await jagoanproject.sendMessage(w.chatId, buildRejectGroupText(w, reason));
  if (rejectSession?.ownerJid) {
    await jagoanproject.sendMessage(rejectSession.ownerJid, {
      text: reason ? `\u2705 Penolakan berhasil dikirim ke grup beserta alasan.

*ID Sesi:* ${sessionId}
*Alasan:* ${reason}` : `\u2705 Penolakan berhasil dikirim ke grup tanpa alasan.

*ID Sesi:* ${sessionId}`
    });
  }
  return true;
}
function startRejectReasonTimer(jagoanproject, sessionId) {
  clearRejectReasonTimer(sessionId);
  const rejectSession = getRejectReasonSession(sessionId);
  if (!rejectSession) return;
  const delay = Math.max(0, (rejectSession.expiresAt || 0) - Date.now());
  const timer = setTimeout(async () => {
    try {
      await finalizeRejectSession(jagoanproject, sessionId, "");
    } catch (e) {
      console.error("Gagal finalisasi penolakan otomatis:", e);
    }
  }, delay);
  rejectReasonTimers.set(sessionId, timer);
}
async function processExpiredRejectSessions(jagoanproject) {
  const now = Date.now();
  const expiredIds = waitingRoom.rejectReasonSessions.filter((s) => (s.expiresAt || 0) <= now).map((s) => s.sessionId);
  for (const sessionId of expiredIds) {
    await finalizeRejectSession(jagoanproject, sessionId, "");
  }
}
const handlerBefore = async (m, { jagoanproject, isOwner }) => {
  cleanupExpiredWaiting();
  cleanupBrokenRejectSessions();
  await processExpiredRejectSessions(jagoanproject);
  if (!(isOwner || isOwnerNumber(m.sender))) return false;
  if (m.isGroup) return false;
  const messageText = getMessageText(m);
  if (!messageText) return false;
  if (messageText.startsWith(".")) return false;
  const now = Date.now();
  const activeSessions = waitingRoom.rejectReasonSessions.filter((s) => s.ownerJid === m.chat && (s.expiresAt || 0) > now).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  if (!activeSessions.length) return false;
  const selectedSession = activeSessions[0];
  await finalizeRejectSession(jagoanproject, selectedSession.sessionId, messageText);
  return true;
};
let handler = async (m, { jagoanproject, text, command, isOwner }) => {
  const Reply = (msg) => jagoanproject.reply(m.chat, msg, m);
  cleanupExpiredWaiting();
  cleanupBrokenRejectSessions();
  await processExpiredRejectSessions(jagoanproject);
  const mess = {
    owner: `\u203C\uFE0F *AKSES DITOLAK*

> Mohon maaf, perintah ini hanya bisa digunakan oleh owner.`
  };
  if (!isOwner && ["aksesreq", "delaksesreq"].includes(command.toLowerCase())) {
    return Reply(mess.owner);
  }
  switch (command.toLowerCase()) {
    case "aksesreq": {
      if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di grup!");
      if (isGroupAllowed(m.chat)) return Reply("\u2705 *Grup ini sudah memiliki akses.*");
      dataAkses.groups.push(m.chat);
      saveDataAkses();
      Reply("\u2705 *Berhasil menambahkan akses untuk grup ini.*");
      break;
    }
    case "delaksesreq": {
      if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di grup!");
      if (!isGroupAllowed(m.chat)) return Reply("\u203C\uFE0F *Grup ini belum memiliki akses.*");
      dataAkses.groups = dataAkses.groups.filter((g) => g !== m.chat);
      saveDataAkses();
      Reply("\u2705 *Berhasil mencabut akses untuk grup ini.*");
      break;
    }
    // =========================
    // REQUEST -> WAITING ROOM
    // =========================
    case "req": {
      if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di grup!");
      if (!isGroupAllowed(m.chat)) {
        return Reply(
          `\u203C\uFE0F *AKSES DITOLAK*

> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.aksesreq*.`
        );
      }
      if (!text) return Reply("\u203C\uFE0F *FORMAT TIDAK LENGKAP*\n\n\u2013 Contoh:\n> .req fitur fake notif dana");
      const requestText = text.trim();
      const username = `@${m.sender.split("@")[0]}`;
      const sessionId = makeSessionId(m);
      waitingRoom.waiting.push({
        sessionId,
        type: "req",
        text: requestText,
        userJid: m.sender,
        username,
        chatId: m.chat,
        createdAt: Date.now()
      });
      saveWaitingRoom();
      await jagoanproject.sendMessage(
        m.chat,
        {
          text: `\u2705 *Request kamu sudah dikirim ke owner (private chat)*
Tunggu ACC/TOLAK.

\u2022 Dari: ${username}
\u2022 Isi: ${requestText}`,
          mentions: [m.sender]
        },
        { quoted: m }
      );
      const extraInfo = `\u2022 Tipe: Request
\u2022 Dari: ${username}
\u2022 Grup: ${m.chat}
\u2022 Isi: ${requestText}`;
      await sendOwnerConfirmList(jagoanproject, m, ownerJid(), sessionId, "Request", extraInfo);
      break;
    }
    // =========================
    // ERROR -> WAITING ROOM
    // =========================
    case "error": {
      if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di grup!");
      if (!isGroupAllowed(m.chat)) {
        return Reply(
          `\u203C\uFE0F *AKSES DITOLAK*

> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.aksesreq*.`
        );
      }
      if (!text) return Reply("\u203C\uFE0F *FORMAT TIDAK LENGKAP*\n\n\u2013 Contoh:\n> .error fitur notif dana gagal kirim");
      const errorText = text.trim();
      const username = `@${m.sender.split("@")[0]}`;
      const sessionId = makeSessionId(m);
      waitingRoom.waiting.push({
        sessionId,
        type: "error",
        text: errorText,
        userJid: m.sender,
        username,
        chatId: m.chat,
        createdAt: Date.now()
      });
      saveWaitingRoom();
      await jagoanproject.sendMessage(
        m.chat,
        {
          text: `\u2705 *Laporan error kamu sudah dikirim ke owner (private chat)*
Tunggu ACC/TOLAK.

\u2022 Dari: ${username}
\u2022 Isi: ${errorText}`,
          mentions: [m.sender]
        },
        { quoted: m }
      );
      const extraInfo = `\u2022 Tipe: Error
\u2022 Dari: ${username}
\u2022 Grup: ${m.chat}
\u2022 Isi: ${errorText}`;
      await sendOwnerConfirmList(jagoanproject, m, ownerJid(), sessionId, "Laporan Error", extraInfo);
      break;
    }
    // =========================
    // OWNER ACCEPT -> PINDAH LIST
    // =========================
    case "wracc": {
      if (!(isOwner || isOwnerNumber(m.sender))) {
        return Reply("\u203C\uFE0F *AKSES DITOLAK*\n\n> Konfirmasi ini khusus owner.");
      }
      const sessionId = (text || "").trim();
      if (!sessionId) return Reply("\u203C\uFE0F *FORMAT SALAH*\n\n\u2013 Contoh:\n> .wracc <sessionId>");
      const idx = waitingRoom.waiting.findIndex((w2) => w2.sessionId === sessionId);
      if (idx === -1) return Reply("\u203C\uFE0F *SESI TIDAK DITEMUKAN / SUDAH EXPIRED*");
      clearRejectReasonTimer(sessionId);
      removeRejectReasonSession(sessionId);
      const w = waitingRoom.waiting[idx];
      if (w.type === "req") {
        dataRequest.requests.push({
          id: dataRequest.requests.length + 1,
          feature: w.text,
          user: w.username
        });
        saveDataRequest();
      } else if (w.type === "error") {
        dataError.errors.push({
          id: dataError.errors.length + 1,
          error: w.text,
          user: w.username
        });
        saveDataError();
      }
      waitingRoom.waiting.splice(idx, 1);
      saveWaitingRoom();
      const tagUser = mentionUser(w.userJid);
      await jagoanproject.sendMessage(w.chatId, {
        text: `\u2705 *DISETUJUI OWNER*
\u2013 ${w.type === "req" ? "Request" : "Error"} berhasil masuk list.

\u2022 Dari: ${tagUser}
\u2022 Isi: ${w.text}`,
        mentions: [w.userJid]
      });
      break;
    }
    // =========================
    // OWNER REJECT -> BUKA SESI ALASAN 3 MENIT
    // =========================
    case "wrrej": {
      if (!(isOwner || isOwnerNumber(m.sender))) {
        return Reply("\u203C\uFE0F *AKSES DITOLAK*\n\n> Konfirmasi ini khusus owner.");
      }
      const sessionId = (text || "").trim();
      if (!sessionId) return Reply("\u203C\uFE0F *FORMAT SALAH*\n\n\u2013 Contoh:\n> .wrrej <sessionId>");
      const waitingData = getWaitingBySessionId(sessionId);
      if (!waitingData) return Reply("\u203C\uFE0F *SESI TIDAK DITEMUKAN / SUDAH EXPIRED*");
      clearRejectReasonTimer(sessionId);
      removeRejectReasonSession(sessionId);
      waitingRoom.rejectReasonSessions.push({
        sessionId,
        ownerJid: m.chat,
        createdAt: Date.now(),
        expiresAt: Date.now() + REJECT_REASON_TTL_MS
      });
      saveWaitingRoom();
      startRejectReasonTimer(jagoanproject, sessionId);
      await jagoanproject.sendMessage(m.chat, {
        text: `\u274C *MODE ALASAN PENOLAKAN AKTIF*

*ID Sesi:* ${sessionId}
Silakan kirim *1 pesan teks* berisi alasan penolakan dalam waktu *3 menit*.

Jika tidak mengirim alasan sampai waktu habis, bot akan otomatis mengirim penolakan ke grup *tanpa alasan*.`
      });
      break;
    }
    // =========================
    // LIST FINAL (DB)
    // =========================
    case "reqlist": {
      if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di grup!");
      if (!isGroupAllowed(m.chat)) {
        return Reply(
          `\u203C\uFE0F *AKSES DITOLAK*

> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.aksesreq*.`
        );
      }
      let listText = "*\u203C\uFE0F REQUEST FITUR DAN LAPOR ERROR*\n\n";
      listText += "*REQUEST FITUR :*\n\n";
      if (dataRequest.requests.length === 0) {
        listText += "tidak ada request fitur saat ini.\n";
      } else {
        dataRequest.requests.forEach((req) => {
          listText += `${req.id}. ${req.feature} ${req.user}
`;
        });
      }
      listText += "\n*FITUR ERROR :*\n\n";
      if (dataError.errors.length === 0) {
        listText += "tidak ada laporan error saat ini.\n";
      } else {
        dataError.errors.forEach((err) => {
          listText += `${err.id}. ${err.error} ${err.user}
`;
        });
      }
      Reply(listText);
      break;
    }
    // =========================
    // DELETE REQUEST
    // =========================
    case "delreq": {
      if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di grup!");
      if (!isGroupAllowed(m.chat)) {
        return Reply(`\u203C\uFE0F *AKSES DITOLAK*

> Grup ini belum memiliki aksesreq, minta pada owner untuk menambahkan akses grup dengan *.aksesreq*.`);
      }
      if (!text) return Reply("\u203C\uFE0F *FORMAT TIDAK LENGKAP*\n\n\u2013 Contoh:\n> .delreq 1\n> .delreq 2,4,5,3");
      const ids = parseIdList(text);
      if (ids.length === 0) return Reply("\u203C\uFE0F *FORMAT SALAH*\n\n\u2013 Gunakan angka, pisahkan dengan koma.\n> .delreq 2,4,5");
      const idSet = new Set(ids);
      const removed = dataRequest.requests.filter((r) => idSet.has(r.id));
      if (removed.length === 0) return Reply(`\u203C\uFE0F Tidak ada request dengan ID: ${ids.join(", ")} yang ditemukan.`);
      dataRequest.requests = dataRequest.requests.filter((r) => !idSet.has(r.id));
      dataRequest.requests.forEach((req, i) => req.id = i + 1);
      saveDataRequest();
      const removedNames = removed.map((r) => `\u2022 ${r.feature} ${r.user}`).join("\n");
      const caption = `\u2705 *Berhasil hapus ${removed.length} request.*

*Yang terhapus:*
${removedNames}`;
      await sendLihatListButton(jagoanproject, m, caption);
      break;
    }
    // =========================
    // DELETE ERROR
    // =========================
    case "delerror": {
      if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di grup!");
      if (!isOwnerNumber(m.sender)) return Reply("Khusus owner!");
      if (!isGroupAllowed(m.chat)) {
        return Reply(
          `\u203C\uFE0F *AKSES DITOLAK*

> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.aksesreq*.`
        );
      }
      if (!text) return Reply("\u203C\uFE0F *FORMAT TIDAK LENGKAP*\n\n\u2013 Contoh:\n> .delerror 1\n> .delerror 2,4,5\n> .delerror all");
      let removed = [];
      if (text.trim().toLowerCase() === "all") {
        removed = dataError.errors.splice(0, dataError.errors.length);
        saveDataError();
        if (!removed.length) return Reply("Tidak ada error yang dihapus.");
        const removedNames2 = removed.map((e) => `\u2022 ${e.error} ${e.user}`).join("\n");
        const caption2 = `\u2705 *Berhasil hapus ${removed.length} error.*

*Yang terhapus:*
${removedNames2}`;
        await sendLihatListButton(jagoanproject, m, caption2, ".reqlist");
        break;
      }
      const ids = parseIdList(text);
      if (ids.length === 0) return Reply("\u203C\uFE0F *FORMAT SALAH*\n\n\u2013 Gunakan angka, pisahkan dengan koma.\n> .delerror 2,4,5");
      const idSet = new Set(ids);
      removed = dataError.errors.filter((e) => idSet.has(e.id));
      if (removed.length === 0) return Reply(`\u203C\uFE0F Tidak ada error dengan ID: ${ids.join(", ")} yang ditemukan.`);
      dataError.errors = dataError.errors.filter((e) => !idSet.has(e.id));
      dataError.errors.forEach((e, i) => e.id = i + 1);
      saveDataError();
      const removedNames = removed.map((e) => `\u2022 ${e.error} ${e.user}`).join("\n");
      const caption = `\u2705 *Berhasil hapus ${removed.length} error.*

*Yang terhapus:*
${removedNames}`;
      await sendLihatListButton(jagoanproject, m, caption, ".reqlist");
      break;
    }
    default:
      Reply("Perintah tidak dikenali.");
      break;
  }
};
handler.help = [
  "aksesreq",
  "delaksesreq",
  "req <teks>",
  "error <teks>",
  "wracc <sessionId> (owner)",
  "wrrej <sessionId> (owner)",
  "reqlist",
  "delreq <nomor / nomor,nomor,...>",
  "delerror <nomor / nomor,nomor,...>"
];
handler.before = handlerBefore;
handler.tags = ["group"];
handler.command = /^(aksesreq|delaksesreq|req|error|wracc|wrrej|reqlist|delreq|delerror)$/i;
handler.group = false;
handler.register = false;
handler.limit = false;
var group_reqfitur_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
