/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - listonline.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_listonline_exports = {};
__export(group_listonline_exports, {
  default: () => group_listonline_default
});
module.exports = __toCommonJS(group_listonline_exports);
var import_jid = require("../../lib/jagoan/function/jid.js");
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const ACTIVE_PRESENCE = /* @__PURE__ */ new Set(["available", "online", "composing", "recording", "paused"]);
const OFFLINE_PRESENCE = /* @__PURE__ */ new Set(["unavailable", "offline"]);
function participantAliases(participant = {}) {
  return [...new Set([
    typeof participant === "string" ? participant : null,
    participant?.phoneNumber,
    participant?.phoneJid,
    participant?.pn,
    participant?.pnJid,
    participant?.participantAlt,
    participant?.remoteJidAlt,
    participant?.jid,
    participant?.id,
    participant?.participant,
    participant?.user,
    participant?.lid,
    participant?.lidJid
  ].map(import_jid.normalizeJid).filter(Boolean))];
}
function participantPhoneJid(participant = {}) {
  return participantAliases(participant).find(import_jid.isPhoneJid) || null;
}
function getPresenceStatus(value) {
  if (value == null) return "";
  if (typeof value === "string") return value.toLowerCase();
  if (value?.online === true) return "online";
  if (value?.unavailable === true) return "unavailable";
  if (value?.unavailable === false && value?.lastSeen == null) return "available";
  return String(
    value?.type ?? value?.lastKnownPresence ?? value?.presence ?? value?.state ?? value?.status ?? ""
  ).toLowerCase();
}
function isPresenceOnline(value) {
  const status = getPresenceStatus(value);
  if (OFFLINE_PRESENCE.has(status)) return false;
  return ACTIVE_PRESENCE.has(status);
}
function addPresenceEntries(targetMap, update = {}) {
  const entries = Object.entries(update?.presences || {});
  const commonStatus = getPresenceStatus(update);
  if (entries.length) {
    for (const [jid, rawData] of entries) {
      const normalized = (0, import_jid.normalizeJid)(jid);
      if (!normalized) continue;
      const data = rawData && typeof rawData === "object" ? { ...rawData } : { lastKnownPresence: rawData };
      if (!getPresenceStatus(data) && commonStatus) data.lastKnownPresence = commonStatus;
      data.updatedAt = Number(data.updatedAt || Date.now());
      targetMap.set(normalized, data);
    }
  }
  const rawEvent = update?.raw || update;
  const aliases = [
    update?.participant,
    rawEvent?.participantJid,
    rawEvent?.jid,
    rawEvent?.fromJid,
    rawEvent?.from,
    rawEvent?.userJid,
    rawEvent?.pnJid,
    rawEvent?.phoneNumber,
    rawEvent?.lidJid
  ].map(import_jid.normalizeJid).filter(Boolean);
  for (const jid of new Set(aliases)) {
    if (targetMap.has(jid)) continue;
    targetMap.set(jid, {
      ...rawEvent && typeof rawEvent === "object" ? rawEvent : {},
      lastKnownPresence: commonStatus || getPresenceStatus(rawEvent),
      updatedAt: Date.now()
    });
  }
}
async function subscribePresenceSnapshot(jagoanproject, metadata) {
  const snapshot = /* @__PURE__ */ new Map();
  if (typeof jagoanproject.presenceSubscribe !== "function") return snapshot;
  const participants = Array.isArray(metadata?.participants) ? metadata.participants : [];
  const subscribeTargets = [];
  for (const participant of participants) {
    for (const alias of participantAliases(participant)) {
      if (alias && !alias.endsWith("@g.us")) subscribeTargets.push(alias);
    }
  }
  const uniqueTargets = [...new Set(subscribeTargets)];
  if (!uniqueTargets.length) return snapshot;
  const onPresence = (update) => addPresenceEntries(snapshot, update);
  jagoanproject.ev?.on?.("presence.update", onPresence);
  let announcedAvailable = false;
  try {
    if (typeof jagoanproject.sendPresenceUpdate === "function") {
      await jagoanproject.sendPresenceUpdate("available").catch(() => null);
      announcedAvailable = true;
      await sleep(120);
    }
    for (let i = 0; i < uniqueTargets.length; i += 15) {
      const batch = uniqueTargets.slice(i, i + 15);
      await Promise.allSettled(batch.map((jid) => jagoanproject.presenceSubscribe(jid)));
      if (i + 15 < uniqueTargets.length) await sleep(100);
    }
    await sleep(uniqueTargets.length <= 30 ? 2200 : 3e3);
  } finally {
    if (typeof jagoanproject.ev?.off === "function") jagoanproject.ev.off("presence.update", onPresence);
    else jagoanproject.ev?.removeListener?.("presence.update", onPresence);
    if (announcedAvailable && typeof jagoanproject.sendPresenceUpdate === "function") {
      await jagoanproject.sendPresenceUpdate("unavailable").catch(() => null);
    }
  }
  return snapshot;
}
function readFreshCachedPresence(groupStore, aliases, maxAge = 45e3) {
  const presences = groupStore?.presences;
  if (!presences || typeof presences !== "object" || Array.isArray(presences)) return null;
  for (const alias of aliases) {
    const value = presences[alias];
    if (!value) continue;
    const updatedAt = Number(value?.updatedAt || 0);
    if (updatedAt && Date.now() - updatedAt > maxAge) continue;
    return value;
  }
  return null;
}
async function makeOnlineRow(jagoanproject, id, metadata, participant, canonicalHint = null) {
  const aliases = participantAliases(participant);
  const altPhone = participantPhoneJid(participant);
  const rawJid = aliases[0] || altPhone;
  if (!rawJid) return null;
  const canonical = canonicalHint || await (0, import_jid.resolveJid)(jagoanproject, rawJid, {
    groupJid: id,
    groupMetadata: metadata,
    altJid: altPhone
  }).catch(() => null);
  const phoneJid = (0, import_jid.isPhoneJid)(canonical) ? canonical : altPhone || null;
  const mentionJid = await (0, import_jid.resolveMentionJid)(jagoanproject, rawJid, {
    groupJid: id,
    groupMetadata: metadata,
    altJid: phoneJid
  }).catch(() => phoneJid || canonical || rawJid);
  const number = (0, import_jid.jidToNumber)(phoneJid || canonical || mentionJid);
  let label = number ? `@${number}` : "";
  if (!label) {
    const nameTarget = canonical || mentionJid || rawJid;
    const name = await jagoanproject.getNameAsync?.(nameTarget, false, {
      groupJid: id,
      groupMetadata: metadata
    }).catch?.(() => "") || "";
    label = String(name || "User").trim();
  }
  return {
    key: number || (0, import_jid.normalizeJid)(phoneJid || mentionJid || canonical || rawJid),
    label,
    number,
    mentionJid: mentionJid || phoneJid || canonical || rawJid
  };
}
let handler = async (m, { jagoanproject, args }) => {
  try {
    const id = args?.[0]?.match(/\d+\-\d+@g\.us/)?.[0] || m.chat;
    const metadata = await jagoanproject.groupMetadata(id).catch(() => jagoanproject.chats?.[id]?.metadata || null);
    if (!metadata || !Array.isArray(metadata.participants)) {
      throw new Error("Metadata grup tidak tersedia");
    }
    const groupStore = jagoanproject.chats?.[id] || {};
    const liveSnapshot = await subscribePresenceSnapshot(jagoanproject, metadata);
    const rows = [];
    for (const participant of metadata.participants) {
      const aliases = participantAliases(participant);
      if (!aliases.length) continue;
      let presence = null;
      let gotLiveSnapshot = false;
      for (const alias of aliases) {
        if (!liveSnapshot.has(alias)) continue;
        presence = liveSnapshot.get(alias);
        gotLiveSnapshot = true;
        break;
      }
      if (!gotLiveSnapshot) presence = readFreshCachedPresence(groupStore, aliases);
      if (!isPresenceOnline(presence)) continue;
      const row = await makeOnlineRow(jagoanproject, id, metadata, participant);
      if (!row?.key || rows.some((item) => item.key === row.key)) continue;
      rows.push(row);
    }
    rows.sort((a, b) => {
      if (a.number && b.number) return a.number.localeCompare(b.number, "id", { numeric: true });
      if (a.number) return -1;
      if (b.number) return 1;
      return a.label.localeCompare(b.label, "id");
    });
    const onlineList = rows.length ? rows.map((item, index) => `*${index + 1}.* ${item.label}`).join("\n") : "Tidak ada member yang terdeteksi online saat snapshot diambil.";
    const mentionedJid = [...new Set(rows.filter((item) => item.number).map((item) => item.mentionJid).filter(Boolean))];
    await jagoanproject.reply(m.chat, `*\u{1F465} List Online Users:*
${onlineList}`, m, {
      mentions: mentionedJid,
      contextInfo: { mentionedJid }
    });
  } catch (e) {
    console.error("[LISTONLINE]", e);
    await m.reply?.(`\u274C Gagal mengambil presence grup: ${e?.message || e}`);
  }
};
handler.help = ["listonline"].map((a) => a + " *[view status online]*");
handler.tags = ["group"];
handler.command = /^(liston(line)?)/i;
handler.group = true;
handler.register = true;
handler.limit = true;
var group_listonline_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
