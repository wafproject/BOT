/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/group/group - cekasalmember.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var group_cekasalmember_exports = {};
__export(group_cekasalmember_exports, {
  default: () => group_cekasalmember_default
});
module.exports = __toCommonJS(group_cekasalmember_exports);
let handler = async (m, { participants = [] }) => {
  let countIndonesia = 0;
  let countMalaysia = 0;
  let countUSA = 0;
  let countOther = 0;
  participants.forEach((participant) => {
    const phoneNumber = String(participant.jid || participant.id || "").split("@")[0];
    if (phoneNumber.startsWith("62")) countIndonesia++;
    else if (phoneNumber.startsWith("60")) countMalaysia++;
    else if (phoneNumber.startsWith("1")) countUSA++;
    else countOther++;
  });
  const replyMessage = `Jumlah Anggota Grup Berdasarkan Negara:

\u{1F1EE}\u{1F1E9} Indonesia: ${countIndonesia}
\u{1F1F2}\u{1F1FE} Malaysia: ${countMalaysia}
\u{1F1FA}\u{1F1F8} USA: ${countUSA}
\u{1F3F3}\uFE0F Lainnya: ${countOther}`;
  m.reply(replyMessage);
};
handler.tags = ["group"];
handler.help = ["cekasalmember"];
handler.command = ["cekasalmember"];
handler.group = true;
handler.register = true;
handler.limit = true;
var group_cekasalmember_default = handler;
handler.all = async (m, { jagoanproject, participants = [] }) => {
  let text = m.text?.trim();
  if (!text) return;
  if (text.toLowerCase().startsWith("cekasalmember")) {
    let isi = text.slice(13).trim();
    if (!isi) {
      if (m.quoted?.text || m.quoted?.caption || m.quoted?.description) isi = m.quoted.text || m.quoted.caption || m.quoted.description;
      else return m.reply(`*\u{1F4DD} CONTOH :*

\u2014 cekasalmember <teks>`);
    }
    let fakeCmd = { ...m, text: isi };
    return handler(fakeCmd, { jagoanproject, participants, args: [], text: fakeCmd.text, usedPrefix: "", command: "cekasalmember" });
  }
};

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "group" }
)
