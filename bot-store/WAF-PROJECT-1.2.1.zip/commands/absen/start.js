/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/absen/absen - start.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var absen_start_exports = {};
__export(absen_start_exports, {
  default: () => absen_start_default
});
module.exports = __toCommonJS(absen_start_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = import_path.default.dirname(__filename);
const ABSEN_DB_DIR = import_path.default.resolve(__dirname, "../../database");
const ABSEN_DB_FILE = import_path.default.join(ABSEN_DB_DIR, "absen.json");
function ensureAbsenDbDir() {
  if (!import_fs.default.existsSync(ABSEN_DB_DIR)) import_fs.default.mkdirSync(ABSEN_DB_DIR, { recursive: true });
}
function serializeAbsenState(state = {}) {
  let out = {};
  for (let [chatId, value] of Object.entries(state || {})) {
    if (!Array.isArray(value)) continue;
    out[chatId] = {
      entries: Array.isArray(value[1]) ? value[1] : [],
      text: value[2] || ""
    };
  }
  return out;
}
function loadAbsenState() {
  ensureAbsenDbDir();
  if (!import_fs.default.existsSync(ABSEN_DB_FILE)) return {};
  try {
    let raw = import_fs.default.readFileSync(ABSEN_DB_FILE, "utf8");
    if (!raw.trim()) return {};
    let json = JSON.parse(raw);
    let out = {};
    for (let [chatId, value] of Object.entries(json || {})) {
      out[chatId] = [null, Array.isArray(value?.entries) ? value.entries : [], value?.text || ""];
    }
    return out;
  } catch {
    return {};
  }
}
function syncAbsenState() {
  jagoanproject.absen = {
    ...loadAbsenState(),
    ...jagoanproject.absen || {}
  };
}
function saveAbsenState() {
  ensureAbsenDbDir();
  import_fs.default.writeFileSync(ABSEN_DB_FILE, JSON.stringify(serializeAbsenState(jagoanproject.absen), null, 2));
}
let handler = async (m, { usedPrefix, text }) => {
  syncAbsenState();
  let id = m.chat;
  if (id in jagoanproject.absen) {
    throw `_*Masih ada absen di chat ini!*_

*${usedPrefix}hapusabsen* - untuk menghapus absen`;
  }
  jagoanproject.absen[id] = [
    null,
    [],
    text || ""
  ];
  saveAbsenState();
  m.reply(`Berhasil memulai absen!

*${usedPrefix}absen* - untuk absen
*${usedPrefix}cekabsen* - untuk mengecek absen
*${usedPrefix}hapusabsen* - untuk menghapus data absen`);
};
handler.help = ["mulaiabsen"];
handler.tags = ["absen"];
handler.command = /^(start|mulai)absen$/i;
handler.group = true;
handler.admin = true;
handler.register = true;
handler.limit = true;
var absen_start_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "absen" }
)
