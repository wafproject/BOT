/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/absen/absen - absen.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var absen_absen_exports = {};
__export(absen_absen_exports, {
  default: () => absen_absen_default
});
module.exports = __toCommonJS(absen_absen_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = import_path.default.dirname(__filename);
const ABSEN_DB_DIR = import_path.default.resolve(__dirname, "../../database");
const ABSEN_DB_FILE = import_path.default.join(ABSEN_DB_DIR, "absen.json");
function ensureAbsenDbDir() {
  if (!import_fs.default.existsSync(ABSEN_DB_DIR)) import_fs.default.mkdirSync(ABSEN_DB_DIR, { recursive: true });
}
function serializeAbsenState(state = {}) {
  let out = {};
  for (let [chatId, value] of Object.entries(state || {})) {
    if (!Array.isArray(value)) continue;
    out[chatId] = {
      entries: Array.isArray(value[1]) ? value[1] : [],
      text: value[2] || ""
    };
  }
  return out;
}
function loadAbsenState() {
  ensureAbsenDbDir();
  if (!import_fs.default.existsSync(ABSEN_DB_FILE)) return {};
  try {
    let raw = import_fs.default.readFileSync(ABSEN_DB_FILE, "utf8");
    if (!raw.trim()) return {};
    let json = JSON.parse(raw);
    let out = {};
    for (let [chatId, value] of Object.entries(json || {})) {
      out[chatId] = [null, Array.isArray(value?.entries) ? value.entries : [], value?.text || ""];
    }
    return out;
  } catch {
    return {};
  }
}
function syncAbsenState() {
  jagoanproject.absen = {
    ...loadAbsenState(),
    ...jagoanproject.absen || {}
  };
}
function saveAbsenState() {
  ensureAbsenDbDir();
  import_fs.default.writeFileSync(ABSEN_DB_FILE, JSON.stringify(serializeAbsenState(jagoanproject.absen), null, 2));
}
let handler = async (m, { usedPrefix, text }) => {
  let id = m.chat;
  syncAbsenState();
  if (!(id in jagoanproject.absen)) {
    throw `_*Tidak ada absen berlangsung di grup ini!*_

Ketik *${usedPrefix}mulaiabsen* untuk memulai absen`;
  }
  const normalizeJid = (jid = "") => {
    if (!jid) return "";
    const [left, right] = jid.split("@");
    if (!right) return jid;
    const u = (left.split(":")[0] || "").trim();
    return `${u}@${right}`;
  };
  const participantCandidates = (p = {}) => {
    const arr = [];
    if (typeof p === "string") arr.push(p);
    if (p && typeof p.id === "string") arr.push(p.id);
    if (p && typeof p.jid === "string") arr.push(p.jid);
    if (p && typeof p.participant === "string") arr.push(p.participant);
    if (p && typeof p.user === "string") arr.push(p.user);
    if (p && typeof p.lid === "string") arr.push(p.lid);
    if (p && typeof p.pn === "string") arr.push(p.pn);
    return arr.filter(Boolean).map(normalizeJid);
  };
  let metadata = await jagoanproject.groupMetadata(m.chat);
  let senderNorm = normalizeJid(m.sender);
  let matched = metadata.participants.find((p) => {
    const cands = participantCandidates(p);
    return cands.includes(senderNorm);
  });
  let key = matched ? normalizeJid(matched.id || senderNorm) : senderNorm;
  let absen = jagoanproject.absen[id][1];
  if (absen.some((x) => normalizeJid(x.key || x.sender) === key)) {
    let buttonMessage = {
      text: `_*Anda sudah absen!*_ Klik tombol di bawah untuk mengecek daftar absen.`,
      footer: `_${namebot}_`,
      buttons: [
        { buttonId: `${usedPrefix}cekabsen`, buttonText: { displayText: "Cek Absen" }, type: 1 }
      ],
      headerType: 4
    };
    await jagoanproject.sendMessage(m.chat, buttonMessage, { quoted: m });
    return;
  }
  let names = (text || "").split(",").map((v) => v.trim()).filter(Boolean);
  if (!names.length) names = [m.pushName || "Tanpa Nama"];
  names.forEach((name) => {
    absen.push({
      sender: senderNorm,
      key,
      name
    });
  });
  saveAbsenState();
  let d = /* @__PURE__ */ new Date();
  let date = d.toLocaleDateString("id", { day: "numeric", month: "long", year: "numeric" });
  let list = absen.map((p, index) => {
    let jid = normalizeJid(p.key || p.sender);
    return `\u2502 ${index + 1}. @${jid.split("@")[0]}`;
  }).join("\n");
  let mentions = [...new Set(absen.map((x) => normalizeJid(x.key || x.sender)))];
  await jagoanproject.sendMessage(m.chat, {
    text: `*\u300C ABSEN \u300D*

Tanggal: ${date}

${jagoanproject.absen[id][2] || ""}

\u250C *Yang sudah absen:*
\u2502
\u2502 Total: ${absen.length}
${list || "\u2502 -"}
\u2502
\u2514\u2500\u2500\u2500\u2500

_${namebot}_`,
    mentions
  }, { quoted: m });
};
handler.help = ["absen nama"];
handler.tags = ["absen"];
handler.command = /^(absen|hadir)$/i;
handler.group = true;
handler.register = false;
handler.limit = true;
var absen_absen_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "absen" }
)
