/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/absen/absen - cutabsen.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var absen_cutabsen_exports = {};
__export(absen_cutabsen_exports, {
  default: () => absen_cutabsen_default
});
module.exports = __toCommonJS(absen_cutabsen_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = import_path.default.dirname(__filename);
const ABSEN_DB_DIR = import_path.default.resolve(__dirname, "../../database");
const ABSEN_DB_FILE = import_path.default.join(ABSEN_DB_DIR, "absen.json");
function ensureAbsenDbDir() {
  if (!import_fs.default.existsSync(ABSEN_DB_DIR)) import_fs.default.mkdirSync(ABSEN_DB_DIR, { recursive: true });
}
function serializeAbsenState(state = {}) {
  let out = {};
  for (let [chatId, value] of Object.entries(state || {})) {
    if (!Array.isArray(value)) continue;
    out[chatId] = {
      entries: Array.isArray(value[1]) ? value[1] : [],
      text: value[2] || ""
    };
  }
  return out;
}
function loadAbsenState() {
  ensureAbsenDbDir();
  if (!import_fs.default.existsSync(ABSEN_DB_FILE)) return {};
  try {
    let raw = import_fs.default.readFileSync(ABSEN_DB_FILE, "utf8");
    if (!raw.trim()) return {};
    let json = JSON.parse(raw);
    let out = {};
    for (let [chatId, value] of Object.entries(json || {})) {
      out[chatId] = [null, Array.isArray(value?.entries) ? value.entries : [], value?.text || ""];
    }
    return out;
  } catch {
    return {};
  }
}
function syncAbsenState() {
  jagoanproject.absen = {
    ...loadAbsenState(),
    ...jagoanproject.absen || {}
  };
}
function saveAbsenState() {
  ensureAbsenDbDir();
  import_fs.default.writeFileSync(ABSEN_DB_FILE, JSON.stringify(serializeAbsenState(jagoanproject.absen), null, 2));
}
let handler = async (m, { usedPrefix, command, text }) => {
  let id = m.chat;
  syncAbsenState();
  if (!text) return m.reply(
    `\u26A0\uFE0F *Format Salah!*

> Penggunaan: ${usedPrefix}${command} (nama atau nomor urut)

\u{1F4A1} Contoh:
> ${usedPrefix}${command} Budi
> ${usedPrefix}${command} 1`
  );
  if (!(id in jagoanproject.absen)) {
    throw `_*Tidak ada absen berlangsung di grup ini!*_

Ketik *${usedPrefix}mulaiabsen* untuk memulai absen`;
  }
  let absen = jagoanproject.absen[id][1];
  let input = text.trim();
  let indexToRemove = -1;
  let removedEntry = null;
  if (/^\d+$/.test(input)) {
    let number = parseInt(input) - 1;
    if (number >= 0 && number < absen.length) {
      indexToRemove = number;
      removedEntry = absen.splice(indexToRemove, 1)[0];
      saveAbsenState();
      m.reply(`Nama ${removedEntry.name} (nomor ${number + 1}) berhasil dihapus dari daftar absen.`);
    } else {
      m.reply(`Nomor ${input} tidak valid. Pastikan nomor urut antara 1 dan ${absen.length}.`);
    }
  } else {
    indexToRemove = absen.findIndex((participant) => participant.name.toLowerCase() === input.toLowerCase());
    if (indexToRemove !== -1) {
      removedEntry = absen.splice(indexToRemove, 1)[0];
      saveAbsenState();
      m.reply(`Nama ${removedEntry.name} (nomor ${indexToRemove + 1}) berhasil dihapus dari daftar absen.`);
    } else {
      m.reply(`Nama ${input} tidak ditemukan dalam daftar absen.`);
    }
  }
};
handler.help = ["cutabsen [nama atau nomor urut]"];
handler.tags = ["absen"];
handler.command = /^(rmabsen|cutabsen|cabsen)$/i;
handler.group = true;
handler.register = true;
handler.limit = true;
var absen_cutabsen_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "absen" }
)
