/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekpacar.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekpacar_exports = {};
__export(cek_cekpacar_exports, {
  default: () => cek_cekpacar_default
});
module.exports = __toCommonJS(cek_cekpacar_exports);
let handler = async (m, { jagoanproject, participants, groupMetadata }) => {
  if (!m.isGroup) {
    return m.reply("Fitur ini hanya bisa dipakai di grup");
  }
  const members = participants.map((v) => v.id).filter((id) => id && id !== jagoanproject.user.jid);
  if (members.length < 2) {
    return m.reply("Member grup tidak cukup untuk cek pacar");
  }
  const orang = members[Math.floor(Math.random() * members.length)];
  let pasangan = members[Math.floor(Math.random() * members.length)];
  while (pasangan === orang && members.length > 1) {
    pasangan = members[Math.floor(Math.random() * members.length)];
  }
  const namaGrup = groupMetadata?.subject || "grup ini";
  const teks = `\u{1F498} *CEK PACAR*

Di ${namaGrup}, pasangan yang paling cocok adalah:

@${orang.split("@")[0]} \u2764\uFE0F @${pasangan.split("@")[0]}

Ciee cocok banget \u{1F970}`;
  await jagoanproject.reply(m.chat, teks, m, {
    mentions: [orang, pasangan]
  });
};
handler.help = ["cekpacar"];
handler.tags = ["cek"];
handler.command = /^cekpacar$/i;
handler.group = true;
handler.register = true;
var cek_cekpacar_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
