/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekall.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekall_exports = {};
__export(cek_cekall_exports, {
  default: () => cek_cekall_default
});
module.exports = __toCommonJS(cek_cekall_exports);
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const PhoneNumber = require2("awesome-phonenumber");
const fetch = require2("node-fetch");
let handler = async (m, { jagoanproject, text, command }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? jagoanproject.user.jid : m.sender;
  let name = jagoanproject.getName(who);
  switch (command) {
    case "goblokcek":
    case "jelekcek":
    case "gaycek":
    case "rate":
    case "lesbicek":
    case "gantengcek":
    case "cantikcek":
    case "begocek":
    case "suhucek":
    case "pintercek":
    case "jagocek":
    case "nolepcek":
    case "babicek":
    case "bebancek":
    case "baikcek":
    case "jahatcek":
    case "anjingcek":
    case "haramcek":
    case "pakboycek":
    case "pakgirlcek":
    case "sangecek":
    case "bapercek":
    case "fakboycek":
    case "alimcek":
    case "suhucek":
    case "fakgirlcek":
    case "kerencek":
    case "wibucek":
    case "pasarkascek":
    case "kulcek":
    case "cekgoblok":
    case "cekjelek":
    case "cekgay":
    case "ceklesbi":
    case "cekganteng":
    case "cekcantik":
    case "cekbego":
    case "ceksuhu":
    case "cekpinter":
    case "cekjago":
    case "ceknolep":
    case "cekbabi":
    case "cekbeban":
    case "cekbaik":
    case "cekjahat":
    case "cekanjing":
    case "cekharam":
    case "cekpakboy":
    case "cekpakgirl":
    case "ceksange":
    case "cekbaper":
    case "cekfakboy":
    case "cekalim":
    case "ceksuhu":
    case "cekfakgirl":
    case "cekkeren":
    case "cekwibu":
    case "cekpasarkas":
    case "cekkul": {
      const cek2 = cek1[Math.floor(Math.random() * cek1.length)];
      jagoanproject.sendMessage(m.chat, { text: "Pertanyaan : *" + command + `*
Nama : @${m.sender.split("@")[0]}
Jawaban : ` + cek2 + "%", mentions: [m.sender] }, { quoted: m });
      break;
    }
  }
};
handler.tags = ["cek"];
handler.help = handler.command = [
  "goblokcek",
  "jelekcek",
  "gaycek",
  "rate",
  "lesbicek",
  "gantengcek",
  "cantikcek",
  "begocek",
  "suhucek",
  "pintercek",
  "jagocek",
  "nolepcek",
  "babicek",
  "bebancek",
  "baikcek",
  "jahatcek",
  "anjingcek",
  "haramcek",
  "pakboycek",
  "pakgirlcek",
  "sangecek",
  "bapercek",
  "fakboycek",
  "alimcek",
  "suhucek",
  "fakgirlcek",
  "kerencek",
  "wibucek",
  "pasarkascek",
  "kulcek",
  "cekgoblok",
  "cekjelek",
  "cekgay",
  "ceklesbi",
  "cekbego",
  "ceksuhu",
  "cekjago",
  "cekbabi",
  "cekbeban",
  "cekbaik",
  "cekjahat",
  "cekanjing",
  "cekharam",
  "cekpakboy",
  "cekpakgirl",
  "cekbaper",
  "cekfakboy",
  "cekalim",
  "ceksuhu",
  "cekfakgirl",
  "cekpasarkas",
  "cekkul"
];
handler.register = true;
handler.limit = true;
var cek_cekall_default = handler;
global.cek1 = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100"];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
