/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekumur.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekumur_exports = {};
__export(cek_cekumur_exports, {
  default: () => cek_cekumur_default
});
module.exports = __toCommonJS(cek_cekumur_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.umur)}\u201D`, m);
};
handler.help = ["cekumur"];
handler.tags = ["cek"];
handler.command = /^(cekumur)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cekumur_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.umur = [
  "10 Tahun (Buset Bocil)",
  "1 Tahun (Bisa Main Hp Lu? \u2620\uFE0F)",
  "5 Tahun (apa ya nama nya kalo 5 tahun, Batista? Ehh Balita)",
  "8 Tahun (Aduh anak kemarin sore udah bisa main hp aja nih\u{1F602})",
  "12 Tahun (Masih SD Udah Mau Masuk SMP)",
  "13 Tahun (diem dulu, anak esempeh satu ini sedang memasuki fase pahitnya kehidupan)",
  "15 Tahun (udah mau tamat esempeh)",
  "17 Tahun (cieee dah punya KTP, jangan di pake pinjol \u{1F602})",
  "20 Tahun (cok kapan nikah?)",
  "21 Tahun (yakin belum mau nikah?)",
  "22 Tahun (umur yang udah serius, jangan main main)",
  "25 Tahun (woi tua, kapan lu nikah tolol \u{1F602})",
  "30 Tahun (Udah pantes di panggil bapak bapak/om)",
  "1000 Tahun (Jangan heran, bangsa elf loh ya)",
  "Unlimited Umur/Immortal\u{1F480}",
  " 5000 Tahun (waw kalo kalian mau nanya nanya sejarah dunia ini ke dia aja nih)",
  "Lahir Dari 1 Tahun Masehi \u{1F480})",
  "Udah hidup dari awal terbentuknya bumi (Nenek moyang nematoda \u{1F602})"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
