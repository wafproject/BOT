/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekrajin.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekrajin_exports = {};
__export(cek_cekrajin_exports, {
  default: () => cek_cekrajin_default
});
module.exports = __toCommonJS(cek_cekrajin_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.rajin)}\u201D`, m);
};
handler.help = ["cekrajin"];
handler.tags = ["cek"];
handler.command = /^(cekrajin)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cekrajin_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.rajin = [
  "enggak rajin",
  "rajin kalo gak di suruh",
  "biasa aja rajin nya",
  "lu rajin bgt njir ampe seluruh rumah pun mau lu bersihin",
  "rajin sih cuma lu lgbt",
  "rajin banget sampe rumah tetangga pun mau di bersihin njir",
  "lu nggak rajin, lu malasss \u{1F9E2}",
  "rajin",
  "lu rajin bgt njir",
  "rajin banget sampe sampe rumah bening tiap hari gara gara elu",
  "lu pemalas cok, diluar lagi kiamat pun lu gak lari menyelamatkan diri saking malasnya"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
