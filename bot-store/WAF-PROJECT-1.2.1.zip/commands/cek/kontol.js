/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - kontol.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_kontol_exports = {};
__export(cek_kontol_exports, {
  default: () => cek_kontol_default
});
module.exports = __toCommonJS(cek_kontol_exports);
let handler = async (m, { jagoanproject, text }) => {
  let who, name;
  if (m.mentionedJid && m.mentionedJid[0]) {
    who = m.mentionedJid[0];
    name = jagoanproject.getName(who);
  } else if (text && !text.startsWith("@")) {
    who = m.sender;
    name = text.trim();
  } else {
    who = m.fromMe ? jagoanproject.user.jid : m.sender;
    name = `@${who.split("@")[0]}`;
  }
  if (!name) {
    return jagoanproject.reply(m.chat, "\u{1F6A9} Tidak dapat menemukan nama pengguna!", m);
  }
  let ukuran = Math.floor(Math.random() * 19) + 1;
  let emot = ukuran < 3 ? "\u{1F602}" : ukuran < 7 ? "\u{1F632}" : ukuran < 10 ? "\u{1F440}" : ukuran < 15 ? "\u{1F924}" : "\u{1F975}";
  let displayName = m.mentionedJid && m.mentionedJid[0] || (!text || text.startsWith("@")) ? `@${who.split("@")[0]}` : name;
  jagoanproject.reply(m.chat, `
*\u2013\u2013\u2013\u2013\u2013\u2013\u300E CEK - KON \u300F\u2013\u2013\u2013\u2013\u2013\u2013*
\u2022 Nama : ${displayName}
\u2022 Kontol : ${pickRandom(["item bgt njing", "benda itu hijau", "Bintik Bintik Njir", "Putih Mulus Banget", "Fantablack Njir", "Pink Banget", "Hitam Mengkilap", "Warna Golden", "Abu Abu", "Gede Putih Tpi Gaada Biji Nya"])}
\u2022 Kondisi : ${pickRandom(["perjaka", "ga perjaka", "udh pernah di sepong", "udah pernah di masukin ke memek", "pernah di masukin ke bool", "belum sunat njir", "jumbo"])}
\u2022 Jembut : ${pickRandom(["lebat", "ada sedikit", "gada jembut", "tipis", "muluss"])}
\u2022 Ukuran : ${ukuran} cm ${emot}
`, m, { contextInfo: { mentionedJid: m.mentionedJid && m.mentionedJid[0] || (!text || text.startsWith("@")) ? [who] : [] } });
};
handler.help = ["cekkontol [@tag|nama]"];
handler.tags = ["cek"];
handler.command = /^cekkontol$/i;
handler.premium = false;
handler.register = true;
handler.limit = true;
var cek_kontol_default = handler;
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
