/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - mem.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_mem_exports = {};
__export(cek_mem_exports, {
  default: () => cek_mem_default
});
module.exports = __toCommonJS(cek_mem_exports);
let handler = async (m, { jagoanproject, command, text }) => {
  if (!text) return jagoanproject.reply(m.chat, "*Ketik Namanya!*", m);
  let mek = `
*\u2013\u2013\u2013\u2013\u2013\u2013\u300E CEK - MEM \u300F\u2013\u2013\u2013\u2013\u2013\u2013*
\u2022 Nama : ${text}
\u2022 Memek : ${pickRandom(["Ih item", "Belang wkwk", "Muluss", "Putih Mulus", "Black Doff", "Pink wow", "Item Glossy"])}
\u2022 Lubang : ${pickRandom(["Perawan", "Ga perawan", "Udah pernah dimasukin", "Masih rapet", "Tembem"])}
\u2022 Jembut : ${pickRandom(["Lebat", "Ada sedikit", "Gada jembut", "Tipis", "Mulus"])}
`.trim();
  jagoanproject.reply(m.chat, mek, m);
};
handler.help = ["cekmemek"];
handler.tags = ["cek"];
handler.command = /^cekmemek/i;
handler.register = true;
handler.limit = true;
var cek_mem_default = handler;
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
