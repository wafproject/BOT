/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - ceksange.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_ceksange_exports = {};
__export(cek_ceksange_exports, {
  default: () => cek_ceksange_default
});
module.exports = __toCommonJS(cek_ceksange_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.sange)}\u201D`, m);
};
handler.help = ["ceksange"];
handler.tags = ["cek"];
handler.command = /^(ceksange)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_ceksange_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.sange = [
  "sangean lu",
  "kebal sange\u{1F9E2}",
  "gak terlalu sangean",
  "agak agak suka sange",
  "sange sama kartun\u{1F602}",
  "sering sange kalo liat anak kecil",
  "sange sama bokep anak kecil",
  "raja sange",
  "puncak kesangean njir\u{1F628}",
  "gak suka sange",
  "menolak sange dia mah padahal sebenarnya pengen",
  "gabisa sange (mandul kali ya?)",
  "sange sama pintu lemari\u{1F602}",
  "sange kalo liat kucing lagi kawin",
  "sange sama bokep furry",
  "sange sama papan tulis",
  "sange kalo liat foto mas amba loh ya"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
