/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - jomokcek.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_jomokcek_exports = {};
__export(cek_jomokcek_exports, {
  default: () => cek_jomokcek_default
});
module.exports = __toCommonJS(cek_jomokcek_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.gay)}\u201D`, m);
};
handler.help = ["jomokcek"];
handler.tags = ["fun"];
handler.command = /^(jomokcek)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = true;
handler.register = true;
var cek_jomokcek_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.gay = [
  "Jomok Level : 4%\n\nAman Cik\u{1F618}!",
  "Jomok Level : 7%\n\nMendinglah Rek\u{1F60B}",
  "Jomok Level : 12%\n\nWaspada Calon Raja Iblis\u{1F632}",
  "Jomok Level : 22%\n\nWeladalah\u{1F97A}",
  "Jomok Level : 27%\n\nJomok Dikit\u{1F92D}",
  "Jomok Level : 35%\n\nJomok \xBC\u{1F631}",
  "Jomok Level : 41%\n\nBahaya Wir\u{1F92F}",
  "Jomok Level : 48%\n\nSetengah Jomok\u{1F614}",
  "Jomok Level : 56%\n\nLu Jomok juga\u{1F62B}",
  "Jomok Level : 64%\n\nAnjir Calon Sungut Lele\u{1F928}",
  "Jomok Level : 71%\n\nWaduh\u{1F602}",
  "Jomok Level : 1%\n\n99% Slow Aja Keles\u{1F605}!",
  "Jomok Level : 77%\n\nCalon Calon Ini Mah Njir\u{1F923}",
  "Jomok Level : 83%\n\nWaspada Pantat Hitam\u{1F60B}",
  "Jomok Level : 89%\n\nJomok Banget Njir\u{1F606}!",
  "Jomok Level : 94%\n\nTOBAT WOEE,, JOMOK LU UDH MELEWATI BATAS!\u{1F602}",
  "Jomok Level : 100%\n\nLU ORANG TERJOMOK NJIR\u{1F917}",
  "Jomok Level : 100%\n\nLU PECINTA LOBANG PANTAD BEJIR\u{1F929}",
  "Jomok Level : 100%\n\nLU SI RAJA IBLIS\u{1F975}",
  "Jomok Level : 100%\n\nDAH GA KETOLONG JOMOKNYA NIH ORANG\u{1F970}"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
