/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cektinggi.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cektinggi_exports = {};
__export(cek_cektinggi_exports, {
  default: () => cek_cektinggi_default
});
module.exports = __toCommonJS(cek_cektinggi_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.tinggi)}\u201D`, m);
};
handler.help = ["cektinggi"];
handler.tags = ["cek"];
handler.command = /^(cektinggi)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cektinggi_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.tinggi = [
  "144CM (itu tinggi apa resolusi video\u{1F602})",
  "120CM (botol yakult botol yakult)",
  "150CM (pendek banget lu njir)",
  "170CM (idaman banget mas/mbak \u{1F970})",
  "100CM (anjir cok ketemu orang 150 keatas kalo mau nyepong gausah berlutut itu \u{1F602})",
  "180CM (diatas rata rata)",
  "190CM (kalo lu jadi kiper gaakan bisa di tembus kyknya)",
  "1000CM (LU MANUSIA APA TITAN KONTOL \u{1F602})",
  "130CM (ihhh kemasan sasettt \u{1F60D})",
  "145CM (standar tinggi cewek loh ya, kalo lu cowok terus tinggi lu 145CM jadi femboy aja sono \u{1F602})",
  "155CM (udah standar tinggi cewek, tapi kalo lu cowok sih jadi femboy aja kata gw)",
  "160CM (biasa aja, standar tinggi warga Indonesia)",
  "165CM (ideal gak sih?)",
  "200CM (gile lu, bisa di pake sodok mangga nih \u{1F602})",
  "240CM (Anjir raksasa, udah kyk resolusi video aja lu \u{1F602})"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
