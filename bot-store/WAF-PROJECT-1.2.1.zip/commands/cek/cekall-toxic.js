/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekall-toxic.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekall_toxic_exports = {};
__export(cek_cekall_toxic_exports, {
  default: () => cek_cekall_toxic_default
});
module.exports = __toCommonJS(cek_cekall_toxic_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
var import_node_fetch = __toESM(require("node-fetch"));
var import_fs = __toESM(require("fs"));
const { jidNormalizedUser } = __zapo_1;
let handler = async (m, { jagoanproject, args, text, usedPrefix, command }) => {
  let template = (args[0] || "").toLowerCase();
  if (!args[0]) {
    let caption = `*Contoh Penggunaan* \u{1F60E}

${usedPrefix + command} tai @user

*List Command*
\u22C6\u0F3A anjing 
\u22C6\u0F3A asu 
\u22C6\u0F3A babi 
\u22C6\u0F3A bajingan 
\u22C6\u0F3A banci 
\u22C6\u0F3A bangsat 
\u22C6\u0F3A bego 
\u22C6\u0F3A bejad 
\u22C6\u0F3A bencong 
\u22C6\u0F3A bolot 
\u22C6\u0F3A brengsek 
\u22C6\u0F3A budek 
\u22C6\u0F3A buta 
\u22C6\u0F3A geblek 
\u22C6\u0F3A gembel 
\u22C6\u0F3A gila 
\u22C6\u0F3A goblok 
\u22C6\u0F3A hina 
\u22C6\u0F3A iblis 
\u22C6\u0F3A idiot 
\u22C6\u0F3A jablay 
\u22C6\u0F3A jelek 
\u22C6\u0F3A kampret 
\u22C6\u0F3A kampungan 
\u22C6\u0F3A kamseupay 
\u22C6\u0F3A keparat 
\u22C6\u0F3A kontol 
\u22C6\u0F3A kunyuk 
\u22C6\u0F3A memek 
\u22C6\u0F3A monyet 
\u22C6\u0F3A ngentot 
\u22C6\u0F3A pecun 
\u22C6\u0F3A perek 
\u22C6\u0F3A sarap 
\u22C6\u0F3A setan 
\u22C6\u0F3A sinting 
\u22C6\u0F3A sompret 
\u22C6\u0F3A tai 
\u22C6\u0F3A tolol 
\u22C6\u0F3A udik 
`;
    await jagoanproject.reply(m.chat, caption, m, { mentions: jagoanproject.parseMention(caption) });
    return;
  }
  if (command) {
    switch (template) {
      case "anjing":
      case "asu":
      case "babi":
      case "bajingan":
      case "banci":
      case "bangsat":
      case "bego":
      case "bejad":
      case "bencong":
      case "bolot":
      case "brengsek":
      case "budek":
      case "buta":
      case "geblek":
      case "gembel":
      case "gila":
      case "goblok":
      case "iblis":
      case "idiot":
      case "jablay":
      case "jelek":
      case "kampret":
      case "kampungan":
      case "kamseupay":
      case "keparat":
      case "kontol":
      case "kunyuk":
      case "hina":
      case "memek":
      case "monyet":
      case "ngentot":
      case "pecun":
      case "perek":
      case "sarap":
      case "setan":
      case "sinting":
      case "sompret":
      case "tai":
      case "tolol":
      case "udik":
        let who;
        try {
          if (m.isGroup) {
            if (m.mentionedJid && m.mentionedJid[0]) {
              who = jidNormalizedUser(m.mentionedJid[0]);
            } else if (m.quoted) {
              who = jidNormalizedUser(m.quoted.sender);
            } else {
              who = jidNormalizedUser(m.sender);
            }
          } else {
            if (m.quoted) {
              who = jidNormalizedUser(m.quoted.sender);
            } else {
              who = jidNormalizedUser(m.sender);
            }
          }
          let name = await jagoanproject.getName(who) || "Tidak ditemukan \u{1F615}";
          const cek2 = cek1[Math.floor(Math.random() * cek1.length)];
          let emoticon = "";
          if (cek2 <= 20) emoticon = "\u{1F604}\u{1F44D}";
          else if (cek2 <= 50) emoticon = "\u{1F605}\u{1F44C}";
          else if (cek2 <= 80) emoticon = "\u{1F62C}\u26A0\uFE0F";
          else emoticon = "\u{1F631}\u{1F525}";
          let caption = `Tingkat *${template}an* \u{1F4CA}
Atas nama *${name}* (@${who.split("@")[0]}) adalah *${cek2}%* ${emoticon}`;
          await jagoanproject.reply(m.chat, caption, m, { mentions: jagoanproject.parseMention(caption) });
        } catch (e) {
          try {
            who = jidNormalizedUser(m.quoted ? m.quoted.sender : m.sender);
            let name = await jagoanproject.getName(who) || "Tidak ditemukan \u{1F615}";
            const cek2 = cek1[Math.floor(Math.random() * cek1.length)];
            let emoticon = "";
            if (cek2 <= 20) emoticon = "\u{1F604}\u{1F44D}";
            else if (cek2 <= 50) emoticon = "\u{1F605}\u{1F44C}";
            else if (cek2 <= 80) emoticon = "\u{1F62C}\u26A0\uFE0F";
            else emoticon = "\u{1F631}\u{1F525}";
            let caption = `Tingkat *${template}an* \u{1F4CA}
Atas nama *${name}* (@${who.split("@")[0]}) adalah *${cek2}%* ${emoticon}`;
            await jagoanproject.reply(m.chat, caption, m, { mentions: jagoanproject.parseMention(caption) });
          } catch {
            await jagoanproject.reply(m.chat, `\u274C Maaf, tidak bisa mengambil nama user \u{1F622}`, m);
          }
        }
        break;
    }
  }
};
handler.help = ["cek <menu> <user>"];
handler.tags = ["cek"];
handler.command = /^cek$/i;
handler.register = true;
handler.limit = true;
var cek_cekall_toxic_default = handler;
global.cek1 = Array.from({ length: 100 }, (_, i) => `${i + 1}`);

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
