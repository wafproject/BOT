/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekpedo.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekpedo_exports = {};
__export(cek_cekpedo_exports, {
  default: () => cek_cekpedo_default
});
module.exports = __toCommonJS(cek_cekpedo_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.pedo)}\u201D`, m);
};
handler.help = ["cekpedo"];
handler.tags = ["cek"];
handler.command = /^(cekpedo)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cekpedo_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.pedo = [
  "Pedo 1%\n\nGaK Pedo Kok Aman",
  "Pedo 5%\n\nMasih Gak Pedo",
  "Pedo 10%\n\nMasih Aman",
  "Pedo 15%\n\nAman Kok",
  "Pedo 20%\n\nHampir Aman",
  "Pedo 25%\n\nWahh Udah Rada Rada Nih",
  "Pedo 30%\n\n\u{1F628}\u{1F628}\u{1F628}",
  "Pedo 35%\n\nAdek Kalian Cewek? Amanin Cepet",
  "Pedo 40%\n\nSalah Satu Sekte *Umur Hanya Angka*",
  "Pedo 45%\n\nUdah Mau Setengah Pedo Njir",
  "Pedo 50%\n\nWaduh Rek",
  "Pedo 55%\n\nMulai Gak Aman Nih",
  "Pedo 60%\n\nSuka Jilatin Kaki Anak Kecil Dia Nih",
  "Pedo 65%\n\nWaduhhh",
  "Pedo 70%\n\nKok Lu Bisa Suka Sama Anak Kecil Sih",
  "Pedo 75%\n\nMenjauh Kau Pedo",
  "Pedo 80%\n\nAduhh Bang Jangan Ewe Adek Gw Yak",
  "Pedo 85%\n\nBang Anak Tetangga Itu Bang Jangan Di Ewe",
  "Pedo 90%\n\nGolongan Orang Yang Kalo Ada Anak Kecil Langsung Ngaceng",
  "Pedo 95%\n\nMending Gay Aja Bang, Ngapain Jadi Pedo Njir\u{1F639}",
  "Pedo 100%\n\n\u2620\uFE0F\u2620\uFE0F\u2620\uFE0F\u2620\uFE0F\u2620\uFE0F",
  "Pedo Pro\n\nHarus Di Basmi Dia Nih Woi",
  "Inilah Pedo Tersebut\n\nPANGGIL FBI CEPET WOI, KETIK 1 UNTUK MEMBUNUH PEDO"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
