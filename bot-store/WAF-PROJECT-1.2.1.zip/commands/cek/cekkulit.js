/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekkulit.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekkulit_exports = {};
__export(cek_cekkulit_exports, {
  default: () => cek_cekkulit_default
});
module.exports = __toCommonJS(cek_cekkulit_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.kulit)}\u201D`, m);
};
handler.help = ["cekkulit"];
handler.tags = ["cek"];
handler.command = /^(cekkulit)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cekkulit_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.kulit = [
  "Putih Bersih",
  "Sawo Matang",
  "Item Njir Kyk Orang Afrika",
  "Putih Banget (Keputihan)",
  "Putih Pink (Pantat Nya Pun Pink)",
  "Gak Putih Gak Hitam",
  "Hampir Hitam",
  "Agak Putih",
  "Kuning Langsat",
  "Negro",
  "Nigga",
  "Putih Kyk Artis Korea",
  "Lu Mirip Kyk Sadio Mane Hitam Nya",
  "Awokawok Belang",
  "Muka doang yang putih"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
