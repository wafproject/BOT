/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekskill.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekskill_exports = {};
__export(cek_cekskill_exports, {
  default: () => cek_cekskill_default
});
module.exports = __toCommonJS(cek_cekskill_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.skill)}\u201D`, m);
};
handler.help = ["cekskill"];
handler.tags = ["cek"];
handler.command = /^(cekskill)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cekskill_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.skill = [
  "pengendali air muani",
  "bisa menghilang kalo liat cewek cantik/cowok ganteng",
  "bisa menyamarkan keberadaan nya dari orang orang sekitar (kasian NPC)",
  "kentut nya ber api",
  "menggandakan uang (Di Print Doang Njir Menggandakan Apaan)",
  "Pengendali Pasir + Semen (Nguli Njir)",
  "ahli ngocok (100 Kocokan Semenit)",
  "bisa coli 100 kali sehari tanpa merasa lelah",
  "ahli ngoding (Kyk Aping)",
  "menguasai seluruh elemen",
  "gapunya skill (Kasian)",
  "memanipulasi orang (dikasih muani njir orang nya)",
  "kemampuan untuk melihat dan melacak tobrut",
  "ahli nyari situs bokep enak",
  "ahli membuat pudding coklat seperti pak hambali",
  "ahli di segala mata pelajaran",
  "kepintaran seperti Amba Einstein",
  "jago tidur (Bisa Tidur 3 Hari Gak Bangun Bangun Njir)"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
