/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - tempacolmek.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_tempacolmek_exports = {};
__export(cek_tempacolmek_exports, {
  default: () => cek_tempacolmek_default
});
module.exports = __toCommonJS(cek_tempacolmek_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.tempatcolmek)}\u201D`, m);
};
handler.help = ["tempatcolmek"];
handler.tags = ["cek"];
handler.command = /^(tempatcolmek)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_tempacolmek_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.tempatcolmek = [
  "Di Dalem Kamar\n*Normal Sih Tapi Sambil Liatin Foto Lisa Blackpink Njir*\u{1F480}",
  "Di Kali\n*Kyk Gaada Tempat Lain Aja Neng*",
  "Di Dalem Kamar Nya Bestie\n*Sekalian Aja Minta Di Colmekin Sama Bestie*\u{1F602}",
  "Di Depan Cowok Lu\n*Lu Ngapain Cok, Itu Kontol Cowok Lu Nganggur Malah Colmek*\u{1F602}\u{1F602}\u{1F602}",
  "Di Rumah Nya Jokowi\n*Di Kamar Gw Aja Sini, Ngapain Ke Rumah Penghutang Negara*\u{1F620}",
  "Di Atas Atap\n*Stress Lu Ya?*\u{1F605}",
  "Di Dalem Wc Guru\n*Wah Itu Guru Lu Mau Berak Njir Ada Ada Aja Lu*\u{1F611}",
  "Di Kantor DPR\n*Lu Diangkat Jadi Wakil DPR Karna Cara Colmek Lu Yang Nggak Biasa*\u{1F480}",
  "Di Depan Ortunya Cowok Lu\n*Ada Ada Aja Lu, Tapi Calon Bapak Mertua Lu Kok Titid Nya Tegang?*\u{1F605}",
  "Di Boxing Arena\n*Ini Tempat Adu Jotos Woi Bukan Adu Colmek, Pulang Lu Sono*\u{1F611}",
  "Di Kandang Ayam\n*Jangan Woi Ntar Memek Lu Bau Ayam*\u{1F602}",
  "Di Depan Guru\n*Lu Kalo Colmek Liat Tempat Lah, Ntar Di Ewe Guru Lagi Yang Kena Batunya*\u{1F602}",
  "Di Ruang Tamu\n*Ntar Kalo Ada Tamu Terus Ku Di Ewe Gimana?*\u{1F611}",
  "Di Meja Billiard\n*Lu Kalo Gatau Main Billiard Pulang Aja, Kurang Kerjaan Lu*\u{1F602}",
  "Di Tengah Lapangan\n*Lu Di Videoin Tuh, Ntar Lagi Viral*\u{1F60B}",
  "Di Dalam Kereta\n*Hati Hati Ntar Di Sodok Penumpang*\u{1F602}",
  "Di Kantor Polisi\n*Ntar Lagi Ada Kasus Viral (Polisi Rudapaksa Cewek Random)*\u{1F602}",
  "Di RS\n*Orang Orang Pada Datang Berobat, Lu Malah Datang Colmek*\u{1F611}",
  "Di Dalem Wc Sekolah\n*Siswa Lain Kasian Itu Mau Berak, Cepet Dikit*\u{1F611}"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
