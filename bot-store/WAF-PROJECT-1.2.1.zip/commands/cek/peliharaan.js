/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - peliharaan.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_peliharaan_exports = {};
__export(cek_peliharaan_exports, {
  default: () => cek_peliharaan_default
});
module.exports = __toCommonJS(cek_peliharaan_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.peliharaan)}\u201D`, m);
};
handler.help = ["cekpeliharaan"];
handler.tags = ["cek"];
handler.command = /^(cekpeliharaan)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_peliharaan_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.peliharaan = [
  "Babi Ngepet\u{1F43D}",
  "Monyet Sigma\u{1F412}",
  "Kadal Yapping\u{1F98E}",
  "Rusa Knalpot Racing\u{1F98C}",
  "Badak Mas Amba\u{1F98F}",
  "Kijang Ahli Mberr\u{1F98C}",
  "Ayam Kampus\u{1F440}",
  "Ayam Semok Montok\u{1F414}",
  "Kuda Lumping Jawa\u{1F40E}",
  "Burung Mas Amba\u{1F54A}\uFE0F",
  "Singa Di Ranjang\u{1F981}",
  "Tikus Kantor\u{1F400}",
  "\u{1F420}Ikan Laga Laga (Seronoknya Main Laga Laga)",
  "Harimau Berkontol Besar 20CM\u{1F405}",
  "Serigala Berbulu Domba\u{1F43A}",
  "Sweety Fox\u{1F98A}\u{1F60B}",
  "Kucing Mewing\u{1F431}",
  "Anjing Gyatt\u{1F436}",
  "Jerapah Ahli Sepong\u{1F992}",
  "Angsa Mengemud i\u{1F9A2}",
  "Bebek Bakar Madu\u{1F986}",
  "Buaya Darat\u{1F40A} (Hai Cantik Boleh Kenalan Gak)",
  "Cacing Besar Alaska\u{1FAB1}",
  "Ubur Ubur Spogebob\u{1FABC}",
  "Kraken Njir\u{1F419}",
  "Kepiting Kikir\u{1F980}",
  "Dinosaurus Khas Balikpapan\u{1F996}"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
