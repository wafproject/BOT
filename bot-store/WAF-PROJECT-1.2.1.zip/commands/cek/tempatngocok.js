/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - tempatngocok.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_tempatngocok_exports = {};
__export(cek_tempatngocok_exports, {
  default: () => cek_tempatngocok_default
});
module.exports = __toCommonJS(cek_tempatngocok_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.tempatngocok)}\u201D`, m);
};
handler.help = ["tempatngocok"];
handler.tags = ["cek"];
handler.command = /^(tempatngocok)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_tempatngocok_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.tempatngocok = [
  "Di Kantor DPR\n*Astaga*\u{1F602}",
  "Di Rumah Tetangga\n*Kurang Kerjaan Amat Lu*\u{1F602}",
  "Di Kamar Mandi\n*Standar Aja, Tapi Plis Lah Kalo Bisa Jangan Coli Kalo Gak Pake Foto Messi*\u{1F602}",
  "Di Kamar Sambil Liat Video Pop Mie\n*Astaga Bro Aduhai, Tapi Boleh Dong Kirim Video Nya*\u{1F60B}",
  "Di Depan Ortu Nya\n*Bro, Lu Dicoret Dari KK Sih Abis Ini*\u{1F602}",
  "Di Belakang Rumah\n*Gajelas Lu, Kan Di Kamar Bisa, Ngapain Malah Di belakang Rumah Anjir*\u{1F602}",
  "Di Depan Depan Pacar Nya\n*Ayang Jadi Makin Sayang Karna Titid Lu 20CM*\u{1F480}",
  "Di Kantor Gubernur\n*Langsung Di Angkat Jadi Gubernur Karna Cara Coli Nya Nggak Biasa*\u{1F480}",
  "Di Dalam Kulkas\n*Joni Mu Bilek (Bang Dingin Bang)*\u{1F602}",
  "Dirumah Mas Amba\n*Diajarin Tatacara Coli Yang Benar Loh Ya*\u{1F60B}",
  "Di Dalam Lemari\n*Astaga Kyk Gaada Tempat Lain Aja*\u{1F480}",
  "Diatas Motor\n*New FreeStyle Unlocked*\u{1F602}",
  "Di Depan Ustad\n*Abis Ini Diceramahin 30 Juz*\u{1F602}",
  "Di Atas Genteng Rumah Tetangga\n*Penyakit Coli Gila*\u{1F480}",
  "Di Pinggir Jalan\n*Gaada Kerjaan Lain Ya Lu?*\u{1F60A}",
  "Di Dalam Angkot\n*Liat Tempat Lah Cok*\u{1F602}",
  "Di Toko Hp\n*Beli Hp Woi Malah Coli Lu Tolol*\u{1F92C}",
  "Di Depan Calon Mertua\n*Calon Mertua Malah Minta Dinikahin*\u{1F480}",
  "Di Kamar Ortu\n*Jangan Lupa Bersihin Dan Pake Pengharum Ruangan Ntar Ketahuan Cok*\u{1F602}",
  "Di Markas OPM\n*Angkat Tangan Kiri*\u{1F480}",
  "Di Neraka\n*Udah Panas Masih Aja Coli*\u{1F480}",
  "Di Atas Pohon\n*Itu Siapa, Kelitan Burung Nya Tuh*\u{1F426}",
  "Di Dalam Gereja\n*Bodo*\u{1F621}",
  "Di Mall\n*Pengunjung Pada Videoin Elu Njir Malu Dikit Lah*\u{1F602}",
  "Di Tengah Jalan\n*Woi Tolol Bikin Macet Aja Lu*\u{1F611}",
  "Di Lampu Merah\n*Orang Orang Pada Ngamen Lu Malah Coli*\u{1F602}",
  "Di Depan Kepala Sekolah\n*Kepala Sekolah Malah Nyepong*\u{1F480}",
  "Di Kantor Lurah\n*Lurah Pun Bingung Sama Kelakuan Elu*",
  "Di Wc Sekolah\n*Liat Tempat Lah Bjir*\u{1F611}",
  "Di Wc Umum\n*Cepetan Crot Wou Gw Udah Kebelet Berak*\u{1F620}",
  "Di Dalam Maxim\n*Sopir Nya Malah Ikutan*\u{1F628}",
  "Di Rumah Ayang\n*Dicoliin Ayang Juga Loh Ya*\u{1F60B}",
  "Di Kebun Pisang\n*Ewe Pisang Njir Bukan Coli Dia Mah*"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
