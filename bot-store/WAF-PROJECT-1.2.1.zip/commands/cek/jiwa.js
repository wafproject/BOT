/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - jiwa.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_jiwa_exports = {};
__export(cek_jiwa_exports, {
  default: () => cek_jiwa_default
});
module.exports = __toCommonJS(cek_jiwa_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.jiwa)}\u201D`, m);
};
handler.help = ["cekjiwa"];
handler.tags = ["cek"];
handler.command = /^(cekjiwa)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_jiwa_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.jiwa = [
  "lu nggak gila kok siapa bilang?",
  "agak gila lu",
  "kadang koslet",
  "selalu gila",
  "lu kena penyakit yung kai blue gila",
  "kadang stress kadang enggak",
  "lu gak benar benar gila, kadang kadang aja",
  "ke RSJ yuk? udah parah itu",
  "lu yang gw sering liat di lampu merah cuma pake kolor ya?\u{1F602}",
  "gak gila",
  "beneran gila, cuma kalo mau di tanganin udah telat, udah parah ini mah\u{1F602}",
  "stress + gila + tolol (lengkap dah",
  "lu kena penyakit siput gila",
  "lu kena penyakit amba gila",
  "lu gak gila kok, cuma stress\u{1F602}",
  "gila lu ya? minum obat sana"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
