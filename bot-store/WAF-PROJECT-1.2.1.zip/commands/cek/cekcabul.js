/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek-cekcabul.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekcabul_exports = {};
__export(cek_cekcabul_exports, {
  default: () => cek_cekcabul_default
});
module.exports = __toCommonJS(cek_cekcabul_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.cabul)}\u201D`, m);
};
handler.help = ["cekcabul"];
handler.tags = ["cek"];
handler.command = /^(cekcabul)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cekcabul_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.cabul = [
  "Cabul 1%\nAman Mas",
  "Cabul 5%\nBoleh Lah",
  "Cabul 10%\nNggak Cabul",
  "Cabul 15%\nAman Kok",
  "Cabul 20%\nHampir Aman",
  "Cabul 25%\nWahh Udah Rada Rada Nih",
  "Cabul 30%\n\u{1F628}\u{1F628}\u{1F628}",
  "Cabul 35%\nHentikan Nonton Bokep Sebelum Telat",
  "Cabul 40%\nMulai Lu Mulai, Jangan Sampe Lu Ewe Pacar Orang Ya\nAwas Lu",
  "Cabul 45%\nUdah Mau Setengah Cabul Njir",
  "Cabul 50%\nWaduh Rek Setengah Loh Ya",
  "Cabul 55%\nKadang Cabul Kadang Enggak",
  "Cabul 60%\nGak Aman",
  "Cabul 65%\nWaduh Loh Ya",
  "Cabul 70%\nHadeh Bang, Jangan Kebanyakan Nonton Bokep Lah",
  "Cabul 75%\nMenjauh Kau Cabul",
  "Cabul 80%\nAduhh Bang Jangan Ewe Gw, Gw Cowok Bang",
  "Cabul 85%\nColi Mulu Dia Nih",
  "Cabul 90%\nLiat Porno Dikit Langsung Ngaceng",
  "Cabul 95%\nNenek Nenek Pun Di Ewe Sama Dia Nih",
  "Cabul 100%\n\u2620\uFE0F\u2620\uFE0F\u2620\uFE0F\u2620\uFE0F\u2620\uFE0F",
  "Cabul Pro\nHarus Di Basmi Dia Nih Woi",
  "Inilah Cabul Tersebut\nBROO NO WAYY GAK NYANGKA GW LU SECABUL ITU",
  "Cabul ProMax\nAnjir Lu Cok Segala Jenis Manusia Di Embat\nNenek Gw Pun Lu Embat"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
