/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - ras.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_ras_exports = {};
__export(cek_ras_exports, {
  default: () => cek_ras_default
});
module.exports = __toCommonJS(cek_ras_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.ras)}\u201D`, m);
};
handler.help = ["cekras"];
handler.tags = ["cek"];
handler.command = /^(cekras)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_ras_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.ras = [
  "Manusia Biasa",
  "Ras Manusia+Iblis",
  "Ras Manusia+Babi Ngepet\u{1F602}",
  "Ras Nigga",
  "Ras Elf",
  "Ras Nabati (Njir Tumbuhan\u{1F602})",
  "Ras Iblis Murni",
  "Ras Jomok",
  "Ras Manusia Setengah Hewan",
  "Ras Laba Laba Sunda",
  "Ras Peri",
  "Ras Werewolf",
  "Ras Kucing Miaww",
  "Ras Siput",
  "Ras Kalajengking",
  "Ras Goblin",
  "Ras Monster",
  "Ras Dwarf",
  "Ras Manusia+Kambing (WTF\u{1F480}\u{1F480}\u{1F480})",
  "Ras Ikan (\u{1F602}\u{1F602}\u{1F602})",
  "Ras Kuda (Kontol/Memek Lu Pasti Besar)",
  "Ras Iblis Campuran Elf (Ras Terkuat)",
  "Ras Yapping"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
