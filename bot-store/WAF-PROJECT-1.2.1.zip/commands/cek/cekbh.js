/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek -cekbh.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekbh_exports = {};
__export(cek_cekbh_exports, {
  default: () => cek_cekbh_default
});
module.exports = __toCommonJS(cek_cekbh_exports);
let handler = async (m, { text }) => {
  if (!text) throw "Masukan nama!\n\nContoh: .cekbh owner";
  const sizes = ["tepos", "30", "32A", "32B", "32C", "34A", "34B", "34C", "36A", "36B", "36C", "38A", "38B", "38C", "40A", "40B", "40C", "42A", "42B", "42C"];
  const colors = ["Merah", "Biru", "Hijau", "Kuning", "Hitam", "Putih", "Oranye", "Ungu", "Coklat", "Abu-abu", "Merah Muda", "Biru Muda", "Hijau Muda", "Krem", "Biru Tua", "Hijau Tua", "Biru Langit", "Toska", "Salmon", "Emas", "Perak", "Magenta", "Cyan", "Olive", "Navy", "transparan"];
  const shapes = ["underwired", "push-up", "balcanote", "padded", "halter", "Bikini", "bralette", "sport", "tube", "bridal", "T-brief", "tshirt", "multiway", "Midi", "Maxi", "tidak pakai", "nursing", "Cheeky", "Brazilian", "Cutaway", "halter"];
  const randomSize = await getRandomItem(sizes);
  const randomColor = await getRandomItem(colors);
  const randomShape = await getRandomItem(shapes);
  jagoanproject.reply(m.chat, `Bra si ${text} adalah:
Ukuran: ${randomSize}
Warna: ${randomColor}
Bentuk: ${randomShape}`, m);
};
handler.help = handler.command = ["cekbh"];
handler.tags = ["cek"];
handler.register = true;
handler.limit = true;
var cek_cekbh_default = handler;
function getRandomItem(array) {
  const randomIndex = Math.floor(Math.random() * array.length);
  return array[randomIndex];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
