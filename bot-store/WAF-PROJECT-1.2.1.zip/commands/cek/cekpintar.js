/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/cek/cek - cekpintar.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cek_cekpintar_exports = {};
__export(cek_cekpintar_exports, {
  default: () => cek_cekpintar_default
});
module.exports = __toCommonJS(cek_cekpintar_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `\u201C${pickRandom(global.pintar)}\u201D`, m);
};
handler.help = ["cekpintar"];
handler.tags = ["cek"];
handler.command = /^(cekpintar)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;
handler.register = true;
var cek_cekpintar_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.pintar = [
  "Aowkaowk Lu Gak Pintar Cok\nSekolah dulu sana yang bener",
  "Masih Lebih Pintar Adek Gw Ketimbang Elu",
  "15% Lah Ya, Masih Pinteran Kucing Gw",
  "69%, Lu Sebenarnya Pinter Cuma Sayang Nya Lu Pedo",
  "10% Doang, Semut Juga Lebih Pinter Daripada Elu",
  "20%, Bisa Tuh, Kembangin Aja Terus\nSiapa Tau Bisa Ngalahin Kepintaran Ayam",
  "25%, Jangan Kebanyakan Jomok\nBtw Ada Doksli Kecap Buk Buk Gak Cik?",
  "30% Lah Ya, Lu Pinter Kok, Kembangin Lagi",
  "40%\nJangan Kebanyakan Nonton Bokep\nHehe",
  "50%\nOtak Lu Setengah Setengah Cok\nkadang Pinter Kadang Enggak",
  "60%\nIQ Lu Udah Boleh Lah Ya\nTinggal Kurangin Nonton Bokep Anak Kecil \u{1F928}",
  "Gile Cok Lu Terlalu Pinter\nSampe Sampe Cuma 1% Doang Gila \u{1F60E}",
  "100%\nWahh Salut Gwe, Lu Sering Juara Kelas Ya?\nJadiin Gwe Murid Mu Plis",
  "Lu Setara Albert Einstein Njir\nJangan Jangan Teori Teori Fisika Lu Yang Nemuin?\n\u{1F628}\u{1F628}\u{1F628}"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "cek" }
)
