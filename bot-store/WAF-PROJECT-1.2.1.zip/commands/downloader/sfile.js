/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - sfile.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_sfile_exports = {};
__export(downloader_sfile_exports, {
  default: () => downloader_sfile_default
});
module.exports = __toCommonJS(downloader_sfile_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
const sfileLib = {
  createHeaders(referer) {
    return {
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
      "sec-ch-ua": '"Not/A)Brand";v="8", "Chromium";v="137", "Google Chrome";v="137"',
      dnt: "1",
      "sec-ch-ua-mobile": "?1",
      "sec-ch-ua-platform": '"Android"',
      "sec-fetch-site": "same-origin",
      "sec-fetch-mode": "cors",
      "sec-fetch-dest": "empty",
      Referer: referer,
      Accept: "*/*",
      "Accept-Language": "en-US,en;q=0.9"
    };
  },
  extractCookies(headers) {
    return (headers?.["set-cookie"] || []).map((c) => String(c).split(";")[0]).join("; ") || "";
  },
  _getListValue(text, fallback = "") {
    if (!text) return fallback;
    const parts = String(text).split(":");
    if (parts.length < 2) return fallback;
    return parts.slice(1).join(":").trim();
  },
  extractMetadata($) {
    const metadata = {};
    const ogTitle = $('meta[property="og:title"]').attr("content");
    const h1 = $("h1").first().text().trim();
    const titleTag = $("title").text().trim();
    metadata.file_name = (ogTitle || h1 || titleTag || "").trim() || null;
    if (metadata.file_name && /sfile\.mobi/i.test(metadata.file_name)) {
      metadata.file_name = metadata.file_name.replace(/\s*-\s*sfile\.mobi\s*/i, "").trim();
    }
    const box = $(".file-content").eq(0);
    if (box && box.length) {
      const imgAlt = box.find("img").attr("alt");
      if (!metadata.file_name && imgAlt) metadata.file_name = imgAlt.trim();
      const lists = box.find(".list").toArray().map((el) => $(el).text().trim());
      const mimetypeLegacy = lists[0]?.split("-")?.[1]?.trim();
      metadata.mimetype = mimetypeLegacy || null;
      metadata.upload_date = this._getListValue(lists[2]) || null;
      metadata.download_count = this._getListValue(lists[3]) || null;
      metadata.author_name = box.find(".list").eq(1).find("a").text().trim() || box.find('a[href*="user"]').first().text().trim() || null;
      for (const line of lists) {
        const low = line.toLowerCase();
        if (!metadata.upload_date && low.includes("upload date"))
          metadata.upload_date = this._getListValue(line);
        if (!metadata.download_count && (low.includes("download") || low.includes("downloads")))
          metadata.download_count = this._getListValue(line);
        if (!metadata.mimetype && (low.includes("type") || low.includes("mime")))
          metadata.mimetype = this._getListValue(line);
      }
    }
    return metadata;
  },
  async makeRequest(url, options) {
    try {
      return await import_axios.default.get(url, {
        timeout: 3e4,
        maxRedirects: 5,
        validateStatus: () => true,
        ...options
      });
    } catch (err) {
      if (err?.response) return err.response;
      throw new Error(`Request gagal: ${err.message}`);
    }
  },
  async getFinalUrl(url) {
    let headers = this.createHeaders(url);
    const initial = await this.makeRequest(url, { headers });
    const cookies = this.extractCookies(initial.headers);
    if (cookies) headers.Cookie = cookies;
    let $ = cheerio.load(initial.data);
    const metadata = this.extractMetadata($);
    let downloadUrl = $("#download").attr("href");
    if (!downloadUrl) throw new Error("Download URL gak ketemu (#download)");
    if (downloadUrl.startsWith("/")) downloadUrl = `https://sfile.mobi${downloadUrl}`;
    headers = { ...headers, Referer: url };
    const mid = await this.makeRequest(downloadUrl, { headers });
    $ = cheerio.load(mid.data);
    const scripts = $("script").map((_, el) => $(el).html() || "").get().join("\n");
    const finalUrlRegex = /https:\\\/\\\/download\d+\.sfile\.mobi\\\/downloadfile\\\/\d+\\\/\d+\\\/[a-z0-9]+\\\/[^\s'"]+/gi;
    const matches = scripts.match(finalUrlRegex);
    if (!matches?.length) throw new Error("Link download final gak ketemu di script");
    const finalUrl = matches[matches.length - 1].replace(/\\\//g, "/");
    return { metadata, finalUrl, referer: downloadUrl, headers };
  },
  // return buffer + response headers biar bisa validasi
  async downloadBuffer(finalUrl, headers, referer) {
    const res = await this.makeRequest(finalUrl, {
      headers: { ...headers, Referer: referer },
      responseType: "arraybuffer"
    });
    const buf = Buffer.from(res.data || []);
    return { buffer: buf, headers: res.headers || {}, status: res.status };
  },
  async search(query, page = 1) {
    if (!query || !String(query).trim()) throw new Error("Query kosong");
    page = Number(page) || 1;
    const url = `https://sfile.mobi/search.php?q=${encodeURIComponent(
      String(query).trim()
    )}&page=${page}`;
    const headers = this.createHeaders(url);
    const res = await this.makeRequest(url, { headers });
    const $ = cheerio.load(res.data);
    const result = [];
    $("div.list").each((_, el) => {
      const a = $(el).find("a").first();
      const title = a.text().trim();
      let link = a.attr("href");
      const raw = $(el).text().trim();
      const sizeMatch = raw.match(/\(([^)]+)\)/);
      const size = sizeMatch ? sizeMatch[1].trim() : null;
      if (link && link.startsWith("/")) link = `https://sfile.mobi${link}`;
      if (title && link) result.push({ title, size, link });
    });
    return result;
  }
};
function guessMime(name = "") {
  const n = String(name).toLowerCase();
  if (n.endsWith(".apk")) return "application/vnd.android.package-archive";
  if (n.endsWith(".zip")) return "application/zip";
  if (n.endsWith(".rar")) return "application/vnd.rar";
  if (n.endsWith(".7z")) return "application/x-7z-compressed";
  if (n.endsWith(".pdf")) return "application/pdf";
  if (n.endsWith(".mp3")) return "audio/mpeg";
  if (n.endsWith(".mp4")) return "video/mp4";
  if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
  if (n.endsWith(".png")) return "image/png";
  return "application/octet-stream";
}
function resolveConn(ctxThis, m, connArg) {
  return connArg || ctxThis || m?.conn || global && global.conn || null;
}
function isProbablyHtml(buffer, contentType = "") {
  const ct = String(contentType || "").toLowerCase();
  if (ct.includes("text/html")) return true;
  const head = buffer.slice(0, 200).toString("utf8").trim().toLowerCase();
  return head.startsWith("<!doctype") || head.startsWith("<html") || head.includes("<title>");
}
function getFilenameFromDisposition(cd) {
  if (!cd) return null;
  const s = String(cd);
  const m1 = s.match(/filename\*\s*=\s*utf-8''([^;]+)/i);
  if (m1?.[1]) return decodeURIComponent(m1[1].trim().replace(/(^"|"$)/g, ""));
  const m2 = s.match(/filename\s*=\s*("?)([^";]+)\1/i);
  if (m2?.[2]) return m2[2].trim();
  return null;
}
async function handler(m, opts) {
  const { command, text } = opts || {};
  const conn = resolveConn(this, m, opts?.conn);
  if (!text) {
    return m.reply(
      command === "sfiles" ? "Contoh: .sfiles minecraft" : "Contoh: .sfile https://sfile.mobi/xxxx"
    );
  }
  try {
    if (command === "sfiles") {
      const results = await sfileLib.search(text, 1);
      if (!results.length) return m.reply("Tidak ada hasil.");
      const msg = results.slice(0, 10).map(
        (v, i) => `${i + 1}. ${v.title}
   Size: ${v.size || "-"}
   Link: ${v.link}`
      ).join("\n\n");
      return m.reply(msg);
    }
    if (!/^https?:\/\/(www\.)?sfile\.mobi\/[A-Za-z0-9]+/i.test(text)) {
      return m.reply("URL tidak valid (harus link sfile.mobi)");
    }
    await m.reply("\u23F3 Downloading file...");
    const { metadata, finalUrl, referer, headers } = await sfileLib.getFinalUrl(text);
    const dl = await sfileLib.downloadBuffer(finalUrl, headers, referer);
    const buffer = dl.buffer;
    if (!buffer.length || isProbablyHtml(buffer, dl.headers["content-type"])) {
      const meta = metadata || {};
      const info = `\u274C Server balikin HTML/blocked (bukan file asli).

\u{1F4C2} Name: ${meta.file_name || "-"}
\u{1F4E6} Type: ${meta.mimetype || "-"}
\u{1F4C5} Upload: ${meta.upload_date || "-"}
\u2B07\uFE0F Downloads: ${meta.download_count || "-"}
\u{1F464} Author: ${meta.author_name || "-"}

\u{1F517} Direct: ${finalUrl}`;
      return m.reply(info);
    }
    const cdName = getFilenameFromDisposition(dl.headers["content-disposition"]);
    const fileName = cdName || metadata?.file_name || "sfile_download";
    const mimeHeader = String(dl.headers["content-type"] || "").split(";")[0].trim();
    const mime = mimeHeader || metadata?.mimetype || guessMime(fileName);
    const caption = `\u2705 Sukses
\u{1F4C2} Name: ${fileName}
\u{1F4E6} Type: ${mime}
\u{1F4C5} Upload: ${metadata?.upload_date || "-"}
\u2B07\uFE0F Downloads: ${metadata?.download_count || "-"}
\u{1F464} Author: ${metadata?.author_name || "-"}`;
    if (!conn || typeof conn.sendMessage !== "function") {
      return m.reply(caption + `

\u26A0\uFE0F Conn.sendMessage tidak ditemukan.
\u{1F517} Direct: ${finalUrl}`);
    }
    await conn.sendMessage(
      m.chat,
      {
        document: buffer,
        fileName,
        mimetype: mime,
        caption
      },
      { quoted: m }
    );
  } catch (e) {
    return m.reply(`\u274C ${e.message}`);
  }
}
handler.help = ["sfile <link>", "sfiles <query>"];
handler.tags = ["downloader"];
handler.command = /^(sfile|sfiles)$/i;
var downloader_sfile_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
