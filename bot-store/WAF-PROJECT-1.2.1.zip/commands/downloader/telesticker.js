/**
 * downloader/telesticker.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/telesticker",
  "command": [
    "telesticker",
    "stele"
  ],
  "kind": "download",
  "premium": true,
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
