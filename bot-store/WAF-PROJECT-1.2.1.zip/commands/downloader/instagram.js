/**
 * downloader/instagram.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/igdowloader",
  "command": [
    "ig",
    "igdl",
    "instagram",
    "instagramdl"
  ],
  "kind": "download",
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
