/**
 * downloader/pinterest.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "command": [
    "pinterest",
    "pin"
  ],
  "category": "downloader"
}

const R = require('../../lib/botcahx-routes.js').pinterest
handler_def.route = R.route
handler_def.routeHelp = R.help
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
