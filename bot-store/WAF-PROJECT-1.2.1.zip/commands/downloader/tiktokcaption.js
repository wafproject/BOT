/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - tiktokcaption.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_tiktokcaption_exports = {};
__export(downloader_tiktokcaption_exports, {
  default: () => downloader_tiktokcaption_default
});
module.exports = __toCommonJS(downloader_tiktokcaption_exports);
var import_axios = __toESM(require("axios"));
let handler = async (m, { jagoanproject, text }) => {
  if (!text) return m.reply(`\u203C\uFE0F Harap masukan link TikTok, contoh: .ttcaption https://vt.tiktok.com/...`);
  try {
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F552}", key: m.key } });
    const result = await tiktok2(text);
    if (!result.title) return m.reply("\u274C Caption tidak ditemukan.");
    await jagoanproject.sendMessage(m.chat, {
      text: result.title
    }, { quoted: m });
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } });
  } catch (error) {
    console.error(error);
    m.reply("\u274C Terjadi kesalahan: " + error.message);
  }
};
handler.help = ["ttcaption"];
handler.tags = ["downloader"];
handler.command = /^(ttcaption)$/i;
handler.register = true;
handler.limit = true;
var downloader_tiktokcaption_default = handler;
async function tiktok2(query) {
  try {
    const encodedParams = new URLSearchParams();
    encodedParams.set("url", query);
    encodedParams.set("hd", "1");
    const response = await (0, import_axios.default)({
      method: "POST",
      url: "https://tikwm.com/api/",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Cookie": "current_language=en",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
      },
      data: encodedParams
    });
    const data = response.data.data;
    return {
      title: data.title,
      digg_count: data.digg_count,
      play_count: data.play_count,
      share_count: data.share_count
    };
  } catch (error) {
    console.error("Error fetching TikTok caption:", error);
    throw new Error("Gagal mengambil data dari TikTok.");
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
