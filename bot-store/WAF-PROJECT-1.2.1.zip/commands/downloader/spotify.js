/**
 * downloader/spotify.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/spotify",
  "command": [
    "spotify",
    "spotifydl",
    "spdl"
  ],
  "kind": "download",
  "prefer": {
    "*": "audio"
  },
  "search": {
    "path": "/api/search/spotify",
    "param": "query",
    "example": "tulus hati-hati di jalan"
  },
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
