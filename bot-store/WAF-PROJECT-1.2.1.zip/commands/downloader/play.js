/**
 * downloader/play.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/yt",
  "command": [
    "play",
    "playdl"
  ],
  "kind": "download",
  "prefer": {
    "*": "audio"
  },
  "search": {
    "path": "/api/search/yts",
    "param": "query",
    "example": "kangen band yolanda"
  },
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
