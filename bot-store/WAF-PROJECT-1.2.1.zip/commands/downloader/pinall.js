/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - pinall.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_pinall_exports = {};
__export(downloader_pinall_exports, {
  default: () => downloader_pinall_default
});
module.exports = __toCommonJS(downloader_pinall_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
const pindl = {
  video: async (url) => {
    try {
      let {
        data: html
      } = await import_axios.default.get(url);
      let $ = cheerio.load(html);
      const mediaDataScript = $('script[data-test-id="video-snippet"]');
      if (mediaDataScript.length) {
        const mediaData = JSON.parse(mediaDataScript.html());
        if (mediaData["@type"] === "VideoObject" && mediaData.contentUrl && mediaData.contentUrl.endsWith(".mp4")) {
          return {
            type: "video",
            name: mediaData.name,
            description: mediaData.description,
            contentUrl: mediaData.contentUrl,
            thumbnailUrl: mediaData.thumbnailUrl,
            uploadDate: mediaData.uploadDate,
            duration: mediaData.duration,
            commentCount: mediaData.commentCount,
            likeCount: mediaData.interactionStatistic?.find(
              (stat) => stat.InteractionType["@type"] === "https://schema.org/LikeAction"
            )?.InteractionCount,
            watchCount: mediaData.interactionStatistic?.find(
              (stat) => stat.InteractionType["@type"] === "https://schema.org/WatchAction"
            )?.InteractionCount,
            creator: mediaData.creator?.name,
            creatorUrl: mediaData.creator?.url,
            keywords: mediaData.keywords
          };
        }
      }
      return null;
    } catch (error) {
      return {
        error: "Error fetching video data"
      };
    }
  },
  image: async (url) => {
    try {
      let {
        data: html
      } = await import_axios.default.get(url);
      let $ = cheerio.load(html);
      const mediaDataScript = $('script[data-test-id="leaf-snippet"]');
      if (mediaDataScript.length) {
        const mediaData = JSON.parse(mediaDataScript.html());
        if (mediaData["@type"] === "SocialMediaPosting" && mediaData.image && (mediaData.image.endsWith(".png") || mediaData.image.endsWith(".jpg") || mediaData.image.endsWith(".jpeg") || mediaData.image.endsWith(".webp")) && !mediaData.image.endsWith(".gif")) {
          return {
            type: "image",
            author: mediaData.author?.name,
            authorUrl: mediaData.author?.url,
            headline: mediaData.headline,
            articleBody: mediaData.articleBody,
            image: mediaData.image,
            datePublished: mediaData.datePublished,
            sharedContentUrl: mediaData.sharedContent?.url,
            isRelatedTo: mediaData.isRelatedTo,
            mainEntityOfPage: mediaData.mainEntityOfPage?.["@id"]
          };
        }
      }
      return null;
    } catch (error) {
      return {
        error: "Error fetching image data"
      };
    }
  },
  gif: async (url) => {
    try {
      let {
        data: html
      } = await import_axios.default.get(url);
      let $ = cheerio.load(html);
      const mediaDataScript = $('script[data-test-id="leaf-snippet"]');
      if (mediaDataScript.length) {
        const mediaData = JSON.parse(mediaDataScript.html());
        if (mediaData["@type"] === "SocialMediaPosting" && mediaData.image && mediaData.image.endsWith(".gif")) {
          return {
            type: "gif",
            author: mediaData.author?.name,
            authorUrl: mediaData.author?.url,
            headline: mediaData.headline,
            articleBody: mediaData.articleBody,
            gif: mediaData.image,
            datePublished: mediaData.datePublished,
            sharedContentUrl: mediaData.sharedContent?.url,
            isRelatedTo: mediaData.isRelatedTo,
            mainEntityOfPage: mediaData.mainEntityOfPage?.["@id"]
          };
        }
      }
      return null;
    } catch (error) {
      return {
        error: "Error fetching gif data"
      };
    }
  },
  download: async (urlPin) => {
    let result = await pindl.video(urlPin);
    if (result) return result;
    result = await pindl.image(urlPin);
    if (result) return result;
    result = await pindl.gif(urlPin);
    return result || {
      error: "No media found"
    };
  }
};
const handler = async (m, {
  text
}) => {
  if (!text) throw "Url mana.";
  try {
    const result = await pindl.download(text);
    if (result.error) throw result.error;
    let caption = `done desu
`;
    if (result.type === "video") {
      caption += `\u{1F4F9} *Video Info*:
\u{1F4C4} Nama: ${result.name || "N/A"}
\u{1F517} URL: ${result.contentUrl}
`;
      await jagoanproject.sendMessage(m.chat, {
        video: {
          url: result.contentUrl
        },
        caption
      }, {
        quoted: m
      });
    } else if (result.type === "image") {
      caption += `\u{1F5BC}\uFE0F *Image Info*:
\u{1F4C4} Judul: ${result.headline || "N/A"}
\u{1F517} URL: ${result.image}
`;
      await jagoanproject.sendMessage(m.chat, {
        image: {
          url: result.image
        },
        caption
      }, {
        quoted: m
      });
    } else if (result.type === "gif") {
      caption += `\u{1F39E}\uFE0F *GIF Info*:
\u{1F4C4} Judul: ${result.headline || "N/A"}
\u{1F517} URL: ${result.gif}
`;
      await jagoanproject.sendMessage(m.chat, {
        video: {
          url: result.gif
        },
        caption
      }, {
        quoted: m
      });
    }
  } catch (error) {
    await jagoanproject.sendMessage(m.chat, {
      text: `ada yg slh ${error}`
    }, {
      quoted: m
    });
  }
};
handler.help = ["pinall"];
handler.tags = ["downloader", "premium"];
handler.command = /^(pdl|pinall)$/i;
handler.premium = true;
handler.register = true;
handler.limit = true;
var downloader_pinall_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
