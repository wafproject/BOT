/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - mega.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_mega_exports = {};
__export(downloader_mega_exports, {
  default: () => downloader_mega_default
});
module.exports = __toCommonJS(downloader_mega_exports);
var __megajs_1 = __toESM(require("megajs"));
var import_path = __toESM(require("path"));
const { File } = __megajs_1;
let handler = async (m, { jagoanproject, usedPrefix, command, args }) => {
  let input = `*Format Salah* \u274C
Contoh:

> ${usedPrefix + command} https://mega.nz/file/ex4FAL6C#FvtquKNK5ia8M5oe1ZpFG8e0y4KnMWciqw5RGopxk0g`;
  if (!args[0]) return jagoanproject.sendMessage(m.chat, { text: input }, { quoted: m });
  console.log("Struktur m:", JSON.stringify(m, null, 2));
  let processingMsg;
  try {
    processingMsg = await jagoanproject.sendMessage(m.chat, { text: "\u23F3 _Sedang memproses unduhan, mohon tunggu..._" }, { quoted: m });
  } catch (e) {
    console.error("Gagal mengirim pesan proses:", e);
    return jagoanproject.sendMessage(m.chat, { text: "\u26A0\uFE0F Terjadi kesalahan saat memulai proses." }, { quoted: m });
  }
  try {
    const data = await MegaDl(args[0]);
    if (!data.buffer || !data.name) {
      throw new Error("Gagal mendapatkan file atau nama file tidak valid.");
    }
    const ext = import_path.default.extname(data.name) || "";
    await jagoanproject.sendMessage(m.chat, {
      document: data.buffer,
      fileName: data.name,
      mimetype: ext ? `application/${ext.slice(1)}` : "application/octet-stream"
    }, { quoted: m });
    await jagoanproject.sendMessage(m.chat, { text: `\u2705 _File *${data.name}* berhasil diunduh!_` }, { quoted: m });
  } catch (e) {
    console.error("Error saat mengunduh:", e);
    await jagoanproject.sendMessage(m.chat, { text: `\u274C Error: ${e.message || "Gagal mengunduh file."}` }, { quoted: m });
  } finally {
    if (processingMsg && processingMsg.key) {
      try {
        await jagoanproject.sendMessage(m.chat, { delete: processingMsg.key });
      } catch (e) {
        console.error("Gagal menghapus pesan proses:", e);
      }
    }
  }
};
handler.help = ["megadl <url>"];
handler.tags = ["downloader"];
handler.command = /^(mega|megadl)$/i;
handler.limit = 2;
handler.premium = false;
handler.register = true;
var downloader_mega_default = handler;
async function MegaDl(url) {
  if (!(url && url.match(/mega\.nz/i))) throw new Error("URL tidak valid, pastikan menggunakan link Mega.nz \u{1F517}");
  try {
    const file = File.fromURL(url);
    await file.loadAttributes();
    const buffer = await file.downloadBuffer();
    if (!buffer) throw new Error("Gagal mengunduh file \u{1F4E5}");
    return {
      downloadUrl: url,
      name: file.name,
      fileSize: file.size,
      buffer
    };
  } catch (e) {
    throw new Error(`Gagal memproses file: ${e.message} \u{1F6AB}`);
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
