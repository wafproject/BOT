/**
 * downloader/tiktok.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/tiktok",
  "command": [
    "tt",
    "tiktok",
    "tikmp3"
  ],
  "kind": "download",
  "prefer": {
    "tt": "video",
    "tiktok": "video",
    "tikmp3": "audio"
  },
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
