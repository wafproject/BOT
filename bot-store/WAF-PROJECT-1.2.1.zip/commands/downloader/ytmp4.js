/**
 * downloader/ytmp4.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/yt",
  "command": [
    "ytmp3",
    "ytmp4"
  ],
  "kind": "download",
  "prefer": {
    "ytmp3": "audio",
    "ytmp4": "video"
  },
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
