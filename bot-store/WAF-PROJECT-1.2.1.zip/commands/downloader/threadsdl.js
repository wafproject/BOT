/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - threadsdl.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_threadsdl_exports = {};
__export(downloader_threadsdl_exports, {
  default: () => downloader_threadsdl_default
});
module.exports = __toCommonJS(downloader_threadsdl_exports);
var import_axios = __toESM(require("axios"));
function pickHrefByClass(html, needleRegexFragment) {
  const re = new RegExp(
    `<a[^>]*class="[^"]*${needleRegexFragment}[^"]*"[^>]*href="([^"]+)"`,
    "i"
  );
  const m = html.match(re);
  return m ? m[1] : null;
}
function extractAllHrefs(html) {
  return [...html.matchAll(/<a[^>]*href="([^"]+)"/gi)].map((x) => x[1]);
}
function mergeCookies(setCookieArr) {
  if (!Array.isArray(setCookieArr)) return "";
  return setCookieArr.map((c) => String(c).split(";")[0]).filter(Boolean).join("; ");
}
function pickFirstFormInputName(html) {
  const m = html.match(/<input[^>]+name="([^"]+)"[^>]*(type="text"|type="url"|type="search")/i) || html.match(/<input[^>]+(type="text"|type="url"|type="search")[^>]+name="([^"]+)"/i);
  if (!m) return "url";
  const name = m[1] && !m[1].startsWith("type=") ? m[1] : m[2];
  return name || "url";
}
function extractHiddenInputs(html) {
  const out = {};
  const matches = [...html.matchAll(/<input[^>]+type="hidden"[^>]*>/gi)].map((x) => x[0]);
  for (const tag of matches) {
    const name = (tag.match(/name="([^"]+)"/i) || [])[1];
    const value = (tag.match(/value="([^"]*)"/i) || [])[1] ?? "";
    if (name) out[name] = value;
  }
  return out;
}
function normalizeThreadsUrl(inputUrl) {
  const u = new URL(inputUrl);
  if (u.hostname === "www.threads.com") u.hostname = "www.threads.net";
  if (u.hostname === "threads.com") u.hostname = "threads.net";
  u.search = "";
  return u.toString();
}
async function SaveThrDl(inputUrl) {
  const cleanUrl = normalizeThreadsUrl(inputUrl);
  const client = import_axios.default.create({
    timeout: 3e4,
    validateStatus: () => true,
    headers: {
      "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36",
      "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    }
  });
  try {
    const pre = await client.get("https://savethr.com/id", {
      headers: {
        Referer: "https://savethr.com/"
      }
    });
    const preHtml = typeof pre.data === "string" ? pre.data : String(pre.data);
    const cookie = mergeCookies(pre.headers?.["set-cookie"]);
    const fieldName = pickFirstFormInputName(preHtml);
    const hidden = extractHiddenInputs(preHtml);
    const formObj = { ...hidden };
    formObj[fieldName] = cleanUrl;
    const body = new URLSearchParams(formObj).toString();
    const res = await client.post("https://savethr.com/process", body, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Origin: "https://savethr.com",
        Referer: "https://savethr.com/id",
        // HTMX headers
        "HX-Request": "true",
        "HX-Current-URL": "https://savethr.com/id",
        "HX-Target": "result-container",
        "HX-Trigger": "search-form",
        // cookies hasil GET /id
        ...cookie ? { Cookie: cookie } : {}
      }
    });
    const html = typeof res.data === "string" ? res.data : String(res.data);
    if (html.toLowerCase().includes("something went wrong")) {
      console.log("=== SAVETHR SCRAPE ===");
      console.log("status:", res.status);
      console.log("cleanUrl:", cleanUrl);
      console.log("fieldName:", fieldName);
      console.log("cookie:", cookie ? "[OK]" : "[NONE]");
      console.log("======================");
      throw new Error("Savethr membalas: Something went wrong (kemungkinan butuh token/cookie tambahan atau terblokir).");
    }
    const audio = pickHrefByClass(html, "download_mp3") || pickHrefByClass(html, "\\bmp3\\b") || null;
    let video = pickHrefByClass(html, "download_link") || null;
    if (video && audio && video === audio) {
      const hrefs = extractAllHrefs(html);
      const altVideo = hrefs.find(
        (h) => h.includes("ssscdn.io/savethr/") && h !== audio
      );
      if (altVideo) video = altVideo;
    }
    console.log("=== SAVETHR SCRAPE ===");
    console.log("status:", res.status);
    console.log("cleanUrl:", cleanUrl);
    console.log("fieldName:", fieldName);
    console.log("cookie:", cookie ? "[OK]" : "[NONE]");
    console.log("video:", video);
    console.log("audio:", audio);
    console.log("======================");
    if (!video && !audio) {
      throw new Error(
        `Tidak ditemukan link video/audio.
Cuplikan respons:
${html.slice(0, 900)}...`
      );
    }
    return { video, audio, html, cleanUrl };
  } catch (e) {
    console.error("Error SaveThrDl:", e.message);
    return null;
  }
}
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  const guideMessage = `URL tidak valid! Pastikan Anda menyalin link dengan benar dari Threads.

Contoh:
${usedPrefix}${command} https://www.threads.net/@kiyoeditz/post/DBM2ZfDhNt1

Opsi:
- Kirim video (default): ${usedPrefix}${command} <url>
- Kirim audio/mp3: ${usedPrefix}${command} <url> --audio
- Kirim keduanya: ${usedPrefix}${command} <url> --all`;
  if (!args[0]) {
    throw `Masukkan URL!

Contoh:
${usedPrefix}${command} https://www.threads.net/@kiyoeditz/post/DBM2ZfDhNt1`;
  }
  if (!/\/post\//i.test(args[0])) throw guideMessage;
  const wantAudio = args.includes("--audio") || args.includes("--mp3");
  const wantAll = args.includes("--all");
  jagoanproject.reply(m.chat, `_Sedang memproses, harap tunggu..._`, m);
  const data = await SaveThrDl(args[0]);
  if (!data) throw `Gagal memproses link (savethr tidak mengembalikan data). Coba ulang atau ganti link Threads.`;
  const { video, audio } = data;
  await m.reply("_Sedang mengirim file..._");
  if (!wantAudio || wantAll) {
    if (video) {
      await jagoanproject.sendFile(
        m.chat,
        video,
        "threads.mp4",
        "",
        m,
        null,
        {
          asDocument: global.db.data?.users?.[m.sender]?.useDocument || false,
          headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36",
            Referer: "https://savethr.com/",
            Accept: "*/*"
          }
        }
      );
    } else if (!wantAudio) {
      throw `Video tidak tersedia dari sumber ini. Coba gunakan opsi --audio jika hanya audionya yang ada.`;
    }
  }
  if (wantAudio || wantAll) {
    if (audio) {
      await jagoanproject.sendFile(
        m.chat,
        audio,
        "threads.mp3",
        "",
        m,
        null,
        {
          asDocument: global.db.data?.users?.[m.sender]?.useDocument || false,
          headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36",
            Referer: "https://savethr.com/",
            Accept: "*/*"
          }
        }
      );
    } else if (wantAudio) {
      throw `Audio tidak tersedia dari sumber ini (mp3 tidak ditemukan).`;
    }
  }
};
handler.help = ["threads"];
handler.command = /^(threads)$/i;
handler.tags = ["downloader"];
handler.limit = true;
handler.group = false;
handler.premium = false;
handler.register = true;
var downloader_threadsdl_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
