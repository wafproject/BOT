/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - snackvideo.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_snackvideo_exports = {};
__export(downloader_snackvideo_exports, {
  default: () => downloader_snackvideo_default
});
module.exports = __toCommonJS(downloader_snackvideo_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, text, command }) => {
  if (!text) return m.reply("Silakan masukkan URL video untuk DIDOWNLOAD.");
  try {
    const result = await downloadSnackVideo(text);
    let message = `
\u{1F3A5} *SnackVideo Download!* \u{1F3A5}
-  Title: ${result.metadata.title}
-  Uploaded: ${result.metadata.uploaded}
-  Likes: ${result.metadata.likes}
-  Views: ${result.metadata.watch}
-  Comments: ${result.metadata.comment}
-  Shares: ${result.metadata.share}
-  Author: ${result.metadata.author}
        `;
    m.reply(message);
    await jagoanproject.sendFile(m.chat, result.download, "snackvideo.mp4", null, m);
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan saat memproses permintaan Anda.");
  }
};
handler.command = /^(snackvideo-download|snackdl)$/i;
handler.help = ["snackvideo-download <URL>"];
handler.tags = ["fun"];
handler.limit = true;
handler.register = true;
var downloader_snackvideo_default = handler;
async function downloadSnackVideo(url) {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await import_axios.default.get(url);
      const $ = cheerio.load(response.data);
      let result = {
        metadata: {},
        download: null
      };
      const json = JSON.parse($("#VideoObject").text().trim());
      result.metadata.title = json.name;
      result.metadata.thumbnail = json.thumbnailUrl[0];
      result.metadata.uploaded = new Date(json.uploadDate).toLocaleString();
      result.metadata.comment = json.commentCount;
      result.metadata.watch = json.interactionStatistic[0].userInteractionCount;
      result.metadata.likes = json.interactionStatistic[1].userInteractionCount;
      result.metadata.share = json.interactionStatistic[2].userInteractionCount;
      result.metadata.author = json.creator.mainEntity.name;
      result.download = json.contentUrl;
      resolve(result);
    } catch (error) {
      reject({ msg: error.message });
    }
  });
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
