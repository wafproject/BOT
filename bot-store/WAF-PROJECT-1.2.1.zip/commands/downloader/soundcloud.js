/**
 * downloader/soundcloud.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/soundcloud",
  "command": [
    "soundcloud",
    "scloud"
  ],
  "kind": "download",
  "prefer": {
    "*": "audio"
  },
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
