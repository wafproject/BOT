/**
 * downloader/twitter.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/twitter",
  "command": [
    "twitter",
    "twdl",
    "twvid"
  ],
  "kind": "download",
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
