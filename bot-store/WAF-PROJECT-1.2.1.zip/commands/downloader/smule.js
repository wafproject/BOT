/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - smule.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_smule_exports = {};
__export(downloader_smule_exports, {
  default: () => downloader_smule_default
});
module.exports = __toCommonJS(downloader_smule_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, usedPrefix, command, args }) => {
  let input = `*[ ! ] Parameter tidak tepat* \u{1F615}

Contoh: ${usedPrefix + command} https://www.smule.com/recording/sample-song/123456789`;
  if (!args[0]) return jagoanproject.reply(m.chat, input, m);
  jagoanproject.reply(m.chat, "_Mohon Tunggu, sedang memproses..._ \u23F3", m.key);
  try {
    const res = await smuleDownloader(args[0]);
    if (!res.status) throw res.message;
    const caption = `\u{1F3B5} *${res.data.metadata.title}* \u{1F3B5}

\u{1F517} *Link*: ${res.data.metadata.smule_link}
\u{1F4DD} *Deskripsi*: ${res.data.metadata.description}`;
    if (res.data.metadata.thumbnail) {
      await jagoanproject.sendMessage(
        m.chat,
        {
          image: { url: res.data.metadata.thumbnail },
          caption
        },
        { quoted: m }
      );
    } else {
      await jagoanproject.reply(m.chat, caption, m);
    }
    if (res.data.audio.mp3 && res.data.audio.mp3 !== "Tidak ditemukan link audio mp3") {
      await jagoanproject.sendMessage(
        m.chat,
        {
          document: { url: res.data.audio.mp3 },
          fileName: `${res.data.metadata.title}.mp3`,
          mimetype: "audio/mp3"
        },
        { quoted: m }
      );
    }
    if (res.data.video.mp4 && res.data.video.mp4 !== "Tidak ditemukan link video mp4") {
      await jagoanproject.sendMessage(
        m.chat,
        {
          video: { url: res.data.video.mp4 },
          caption: `\u{1F3AC} Video: *${res.data.metadata.title}*`,
          mimetype: "video/mp4"
        },
        { quoted: m }
      );
    }
  } catch (error) {
    await jagoanproject.reply(m.chat, `\u274C Error: ${error.message} \u{1F613}`, m);
  }
};
handler.help = ["smule <link>"];
handler.tags = ["downloader"];
handler.command = /^(smule)$/i;
handler.limit = 2;
handler.premium = false;
handler.register = true;
var downloader_smule_default = handler;
async function smuleDownloader(smuleUrl) {
  if (!smuleUrl || !smuleUrl.match(/smule\.com/i)) {
    return {
      status: false,
      message: "URL Smule tidak valid"
    };
  }
  const targetUrl = `https://sownloader.com/index.php?url=${encodeURIComponent(smuleUrl)}`;
  try {
    const response = await import_axios.default.get(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
      }
    });
    const $ = cheerio.load(response.data);
    const title = $("h4 a").first().text().trim() || "Tidak ditemukan judul";
    const smuleLink = $("h4 a").attr("href") || smuleUrl;
    const thumbnail = $(".sownloader-web-thumbnail").attr("src") || "";
    const description = $(".sownloader-web-thumbnail").closest(".row").find("p").first().text().trim() || "Tidak ada deskripsi";
    let audioMp3 = "";
    const mp3Button = $("button.btn:contains('Download as MP3')").attr("onclick");
    if (mp3Button) {
      const match = mp3Button.match(/'(https?:\/\/[^']+\.m4a)'/);
      if (match) {
        audioMp3 = `https://sownloader.com/system/modules/downloader.php?url=${encodeURIComponent(
          match[1]
        )}&name=${encodeURIComponent(title)}&ext=mp3`;
      }
    }
    let videoMp4 = $("a.btn[href*='.mp4']").attr("href") || "";
    if (videoMp4 && videoMp4.startsWith("/")) {
      videoMp4 = `https://sownloader.com${videoMp4}`;
    }
    return {
      status: true,
      message: "Berhasil mengambil data dari Smule",
      data: {
        metadata: {
          title,
          smule_link: smuleLink,
          thumbnail,
          description
        },
        audio: {
          mp3: audioMp3 || "Tidak ditemukan link audio mp3"
        },
        video: {
          mp4: videoMp4 || "Tidak ditemukan link video mp4"
        }
      }
    };
  } catch (error) {
    return {
      status: false,
      message: `Gagal mengambil data: ${error.message}`
    };
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
