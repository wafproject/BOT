/**
 * downloader/pindl.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/search/pinterest",
  "command": [
    "pindl"
  ],
  "kind": "text",
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
