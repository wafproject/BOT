/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - npmdl.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_npmdl_exports = {};
__export(downloader_npmdl_exports, {
  default: () => downloader_npmdl_default
});
module.exports = __toCommonJS(downloader_npmdl_exports);
var __stream_1 = __toESM(require("stream"));
var __util_2 = __toESM(require("util"));
var import_node_fetch = __toESM(require("node-fetch"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const { pipeline } = __stream_1;
const { promisify } = __util_2;
const streamPipeline = promisify(pipeline);
let handler = async (m, { args, usedPrefix, command }) => {
  if (!args[0]) throw `Masukkan nama paket NPM, contoh:
${usedPrefix + command} express`;
  let packageName = args[0].trim();
  let encodedName = encodeURIComponent(packageName);
  let registryUrl = `https://registry.npmjs.org/${encodedName}/-/${packageName}-latest.tgz`;
  let fileName = `${packageName}-latest.tgz`;
  let filePath = import_path.default.join(__dirname, "../../tmp", fileName);
  if (!import_fs.default.existsSync(import_path.default.dirname(filePath))) {
    import_fs.default.mkdirSync(import_path.default.dirname(filePath), { recursive: true });
  }
  try {
    m.reply(`\u{1F4E5} Sedang mengunduh paket NPM *${packageName}@latest*...`);
    const response = await (0, import_node_fetch.default)(registryUrl);
    if (!response.ok) {
      const metaRes = await (0, import_node_fetch.default)(`https://registry.npmjs.org/${encodedName}`);
      if (!metaRes.ok) throw `\u274C Paket *${packageName}* tidak ditemukan di NPM!`;
      const meta = await metaRes.json();
      const latestVersion = meta["dist-tags"].latest;
      const tarballUrl = meta.versions[latestVersion].dist.tarball;
      const newFileName = `${packageName}-${latestVersion}.tgz`;
      filePath = import_path.default.join(__dirname, "../../tmp", newFileName);
      const tarballRes = await (0, import_node_fetch.default)(tarballUrl);
      if (!tarballRes.ok) throw `\u274C Gagal mengunduh *${packageName}@${latestVersion}*`;
      await streamPipeline(tarballRes.body, import_fs.default.createWriteStream(filePath));
      let buffer = import_fs.default.readFileSync(filePath);
      await jagoanproject.sendMessage(m.chat, {
        document: buffer,
        fileName: newFileName,
        mimetype: "application/gzip",
        caption: `\u2705 Berhasil mengunduh *${packageName}@${latestVersion}*
\u{1F4E6} File: \`${newFileName}\``
      }, { quoted: m });
    } else {
      await streamPipeline(response.body, import_fs.default.createWriteStream(filePath));
      let buffer = import_fs.default.readFileSync(filePath);
      await jagoanproject.sendMessage(m.chat, {
        document: buffer,
        fileName,
        mimetype: "application/gzip",
        caption: `\u2705 Berhasil mengunduh *${packageName}@latest*
\u{1F4E6} File: \`${fileName}\``
      }, { quoted: m });
    }
    import_fs.default.unlink(filePath, (err) => {
      if (err) console.error("Gagal hapus file:", err);
    });
  } catch (err) {
    m.reply("\u274C Gagal memproses: " + err.message || err);
  }
};
handler.help = ["npmclone <paket>"];
handler.tags = ["downloader", "premium"];
handler.command = /^npmclone|npmdl$/i;
handler.limit = true;
handler.register = true;
handler.premium = true;
var downloader_npmdl_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
