/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - moewalls.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_moewalls_exports = {};
__export(downloader_moewalls_exports, {
  default: () => downloader_moewalls_default
});
module.exports = __toCommonJS(downloader_moewalls_exports);
let __moewalls_mod = null;
async function __load___moewalls_mod() {
  if (__moewalls_mod) return __moewalls_mod;
  try {
    __moewalls_mod = await import("../../lib/jagoan/lib/moewalls.js");
  } catch (e) {
    __moewalls_mod = { __err: e };
  }
  return __moewalls_mod;
}
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  const __m = await __load___moewalls_mod();
  if (__m?.__err) return m.reply("Fitur ini error: dependency gagal dimuat.");
  const moewalls = __m.default;
  if (!text) {
    throw `Masukkan teks dan angka dengan pemisah sebagai index

Contoh:
${usedPrefix}${command} elaina|1

*index bisa membanyak hasil yang ditemukan.*`;
  }
  const query = text.split("|")[0]?.trim();
  const pageInput = text.split("|")[1]?.trim() || "1";
  const index = parseInt(pageInput, 10) - 1;
  if (!query) {
    throw `Masukkan kata kunci pencarian.

Contoh:
${usedPrefix}${command} elaina|1`;
  }
  if (isNaN(index) || index < 0) {
    throw `Index tidak valid. Contoh penggunaan:
${usedPrefix}${command} elaina|1`;
  }
  try {
    await jagoanproject.reply(m.chat, `_Sedang memproses, harap tunggu..._`, m);
    const res = await moewalls(query);
    if (!res || res.error) {
      throw new Error(res?.error || "Gagal mengambil data dari Moewalls.");
    }
    if (!res.wallpapers || !res.wallpapers.length) {
      return m.reply(`Hasil untuk *${query}* tidak ditemukan.`);
    }
    if (!res.wallpapers[index]) {
      return m.reply(
        `Index tidak ditemukan.

Total hasil: *${res.total}*
Gunakan index dari *1* sampai *${res.total}*.`
      );
    }
    const item = res.wallpapers[index];
    if (!item.video) {
      return m.reply(
        `Video untuk hasil index *${index + 1}* tidak ditemukan.
Coba gunakan index lain.`
      );
    }
    let capt = `\u256D\u2500\u2500\u2500\u2500 \u3014MOEWALLS\u3015 \u2500\u2B23
`;
    capt += ` \u2B21 *Pencarian* : ${res.query}
`;
    capt += ` \u2B21 *Total* : ${res.total}
`;
    capt += `\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2B23
`;
    capt += ` \u2B21 *Judul* : ${item.title}
`;
    capt += ` \u2B21 *Source* : ${item.source}
`;
    capt += ` \u2B21 *Menampilkan* : ${item.index} - ${res.total}
`;
    await jagoanproject.sendMessage(
      m.chat,
      {
        video: { url: item.video },
        caption: capt
      },
      { quoted: m }
    );
  } catch (e) {
    throw `Error: ${e.message || e}`;
  }
};
handler.help = ["moewalls"];
handler.command = /^(moewalls)$/i;
handler.tags = ["downloader"];
handler.premium = false;
handler.register = true;
handler.limit = true;
var downloader_moewalls_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
