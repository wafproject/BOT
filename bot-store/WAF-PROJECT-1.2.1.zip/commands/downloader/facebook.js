/**
 * downloader/facebook.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/download/fbdown",
  "command": [
    "fb",
    "fbdl"
  ],
  "kind": "download",
  "prefer": {
    "*": "video"
  },
  "category": "downloader"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
