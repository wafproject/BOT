/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - applemusic.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_applemusic_exports = {};
__export(downloader_applemusic_exports, {
  default: () => downloader_applemusic_default
});
module.exports = __toCommonJS(downloader_applemusic_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
const handler = async (m, { jagoanproject, command, text, usedPrefix }) => {
  if (!text) {
    throw `*\u2022 Example :* ${usedPrefix + command} *[judul lagu]*`;
  }
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  try {
    const appleMusic = new AppleMusic();
    const searchResults = await appleMusic.search(text);
    if (!searchResults.length) {
      throw new Error("Tidak ditemukan hasil untuk pencarian ini.");
    }
    const songInfo = searchResults[0];
    const downloadInfo = await appleMusic.download(songInfo.song);
    if (!downloadInfo.download) {
      throw new Error("Gagal mendownload lagu.");
    }
    await jagoanproject.sendMessage(m.chat, {
      audio: { url: downloadInfo.download },
      mimetype: "audio/mpeg",
      fileName: `${songInfo.title}.mp3`
    }, { quoted: m });
  } catch (error) {
    console.error(error);
    await jagoanproject.sendMessage(m.chat, global.eror, { quoted: m });
  }
};
handler.help = ["applemusic"].map((v) => v + " *query*");
handler.tags = ["downloader"];
handler.command = /^(applemusic)$/i;
handler.register = true;
handler.limit = true;
var downloader_applemusic_default = handler;
class AppleMusic {
  // Fungsi untuk mencari lagu berdasarkan kata kunci
  search = async function search(q) {
    return new Promise(async (resolve, reject) => {
      await import_axios.default.get("https://music.apple.com/id/search?term=" + encodeURIComponent(q)).then((a) => {
        let $ = cheerio.load(a.data);
        let array = [];
        $(".shelf-grid__body ul li .track-lockup").each((a2, i) => {
          let title = $(i).find(".track-lockup__content li").eq(0).find("a").text().trim();
          let album = $(i).find(".track-lockup__content li").eq(0).find("a").attr("href");
          let crop = $(i).find(".track-lockup__content li").eq(0).find("a").attr("href").split("/").pop();
          let song = album.replace(crop, "").trim().replace("/album/", "/song/").trim() + album.split("i=")[1];
          let image = $(i).find(".svelte-3e3mdo source").eq(1).attr("srcset").split(",")[1].split(" ")[0].trim();
          let artist = {
            name: $(i).find(".track-lockup__content li").eq(1).find("a").text().trim(),
            url: $(i).find(".track-lockup__content li").eq(1).find("a").attr("href")
          };
          array.push({
            title,
            image,
            song,
            artist
          });
        });
        resolve(array);
      });
    });
  };
  // Fungsi untuk mengunduh lagu
  download = async function download(url) {
    return new Promise(async (resolve, reject) => {
      import_axios.default.get(url).then(async (a) => {
        let $ = cheerio.load(a.data);
        let json = JSON.parse($("script").eq(0).text());
        let info = {
          metadata: {},
          download: {}
        };
        delete json.audio["@type"];
        delete json.audio.audio;
        delete json.audio.inAlbum["@type"];
        delete json.audio.inAlbum.byArtist;
        json.audio.artist = json.audio.byArtist[0];
        delete json.audio.artist["@type"];
        delete json.audio.byArtist;
        info.metadata = json.audio;
        let {
          data
        } = await import_axios.default.get("https://aaplmusicdownloader.com/api/composer/ytsearch/mytsearch.php", {
          params: {
            name: info.metadata.name,
            artist: info.metadata.artist.name,
            album: info.metadata.inAlbum.name,
            link: info.metadata.url
          }
        }).catch((e) => e.response);
        if (!data.videoid) return reject(data);
        let download2 = await import_axios.default.get("https://aaplmusicdownloader.com/api/ytdl.php?q=" + data.videoid).catch((e) => e.response);
        info.download = download2.data.dlink;
        resolve(info);
      });
    });
  };
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
