/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/downloader/downloader - playvideo.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var downloader_playvideo_exports = {};
__export(downloader_playvideo_exports, {
  default: () => downloader_playvideo_default
});
module.exports = __toCommonJS(downloader_playvideo_exports);
var import_node_fetch = __toESM(require("node-fetch"));
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`*\u2022 Example :* ${usedPrefix + command} *[query]*`);
  }
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  try {
    const url = `https://ochinpo-helper.hf.space/yt?query=${encodeURIComponent(text)}`;
    const response = await (0, import_node_fetch.default)(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status} ${response.statusText}`);
    }
    const contentType = response.headers.get("content-type") || "";
    const raw = await response.text();
    if (!contentType.includes("application/json")) {
      console.error("Response bukan JSON:", raw.slice(0, 500));
      throw new Error("API mengembalikan HTML / bukan JSON");
    }
    let json;
    try {
      json = JSON.parse(raw);
    } catch (err) {
      console.error("Gagal parse JSON:", raw.slice(0, 500));
      throw new Error("Format JSON tidak valid");
    }
    if (!json.success || !json.result) {
      throw new Error("Failed to fetch video info");
    }
    let { title, duration, views, author, download } = json.result;
    if (!download?.video) {
      throw new Error("Link download video tidak ditemukan");
    }
    let caption = `*\u4E42 P L A Y - V I D E O*

   *\u25E6 Title :* ${title}
   *\u25E6 Duration :* ${duration?.timestamp || "-"}
   *\u25E6 Views :* ${views || "-"}
   *\u25E6 Author :* ${author?.name || "-"}`;
    await jagoanproject.sendFile(
      m.chat,
      download.video,
      `${title}.mp4`,
      caption,
      m
    );
  } catch (e) {
    console.error("PLAYVIDEO ERROR:", e);
    await jagoanproject.sendMessage(m.chat, { ...global.eror, text: `${global.eror.text}

Detail: ${e.message}` }, { quoted: m });
  }
};
handler.help = ["playvideo"].map((v) => v + " *query*");
handler.tags = ["downloader", "premium"];
handler.command = /^(playvid|playvideo)$/i;
handler.premium = true;
handler.register = true;
handler.limit = true;
var downloader_playvideo_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "downloader" }
)
