/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/giveaway/giveaway - bannedgiveaway.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var giveaway_bannedgiveaway_exports = {};
__export(giveaway_bannedgiveaway_exports, {
  default: () => giveaway_bannedgiveaway_default
});
module.exports = __toCommonJS(giveaway_bannedgiveaway_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const ensureDatabaseDir = () => {
  const dir = import_path.default.join(__dirname, "../../database");
  if (!import_fs.default.existsSync(dir)) import_fs.default.mkdirSync(dir, { recursive: true });
};
const bannedPath = () => import_path.default.join(__dirname, "../../database/giveaway_banned.json");
const giveawaysPath = () => import_path.default.join(__dirname, "../../database/giveaways.json");
const loadJSON = (filePath, fallback) => {
  try {
    if (import_fs.default.existsSync(filePath)) return JSON.parse(import_fs.default.readFileSync(filePath, "utf8"));
    return fallback;
  } catch (e) {
    console.error("Error loading JSON:", filePath, e);
    return fallback;
  }
};
const saveJSON = (filePath, data) => {
  try {
    ensureDatabaseDir();
    import_fs.default.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("Error saving JSON:", filePath, e);
  }
};
let handler = async (m, { jagoanproject, usedPrefix }) => {
  const id = m.chat;
  const target = m.quoted && (m.quoted.sender || m.quoted.participant) || m.mentionedJid && m.mentionedJid[0];
  if (!target) {
    throw `\u203C\uFE0F *FORMAT SALAH*

\u2013 Reply pesan user atau mention user.
\u{1F4DD} Contoh:
\u2013 reply user: ${usedPrefix}bannedgiveaway
\u2013 mention: ${usedPrefix}bannedgiveaway @user`;
  }
  const bannedDB = loadJSON(bannedPath(), {});
  if (!Array.isArray(bannedDB[id])) bannedDB[id] = [];
  if (bannedDB[id].includes(target)) {
    throw `\u203C\uFE0F User @${target.split("@")[0]} sudah *dibanned* dari giveaway.`;
  }
  bannedDB[id].push(target);
  saveJSON(bannedPath(), bannedDB);
  const giveaways = loadJSON(giveawaysPath(), {});
  let removed = false;
  if (giveaways[id] && Array.isArray(giveaways[id][1])) {
    const before = giveaways[id][1].length;
    giveaways[id][1] = giveaways[id][1].filter((jid) => jid !== target);
    removed = giveaways[id][1].length !== before;
    if (removed) saveJSON(giveawaysPath(), giveaways);
  }
  return jagoanproject.reply(
    m.chat,
    `\u2705 *BAN GIVEAWAY BERHASIL*

\u2013 User: @${target.split("@")[0]}
\u2013 Status: diblokir ikut giveaway
\u2013 Auto keluarkan dari peserta: *${removed ? "YA" : "TIDAK / belum ikut"}*`,
    m,
    { contextInfo: { mentionedJid: [target] } }
  );
};
handler.help = ["bannedgiveaway"];
handler.tags = ["giveaway"];
handler.command = /^bannedgiveaway|banga$/i;
handler.group = true;
handler.admin = true;
handler.register = true;
handler.limit = true;
var giveaway_bannedgiveaway_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "giveaway" }
)
