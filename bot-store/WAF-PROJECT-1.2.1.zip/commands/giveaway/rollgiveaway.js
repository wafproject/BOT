/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/giveaway/giveaway - rollgiveaway.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var giveaway_rollgiveaway_exports = {};
__export(giveaway_rollgiveaway_exports, {
  default: () => giveaway_rollgiveaway_default
});
module.exports = __toCommonJS(giveaway_rollgiveaway_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const ensureDatabaseDir = () => {
  const dir = import_path.default.join(__dirname, "../../database");
  if (!import_fs.default.existsSync(dir)) {
    import_fs.default.mkdirSync(dir, { recursive: true });
  }
};
const loadGiveaways = () => {
  const filePath = import_path.default.join(__dirname, "../../database/giveaways.json");
  try {
    if (import_fs.default.existsSync(filePath)) {
      const data = import_fs.default.readFileSync(filePath, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (err) {
    console.error("Error loading giveaways:", err);
    return {};
  }
};
const saveGiveaways = (giveaways) => {
  const filePath = import_path.default.join(__dirname, "../../database/giveaways.json");
  try {
    ensureDatabaseDir();
    import_fs.default.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), "utf8");
  } catch (err) {
    console.error("Error saving giveaways:", err);
  }
};
let handler = async (m, { jagoanproject, usedPrefix }) => {
  jagoanproject.giveway = loadGiveaways();
  let id = m.chat;
  if (!(id in jagoanproject.giveway)) throw `\u203C\uFE0F *UPSS!! TIDAK BISA*

\u2013 tidak ada giveaway yang sedang berlangsung di group ini, untuk memulai giveaway ikuti contoh dibawah ini.
\u{1F4DD} Contoh penggunaan :

\u2013 ${usedPrefix}mulaigiveaway akun epep`;
  let d = /* @__PURE__ */ new Date();
  let date = d.toLocaleDateString("id", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
  let absen = jagoanproject.giveway[id][1];
  shuffleArray(absen);
  if (absen.length === 0) throw "*tidak ada peserta yang tersisa!*";
  let totalParticipants = absen.length;
  let cita = absen.shift();
  let tag = `@${cita.split`@`[0]}`;
  let prize = jagoanproject.giveway[id][2];
  let loadd = [
    "\u25A0\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1 10%",
    // '■■□□□□□□□□ 20%',
    // '■■■□□□□□□□ 30%',
    "\u25A0\u25A0\u25A0\u25A0\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1 40%",
    // '■■■■■□□□□□ 50%',
    // '■■■■■■□□□□ 60%',
    "\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A1\u25A1\u25A1 70%",
    // '■■■■■■■■□□ 80%',
    "\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A1 90%",
    "\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0 100%",
    "*\u2705 LAODING COMPLETE*"
  ];
  let { key } = await jagoanproject.sendMessage(m.chat, { text: "*\u267B\uFE0F Mengacak pemenang..*" });
  for (let i = 0; i < loadd.length; i++) {
    await sleep(1e3);
    await jagoanproject.sendMessage(m.chat, { text: loadd[i], edit: key });
  }
  let fakeMessages = [
    `Apakah @${cita.split`@`[0]} yang menang??\u{1F914}\u{1F914}`,
    `Oh bukann\u{1F601}, acak lagiii ahhh...`,
    `Apakah @${cita.split`@`[0]} yang menang? \u{1F62D} Hmmm, dari tampangnya keknya gak cocok deh`,
    `Kalau @${cita.split`@`[0]}? Kayaknya masih bukan deh, acak lagi ahh.. terakhir nih guys...\u{1F602} `
  ];
  let remainingAbsens = [...absen];
  const getRandomParticipant = () => {
    if (remainingAbsens.length === 0) return null;
    let randomIndex = Math.floor(Math.random() * remainingAbsens.length);
    let randomParticipant = remainingAbsens.splice(randomIndex, 1)[0];
    return randomParticipant;
  };
  for (let message of fakeMessages) {
    let randomParticipant = getRandomParticipant();
    if (randomParticipant) {
      let tagRandomParticipant = `@${randomParticipant.split`@`[0]}`;
      await jagoanproject.sendMessage(m.chat, {
        text: message.replace("@" + cita.split`@`[0], tagRandomParticipant),
        contextInfo: { mentionedJid: [randomParticipant] }
      });
    }
    await sleep(7e3);
  }
  await sleep(5e3);
  let remainingParticipants = absen.length;
  jagoanproject.giveway[id][1] = absen;
  saveGiveaways(jagoanproject.giveway);
  return jagoanproject.reply(m.chat, `\u{1F38A} *CONGRATULATIONS* \u{1F38A}

\u2013 Selamat kepada ${tag}, kamu adalah pemenang giveaway dengan hadiah *${prize}* dari ${totalParticipants} peserta.

\u2013 \u{1F934}\u{1F3FB} Pemenang: ${tag}
\u2013 \u{1F381} Hadiah: ${prize}
\u2013 \u{1F4C6} Tanggal: ${date}
\u2013 \u{1F468}\u200D\u{1F468}\u200D\u{1F467}\u200D\u{1F466} Sisa peserta: ${remainingParticipants}
\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014
*\u{1F4DD} NOTE:* Hapus giveaway setelah selesai dengan cara ketik *.hapusgiveaway*`, m, { contextInfo: { mentionedJid: [cita] } });
};
handler.help = ["rollgiveaway"];
handler.tags = ["giveaway"];
handler.command = /^(rolling|rollgiveaway|rollinggiveaway)$/i;
handler.admin = true;
handler.register = true;
handler.limit = true;
var giveaway_rollgiveaway_default = handler;
const sleep = (ms) => {
  return new Promise((resolve) => setTimeout(resolve, ms));
};
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "giveaway" }
)
