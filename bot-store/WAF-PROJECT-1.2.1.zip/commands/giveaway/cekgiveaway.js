/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/giveaway/giveaway - cekgiveaway.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var giveaway_cekgiveaway_exports = {};
__export(giveaway_cekgiveaway_exports, {
  default: () => giveaway_cekgiveaway_default
});
module.exports = __toCommonJS(giveaway_cekgiveaway_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const loadBannedGiveaway = () => {
  const filePath = import_path.default.join(__dirname, "../../database/giveaway_banned.json");
  try {
    if (import_fs.default.existsSync(filePath)) {
      const data = import_fs.default.readFileSync(filePath, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (err) {
    console.error("Error loading giveaway banned list:", err);
    return {};
  }
};
const loadGiveaways = () => {
  const filePath = import_path.default.join(__dirname, "../../database/giveaways.json");
  try {
    if (import_fs.default.existsSync(filePath)) {
      const data = import_fs.default.readFileSync(filePath, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (err) {
    console.error("Error loading giveaways:", err);
    return {};
  }
};
let handler = async (m, { jagoanproject, usedPrefix }) => {
  jagoanproject.giveway = loadGiveaways();
  let id = m.chat;
  if (!(id in jagoanproject.giveway)) throw `\u203C\uFE0F *UPSS!! TIDAK BISA*

\u2013 tidak ada giveaway yang sedang berlangsung di group ini, untuk memulai giveaway ikuti contoh dibawah ini.
\u{1F4DD} Contoh penggunaan :

\u2013 ${usedPrefix}mulaigiveaway akun epep`;
  let d = /* @__PURE__ */ new Date();
  let date = d.toLocaleDateString("id", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
  let absen = jagoanproject.giveway[id][1];
  const bannedDB = loadBannedGiveaway();
  const bannedList = Array.isArray(bannedDB[id]) ? bannedDB[id] : [];
  const pesertaValid = absen.filter((jid) => !bannedList.includes(jid));
  shuffleArray(pesertaValid);
  let list = pesertaValid.length ? pesertaValid.map((v, i) => `${i + 1}. @${v.split`@`[0]}`).join("\n") : "*Belum ada peserta*";
  let bannedText = bannedList.length ? bannedList.map((v, i) => `${i + 1}. @${v.split`@`[0]}`).join("\n") : "*Tidak ada user yang dibanned*";
  let mentioned = [.../* @__PURE__ */ new Set([...pesertaValid, ...bannedList])];
  jagoanproject.reply(m.chat, `*\u{1F6CD}\uFE0F LIST PESERTA GIVEAWAY*

\u2013 \u{1F4C6} tanggal : ${date}
\u2013 \u{1F381} hadiah  : ${jagoanproject.giveway[id][2]}

\u2013 \u{1F468}\u200D\u{1F468}\u200D\u{1F467}\u200D\u{1F466} peserta giveaway :

${list}

\u2013 \u{1F6AB} tidak boleh ikut (banned) :

${bannedText}

> *${global.namebot}*`, m, { contextInfo: { mentionedJid: mentioned } });
};
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
handler.help = ["cekgiveaway"];
handler.tags = ["giveaway"];
handler.command = /^cekgiveaway$/i;
handler.admin = true;
handler.register = true;
handler.limit = true;
var giveaway_cekgiveaway_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "giveaway" }
)
