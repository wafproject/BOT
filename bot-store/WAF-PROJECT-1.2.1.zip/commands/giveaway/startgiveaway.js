/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/giveaway/giveaway - startgiveaway.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var giveaway_startgiveaway_exports = {};
__export(giveaway_startgiveaway_exports, {
  default: () => giveaway_startgiveaway_default
});
module.exports = __toCommonJS(giveaway_startgiveaway_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const { generateWAMessageFromContent, proto } = __zapo_1;
const ensureDatabaseDir = () => {
  const dir = import_path.default.join(__dirname, "../../database");
  if (!import_fs.default.existsSync(dir)) {
    import_fs.default.mkdirSync(dir, { recursive: true });
  }
};
const loadGiveaways = () => {
  const filePath = import_path.default.join(__dirname, "../../database/giveaways.json");
  try {
    if (import_fs.default.existsSync(filePath)) {
      const data = import_fs.default.readFileSync(filePath, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (err) {
    console.error("Error loading giveaways:", err);
    return {};
  }
};
const saveGiveaways = (giveaways) => {
  const filePath = import_path.default.join(__dirname, "../../database/giveaways.json");
  try {
    ensureDatabaseDir();
    import_fs.default.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), "utf8");
  } catch (err) {
    console.error("Error saving giveaways:", err);
  }
};
let handler = async (m, { jagoanproject, usedPrefix, text, command, participants }) => {
  jagoanproject.giveway = loadGiveaways();
  let id = m.chat;
  if (!text) throw `\u203C\uFE0F *FORMAT TIDAK LENGKAP*

\u{1F4DD} Contoh penggunaan :

${usedPrefix + command} GIVEAWAY AKUN PREMIUM`;
  if (id in jagoanproject.giveway) {
    throw `\u203C\uFE0F *ATTENTION*

> masih ada giveaway yang belum selesai di group ini, untuk menghapus giveaway ketik .deletegiveaway`;
  }
  let mentionedJids = participants.map((u) => u.id);
  const giveawayTitle = `\u{1F389} *GIVEAWAY DIMULAI!!*`;
  await jagoanproject.sendMessage(m.chat, { text: giveawayTitle, mentions: mentionedJids }, { quoted: m });
  let listMessage = {
    title: "\u{1F381} CLICK HERE",
    sections: [{
      title: "\u203C\uFE0F SILAHKAN PILIH OPSI DIBAWAH INI",
      rows: [
        {
          title: "\u{1F4CB} IKUT GIVEAWAY",
          id: `${usedPrefix}ikut`,
          description: "\u2570\u2508\u27A4 untuk mengikuti giveaway"
        },
        {
          title: "\u{1F3AF} PILIH PEMENANG",
          id: `${usedPrefix}rollgiveaway`,
          description: "\u2570\u2508\u27A4 untuk mengacak pemenang (khusus admin)."
        },
        {
          title: "\u{1F5D1}\uFE0F HAPUS GIVEAWAY",
          id: `${usedPrefix}deletegiveaway`,
          description: "\u2570\u2508\u27A4 untuk menghapus giveaway (khusus admin)."
        },
        {
          title: "\u{1F465} CEK PESERTA",
          id: `${usedPrefix}cekgiveaway`,
          description: "\u2570\u2508\u27A4 untuk melihat daftar peserta giveaway."
        }
      ]
    }]
  };
  try {
    let msg = generateWAMessageFromContent(m.chat, {
      interactiveMessage: proto.Message.InteractiveMessage.create({
        body: proto.Message.InteractiveMessage.Body.create({
          text: `
\u2013 silahkan klik tombol dibawah untuk melihat opsi giveaway.

\u{1F6CD}\uFE0F *DETAIL GIVEAWAY*
\u2570\u2508\u27A4 ${text}

`
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: "*_Semoga keberuntungan datang padamu kawan \u{1F38A}_*"
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          title: "\u{1F381} GIVEAWAY BERLANGSUNG"
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: JSON.stringify(listMessage)
            }
          ]
        })
      })
    }, { userJid: m.chat, quoted: m });
    await jagoanproject.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  } catch (err) {
    console.error("[ERROR] Gagal mengirim interactive message:", err);
    await jagoanproject.sendMessage(m.chat, {
      text: `\u203C\uFE0F INFORMASI GIVEAWAY*

\u{1F4CB} *.ikut* - bergabung giveaway
\u{1F3AF} *.rollgiveaway* - pilih pemenang
\u{1F5D1}\uFE0F *.deletegiveaway* - hapus giveaway
\u{1F465} *.cekgiveaway* - cek peserta

\u{1F6CD}\uFE0F *DETAIL GIVEAWAY*
\u2570\u2508\u27A4 ${text}

*_Semoga beruntung bang\u{1F38A}_*`
    }, { quoted: m });
  }
  jagoanproject.giveway[id] = [{ text: giveawayTitle, mentions: mentionedJids }, [], text];
  saveGiveaways(jagoanproject.giveway);
};
handler.help = ["mulaigiveaway"];
handler.tags = ["giveaway"];
handler.command = /^(start|mulai)giveaway$/i;
handler.group = true;
handler.admin = true;
handler.register = true;
handler.limit = true;
var giveaway_startgiveaway_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "giveaway" }
)
