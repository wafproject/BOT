/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/giveaway/giveaway - keluargiveaway.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var giveaway_keluargiveaway_exports = {};
__export(giveaway_keluargiveaway_exports, {
  default: () => giveaway_keluargiveaway_default
});
module.exports = __toCommonJS(giveaway_keluargiveaway_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const ensureDatabaseDir = () => {
  const dir = import_path.default.join(__dirname, "../../database");
  if (!import_fs.default.existsSync(dir)) {
    import_fs.default.mkdirSync(dir, { recursive: true });
  }
};
const loadGiveaways = () => {
  const filePath = import_path.default.join(__dirname, "../../database/giveaways.json");
  try {
    if (import_fs.default.existsSync(filePath)) {
      const data = import_fs.default.readFileSync(filePath, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (err) {
    console.error("Error loading giveaways:", err);
    return {};
  }
};
const saveGiveaways = (giveaways) => {
  const filePath = import_path.default.join(__dirname, ".../../database/giveaways.json");
  try {
    ensureDatabaseDir();
    import_fs.default.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), "utf8");
  } catch (err) {
    console.error("Error saving giveaways:", err);
  }
};
let handler = async (m, { jagoanproject, usedPrefix }) => {
  jagoanproject.giveway = loadGiveaways();
  let id = m.chat;
  if (!(id in jagoanproject.giveway)) throw `\u203C\uFE0F *UPSS!! TIDAK BISA*

\u2013 Tidak ada giveaway yang sedang berlangsung di grup ini. Untuk memulai giveaway, gunakan perintah:
\u{1F4DD} Contoh: ${usedPrefix}mulaigiveaway akun epep`;
  let absen = jagoanproject.giveway[id][1];
  const wasParticipant = absen.includes(m.sender);
  if (!wasParticipant) throw "*\u203C\uFE0F KAMU BELUM IKUT GIVEAWAY*\n\n\u2013 Kamu belum terdaftar sebagai peserta giveaway. Gunakan perintah *.ikut* untuk bergabung.";
  jagoanproject.giveway[id][1] = absen.filter((participant) => participant !== m.sender);
  saveGiveaways(jagoanproject.giveway);
  let d = /* @__PURE__ */ new Date();
  let date = d.toLocaleDateString("id", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
  jagoanproject.reply(m.chat, `*\u2705 BERHASIL KELUAR DARI GIVEAWAY*

\u2013 \u{1F4C6} Tanggal: ${date}
\u2013 \u{1F381} Hadiah: ${jagoanproject.giveway[id][2]}

Kamu telah keluar dari daftar peserta giveaway.`, m);
};
handler.help = ["keluargiveaway"];
handler.tags = ["giveaway"];
handler.command = /^(keluargiveaway)$/i;
handler.group = true;
handler.register = true;
handler.limit = true;
var giveaway_keluargiveaway_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "giveaway" }
)
