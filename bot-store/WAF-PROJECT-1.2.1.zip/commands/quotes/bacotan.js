/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/quotes/quotes - bacotan.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var quotes_bacotan_exports = {};
__export(quotes_bacotan_exports, {
  default: () => quotes_bacotan_default
});
module.exports = __toCommonJS(quotes_bacotan_exports);
let handler = async (m) => {
  let bacotan = pickRandom(bacot);
  m.reply(bacotan);
};
handler.help = ["bacot"];
handler.tags = ["quotes"];
handler.command = /^(bacot)$/i;
handler.register = true;
handler.limit = true;
var quotes_bacotan_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
const bacot = [
  "Kamu suka kopi nggak? Aku sih suka. Tau kenapa alesannya? Kopi itu ibarat kamu, pahit sih tapi bikin candu jadi pingin terus.",
  "Gajian itu kayak mantan ya? Bisanya cuman lewat sebentar saja.",
  "Kata pak haji, cowok yang nggak mau pergi Sholat Jumat disuruh pakai rok aja.",
  "Kamu tahu mantan nggak? Mantan itu ibarat gajian, biasa numpang lewat dong di kehidupan kita.",
  "Aku suka kamu, kamu suka dia, tapi dia sayangnya nggak ke kamu. Wkwkw lucu ya? Cinta serumit ini.",
  "Google itu hebat ya? Tapi sayang sehebat-hebatnya Google nggak bisa menemukan jodoh kita.",
  "Terlalu sering memegang pensil alis dapat membuat mata menjadi buta, jika dicolok-colokkan ke mata.",
  "Saya bekerja keras karena sadar kalau uang nggak punya kaki buat jalan sendiri ke kantong saya.",
  "Jika kamu tak mampu meyakinkan dan memukau orang dengan kepintaranmu, bingungkan dia dengan kebodohanmu.",
  "Selelah-lelahnya bekerja, lebih lelah lagi kalau nganggur.",
  "Kita hidup di masa kalau salah kena marah, pas bener dibilang tumben.",
  "Nggak ada bahu pacar? Tenang aja, masih ada bahu jalan buat nyandar.",
  "Mencintai dirimu itu wajar, yang gak wajar mencintai bapakmu.",
  "Katanya enggak bisa bohong. Iyalah, mata kan cuma bisa melihat.",
  "Madu di tangan kananmu, racun di tangan kirimu, jodoh tetap di tangan tuhan.",
  "Selingkuh terjadi bukan karena ada niat, selingkuh terjadi karna pacar kamu masih laku.",
  "Netizen kalau senam jempol di ponsel nggak pakai pendinginan, pantes komennya bikin panas terus.",
  "Jodoh memang enggak kemana, tapi saingannya ada dimana-mana.",
  "Perasaan aku salah terus di matamu. Kalu gitu, besok aku pindah ke hidungmu.",
  "Jomblo tidak perlu malu, jomblo bukan berarti tidak laku, tapi memang tidak ada yang mau.",
  "Jika doamu belum terkabul maka bersabar, ingatlah bahwa yang berdoa bukan cuma kamu!",
  "Masih berharap dan terus berharap lama-lama aku jadi juara harapan.",
  "Manusia boleh berencana, tapi akhirnya saldo juga yang menentukan.",
  "Statusnya rohani, kelakuannya rohalus.",
  "Kegagalan bukan suatu keberhasilan.",
  "Tadi mau makan bakso, cuma kok panas banget, keliatannya baksonya lagi demam.",
  "Aku juga pernah kaya, waktu gajian.",
  "Aku diputusin sama pacar karena kita beda keyakinan. Aku yakin kalau aku ganteng, tapi dia enggak.",
  "Masa depanmu tergantung pada mimpimu, maka perbanyaklah tidur.",
  "Seberat apapun pekerjaanmu, akan semakin ringan jika tidak dibawa.",
  "Jangan terlalu berharap! nanti jatuhnya sakit!",
  "Ingat! Anda itu jomblo",
  "Gak tau mau ngetik apa"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "quotes" }
)
