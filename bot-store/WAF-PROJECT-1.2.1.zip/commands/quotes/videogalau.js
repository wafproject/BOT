/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/quotes/quotes - videogalau.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var quotes_videogalau_exports = {};
__export(quotes_videogalau_exports, {
  default: () => quotes_videogalau_default
});
module.exports = __toCommonJS(quotes_videogalau_exports);
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F552}", key: m.key } });
  jagoanproject.sendFile(m.chat, pickRandom(galau), "galau.mp4", "Nih kak!", m);
};
handler.help = ["videoquotes", "videogalau"];
handler.tags = ["quotes"];
handler.command = /^(videoquotes|videogalau)$/i;
handler.premium = false;
handler.limit = true;
handler.fail = null;
handler.register = true;
var quotes_videogalau_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
const galau = [
  "https://telegra.ph/file/c83205eeeecceb9e4db87.mp4",
  "https://telegra.ph/file/a001c30cafa587a3bef2c.mp4",
  "https://telegra.ph/file/09cf5ac786cbfda551617.mp4",
  "https://telegra.ph/file/e696afd2cfe29a199be11.mp4",
  "https://telegra.ph/file/5be5e3696c03edff2772b.mp4",
  "https://telegra.ph/file/b9b3dece43e557b4addc1.mp4",
  "https://telegra.ph/file/a33e23d6736f8cb40b4fb.mp4",
  "https://telegra.ph/file/3426da3a67bdc0238bd46.mp4",
  "https://telegra.ph/file/394386e5dff94ccff2323.mp4",
  "https://telegra.ph/file/1a1cf22235249f0a459e5.mp4",
  "https://telegra.ph/file/a5578746d1abf176894ed.mp4",
  "https://telegra.ph/file/99dcebf89c97f13f4f657.mp4",
  "https://telegra.ph/file/6a808e89640f23ecfc936.mp4",
  "https://telegra.ph/file/2e35480077a5eae3b2a1e.mp4",
  "https://telegra.ph/file/6c5ba9ed473f188a963b2.mp4",
  "https://telegra.ph/file/0038f0816771d2586b872.mp4",
  "https://telegra.ph/file/946cb25280e747511a707.mp4"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "quotes" }
)
