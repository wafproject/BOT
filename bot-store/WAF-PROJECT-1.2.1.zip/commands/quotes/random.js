/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/quotes/quotes - random.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var quotes_random_exports = {};
__export(quotes_random_exports, {
  default: () => quotes_random_default
});
module.exports = __toCommonJS(quotes_random_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject }) => {
  const result = await quotes();
  if (result) {
    const { quote, author, tags } = result;
    const response = `_${quote}_

~ *${jagoanproject.getName(m.sender)}*`;
    m.reply(response);
  } else {
    console.log("tidak ada kata kata untuk hari ini");
  }
};
handler.help = ["quotes *random quotes*"];
handler.tags = ["quotes"];
handler.command = /^(quotesrandom)$/i;
handler.register = true;
handler.limit = true;
var quotes_random_default = handler;
async function quotes() {
  try {
    const { data } = await import_axios.default.get(`https://quotes.toscrape.com/random`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
      }
    });
    const $ = cheerio.load(data);
    const quoteText = $(".quote .text").text().trim();
    const author = $(".quote .author").text().trim();
    const tags = [];
    $(".quote .tags .tag").each((i, el) => {
      tags.push($(el).text().trim());
    });
    return {
      quote: quoteText,
      author,
      tags
    };
  } catch (error) {
    console.error("Error fetching quote:", error.message);
    return null;
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "quotes" }
)
