/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - ceritahantu.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_ceritahantu_exports = {};
__export(internet_ceritahantu_exports, {
  default: () => internet_ceritahantu_default
});
module.exports = __toCommonJS(internet_ceritahantu_exports);
var cheerio = __toESM(require("cheerio"));
var import_axios = __toESM(require("axios"));
const status = {
  wait: "Please wait while I fetch the stories..."
};
let handler = async (m, { jagoanproject }) => {
  await m.reply(status.wait);
  let res = await ceritahantu();
  let hasil = res.map((v) => {
    return `\u2022 Title: ${v.title}
\u2022 Snippet: ${v.snippet}
\u2022 Image: ${v.image}
\u2022 URL: ${v.url}
    `;
  });
  jagoanproject.reply(m.chat, hasil.join("\n"));
};
handler.command = handler.help = ["ceritahantu", "ceritahoror"];
handler.tags = ["internet"];
handler.limit = true;
handler.register = true;
var internet_ceritahantu_default = handler;
async function ceritahantu() {
  const response = await import_axios.default.get("https://cerita-hantu-nyata.blogspot.com/search?q=Kentang&m=1");
  const $ = cheerio.load(response.data);
  const popularPosts = [];
  $(".item-content").each((index, element) => {
    const post = {};
    post.title = $(element).find(".item-title a").text();
    post.snippet = $(element).find(".item-snippet").text().trim();
    post.image = $(element).find(".item-thumbnail img").attr("src");
    post.url = $(element).find(".item-title a").attr("href");
    popularPosts.push(post);
  });
  return popularPosts;
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
