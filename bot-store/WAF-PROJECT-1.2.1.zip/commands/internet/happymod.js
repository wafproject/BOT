/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - happymod.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_happymod_exports = {};
__export(internet_happymod_exports, {
  default: () => internet_happymod_default
});
module.exports = __toCommonJS(internet_happymod_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
const {
  generateWAMessageContent,
  generateWAMessageFromContent,
  proto
} = __zapo_1;
function formatVersionSize(text = "") {
  const raw = String(text || "").replace(/\*/g, "").replace(/\s+/g, " ").trim();
  let version = "Tidak diketahui";
  let size = "Tidak diketahui";
  const verMatch = raw.match(/\bv?\s*(\d+(?:\.\d+){1,})\b/i);
  const sizeMatch = raw.match(/\b(\d+(?:\.\d+)?)\s*(MB|GB)\b/i);
  if (verMatch) version = verMatch[1];
  if (sizeMatch) size = `${sizeMatch[1]} ${String(sizeMatch[2]).toUpperCase()}`;
  return { version, size };
}
function splitNameAndMeta(name = "") {
  let cleanName = String(name || "").replace(/\*/g, "").replace(/\s+/g, " ").trim();
  const metaMatch = cleanName.match(
    /(\d+(?:\.\d+){1,})\s*\+\s*(\d+(?:\.\d+)?)\s*(MB|GB)/i
  );
  let meta = "";
  if (metaMatch) {
    meta = `${metaMatch[1]} + ${metaMatch[2]} ${metaMatch[3].toUpperCase()}`;
    cleanName = cleanName.replace(metaMatch[0], "").replace(/\s+/g, " ").trim();
  }
  return { cleanName, meta };
}
function prettifyMods(mods = "") {
  let modLabel = String(mods || "").trim() || "Mod tidak terdeteksi";
  const lower = modLabel.toLowerCase();
  if (lower.includes("premium")) return `\u{1F48E} ${modLabel}`;
  if (lower.includes("unlocked")) return `\u{1F513} ${modLabel}`;
  if (lower.includes("remove ads") || lower.includes("no ads")) return `\u{1F6AB}\u{1F4E2} ${modLabel}`;
  if (lower.includes("mod")) return `\u{1F6E0}\uFE0F ${modLabel}`;
  return `\u2728 ${modLabel}`;
}
async function searchHappyModCloud(query) {
  const headers = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36",
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "id,en-US;q=0.9,en;q=0.8",
    Referer: "https://id.happymod.cloud/",
    Connection: "keep-alive"
  };
  let html = "";
  try {
    const postResponse = await import_axios.default.post(
      "https://id.happymod.cloud/search.html",
      `q=${encodeURIComponent(query)}`,
      {
        headers: {
          ...headers,
          "Content-Type": "application/x-www-form-urlencoded",
          Origin: "https://id.happymod.cloud"
        },
        timeout: 3e4
      }
    );
    html = postResponse.data;
  } catch (postErr) {
    console.log("POST gagal:", postErr.message);
  }
  if (!html || html.length < 1e3 || !html.includes("<div")) {
    try {
      const getResponse = await import_axios.default.get(
        `https://id.happymod.cloud/search.html?q=${encodeURIComponent(query)}`,
        { headers, timeout: 3e4 }
      );
      html = getResponse.data;
    } catch (getErr) {
      console.log("GET gagal:", getErr.message);
      return [];
    }
  }
  const $ = cheerio.load(html);
  const results = [];
  const selectors = [
    ".mod-item",
    ".app-item",
    ".list-item",
    "li:has(img)",
    "div:has(img):has(a)",
    "article",
    ".item"
  ];
  selectors.some((sel) => {
    const items = $(sel);
    if (items.length > 0) {
      items.each((_, el) => {
        const $el = $(el);
        let icon = $el.find('img[src*="git99.com"], img[data-src*="git99.com"]').first().attr("src") || $el.find('img[src*="git99.com"], img[data-src*="git99.com"]').first().attr("data-src") || $el.find("img").first().attr("src") || $el.find("img").first().attr("data-src") || $el.find("source").attr("srcset")?.split(",")[0]?.trim().split(" ")[0] || "https://id.happymod.cloud/static/img/logo.webp";
        if (icon && icon.startsWith("//")) icon = "https:" + icon;
        if (icon && !icon.startsWith("http")) {
          icon = "https://id.happymod.cloud" + (icon.startsWith("/") ? "" : "/") + icon;
        }
        let name = $el.find("h3, .title, .app-name, .name, a strong, .entry-title, b, strong").first().text().trim() || $el.find("a").first().text().trim();
        let versionSize = $el.find(".version, .size, small, .info, .text-muted, .details").first().text().trim() || $el.contents().filter(
          (_2, node) => node.type === "text" && /(\d+(?:\.\d+){1,})\s*\+\s*(\d+(?:\.\d+)?)\s*(MB|GB)/i.test(node.data || "")
        ).text().trim();
        const { cleanName, meta } = splitNameAndMeta(name);
        name = cleanName || name;
        if ((!versionSize || versionSize.length < 3) && meta) versionSize = meta;
        let mods = $el.find(
          '.tag, .mod-tag, .label, span:contains("Premium"), span:contains("Unlocked"), span:contains("Mod"), span:contains("Remove ads"), .badge'
        ).map((_2, t) => $(t).text().trim()).get().filter(Boolean).join(", ") || "Mod tidak terdeteksi";
        let url = $el.find("a").first().attr("href");
        if (url) {
          if (!url.startsWith("http"))
            url = "https://id.happymod.cloud" + (url.startsWith("/") ? "" : "/") + url;
        } else {
          url = "https://id.happymod.cloud/";
        }
        if (name && name.length > 3 && !name.includes("HappyMod") && !name.includes("Copyright")) {
          results.push({
            name,
            version_size: versionSize || "",
            mods,
            url,
            icon
          });
        }
      });
      return true;
    }
    return false;
  });
  if (results.length === 0) {
    const lines = html.replace(/<[^>]+>/g, "\n").split(/\n+/).map((l) => l.trim()).filter(Boolean);
    let current = null;
    for (const line of lines) {
      if (line.length > 10 && !/(\d+(?:\.\d+){1,})\s*\+\s*(\d+(?:\.\d+)?)\s*(MB|GB)/i.test(line) && !line.includes("Premium") && !line.includes("Unlocked")) {
        if (current) results.push(current);
        current = { name: line, version_size: "", mods: "", url: "", icon: "" };
      } else if (current) {
        if (/(\d+(?:\.\d+){1,})\s*\+\s*(\d+(?:\.\d+)?)\s*(MB|GB)/i.test(line)) current.version_size = line;
        if (line.includes("Premium") || line.includes("Unlocked") || line.includes("Remove ads") || line.includes("Mod")) {
          current.mods += (current.mods ? ", " : "") + line;
        }
      }
    }
    if (current) results.push(current);
    results.forEach((app) => {
      const { cleanName, meta } = splitNameAndMeta(app.name);
      app.name = cleanName || app.name;
      if (!app.version_size && meta) app.version_size = meta;
      const slug = app.name.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-");
      app.url = `https://id.happymod.cloud/${slug}`;
      app.icon = "https://id.happymod.cloud/static/img/logo.webp";
      if (!app.mods) app.mods = "Mod tidak terdeteksi";
    });
  }
  return results;
}
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  if (!text) return m.reply(`\u2022 *Contoh penggunaan:* ${usedPrefix + command} spotify`);
  await m.reply("*_`Sedang mencari di HappyMod.cloud... tunggu sebentar ya`_**");
  try {
    const data = await searchHappyModCloud(text);
    if (!data.length) {
      return m.reply(`Tidak menemukan hasil untuk "${text}".
Coba kata kunci lain atau periksa ejaan.`);
    }
    const results = data.slice(0, 10);
    const namebot = global.namebot || "Bot Kamu";
    let cards = [];
    let nomor = 1;
    for (const app of results) {
      let imgUrl = app.icon;
      if (!imgUrl || !imgUrl.startsWith("http")) {
        imgUrl = "https://id.happymod.cloud/static/img/logo.webp";
      }
      const { version, size } = formatVersionSize(app.version_size);
      const modLabel = prettifyMods(app.mods);
      cards.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: `\u{1F4E6} *${app.name}*

\u{1F195} *Versi* : ${version}
\u{1F4C1} *Size*  : ${size}

_${modLabel}_
\u{1F517} ${app.url}`
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
          text: namebot
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: `Hasil ke-${nomor++}`,
          hasMediaAttachment: true,
          imageMessage: (await generateWAMessageContent(
            { image: { url: imgUrl } },
            { upload: jagoanproject.waUploadToServer }
          )).imageMessage
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "Buka di HappyMod",
                url: app.url
              })
            }
          ]
        })
      });
    }
    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `*\u{1F50D} Hasil Pencarian HappyMod.cloud*

\u{1F9FE} *Query* : ${text}
\u{1F4CC} *Ditemukan* : ${results.length} hasil`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: namebot
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards
              })
            })
          }
        }
      },
      {}
    );
    await jagoanproject.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  } catch (err) {
    console.error("Error happymodcloud:", err);
    await m.reply("Terjadi kesalahan saat mengambil data dari HappyMod.cloud.\nCoba lagi nanti atau ganti kata kunci.");
  }
};
handler.help = ["happymodcloud", "hmcloud"].map((v) => v + " <query>");
handler.tags = ["internet", "downloader"];
handler.command = /^(happymodcloud|hmcloud)$/i;
handler.register = true;
handler.limit = true;
var internet_happymod_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
