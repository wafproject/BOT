/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - fetch.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_fetch_exports = {};
__export(internet_fetch_exports, {
  default: () => internet_fetch_default
});
module.exports = __toCommonJS(internet_fetch_exports);
var import_node_fetch = __toESM(require("node-fetch"));
var import_util = __toESM(require("util"));
global.API = function(base, path = "/", query = {}, apikeyqueryname) {
  let q = new URLSearchParams(query);
  if (apikeyqueryname) q.append(apikeyqueryname, global.APIKeys?.[base] || "");
  return `${base}${path}?${q}`;
};
let handler = async (m, { text }) => {
  if (!/^https?:\/\//.test(text)) {
    throw "Awali *URL* dengan http:// atau https://";
  }
  try {
    let _url = new URL(text);
    const isS3Url = _url.searchParams.has("X-Amz-Signature");
    let url = text;
    if (!isS3Url && global.API) {
      url = global.API(_url.origin, _url.pathname, Object.fromEntries(_url.searchParams.entries()), "APIKEY");
    }
    if (isS3Url) {
      const amzDate = _url.searchParams.get("X-Amz-Date");
      const expires = parseInt(_url.searchParams.get("X-Amz-Expires") || "0");
      if (amzDate && expires) {
        const urlDate = new Date(
          parseInt(amzDate.slice(0, 4)),
          // Tahun
          parseInt(amzDate.slice(4, 6)) - 1,
          // Bulan (0-based)
          parseInt(amzDate.slice(6, 8)),
          // Hari
          parseInt(amzDate.slice(9, 11)),
          // Jam
          parseInt(amzDate.slice(11, 13)),
          // Menit
          parseInt(amzDate.slice(13, 15))
          // Detik
        );
        const expireTime = urlDate.getTime() + expires * 1e3;
        if (Date.now() > expireTime) {
          throw "URL telah kedaluwarsa";
        }
      }
    }
    let res = await (0, import_node_fetch.default)(url, { timeout: 3e4 });
    if (!res.ok) {
      if (res.status === 403) {
        throw "Akses ditolak (403 Forbidden). Periksa kredensial atau waktu kedaluwarsa URL.";
      }
      throw `Gagal mengambil data dari URL: ${res.status} ${res.statusText}`;
    }
    const contentLength = res.headers.get("content-length");
    if (contentLength && parseInt(contentLength) > 100 * 1024 * 1024 * 1024) {
      throw `Ukuran konten terlalu besar: ${contentLength} bytes`;
    }
    const contentType = res.headers.get("content-type") || "unknown";
    if (!/text|json/.test(contentType)) {
      try {
        return await jagoanproject.sendFile(m.chat, url, "file.mp4", text, m);
      } catch (e) {
        throw `Gagal mengirim file: ${e.message}`;
      }
    }
    let txt = await res.buffer();
    try {
      txt = import_util.default.format(JSON.parse(txt.toString()));
    } catch (e) {
      txt = txt.toString();
    }
    await m.reply(txt.slice(0, 65536));
  } catch (error) {
    await m.reply(`Error: ${error.message || "Terjadi kesalahan saat memproses permintaan"}`);
  }
};
handler.help = ["fetch", "get"].map((v) => v + " <url>");
handler.tags = ["internet"];
handler.command = /^(fetch|get)$/i;
handler.register = true;
handler.limit = true;
var internet_fetch_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
