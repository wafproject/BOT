/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - shuterstock.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_shuterstock_exports = {};
__export(internet_shuterstock_exports, {
  default: () => internet_shuterstock_default
});
module.exports = __toCommonJS(internet_shuterstock_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
async function shutterShockSearch(query) {
  try {
    const { data } = await import_axios.default.get("https://www.shutterstock.com/id/search/" + encodeURIComponent(query), {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
      }
    });
    const $ = cheerio.load(data);
    const results = [];
    $("a.mui-t7xql4-a-inherit-link").each((index, element) => {
      const title = $(element).attr("aria-label");
      const href = $(element).attr("href");
      const imageUrl = $(element).find("img").attr("src");
      if (title && href) {
        results.push({
          title,
          link: `https://www.shutterstock.com${href}`,
          imageUrl: imageUrl || ""
        });
      }
    });
    return results;
  } catch (error) {
    return { error: error.message };
  }
}
const handler = async (m, { text, args, command }) => {
  try {
    if (command === "shutterstock") {
      if (!text) return m.reply("Masukkan kata kunci pencarian! Contoh: .shutterstock anime");
      const results = await shutterShockSearch(text);
      if (!results || results.length === 0) return m.reply(`Tidak ditemukan hasil untuk "${text}".`);
      let response = `\u{1F4F8} Hasil Pencarian Shutterstock untuk "${text}":

`;
      results.slice(0, 5).forEach((item, i) => {
        response += `${i + 1}. **${item.title}**
   \u{1F517} [Lihat Gambar](${item.link})
   ![Image](${item.imageUrl})

`;
      });
      m.reply(response.trim());
    }
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan saat mengambil data.");
  }
};
handler.command = ["shutterstock"];
handler.tags = ["internet"];
handler.limit = true;
handler.register = true;
var internet_shuterstock_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
