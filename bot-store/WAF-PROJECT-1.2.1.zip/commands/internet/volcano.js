/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - volcano.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_volcano_exports = {};
__export(internet_volcano_exports, {
  default: () => internet_volcano_default
});
module.exports = __toCommonJS(internet_volcano_exports);
var import_node_fetch = __toESM(require("node-fetch"));
function levenshtein(a, b) {
  a = a || "";
  b = b || "";
  const m = a.length, n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }
  return dp[m][n];
}
function similarity(a, b) {
  a = (a || "").toLowerCase().trim();
  b = (b || "").toLowerCase().trim();
  if (!a && !b) return 1;
  const dist = levenshtein(a, b);
  const maxLen = Math.max(a.length, b.length) || 1;
  return 1 - dist / maxLen;
}
function rangeLabel(start, end) {
  return `${start}\u2013${end}`;
}
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  if (!jagoanproject) {
    return m.reply("\u{1F342} Error: `jagoanproject` tidak tersedia di plugin ini.");
  }
  const react = async (emoji) => {
    try {
      await jagoanproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
    } catch {
    }
  };
  try {
    await react("\u23F3");
    const res = await (0, import_node_fetch.default)("https://indonesia-public-static-api.vercel.app/api/volcanoes");
    if (!res.ok) throw new Error("Fetch gagal");
    const raw = await res.json();
    if (!Array.isArray(raw) || !raw.length) {
      await react("\u274C");
      return m.reply("\u{1F342} Data gunung berapi tidak tersedia.");
    }
    const max = 150;
    const data = raw.slice(0, max);
    const total = data.length;
    const q = (text || "").trim();
    if (q && /^\d+$/.test(q)) {
      const num = parseInt(q);
      if (isNaN(num) || num < 1 || num > total) {
        await react("\u274C");
        return m.reply(`\u{1F342} *Nomor tidak valid.*
Gunakan angka *1\u2013${total}*`);
      }
      const v = data[num - 1];
      const msg = `\u{1F30B} *DATA GUNUNG BERAPI*

\u{1F522} *Nomor:* ${num}
\u{1F3D4}\uFE0F *Nama:* ${v.nama || "N/A"}
\u{1F9F1} *Bentuk:* ${v.bentuk || "N/A"}
\u{1F4CF} *Tinggi:* ${v.tinggi_meter || "N/A"}
\u{1F525} *Letusan Terakhir:* ${v.estimasi_letusan_terakhir || "N/A"}
\u{1F4CD} *Lokasi:* ${v.geolokasi || "N/A"}

\u2728 *Tips:* ketik *${usedPrefix + command}* untuk list & tombol Next`;
      await m.reply(msg);
      await react("\u{1F389}");
      return;
    }
    let page = 1;
    const pageMatch = q.match(/--page\s+(\d+)/i);
    if (pageMatch) {
      page = parseInt(pageMatch[1]);
      if (isNaN(page) || page < 1) page = 1;
    }
    if (q && !pageMatch) {
      const query = q.toLowerCase();
      const matches = data.map((v, idx) => ({ v, idx: idx + 1 })).filter((x) => (x.v.nama || "").toLowerCase().includes(query));
      if (matches.length) {
        const shown = matches.slice(0, 10);
        const out = shown.map((x) => {
          const v = x.v;
          return `\u{1F50E} *#${x.idx} \u2014 ${v.nama || "Tidak diketahui"}*
\u2022 \u{1F9F1} *Bentuk:* ${v.bentuk || "N/A"}
\u2022 \u{1F4CF} *Tinggi:* ${v.tinggi_meter || "N/A"}
\u2022 \u{1F525} *Letusan Terakhir:* ${v.estimasi_letusan_terakhir || "N/A"}
\u2022 \u{1F4CD} *Lokasi:* ${v.geolokasi || "N/A"}`;
        }).join("\n\n");
        const moreNote = matches.length > 10 ? `

\u{1F4CC} Ada *${matches.length - 10}* hasil lain. Coba query lebih spesifik ya \u{1F642}` : "";
        await m.reply(
          `\u{1F30B} *HASIL PENCARIAN GUNUNG*
\u{1F524} Query: *${q}*
\u{1F4CA} Ditemukan: *${matches.length}*

` + out + moreNote + `

\u2728 *Lihat detail:* ${usedPrefix + command} <nomor>
Contoh: *${usedPrefix + command} ${shown[0].idx}*`
        );
        await react("\u{1F389}");
        return;
      }
      const scored = data.map((v, idx) => ({
        name: v.nama || "",
        idx: idx + 1,
        score: similarity(query, (v.nama || "").toLowerCase())
      })).sort((a, b) => b.score - a.score);
      const suggestions = scored.filter((x) => x.score >= 0.8).slice(0, 5);
      if (suggestions.length) {
        const sugText = suggestions.map((x) => `\u2022 \u2705 *${x.name}* (nomor #${x.idx}, mirip ${(x.score * 100).toFixed(0)}%)`).join("\n");
        await react("\u274C");
        return m.reply(
          `\u{1F342} *Tidak ditemukan:* *${q}*
Tapi ada yang mendekati (\u2265 80%):
${sugText}

\u2728 *Lihat detail:* ${usedPrefix + command} <nomor>
Contoh: *${usedPrefix + command} ${suggestions[0].idx}*`
        );
      }
      await react("\u274C");
      return m.reply(
        `\u{1F342} *Tidak ditemukan:* *${q}*
Coba ejaan lain ya.
\u{1F4CC} Contoh: *${usedPrefix + command} semeru*`
      );
    }
    const pageSize = 10;
    const maxPage = Math.ceil(total / pageSize);
    if (page > maxPage) page = maxPage;
    const startIdx = (page - 1) * pageSize;
    const endIdx = Math.min(startIdx + pageSize, total);
    const list = data.slice(startIdx, endIdx).map((v, i) => {
      const no = startIdx + i + 1;
      return `\u{1F30B} *${no}. ${v.nama || "Tidak diketahui"}*
\u2022 \u{1F9F1} *Bentuk:* ${v.bentuk || "N/A"}
\u2022 \u{1F4CF} *Tinggi:* ${v.tinggi_meter || "N/A"}
\u2022 \u{1F525} *Letusan Terakhir:* ${v.estimasi_letusan_terakhir || "N/A"}
\u2022 \u{1F4CD} *Lokasi:* ${v.geolokasi || "N/A"}`;
    }).join("\n\n");
    const header = `\u{1F4CA} *DAFTAR GUNUNG BERAPI INDONESIA*
\u{1F4C4} Halaman: *${page}/${maxPage}* (${rangeLabel(startIdx + 1, endIdx)})
\u{1F4E6} Total data: *${total}*

`;
    const footer = `

\u2728 *Interaktif:*
\u2022 Ketik *${usedPrefix + command} <nomor>* untuk detail
\u2022 Ketik *${usedPrefix + command} <nama>* untuk cari (tidak case sensitive)
Contoh: *${usedPrefix + command} semeru*`;
    const buttons = [];
    if (page > 1) {
      buttons.push({
        buttonId: `${usedPrefix + command} --page ${page - 1}`,
        buttonText: { displayText: "\u2B05\uFE0F Prev" },
        type: 1
      });
    }
    if (page < maxPage) {
      buttons.push({
        buttonId: `${usedPrefix + command} --page ${page + 1}`,
        buttonText: { displayText: "\u27A1\uFE0F Next" },
        type: 1
      });
    }
    await jagoanproject.sendMessage(
      m.chat,
      {
        text: header + list + footer,
        footer: "\u{1F39B}\uFE0F Tekan tombol untuk pindah halaman",
        buttons: buttons.length ? buttons : void 0,
        headerType: 1
      },
      { quoted: m }
    );
    await react("\u{1F389}");
  } catch (e) {
    console.error("[volcano error]", e);
    await react("\u274C");
    await m.reply("\u{1F342} Terjadi kesalahan saat memproses data.");
  }
};
handler.help = ["volcano"];
handler.tags = ["internet", "information"];
handler.command = /^(volcano)$/i;
handler.limit = false;
handler.register = false;
var internet_volcano_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
