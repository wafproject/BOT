/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - lebaran.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_lebaran_exports = {};
__export(internet_lebaran_exports, {
  default: () => internet_lebaran_default
});
module.exports = __toCommonJS(internet_lebaran_exports);
var import_jid = require("../../lib/jagoan/function/jid.js");
const sentGroups = /* @__PURE__ */ new Set();
let handler = async (m, { jagoanproject }) => {
  if (!jagoanproject) return m.reply("Bot tidak terhubung.");
  const imageUrl = "https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1774012042406.jpeg";
  const lebaranMessage = `\u{1F389} *Alhamdulillah* 

\u062A\u064E\u0642\u064E\u0628\u064E\u0651\u0644\u064E \u0627\u0644\u0644\u064E\u0651\u0647\u064F \u0645\u0650\u0646\u064E\u0651\u0627 \u0648\u064E\u0645\u0650\u0646\u0652\u0643\u064F\u0645\u0652 \u0648\u064E \u062A\u064E\u0642\u064E\u0628\u064E\u0651\u0644\u0652 \u064A\u0627\u064E \u0643\u064E\u0631\u0650\u064A\u0652\u0645\u064F.

"Taqabbalallahu minna wa minkum taqabbal ya karim"

"Semoga Allah menerima amal ibadah kita dan kamu semua, dan terimalah ya (Allah) Yang Maha Mulia"

\u{1F319} Mohon maaf lahir dan batin. Semoga kita semua diberkahi kebahagiaan dan kesehatan! \u{1F64F}\u2728

> Auto Broadcast Lebaran`;
  try {
    const chats = await jagoanproject.groupFetchAllParticipating();
    const chatIds = Object.keys(chats || {});
    if (!chatIds.length) return m.reply("Bot tidak berada di grup manapun.");
    let successCount = 0;
    let skippedCount = 0;
    let failedCount = 0;
    for (const chatId of chatIds) {
      try {
        if (sentGroups.has(chatId)) {
          skippedCount++;
          continue;
        }
        const groupMetadata = chats[chatId];
        if (!groupMetadata?.id || !Array.isArray(groupMetadata?.participants)) {
          failedCount++;
          continue;
        }
        const mentions = [];
        for (const participant of groupMetadata.participants) {
          const normalized = await (0, import_jid.normalizeParticipant)(jagoanproject, participant, {
            groupJid: chatId,
            groupMetadata
          });
          if ((0, import_jid.isPhoneJid)(normalized.id) && !mentions.includes(normalized.id)) mentions.push(normalized.id);
        }
        if (!mentions.length) {
          console.warn(`[LEBARAN] Tidak ada JID nomor yang dapat dipetakan untuk ${chatId}`);
          failedCount++;
          continue;
        }
        await jagoanproject.relayMessage(
          chatId,
          {
            extendedTextMessage: {
              text: lebaranMessage,
              contextInfo: {
                mentionedJid: mentions,
                extendedPreview: {
                  title: "\u2728 Selamat Idul Fitri \u2728",
                  body: "Mohon maaf lahir batin",
                  thumbnailUrl: imageUrl,
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          },
          {}
        );
        const audioUrl = "https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1774012245368.mpeg";
        await jagoanproject.sendMessage(chatId, {
          audio: { url: audioUrl },
          mimetype: "audio/mpeg",
          ptt: true
        }).catch(() => {
        });
        sentGroups.add(chatId);
        successCount++;
        await new Promise((resolve) => setTimeout(resolve, 3e4));
      } catch (error) {
        console.error(`Gagal mengirim ke ${chatId}:`, error?.message || error);
        failedCount++;
      }
    }
    const summary = `\u{1F4CA} *Broadcast Lebaran Selesai*

Total grup target: ${chatIds.length}
\u2713 Berhasil: ${successCount}
\u23ED Dilewati: ${skippedCount}
\u2717 Gagal: ${failedCount}

Mention dikirim hanya kepada anggota yang berhasil dipetakan ke JID nomor.`;
    await jagoanproject.sendMessage(m.chat, { text: summary });
  } catch (error) {
    console.error("Error broadcast Lebaran:", error);
    await jagoanproject.sendMessage(m.chat, { text: `Error: ${error?.message || error}` });
  }
};
handler.command = /^(lebaran)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var internet_lebaran_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
