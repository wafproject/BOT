/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - apksum.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_apksum_exports = {};
__export(internet_apksum_exports, {
  default: () => internet_apksum_default
});
module.exports = __toCommonJS(internet_apksum_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
const handler = async (m, {
  jagoanproject,
  args,
  command
}) => {
  if (!args[0]) {
    return jagoanproject.reply(m.chat, "Metode yang tersedia\n\n- Search <Query>\n- Download <url halamam>", m);
  }
  if (args[0] === "search") {
    const query = args.slice(1).join(" ");
    if (!query) {
      return jagoanproject.reply(m.chat, "Masukkan kata kunci pencarian.\n\n- Contoh: apksum search minecraft", m);
    }
    const baseUrl = "https://m.apksum.com/search?q=";
    const searchUrl = baseUrl + encodeURIComponent(query);
    const cookies = {
      PHPSESSID: "tho2f92d6gqf2bq8j2tqojf5d9",
      _ga: "GA1.1.867180231.1736720071",
      __ppIdCC: "wpjaun_xon21730769976581",
      fpestid: "GZhKMVyVeoQgF_4KDbVyRbKez0hqow4qcGwkMkdgVxp0qVdFtUtk0E7khhDCJfCg2Q2yYA",
      sharedid: "b323af35-e1df-4383-8d41-6dbdb09eb10e",
      sharedid_cst: "zix7LPQsHA==",
      __viCookieActive: "true",
      cto_bundle: "sO0TsF96ZVJ5enFKUmRHZ01DeFQ0R0dHV0xTZ2NaYmpUS2xCc21iRU5kd0RpekdtTklNTmtuNXkxSCUyQjhIajk2ZjBQQVJZNU9qdXBTRzYwbEYlMkZKJTJGUFBSbWJzeXJ3OFF5Q09kb28zdFh1MzZoNEEwYmMyV1BEWTFpR1R0eWYlMkZMJTJCYm9uQldHWmZtSGtNYk9KY3Q2OGJrNEVkbmtRJTNEJTNE",
      cto_bidid: "sqBfM19HbFdPOHVRQ1NPcXBlaUowREFmaFdBa3FJa0c3blprSVFOSk1JV3lNS3Y0UjFUOFh1dDFPUGJ3TldRYmpReDQzRGRyc1NwSlFucGNDU1dBZFZySmdkU0RNSFhmJTJCMWJsYmdKYkVHS21uJTJGMHMlM0Q",
      __gads: "ID=3106d8283740c066:T=1736720076:RT=1736720433:S=ALNI_MZbyVQGOfiYpAuoq78FicbCHPuRKA",
      __gpi: "UID=00000fe6b9fbf918:T=1736720076:RT=1736720433:S=ALNI_MZ6KkHrO9fdq5Tt8ATtdq73ToXPFA",
      __eoi: "ID=4eebfe5c3a6a0d77:T=1736720076:RT=1736720433:S=AA-AfjZlT3ffkjGJvvgHgaD_MdWQ",
      _ga_8JFH2XCMDR: "GS1.1.1736720071.1.1.1736720529.0.0.0"
    };
    const cookieString = Object.entries(cookies).map(([key, value]) => `${key}=${value}`).join("; ");
    try {
      const zan = await import_axios.default.get(searchUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
          "Cookie": cookieString
        }
      });
      const $ = cheerio.load(zan.data);
      const results = [];
      $("div.box ul#pagedata li a").each((index, element) => {
        const href = $(element).attr("href");
        const title = $(element).attr("title");
        if (href && title) {
          results.push({
            name: title.trim(),
            url: `https://m.apksum.com${href.trim()}`
          });
        }
      });
      if (results.length === 0) {
        return jagoanproject.reply(m.chat, "Tidak ada hasil yang ditemukan untuk pencarian tersebut.", m);
      }
      let responseText = "Hasil pencarian:\n\n";
      results.forEach((result, index) => {
        responseText += `${index + 1}. ${result.name}
${result.url}

`;
      });
      jagoanproject.reply(m.chat, responseText, m);
    } catch (error) {
      jagoanproject.reply(m.chat, `${error.message}`, m);
    }
  }
  if (args[0] === "download") {
    const url = args[1];
    if (!url) {
      return jagoanproject.reply(m.chat, "Masukkan URL aplikasi yang ingin diambil downloadnya. Contoh penggunaan: apksum download https://m.apksum.com/download/com.mojang.minecraftpe_1.21.60.25_free", m);
    }
    try {
      const zan = await import_axios.default.get(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }
      });
      const $ = cheerio.load(zan.data);
      const downloadLinks = [];
      $("div.down-warp .down a").each((i, elem) => {
        const downloadUrl = $(elem).attr("href");
        const downloadTitle = $(elem).attr("title");
        if (downloadUrl && downloadTitle) {
          downloadLinks.push({
            name: downloadTitle,
            url: `https://m.apksum.com${downloadUrl}`
          });
        }
      });
      if (downloadLinks.length === 0) {
        return jagoanproject.reply(m.chat, "Tidak ditemukan link download untuk aplikasi ini.", m);
      }
      let responseText = "Link download ditemukan:\n\n";
      downloadLinks.forEach((link, index) => {
        responseText += `${index + 1}. ${link.name}
${link.url}

`;
      });
      jagoanproject.reply(m.chat, responseText, m);
    } catch (error) {
      jagoanproject.reply(m.chat, `${error.message}`, m);
    }
  }
};
handler.help = ["apksum search query", "apksum download url"];
handler.tags = ["internet"];
handler.command = /^apksum$/i;
handler.register = true;
handler.limit = true;
var internet_apksum_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
