/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - waifu.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_waifu_exports = {};
__export(internet_waifu_exports, {
  default: () => internet_waifu_default
});
module.exports = __toCommonJS(internet_waifu_exports);
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) return m.reply`[ Notice ] ${usedPrefix + command} masukkan prompt nya!`;
  try {
    m.reply("*Process generating image, please wait...*");
    let sdxl = await (await fetch(`https://endpoint.web.id/ai/sdxl-waifu?key=${global.key}&prompt=` + text)).json();
    if (sdxl.result && sdxl.result.image) {
      let baby = sdxl.result;
      jagoanproject.sendMessage(m.chat, { image: { url: baby.image }, caption: "[ Succes Get Image To Your Prompt ]" }, { quoted: m });
    } else if (sdxl.result.message) {
      m.reply(sdxl.result.message);
    } else {
      m.reply("*No image generated and no message available.*");
    }
  } catch (e) {
    m.reply("Terjadi kesalahan....");
  }
};
handler.help = ["waifu-sdxl"];
handler.tags = ["anime"];
handler.command = /^(waifu-sdxl)$/i;
handler.limit = true;
handler.register = true;
var internet_waifu_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
