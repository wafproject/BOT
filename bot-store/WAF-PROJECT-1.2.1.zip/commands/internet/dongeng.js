/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - dongeng.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_dongeng_exports = {};
__export(internet_dongeng_exports, {
  default: () => internet_dongeng_default
});
module.exports = __toCommonJS(internet_dongeng_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
const dongeng = {
  list: async () => {
    let nextPageUrl = "https://www.1000dongeng.com/";
    const posts = [];
    try {
      while (nextPageUrl) {
        const { data } = await import_axios.default.get(nextPageUrl);
        const $ = cheerio.load(data);
        $(".date-outer .date-posts .post-outer").each((index, element) => {
          const title = $(element).find(".post-title a").text();
          const link = $(element).find(".post-title a").attr("href");
          const author = $(element).find(".post-author .fn").text().trim();
          const date = $(element).find(".post-timestamp .published").text();
          const image = $(element).find(".post-thumbnail amp-img").attr("src") || "Image not available";
          posts.push({
            title,
            link,
            author,
            date,
            image
          });
        });
        const nextLink = $(".blog-pager-older-link").attr("href");
        nextPageUrl = nextLink ? nextLink : null;
      }
      return {
        total: posts.length,
        posts
      };
    } catch (error) {
      throw new Error("Error fetching the website: " + error.message);
    }
  },
  getDongeng: async (url) => {
    try {
      const { data } = await import_axios.default.get(url);
      const $ = cheerio.load(data);
      const title = $("h1.post-title.entry-title").text().trim();
      const author = $(".post-author .fn").text().trim();
      const storyContent = $(".superarticle").find("div").map((i, el) => {
        return $(el).text().trim();
      }).get().join("\n");
      return {
        title,
        author,
        storyContent
      };
    } catch (error) {
      throw new Error("Error fetching the dongeng: " + error.message);
    }
  }
};
const handler = async (m, { args, command }) => {
  if (command === "dongenglist") {
    try {
      const { total, posts } = await dongeng.list();
      const message = `\u2705 *Daftar Dongeng* (${total} total)

` + posts.slice(0, 10).map((post, i) => `${i + 1}. ${post.title}
Link: ${post.link}
`).join("\n");
      m.reply(message);
    } catch (error) {
      m.reply(`gagal: ${error.message}`);
    }
  }
  if (command === "dongeng") {
    if (!args.length) {
      return m.reply("silahkan dibaca melalui link.");
    }
    const url = args[0];
    try {
      const { title, author, storyContent } = await dongeng.getDongeng(url);
      const message = `\u{1F4D6} *${title}*
\u270D\uFE0F *Penulis*: ${author}

${storyContent.slice(0, 2e3)}...

Cerita terlalu panjang? Buka di link berikut:
` + url;
      m.reply(message);
    } catch (error) {
      m.reply(`${error.message}`);
    }
  }
};
handler.command = ["dongenglist", "dongeng"];
handler.tags = ["internet"];
handler.help = ["dongenglist"];
handler.register = true;
handler.limit = true;
var internet_dongeng_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
