/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - alkitab.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_alkitab_exports = {};
__export(internet_alkitab_exports, {
  default: () => internet_alkitab_default
});
module.exports = __toCommonJS(internet_alkitab_exports);
var import_node_fetch = __toESM(require("node-fetch"));
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `uhm.. teksnya mana?

contoh:
${usedPrefix + command} kejadian`;
  let res = await import_axios.default.get(`https://alkitab.me/search?q=${encodeURIComponent(text)}`, {
    headers: {
      "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
    }
  });
  let $ = cheerio.load(res.data);
  let result = [];
  $("div.vw").each(function(a, b) {
    let teks = $(b).find("p").text().trim();
    let link = $(b).find("a").attr("href");
    let title = $(b).find("a").text().trim();
    result.push({ teks, link, title });
  });
  let foto = "https://telegra.ph/file/a333442553b1bc336cc55.jpg";
  let judul = "*\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u300C Alkitab \u300D \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500*";
  let caption = result.map((v) => `\u{1F48C} ${v.title}
\u{1F4EE} ${v.teks}`).join("\n\u2504\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2508\u2504\n");
  jagoanproject.sendFile(m.chat, foto, "alkitab.jpg", `${judul}

${caption}`, m);
};
handler.help = ["alkitab"].map((v) => v + " <pencarian>");
handler.tags = ["internet"];
handler.command = /^(alkitab)$/i;
handler.register = true;
handler.limit = true;
var internet_alkitab_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
