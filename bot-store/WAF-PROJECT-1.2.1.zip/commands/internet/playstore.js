/**
 * internet/playstore.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/search/playstore",
  "command": [
    "playstore"
  ],
  "kind": "text",
  "category": "internet"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
