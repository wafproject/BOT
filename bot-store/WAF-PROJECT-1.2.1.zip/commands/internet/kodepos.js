/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - kodepos.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_kodepos_exports = {};
__export(internet_kodepos_exports, {
  default: () => internet_kodepos_default
});
module.exports = __toCommonJS(internet_kodepos_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  if (!text) throw "Mana Provinsinya?\n\nContoh: *" + usedPrefix + command + " Jateng*";
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  let res = await KodePos(text);
  let hasil = res.map(
    (item) => `\u2022 *Provinsi:* ${item.province}
\u2022 *Kota:* ${item.city}
\u2022 *Kecamatan:* ${item.subdistrict}
\u2022 *Desa:* ${item.village}
\u2022 *KodePos:* ${item.postalcode}`
  ).join("\n\n");
  let tex = `${hasil || "Not Found"}`;
  m.reply("*KODEPOS INDONESIA*\n\n" + tex);
};
handler.help = ["kodepos"];
handler.tags = ["internet"];
handler.command = ["kodepos"];
handler.register = true;
handler.limit = true;
var internet_kodepos_default = handler;
function KodePos(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        data
      } = await import_axios.default.get("https://nomorkodepos.com/?s=" + query);
      const $ = cheerio.load(data);
      let _data = [];
      $("table.pure-table.pure-table-horizontal > tbody > tr").each((i, u) => {
        let _doto = [];
        $(u).find("td").each((l, p) => {
          _doto.push($(p).text().trim());
        });
        _data.push({
          province: _doto[0],
          city: _doto[1],
          subdistrict: _doto[2],
          village: _doto[3],
          postalcode: _doto[4]
        });
      });
      resolve(_data);
    } catch (err) {
      console.error(err);
    }
  });
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
