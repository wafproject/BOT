/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - jadwaltv.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_jadwaltv_exports = {};
__export(internet_jadwaltv_exports, {
  default: () => internet_jadwaltv_default
});
module.exports = __toCommonJS(internet_jadwaltv_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
async function jadwal(tv) {
  try {
    let { data } = await import_axios.default.get(`https://www.jadwaltv.net/channel/${tv}`);
    let $ = cheerio.load(data);
    let hasil = [];
    $("table.table-bordered tbody tr").each((i, el) => {
      let jam = $(el).find("td").eq(0).text().trim();
      let acara = $(el).find("td").eq(1).text().trim();
      if (jam && acara) {
        hasil.push({ jam, acara });
      }
    });
    return hasil;
  } catch (error) {
    console.error("Error:", error.message);
    return null;
  }
}
async function handler(m, { args }) {
  if (!args[0]) return m.reply("\u274C Masukkan nama channel TV! Contoh: .jadwaltv gtv");
  const tv = args[0].toLowerCase();
  const jadwalTv = await jadwal(tv);
  if (!jadwalTv || jadwalTv.length === 0) {
    return m.reply(`\u26A0\uFE0F Jadwal untuk channel *${tv.toUpperCase()}* tidak ditemukan atau sedang tidak tersedia.`);
  }
  const jadwalList = jadwalTv.map((item) => `\u{1F552} *${item.jam}*: ${item.acara}`).join("\n");
  const response = `
\u{1F4FA} *Jadwal TV ${tv.toUpperCase()}*

${jadwalList}

\u{1F310} Sumber: https://www.jadwaltv.net/channel/${tv}
    `.trim();
  m.reply(response);
}
handler.command = ["jadwaltv"];
handler.tags = ["internet"];
handler.help = ["jadwaltv <channel>"];
handler.register = true;
handler.limit = true;
var internet_jadwaltv_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
