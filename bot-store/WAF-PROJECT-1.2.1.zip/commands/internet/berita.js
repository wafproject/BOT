/**
 * internet/berita.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "command": [
    "berita",
    "news"
  ],
  "kind": "text",
  "category": "internet"
}

const R = require('../../lib/botcahx-routes.js').berita
handler_def.route = R.route
handler_def.routeHelp = R.help
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
