/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - emas.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_emas_exports = {};
__export(internet_emas_exports, {
  default: () => internet_emas_default
});
module.exports = __toCommonJS(internet_emas_exports);
var import_node_fetch = __toESM(require("node-fetch"));
const METAL_API_KEY = () => String(global.metalapikey || "").trim(); // isi di settings.js: global.metalapikey = "..."
const USD_TO_IDR = 16e3;
const TROY_OUNCE_TO_GRAM = 31.1034768;
let handler = async (m, { jagoanproject }) => {
  try {
    const url = `https://api.metalpriceapi.com/v1/latest?api_key=${METAL_API_KEY()}&base=USD&currencies=XAU`;
    const res = await (0, import_node_fetch.default)(url);
    const json = await res.json();
    if (!json.success) {
      throw json.error?.info || "Gagal mengambil data emas";
    }
    const usdPerOunce = json.rates.USDXAU;
    const usdPerGram = usdPerOunce / TROY_OUNCE_TO_GRAM;
    const idrPerOunce = usdPerOunce * USD_TO_IDR;
    const idrPerGram = usdPerGram * USD_TO_IDR;
    const time = new Date(json.timestamp * 1e3).toLocaleString("id-ID");
    let teks = `
*HARGA EMAS TERKINI*

\u{1F4C5} Update:
> ${time}

\u{1F4B0} *Per Troy Ounce*
> USD ${usdPerOunce.toFixed(2)}
> IDR ${idrPerOunce.toLocaleString("id-ID")}

\u2696\uFE0F *Per Gram*
> USD ${usdPerGram.toFixed(2)}
> IDR ${idrPerGram.toLocaleString("id-ID")}

\u{1F4CA} Sumber:
MetalpriceAPI (XAU)
`.trim();
    await jagoanproject.sendMessage(m.chat, { text: teks }, { quoted: m });
  } catch (e) {
    await jagoanproject.sendMessage(
      m.chat,
      { text: `\u274C Gagal mengambil harga emas

${e}` },
      { quoted: m }
    );
  }
};
handler.help = ["emas"];
handler.tags = ["internet"];
handler.command = /^(emas|gold)$/i;
handler.limit = true;
handler.register = true;
var internet_emas_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
