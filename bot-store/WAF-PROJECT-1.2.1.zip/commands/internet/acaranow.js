/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - acaranow.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_acaranow_exports = {};
__export(internet_acaranow_exports, {
  default: () => internet_acaranow_default
});
module.exports = __toCommonJS(internet_acaranow_exports);
var cheerio = __toESM(require("cheerio"));
var import_axios = __toESM(require("axios"));
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  let res = await AcaraNow();
  let hasil = res.map(
    (item) => `${item}`
  ).join("\n");
  m.reply("*ACARA TV INDONESIA*\n" + hasil);
};
handler.help = ["acaranow"];
handler.tags = ["internet"];
handler.command = ["acaranow"];
handler.register = true;
handler.limit = true;
var internet_acaranow_default = handler;
function AcaraNow() {
  return new Promise(async (resolve, reject) => {
    try {
      const {
        data
      } = await import_axios.default.get("https://www.jadwaltv.net/channel/acara-tv-nasional-saat-ini");
      const $ = cheerio.load(data);
      let tv = [];
      $("table.table.table-bordered > tbody > tr").each((u, i) => {
        let an = $(i).text().split("WIB");
        if (an[0] === "JamAcara") return;
        if (typeof an[1] === "undefined") return tv.push("\n*" + an[0] + "*");
        tv.push(`${an[0]} - ${an[1]}`);
      });
      if (tv.every((x) => x === void 0)) return resolve({
        developer: nameowner,
        mess: "Tidak di temukan Hasil"
      });
      resolve(tv);
    } catch (err) {
      console.error(err);
    }
  });
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
