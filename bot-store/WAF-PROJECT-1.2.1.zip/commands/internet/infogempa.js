/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - infogempa.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_infogempa_exports = {};
__export(internet_infogempa_exports, {
  default: () => internet_infogempa_default
});
module.exports = __toCommonJS(internet_infogempa_exports);
var import_axios = __toESM(require("axios"));
const BMKG_URL = "https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json";
const BMKG_BASE = "https://data.bmkg.go.id/DataMKG/TEWS/";
const infogempa = {
  get url() {
    return {
      api_gempa: BMKG_URL
    };
  },
  async mintaJson(description, url) {
    const configs = [
      {
        timeout: 2e4,
        maxRedirects: 5,
        validateStatus: (status2) => status2 >= 200 && status2 < 300,
        headers: {
          "Accept": "application/json, text/plain, */*",
          "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
          "Cache-Control": "no-cache",
          "Pragma": "no-cache",
          "Referer": "https://www.bmkg.go.id/",
          "Origin": "https://www.bmkg.go.id",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
        }
      },
      {
        timeout: 2e4,
        maxRedirects: 5,
        validateStatus: (status2) => status2 >= 200 && status2 < 300,
        headers: {
          "Accept": "application/json",
          "User-Agent": "Mozilla/5.0"
        }
      }
    ];
    let lastError = null;
    for (const config of configs) {
      try {
        const { data } = await import_axios.default.get(url, config);
        if (!data?.Infogempa?.gempa) {
          throw new Error("Invalid earthquake data structure");
        }
        return data;
      } catch (error) {
        lastError = error;
      }
    }
    const status = lastError?.response?.status;
    const statusText = lastError?.response?.statusText;
    const message = status ? `HTTP ${status}${statusText ? " " + statusText : ""}` : lastError?.message || "Unknown error";
    throw new Error(`Failed to fetch JSON for ${description}: ${message}`);
  },
  formatGempa(gempa, placeName = "") {
    const namaTempat = placeName.trim() ? `\u{1F4CC} Nama: ${placeName}
` : "";
    let hasil = `\u{1F30D} *Info Gempa BMKG*

`;
    hasil += namaTempat;
    hasil += `\u{1F4C5} Tanggal: *${gempa.Tanggal || "N/A"}*
`;
    hasil += `\u23F0 Jam: *${gempa.Jam || "N/A"}*
`;
    hasil += `\u{1F552} DateTime: *${gempa.DateTime || "N/A"}*
`;
    hasil += `\u{1F4CF} Magnitude: *${gempa.Magnitude || "N/A"}*
`;
    hasil += `\u{1F30A} Kedalaman: *${gempa.Kedalaman || "N/A"}*
`;
    hasil += `\u{1F4CD} Wilayah: *${gempa.Wilayah || "N/A"}*
`;
    hasil += `\u{1F9ED} Koordinat: *${gempa.Coordinates || `${gempa.Lintang || "N/A"}, ${gempa.Bujur || "N/A"}`}*
`;
    hasil += gempa.Potensi ? `\u26A0\uFE0F Potensi: *${gempa.Potensi}*
` : "";
    hasil += gempa.Dirasakan ? `\u{1F440} Dirasakan: *${gempa.Dirasakan}*
` : "";
    hasil += `\u{1F517} Sumber: https://www.bmkg.go.id`;
    return hasil.trim();
  },
  async getGempa() {
    const gempaJson = await this.mintaJson("info gempa", this.url.api_gempa);
    return gempaJson.Infogempa.gempa;
  },
  async run(lokasiKamu = "") {
    const gempa = await this.getGempa();
    return {
      text: this.formatGempa(gempa, lokasiKamu),
      gempa,
      imageUrl: gempa?.Shakemap ? `${BMKG_BASE}${gempa.Shakemap}` : null
    };
  }
};
let handler = async (m, { conn, text }) => {
  try {
    const sock = conn || global.jagoanproject;
    if (!sock) {
      return m.reply("Socket bot belum siap. Coba lagi beberapa detik.");
    }
    const result = await infogempa.run(text || "");
    if (result.imageUrl) {
      await sock.sendMessage(m.chat, {
        image: { url: result.imageUrl },
        caption: result.text
      }, { quoted: m });
    } else {
      await m.reply(result.text);
    }
  } catch (error) {
    await m.reply(`Terjadi kesalahan saat mengambil info gempa.

${error.message}`);
  }
};
handler.help = ["infogempa", "gempa"];
handler.tags = ["internet", "tools"];
handler.command = /^(infogempa|gempa)$/i;
handler.register = true;
var internet_infogempa_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
