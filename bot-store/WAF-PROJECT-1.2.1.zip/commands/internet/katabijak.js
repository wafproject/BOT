/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - katabijak.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_katabijak_exports = {};
__export(internet_katabijak_exports, {
  default: () => internet_katabijak_default
});
module.exports = __toCommonJS(internet_katabijak_exports);
var import_jagokata = __toESM(require("../../lib/jagoan/lib/jagokata.js"));
let handler = async (m, { command, args, usedPrefix }) => {
  let er = `\u2022 *Example :* ${usedPrefix + command} cinta

Opsi Tersedia:
\u2022 cinta
\u2022 rindu
\u2022 mimpi
\u2022 sendiri
\u2022 sabar
\u2022 kesedihan
\u2022 pernikahan
\u2022 kemerdekaan`;
  if (!args[0]) return jagoanproject.reply(m.chat, er, m);
  switch (args[0].toLowerCase()) {
    case "cinta":
    case "rindu":
    case "mimpi":
    case "sendiri":
    case "sabar":
    case "kesedihan":
    case "pernikahan":
    case "kemerdekaan":
      (0, import_jagokata.default)(args[0].toLowerCase()).then((res) => {
        let data = JSON.stringify(res);
        let json = JSON.parse(data);
        let random = Math.floor(Math.random() * json.data.length);
        let hasil = json.data[random];
        let { author, bio, quote } = hasil;
        jagoanproject.reply(m.chat, `\u201C${quote}\u201D

${author} - ${bio}`, m);
      });
      break;
    default:
      return jagoanproject.reply(m.chat, er, m);
  }
};
handler.help = ["katabijak"].map((v) => v + " *<text>*");
handler.tags = ["internet"];
handler.command = /^(katabijak|jagokata)$/i;
handler.register = true;
handler.limit = true;
var internet_katabijak_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
