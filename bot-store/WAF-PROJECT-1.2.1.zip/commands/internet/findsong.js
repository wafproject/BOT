/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/internet/internet - findsong.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var internet_findsong_exports = {};
__export(internet_findsong_exports, {
  default: () => internet_findsong_default
});
module.exports = __toCommonJS(internet_findsong_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  if (!text) throw `*\u2022 Example:* ${usedPrefix + command} *Starboy*`;
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  try {
    let lirik = await findSongs(text);
    let caption = `*[ ${command === "lirik" ? command + " SEARCH" : command.toUpperCase().split("").join(" ")} ]*
\u2022 Title:* ${lirik.title}
\u2022 Album:* ${lirik.album}

\`\`\`${lirik.lyrics}\`\`\``;
    jagoanproject.sendFile(m.chat, lirik.thumb, null, caption, m);
  } catch (e) {
    throw "Request Error";
  }
};
handler.help = ["songfind", "findsong"].map((a) => a + " *<Name song>*");
handler.tags = ["internet"];
handler.command = ["songfind", "findsong"];
handler.register = true;
handler.limit = true;
var internet_findsong_default = handler;
async function findSongs(text) {
  try {
    const { data } = await import_axios.default.get(
      "https://songsear.ch/q/" + encodeURIComponent(text)
    );
    const $ = cheerio.load(data);
    const result = {
      title: $("div.results > div:nth-child(1) > .head > h3 > b").text() + " - " + $("div.results > div:nth-child(1) > .head > h2 > a").text(),
      album: $("div.results > div:nth-child(1) > .head > p").text(),
      number: $("div.results > div:nth-child(1) > .head > a").attr("href").split("/")[4],
      thumb: $("div.results > div:nth-child(1) > .head > a > img").attr("src")
    };
    const { data: lyricData } = await import_axios.default.get(
      `https://songsear.ch/api/song/${result.number}?text_only=true`
    );
    const lyrics = lyricData.song.text_html.replace(/<br\/>/g, "\n").replace(/&#x27;/g, "'");
    return {
      status: true,
      title: result.title,
      album: result.album,
      thumb: result.thumb,
      lyrics
    };
  } catch (err) {
    console.log(err);
    return {
      status: false,
      error: "Unknown error occurred"
    };
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "internet" }
)
