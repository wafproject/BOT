/**
 * random/ayuzawa.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/anime/ayuzawa",
  "command": [
    "ayuzawa"
  ],
  "kind": "media",
  "category": "random"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
