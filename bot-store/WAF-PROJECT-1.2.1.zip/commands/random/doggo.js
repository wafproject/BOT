/**
 * random/doggo.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/wallpaper/anjing",
  "command": [
    "doggo"
  ],
  "kind": "media",
  "category": "random"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
