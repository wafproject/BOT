/**
 * .setapikey <key> — ganti API key BOTCAHX (global.btc) di settings.js
 * (dulu untuk API Jagoan; bot sudah lepas dari API Jagoan)
 */
const fs = require('fs').promises
const path = require('path')

const handler = async (m, { text, usedPrefix, command }) => {
  const key = String(text || '').trim().split(/\s+/)[0]
  if (!key) {
    return m.reply(
      `🔐 *Set API key BOTCAHX*\n\nCara pakai: *${usedPrefix}${command} <apikey>*\n\n` +
      `Ambil key dari akun kamu di api.botcahx.eu.org (menu profil/dashboard).\n` +
      `Yang diubah: *global.btc* di settings.js\n\n` +
      `Setelah itu cek dengan *${usedPrefix}cekapikey*`
    )
  }
  if (!/^[\w-]{4,80}$/.test(key)) return m.reply('❌ Format API key tidak valid.')
  const file = path.join(process.cwd(), 'settings.js')
  try {
    let src = await fs.readFile(file, 'utf8')
    const re = /^(\s*global\.btc\s*=\s*)(["'`])[^"'`]*\2\s*;?/m
    if (re.test(src)) src = src.replace(re, `$1"${key}";`)
    else src += `\nglobal.btc = "${key}";\n`
    await fs.writeFile(file, src, 'utf8')
    global.btc = key
    try { await m.delete?.() } catch {}
    return m.reply('✅ API key botcahx diperbarui & langsung aktif (tanpa restart).\nCek dengan *.cekapikey*')
  } catch (e) {
    console.error('[setapikey]', e)
    return m.reply('❌ Gagal menulis settings.js: ' + (e?.message || e))
  }
}

handler.help = ['setapikey <apikey botcahx>']
handler.tags = ['owner']
handler.category = 'owner'
handler.command = /^setapikey$/i
handler.rowner = true

module.exports = handler
