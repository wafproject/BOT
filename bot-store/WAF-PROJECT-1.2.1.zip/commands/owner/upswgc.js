/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - upswgc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_upswgc_exports = {};
__export(owner_upswgc_exports, {
  default: () => owner_upswgc_default
});
module.exports = __toCommonJS(owner_upswgc_exports);
var import_simple = require("../../lib/jagoan/simple.js");
const hexToArgb = (hex) => {
  if (!hex) return void 0;
  let value = String(hex).replace("#", "").trim();
  if (value.length === 3) value = value.split("").map((c) => c + c).join("");
  if (!/^[0-9a-f]{6}$/i.test(value)) return void 0;
  const r = parseInt(value.slice(0, 2), 16);
  const g = parseInt(value.slice(2, 4), 16);
  const b = parseInt(value.slice(4, 6), 16);
  return (255 << 24 | r << 16 | g << 8 | b) >>> 0;
};
async function groupStatus(sock, jid, inputContent = {}) {
  const content = { ...inputContent || {} };
  const backgroundColor = content.backgroundColor;
  const font = content.font;
  delete content.backgroundColor;
  delete content.font;
  const inside = await (0, import_simple.generateWAMessageContent)(content, {
    upload: sock.waUploadToServer,
    backgroundColor,
    font
  });
  const messageType = Object.keys(inside || {})[0];
  if (!messageType || !inside?.[messageType]) {
    throw new Error("Payload status grup tidak dapat dibuat");
  }
  const groupStatusContext = {
    featureEligibilities: {
      canReceiveMultiReact: true
    },
    statusSourceType: 4,
    statusAttributions: [
      { type: 10 }
    ],
    isGroupStatus: true,
    statusAudienceMetadata: {
      audienceType: 1
    }
  };
  inside[messageType].contextInfo = {
    ...inside[messageType].contextInfo || {},
    ...groupStatusContext
  };
  if (messageType === "extendedTextMessage") {
    if (backgroundColor != null) inside[messageType].backgroundArgb = backgroundColor;
    inside[messageType].textArgb = 4294967295;
    inside[messageType].font = Number.isFinite(Number(font)) ? Number(font) : 5;
    inside[messageType].previewType = 0;
    inside[messageType].inviteLinkGroupTypeV2 = 0;
  }
  await sock.relayMessage(jid, inside, {});
  return true;
}
function parseTargetInput(raw = "") {
  const input = String(raw || "").trim();
  if (!input) return { targetJid: null, caption: null };
  const match = input.match(/^([^\s|]+@g\.us)(?:\s*\|\s*([\s\S]*))?$/i);
  if (!match) return { targetJid: null, caption: input };
  return {
    targetJid: match[1],
    caption: typeof match[2] === "string" ? match[2].trim() : null
  };
}
let handler = async (m, { conn, jagoanproject, usedPrefix, command, text, isAdmin, isOwner, isROwner }) => {
  const sock = conn || jagoanproject || global.jagoanproject;
  if (!sock || typeof sock.relayMessage !== "function" || typeof sock.waUploadToServer !== "function") {
    return m.reply("\u274C Socket koneksi untuk status grup belum siap.");
  }
  const ownerAccess = Boolean(isOwner || isROwner || m.fromMe);
  const currentIsGroup = String(m.chat || "").endsWith("@g.us");
  if (currentIsGroup) {
    if (!isAdmin && !ownerAccess) return m.reply("\u274C Fitur story grup hanya untuk admin grup atau owner bot.");
  } else if (!ownerAccess) {
    return m.reply("\u274C Fitur story grup hanya untuk admin grup atau owner bot.");
  }
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || quoted.mtype || "";
  const parsed = parseTargetInput(text);
  let targetJid = parsed.targetJid || (currentIsGroup ? m.chat : "");
  let caption = parsed.caption;
  if (caption == null && m.quoted) caption = m.quoted.text || m.quoted.caption || "";
  caption = String(caption || "").trim();
  if (!targetJid || !targetJid.endsWith("@g.us")) {
    return m.reply(
      `\u274C Gunakan perintah ini di grup, atau owner dapat menyertakan ID grup.

Format:
\u2022 ${usedPrefix + command} teks status
\u2022 ${usedPrefix + command} (reply gambar/video/audio)
\u2022 ${usedPrefix + command} 120363xxx@g.us
\u2022 ${usedPrefix + command} 120363xxx@g.us | teks status`
    );
  }
  if (!ownerAccess && targetJid !== m.chat) {
    return m.reply("\u274C Admin grup hanya dapat membuat story untuk grup ini.");
  }
  if (targetJid !== m.chat) {
    const groupMetadata = await sock.groupMetadata(targetJid).catch(() => null);
    if (!groupMetadata) {
      return m.reply("\u274C Bot tidak tergabung di grup tersebut atau ID grup tidak valid.");
    }
  }
  try {
    await sock.sendMessage(m.chat, { react: { text: "\u23F3", key: m.key } }).catch(() => {
    });
    let payload = {};
    if (/image|imageMessage/i.test(mime)) {
      const buffer = await quoted.download();
      payload = { image: buffer, caption };
    } else if (/video|videoMessage/i.test(mime)) {
      const buffer = await quoted.download();
      payload = { video: buffer, caption };
    } else if (/audio|audioMessage/i.test(mime)) {
      const buffer = await quoted.download();
      payload = { audio: buffer, mimetype: "audio/mp4" };
    } else if (caption) {
      payload = {
        text: caption,
        backgroundColor: hexToArgb("#1B5E20"),
        font: 5
      };
    } else {
      await sock.sendMessage(m.chat, { react: { text: "\u{1F913}", key: m.key } }).catch(() => {
      });
      return m.reply(
        `\u274C Reply media atau ketik teks yang ingin dijadikan story grup.

Contoh:
\u2022 ${usedPrefix + command} Promo hari ini
\u2022 ${usedPrefix + command} (reply gambar/video/audio)`
      );
    }
    await groupStatus(sock, targetJid, payload);
    await sock.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } }).catch(() => {
    });
    return m.reply(targetJid === m.chat ? "\u2705 Berhasil upload ke story grup." : `\u2705 Berhasil upload story grup ke ${targetJid}`);
  } catch (err) {
    console.error("[SWGC]", err);
    await sock.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } }).catch(() => {
    });
    return m.reply("\u274C Gagal membuat story grup: " + (err?.message || err));
  }
};
handler.help = ["swgc", "upswgc"];
handler.tags = ["group"];
handler.command = /^(upswgc|swgc|swgrup)$/i;
handler.admin = false;
handler.botAdmin = false;
handler.group = false;
handler.register = true;
handler.limit = true;
var owner_upswgc_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
