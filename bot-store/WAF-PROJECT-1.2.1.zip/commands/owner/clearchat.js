/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - clearchat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_clearchat_exports = {};
__export(owner_clearchat_exports, {
  default: () => owner_clearchat_default
});
module.exports = __toCommonJS(owner_clearchat_exports);
let handler = async (m, { jagoanproject }) => {
  try {
    if (!m.key || !m.messageTimestamp) {
      return jagoanproject.reply(m.chat, "\u274C Tidak bisa membaca data pesan!", m);
    }
    await jagoanproject.chatModify({
      delete: true,
      lastMessages: [
        {
          key: m.key,
          messageTimestamp: m.messageTimestamp
        }
      ]
    }, m.chat);
  } catch (e) {
    jagoanproject.reply(m.chat, "\u274C Gagal menghapus percakapan!\n\n" + e.message, m);
  }
};
handler.help = ["clearchat"];
handler.tags = ["owner"];
handler.command = /^clearchat$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_clearchat_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
