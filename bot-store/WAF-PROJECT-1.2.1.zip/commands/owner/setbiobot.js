/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - setbiobot.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_setbiobot_exports = {};
__export(owner_setbiobot_exports, {
  default: () => owner_setbiobot_default
});
module.exports = __toCommonJS(owner_setbiobot_exports);
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  if (!text) {
    return jagoanproject.reply(m.chat, `*\u{1F4CC} Cara penggunaan:*

\u2022 ${usedPrefix + command} teksbio`, m);
  }
  const caption = text.trim();
  if (!caption) return jagoanproject.reply(m.chat, `\u26A0\uFE0F Caption tidak boleh kosong.`, m);
  try {
    await jagoanproject.updateProfileStatus(caption);
    jagoanproject.reply(m.chat, `\u2705 Bio bot berhasil diubah menjadi:

"${caption}"`, m);
  } catch (e) {
    console.error("\u274C Gagal update bio:", e);
    jagoanproject.reply(m.chat, `\u274C Gagal mengganti bio bot.`, m);
  }
};
handler.help = ["setbio"].map((c) => c + " *[teks]*");
handler.tags = ["owner"];
handler.command = /^setbio$/i;
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_setbiobot_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
