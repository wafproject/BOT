/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - bcgc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_bcgc_exports = {};
__export(owner_bcgc_exports, {
  default: () => owner_bcgc_default
});
module.exports = __toCommonJS(owner_bcgc_exports);
let handler = async (m, { jagoanproject, text, participants }) => {
  if (!text) return m.reply(`
\u{1F4E2} *BROADCAST GROUP (BCGC)*

Format penggunaan:
.bcgc [delay] [pesan]

\u23F1 Keterangan delay:
\u2022 s = second (detik)
\u2022 m = minute (menit)
\u2022 h = hour (jam)
\u2022 d = day (hari)

\u{1F4CC} Contoh penggunaan:
\u2022 .bcgc 5s Halo semua
\u2022 .bcgc 10m Info penting
\u2022 .bcgc 1h Pengumuman
\u2022 .bcgc 1d informasi
\u2022 .bcgc Halo tanpa set delay (maka  default 5 detik)

\u2139 Catatan:
\u2022 Delay ditulis di awal pesan
\u2022 Jika delay tidak diisi, default 5 detik
\u2022 Delay berfungsi sebagai jeda kirim per grup
`);
  let groups = Object.entries(jagoanproject.chats).filter(
    ([jid, chat]) => jid.endsWith("@g.us") && chat.isChats && !chat.metadata?.read_only && !chat.metadata?.announce
  ).map((v) => v[0]);
  let delay = 5e3;
  let msg = text;
  let regex = /^(\d+)(s|m|h|d)\s+/i;
  let match = text.match(regex);
  if (match) {
    let num = parseInt(match[1]);
    let type = match[2].toLowerCase();
    switch (type) {
      case "s":
        delay = num * 1e3;
        break;
      case "m":
        delay = num * 6e4;
        break;
      case "h":
        delay = num * 36e5;
        break;
      case "d":
        delay = num * 864e5;
        break;
    }
    msg = text.replace(regex, "");
  }
  m.reply(`\u{1F4E2} Broadcast ke ${groups.length} grup
\u23F1 Delay: ${delay / 1e3}s per grup`);
  for (let id of groups) {
    let participantIds = participants.map((a) => a.id);
    await jagoanproject.sendMessage(id, {
      text: `*[ BROADCAST GROUP ]*

${msg}`,
      mentions: participantIds
    }).catch(() => {
    });
    await new Promise((res) => setTimeout(res, delay));
  }
  await jagoanproject.sendMessage(m.chat, global.done, { quoted: m });
};
handler.help = ["bcgc *[delay] [pesan]*"];
handler.tags = ["owner"];
handler.command = /^(broadcast|bc)(group|grup|gc)$/i;
handler.rowner = true;
var owner_bcgc_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
