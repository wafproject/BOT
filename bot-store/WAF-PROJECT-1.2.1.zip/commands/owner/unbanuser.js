/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - unbanuser.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_unbanuser_exports = {};
__export(owner_unbanuser_exports, {
  default: () => owner_unbanuser_default
});
module.exports = __toCommonJS(owner_unbanuser_exports);
let handler = async (m, { jagoanproject, isOwner, text }) => {
  try {
    let user = global.db?.data?.users?.[m.sender];
    if (user?.banned && user.bannedUntil && Date.now() >= user.bannedUntil) {
      user.banned = false;
      user.bannedUntil = null;
      await jagoanproject.reply(m.chat, "Masa banned kamu sudah habis. Kamu sekarang bisa menggunakan bot kembali \u2705", m);
    }
  } catch (e) {
    console.log("Auto-unban error:", e);
  }
  if (!isOwner) {
    global.jpDfail("owner", m, jagoanproject);
    throw false;
  }
  let who;
  let input = (text || "").trim();
  if (m.isGroup) {
    if (m.mentionedJid?.length) {
      who = m.mentionedJid[0];
    } else if (m.quoted) {
      who = m.quoted.sender;
    } else if (input) {
      let number = input.replace(/[^0-9]/g, "");
      if (!number.startsWith("62")) throw "\u274C Nomor harus diawali dengan 62.\n\n\u{1F4DD} Contoh : .unbanuser 628xxxxxxx";
      who = number + "@s.whatsapp.net";
    } else {
      throw "\u274C Format salah!\n\n\u{1F4DD} Cara penggunaan :\n\n\u2014 .unbanuser <@user>\n\u2014 .unbanuser <reply>\n\u2014 .unbanuser <nomor>";
    }
  } else {
    if (input) {
      let number = input.replace(/[^0-9]/g, "");
      if (!number.startsWith("62")) throw "\u274C Nomor harus diawali dengan 62.\n\n\u{1F4DD} Contoh: .unbanuser 628xxxxxxx";
      who = number + "@s.whatsapp.net";
    } else {
      who = m.chat;
    }
  }
  try {
    if (!who) throw "\u274C User tidak valid!";
    if (!global.db?.data?.users) throw "\u274C Database pengguna tidak tersedia.";
    let users = global.db.data.users;
    if (!users[who]) {
      return jagoanproject.reply(
        m.chat,
        `\u274C User belum terdaftar di database.

\u{1FA80} nomor : ${who.split("@")[0]}`,
        m
      );
    }
    let target = users[who];
    if (!target.banned) {
      return jagoanproject.reply(
        m.chat,
        `\u26A0\uFE0F User tidak dalam masa banned.

\u{1FA80} nomor : ${who.split("@")[0]}
\u2705 status : tidak dibanned`,
        m
      );
    }
    target.banned = false;
    target.bannedUntil = null;
    await jagoanproject.reply(
      m.chat,
      `\u2705 Berhasil unban user!

\u{1FA80} nomor : ${who.split("@")[0]}
\u2705 status : unban`,
      m
    );
  } catch (e) {
    console.log("Manual unban error:", e);
    await jagoanproject.reply(m.chat, `Error: ${e.message || e}`, m);
  }
};
handler.help = ["unbanuser <nomor|@tag|reply>"];
handler.tags = ["owner"];
handler.command = /^unbanuser$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_unbanuser_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
