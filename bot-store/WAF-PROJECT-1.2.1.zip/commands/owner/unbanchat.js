/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - unbanchat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_unbanchat_exports = {};
__export(owner_unbanchat_exports, {
  default: () => owner_unbanchat_default
});
module.exports = __toCommonJS(owner_unbanchat_exports);
let handler = async (m, { jagoanproject, text, args, isOwner, isROwner }) => {
  if (!(isOwner || isROwner)) throw "\u{1F621} Hanya owner yang bisa unbanned chat!!";
  let id = args[0] || m.chat;
  if (!id.endsWith("@g.us")) throw "ID group tidak valid! \u{1F60F}";
  let chat = global.db.data.chats[id];
  if (!chat) throw "\u203C\uFE0F Data group tidak ditemukan!";
  if (!chat.isBanned) throw "Group ini tidak sedang dibanned kok~ \u{1F61D}";
  chat.isBanned = false;
  chat.bannedUntil = null;
  m.reply(`\u2705 Berhasil unbanchat!!

\u{1F3E0} ID : *${id}*

> sekarang semua member bisa menggunakan bot lagi!`);
};
handler.help = ["unbanchat"];
handler.tags = ["owner"];
handler.command = /^unbanchat$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_unbanchat_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
