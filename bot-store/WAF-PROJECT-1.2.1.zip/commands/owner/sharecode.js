/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - sharecode.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_sharecode_exports = {};
__export(owner_sharecode_exports, {
  default: () => owner_sharecode_default
});
module.exports = __toCommonJS(owner_sharecode_exports);
let handler = async (m, { jagoanproject, text, args, prefix }) => {
  const newsletterList = [
    "120363393660581814@newsletter"
  ];
  const input = text && text.trim() || args.join(" ").trim();
  if (!input || !input.includes("|")) {
    return jagoanproject.sendMessage(m.chat, {
      text: "\u2757 Format salah!\nGunakan format:\n\n*.sharecode URL_GAMBAR|URL_TUJUAN|TEKS_TOMBOL*"
    }, { quoted: m });
  }
  const parts = input.split("|").map((x) => x.trim());
  if (parts.length < 3 || parts.some((x) => !x)) {
    return jagoanproject.sendMessage(m.chat, {
      text: `${prefix}sharecode url-image|link|teks-button`
    }, { quoted: m });
  }
  const [imageUrl, targetUrl, buttonText] = parts;
  const titleText = "> INFORMASI UPDATE\n> CLICK BUTTON\n";
  const footerText = "Jagoan Project";
  await jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F504}", key: m.key } });
  try {
    const interactiveMessage = {
      interactiveMessage: {
        title: titleText,
        footer: footerText,
        image: { url: imageUrl },
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: buttonText,
              url: targetUrl
            })
          },
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "saluran\u{1F389}",
              url: "https://whatsapp.com/channel/0029VanhMDo42DcjiRGJOc2m"
            })
          }
        ]
      }
    };
    for (const id of newsletterList) {
      await jagoanproject.sendMessage(id, interactiveMessage);
      console.log(`\u2705 Dikirim ke: ${id}`);
      await new Promise((res) => setTimeout(res, 1500));
    }
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } });
    await jagoanproject.sendMessage(m.chat, {
      text: `\u2705 Berhasil mengirim pesan ke ${newsletterList.length} saluran:
${newsletterList.join("\n")}`
    });
  } catch (e) {
    console.error(e);
    await jagoanproject.sendMessage(m.chat, {
      text: `\u274C Terjadi kesalahan saat mengirim ke saluran:
${e.message}`
    });
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } });
  }
};
handler.help = ["sharecode <url_gambar>|<url_tujuan>|<teks_tombol>"];
handler.tags = ["owner"];
handler.command = ["sharecode"];
var owner_sharecode_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
