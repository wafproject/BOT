/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - setthumbnail.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_setthumbnail_exports = {};
__export(owner_setthumbnail_exports, {
  default: () => owner_setthumbnail_default
});
module.exports = __toCommonJS(owner_setthumbnail_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
let handler = async (m, { text, command }) => {
  try {
    if (!text || !text.startsWith("http")) {
      return m.reply("\u203C\uFE0F Kirim perintah dengan link thumbnail!!\n\n\u{1F4DD} Contoh penggunaan :\n\n\u2013 .setthumb https://i.supa.codes/ZE0lNH");
    }
    let thumbURL = text.trim();
    let settingsPath = import_path.default.join(__dirname, "../../settings.js");
    let settingsContent = import_fs.default.readFileSync(settingsPath, "utf-8");
    if (!settingsContent.includes("global.thumb")) {
      return m.reply("\u274C Tidak ditemukan global.thumb di settings.js");
    }
    let newContent = settingsContent.replace(/global\.thumb\s*=\s*['"].*?['"];/, `global.thumb = '${thumbURL}';`);
    import_fs.default.writeFileSync(settingsPath, newContent);
    m.reply(`\u2705 Berhasil mengganti thumbnail!!

\u2013 Link thumbnail : ${thumbURL}`);
  } catch (err) {
    console.error(err);
    m.reply("\u274C Terjadi kesalahan saat mengubah thumbnail!");
  }
};
handler.help = ["setthumb <link>"];
handler.tags = ["owner"];
handler.command = /^setthumb$/i;
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_setthumbnail_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
