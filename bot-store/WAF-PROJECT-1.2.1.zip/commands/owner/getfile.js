/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - getfile.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_getfile_exports = {};
__export(owner_getfile_exports, {
  default: () => owner_getfile_default
});
module.exports = __toCommonJS(owner_getfile_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
const tempStorage = {};
const mimeTypes = {
  // Images
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".bmp": "image/bmp",
  // Videos
  ".mp4": "video/mp4",
  ".avi": "video/avi",
  ".mkv": "video/x-matroska",
  ".mov": "video/quicktime",
  ".wmv": "video/x-ms-wmv",
  // Audio
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
  ".ogg": "audio/ogg",
  ".flac": "audio/flac",
  ".aac": "audio/aac",
  // Documents
  ".pdf": "application/pdf",
  ".doc": "application/msword",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".xls": "application/vnd.ms-excel",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".ppt": "application/vnd.ms-powerpoint",
  ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  // Code/Text
  ".js": "text/javascript",
  ".json": "application/json",
  ".html": "text/html",
  ".css": "text/css",
  ".txt": "text/plain",
  ".md": "text/markdown",
  // Fonts
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".eot": "application/vnd.ms-fontobject",
  // Archives
  ".zip": "application/zip",
  ".rar": "application/vnd.rar",
  ".7z": "application/x-7z-compressed",
  // Default fallback
  ".default": "application/octet-stream"
};
const getMimeType = (filePath) => {
  const ext = import_path.default.extname(filePath).toLowerCase();
  return mimeTypes[ext] || mimeTypes[".default"];
};
const sanitizePath = (inputPath) => {
  const projectDir = process.cwd();
  const resolvedPath = import_path.default.resolve(projectDir, inputPath);
  if (!resolvedPath.startsWith(projectDir)) {
    throw new Error("Akses ke path di luar direktori proyek tidak diizinkan!");
  }
  return resolvedPath;
};
let handler = async (m, { jagoanproject, usedPrefix, command, text }) => {
  try {
    if (!text) return m.reply(`*\u203C\uFE0F Format tidak valid.*

\u{1F4DD} Contoh penggunaan:

\u2013 ${usedPrefix + command} path/to/file.js`);
    const [option, filePathInput] = text.split("|").map((str) => str.trim());
    if (!filePathInput) {
      const inputPath = text.trim();
      if (!inputPath) return m.reply(`*\u{1F4DD} Contoh penggunaan:*

\u2013 ${usedPrefix + command} path/to/file.js`);
      const filePath2 = sanitizePath(inputPath);
      if (!import_fs.default.existsSync(filePath2)) {
        if (import_fs.default.existsSync(import_path.default.dirname(filePath2))) {
          const entries = import_fs.default.readdirSync(import_path.default.dirname(filePath2));
          const directories = entries.filter((v) => import_fs.default.lstatSync(import_path.default.join(import_path.default.dirname(filePath2), v)).isDirectory()).map((v) => `\u{1F4C2} ${v}`);
          const files = entries.filter((v) => !import_fs.default.lstatSync(import_path.default.join(import_path.default.dirname(filePath2), v)).isDirectory()).map((v) => `\u{1F4C4} ${v}`);
          const listFiles = [...directories, ...files].join("\n");
          return m.reply(`_'${inputPath}' tidak ditemukan!_

\u{1F4C2} Daftar file di direktori ${import_path.default.dirname(inputPath)}:

${listFiles || "Kosong"}`);
        }
        return m.reply(`_'${inputPath}' tidak ditemukan!_

\u{1F4C2} Pastikan path file valid.`);
      }
      if (import_fs.default.lstatSync(filePath2).isDirectory()) {
        const entries = import_fs.default.readdirSync(filePath2);
        const directories = entries.filter((v) => import_fs.default.lstatSync(import_path.default.join(filePath2, v)).isDirectory()).map((v) => `\u{1F4C2} ${v}`);
        const files = entries.filter((v) => !import_fs.default.lstatSync(import_path.default.join(filePath2, v)).isDirectory()).map((v) => `\u{1F4C4} ${v}`);
        const listFiles = [...directories, ...files].join("\n");
        return m.reply(`\u{1F4C2} Daftar file di direktori *${inputPath}*:

${listFiles || "Kosong"}`);
      }
      tempStorage[m.chat] = inputPath;
      const mimeType2 = getMimeType(filePath2);
      await jagoanproject.sendMessage(m.chat, {
        text: `\u203C\uFE0F *PILIH FORMAT PENGIRIMAN*

\u{1F4C4} *${inputPath}*
\u{1F4CB} *Mimetype:* ${mimeType2}

> Silahkan pilih format pengiriman:`,
        footer: global.namebot || "Bot",
        buttons: [
          {
            buttonId: `${usedPrefix}${command} text|${inputPath}`,
            buttonText: { displayText: "\u{1F4C4} TEXT" },
            type: 1
          },
          {
            buttonId: `${usedPrefix}${command} file|${inputPath}`,
            buttonText: { displayText: "\u{1F4CE} FILE" },
            type: 1
          }
        ],
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
      return;
    }
    if (!["text", "file"].includes(option.toLowerCase())) {
      return m.reply(`*\u203C\uFE0F Format pengiriman tidak valid.*

Pilih salah satu: 'text' atau 'file'

\u{1F4DD} Contoh: ${usedPrefix + command} text|${filePathInput}`);
    }
    const filePath = sanitizePath(filePathInput);
    if (!import_fs.default.existsSync(filePath)) {
      delete tempStorage[m.chat];
      if (import_fs.default.existsSync(import_path.default.dirname(filePath))) {
        const entries = import_fs.default.readdirSync(import_path.default.dirname(filePath));
        const directories = entries.filter((v) => import_fs.default.lstatSync(import_path.default.join(import_path.default.dirname(filePath), v)).isDirectory()).map((v) => `\u{1F4C2} ${v}`);
        const files = entries.filter((v) => !import_fs.default.lstatSync(import_path.default.join(import_path.default.dirname(filePath), v)).isDirectory()).map((v) => `\u{1F4C4} ${v}`);
        const listFiles = [...directories, ...files].join("\n");
        return m.reply(`_'${filePathInput}' tidak ditemukan!_

\u{1F4C2} Daftar file di direktori ${import_path.default.dirname(filePathInput)}:

${listFiles || "Kosong"}`);
      }
      return m.reply(`_'${filePathInput}' tidak ditemukan!_

\u{1F4C2} Pastikan path file valid.`);
    }
    if (import_fs.default.lstatSync(filePath).isDirectory()) {
      delete tempStorage[m.chat];
      const entries = import_fs.default.readdirSync(filePath);
      const directories = entries.filter((v) => import_fs.default.lstatSync(import_path.default.join(filePath, v)).isDirectory()).map((v) => `\u{1F4C2} ${v}`);
      const files = entries.filter((v) => !import_fs.default.lstatSync(import_path.default.join(filePath, v)).isDirectory()).map((v) => `\u{1F4C4} ${v}`);
      const listFiles = [...directories, ...files].join("\n");
      return m.reply(`\u{1F4C2} Daftar file di direktori *${filePathInput}*:

${listFiles || "Kosong"}`);
    }
    const fileName = import_path.default.basename(filePath);
    const fileBuffer = import_fs.default.readFileSync(filePath);
    const mimeType = getMimeType(filePath);
    if (/^text$/i.test(option)) {
      delete tempStorage[m.chat];
      if (!mimeType.startsWith("text/") && !mimeType.includes("json") && !mimeType.includes("javascript")) {
        return m.reply(`\u274C *File ${fileName}* bukan text file!

\u{1F4CB} Gunakan opsi *FILE* untuk mengirim file.`);
      }
      try {
        const fileContent = import_fs.default.readFileSync(filePath, "utf8");
        if (fileContent.length > 65536) {
          return await jagoanproject.sendMessage(m.chat, {
            document: fileBuffer,
            fileName,
            mimetype: mimeType,
            caption: `\u{1F4C4} *${fileName}* dikirim sebagai dokumen karena melebihi batas 65.536 karakter untuk pesan teks.`
          }, { quoted: m });
        }
        const ext = import_path.default.extname(fileName).toLowerCase().replace(".", "") || "txt";
        return await jagoanproject.sendMessage(m.chat, {
          text: `\u{1F4C4} *${fileName}*

\`\`\`${ext}
${fileContent}
\`\`\``
        }, { quoted: m });
      } catch {
        return m.reply(`\u274C *File ${fileName}* tidak dapat dibaca sebagai text! Gunakan opsi *FILE* untuk mengirim file.`);
      }
    }
    if (/^file$/i.test(option)) {
      delete tempStorage[m.chat];
      if (mimeType.startsWith("image/")) {
        return await jagoanproject.sendMessage(m.chat, {
          image: fileBuffer,
          caption: `\u{1F5BC}\uFE0F *${fileName}* (${mimeType})`,
          mimetype: mimeType
        }, { quoted: m });
      } else if (mimeType.startsWith("video/")) {
        return await jagoanproject.sendMessage(m.chat, {
          video: fileBuffer,
          caption: `\u{1F3A5} *${fileName}* (${mimeType})`,
          mimetype: mimeType
        }, { quoted: m });
      } else if (mimeType.startsWith("audio/")) {
        return await jagoanproject.sendMessage(m.chat, {
          audio: fileBuffer,
          mimetype: mimeType,
          ptt: false,
          fileName
        }, { quoted: m });
      } else {
        return await jagoanproject.sendMessage(m.chat, {
          document: fileBuffer,
          fileName,
          mimetype: mimeType,
          caption: `\u{1F4C4} *${fileName}* (${mimeType})`
        }, { quoted: m });
      }
    }
  } catch (e) {
    delete tempStorage[m.chat];
    return m.reply(`\u274C Terjadi kesalahan: ${e.message}`);
  }
};
handler.help = ["getfile"].map((v) => v + " <path/to/file> atau <format>|<path/to/file>");
handler.tags = ["owner"];
handler.command = /^(getfile|gf)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_getfile_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
