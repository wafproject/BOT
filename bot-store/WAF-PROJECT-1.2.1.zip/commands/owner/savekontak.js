/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - savekontak.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_savekontak_exports = {};
__export(owner_savekontak_exports, {
  default: () => owner_savekontak_default
});
module.exports = __toCommonJS(owner_savekontak_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
function cleanName(value = "") {
  return String(value || "").replace(/[\r\n\t]+/g, " ").replace(/\s+/g, " ").trim();
}
function isUsableContactName(value = "", phoneNumber = "") {
  const name = cleanName(value);
  if (!name) return false;
  const lower = name.toLowerCase();
  if ([
    "unknown",
    "pengguna",
    "user",
    "private",
    "whatsapp user",
    "tidak diketahui",
    "unknown user",
    "grup",
    "group"
  ].includes(lower)) return false;
  const digits = name.replace(/\D/g, "");
  const phoneDigits = String(phoneNumber || "").replace(/\D/g, "");
  if (phoneDigits && digits === phoneDigits) return false;
  if (/^\+?[\d\s().-]{6,}$/.test(name)) return false;
  if (/@(?:s\.whatsapp\.net|lid|c\.us)$/i.test(name)) return false;
  return true;
}
function escapeVCardText(value = "") {
  return cleanName(value).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,");
}
function directPhoneJid(jagoanproject, value) {
  if (!value) return "";
  let jid = typeof value === "string" ? value : String(value || "");
  try {
    jid = jagoanproject.decodeJid(jid) || jid;
  } catch {
  }
  jid = String(jid || "").trim().replace(/@c\.us$/i, "@s.whatsapp.net");
  if (/^\d+$/.test(jid)) jid = `${jid}@s.whatsapp.net`;
  return jid.endsWith("@s.whatsapp.net") ? jid : "";
}
async function resolveParticipantPhoneJid(jagoanproject, participant, groupJid, groupMetadata) {
  const candidates = [
    participant?.phoneNumber,
    participant?.pn,
    participant?.participantAlt,
    participant?.remoteJidAlt,
    participant?.phoneJid,
    participant?.jid,
    participant?.id,
    participant?.participant,
    participant?.user
  ].filter(Boolean);
  for (const candidate of candidates) {
    const phoneJid = directPhoneJid(jagoanproject, candidate);
    if (phoneJid) return phoneJid;
  }
  if (typeof jagoanproject.resolveJid === "function") {
    try {
      const resolved = await jagoanproject.resolveJid(participant, { groupJid, groupMetadata });
      const phoneJid = directPhoneJid(jagoanproject, resolved);
      if (phoneJid) return phoneJid;
    } catch (e) {
      console.warn("[savekontak] Gagal resolve participant JID:", e?.message || e);
    }
    for (const candidate of candidates) {
      try {
        const resolved = await jagoanproject.resolveJid(candidate, { groupJid, groupMetadata });
        const phoneJid = directPhoneJid(jagoanproject, resolved);
        if (phoneJid) return phoneJid;
      } catch {
      }
    }
  }
  return "";
}
function collectIdentityKeys(jagoanproject, participant, phoneJid) {
  const rawKeys = [
    phoneJid,
    participant?.phoneNumber,
    participant?.pn,
    participant?.participantAlt,
    participant?.remoteJidAlt,
    participant?.phoneJid,
    participant?.jid,
    participant?.id,
    participant?.participant,
    participant?.user,
    participant?.lid
  ].filter(Boolean);
  const keys = /* @__PURE__ */ new Set();
  const add = (value) => {
    if (!value) return;
    let jid = String(value || "").trim();
    if (!jid) return;
    keys.add(jid);
    try {
      const decoded = jagoanproject.decodeJid(jid);
      if (decoded) keys.add(String(decoded));
    } catch {
    }
    if (jid.endsWith("@c.us")) keys.add(jid.replace(/@c\.us$/i, "@s.whatsapp.net"));
    if (/^\d+$/.test(jid)) keys.add(`${jid}@s.whatsapp.net`);
  };
  for (const value of rawKeys) add(value);
  for (const key of [...keys]) {
    try {
      const lid = jagoanproject.__jidMapping?.pnToLid?.get?.(key);
      if (lid) add(lid);
    } catch {
    }
    try {
      const pn = jagoanproject.__jidMapping?.lidToPn?.get?.(key);
      if (pn) add(pn);
    } catch {
    }
  }
  return [...keys];
}
function getChatRecords(jagoanproject, participant, phoneJid) {
  const records = [];
  for (const key of collectIdentityKeys(jagoanproject, participant, phoneJid)) {
    const record = jagoanproject.chats?.[key];
    if (record && typeof record === "object" && !records.includes(record)) records.push(record);
  }
  return records;
}
function getDbUserRecords(jagoanproject, participant, phoneJid) {
  const users = global.db?.data?.users;
  if (!users || typeof users !== "object") return [];
  const records = [];
  for (const key of collectIdentityKeys(jagoanproject, participant, phoneJid)) {
    const record = users[key];
    if (record && typeof record === "object" && !records.includes(record)) records.push(record);
  }
  return records;
}
function firstUsableName(values, phoneJid) {
  for (const value of values) {
    if (isUsableContactName(value, phoneJid)) return cleanName(value);
  }
  return "";
}
async function resolveContactName(jagoanproject, participant, phoneJid, groupJid, groupMetadata) {
  let name = firstUsableName([
    participant?.name,
    participant?.displayName,
    participant?.contactName,
    participant?.notify,
    participant?.pushName,
    participant?.pushname,
    participant?.verifiedName,
    participant?.verified_name,
    participant?.shortName
  ], phoneJid);
  if (name) return name;
  const chatRecords = getChatRecords(jagoanproject, participant, phoneJid);
  const dbRecords = getDbUserRecords(jagoanproject, participant, phoneJid);
  name = firstUsableName([
    ...chatRecords.flatMap((record) => [record?.pushName, record?.notify]),
    ...dbRecords.flatMap((record) => [record?.waPushName, record?.pushName])
  ], phoneJid);
  if (name) return name;
  name = firstUsableName([
    ...chatRecords.flatMap((record) => [
      record?.name,
      record?.vname,
      record?.verifiedName,
      record?.displayName,
      record?.contactName
    ]),
    ...dbRecords.flatMap((record) => [record?.contactName, record?.displayName, record?.name])
  ], phoneJid);
  if (name) return name;
  name = firstUsableName([
    participant?.username,
    participant?.userName,
    participant?.waUsername,
    ...chatRecords.flatMap((record) => [record?.username, record?.userName, record?.waUsername]),
    ...dbRecords.flatMap((record) => [record?.username, record?.userName, record?.waUsername])
  ], phoneJid);
  if (name) return name;
  try {
    const resolvedName = typeof jagoanproject.getNameAsync === "function" ? await jagoanproject.getNameAsync(phoneJid, false, { groupJid, groupMetadata }) : await Promise.resolve(jagoanproject.getName?.(phoneJid));
    if (isUsableContactName(resolvedName, phoneJid)) return cleanName(resolvedName);
  } catch (e) {
    console.warn(`[savekontak] Gagal mengambil nama ${phoneJid}:`, e?.message || e);
  }
  return "";
}
let handler = async (m, { jagoanproject, isOwner, groupMetadata }) => {
  const isGroup = String(m.chat || "").endsWith("@g.us");
  if (!isOwner) return m.reply("\u{1F6AB} *Perintah ini hanya untuk owner bot!*");
  if (!isGroup) return m.reply(`\u{1F6AB} *Perintah ini hanya bisa digunakan di grup! ID Chat: ${m.chat}`);
  if (!groupMetadata) return m.reply("\u274C *Gagal mendapatkan metadata grup. Pastikan bot memiliki akses ke grup!*");
  const databaseDir = import_path.default.join(__dirname, "../../database");
  if (!import_fs.default.existsSync(databaseDir)) import_fs.default.mkdirSync(databaseDir, { recursive: true });
  const contactsFile = import_path.default.join(databaseDir, "contacts.json");
  const vcardFile = import_path.default.join(databaseDir, "contacts.vcf");
  if (!import_fs.default.existsSync(contactsFile)) import_fs.default.writeFileSync(contactsFile, JSON.stringify([]));
  try {
    const participants = Array.isArray(groupMetadata.participants) ? groupMetadata.participants : [];
    if (!participants.length) return m.reply("\u274C *Tidak ada peserta di grup ini!*");
    const groupName = cleanName(groupMetadata.subject || "Group").replace(/;/g, " ") || "Group";
    const contacts = [];
    let privateCounter = 0;
    let unresolvedCounter = 0;
    for (const participant of participants) {
      const jid = await resolveParticipantPhoneJid(jagoanproject, participant, m.chat, groupMetadata);
      if (!jid) {
        unresolvedCounter += 1;
        console.warn("[savekontak] Participant dilewati karena nomor WA tidak dapat di-resolve:", participant?.id || participant?.jid || participant?.lid || participant);
        continue;
      }
      const number = jid.split("@")[0].replace(/\D/g, "");
      if (!number) {
        unresolvedCounter += 1;
        continue;
      }
      let contactName = await resolveContactName(jagoanproject, participant, jid, m.chat, groupMetadata);
      if (!contactName) {
        privateCounter += 1;
        contactName = `${groupName} #${String(privateCounter).padStart(2, "0")}`;
      }
      contacts.push({
        jid,
        phoneNumber: `+${number}`,
        name: contactName
      });
    }
    if (!contacts.length) return m.reply("\u274C *Tidak ada kontak valid untuk disimpan!*");
    import_fs.default.writeFileSync(contactsFile, JSON.stringify(contacts, null, 2), "utf8");
    const vcardContent = contacts.map(({ phoneNumber, name }) => [
      "BEGIN:VCARD",
      "VERSION:3.0",
      `FN:${escapeVCardText(name)}`,
      `TEL;type=CELL;type=VOICE:${phoneNumber}`,
      "END:VCARD",
      ""
    ].join("\r\n")).join("");
    import_fs.default.writeFileSync(vcardFile, vcardContent, "utf8");
    const safeFileName = groupName.replace(/[^a-zA-Z0-9._-]+/g, "_").replace(/^_+|_+$/g, "") || "Group";
    const skippedInfo = unresolvedCounter ? `
\u26A0\uFE0F ${unresolvedCounter} participant tidak punya nomor WA yang bisa di-resolve.` : "";
    await jagoanproject.sendMessage(m.chat, {
      document: import_fs.default.readFileSync(vcardFile),
      fileName: `${safeFileName}_contacts.vcf`,
      caption: `\u2705 *File kontak berhasil dibuat! Total: ${contacts.length} kontak*${skippedInfo}`,
      mimetype: "text/vcard"
    }, { quoted: m });
  } catch (err) {
    console.error("Error in savekontak:", err);
    await m.reply(`\u274C *Error:* ${err?.message || String(err)}`);
  } finally {
    try {
      import_fs.default.writeFileSync(contactsFile, JSON.stringify([]), "utf8");
    } catch {
    }
    try {
      import_fs.default.writeFileSync(vcardFile, "", "utf8");
    } catch {
    }
  }
};
handler.command = ["savekontak"];
handler.tags = ["owner", "group"];
handler.help = ["savekontak"];
handler.group = true;
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_savekontak_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
