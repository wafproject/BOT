/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - spamedit.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_spamedit_exports = {};
__export(owner_spamedit_exports, {
  default: () => owner_spamedit_default
});
module.exports = __toCommonJS(owner_spamedit_exports);
const handler = async (message, { usedPrefix, command, text, jagoanproject }) => {
  if (!jagoanproject) {
    console.error("Error: Objek jagoanproject tidak didefinisikan");
    return message.reply("\u274C Terjadi kesalahan: koneksi bot tidak tersedia.");
  }
  const args = (text || "").trim().split(/\s+/).filter(Boolean);
  if (args.length < 1) {
    return await jagoanproject.sendMessage(
      message.chat,
      {
        text: `Format: \`${usedPrefix + command} <target>\`
Contoh: \`${usedPrefix + command} 100\``
      },
      { quoted: message }
    );
  }
  const target = parseInt(args[0]);
  if (isNaN(target) || target < 1 || target > 1e4) {
    return await jagoanproject.sendMessage(
      message.chat,
      { text: "Target harus angka 1\u201310000" },
      { quoted: message }
    );
  }
  const sent = await jagoanproject.sendMessage(
    message.chat,
    { text: "0" },
    { quoted: message }
  );
  if (!sent || !sent.key) {
    return await jagoanproject.sendMessage(
      message.chat,
      { text: "Gagal mengirim pesan awal" },
      { quoted: message }
    );
  }
  const key = sent.key;
  for (let i = 1; i <= target; i++) {
    await jagoanproject.sendMessage(message.chat, {
      text: `${i}`,
      edit: key
    });
  }
  await jagoanproject.sendMessage(message.chat, {
    text: `Selesai! Telah diedit ${target}\xD7`,
    edit: key
  });
};
handler.help = ["spamedit <target>"];
handler.tags = ["owner"];
handler.command = /^(spamedit|spam-edit|se)$/i;
handler.rowner = true;
handler.limit = false;
handler.register = false;
var owner_spamedit_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
