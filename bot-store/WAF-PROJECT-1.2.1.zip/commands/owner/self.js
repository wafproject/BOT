/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - self.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_self_exports = {};
__export(owner_self_exports, {
  default: () => owner_self_default
});
module.exports = __toCommonJS(owner_self_exports);
let handler = async (m, { jagoanproject, command }) => {
  let isPublic = command === "public";
  let self = global.opts["self"];
  if (self === !isPublic) return m.reply(`Is it ${!isPublic ? "Self" : "Public"} from earlier ${m.sender.split("@")[0] === global.jpOwner[1] ? "Sister" : "Brother"}`);
  global.opts["self"] = !isPublic;
  m.reply(`Success *${!isPublic ? "Self" : "Public"}* bot!`);
};
handler.help = ["self", "public"].map((a) => a + " *[options]*");
handler.tags = ["owner"];
handler.owner = true;
handler.command = /^(self|public)$/i;
handler.register = true;
handler.limit = true;
var owner_self_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
