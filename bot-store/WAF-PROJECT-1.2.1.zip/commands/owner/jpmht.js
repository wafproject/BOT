/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - jpmht.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_jpmht_exports = {};
__export(owner_jpmht_exports, {
  default: () => owner_jpmht_default
});
module.exports = __toCommonJS(owner_jpmht_exports);
let handler = async (m, { jagoanproject, text, participants }) => {
  const delayjpm = 10;
  let groups = Object.entries(jagoanproject.chats).filter(([jid, chat]) => jid.endsWith("@g.us") && chat.isChats && !chat.metadata?.read_only && !chat.metadata?.announce).map((v) => v[0]);
  if (groups.length === 0) {
    return jagoanproject.reply(m.chat, "\u{1F6AB} *Oops!* Bot belum bergabung di grup mana pun nih! \u{1F605}", m);
  }
  let [jumlah, teks] = text.split("|").map((item) => item.trim());
  if (!text || !jumlah || !teks) {
    return jagoanproject.reply(
      m.chat,
      `\u2728 *Halo bro!* \u2728
Formatnya salah nih, wajib masukin jumlah grup dan teks ya! \u{1F4E9}
\u{1F4DD} *Cara pakai:* .jmpht <jumlah>|<teks>
\u{1F31F} *Contoh:* .jmpht 3|Halo bro, apa kabar?
\u{1F4CA} *Maksimal grup:* ${groups.length}
> JPM Veri Hidetag`,
      m
    );
  }
  jumlah = parseInt(jumlah);
  if (isNaN(jumlah) || jumlah <= 0) {
    return jagoanproject.reply(
      m.chat,
      `\u26A0\uFE0F *Eits!* Jumlah grup harus angka positif dong! \u{1F61C}
\u{1F4CA} *Maksimal grup:* ${groups.length}
\u{1F4DD} *Contoh:* .jmpht 3|Halo bro`,
      m
    );
  }
  if (jumlah > groups.length) {
    return jagoanproject.reply(
      m.chat,
      `\u{1F6A8} *Waduh!* Jumlah yang kamu minta (${jumlah}) kebanyakan bro! \u{1F605}
\u{1F4CA} *Maksimal grup:* ${groups.length}
\u{1F4DD} *Contoh:* .jmpht ${groups.length}|Halo bro`,
      m
    );
  }
  const qlocJpm = {
    key: {
      participant: "0@s.whatsapp.net",
      ...m.chat ? { remoteJid: `status@broadcast` } : {}
    },
    message: {
      locationMessage: {
        name: `\u{1F4E3} Broadcast`,
        jpegThumbnail: ""
      }
    }
  };
  try {
    let selectedGroups = groups.sort(() => 0.5 - Math.random()).slice(0, jumlah);
    await jagoanproject.reply(
      m.chat,
      `\u{1F680} *Siap bro!* Mengirim pesan JMPHT ke ${selectedGroups.length} grup acak... \u23F3`,
      m
    );
    let successCount = 0;
    for (let id of selectedGroups) {
      try {
        let member = participants.map((v) => v.id) || [];
        await jagoanproject.sendMessage(id, {
          text: `${teks}`,
          mentions: member
          // Menambahkan hidetag untuk semua member
        }, {
          quoted: qlocJpm
        });
        successCount++;
        await new Promise((resolve) => setTimeout(resolve, delayjpm * 1e3));
      } catch (error) {
        console.log(`Gagal mengirim ke ${id}: ${error}`);
      }
    }
    await jagoanproject.reply(
      m.chat,
      `\u{1F389} *Selesai bro!* \u{1F389}
\u2705 Terkirim ke: ${successCount} dari ${selectedGroups.length} grup

> Jika ada yang tidak terkirim, pastikan bot memiliki akses mengirim pesan ke grup tersebut`,
      m
    );
  } catch (error) {
    console.error(error);
    await jagoanproject.reply(
      m.chat,
      `\u{1F631} *Aduh!* Ada error nih bro saat kirim JMPHT! Coba lagi ya! \u{1F64F}`,
      m
    );
  }
};
handler.help = ["jpmht <jumlah>|<teks>"];
handler.tags = ["owner"];
handler.command = /^jmpht$/i;
handler.owner = true;
handler.rowner = false;
handler.register = true;
handler.limit = true;
var owner_jpmht_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
