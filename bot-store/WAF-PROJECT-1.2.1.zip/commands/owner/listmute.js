/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - listmute.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_listmute_exports = {};
__export(owner_listmute_exports, {
  default: () => owner_listmute_default
});
module.exports = __toCommonJS(owner_listmute_exports);
let handler = async (m, { jagoanproject, args }) => {
  let chats = global.db.data.chats;
  let mutedChats = Object.entries(chats).filter(([_, chat]) => chat.isBanned);
  if (args[0]) {
    let index = parseInt(args[0]) - 1;
    if (isNaN(index) || index < 0 || index >= mutedChats.length) {
      return m.reply("\u274C Nomor yang kamu masukkan tidak valid.");
    }
    let [chatId] = mutedChats[index];
    chats[chatId].isBanned = false;
    return m.reply(`\u2705 Berhasil meng-unmute grup:
*${chatId}*`);
  }
  if (mutedChats.length === 0) {
    return m.reply("\u2705 Tidak ada grup yang sedang di-mute.");
  }
  let list = "";
  for (let i = 0; i < mutedChats.length; i++) {
    let [id] = mutedChats[i];
    let name = "\u274C Tidak diketahui (bot kemungkinan sudah keluar dari grup)";
    if (id.endsWith("@g.us")) {
      try {
        let metadata = await jagoanproject.groupMetadata(id);
        name = metadata.subject || name;
      } catch (e) {
      }
    } else {
      name = "\u274C Bukan grup WA (bukan @g.us)";
    }
    list += `${i + 1}. *${name}*
   _${id}_

`;
  }
  return m.reply(`\u{1F4C3} *Daftar Grup yang di-Mute:*

${list}Ketik *listmute [nomor]* untuk meng-unmute.`);
};
handler.help = ["listmute"];
handler.tags = ["owner"];
handler.command = ["listmute"];
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_listmute_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
