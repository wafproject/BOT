/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - dellimit.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_dellimit_exports = {};
__export(owner_dellimit_exports, {
  default: () => owner_dellimit_default
});
module.exports = __toCommonJS(owner_dellimit_exports);
let handler = async (m, { jagoanproject, text }) => {
  if (!text) {
    return jagoanproject.reply(m.chat, "\u2022 *Example :* .dellimit @user 10", m);
  }
  let mentionedJid = m.mentionedJid[0];
  if (!mentionedJid) {
    return jagoanproject.reply(m.chat, "Tag pengguna yang ingin dikurangi limitnya. Contoh: .dellimit @user 10", m);
  }
  let pointsToSubtract = parseInt(text.split(" ")[1]);
  if (isNaN(pointsToSubtract)) {
    return jagoanproject.reply(m.chat, "Jumlah limit yang dimasukkan harus berupa angka. Contoh: .dellimit @user 10", m);
  }
  let users = global.db.data.users;
  if (!users[mentionedJid]) {
    users[mentionedJid] = {
      limit: 0,
      exp: 0,
      lastclaim: 0
    };
  }
  users[mentionedJid].limit -= pointsToSubtract;
  if (users[mentionedJid].limit < 0) {
    users[mentionedJid].limit = 0;
  }
  jagoanproject.reply(m.chat, `Berhasil mengurangi ${pointsToSubtract} limit untuk @${mentionedJid.split("@")[0]}.`, m, {
    mentions: [mentionedJid]
  });
};
handler.help = ["dellimit *@user/<amount>*"];
handler.tags = ["owner"];
handler.command = /^dellimit$/i;
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_dellimit_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
