/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - creategc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_creategc_exports = {};
__export(owner_creategc_exports, {
  default: () => owner_creategc_default
});
module.exports = __toCommonJS(owner_creategc_exports);
let handler = async (m, { jagoanproject, text, isOwner }) => {
  if (!text) return m.reply("\u2022 *Example:* .creategc *[Nama Grup]*");
  try {
    await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
    let group = await jagoanproject.groupCreate(text, [m.sender]);
    let link = await jagoanproject.groupInviteCode(group.gid);
    let url = "https://chat.whatsapp.com/" + link;
    await jagoanproject.groupParticipantsUpdate(group.gid, [m.sender], "promote");
    m.reply(`_Berhasil Membuat Grup *${text}*_

*Nama:* ${text}
*ID:* ${group.gid}
*Link:* ${url}`);
  } catch (e) {
    console.error(e);
    await jagoanproject.sendMessage(m.chat, global.eror, { quoted: m });
  }
};
handler.help = ["creategroup"].map((a) => a + " *[Nama Grup]*");
handler.tags = ["owner"];
handler.command = /^((create|buat)(gc|grup|group))$/;
handler.owner = true;
handler.rowner = true;
handler.group = true;
handler.register = true;
handler.limit = true;
var owner_creategc_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
