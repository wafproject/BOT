/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - ownlist.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_ownlist_exports = {};
__export(owner_ownlist_exports, {
  default: () => owner_ownlist_default
});
module.exports = __toCommonJS(owner_ownlist_exports);
let handler = async (m, { jagoanproject }) => {
  if (!global.jpOwner || global.jpOwner.length === 0) {
    return m.reply("Belum ada owner yang terdaftar.");
  }
  let teks = "*\u2261 Daftar Owner Bot:*\n\n";
  global.jpOwner.forEach(([id, name = "", isActive], index) => {
    teks += `*${index + 1}.* @${id}${name ? ` (${name})` : ""}${isActive ? " \u2705 Aktif" : ""}
`;
  });
  await jagoanproject.reply(m.chat, teks.trim(), m, {
    mentions: global.jpOwner.map(([id]) => id + "@s.whatsapp.net")
  });
};
handler.help = ["ownerlist"];
handler.tags = ["owner"];
handler.command = /^ownerlist$/i;
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_ownlist_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
