/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - save-global.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_save_global_exports = {};
__export(owner_save_global_exports, {
  default: () => owner_save_global_default
});
module.exports = __toCommonJS(owner_save_global_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const handler = async (m, { text, usedPrefix, command, jagoanproject }) => {
  if (!m.quoted || !m.quoted.mtype.includes("document")) {
    throw `\u{1F4C1} *Fitur Simpan File*

\u27A4 Balas file yang ingin disimpan
\u27A4 Ketik: *${usedPrefix + command} [path/namafile]*

Contoh:
.save ./folder/file.js
.save ./media/11/`;
  }
  let inputPath = text?.trim() || "";
  let dir = ".";
  let filename = m.quoted.fileName || "file.unknown";
  if (inputPath) {
    let resolvedPath = import_path.default.resolve(inputPath);
    let isDirectory = false;
    if (inputPath.endsWith("/")) {
      isDirectory = true;
    } else if (import_fs.default.existsSync(resolvedPath)) {
      try {
        isDirectory = import_fs.default.statSync(resolvedPath).isDirectory();
      } catch {
        isDirectory = false;
      }
    }
    if (isDirectory) {
      dir = resolvedPath;
    } else {
      dir = import_path.default.dirname(resolvedPath);
      filename = import_path.default.basename(resolvedPath);
    }
  }
  if (!filename || filename === ".") {
    throw `\u2757 Nama file tidak valid.`;
  }
  const fullPath = import_path.default.resolve(dir, filename);
  if (!import_fs.default.existsSync(dir)) {
    throw `\u2757 Direktori *${dir}* tidak ditemukan.`;
  }
  if (!import_fs.default.statSync(dir).isDirectory()) {
    throw `\u2757 Path *${dir}* bukan direktori.`;
  }
  if (import_fs.default.existsSync(fullPath) && import_fs.default.statSync(fullPath).isDirectory()) {
    throw `\u2757 Path *${fullPath}* adalah direktori, bukan file.`;
  }
  const loading = await jagoanproject.sendMessage(m.chat, { text: "\u23F3 Menyimpan file..." });
  const msgKey = loading.key;
  for (let i = 0; i < 2; i++) {
    await sleep(800);
    await jagoanproject.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: { conversation: `\u23F3 Menyimpan${".".repeat(i + 1)}` }
      }
    }, {});
  }
  try {
    const buffer = await m.quoted.download();
    import_fs.default.writeFileSync(fullPath, buffer);
    await jagoanproject.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: { conversation: `\u2705 File berhasil disimpan di:
\u{1F4C1} *${fullPath}*` }
      }
    }, {});
  } catch (err) {
    await jagoanproject.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: { conversation: `\u274C Gagal menyimpan file!
Error: ${err.message}` }
      }
    }, {});
  }
};
handler.help = ["save [path/nama_file]"];
handler.tags = ["owner"];
handler.command = /^save$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_save_global_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
