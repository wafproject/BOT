/**
 * .cekapikey — tes apakah API key BOTCAHX (global.btc) diterima server.
 * botcahx tidak punya endpoint cek key resmi, jadi dites ke endpoint ringan.
 */
const btc = require('../../lib/botcahx.js')

const handler = async (m, { usedPrefix }) => {
  const key = String(global.btc || '').trim()
  if (!key) return m.reply(`❌ global.btc masih kosong. Isi dengan *${usedPrefix}setapikey <apikey>*`)
  const masked = key.length > 4 ? key.slice(0, 2) + '•'.repeat(key.length - 4) + key.slice(-2) : '••••'
  try {
    await btc.callApi('/api/randomtext/fakta', {})
    return m.reply(`✅ *API key botcahx aktif*\n🔑 ${masked}\n🌐 ${global.apibtc || 'https://api.botcahx.eu.org'}`)
  } catch (e) {
    const msg = String(e?.message || e).split(key).join('***')
    return m.reply(`❌ *API key botcahx bermasalah*\n🔑 ${masked}\n\n${msg.slice(0, 300)}\n\nGanti dengan *${usedPrefix}setapikey <apikey>* (ambil dari akun api.botcahx.eu.org).`)
  }
}

handler.help = ['cekapikey']
handler.tags = ['owner']
handler.category = 'owner'
handler.command = /^(cekapikey)$/i
handler.rowner = true

module.exports = handler
