/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - resetuser.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_resetuser_exports = {};
__export(owner_resetuser_exports, {
  default: () => owner_resetuser_default
});
module.exports = __toCommonJS(owner_resetuser_exports);
let handler = async (m, { jagoanproject, text }) => {
  function no(number) {
    return number.replace(/\s/g, "").replace(/([@+-])/g, "");
  }
  let input = text ? no(text) : "";
  let user;
  try {
    if (m.mentionedJid && m.mentionedJid[0]) {
      user = m.mentionedJid[0];
    } else if (m.quoted && m.quoted.sender) {
      user = m.quoted.sender;
    } else if (input) {
      if (isNaN(input)) {
        const split = input.split("@");
        if (split.length > 1 && split[1]) {
          user = no(split[1]) + "@s.whatsapp.net";
        } else {
          return jagoanproject.reply(m.chat, `\u274C *Nomor tidak valid!*
Gunakan format: @tag / reply / 628xxx`, m);
        }
      } else {
        if (input.length < 9 || input.length > 15) {
          return jagoanproject.reply(m.chat, `\u26A0\uFE0F *Panjang nomor tidak valid!*
Minimal 9, maksimal 15 digit.`, m);
        }
        user = input + "@s.whatsapp.net";
      }
    } else {
      return jagoanproject.reply(m.chat, `\u2753 *Cara Pakai:*
\u2022 Tag user: @user
\u2022 Reply pesan user
\u2022 Ketik nomor: 628xxx`, m);
    }
    if (!user || !user.includes("@s.whatsapp.net")) {
      return jagoanproject.reply(m.chat, `\u{1F6AB} *Gagal mendeteksi user!*
Coba tag, reply, atau ketik nomor dengan benar.`, m);
    }
    const number = user.split("@")[0];
    if (!global.db.data.users[user]) {
      return jagoanproject.reply(m.chat, `\u2139\uFE0F *@${number}* tidak terdaftar di database.`, m, {
        contextInfo: { mentionedJid: [user] }
      });
    }
    delete global.db.data.users[user];
    jagoanproject.reply(
      m.chat,
      `\u2705 *BERHASIL DI-RESET!*

\u{1F464} User: @${number}
\u{1F5D1}\uFE0F Data telah dihapus dari database.
\u{1F504} Bot akan melupakan semua data user ini.`,
      m,
      {
        contextInfo: { mentionedJid: [user] }
      }
    );
  } catch (e) {
    console.log(e);
    jagoanproject.reply(m.chat, `\u2757 *Terjadi kesalahan!*
Coba lagi atau hubungi owner.`, m);
  }
};
handler.help = ["reset @user/reply/628xxx"];
handler.tags = ["owner"];
handler.command = /^reset$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_resetuser_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
