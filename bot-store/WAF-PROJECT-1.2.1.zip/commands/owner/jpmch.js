/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - jpmch.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_jpmch_exports = {};
__export(owner_jpmch_exports, {
  default: () => owner_jpmch_default
});
module.exports = __toCommonJS(owner_jpmch_exports);
let handler = async (m, { jagoanproject, text, command }) => {
  const delayjpmch = 5;
  if (command === "listchannels") {
    let channels2 = Object.entries(jagoanproject.chats).filter(([jid, chat]) => jid.endsWith("@newsletter") && chat.isChats).map((v) => ({ jid: v[0], metadata: v[1].metadata || {} }));
    let response = `\u{1F4CB} *Daftar Saluran:*

`;
    if (channels2.length === 0) {
      response += `Tidak ada saluran yang ditemukan. \u{1F605}
`;
    } else {
      channels2.forEach((c) => {
        response += `JID: ${c.jid}
`;
        response += `Metadata: ${JSON.stringify(c.metadata, null, 2)}

`;
      });
    }
    response += `> Jika saluran tidak terdeteksi, coba restart bot atau gunakan .refreshchannels`;
    return jagoanproject.reply(m.chat, response, m);
  }
  if (command === "refreshchannels") {
    try {
      await jagoanproject.chatModify({ refresh: true }, m.chat);
      return jagoanproject.reply(m.chat, `\u{1F504} *Menyegarkan data saluran...* Coba lagi .jpmch atau .listchannels setelah beberapa detik.`, m);
    } catch (error) {
      return jagoanproject.reply(m.chat, `\u274C Gagal menyegarkan data saluran: ${error.message}`, m);
    }
  }
  let channels = Object.entries(jagoanproject.chats).filter(([jid, chat]) => jid.endsWith("@newsletter") && chat.isChats).map((v) => v[0]);
  console.log("Saluran terdeteksi:", channels);
  if (channels.length === 0) {
    return jagoanproject.reply(
      m.chat,
      `\u{1F6AB} *Oops!* Tidak ada saluran yang ditemukan nih! \u{1F605}
> Coba gunakan .listchannels untuk melihat daftar saluran.
> Gunakan .refreshchannels untuk menyegarkan data saluran.`,
      m
    );
  }
  if (!text || text.trim() === "") {
    return jagoanproject.reply(
      m.chat,
      `\u2728 *Halo bro!* \u2728
Formatnya salah nih, wajib masukin teks ya! \u{1F4E9}
\u{1F4DD} *Cara pakai:* .jpmch <teks>
\u{1F31F} *Contoh:* .jpmch Halo bro, apa kabar?
\u{1F4CA} *Jumlah saluran:* ${channels.length}`,
      m
    );
  }
  const qlocJpmch = {
    key: {
      participant: "0@s.whatsapp.net",
      ...m.chat ? { remoteJid: `status@broadcast` } : {}
    },
    message: {
      locationMessage: {
        name: `\u{1F4E3} Broadcast Saluran`,
        jpegThumbnail: ""
      }
    }
  };
  try {
    await jagoanproject.reply(
      m.chat,
      `\u{1F680} *Siap bro!* Mengirim pesan JPMCH ke ${channels.length} saluran... \u23F3`,
      m
    );
    let successCount = 0;
    for (let id of channels) {
      try {
        await jagoanproject.sendMessage(id, {
          text: text.trim()
        }, {
          quoted: qlocJpmch
        });
        successCount++;
        await new Promise((resolve) => setTimeout(resolve, delayjpmch * 1e3));
      } catch (error) {
        console.log(`Gagal mengirim ke ${id}: ${error}`);
      }
    }
    await jagoanproject.reply(
      m.chat,
      `\u{1F389} *Selesai bro!* \u{1F389}
\u2705 Terkirim ke: ${successCount} dari ${channels.length} saluran

> Jika ada yang tidak terkirim, pastikan bot memiliki akses untuk mengirim pesan ke saluran tersebut.`,
      m
    );
  } catch (error) {
    console.error(error);
    await jagoanproject.reply(
      m.chat,
      `\u{1F631} *Aduh!* Ada error nih bro saat kirim JPMCH! Coba lagi ya! \u{1F64F}
> Debug info: ${error.message}`,
      m
    );
  }
};
handler.help = ["jpmch <teks>", "listchannels", "refreshchannels"];
handler.tags = ["owner"];
handler.command = /^(jpmch|listchannels|refreshchannels)$/i;
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_jpmch_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
