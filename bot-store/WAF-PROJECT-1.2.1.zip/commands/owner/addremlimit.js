/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - addremlimit.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_addremlimit_exports = {};
__export(owner_addremlimit_exports, {
  default: () => owner_addremlimit_default
});
module.exports = __toCommonJS(owner_addremlimit_exports);
let handler = async (m, { jagoanproject, usedPrefix, command, text, args }) => {
  let who;
  let limitValue;
  let input = text.trim();
  if (m.isGroup) {
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      who = m.mentionedJid[0];
      limitValue = args[1];
    } else if (m.quoted) {
      who = m.quoted.sender;
      limitValue = args[0];
    } else if (input) {
      let parts = input.split(" ");
      who = parts[0].replace(/[^0-9]/g, "").replace(/^(\+62|62)/, "62") + "@s.whatsapp.net";
      limitValue = parts[1];
    } else {
      throw `\u2022 *Example:* ${usedPrefix + command} *[@user | reply | number] & limit*

\u{1F4DD} Contoh penggunaan:
\u2014 ${usedPrefix + command} @user 10
\u2014 ${usedPrefix + command} reply 5
\u2014 ${usedPrefix + command} 6285257129838 15`;
    }
  } else {
    if (input) {
      let parts = input.split(" ");
      who = parts[0].replace(/[^0-9]/g, "").replace(/^(\+62|62)/, "62") + "@s.whatsapp.net";
      limitValue = parts[1];
    } else {
      who = m.sender;
      limitValue = args[0];
    }
  }
  if (!who) throw "*[ ! ] User tidak valid!*";
  if (!limitValue) throw "*[ ! ] Masukkan jumlah limit!*";
  if (isNaN(limitValue)) throw "*[ ! ] Hanya angka yang diperbolehkan!*";
  limitValue = parseInt(limitValue);
  let users = global.db.data.users;
  if (!users[who]) users[who] = { limit: 0 };
  if (command === "addlimit") {
    users[who].limit += limitValue;
    jagoanproject.reply(m.chat, `\u2705 Berhasil menambahkan ${limitValue} limit untuk @${who.split("@")[0]}!`, m);
  } else if (command === "remlimit") {
    if (limitValue > users[who].limit) {
      users[who].limit = 0;
      jagoanproject.reply(m.chat, `\u2705 Berhasil mengurangi limit untuk @${who.split("@")[0]}. Limit sekarang 0!`, m);
    } else {
      users[who].limit -= limitValue;
      jagoanproject.reply(m.chat, `\u2705 Berhasil mengurangi ${limitValue} limit untuk @${who.split("@")[0]}!`, m);
    }
  }
};
handler.help = ["addlimit", "remlimit"].map((a) => a + " *[@user | reply | number] & value*");
handler.tags = ["owner"];
handler.command = /^(add|rem)limit$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_addremlimit_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
