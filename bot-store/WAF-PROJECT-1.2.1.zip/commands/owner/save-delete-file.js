/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - save-delete-file.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_save_delete_file_exports = {};
__export(owner_save_delete_file_exports, {
  default: () => owner_save_delete_file_default
});
module.exports = __toCommonJS(owner_save_delete_file_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
const ROOT_PLUGINS = import_path.default.resolve("./plugins");
function ensureDir(dir) {
  if (!import_fs.default.existsSync(dir)) import_fs.default.mkdirSync(dir, { recursive: true });
}
function normName(s) {
  return String(s || "").replace(/\.js$/i, "").trim();
}
function safeFolderName(s) {
  return String(s || "").replace(/[\/\\:*?"<>|]/g, "").replace(/\s+/g, " ").trim();
}
function splitCategory(nameRaw) {
  const name = normName(nameRaw);
  const m = name.match(/^(.+?)[\s]*-[\s]*(.+)$/);
  if (!m) return { category: null, rest: name };
  const category = safeFolderName(m[1]);
  const rest = m[2].trim();
  return { category: category || null, rest };
}
function prettyRel(p) {
  return import_path.default.relative(ROOT_PLUGINS, p).replace(/\\/g, "/");
}
function listAllJSFiles(dir) {
  if (!import_fs.default.existsSync(dir)) return [];
  const out = [];
  const entries = import_fs.default.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = import_path.default.join(dir, e.name);
    if (e.isDirectory()) out.push(...listAllJSFiles(full));
    else if (e.isFile() && e.name.endsWith(".js")) out.push(full);
  }
  return out;
}
function buildSavePathFromFileName(fileName) {
  const base = import_path.default.basename(fileName);
  const nameNoExt = base.replace(/\.js$/i, "");
  const { category } = splitCategory(nameNoExt);
  if (category) {
    const folder = import_path.default.join(ROOT_PLUGINS, category);
    ensureDir(folder);
    return import_path.default.join(folder, base);
  }
  ensureDir(ROOT_PLUGINS);
  return import_path.default.join(ROOT_PLUGINS, base);
}
function buildSavePathFromText(nameText) {
  const clean = normName(nameText);
  const { category } = splitCategory(clean);
  const base = clean + ".js";
  if (category) {
    const folder = import_path.default.join(ROOT_PLUGINS, category);
    ensureDir(folder);
    return import_path.default.join(folder, base);
  }
  ensureDir(ROOT_PLUGINS);
  return import_path.default.join(ROOT_PLUGINS, base);
}
function normalizeForCompare(s) {
  return normName(s).toLowerCase().replace(/\s+/g, " ").replace(/\s*-\s*/g, "-").trim();
}
function filenameNoExt(p) {
  return import_path.default.basename(p).replace(/\.js$/i, "");
}
function findDeleteCandidates(inputText) {
  const queryRaw = normName(inputText);
  const queryNorm = normalizeForCompare(queryRaw);
  const { category } = splitCategory(queryRaw);
  const all = listAllJSFiles(ROOT_PLUGINS);
  if (category) {
    const inFolder = all.filter((f) => {
      const rel = prettyRel(f);
      const folder = rel.split("/")[0];
      if (folder !== category) return false;
      return normalizeForCompare(filenameNoExt(f)) === queryNorm;
    });
    if (inFolder.length) return inFolder;
    const anywhere = all.filter((f) => normalizeForCompare(filenameNoExt(f)) === queryNorm);
    return anywhere;
  }
  const exact = all.filter((f) => normalizeForCompare(filenameNoExt(f)) === queryNorm);
  return exact;
}
async function sendEdit(jagoanproject, chat, msgKey, text) {
  return jagoanproject.relayMessage(chat, {
    protocolMessage: {
      key: msgKey,
      type: 14,
      editedMessage: { conversation: text }
    }
  }, {});
}
let handler = async (m, { text, usedPrefix, command, jagoanproject }) => {
  if (!m.quoted && !text && command === "sf") {
    throw `*Fitur Simpan Plugin (sf)*

\u{1F4CC} Cara pakai:
- Balas file *.js* lalu ketik: *${usedPrefix}sf*
- Balas teks lalu ketik: *${usedPrefix}sf <nama_plugin>*

\u{1F4C2} Folder otomatis:
- Nama depan sebelum '-' jadi folder
  Contoh:
  - group - kick  => plugins/group/group - kick.js
  - group-kick    => plugins/group/group-kick.js
`;
  }
  if (!text && command === "df") {
    throw `*Fitur Hapus Plugin (df)*

\u{1F4CC} Cara pakai:
- *${usedPrefix}df <nama_plugin>*

Contoh:
- *${usedPrefix}df group - kick*
- *${usedPrefix}df group-kick*
- *${usedPrefix}df ai - hijab*
`;
  }
  if (command === "sf") {
    if (m.quoted && m.quoted.mtype === "documentMessage" && m.quoted.fileName?.endsWith(".js")) {
      const fileName = m.quoted.fileName;
      const savePath = buildSavePathFromFileName(fileName);
      const loadingMsg = await jagoanproject.sendMessage(m.chat, { text: `\u23F3 Menyimpan plugin...` });
      const msgKey = loadingMsg?.key;
      try {
        const buffer = await m.quoted.download();
        ensureDir(import_path.default.dirname(savePath));
        import_fs.default.writeFileSync(savePath, buffer);
        await sendEdit(jagoanproject, m.chat, msgKey, `\u2705 Berhasil disimpan!
\u{1F4C2} Lokasi: *${prettyRel(savePath)}*`);
      } catch (e) {
        await sendEdit(jagoanproject, m.chat, msgKey, `\u274C Gagal menyimpan!
Error: ${e?.message || e}`);
      }
      return;
    }
    if (m.quoted?.text) {
      if (!text) throw `\u2757 Masukkan nama plugin.
Contoh: *${usedPrefix}sf group-kick*`;
      const savePath = buildSavePathFromText(text);
      const loadingMsg = await jagoanproject.sendMessage(m.chat, { text: `\u23F3 Menyimpan plugin dari teks...` });
      const msgKey = loadingMsg?.key;
      try {
        ensureDir(import_path.default.dirname(savePath));
        import_fs.default.writeFileSync(savePath, `// \u2728 Plugin ${normName(text)} \u2728

` + m.quoted.text);
        await sendEdit(jagoanproject, m.chat, msgKey, `\u2705 Berhasil disimpan!
\u{1F4C2} Lokasi: *${prettyRel(savePath)}*`);
      } catch (e) {
        await sendEdit(jagoanproject, m.chat, msgKey, `\u274C Gagal menyimpan!
Error: ${e?.message || e}`);
      }
      return;
    }
    throw `\u2757 Balas file *.js* atau balas teks.
Contoh:
- Balas file => *${usedPrefix}sf*
- Balas teks => *${usedPrefix}sf group-kick*`;
  }
  if (command === "df") {
    const query = normName(text);
    const candidates = findDeleteCandidates(query);
    if (!candidates.length) {
      const all = listAllJSFiles(ROOT_PLUGINS).map((f) => import_path.default.basename(f)).sort((a, b) => a.localeCompare(b));
      const unique = [...new Set(all)];
      const list = unique.map((v) => `- ${v}`).join("\n");
      throw `\u26A0\uFE0F Plugin *${query}.js* tidak ditemukan!
> Gunakan .df <nama plugin>
> Contoh : .df group - kick

\u{1F4CC} Daftar semua plugin (nama saja):
${list}`;
    }
    if (candidates.length > 1) {
      const list = candidates.map((v) => `- ${prettyRel(v)}`).sort((a, b) => a.localeCompare(b)).join("\n");
      throw `\u26A0\uFE0F Ditemukan lebih dari 1 plugin yang cocok dengan *${query}*:

${list}

\u2705 Ketik lebih spesifik, contoh:
- *${usedPrefix}df ai - hijab*
- *${usedPrefix}df group - kick*`;
    }
    const target = candidates[0];
    const loadingMsg = await jagoanproject.sendMessage(m.chat, { text: `\u23F3 Menghapus plugin...` });
    const msgKey = loadingMsg?.key;
    try {
      import_fs.default.unlinkSync(target);
      await sendEdit(jagoanproject, m.chat, msgKey, `\u{1F5D1}\uFE0F Berhasil dihapus!
\u{1F4C2} Lokasi: *${prettyRel(target)}*`);
    } catch (e) {
      await sendEdit(jagoanproject, m.chat, msgKey, `\u274C Gagal menghapus!
Error: ${e?.message || e}`);
    }
    return;
  }
};
handler.help = ["sf", "df"].map((v) => v + " *[nama_plugin]*");
handler.tags = ["owner"];
handler.command = /^(sf|df)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_save_delete_file_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
