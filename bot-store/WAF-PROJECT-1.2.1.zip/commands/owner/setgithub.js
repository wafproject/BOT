/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - setgithub.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_setgithub_exports = {};
__export(owner_setgithub_exports, {
  default: () => owner_setgithub_default
});
module.exports = __toCommonJS(owner_setgithub_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  const em = {
    info: "\u{1F4DD}",
    wait: "\u23F3",
    ok: "\u2705",
    warn: "\u26A0\uFE0F",
    err: "\u274C"
  };
  if (!text || !text.trim()) {
    return jagoanproject.reply(
      m.chat,
      `${em.warn} *Token GitHub-nya mana?*

${em.info} *Cara pakai:*
\u2022 ${usedPrefix + command} ghp_xxxxxxx

${em.info} *Info:* Gunakan Token Classic atau Fine-grained PAT.`,
      m
    );
  }
  let newToken = text.trim();
  newToken = newToken.replace(/\r?\n/g, "").replace(/"/g, '\\"').trim();
  await jagoanproject.reply(m.chat, `${em.wait} *Otw update Token GitHub...*`, m);
  let settingsPath = import_path.default.join(process.cwd(), "settings.js");
  if (!import_fs.default.existsSync(settingsPath)) {
    return jagoanproject.reply(
      m.chat,
      `${em.err} *Gagal!* File *settings.js* tidak ketemu.`,
      m
    );
  }
  try {
    const before = import_fs.default.readFileSync(settingsPath, "utf8");
    const regex = /global\.tokengithub\s*=\s*(['"`])([\s\S]*?)\1\s*;?/i;
    if (!regex.test(before)) {
      return jagoanproject.reply(
        m.chat,
        `${em.err} *Gagal!* Pola *global.tokengithub* tidak ditemukan di settings.js.
${em.info} Pastikan di settings.js ada baris:
global.tokengithub = "isi_token"`,
        m
      );
    }
    const after = before.replace(regex, (match, quote) => {
      return `global.tokengithub = ${quote}${newToken}${quote};`;
    });
    import_fs.default.writeFileSync(settingsPath, after, "utf8");
    global.tokengithub = newToken;
    const censored = newToken.substring(0, 8) + "********";
    return jagoanproject.reply(
      m.chat,
      `${em.ok} *Berhasil!* Token GitHub telah diperbarui:

*${censored}*

${em.info} Sekarang kamu bisa menggunakan fitur yang memerlukan akses GitHub.`,
      m
    );
  } catch (e) {
    console.error("\u274C Error setgithub:", e);
    return jagoanproject.reply(
      m.chat,
      `${em.err} *Gagal mengganti token GitHub.*`,
      m
    );
  }
};
handler.help = ["setgithub"].map((v) => v + " *[token baru]*");
handler.tags = ["owner"];
handler.command = /^(setgithub)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = false;
var owner_setgithub_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
