/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - banuser.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_banuser_exports = {};
__export(owner_banuser_exports, {
  default: () => owner_banuser_default
});
module.exports = __toCommonJS(owner_banuser_exports);
var import_jid = require("../../lib/jagoan/function/jid.js");
var import_ms = __toESM(require("ms"));
function normalizePhone(inputRaw) {
  if (!inputRaw) return "";
  if (/[a-zA-Z]/.test(inputRaw)) return null;
  const digitsOnly = inputRaw.replace(/[^0-9]/g, "");
  return digitsOnly;
}
let handler = async (m, { jagoanproject, isOwner, args, text }) => {
  if (!isOwner) {
    global.jpDfail("owner", m, jagoanproject);
    throw false;
  }
  let who;
  let duration;
  let input = (text || "").trim();
  if (m.isGroup) {
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      who = m.mentionedJid[0];
      duration = args[1];
    } else if (m.quoted) {
      who = m.quoted.sender;
      duration = args[0];
    } else if (input) {
      let parts = input.split(" ");
      let rawNumber = parts[0];
      let number = normalizePhone(rawNumber);
      if (number === null) {
        throw "\u274C Nomor ditolak!\n\n\u27A1\uFE0F Nomor harus *full angka* (tidak boleh campur huruf).\n\n\u{1F4DD} Contoh:\n\u2014 .banuser +6285257129838 1h\n\u2014 .banuser 1-202-555-0101 30m";
      }
      if (!number || number.length < 5) {
        throw "\u274C Nomor tidak valid!\n\n\u27A1\uFE0F Masukkan nomor HP yang benar (minimal 5 digit).\n\n\u{1F4DD} Contoh:\n\u2014 .banuser +6285257129838 1h\n\u2014 .banuser 12025550101 30m";
      }
      who = number + "@s.whatsapp.net";
      duration = parts[1];
    } else {
      throw "\u274C Format salah!!\n\n\u{1F4DD} Cara penggunaan :\n\n\u2014 .banuser <@user> <durasi>\n\u2014 .banuser <reply chat> <durasi>\n\u2014 .banuser <nomor> <durasi>\n\n\u{1F4DD} Contoh penggunaan :\n\n\u2014 .banuser @arman 10d\n\u2014 .banuser reply 30h\n\u2014 .banuser +6285257129838 40s\n\u2014 .banuser 1-202-555-0101 30m\n\n\u23F0 Format waktu :\n\n\u2014 s = detik\n\u2014 m = menit\n\u2014 h = jam\n\u2014 d = hari\n\n> tanpa format waktu = permanent.";
    }
  } else {
    if (input) {
      let parts = input.split(" ");
      let rawNumber = parts[0];
      let number = normalizePhone(rawNumber);
      if (number === null) {
        throw "\u274C Nomor ditolak!\n\n\u27A1\uFE0F Nomor harus *full angka* (tidak boleh campur huruf).\n\n\u{1F4DD} Contoh:\n\u2014 .banuser +6285257129838 30m\n\u2014 .banuser 1-202-555-0101 30m";
      }
      if (!number || number.length < 5) {
        throw "\u274C Nomor tidak valid!\n\n\u27A1\uFE0F Masukkan nomor HP yang benar (minimal 5 digit).\n\n\u{1F4DD} Contoh:\n\u2014 .banuser +6285257129838 30m\n\u2014 .banuser 12025550101 30m";
      }
      who = number + "@s.whatsapp.net";
      duration = parts[1];
    } else {
      who = m.chat;
    }
  }
  if (who) {
    who = await (0, import_jid.resolveJid)(jagoanproject, who, {
      groupJid: m.isGroup ? m.chat : null,
      groupMetadata: m.isGroup ? await jagoanproject.groupMetadata(m.chat).catch(() => null) : null
    });
  }
  try {
    if (!who) throw "\u274C User tidak valid!";
    if (!global.db?.data?.users) throw "\u203C\uFE0F Database pengguna tidak tersedia";
    let users = global.db.data.users;
    if (!users[who]) users[who] = {};
    users[who].banned = true;
    let bannedUntil = null;
    if (duration && duration.toLowerCase() !== "permanent") {
      let msDuration = (0, import_ms.default)(duration);
      if (!msDuration)
        throw "\u274C Format waktu salah!!\n\n\u{1F4DD} Gunakan contoh :\n\n\u2014 10s\n\u2014 30m\n\u2014 1h\n\u2014 2d\n\n> tanpa format waktu = permanent";
      bannedUntil = Date.now() + msDuration;
      users[who].bannedUntil = bannedUntil;
    } else {
      users[who].bannedUntil = null;
    }
    let durasiText = bannedUntil ? ` selama ${(0, import_ms.default)(bannedUntil - Date.now(), { long: true })}` : " secara permanent";
    await jagoanproject.reply(
      m.chat,
      `\u2705 Berhasil banned user!!

\u{1FA80} nomor : ${who.split("@")[0]}
\u26D4 status : banned
\u23F0 durasi : ${durasiText}`,
      m
    );
  } catch (e) {
    console.log("Error occurred:", e);
    await jagoanproject.reply(m.chat, `Error: ${e.message || e}`, m);
  }
};
handler.help = ["banuser <nomor|@tag|reply> [durasi]"];
handler.tags = ["owner"];
handler.command = /^banuser$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_banuser_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
