/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - blacklist.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_blacklist_exports = {};
__export(owner_blacklist_exports, {
  default: () => owner_blacklist_default
});
module.exports = __toCommonJS(owner_blacklist_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const dirDB = import_path.default.join(__dirname, "../../database");
const filePath = import_path.default.join(dirDB, "blacklist.json");
const configPath = import_path.default.join(dirDB, "blacklist-config.json");
if (!import_fs.default.existsSync(dirDB)) import_fs.default.mkdirSync(dirDB);
if (!import_fs.default.existsSync(filePath)) import_fs.default.writeFileSync(filePath, "[]");
if (!import_fs.default.existsSync(configPath)) import_fs.default.writeFileSync(configPath, JSON.stringify({ denganKick: false }, null, 2));
function loadConfig() {
  return JSON.parse(import_fs.default.readFileSync(configPath));
}
function saveConfig(data2) {
  import_fs.default.writeFileSync(configPath, JSON.stringify(data2, null, 2));
}
function loadBlacklist() {
  return JSON.parse(import_fs.default.readFileSync(filePath));
}
function saveBlacklist(data2) {
  import_fs.default.writeFileSync(filePath, JSON.stringify(data2, null, 2));
}
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  const sender = m.sender.replace(/\D/g, "");
  const ownerList = global.jpOwner.map((o) => Array.isArray(o) ? o[0] : o).map((x) => x + "");
  if (!ownerList.includes(sender)) {
    return m.reply("\u274C *Akses ditolak!*\nFitur ini hanya untuk *owner* saja.");
  }
  const act = (args[0] || "").toLowerCase();
  const input = args[1];
  if (act === "list") {
    const data2 = loadBlacklist();
    if (!data2.length) return m.reply("\u{1F4C3} *Blacklist kosong.*");
    let list = data2.map((n, i) => `*${i + 1}.* wa.me/${n}`).join("\n");
    return m.reply(`\u{1F4DB} *DAFTAR BLACKLIST*

${list}`);
  }
  if (act === "kick") {
    if (!["true", "false"].includes(input?.toLowerCase())) {
      return m.reply(`\u26A0\uFE0F *Format salah!*

*Contoh:*
${usedPrefix + command} kick true
${usedPrefix + command} kick false`);
    }
    const config = loadConfig();
    config.denganKick = input.toLowerCase() === "true";
    saveConfig(config);
    return m.reply(`\u2705 Fitur Blacklist versi kick user telah diatur ke *${config.denganKick ? "ON" : "OFF"}*!`);
  }
  let mentionedJid = [];
  try {
    mentionedJid = m.mentionedJid || [];
  } catch (e) {
    mentionedJid = [];
  }
  const isReply = m.quoted && m.quoted.sender;
  const isMention = mentionedJid.length > 0;
  let targetNumber = null;
  if (isReply) targetNumber = m.quoted.sender;
  else if (isMention) targetNumber = mentionedJid[0];
  else if (input) targetNumber = input;
  if (!targetNumber && typeof eval === "function") {
    try {
      const evalResult = eval(`(() => {
        const jidList = m.mentionedJid || [];
        return jidList.length ? jidList[0] : null;
      })()`);
      if (evalResult) targetNumber = evalResult;
    } catch (e) {
      console.error("\u274C Eval gagal ambil JID:", e);
    }
  }
  const nomor = targetNumber?.replace(/[^0-9]/g, "");
  if (!["add", "und", "remove"].includes(act) || !nomor) {
    return m.reply(`\u26A0\uFE0F *Format salah!*

*Contoh:*
${usedPrefix + command} add 628xxxx
${usedPrefix + command} und 628xxxx
${usedPrefix + command} kick true
${usedPrefix + command} kick false
${usedPrefix + command} list
(bisa juga dengan tag atau reply untuk add/remove)`);
  }
  let data = loadBlacklist();
  if (act === "add") {
    if (data.includes(nomor)) return m.reply(`\u26A0\uFE0F Nomor *${nomor}* sudah dalam blacklist.`);
    data.push(nomor);
    saveBlacklist(data);
    m.reply(`\u2705 Nomor *${nomor}* berhasil ditambahkan ke *blacklist*!`);
  } else {
    if (!data.includes(nomor)) return m.reply(`\u26A0\uFE0F Nomor *${nomor}* tidak ada dalam blacklist.`);
    data = data.filter((n) => n !== nomor);
    saveBlacklist(data);
    m.reply(`\u2705 Nomor *${nomor}* berhasil dihapus dari *blacklist*!`);
  }
};
handler.command = /^blacklist|bl$/i;
handler.help = ["blacklist"].map((v) => `${v} [add|und|remove|list] <nomor/@user/reply>`).concat(["blacklist kick [true|false]"]);
handler.tags = ["owner"];
handler.owner = true;
handler.before = async function(m2, { jagoanproject: jagoanproject2 }) {
  if (!m2.isGroup || m2.fromMe || !m2.message || !m2.sender) return;
  const bl = loadBlacklist();
  const config = loadConfig();
  const nomor2 = m2.sender.replace(/\D/g, "");
  if (bl.includes(nomor2)) {
    try {
      await jagoanproject2.sendMessage(m2.chat, {
        delete: {
          remoteJid: m2.chat,
          fromMe: false,
          id: m2.key.id,
          participant: m2.sender
        }
      });
      console.log(`\u{1F6D1} Pesan dari ${nomor2} dihapus (blacklist).`);
      if (config.denganKick) {
        const groupMetadata = await jagoanproject2.groupMetadata(m2.chat);
        const botId = jagoanproject2.user.jid;
        const isAdmin = groupMetadata.participants.find((p) => p.id === botId)?.admin;
        if (isAdmin) {
          try {
            await jagoanproject2.groupParticipantsUpdate(m2.chat, [m2.sender], "remove");
            console.log(`\u{1F6AA} User ${nomor2} telah dikick dari grup (blacklist).`);
          } catch (e) {
            console.error("\u274C Gagal kick user:", e);
          }
        } else {
          console.log("\u26A0\uFE0F Bot bukan admin, tidak bisa kick user.");
        }
      }
    } catch (e) {
      console.error("\u274C Gagal hapus pesan:", e);
    }
  }
};
handler.register = true;
handler.limit = true;
var owner_blacklist_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
