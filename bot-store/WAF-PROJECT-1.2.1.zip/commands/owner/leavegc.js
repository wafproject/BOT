/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - leavegc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_leavegc_exports = {};
__export(owner_leavegc_exports, {
  default: () => owner_leavegc_default
});
module.exports = __toCommonJS(owner_leavegc_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
const { proto, generateWAMessageFromContent } = __zapo_1;
const LEAVE_MENU_CACHE = /* @__PURE__ */ new Map();
function buildLeaveMenuRows(groups = []) {
  return groups.map((g, idx) => ({
    title: g.subject || "Tanpa Nama",
    description: `\u{1F465} ${(g.participants || []).length} anggota`,
    id: `leave_select_${idx + 1}`
  }));
}
let handler = async (m, { jagoanproject }) => {
  let allGroups = await jagoanproject.groupFetchAllParticipating();
  let groups = Object.values(allGroups);
  LEAVE_MENU_CACHE.set(m.chat, { ts: Date.now(), groups });
  if (!groups.length) return m.reply("\u274C Bot tidak ada di grup manapun.");
  let rows = buildLeaveMenuRows(groups);
  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Silakan pilih grup yang ingin bot tinggalkan.

Total grup: *${groups.length}*`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "\u26A0\uFE0F Owner only command"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: "\u{1F6AA} Leave Group Menu"
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  title: "Pilih Grup",
                  sections: [
                    {
                      title: "Daftar Grup",
                      rows
                    }
                  ]
                })
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: m });
  await jagoanproject.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};
handler.help = ["leavegc"];
handler.tags = ["owner"];
handler.command = /^leave(g(c|ro?up))?$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_leavegc_default = handler;
handler.all = async (m, { jagoanproject }) => {
  if (!m.message?.interactiveResponseMessage) return;
  let id = m.message.interactiveResponseMessage.nativeFlowResponseMessage?.paramsJson;
  if (!id) return;
  try {
    let data = JSON.parse(id);
    let selected = data.id;
    if (selected && selected.startsWith("leave_select_")) {
      let index = parseInt(selected.replace("leave_select_", "")) - 1;
      const cachedMenu = LEAVE_MENU_CACHE.get(m.chat);
      let groups = Array.isArray(cachedMenu?.groups) ? cachedMenu.groups : [];
      if (!groups.length) {
        let allGroups = await jagoanproject.groupFetchAllParticipating();
        groups = Object.values(allGroups);
        LEAVE_MENU_CACHE.set(m.chat, { ts: Date.now(), groups });
      }
      if (index < 0 || index >= groups.length) return m.reply("\u26A0\uFE0F Grup tidak ditemukan.");
      let g = groups[index];
      let meta = g;
      let admins = meta.participants.filter((p) => p.admin).map((p, i) => `${i + 1}. @${p.id.split("@")[0]} [${p.admin}]`).join("\n") || "Tidak ada";
      let desc = meta.desc || "Not found";
      let descId = meta.descId || "Not found";
      let text = `*[${index + 1}]*
*Name Grup :* ${meta.subject}
*Owner :* @${meta.owner?.split("@")[0] || "Unknown"}
*ID :* ${meta.id}
*Restrict :* ${meta.restrict || false}
*Announce :* ${meta.announce || false}
*Ephemeral :* ${meta.ephemeralDuration ? meta.ephemeralDuration : "*Not set*"}
*Desc ID :* ${descId}
*Description :* ${desc}
*Admins :*
${admins}

*Participants :* ${meta.participants.length}
*isBotAdmin :* [ ${meta.participants.find((p) => p.id == jagoanproject.user.id && p.admin) ? true : false} ]
*Created :* ${meta.creation ? new Date(meta.creation * 1e3).toLocaleString() : ""}
*Size :* ${meta.size || meta.participants.length}`;
      await jagoanproject.sendMessage(m.chat, { text, mentions: (meta.participants || []).map((p) => p.id) });
      setTimeout(async () => {
        await jagoanproject.groupLeave(g.id);
      }, 3e3);
    }
  } catch (e) {
    console.error("\u274C Error parsing button:", e);
  }
};

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
