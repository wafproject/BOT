/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - restart.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_restart_exports = {};
__export(owner_restart_exports, {
  default: () => owner_restart_default
});
module.exports = __toCommonJS(owner_restart_exports);
var __child_process_1 = __toESM(require("child_process"));
let { spawn } = __child_process_1;
let handler = async (m, { jagoanproject }) => {
  if (!process.send) throw "\u274C *Jangan gunakan:* node main.js\n\u2705 *Gunakan:* node index.js";
  if (global.jagoanproject.user.jid == jagoanproject.user.jid) {
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F504}", key: m.key } });
    await new Promise((resolve) => setTimeout(resolve, 1e3));
    await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
    await new Promise((resolve) => setTimeout(resolve, 3e3));
    if (!global.db.data) await global.db.read();
    await global.db.write();
    setTimeout(() => {
      m.reply("\u2705 *Bot berhasil direstart!*\nBot sudah kembali online. \u{1F680}");
    }, 6e4);
    process.send("reset");
  } else throw "\u26A0\uFE0F _Akses Ditolak!_";
};
handler.help = ["restart"];
handler.tags = ["owner"];
handler.command = /^restart$/i;
handler.rowner = true;
handler.mods = true;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.register = true;
handler.limit = true;
var owner_restart_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
