/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - mute.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_mute_exports = {};
__export(owner_mute_exports, {
  default: () => owner_mute_default
});
module.exports = __toCommonJS(owner_mute_exports);
let handler = async (m, { jagoanproject, isOwner, text, isAdmin, command }) => {
  // WAF: ".mute on" / ".mute off" -> command "mute" + teks on/off
  if (/^mute$/i.test(command)) { command = "mute " + String(text || "").trim().toLowerCase(); text = "" }
  let who;
  if (m.isGroup) {
    if (!(isAdmin || isOwner)) {
      global.jpDfail("admin", m, jagoanproject);
      throw false;
    }
    if (isOwner) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : m.chat;
    else who = m.chat;
  } else {
    if (!isOwner) {
      global.jpDfail("owner", m, jagoanproject);
      throw false;
    }
    who = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : m.chat;
  }
  try {
    if (command === "ban" || command === "banchat" || command === "mute on") {
      if (who.endsWith("g.us")) global.db.data.chats[who].isBanned = true;
      else global.db.data.users[who].banned = true;
      m.reply(`Berhasil Mute! ${await jagoanproject.user.name} tidak aktif di chat ${await jagoanproject.getName(who) == void 0 ? "ini" : await jagoanproject.getName(who)}.`);
    } else if (command === "unbanchat" || command === "unmute" || command === "mute off") {
      global.db.data.chats[m.chat].isBanned = false;
      m.reply("*[ \u2713 ] Successfully unmuted chat!*");
    }
  } catch (e) {
    throw `Nomor tidak ada di database!`;
  }
};
handler.help = ["mute on", "mute off", "unmute"].map((a) => a + " *[mute/unmute bot]*");
handler.tags = ["owner", "group", "premium"];
handler.command = /^(ban|banchat|unmute|mute)$/i; // WAF: unbanchat ditangani unbanchat.js
handler.rowner = true;
handler.owner = true;
handler.premium = true;
handler.register = true;
handler.limit = true;
var owner_mute_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
