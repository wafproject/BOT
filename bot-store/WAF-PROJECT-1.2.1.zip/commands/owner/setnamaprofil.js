/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - setnamaprofil.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_setnamaprofil_exports = {};
__export(owner_setnamaprofil_exports, {
  default: () => owner_setnamaprofil_default
});
module.exports = __toCommonJS(owner_setnamaprofil_exports);
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  const em = {
    info: "\u{1F4DD}",
    wait: "\u23F3",
    ok: "\u2705",
    warn: "\u26A0\uFE0F",
    err: "\u274C"
  };
  if (!text || !text.trim()) {
    return jagoanproject.reply(
      m.chat,
      `${em.warn} *Nama profil WhatsApp-nya mana?*

${em.info} *Cara pakai:*
\u2022 ${usedPrefix + command} Sang Jagoan

${em.info} *Contoh:*
\u2022 ${usedPrefix + command} Jagoan Project Official`,
      m
    );
  }
  let newName = text.trim().replace(/\r?\n/g, " ").replace(/\s{2,}/g, " ").trim();
  if (!newName) {
    return jagoanproject.reply(m.chat, `${em.warn} Nama profil tidak boleh kosong.`, m);
  }
  if (newName.length > 80) {
    return jagoanproject.reply(
      m.chat,
      `${em.warn} Nama profil terlalu panjang.
${em.info} Maksimal *80 karakter* ya.`,
      m
    );
  }
  await jagoanproject.reply(m.chat, `${em.wait} *Sedang mengirim perubahan nama profil WhatsApp...*`, m);
  const metode = [];
  const catatan = [];
  let berhasilKirim = false;
  try {
    if (typeof jagoanproject.resyncAppState === "function") {
      try {
        await jagoanproject.resyncAppState(["critical_block"]);
        catatan.push("resyncAppState sebelum update: OK");
      } catch (e) {
        catatan.push(`resyncAppState sebelum update gagal: ${e?.message || e}`);
      }
    }
    if (typeof jagoanproject.chatModify === "function") {
      try {
        await jagoanproject.chatModify({ pushNameSetting: newName }, "");
        metode.push("chatModify(pushNameSetting)");
        berhasilKirim = true;
      } catch (e) {
        catatan.push(`chatModify gagal: ${e?.message || e}`);
      }
    }
    if (!berhasilKirim && typeof jagoanproject.updateProfileName === "function") {
      try {
        await jagoanproject.updateProfileName(newName);
        metode.push("updateProfileName()");
        berhasilKirim = true;
      } catch (e) {
        catatan.push(`updateProfileName gagal: ${e?.message || e}`);
      }
    }
    if (!berhasilKirim) {
      throw new Error("Socket tidak berhasil mengirim patch pushName. Method yang didukung tidak tersedia atau semuanya gagal.");
    }
    try {
      if (jagoanproject.user && typeof jagoanproject.user === "object") {
        jagoanproject.user.name = newName;
        jagoanproject.user.notify = newName;
      }
      if (jagoanproject.authState?.creds?.me) {
        jagoanproject.authState.creds.me.name = newName;
      }
    } catch {
    }
    await delay(1500);
    if (typeof jagoanproject.resyncAppState === "function") {
      try {
        await jagoanproject.resyncAppState(["critical_block"]);
        catatan.push("resyncAppState sesudah update: OK");
      } catch (e) {
        catatan.push(`resyncAppState sesudah update gagal: ${e?.message || e}`);
      }
    }
    let msg = `${em.ok} *Permintaan ganti nama profil sudah dikirim.*

`;
    msg += `*Nama target:* ${newName}
`;
    return jagoanproject.reply(m.chat, msg, m);
  } catch (e) {
    console.error("\u274C Gagal update profile name:", e);
    let msg = `${em.err} *Gagal mengganti nama profil WhatsApp bot.*
`;
    msg += `${em.info} Detail: ${e?.message || e}

`;
    msg += `Kemungkinan terbesar: patch *pushName* dari library/fork Anda tidak jalan normal. `;
    msg += `Kalau akun bot Anda *WhatsApp Business*, kendala ini memang lebih sering muncul.`;
    if (catatan.length) {
      msg += `

${em.info} *Log singkat:*
\u2022 ${catatan.join("\n\u2022 ")}`;
    }
    return jagoanproject.reply(m.chat, msg, m);
  }
};
handler.help = ["setnamaprofil"].map((v) => v + " *[nama baru]*");
handler.tags = ["owner"];
handler.command = /^(setnamaprofil|setnamaprofile|setnamewa|setprofilename)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = false;
var owner_setnamaprofil_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
