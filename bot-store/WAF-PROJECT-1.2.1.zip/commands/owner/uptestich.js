/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - uptestich.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_uptestich_exports = {};
__export(owner_uptestich_exports, {
  default: () => owner_uptestich_default
});
module.exports = __toCommonJS(owner_uptestich_exports);
var import_moment_timezone = __toESM(require("moment-timezone"));
function randomID(len = 12) {
  let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let id = "";
  for (let i = 0; i < len; i++) {
    id += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return id.toUpperCase();
}
function formatRupiah(angka) {
  let numberString = angka.replace(/[^,\d]/g, "");
  let sisa = numberString.length % 3;
  let rupiah = numberString.substr(0, sisa);
  let ribuan = numberString.substr(sisa).match(/\d{3}/g);
  if (ribuan) {
    let separator = sisa ? "." : "";
    rupiah += separator + ribuan.join(".");
  }
  return "Rp. " + rupiah;
}
let handler = async (m, { jagoanproject, text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply("\u274C Fitur ini hanya untuk Owner!");
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime || !mime.startsWith("image"))
    return m.reply(`\u{1F4CC} Reply gambar produk dengan caption:
${usedPrefix + command} <nama produk>|<harga>

Contoh:
${usedPrefix + command} Kaos Polos|50000`);
  if (!text.includes("|")) return m.reply("\u26A0\uFE0F Format salah!\nContoh: .uptestich Kaos Polos|50000");
  let [produk, harga] = text.split("|");
  if (!produk || !harga) return m.reply("\u26A0\uFE0F Nama produk & harga wajib diisi!\nContoh: .uptestich Kaos Polos|50000");
  let hargaFormatted = formatRupiah(harga.trim());
  let idch = global.chtesti;
  if (!idch) return m.reply("\u274C Channel saluran belum diatur di settings.js");
  let tanggalOnly = (0, import_moment_timezone.default)().tz("Asia/Makassar").format("DD-MM-YYYY");
  let jamOnly = (0, import_moment_timezone.default)().tz("Asia/Makassar").format("HH:mm");
  let trxID = randomID(7);
  let originalSender = m.quoted ? m.quoted.sender : m.sender;
  let customerName = await jagoanproject.getName(originalSender) || originalSender.split("@")[0];
  let caption = `\u{1F6CD}\uFE0F *DETAIL ORDERAN*


\u{1F464} *Customer* : ${customerName}
\u{1F4E6} *Produk*      : ${produk.trim()}
\u{1F4B0} *Harga*        : ${hargaFormatted}
\u{1F4C5} *Tanggal*    : ${tanggalOnly}
\u{1F552} *Jam*           : ${jamOnly} WITA
\u{1F516} *ID*                : JAGPRO-${trxID}

\u{1F64F} Terimakasih telah order, ditunggu next ordernya, Semoga puas dengan pelayanan kami \u2728\u{1F495}
> ${namestore}`;
  await jagoanproject.sendMessage(idch, {
    image: await q.download(),
    caption
  });
  await jagoanproject.sendMessage(m.chat, {
    text: "\u2705 Order berhasil dikirim ke Saluran Testimoni!",
    contextInfo: {
      mentionedJid: [originalSender],
      isForwarded: true,
      forwardingScore: 256,
      forwardedNewsletterMessageInfo: {
        newsletterJid: idch,
        newsletterName: "\u{1F4E2} PESAN TERKIRIM KE SALURAN",
        serverMessageId: -1
      },
      extendedPreview: {
        title: `\u{1F464} Pengirim: ${m.pushName || m.sender.split("@")[0]}`,
        body: `\u{1F4C6} ${tanggalOnly}`,
        thumbnailUrl: await jagoanproject.profilePictureUrl(m.sender, "image").catch((_) => null),
        sourceUrl: "https://whatsapp.com/channel/" + idch.split("@")[0],
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};
handler.command = /^uptestich|uptesti$/i;
handler.owner = true;
var owner_uptestich_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
