/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - simulate.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_simulate_exports = {};
__export(owner_simulate_exports, {
  default: () => owner_simulate_default
});
module.exports = __toCommonJS(owner_simulate_exports);
var import_handler_shim = require("../../lib/jagoan/handler-shim.js");
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  if (!global.jpROwner.includes(m.sender.split`@`[0])) {
    throw "\u{1F621} Hanya owner yang bisa menggunakan fitur simulate!";
  }
  if (!m.isGroup) {
    throw "\u{1F6AB} Fitur ini hanya bisa digunakan di dalam grup!";
  }
  if (!args[0]) {
    throw `\u{1F4DD} *Cara penggunaan:*
${usedPrefix}${command} <welcome|left> [nomor]

\u{1F4A1} *Contoh:*
${usedPrefix}${command} welcome 6281234567890
${usedPrefix}${command} left 6281234567890`;
  }
  const actionInput = args[0].toLowerCase();
  const action = ["left", "leave", "bye", "remove"].includes(actionInput) ? "leave" : actionInput;
  const target = args[1] ? args[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : m.sender;
  let chatData = global.db.data.chats[m.chat] || {};
  if (action === "welcome" && !chatData.welcome) {
    throw "\u26A0\uFE0F Fitur welcome belum diaktifkan di grup ini!";
  }
  if (action === "leave" && !chatData.bye) {
    throw "\u26A0\uFE0F Fitur bye/leave belum diaktifkan di grup ini!";
  }
  let groupMetadata;
  try {
    groupMetadata = await jagoanproject.groupMetadata(m.chat);
  } catch (e) {
    console.error("[ERROR] Gagal mengambil metadata grup:", e);
    throw "\u274C Gagal mengambil metadata grup. Pastikan bot memiliki akses ke grup ini.";
  }
  try {
    if (action === "welcome") {
      await (0, import_handler_shim.sendWelcomeMessage)(jagoanproject, m.chat, target, groupMetadata);
    } else if (action === "leave") {
      await (0, import_handler_shim.sendLeaveMessage)(jagoanproject, m.chat, target, groupMetadata);
    } else {
      throw `\u274C Aksi tidak valid! Gunakan *welcome* atau *left*.

\u{1F4A1} Contoh: ${usedPrefix}${command} welcome 6281234567890`;
    }
  } catch (e) {
    console.error("[ERROR] Gagal menjalankan simulasi:", e);
    let errorMessage = "\u274C Terjadi kesalahan saat menjalankan simulasi: ";
    const errMsg = e?.message || String(e || "");
    if (errMsg.includes("profilePictureUrl")) {
      errorMessage += "Gagal mengambil foto profil pengguna. Pastikan nomor valid atau coba lagi nanti.";
    } else if (errMsg.includes("fetch")) {
      errorMessage += "Gagal mengambil data gambar. Periksa koneksi internet atau URL gambar.";
    } else if (errMsg.includes("makeWelcomeImage") || errMsg.includes("makeLeftImage") || errMsg.includes("Canvas")) {
      errorMessage += "Gagal membuat gambar welcome/leave. Pastikan modul canvafy berfungsi dengan benar.";
    } else {
      errorMessage += errMsg || "Kesalahan tidak diketahui. Silakan coba lagi atau hubungi developer.";
    }
    throw errorMessage;
  }
};
handler.help = ["simulate <welcome|left> [nomor]"];
handler.tags = ["owner"];
handler.command = /^simulate$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
handler.group = true;
var owner_simulate_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
