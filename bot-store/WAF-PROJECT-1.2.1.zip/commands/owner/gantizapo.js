/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - gantizapo.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_gantizapo_exports = {};
__export(owner_gantizapo_exports, {
  default: () => owner_gantizapo_default
});
module.exports = __toCommonJS(owner_gantizapo_exports);
var import_node_child_process = require("node:child_process");
var import_node_fs = __toESM(require("node:fs"));
var import_node_path = __toESM(require("node:path"));
var import_node_url = require("node:url");
const __jpUnused___dirname = import_node_path.default.dirname((0, import_node_url.fileURLToPath)(__jpImportMetaUrl));
const ROOT = import_node_path.default.resolve(__dirname, "../..");
const PACKAGE = import_node_path.default.join(ROOT, "package.json");
function validSpec(value) {
  return /^(latest|next|\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?|\^\d+\.\d+\.\d+|~\d+\.\d+\.\d+)$/.test(value);
}
let handler = async (m, { text }) => {
  const spec = String(text || "latest").trim();
  if (!validSpec(spec)) {
    return m.reply("\u26A0\uFE0F Format versi tidak valid. Contoh: .gantizapo latest atau .gantizapo 1.8.0");
  }
  if (!import_node_fs.default.existsSync(PACKAGE)) return m.reply("\u274C package.json tidak ditemukan di root project.");
  const pkg = JSON.parse(import_node_fs.default.readFileSync(PACKAGE, "utf8"));
  pkg.dependencies ||= {};
  pkg.dependencies["zapo-js"] = spec;
  import_node_fs.default.writeFileSync(PACKAGE, JSON.stringify(pkg, null, 2) + "\n");
  await m.reply(`\u2705 zapo-js diset ke ${spec}. Menjalankan npm install untuk menyinkronkan dependency...`);
  (0, import_node_child_process.execFile)("npm", ["install", "--omit=dev"], { cwd: ROOT }, async (error) => {
    if (error) {
      console.error("[GANTIZAPO]", error);
      return m.reply(`\u274C npm install gagal: ${error.message}`);
    }
    await m.reply("\u2705 Dependency Zapo sudah diperbarui. Silakan restart process bot agar versi baru dipakai.");
  });
};
handler.help = ["gantizapo [latest|versi]"];
handler.tags = ["owner"];
handler.command = /^gantizapo$/i;
handler.rowner = true;
var owner_gantizapo_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
