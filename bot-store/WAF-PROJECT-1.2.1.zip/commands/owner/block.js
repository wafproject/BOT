/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - block.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_block_exports = {};
__export(owner_block_exports, {
  default: () => owner_block_default
});
module.exports = __toCommonJS(owner_block_exports);
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  function no(number2) {
    return number2.replace(/\s/g, "").replace(/([@+-])/g, "");
  }
  text = no(text);
  let user;
  let number;
  if (!text && !m.quoted) {
    return jagoanproject.reply(m.chat, `*Masukkan nomor atau tag user yang mau di ${command} bang*`, m);
  }
  try {
    if (text) {
      number = text;
      user = number + "@s.whatsapp.net";
    } else if (m.quoted && m.quoted.sender) {
      user = m.quoted.sender;
      number = user.split("@")[0];
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      user = m.mentionedJid[0];
      number = user.split("@")[0];
    } else {
      return jagoanproject.reply(m.chat, `\u274C *Gagal mengidentifikasi user! Masukkan nomor atau tag user yang valid*`, m);
    }
    let action = command.toLowerCase() === "block" ? "block" : "unblock";
    await jagoanproject.updateBlockStatus(user, action);
    jagoanproject.reply(m.chat, `\u2705 Berhasil ${action === "block" ? "memblokir user" : "membuka blokir user"}

\u2013 nama : @${number}`, null, {
      contextInfo: {
        mentionedJid: [user]
      }
    });
  } catch (e) {
    console.error(e);
    jagoanproject.reply(m.chat, `\u203C\uFE0F *Terjadi kesalahan saat ${command} user!*`, m);
  }
};
handler.help = ["block <@user/nomor>", "unblock <@user/nomor>"];
handler.tags = ["owner"];
handler.command = /^(block|unblock)$/i;
handler.owner = true;
handler.register = true;
handler.limit = true;
var owner_block_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
