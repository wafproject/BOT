/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - relay.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_relay_exports = {};
__export(owner_relay_exports, {
  default: () => owner_relay_default
});
module.exports = __toCommonJS(owner_relay_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_crypto = __toESM(require("crypto"));
var import_simple = require("../../lib/jagoan/simple.js");
const RELAY_FORMAT = "jagoan-relay-v1";
const RELAY_DIR = import_path.default.resolve("./function/temp/relay");
const MAX_SESSION_BYTES = 8 * 1024 * 1024;
const MAX_IMPORT_BYTES = MAX_SESSION_BYTES * 3;
function ensureRelayDir() {
  import_fs.default.mkdirSync(RELAY_DIR, { recursive: true });
}
function sessionKey(m, conn) {
  const bot = String(conn?.user?.id || conn?.user?.jid || "bot");
  const owner = String(m?.sender || "owner");
  return import_crypto.default.createHash("sha256").update(`${bot}|${owner}`).digest("hex").slice(0, 24);
}
function sessionPath(m, conn) {
  ensureRelayDir();
  return import_path.default.join(RELAY_DIR, `relay-${sessionKey(m, conn)}.json`);
}
function activeMessageTypes(messageObject = {}) {
  return Object.entries(messageObject).filter(([, value]) => value !== null && typeof value !== "undefined").map(([key]) => key);
}
function relaySourceMeta(m, extra = {}) {
  return {
    chat: String(extra.chat || m?.quoted?.chat || m?.chat || ""),
    sender: String(extra.sender || m?.quoted?.sender || ""),
    messageId: String(extra.messageId || m?.quoted?.id || ""),
    mtype: String(extra.mtype || m?.quoted?.mtype || "unknown"),
    importedFrom: extra.importedFrom ? String(extra.importedFrom) : void 0
  };
}
async function getQuotedProtoMessage(m) {
  if (!m?.quoted) return null;
  let fullQuoted = null;
  try {
    fullQuoted = typeof m.getQuotedObj === "function" ? await m.getQuotedObj() : null;
  } catch {
  }
  const rawMessage = fullQuoted?.message || m.quoted?.fakeObj?.message || null;
  if (!rawMessage || typeof rawMessage !== "object") return null;
  return import_simple.proto.Message.fromObject(rawMessage);
}
function makeRelayImplementation() {
  return [
    "import { generateWAMessageFromContent, proto } from '../../lib/jagoan/simple.js'",
    "",
    "const decoded = proto.Message.decode(Buffer.from(session.messageBase64, 'base64'))",
    "const generated = generateWAMessageFromContent(targetJid, decoded, {",
    "  userJid: conn.user.id,",
    "})",
    "await conn.relayMessage(targetJid, generated.message, {",
    "  messageId: generated.key.id,",
    "})"
  ].join("\n");
}
function reviveStaticBuffers(value) {
  if (Array.isArray(value)) return value.map(reviveStaticBuffers);
  if (!value || typeof value !== "object") return value;
  if (value.type === "Buffer" && Array.isArray(value.data)) {
    const bytes = value.data.map((n) => Number(n) & 255);
    return Buffer.from(bytes);
  }
  const out = {};
  for (const [key, child] of Object.entries(value)) out[key] = reviveStaticBuffers(child);
  return out;
}
function cloneRelayData(value, depth = 0) {
  if (depth > 128) throw new Error("relayOptions terlalu dalam.");
  if (Buffer.isBuffer(value)) return Buffer.from(value);
  if (Array.isArray(value)) return value.map((item) => cloneRelayData(item, depth + 1));
  if (value == null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value !== "object") return void 0;
  const out = {};
  for (const [key, child] of Object.entries(value)) {
    if (key === "__proto__" || key === "prototype" || key === "constructor") continue;
    const cloned = cloneRelayData(child, depth + 1);
    if (typeof cloned !== "undefined") out[key] = cloned;
  }
  return out;
}
function sanitizeRelayOptions(value = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const cloned = cloneRelayData(value) || {};
  delete cloned.messageId;
  delete cloned.id;
  delete cloned.statusJidList;
  delete cloned.participant;
  return cloned;
}
function relayErrorText(error) {
  return String(error?.message || error || "");
}
function isPublishAck479(error) {
  const text = relayErrorText(error);
  return /negative\s+publish\s+ack/i.test(text) && /(?:error|code|status)\s*[=:]?\s*479\b/i.test(text) || /\b479\b/.test(text) && /publish\s+ack/i.test(text);
}
function legacyButtonsCompatContent(message = {}) {
  const bm = message?.buttonsMessage;
  if (!bm || !Array.isArray(bm.buttons) || !bm.buttons.length) return null;
  const interactiveButtons = [];
  for (const button of bm.buttons) {
    if (!button || typeof button !== "object") continue;
    if (button.nativeFlowInfo?.name) {
      const params = button.nativeFlowInfo.paramsJson ?? button.nativeFlowInfo.buttonParamsJson ?? button.nativeFlowInfo.params ?? {};
      interactiveButtons.push({
        name: String(button.nativeFlowInfo.name),
        buttonParamsJson: typeof params === "string" ? params : JSON.stringify(params)
      });
      continue;
    }
    if (button.buttonId != null) {
      interactiveButtons.push({
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({
          display_text: String(button.buttonText?.displayText ?? button.displayText ?? button.text ?? "Button"),
          id: String(button.buttonId)
        })
      });
    }
  }
  if (!interactiveButtons.length) return null;
  const location = bm.locationMessage && typeof bm.locationMessage === "object" ? bm.locationMessage : null;
  return {
    text: String(bm.contentText ?? bm.text ?? ""),
    ...bm.footerText != null ? { footer: String(bm.footerText) } : {},
    ...bm.title != null || location?.name != null ? { title: String(bm.title ?? location?.name ?? "") } : {},
    ...location?.address != null ? { subtitle: String(location.address) } : {},
    ...bm.contextInfo && typeof bm.contextInfo === "object" ? { contextInfo: bm.contextInfo } : {},
    interactiveButtons
  };
}
function isZapoManagedInteractiveAddonNode(node) {
  if (!node || typeof node !== "object") return false;
  const tag = String(node.tag || "").toLowerCase();
  return tag === "biz";
}
function stripProtocolManagedAttributes(attributes) {
  if (!attributes || typeof attributes !== "object" || Array.isArray(attributes)) return void 0;
  const out = { ...attributes };
  for (const key of [
    "to",
    "type",
    "id",
    "edit",
    "phash",
    "addressing_mode",
    "participant",
    "peer_recipient_pn",
    "device_fanout"
  ]) delete out[key];
  return Object.keys(out).length ? out : void 0;
}
function prepareZapoLegacyInteractiveOptions(relayOptions = {}) {
  const options = sanitizeRelayOptions(relayOptions);
  let droppedAddonNodes = 0;
  for (const key of ["additionalNodes", "customNodes"]) {
    if (!Array.isArray(options[key])) continue;
    const kept = options[key].filter((node) => {
      if (!isZapoManagedInteractiveAddonNode(node)) return true;
      droppedAddonNodes++;
      return false;
    });
    if (kept.length) options[key] = kept;
    else delete options[key];
  }
  const safeAttrs = stripProtocolManagedAttributes(options.additionalAttributes);
  if (safeAttrs) options.additionalAttributes = safeAttrs;
  else delete options.additionalAttributes;
  delete options.id;
  delete options.messageId;
  return { options, droppedAddonNodes };
}
async function relayLegacyInteractiveOriginal(message, m, conn, relayOptions = {}) {
  if (!message?.buttonsMessage && !message?.listMessage) return false;
  const kind = message?.buttonsMessage ? "buttonsMessage" : "listMessage";
  const { options, droppedAddonNodes } = prepareZapoLegacyInteractiveOptions(relayOptions);
  const sent = await conn.relayMessage(m.chat, message, options);
  const id = sent?.key?.id || sent?.id || sent?.messageId || "-";
  console.log(`[RELAY][ZAPO-LEGACY] ${kind} asli terkirim id=${id} chat=${m.chat} droppedAddonNodes=${droppedAddonNodes}`);
  return true;
}
async function relayLegacyButtonsCompat(message, m, conn, reason = "legacy-buttons") {
  const compat = legacyButtonsCompatContent(message);
  if (!compat) return false;
  await conn.sendMessage(m.chat, compat);
  console.log(`[RELAY][COMPAT] buttonsMessage -> nativeFlow reason=${reason} chat=${m.chat}`);
  return true;
}
function buildSessionFromMessage(message, source = {}, relayMeta = {}) {
  const encoded = Buffer.from(import_simple.proto.Message.encode(message).finish());
  if (!encoded.length) throw new Error("Payload relay kosong.");
  if (encoded.length > MAX_SESSION_BYTES) {
    throw new Error(`Payload terlalu besar (${encoded.length} byte). Batas ${MAX_SESSION_BYTES} byte.`);
  }
  const messageObject = import_simple.proto.Message.toObject(message, {
    longs: String,
    enums: String,
    bytes: String,
    defaults: false
  });
  const types = activeMessageTypes(messageObject);
  return {
    format: RELAY_FORMAT,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    oneShot: true,
    source: {
      chat: String(source.chat || ""),
      sender: String(source.sender || ""),
      messageId: String(source.messageId || ""),
      mtype: String(source.mtype && source.mtype !== "unknown" ? source.mtype : types[0] || "unknown"),
      ...source.importedFrom ? { importedFrom: String(source.importedFrom) } : {}
    },
    messageTypes: types,
    encoding: "protobuf-base64",
    messageBase64: encoded.toString("base64"),
    messageObject,
    implementation: makeRelayImplementation(),
    ...relayMeta.transport ? { transport: String(relayMeta.transport) } : {},
    ...relayMeta.relayOptions && typeof relayMeta.relayOptions === "object" ? { relayOptions: sanitizeRelayOptions(relayMeta.relayOptions) } : {},
    ...relayMeta.messageIdPrefix ? { messageIdPrefix: String(relayMeta.messageIdPrefix).slice(0, 24) } : {}
  };
}
function buildSession(message, m) {
  return buildSessionFromMessage(message, relaySourceMeta(m));
}
function writeSessionAtomic(file, session) {
  const json = JSON.stringify(session, null, 2);
  const temp = `${file}.${process.pid}.${Date.now()}.tmp`;
  import_fs.default.writeFileSync(temp, json);
  import_fs.default.renameSync(temp, file);
  return Buffer.from(json);
}
function validateAndNormalizeSession(candidate, source = {}) {
  let value = candidate;
  if (value && typeof value === "object" && !Array.isArray(value)) {
    if (value.default && typeof value.default === "object") value = value.default;
    if (value.session && typeof value.session === "object") value = value.session;
    else if (value.relay && typeof value.relay === "object") value = value.relay;
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("Payload relay harus berupa object JSON.");
  }
  let message = null;
  const base64 = typeof value.messageBase64 === "string" ? value.messageBase64.trim() : "";
  if (base64) {
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) throw new Error("messageBase64 tidak valid.");
    const binary = Buffer.from(base64, "base64");
    if (!binary.length || binary.length > MAX_SESSION_BYTES) throw new Error("Payload base64 relay kosong atau terlalu besar.");
    message = import_simple.proto.Message.decode(binary);
  } else if (value.messageObject && typeof value.messageObject === "object") {
    message = import_simple.proto.Message.fromObject(reviveStaticBuffers(value.messageObject));
  } else if (value.message && typeof value.message === "object") {
    message = import_simple.proto.Message.fromObject(reviveStaticBuffers(value.message));
  } else {
    const reserved = /* @__PURE__ */ new Set(["format", "createdAt", "oneShot", "source", "messageTypes", "encoding", "implementation"]);
    const keys = Object.keys(value);
    if (keys.length && keys.some((key) => !reserved.has(key))) {
      try {
        message = import_simple.proto.Message.fromObject(reviveStaticBuffers(value));
      } catch {
      }
    }
  }
  if (!message) throw new Error("Tidak menemukan messageBase64/messageObject yang dapat dijadikan relay.");
  return buildSessionFromMessage(message, {
    ...source,
    mtype: String(value?.source?.mtype || source.mtype || "unknown"),
    chat: String(value?.source?.chat || source.chat || ""),
    sender: String(value?.source?.sender || source.sender || ""),
    messageId: String(value?.source?.messageId || source.messageId || "")
  }, {
    transport: value?.transport,
    relayOptions: value?.relayOptions,
    messageIdPrefix: value?.messageIdPrefix
  });
}
function stripCodeFence(text = "") {
  const value = String(text).replace(/^\uFEFF/, "").trim();
  const fenced = value.match(/^```(?:json|js|javascript)?\s*\n?([\s\S]*?)\n?```$/i);
  return fenced ? fenced[1].trim() : value;
}
function extractBalancedJsonObject(text, startAt = 0) {
  const start = text.indexOf("{", startAt);
  if (start < 0) return "";
  let depth = 0;
  let quote = "";
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === quote) quote = "";
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      continue;
    }
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return "";
}
function parseStrictJsonObject(text) {
  const parsed = JSON.parse(text);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Root JSON relay harus object.");
  return parsed;
}
function parseStaticJsObject(text) {
  let i = 0;
  const maxDepth = 128;
  const skip = () => {
    while (i < text.length) {
      if (/\s/.test(text[i])) {
        i++;
        continue;
      }
      if (text.startsWith("//", i)) {
        i += 2;
        while (i < text.length && text[i] !== "\n") i++;
        continue;
      }
      if (text.startsWith("/*", i)) {
        const end = text.indexOf("*/", i + 2);
        if (end < 0) throw new Error("Komentar JS tidak tertutup.");
        i = end + 2;
        continue;
      }
      break;
    }
  };
  const readString = () => {
    const quote = text[i++];
    let out = "";
    while (i < text.length) {
      const ch = text[i++];
      if (ch === quote) return out;
      if (ch === "\\") {
        if (i >= text.length) throw new Error("Escape string JS tidak valid.");
        const e = text[i++];
        const map = { n: "\n", r: "\r", t: "	", b: "\b", f: "\f", v: "\v", "0": "\0" };
        if (e === "u") {
          const hex = text.slice(i, i + 4);
          if (!/^[0-9a-f]{4}$/i.test(hex)) throw new Error("Unicode escape JS tidak valid.");
          out += String.fromCharCode(parseInt(hex, 16));
          i += 4;
        } else if (e === "x") {
          const hex = text.slice(i, i + 2);
          if (!/^[0-9a-f]{2}$/i.test(hex)) throw new Error("Hex escape JS tidak valid.");
          out += String.fromCharCode(parseInt(hex, 16));
          i += 2;
        } else out += Object.prototype.hasOwnProperty.call(map, e) ? map[e] : e;
        continue;
      }
      if (quote === "`" && ch === "$" && text[i] === "{") throw new Error("Template expression tidak diizinkan pada relay JS.");
      out += ch;
    }
    throw new Error("String JS tidak tertutup.");
  };
  const readIdentifier = () => {
    const m = text.slice(i).match(/^[A-Za-z_$][\w$]*/);
    if (!m) throw new Error(`Identifier JS tidak valid di posisi ${i}.`);
    i += m[0].length;
    return m[0];
  };
  const parseValue = (depth = 0) => {
    if (depth > maxDepth) throw new Error("Object relay JS terlalu dalam.");
    skip();
    const ch = text[i];
    if (ch === "{") return parseObject(depth + 1);
    if (ch === "[") return parseArray(depth + 1);
    if (ch === '"' || ch === "'" || ch === "`") return readString();
    const number = text.slice(i).match(/^-?(?:0x[0-9a-f]+|\d+(?:\.\d+)?(?:e[+-]?\d+)?)/i);
    if (number) {
      i += number[0].length;
      return Number(number[0]);
    }
    const id = readIdentifier();
    if (id === "true") return true;
    if (id === "false") return false;
    if (id === "null") return null;
    if (id === "undefined") return null;
    throw new Error(`Nilai executable '${id}' tidak diizinkan pada relay JS.`);
  };
  const parseArray = (depth) => {
    const out = [];
    i++;
    skip();
    if (text[i] === "]") {
      i++;
      return out;
    }
    while (i < text.length) {
      out.push(parseValue(depth));
      skip();
      if (text[i] === "]") {
        i++;
        return out;
      }
      if (text[i] !== ",") throw new Error(`Array JS tidak valid di posisi ${i}.`);
      i++;
      skip();
      if (text[i] === "]") {
        i++;
        return out;
      }
    }
    throw new Error("Array JS tidak tertutup.");
  };
  const parseObject = (depth) => {
    const out = {};
    i++;
    skip();
    if (text[i] === "}") {
      i++;
      return out;
    }
    while (i < text.length) {
      skip();
      let key;
      if (text[i] === '"' || text[i] === "'" || text[i] === "`") key = readString();
      else if (/\d/.test(text[i])) {
        const m = text.slice(i).match(/^\d+(?:\.\d+)?/);
        key = m[0];
        i += m[0].length;
      } else key = readIdentifier();
      skip();
      if (text[i] !== ":") throw new Error(`Property '${key}' bukan data object statis.`);
      i++;
      out[key] = parseValue(depth);
      skip();
      if (text[i] === "}") {
        i++;
        return out;
      }
      if (text[i] !== ",") throw new Error(`Object JS tidak valid di posisi ${i}.`);
      i++;
      skip();
      if (text[i] === "}") {
        i++;
        return out;
      }
    }
    throw new Error("Object JS tidak tertutup.");
  };
  const result = parseValue(0);
  if (!result || typeof result !== "object" || Array.isArray(result)) throw new Error("Root relay JS harus object statis.");
  return result;
}
function escapeRegExp(text = "") {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function findStaticVariableObject(source, variableName, seen = /* @__PURE__ */ new Set()) {
  const name = String(variableName || "").trim();
  if (!/^[A-Za-z_$][\w$]*$/.test(name) || seen.has(name)) return null;
  seen.add(name);
  const re = new RegExp("(?:const|let|var)\\s+" + escapeRegExp(name) + "\\s*=\\s*", "m");
  const match = re.exec(source);
  if (!match) return null;
  let pos = match.index + match[0].length;
  while (/\s/.test(source[pos] || "")) pos++;
  if (source[pos] === "{") {
    const objectText = extractBalancedJsonObject(source, pos);
    if (!objectText) return null;
    try {
      return parseStrictJsonObject(objectText);
    } catch {
    }
    try {
      return parseStaticJsObject(objectText);
    } catch {
    }
    return null;
  }
  const tail = source.slice(pos, pos + 500);
  const wrapper = tail.match(/^(?:reviveBuffers|reviveBuffer|proto\.Message\.fromObject)\s*\(\s*([A-Za-z_$][\w$]*)\s*\)/);
  if (wrapper?.[1]) return findStaticVariableObject(source, wrapper[1], seen);
  const alias = tail.match(/^([A-Za-z_$][\w$]*)\s*[;,\n]/);
  if (alias?.[1]) return findStaticVariableObject(source, alias[1], seen);
  return null;
}
function parseRelayScriptCall(raw, fileName) {
  const call = raw.match(/(?:await\s+)?[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*\.relayMessage\s*\(\s*([^,()]+?)\s*,\s*([A-Za-z_$][\w$]*)\s*(?:,\s*([A-Za-z_$][\w$]*))?\s*\)/m);
  if (!call) return null;
  const messageVar = call[2];
  const optionsVar = call[3] || "";
  const messageObject = findStaticVariableObject(raw, messageVar);
  if (!messageObject) return null;
  const relayOptions = optionsVar ? findStaticVariableObject(raw, optionsVar) || {} : {};
  let messageIdPrefix = "";
  if (optionsVar) {
    const prefixRe = new RegExp(escapeRegExp(optionsVar) + "\\.messageId\\s*=\\s*([\"\\'`])([^\"\\'`]{0,24})\\1\\s*\\+\\s*Date\\.now\\s*\\(\\s*\\)", "m");
    const prefixMatch = prefixRe.exec(raw);
    if (prefixMatch?.[2]) messageIdPrefix = prefixMatch[2];
  }
  const firstType = Object.keys(messageObject).find((key) => messageObject[key] != null) || `import:${fileName}`;
  return {
    format: RELAY_FORMAT,
    transport: "direct-relay",
    messageObject: reviveStaticBuffers(messageObject),
    relayOptions: sanitizeRelayOptions(relayOptions),
    ...messageIdPrefix ? { messageIdPrefix } : {},
    source: { mtype: firstType }
  };
}
function parseRelaySource(text, fileName = "relay") {
  const raw = stripCodeFence(text);
  if (!raw || Buffer.byteLength(raw) > MAX_IMPORT_BYTES) throw new Error("File relay kosong atau terlalu besar.");
  try {
    return parseStrictJsonObject(raw);
  } catch {
  }
  const marker = raw.match(/\/\*\s*JAGOAN_RELAY_JSON_BEGIN\s*\*\/([\s\S]*?)\/\*\s*JAGOAN_RELAY_JSON_END\s*\*\//i);
  if (marker?.[1]) {
    try {
      return parseStrictJsonObject(marker[1].trim());
    } catch {
    }
  }
  const relayScript = parseRelayScriptCall(raw, fileName);
  if (relayScript) return relayScript;
  const anchors = [
    /export\s+default\s+/i,
    /module\.exports\s*=\s*/i,
    /(?:const|let|var)\s+(?:session|relay|payload|message|msg)\s*=\s*/i,
    /proto\.Message\.fromObject\s*\(\s*/i,
    /generateWAMessageFromContent\s*\(\s*[^,()]+\s*,\s*/i
  ];
  for (const re of anchors) {
    const match = re.exec(raw);
    if (!match) continue;
    const objectText = extractBalancedJsonObject(raw, match.index + match[0].length);
    if (!objectText) continue;
    try {
      return parseStrictJsonObject(objectText);
    } catch {
    }
    try {
      return parseStaticJsObject(objectText);
    } catch {
    }
  }
  const base64Match = raw.match(/(?:messageBase64|message_base64)\s*[:=]\s*(["'`])([A-Za-z0-9+/=]{8,})\1/i);
  if (base64Match?.[2]) {
    const typeMatch = raw.match(/mtype\s*[:=]\s*(["'`])([^"'`\r\n]{1,100})\1/i);
    return {
      format: RELAY_FORMAT,
      encoding: "protobuf-base64",
      messageBase64: base64Match[2],
      source: { mtype: typeMatch?.[2] || `import:${fileName}` }
    };
  }
  const decodeBuffer = raw.match(/proto\.Message\.decode\s*\(\s*Buffer\.from\s*\(\s*(["'`])([A-Za-z0-9+/=]{8,})\1\s*,\s*(["'`])base64\3\s*\)\s*\)/i);
  if (decodeBuffer?.[2]) {
    return { format: RELAY_FORMAT, encoding: "protobuf-base64", messageBase64: decodeBuffer[2], source: { mtype: `import:${fileName}` } };
  }
  throw new Error("Format relay JS/JSON tidak dikenali. Didukung: JSON relay, messageBase64/messageObject, atau script statis yang memanggil relayMessage(jid, content, relayOptions).");
}
function quotedFileInfo(m) {
  const q = m?.quoted;
  const fileName = String(q?.fileName || q?.msg?.fileName || q?.message?.documentMessage?.fileName || "");
  const mimetype = String(q?.mimetype || q?.msg?.mimetype || q?.message?.documentMessage?.mimetype || "");
  const ext = import_path.default.extname(fileName).toLowerCase();
  const isDocument = q?.mtype === "documentMessage" || Boolean(fileName) || /json|javascript|text\//i.test(mimetype);
  return { fileName, mimetype, ext, isDocument, supported: isDocument && (ext === ".json" || ext === ".js" || /application\/json|javascript/i.test(mimetype)) };
}
async function getQuotedRelayImport(m) {
  if (!m?.quoted) return null;
  const info = quotedFileInfo(m);
  if (info.supported) {
    if (typeof m.quoted.download !== "function") throw new Error("File reply tidak dapat diunduh.");
    const buffer = await m.quoted.download();
    if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error("File relay kosong.");
    if (buffer.length > MAX_IMPORT_BYTES) throw new Error(`File relay terlalu besar. Maksimal ${MAX_IMPORT_BYTES} byte.`);
    if (buffer.includes(0)) throw new Error("File relay bukan file teks JS/JSON.");
    const candidate = parseRelaySource(buffer.toString("utf8"), info.fileName || "relay");
    return validateAndNormalizeSession(candidate, relaySourceMeta(m, {
      importedFrom: info.fileName || `reply.${info.ext.replace(".", "") || "txt"}`
    }));
  }
  const quotedText = String(m.quoted?.text || "").trim();
  if (quotedText && (/^\s*(?:```(?:json|js|javascript)?\s*)?\{/i.test(quotedText) || /messageBase64|JAGOAN_RELAY_JSON_BEGIN|export\s+default|module\.exports|relayMessage\s*\(|rawContent\s*=/i.test(quotedText))) {
    const candidate = parseRelaySource(quotedText, "reply-text");
    return validateAndNormalizeSession(candidate, relaySourceMeta(m, { importedFrom: "reply-text" }));
  }
  return null;
}
function readSession(file) {
  const stat = import_fs.default.statSync(file);
  if (stat.size > MAX_IMPORT_BYTES) throw new Error("File relay terlalu besar atau tidak valid.");
  const candidate = JSON.parse(import_fs.default.readFileSync(file, "utf8"));
  return validateAndNormalizeSession(candidate, { importedFrom: import_path.default.basename(file) });
}
async function sendRelayFile(m, conn, session, captionExtra = "") {
  const jsonBuffer = Buffer.from(JSON.stringify(session, null, 2));
  const fileName = `relay-${Date.now()}.json`;
  const typeText = session.messageTypes.length ? session.messageTypes.join(", ") : session.source.mtype;
  await conn.sendMessage(m.chat, {
    document: jsonBuffer,
    mimetype: "application/json",
    fileName,
    caption: [
      "\u2705 *RELAY TERSIMPAN*",
      `Jenis: *${typeText}*`,
      `Sesi: *one-shot*`,
      captionExtra,
      "",
      "Ketik *.runrelay* untuk menjalankan sesi lokal.",
      "Atau reply file relay *.json / .js* lalu ketik *.runrelay* untuk menjalankannya langsung.",
      "Alias create: *.crelay* / *.crm*."
    ].filter(Boolean).join("\n")
  }, { quoted: m });
}
async function createRelay(m, conn) {
  if (!m.quoted) {
    return m.reply("Reply pesan atau file relay *.js/.json*, lalu ketik *.crelay* / *.crm*.");
  }
  let session = null;
  let imported = false;
  try {
    session = await getQuotedRelayImport(m);
    imported = Boolean(session);
  } catch (error) {
    return m.reply(`\u274C File relay tidak valid: ${String(error?.message || error).slice(0, 700)}`);
  }
  if (!session) {
    const info = quotedFileInfo(m);
    if (info.isDocument && (info.ext === ".js" || info.ext === ".json")) {
      return m.reply("\u274C File JS/JSON ini tidak berisi payload relay yang dikenali.");
    }
    const message = await getQuotedProtoMessage(m);
    if (!message) return m.reply("\u274C Quoted message tidak dapat dibaca sebagai raw WhatsApp message.");
    session = buildSession(message, m);
  }
  const file = sessionPath(m, conn);
  writeSessionAtomic(file, session);
  await sendRelayFile(m, conn, session, imported ? "\u{1F4E5} Payload diimpor dari file/reply yang Anda balas." : "");
}
async function executeRelaySession(session, m, conn) {
  const typeText = Array.isArray(session.messageTypes) && session.messageTypes.length ? session.messageTypes.join(", ") : String(session?.source?.mtype || "unknown");
  const binary = Buffer.from(session.messageBase64, "base64");
  if (!binary.length || binary.length > MAX_SESSION_BYTES) throw new Error("Payload base64 relay tidak valid.");
  const decoded = import_simple.proto.Message.decode(binary);
  if (session?.transport === "direct-relay") {
    if (decoded?.buttonsMessage || decoded?.listMessage) {
      try {
        const sentLegacy = await relayLegacyInteractiveOriginal(decoded, m, conn, session?.relayOptions || {});
        if (sentLegacy) return typeText;
      } catch (error) {
        if (!isPublishAck479(error)) throw error;
        console.warn(`[RELAY][LEGACY-479] ${decoded?.buttonsMessage ? "buttonsMessage" : "listMessage"} asli ditolak, fallback compat chat=${m.chat}`);
        const sentCompat = await relayLegacyButtonsCompat(decoded, m, conn, "legacy-479-fallback");
        if (sentCompat) return typeText;
        throw error;
      }
    }
    const relayOptions = sanitizeRelayOptions(session?.relayOptions || {});
    try {
      await conn.relayMessage(m.chat, decoded, relayOptions);
      return typeText;
    } catch (error) {
      if (!isPublishAck479(error)) throw error;
      console.warn(`[RELAY][479] raw direct ditolak, retry generated tanpa external relay nodes chat=${m.chat}`);
      const generated2 = (0, import_simple.generateWAMessageFromContent)(m.chat, decoded, {
        userJid: conn.user?.id || conn.user?.jid
      });
      await conn.relayMessage(m.chat, generated2.message, { messageId: generated2.key.id });
      console.log(`[RELAY][479-FALLBACK] generated relay berhasil id=${generated2.key.id} chat=${m.chat}`);
      return typeText;
    }
  }
  const generated = (0, import_simple.generateWAMessageFromContent)(m.chat, decoded, {
    userJid: conn.user?.id || conn.user?.jid
  });
  await conn.relayMessage(m.chat, generated.message, { messageId: generated.key.id });
  return typeText;
}
async function runRelay(m, conn) {
  if (m.quoted) {
    let imported = null;
    try {
      imported = await getQuotedRelayImport(m);
    } catch (error) {
      return m.reply(`\u274C Relay file gagal dibaca: ${String(error?.message || error).slice(0, 800)}`);
    }
    if (imported) {
      try {
        const typeText2 = await executeRelaySession(imported, m, conn);
        return m.reply(`\u2705 Relay *${typeText2}* dari reply berhasil dijalankan.
\u{1F4CE} File asli di chat tidak dihapus.`);
      } catch (error) {
        return m.reply(`\u274C Relay reply gagal dijalankan: ${String(error?.message || error).slice(0, 800)}`);
      }
    }
    const info = quotedFileInfo(m);
    if (info.isDocument && (info.ext === ".js" || info.ext === ".json")) {
      return m.reply("\u274C File JS/JSON yang direply bukan format relay yang didukung.");
    }
  }
  const file = sessionPath(m, conn);
  if (!import_fs.default.existsSync(file)) {
    return m.reply([
      "\u274C Tidak ada sesi relay tersimpan.",
      "\u2022 Reply pesan lalu *.crelay* / *.crm*, kemudian *.runrelay*",
      "\u2022 Atau langsung reply file relay *.json / .js* lalu *.runrelay*"
    ].join("\n"));
  }
  let ok = false;
  let typeText = "unknown";
  let errorMessage = "";
  try {
    const session = readSession(file);
    typeText = await executeRelaySession(session, m, conn);
    ok = true;
  } catch (error) {
    errorMessage = String(error?.message || error || "Unknown error").slice(0, 800);
  } finally {
    try {
      import_fs.default.rmSync(file, { force: true });
    } catch {
    }
  }
  if (ok) return m.reply(`\u2705 Relay *${typeText}* berhasil dijalankan.
\u{1F5D1}\uFE0F File sesi lokal sudah dihapus.`);
  return m.reply(`\u274C Relay gagal dijalankan: ${errorMessage}
\u{1F5D1}\uFE0F File sesi lokal tetap sudah dihapus (one-shot).`);
}
let handler = async (m, { jagoanproject, command }) => {
  if (/^(?:crelay|crm)$/i.test(command)) return createRelay(m, jagoanproject);
  if (/^runrelay$/i.test(command)) return runRelay(m, jagoanproject);
};
handler.help = ["crelay", "crm", "runrelay"];
handler.tags = ["owner"];
handler.command = /^(crelay|crm|runrelay)$/i;
handler.owner = true;
handler.register = true;
var owner_relay_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
