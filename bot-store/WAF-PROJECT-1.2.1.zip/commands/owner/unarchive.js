/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - unarchive.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_unarchive_exports = {};
__export(owner_unarchive_exports, {
  default: () => owner_unarchive_default
});
module.exports = __toCommonJS(owner_unarchive_exports);
var __util_1 = __toESM(require("util"));
var import_path = __toESM(require("path"));
var import_child_process = __toESM(require("child_process"));
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const fs = require2("fs");
const { promisify } = __util_1;
const exec = promisify(import_child_process.default.exec);
function q(s) {
  return `"${String(s).replace(/"/g, '\\"')}"`;
}
async function cmdExists(cmd) {
  try {
    await exec(process.platform === "win32" ? `where ${cmd}` : `command -v ${cmd}`);
    return true;
  } catch {
    return false;
  }
}
async function extractZip(zipPath, targetDir) {
  fs.mkdirSync(targetDir, { recursive: true });
  if (process.platform === "win32") {
    const ps = `powershell -NoProfile -Command "Expand-Archive -Path ${q(zipPath)} -DestinationPath ${q(targetDir)} -Force"`;
    await exec(ps, { windowsHide: true });
    return "powershell";
  }
  if (await cmdExists("unzip")) {
    const cmd = `unzip -o ${q(zipPath)} -d ${q(targetDir)}`;
    await exec(cmd);
    return "unzip";
  }
  if (await cmdExists("7z")) {
    const cmd = `7z x -y -o${q(targetDir)} ${q(zipPath)}`;
    await exec(cmd);
    return "7z";
  }
  throw new Error("Tool extract tidak ditemukan. Install `unzip` atau `7z`.");
}
const handler = async (m, { text, usedPrefix, command, jagoanproject }) => {
  if (!m.quoted || !m.quoted.mtype.includes("document")) {
    throw `\u{1F4E6} *Unarchive ZIP*

\u27A4 Balas file *.zip*
\u27A4 Ketik:
*${usedPrefix + command} <folder_tujuan>*

Contoh:
.unarchive ./plugins/rpg`;
  }
  const destInput = (text || "").trim();
  if (!destInput) throw `\u2757 Folder tujuan belum ditentukan.
Contoh: .unarchive ./plugins/rpg`;
  const fileName = m.quoted.fileName || "";
  if (!fileName.toLowerCase().endsWith(".zip")) throw `\u2757 File harus *.zip*`;
  const targetDir = import_path.default.resolve(destInput);
  const cwd = process.cwd();
  if (!targetDir.startsWith(cwd)) {
    throw `\u2757 Path tujuan tidak boleh keluar dari folder project.
CWD: ${cwd}`;
  }
  const tempZip = import_path.default.join(cwd, `temp_${Date.now()}.zip`);
  const loading = await jagoanproject.sendMessage(m.chat, { text: "\u23F3 Mengekstrak ZIP..." });
  const msgKey = loading.key;
  try {
    const buffer = await m.quoted.download();
    fs.writeFileSync(tempZip, buffer);
    const usedTool = await extractZip(tempZip, targetDir);
    fs.unlinkSync(tempZip);
    await jagoanproject.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: {
          conversation: `\u2705 *Unarchive berhasil!*
\u{1F4C1} Lokasi: ${targetDir}
\u{1F9F0} Tool: ${usedTool}`
        }
      }
    }, {});
  } catch (err) {
    if (fs.existsSync(tempZip)) fs.unlinkSync(tempZip);
    await jagoanproject.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: {
          conversation: `\u274C Gagal unarchive!
${err.message}`
        }
      }
    }, {});
  }
};
handler.help = ["unarchive <folder>"];
handler.tags = ["owner"];
handler.command = /^unarchive$/i;
handler.rowner = true;
var owner_unarchive_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
