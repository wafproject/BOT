/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - boost.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_boost_exports = {};
__export(owner_boost_exports, {
  default: () => owner_boost_default
});
module.exports = __toCommonJS(owner_boost_exports);
var __perf_hooks_1 = __toESM(require("perf_hooks"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const { performance } = __perf_hooks_1;
let handler = async (m, { jagoanproject }) => {
  let start = performance.now();
  let sent = await jagoanproject.sendMessage(m.chat, {
    text: "\u23F3 *Memulai proses boosting dan pembersihan sampah...*"
  }, { quoted: m });
  let deletedSummary = [];
  try {
    let deleteFolderRecursive = function(folderPath) {
      if (import_fs.default.existsSync(folderPath)) {
        import_fs.default.readdirSync(folderPath).forEach((file) => {
          const curPath = import_path.default.join(folderPath, file);
          if (import_fs.default.lstatSync(curPath).isDirectory()) {
            deleteFolderRecursive(curPath);
          } else {
            import_fs.default.unlinkSync(curPath);
          }
        });
        import_fs.default.rmdirSync(folderPath);
      }
    };
    const foldersToClean = [".cache", "temp", "tmp"];
    for (let folder of foldersToClean) {
      let fullPath = import_path.default.join(__dirname, "..", folder);
      if (import_fs.default.existsSync(fullPath) && import_fs.default.lstatSync(fullPath).isDirectory()) {
        let count = 0;
        for (let file of import_fs.default.readdirSync(fullPath)) {
          let filePath = import_path.default.join(fullPath, file);
          import_fs.default.rmSync(filePath, { recursive: true, force: true });
          count++;
        }
        deletedSummary.push(`${folder} ( ${count} file${count !== 1 ? "s" : ""} dihapus )`);
      }
    }
    const baseDir = import_path.default.join(__dirname, "../");
    const zipFiles = import_fs.default.readdirSync(baseDir).filter((file) => file.endsWith(".zip"));
    let deletedZip = [];
    zipFiles.forEach((file) => {
      const filePath = import_path.default.join(baseDir, file);
      import_fs.default.unlinkSync(filePath);
      deletedZip.push(file);
    });
    deletedSummary.push(zipFiles.length > 0 ? `.zip di root (${zipFiles.join(", ")})` : "tidak ada file .zip di root");
    const tmpFolder = import_path.default.join(__dirname, "../src/tmp");
    if (import_fs.default.existsSync(tmpFolder)) {
      deleteFolderRecursive(tmpFolder);
      deletedSummary.push("src/tmp (berhasil dihapus)");
    } else {
      deletedSummary.push("src/tmp (tidak ditemukan)");
    }
    let end = performance.now();
    let timeTaken = (end - start).toFixed(2);
    await jagoanproject.relayMessage(m.chat, {
      protocolMessage: {
        key: sent.key,
        type: 14,
        editedMessage: {
          conversation: `\u2705 *Boosting & Pembersihan Selesai!*

\u{1F5D1}\uFE0F File dan folder yang dibersihkan:
- ${deletedSummary.join("\n- ")}

\u26A1 Waktu proses: *${timeTaken} ms*`
        }
      }
    }, {});
  } catch (err) {
    await jagoanproject.sendMessage(m.chat, { text: `\u274C Terjadi error: ${err.message}` }, { quoted: m });
  }
};
handler.help = ["boost"];
handler.tags = ["owner"];
handler.command = /^boost|refresh$/i;
handler.rowner = true;
var owner_boost_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
