/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - hapusfile.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_hapusfile_exports = {};
__export(owner_hapusfile_exports, {
  default: () => owner_hapusfile_default
});
module.exports = __toCommonJS(owner_hapusfile_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
const tempStorage = {};
const sanitizePath = (inputPath) => {
  const projectDir = process.cwd();
  const resolvedPath = import_path.default.resolve(projectDir, inputPath);
  if (!resolvedPath.startsWith(projectDir)) {
    throw new Error("Akses ke path di luar direktori proyek tidak diizinkan!");
  }
  return resolvedPath;
};
const listDirectory = (dirPath) => {
  const entries = import_fs.default.readdirSync(dirPath);
  const directories = entries.filter((v) => import_fs.default.lstatSync(import_path.default.join(dirPath, v)).isDirectory()).map((v) => `\u{1F4C2} ${v}`);
  const files = entries.filter((v) => !import_fs.default.lstatSync(import_path.default.join(dirPath, v)).isDirectory()).map((v) => `\u{1F4C4} ${v}`);
  return [...directories, ...files].join("\n");
};
let handler = async (m, { jagoanproject, usedPrefix, command, text }) => {
  try {
    if (!text) {
      return m.reply(`*\u203C\uFE0F Format tidak valid.*

\u{1F4DD} Contoh penggunaan:

\u2013 ${usedPrefix + command} path/to/file.js`);
    }
    const [option, filePathInput] = text.split("|").map((str) => str.trim());
    if (!filePathInput) {
      const inputPath = text.trim();
      if (!inputPath) {
        return m.reply(`*\u{1F4DD} Contoh penggunaan:*

\u2013 ${usedPrefix + command} path/to/file.js`);
      }
      const filePath2 = sanitizePath(inputPath);
      if (!import_fs.default.existsSync(filePath2)) {
        if (import_fs.default.existsSync(import_path.default.dirname(filePath2))) {
          const listFiles = listDirectory(import_path.default.dirname(filePath2));
          return m.reply(`_'${inputPath}' tidak ditemukan!_

\u{1F4C2} Daftar file di direktori ${import_path.default.dirname(inputPath)}:

${listFiles || "Kosong"}`);
        }
        return m.reply(`_'${inputPath}' tidak ditemukan!_

\u{1F4C2} Pastikan path file valid.`);
      }
      if (import_fs.default.lstatSync(filePath2).isDirectory()) {
        const listFiles = listDirectory(filePath2);
        return m.reply(`\u{1F4C2} Daftar file di direktori *${inputPath}*:

${listFiles || "Kosong"}`);
      }
      const fileName = import_path.default.basename(filePath2);
      const stats = import_fs.default.statSync(filePath2);
      tempStorage[m.chat] = inputPath;
      await jagoanproject.sendMessage(m.chat, {
        text: `\u26A0\uFE0F *KONFIRMASI HAPUS FILE*

\u{1F4C4} *${fileName}*
\u{1F4CD} *Path:* ${inputPath}
\u{1F4E6} *Ukuran:* ${stats.size} bytes

> File akan dihapus permanen. Lanjutkan?`,
        footer: global.namebot || "Bot",
        buttons: [
          {
            buttonId: `${usedPrefix}${command} yes|${inputPath}`,
            buttonText: { displayText: "\u{1F5D1}\uFE0F HAPUS FILE" },
            type: 1
          },
          {
            buttonId: `${usedPrefix}${command} cancel|${inputPath}`,
            buttonText: { displayText: "\u274C BATAL" },
            type: 1
          }
        ],
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
      return;
    }
    if (!["yes", "cancel"].includes(option.toLowerCase())) {
      return m.reply(`*\u203C\uFE0F Format konfirmasi tidak valid.*

Pilih salah satu: 'yes' atau 'cancel'

\u{1F4DD} Contoh:
\u2013 ${usedPrefix + command} yes|plugins/menu.js
\u2013 ${usedPrefix + command} cancel|plugins/menu.js`);
    }
    const filePath = sanitizePath(filePathInput);
    if (!import_fs.default.existsSync(filePath)) {
      delete tempStorage[m.chat];
      if (import_fs.default.existsSync(import_path.default.dirname(filePath))) {
        const listFiles = listDirectory(import_path.default.dirname(filePath));
        return m.reply(`_'${filePathInput}' tidak ditemukan!_

\u{1F4C2} Daftar file di direktori ${import_path.default.dirname(filePathInput)}:

${listFiles || "Kosong"}`);
      }
      return m.reply(`_'${filePathInput}' tidak ditemukan!_

\u{1F4C2} Pastikan path file valid.`);
    }
    if (import_fs.default.lstatSync(filePath).isDirectory()) {
      delete tempStorage[m.chat];
      const listFiles = listDirectory(filePath);
      return m.reply(`\u{1F4C2} Path *${filePathInput}* adalah direktori, bukan file.

Isi direktori:

${listFiles || "Kosong"}`);
    }
    if (/^cancel$/i.test(option)) {
      delete tempStorage[m.chat];
      return m.reply(`\u274C Penghapusan file dibatalkan.

\u{1F4C4} *${filePathInput}* tetap aman.`);
    }
    if (/^yes$/i.test(option)) {
      const fileName = import_path.default.basename(filePath);
      import_fs.default.unlinkSync(filePath);
      delete tempStorage[m.chat];
      return m.reply(`\u2705 File berhasil dihapus.

\u{1F4C4} *${fileName}*
\u{1F4CD} *Path:* ${filePathInput}`);
    }
  } catch (e) {
    delete tempStorage[m.chat];
    return m.reply(`\u274C Terjadi kesalahan: ${e.message}`);
  }
};
handler.help = ["hapusfile"].map((v) => v + "<path/to/file>");
handler.tags = ["owner"];
handler.command = /^(hapusfile)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_hapusfile_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
