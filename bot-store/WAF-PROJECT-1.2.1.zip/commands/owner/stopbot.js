/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - stopbot.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_stopbot_exports = {};
__export(owner_stopbot_exports, {
  default: () => owner_stopbot_default
});
module.exports = __toCommonJS(owner_stopbot_exports);
var __child_process_1 = __toESM(require("child_process"));
let { spawn } = __child_process_1;
let handler = async (m, { jagoanproject }) => {
  if (!process.send) throw "\u274C *Jangan gunakan:* node main.js\n\u2705 *Gunakan:* node index.js";
  if (global.jagoanproject.user.jid == jagoanproject.user.jid) {
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u23F9\uFE0F", key: m.key } });
    await new Promise((resolve) => setTimeout(resolve, 1e3));
    await m.reply("\u{1F6D1} *Sedang Menghentikan Bot...*\nBot akan segera dimatikan. Jika ingin mengaktifkan, maka Aktifkan manual di console/panel tempat bot di jalankan.");
    await new Promise((resolve) => setTimeout(resolve, 2e3));
    if (!global.db.data) await global.db.read();
    await global.db.write();
    await m.reply("\u2705 *Bot berhasil dihentikan!*\nTerima kasih telah menggunakan bot ini. Sampai jumpa! \u{1F44B}");
    await new Promise((resolve) => setTimeout(resolve, 1e3));
    process.exit(0);
  } else throw "\u26A0\uFE0F _Akses Ditolak!_";
};
handler.help = ["stopbot"];
handler.tags = ["owner"];
handler.command = /^stopbot$/i;
handler.rowner = true;
handler.mods = true;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.register = true;
handler.limit = true;
var owner_stopbot_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
