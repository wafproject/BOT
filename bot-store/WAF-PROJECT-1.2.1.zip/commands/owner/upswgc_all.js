/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - upswgc_all.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_upswgc_all_exports = {};
__export(owner_upswgc_all_exports, {
  default: () => owner_upswgc_all_default
});
module.exports = __toCommonJS(owner_upswgc_all_exports);
let crypto;
let __deps_inited = false;
async function __init_deps() {
  if (__deps_inited) return;
  __deps_inited = true;
  {
    const m = await import("node:crypto");
    crypto = m && "default" in m ? m.default : m;
  }
  {
    const m = await import("../../lib/jagoan/simple.js");
    ({ generateWAMessageContent, generateWAMessageFromContent } = m);
  }
}
let generateWAMessageContent, generateWAMessageFromContent;
const SLEEP_BETWEEN_GROUPS_MS = 300;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function groupStatus(sock, jid, content) {
  const { backgroundColor } = content || {};
  if (content && Object.prototype.hasOwnProperty.call(content, "backgroundColor")) {
    delete content.backgroundColor;
  }
  const inside = await generateWAMessageContent(content, {
    upload: sock.waUploadToServer,
    backgroundColor
  });
  const messageSecret = crypto.randomBytes(32);
  const m = generateWAMessageFromContent(
    jid,
    {
      messageContextInfo: { messageSecret },
      groupStatusMessageV2: {
        message: {
          ...inside,
          messageContextInfo: { messageSecret }
        }
      }
    },
    {}
  );
  await sock.relayMessage(jid, m.message, { messageId: m.key.id });
  return m;
}
let handler = async function(m, { text, usedPrefix, command, conn, jagoanproject }) {
  await __init_deps();
  const sock = conn || jagoanproject || this || global.conn;
  if (!sock || typeof sock.sendMessage !== "function") {
    return m.reply("\u274C Socket koneksi tidak ketemu (conn/jagoanproject undefined).");
  }
  try {
    await sock.sendMessage(m.chat, { react: { text: "\u23F3", key: m.key } });
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    const caption = (text || "").replace(new RegExp(`^\\${usedPrefix}${command}\\s*`, "i"), "").trim();
    if (!mime && !caption) {
      await sock.sendMessage(m.chat, { react: { text: "\u{1F913}", key: m.key } });
      return m.reply(
        `Reply media atau tambahkan teks.

Contoh:
${usedPrefix + command} Hai semua (kirim ke semua grup)`
      );
    }
    let payload = {};
    if (/image/i.test(mime)) {
      payload = { image: await q.download(), caption };
    } else if (/video/i.test(mime)) {
      payload = { video: await q.download(), caption };
    } else if (/audio/i.test(mime)) {
      payload = { audio: await q.download(), mimetype: "audio/mp4" };
    } else if (caption) {
      payload = { text: caption };
    } else {
      await sock.sendMessage(m.chat, { react: { text: "\u{1F913}", key: m.key } });
      return m.reply(
        `Reply media atau tambahkan teks.

Contoh:
${usedPrefix + command} Hai semua (kirim ke semua grup)`
      );
    }
    const all = await sock.groupFetchAllParticipating();
    const groups = Object.keys(all || {});
    if (!groups.length) {
      await sock.sendMessage(m.chat, { react: { text: "\u26A0\uFE0F", key: m.key } });
      return m.reply("\u{1F4ED} Bot belum tergabung ke grup manapun.");
    }
    let sukses = 0, gagal = 0;
    for (const gid of groups) {
      try {
        await groupStatus(sock, gid, payload);
        sukses++;
        await sleep(SLEEP_BETWEEN_GROUPS_MS);
      } catch (e) {
        gagal++;
      }
    }
    await sock.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } });
    return m.reply(
      `\u2705 Selesai kirim status ke *${groups.length}* grup.
Berhasil: ${sukses}
Gagal: ${gagal}`
    );
  } catch (e) {
    await sock.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } });
    return m.reply("\u274C Terjadi kesalahan saat mengirim SWGC ke semua grup.");
  }
};
handler.help = ["swgcall"];
handler.tags = ["owner"];
handler.command = /^swgcall$/i;
handler.owner = true;
var owner_upswgc_all_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
