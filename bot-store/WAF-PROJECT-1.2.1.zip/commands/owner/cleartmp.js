/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - cleartmp.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_cleartmp_exports = {};
__export(owner_cleartmp_exports, {
  default: () => owner_cleartmp_default
});
module.exports = __toCommonJS(owner_cleartmp_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
const TARGET_DIRS = [
  import_path.default.join(process.cwd(), "tmp"),
  import_path.default.join(process.cwd(), "temp"),
  import_path.default.join(process.cwd(), "src", "tmp"),
  import_path.default.join(process.cwd(), "function", "tmp"),
  import_path.default.join(process.cwd(), "function", "temp")
];
function collectFiles(dirPath, bucket = []) {
  if (!import_fs.default.existsSync(dirPath)) return bucket;
  for (const entry of import_fs.default.readdirSync(dirPath, { withFileTypes: true })) {
    const fullPath = import_path.default.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      collectFiles(fullPath, bucket);
      continue;
    }
    bucket.push(fullPath);
  }
  return bucket;
}
let handler = async (m, { jagoanproject }) => {
  const allFiles = [];
  for (const dir of TARGET_DIRS) {
    collectFiles(dir, allFiles);
  }
  let deleted = 0;
  const failed = [];
  for (const file of allFiles) {
    try {
      import_fs.default.unlinkSync(file);
      deleted += 1;
    } catch (e) {
      failed.push(`${file} -> ${e.message}`);
    }
  }
  let msg = `\u2705 Pembersihan tmp selesai.
\u2022 File terhapus: ${deleted}`;
  if (!deleted) msg += `
\u2022 Tidak ada file tmp yang perlu dihapus.`;
  if (failed.length) msg += `
\u2022 Gagal hapus: ${failed.length}`;
  await jagoanproject.reply(m.chat, msg, m);
  if (failed.length) {
    await jagoanproject.reply(m.chat, `Contoh gagal hapus:
${failed.slice(0, 10).join("\n")}`, m);
  }
};
handler.help = ["cleartmp"];
handler.tags = ["owner"];
handler.command = /^(cleartmp)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_cleartmp_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
