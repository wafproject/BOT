/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/owner/owner - resetlimit.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var owner_resetlimit_exports = {};
__export(owner_resetlimit_exports, {
  default: () => owner_resetlimit_default
});
module.exports = __toCommonJS(owner_resetlimit_exports);
let handler = async (m, { jagoanproject, args }) => {
  let list = Object.entries(global.db.data.users);
  let lim = !args || !args[0] ? 100 : isNumber(args[0]) ? parseInt(args[0]) : 10;
  lim = Math.max(1, lim);
  list.map(([user, data], i) => Number(data.limit = lim));
  jagoanproject.reply(m.chat, `*Limit berhasil direset ${lim} / user*`, m);
};
handler.help = ["limit"].map((v) => "reset" + v);
handler.tags = ["owner"];
handler.command = /^(resetlimit|risetlimit)$/i;
handler.rowner = true;
handler.register = true;
handler.limit = true;
var owner_resetlimit_default = handler;
function isNumber(x = 0) {
  x = parseInt(x);
  return !isNaN(x) && typeof x == "number";
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "owner" }
)
