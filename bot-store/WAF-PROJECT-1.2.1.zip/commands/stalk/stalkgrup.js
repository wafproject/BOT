/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/stalk/stalk - stalkgrup.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stalk_stalkgrup_exports = {};
__export(stalk_stalkgrup_exports, {
  default: () => stalk_stalkgrup_default
});
module.exports = __toCommonJS(stalk_stalkgrup_exports);
const regex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i;
let handler = async (m, { jagoanproject, text }) => {
  if (!text) return m.reply("\u{1F4CC} Contoh: .stalkgrup https://chat.whatsapp.com/xxxxx");
  const match = text.match(regex);
  if (!match) return m.reply("\u274C Link tidak valid. Format harus seperti:\nhttps://chat.whatsapp.com/xxxxx");
  const code = match[1];
  try {
    const res = await jagoanproject.groupGetInviteInfo(code);
    const { subject, subjectOwner, owner, creation, desc, size } = res;
    let teks = `\u{1F4CD} *Hasil Stalk Grup:*
`;
    teks += `
\u{1F4DB} *Nama:* ${subject}`;
    teks += `
\u{1F9D1}\u200D\u{1F4BC} *Owner:* wa.me/${(owner || subjectOwner || "").split("@")[0]}`;
    teks += `
\u{1F465} *Jumlah Member:* ${size}`;
    teks += `
\u23F1\uFE0F *Dibuat:* ${new Date(creation * 1e3).toLocaleString()}`;
    if (desc) teks += `
\u{1F4DD} *Deskripsi:*
${desc}`;
    teks += `

\u{1F517} *Link Undangan:*
https://chat.whatsapp.com/${code}`;
    m.reply(teks);
  } catch (e) {
    console.error(e);
    m.reply("\u274C Gagal mengambil info grup. Pastikan link valid dan bot tidak diblokir oleh WhatsApp.");
  }
};
handler.command = /^stalkgrup$/i;
handler.tags = ["stalk"];
handler.help = ["stalkgrup <linkgrup>"];
handler.register = true;
handler.limit = true;
var stalk_stalkgrup_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "stalk" }
)
