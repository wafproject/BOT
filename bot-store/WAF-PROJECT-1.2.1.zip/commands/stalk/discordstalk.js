/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/stalk/stalk - discordstalk.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stalk_discordstalk_exports = {};
__export(stalk_discordstalk_exports, {
  default: () => stalk_discordstalk_default
});
module.exports = __toCommonJS(stalk_discordstalk_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
async function dclookup(id) {
  try {
    const r = await import_axios.default.get(`https://id.rappytv.com/${id}`, {
      headers: { "User-Agent": "Mozilla/5.0 (Linux; Android 10)" },
      timeout: 15e3
    });
    const $ = cheerio.load(r.data);
    return {
      status: "ok",
      result: {
        id: $("span.resulth").first().text().trim() || id,
        global_name: $('strong:contains("Global Name")').parent().find(".resulth").text().trim() || "-",
        display_name: $('strong:contains("Display Name")').parent().find(".resulth").text().trim() || "-",
        avatar: $(".avyimg").attr("src") || null,
        created: $('strong:contains("Created")').parent().find(".resulth").text().trim() || "-",
        banner_color: $("#color").attr("style")?.match(/background-color:\s*(#[0-9a-fA-F]+)/)?.[1] || "-"
      }
    };
  } catch (e) {
    return { status: "error", msg: e.message };
  }
}
function parseDiscordId(input = "") {
  const t = String(input).trim();
  const m = t.match(/^<@!?(\d+)>$/) || t.match(/(\d{10,})/);
  return m ? m[1] : null;
}
let handler = async (m, { text, usedPrefix, command }) => {
  const id = parseDiscordId(text);
  if (!id) throw `\u274C *ID Discord tidak valid*

Contoh:
${usedPrefix + command} 1355400581027729428`;
  const res = await dclookup(id);
  if (res.status !== "ok") throw `\u26A0\uFE0F Error: ${res.msg}`;
  const d = res.result;
  const caption = `\u{1F575}\uFE0F\u200D\u2642\uFE0F *DISCORD STALK*
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F194} *User ID*
\u2514 ${d.id}

\u{1F30D} *Global Name*
\u2514 ${d.global_name}

\u{1F3AD} *Display Name*
\u2514 ${d.display_name}

\u{1F4C5} *Created At*
\u2514 ${d.created}

\u{1F3A8} *Banner Color*
\u2514 ${d.banner_color}
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501`;
  const img = d.avatar || "https://cdn.discordapp.com/embed/avatars/0.png";
  await jagoanproject.sendMessage(
    m.chat,
    { image: { url: img }, caption },
    { quoted: m }
  );
};
handler.help = ["discordstalk <id>"];
handler.tags = ["stalk"];
handler.command = /^(discordstalk|dcstalk|dstalk)$/i;
handler.limit = true;
handler.register = true;
handler.premium = false;
var stalk_discordstalk_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "stalk" }
)
