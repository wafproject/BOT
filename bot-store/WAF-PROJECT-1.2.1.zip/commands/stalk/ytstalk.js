/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/stalk/stalk - ytstalk.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stalk_ytstalk_exports = {};
__export(stalk_ytstalk_exports, {
  default: () => stalk_ytstalk_default
});
module.exports = __toCommonJS(stalk_ytstalk_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, text }) => {
  if (!text) {
    return m.reply("Masukkan username YouTube yang ingin Anda stalk.\n*Contoh:*\n > .ytstalk username");
  }
  try {
    const result = await youtubeStalk(text);
    if (!result || result.error) {
      return m.reply("Tidak dapat menemukan informasi untuk channel tersebut.");
    }
    let response = `Informasi tentang channel @${text}:

`;
    response += `Username: ${result.channelMetadata?.username || "Tidak ditemukan"}
`;
    response += `Subscribers: ${result.channelMetadata?.subscriberCount || "Tidak ditemukan"}
`;
    response += `Video Count: ${result.channelMetadata?.videoCount || "Tidak ditemukan"}
`;
    response += `Description: ${result.channelMetadata?.description || "Tidak ada deskripsi"}
`;
    response += `Channel URL: ${result.channelMetadata?.channelUrl || "Tidak ditemukan"}
`;
    response += `
Video terbaru:
`;
    result.videoDataList.forEach((video) => {
      response += `\u2022 ${video.title} - ${video.viewCount} - ${video.publishedTime}
`;
      response += `Link: https://youtube.com/watch?v=${video.videoId}

`;
    });
    await m.reply(response);
  } catch (error) {
    console.error(error);
    m.reply(m.chat, `Terjadi kesalahan saat mengambil data: ${error.message}`);
  }
};
handler.command = /^(ytstalk|ytst)$/i;
handler.help = ["ytstalk [username]"];
handler.tags = ["stalk"];
handler.register = true;
handler.limit = true;
var stalk_ytstalk_default = handler;
async function youtubeStalk(username) {
  try {
    const { data } = await import_axios.default.get(`https://youtube.com/@${username}?si=ECterZh_kG0zdihm`);
    const $ = cheerio.load(data);
    const ytInitialDataScript = $("script").filter((i, el) => {
      return $(el).html().includes("var ytInitialData =");
    }).html();
    const jsonData = ytInitialDataScript.match(/var ytInitialData = (.*?);/);
    if (jsonData && jsonData[1]) {
      const parsedData = JSON.parse(jsonData[1]);
      const videoDataList = [];
      const tabs = parsedData.contents.twoColumnBrowseResultsRenderer.tabs;
      if (tabs && tabs.length > 0) {
        const videosTab = tabs[0].tabRenderer.content.sectionListRenderer.contents;
        videosTab.forEach((item) => {
          if (item.itemSectionRenderer) {
            item.itemSectionRenderer.contents.forEach((content) => {
              if (content.shelfRenderer && content.shelfRenderer.content && content.shelfRenderer.content.horizontalListRenderer) {
                const items = content.shelfRenderer.content.horizontalListRenderer.items;
                items.forEach((video) => {
                  if (video.gridVideoRenderer) {
                    const videoData = {
                      videoId: video.gridVideoRenderer.videoId,
                      title: video.gridVideoRenderer.title.simpleText,
                      thumbnail: video.gridVideoRenderer.thumbnail.thumbnails[0].url,
                      publishedTime: video.gridVideoRenderer.publishedTimeText.simpleText,
                      viewCount: video.gridVideoRenderer.viewCountText.simpleText,
                      navigationUrl: null,
                      commonConfigUrl: null,
                      duration: null
                    };
                    if (video.gridVideoRenderer.navigationEndpoint.commandMetadata) {
                      videoData.navigationUrl = video.gridVideoRenderer.navigationEndpoint.commandMetadata.webCommandMetadata.url;
                    }
                    if (video.gridVideoRenderer.navigationEndpoint.watchEndpoint && video.gridVideoRenderer.navigationEndpoint.watchEndpoint.watchEndpointSupportedOnesieConfig) {
                      videoData.commonConfigUrl = video.gridVideoRenderer.navigationEndpoint.watchEndpoint.watchEndpointSupportedOnesieConfig.html5PlaybackOnesieConfig.commonConfig.url;
                    }
                    if (video.gridVideoRenderer.thumbnailOverlays) {
                      video.gridVideoRenderer.thumbnailOverlays.forEach((overlay) => {
                        if (overlay.thumbnailOverlayTimeStatusRenderer) {
                          videoData.duration = overlay.thumbnailOverlayTimeStatusRenderer.text.simpleText;
                        }
                      });
                    }
                    videoDataList.push(videoData);
                  }
                });
              }
            });
          }
        });
      }
      const channelMetadata = {
        username: null,
        subscriberCount: null,
        videoCount: null,
        avatarUrl: null,
        channelUrl: null,
        externalId: null,
        description: null,
        rssUrl: null,
        isFamilySafe: null
      };
      if (parsedData.header && parsedData.header.pageHeaderRenderer) {
        const header = parsedData.header.pageHeaderRenderer;
        channelMetadata.username = header.content.pageHeaderViewModel.metadata.contentMetadataViewModel.metadataRows[0].metadataParts[0].text.content;
        if (header.content.pageHeaderViewModel.image.decoratedAvatarViewModel.avatar.avatarViewModel.image.sources.length > 0) {
          channelMetadata.avatarUrl = header.content.pageHeaderViewModel.image.decoratedAvatarViewModel.avatar.avatarViewModel.image.sources[0].url;
        }
      }
      if (parsedData.metadata && parsedData.metadata.channelMetadataRenderer) {
        const channelMeta = parsedData.metadata.channelMetadataRenderer;
        channelMetadata.description = channelMeta.description;
        channelMetadata.externalId = channelMeta.externalId;
        channelMetadata.rssUrl = channelMeta.rssUrl;
        channelMetadata.channelUrl = channelMeta.channelUrl;
        channelMetadata.isFamilySafe = channelMeta.isFamilySafe;
        const metadataRows = parsedData.header.pageHeaderRenderer.content.pageHeaderViewModel.metadata.contentMetadataViewModel.metadataRows;
        if (metadataRows.length > 1) {
          const subscriberRow = metadataRows[1];
          subscriberRow.metadataParts.forEach((part) => {
            if (part.text && part.text.content) {
              if (part.text.content.includes("subscribers")) {
                channelMetadata.subscriberCount = part.text.content;
              } else if (part.text.content.includes("videos")) {
                channelMetadata.videoCount = part.text.content;
              }
            }
          });
        }
      }
      return { videoDataList, channelMetadata };
    } else {
      return null;
    }
  } catch (error) {
    return { error: error.message };
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "stalk" }
)
