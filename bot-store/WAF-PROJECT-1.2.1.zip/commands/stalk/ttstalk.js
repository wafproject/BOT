/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/stalk/stalk - ttstalk.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stalk_ttstalk_exports = {};
__export(stalk_ttstalk_exports, {
  default: () => stalk_ttstalk_default
});
module.exports = __toCommonJS(stalk_ttstalk_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, text }) => {
  if (!text) return m.reply("\u274C Masukkan username TikTok yang ingin kamu stalk.\n\n\u{1F4CC} *Contoh:* .ttstalk username");
  try {
    const result = await tiktokStalk(text);
    const { userInfo } = result;
    const avatarUrl = userInfo.avatar;
    let caption = `\u2728 *TIKTOK STALK RESULT* \u2728

`;
    caption += `\u{1F464} *Nama:* ${userInfo.nama || "-"}
`;
    caption += `\u{1F4DB} *Username:* @${userInfo.username || "-"}
`;
    caption += `\u{1F194} *ID:* ${userInfo.id || "-"}
`;
    caption += `\u{1F4DD} *Bio:* ${userInfo.bio || "Tidak ada bio"}
`;
    caption += `\u2705 *Verifikasi:* ${userInfo.verifikasi ? "\u2714\uFE0F Ya" : "\u274C Tidak"}

`;
    caption += `\u{1F4CA} *Statistik Akun*
`;
    caption += `\u{1F465} Followers: *${userInfo.totalfollowers}*
`;
    caption += `\u27A1\uFE0F Mengikuti: *${userInfo.totalmengikuti}*
`;
    caption += `\u2764\uFE0F Total Like: *${userInfo.totaldisukai}*
`;
    caption += `\u{1F39E} Total Video: *${userInfo.totalvideo}*
`;
    caption += `\u{1F91D} Teman: *${userInfo.totalteman}*`;
    await jagoanproject.sendMessage(m.chat, {
      image: { url: avatarUrl },
      caption
    }, { quoted: m });
  } catch (error) {
    await m.reply(`\u274C Gagal mengambil data: ${error.message}`);
  }
};
handler.command = /^(ttstalk)$/i;
handler.help = ["ttstalk [username]"];
handler.tags = ["stalk", "premium"];
handler.premium = true;
handler.register = true;
handler.limit = true;
var stalk_ttstalk_default = handler;
async function tiktokStalk(username) {
  try {
    const response = await import_axios.default.get(`https://www.tiktok.com/@${username}?_t=ZS-8tHANz7ieoS&_r=1`);
    const html = response.data;
    const $ = cheerio.load(html);
    const scriptData = $("#__UNIVERSAL_DATA_FOR_REHYDRATION__").html();
    const parsedData = JSON.parse(scriptData);
    const userDetail = parsedData.__DEFAULT_SCOPE__?.["webapp.user-detail"];
    if (!userDetail) throw new Error("User tidak ditemukan");
    const userInfo = userDetail.userInfo?.user;
    const stats = userDetail.userInfo?.stats;
    return {
      userInfo: {
        id: userInfo?.id || null,
        username: userInfo?.uniqueId || null,
        nama: userInfo?.nickname || null,
        avatar: userInfo?.avatarLarger || null,
        bio: userInfo?.signature || null,
        verifikasi: userInfo?.verified || false,
        totalfollowers: stats?.followerCount || 0,
        totalmengikuti: stats?.followingCount || 0,
        totaldisukai: stats?.heart || 0,
        totalvideo: stats?.videoCount || 0,
        totalteman: stats?.friendCount || 0
      }
    };
  } catch (error) {
    throw new Error(error.message);
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "stalk" }
)
