/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/stalk/stalk - gensin.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stalk_gensin_exports = {};
__export(stalk_gensin_exports, {
  default: () => stalk_gensin_default
});
module.exports = __toCommonJS(stalk_gensin_exports);
var import_axios = __toESM(require("axios"));
async function handler(m, { jagoanproject, usedPrefix, command, text }) {
  try {
    if (!text) {
      return jagoanproject.reply(
        m.chat,
        `Cara pakai:

*${usedPrefix + command} 700385543*`,
        m
      );
    }
    let uid = String(text || "").trim().replace(/\D/g, "");
    if (!uid) {
      return jagoanproject.reply(
        m.chat,
        `UID hanya boleh angka.
Contoh: *${usedPrefix + command} 700385543*`,
        m
      );
    }
    if (uid.length < 7 || uid.length > 10) {
      return jagoanproject.reply(
        m.chat,
        `Sepertinya UID *${uid}* tidak valid.
Cek lagi ya.

Contoh: *${usedPrefix + command} 700385543*`,
        m
      );
    }
    let apiUrl = `https://enka.network/api/uid/${uid}`;
    const res = await import_axios.default.get(apiUrl, {
      validateStatus: () => true,
      headers: {
        "User-Agent": "WhatsAppBot-Genshin/1.0 (+https://github.com/)",
        "Accept": "application/json"
      },
      timeout: 15e3
    });
    if (res.status !== 200) {
      let msg;
      switch (res.status) {
        case 400:
          msg = `UID *${uid}* salah format.
Cek lagi ya.`;
          break;
        case 404:
          msg = `Player dengan UID *${uid}* tidak ditemukan.
(Info ini dari server HoYo).`;
          break;
        case 424:
          msg = `Genshin lagi *maintenance* / data Enka lagi error setelah update.
Coba lagi nanti.`;
          break;
        case 429:
          msg = `Kena *rate limit* dari Enka.
Terlalu banyak request dalam waktu singkat.
Coba ulang beberapa menit lagi.`;
          break;
        case 500:
          msg = `Server Enka lagi error (500).
Coba lagi nanti.`;
          break;
        case 503:
          msg = `Server Enka lagi down (503).
Coba lagi nanti.`;
          break;
        default:
          msg = `Gagal ambil data dari Enka.
*Status:* ${res.status} ${res.statusText || ""}`.trim();
      }
      return jagoanproject.reply(m.chat, msg, m);
    }
    const data = res.data || {};
    if (!data.playerInfo) {
      return jagoanproject.reply(
        m.chat,
        `Berhasil akses API, tapi *playerInfo* kosong.
Kemungkinan showcase akun ini disembunyikan atau belum di-setup.`,
        m
      );
    }
    const p = data.playerInfo;
    const avatarInfoList = Array.isArray(data.avatarInfoList) ? data.avatarInfoList : [];
    const ttl = typeof data.ttl === "number" ? data.ttl : null;
    const nickname = p.nickname || "-";
    const level = typeof p.level === "number" ? p.level : "-";
    const worldLevel = typeof p.worldLevel === "number" ? p.worldLevel : "-";
    const signature = (p.signature || "").trim() || "-";
    const finishAchievementNum = typeof p.finishAchievementNum === "number" ? p.finishAchievementNum : "-";
    const nameCardId = typeof p.nameCardId === "number" ? p.nameCardId : null;
    const towerFloorIndex = typeof p.towerFloorIndex === "number" ? p.towerFloorIndex : null;
    const towerLevelIndex = typeof p.towerLevelIndex === "number" ? p.towerLevelIndex : null;
    const fetterCount = typeof p.fetterCount === "number" ? p.fetterCount : null;
    const showAvatarInfoList = Array.isArray(p.showAvatarInfoList) ? p.showAvatarInfoList : [];
    const showNameCardIdList = Array.isArray(p.showNameCardIdList) ? p.showNameCardIdList : [];
    const totalChar = avatarInfoList.length;
    const showcasePreview = showAvatarInfoList.map((a, i) => {
      if (!a || !a.avatarId && !a.level) return null;
      return `  ${i + 1}. avatarId: *${a.avatarId || "-"}* \u2022 Lv *${a.level || "-"}*`;
    }).filter(Boolean).join("\n");
    const maxDetailChars = 6;
    const charDetails = avatarInfoList.slice(0, maxDetailChars).map((av, idx) => {
      const id = av.avatarId || "-";
      const levelChar = av.propMap && av.propMap["4001"] && av.propMap["4001"].val ? av.propMap["4001"].val : "-";
      const fetter = av.fetterInfo && typeof av.fetterInfo.expLevel === "number" ? av.fetterInfo.expLevel : "-";
      const skillLevels = av.skillLevelMap || {};
      const fight = av.fightPropMap || {};
      const hp = fight["2000"];
      const atk = fight["2001"];
      const def = fight["2002"];
      const em = fight["28"] || fight["30"];
      const er = fight["23"] || fight["26"];
      const critRate = fight["20"];
      const critDmg = fight["22"];
      const equips = Array.isArray(av.equipList) ? av.equipList : [];
      let weaponInfo = "-";
      const weapon = equips.find((e) => e.weapon);
      if (weapon && weapon.weapon) {
        const w = weapon.weapon;
        const flat = weapon.flat || {};
        weaponInfo = `itemId: *${weapon.itemId || "-"}*, Lv *${w.level || "-"}*, R${w.affixMap && Object.values(w.affixMap)[0] + 1 || 1} (rank: *${flat.rankLevel || "-"}*)`;
      }
      const artiSummary = equips.filter((e) => e.reliquary).map((e, i2) => {
        const r = e.reliquary;
        const f = e.flat || {};
        return `    - ${i2 + 1}) itemId: *${e.itemId || "-"}*, setId: *${f.setId || "-"}*, slot: *${f.equipType || "-"}*, Lv *${r.level || "-"}*`;
      }).join("\n") || "    (tidak ada / tidak terdeteksi)";
      return [
        `\u{1F9CD} *Karakter ${idx + 1}*`,
        `\u2022 avatarId: *${id}*`,
        `\u2022 Level: *${levelChar}*`,
        `\u2022 Friendship (Fetter): *${fetter}*`,
        `\u2022 Skill Level Map: \`${JSON.stringify(skillLevels)}\``,
        `\u2022 Stats (beberapa prop):`,
        `   - HP (2000): *${hp !== void 0 ? hp : "-"}*`,
        `   - ATK (2001): *${atk !== void 0 ? atk : "-"}*`,
        `   - DEF (2002): *${def !== void 0 ? def : "-"}*`,
        `   - Elemental Mastery (28/30): *${em !== void 0 ? em : "-"}*`,
        `   - Energy Recharge (23/26): *${er !== void 0 ? er : "-"}*`,
        `   - Crit Rate (20): *${critRate !== void 0 ? critRate : "-"}*`,
        `   - Crit DMG (22): *${critDmg !== void 0 ? critDmg : "-"}*`,
        `\u2022 Weapon: ${weaponInfo}`,
        `\u2022 Artifacts:`,
        artiSummary
      ].join("\n");
    }).join("\n\n");
    let ownerInfo = "";
    if (data.owner) {
      const o = data.owner;
      const profile = o.profile || {};
      ownerInfo = `
\u{1F464} *Enka Owner*
\u2022 Username: *${o.username || "-"}*
\u2022 Level Enka: *${profile.level || "-"}*
\u2022 Bio:
${(profile.bio || "").trim() || "-"}`;
    }
    let rawJson = JSON.stringify(data, null, 2);
    const maxRawLength = 6e3;
    if (rawJson.length > maxRawLength) {
      rawJson = rawJson.slice(0, maxRawLength) + "\n... (terpotong, data terlalu panjang)";
    }
    const textInfo = `\u{1F50E} *Genshin Profile dari Enka.Network*  

\u{1F464} *Nickname:* ${nickname}
\u{1F194} *UID:* ${data.uid || uid}
\u2B50 *Adventure Rank:* ${level}
\u{1F30D} *World Level:* ${worldLevel}
\u{1F3C6} *Achievement:* ${finishAchievementNum}
\u{1F3B4} *Namecard Utama (ID):* ${nameCardId !== null ? nameCardId : "-"}

\u{1F300} *Spiral Abyss:*
\u2022 Lantai: *${towerFloorIndex !== null ? towerFloorIndex : "-"}*
\u2022 Ruang: *${towerLevelIndex !== null ? towerLevelIndex : "-"}*

\u{1F91D} *Fetter (Friendship Unik):* ${fetterCount !== null ? fetterCount : "-"}

\u{1F4DD} *Signature:*
${signature}

\u{1F3B4} *Namecard Dibuka:*
\u2022 Total: *${showNameCardIdList.length}*
\u2022 List ID: ${showNameCardIdList.length ? showNameCardIdList.join(", ") : "-"}

\u{1F31F} *Showcase Characters (playerInfo.showAvatarInfoList):*
\u2022 Total: *${showAvatarInfoList.length}*
${showcasePreview || "  (kosong / disembunyikan)"}

\u{1F4E6} *Avatar Info List (detail karakter penuh):*
\u2022 Total karakter yang terdeteksi: *${totalChar}*
${totalChar === 0 ? "  (kemungkinan showcase kosong / disembunyikan)" : ""}

${charDetails || "Belum ada detail karakter yang bisa ditampilkan."}



`.trim();
    await jagoanproject.sendMessage(
      m.chat,
      {
        text: textInfo
      },
      { quoted: m }
    );
  } catch (e) {
    console.error("Error di plugin .gensin:", e);
    jagoanproject.reply(
      m.chat,
      `Terjadi error saat mengambil data dari Enka.
*Detail:* ${e.message}`,
      m
    );
  }
}
handler.help = ["gensinimpact", "gensin"].map((v) => v + " <uid>");
handler.tags = ["tools", "info"];
handler.command = /^(gensinimpact|gensin)$/i;
handler.register = false;
handler.limit = false;
var stalk_gensin_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "stalk" }
)
