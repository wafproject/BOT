/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/stalk/stalk - robloxstalk.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stalk_robloxstalk_exports = {};
__export(stalk_robloxstalk_exports, {
  default: () => stalk_robloxstalk_default
});
module.exports = __toCommonJS(stalk_robloxstalk_exports);
var import_axios = __toESM(require("axios"));
async function robloxStalk(username) {
  try {
    const headers = {
      "Content-Type": "application/json",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      Accept: "application/json"
    };
    async function getUsernameData() {
      const res = await import_axios.default.post(
        "https://users.roblox.com/v1/usernames/users",
        { usernames: [username] },
        { headers }
      );
      return res.data?.data?.[0] || null;
    }
    async function getUserData(id2) {
      try {
        const res = await import_axios.default.get(`https://users.roblox.com/v1/users/${id2}`, { headers });
        return res.data;
      } catch {
        return {};
      }
    }
    async function getProfile(id2) {
      try {
        const res = await import_axios.default.get(
          `https://thumbnails.roblox.com/v1/users/avatar?userIds=${id2}&size=720x720&format=Png&isCircular=false`,
          { headers }
        );
        return res.data?.data?.[0]?.imageUrl || null;
      } catch {
        return null;
      }
    }
    async function getPresence(id2) {
      try {
        const res = await import_axios.default.post(
          "https://presence.roblox.com/v1/presence/users",
          { userIds: [id2] },
          { headers }
        );
        const p = res.data?.userPresences?.[0] || {};
        return {
          isOnline: p.userPresenceType === 2,
          lastOnline: p.lastOnline || "Tidak tersedia",
          location: p.lastLocation || "\u274C Tidak sedang bermain apa pun (offline)"
        };
      } catch {
        return {
          isOnline: false,
          lastOnline: "Tidak tersedia",
          location: "\u274C Tidak sedang bermain apa pun (offline)"
        };
      }
    }
    async function getFriendCount(id2) {
      try {
        const res = await import_axios.default.get(`https://friends.roblox.com/v1/users/${id2}/friends/count`, { headers });
        return res.data?.count || 0;
      } catch {
        return 0;
      }
    }
    async function getFollowers(id2) {
      try {
        const res = await import_axios.default.get(`https://friends.roblox.com/v1/users/${id2}/followers/count`, { headers });
        return res.data?.count || 0;
      } catch {
        return 0;
      }
    }
    async function getFollowing(id2) {
      try {
        const res = await import_axios.default.get(`https://friends.roblox.com/v1/users/${id2}/followings/count`, { headers });
        return res.data?.count || 0;
      } catch {
        return 0;
      }
    }
    async function getBadges(id2) {
      try {
        const res = await import_axios.default.get(
          `https://badges.roblox.com/v1/users/${id2}/badges?limit=10&sortOrder=Desc`,
          { headers }
        );
        return res.data?.data?.map((b) => ({
          name: b.name,
          description: b.description,
          iconImageId: b.iconImageId
        })) || [];
      } catch {
        return [];
      }
    }
    async function getFriendList(id2) {
      try {
        const res = await import_axios.default.get(`https://friends.roblox.com/v1/users/${id2}/friends`, { headers });
        return res.data?.data?.map((f) => ({
          id: f.id,
          name: f.name,
          displayName: f.displayName,
          isOnline: f.isOnline,
          profilePicture: `https://www.roblox.com/headshot-thumbnail/image?userId=${f.id}&width=150&height=150&format=png`
        })) || [];
      } catch {
        return [];
      }
    }
    const userData = await getUsernameData();
    if (!userData) throw new Error("Username tidak ditemukan.");
    const id = userData.id;
    const [
      userDetails,
      profilePicture,
      presence,
      friendCount,
      followers,
      following,
      badges,
      friendList
    ] = await Promise.all([
      getUserData(id),
      getProfile(id),
      getPresence(id),
      getFriendCount(id),
      getFollowers(id),
      getFollowing(id),
      getBadges(id),
      getFriendList(id)
    ]);
    return {
      account: {
        username: userDetails.name,
        displayName: userDetails.displayName,
        profilePicture,
        description: userDetails.description || "-",
        created: userDetails.created,
        isBanned: userDetails.isBanned || false,
        hasVerifiedBadge: userDetails.hasVerifiedBadge || false
      },
      presence: {
        isOnline: presence.isOnline,
        lastOnline: presence.lastOnline,
        recentGame: presence.location
      },
      stats: {
        friendCount,
        followers,
        following
      },
      badges,
      friendList
    };
  } catch (err) {
    console.error("[ROBLOX STALK ERROR]", err.response?.status, err.response?.data || err.message);
    return null;
  }
}
let handler = async (m, { jagoanproject, args, text }) => {
  if (!text) {
    return jagoanproject.reply(m.chat, "\u274C Masukkan username Roblox!\n\nContoh: .robloxstalk elz_gokilll", m);
  }
  jagoanproject.reply(m.chat, "\u23F3 Sedang mengambil data profil Roblox...", m);
  try {
    const result = await robloxStalk(text);
    if (!result) {
      return jagoanproject.reply(m.chat, "\u274C Gagal mengambil data profil. Username mungkin tidak ditemukan atau terjadi kesalahan.", m);
    }
    const { account, presence, stats, badges, friendList } = result;
    let message = `\u{1F3AE} *ROBLOX PROFILE STALKER*

`;
    message += `\u{1F464} *INFORMASI AKUN*
`;
    message += `\u2022 Username: ${account.username}
`;
    message += `\u2022 Display Name: ${account.displayName}
`;
    message += `\u2022 Deskripsi: ${account.description}
`;
    message += `\u2022 Dibuat: ${new Date(account.created).toLocaleDateString("id-ID")}
`;
    message += `\u2022 Status: ${account.isBanned ? "\u{1F6AB} Banned" : "\u2705 Aktif"}
`;
    message += `\u2022 Verified Badge: ${account.hasVerifiedBadge ? "\u2705 Ya" : "\u274C Tidak"}

`;
    message += `\u{1F310} *STATUS KEHADIRAN*
`;
    message += `\u2022 Online: ${presence.isOnline ? "\u{1F7E2} Ya" : "\u{1F534} Tidak"}
`;
    message += `\u2022 Terakhir Online: ${presence.lastOnline}
`;
    message += `\u2022 Sedang Bermain: ${presence.recentGame}

`;
    message += `\u{1F4CA} *STATISTIK*
`;
    message += `\u2022 Teman: ${stats.friendCount.toLocaleString()}
`;
    message += `\u2022 Followers: ${stats.followers.toLocaleString()}
`;
    message += `\u2022 Following: ${stats.following.toLocaleString()}

`;
    if (badges.length > 0) {
      message += `\u{1F3C6} *BADGE TERBARU (${badges.length})*
`;
      badges.slice(0, 5).forEach((badge, i) => {
        message += `${i + 1}. ${badge.name}
`;
      });
      message += `
`;
    }
    if (friendList.length > 0) {
      message += `\u{1F465} *DAFTAR TEMAN (${friendList.length > 10 ? "10 dari " + friendList.length : friendList.length})*
`;
      friendList.slice(0, 10).forEach((friend, i) => {
        const status = friend.isOnline ? "\u{1F7E2}" : "\u{1F534}";
        message += `${i + 1}. ${status} ${friend.displayName} (@${friend.name})
`;
      });
    }
    if (account.profilePicture) {
      await jagoanproject.sendFile(m.chat, account.profilePicture, "profile.png", message, m);
    } else {
      jagoanproject.reply(m.chat, message, m);
    }
  } catch (error) {
    console.error("Roblox stalk error:", error);
    jagoanproject.reply(m.chat, "\u274C Terjadi kesalahan saat mengambil data profil. Coba lagi nanti.", m);
  }
};
handler.help = ["robloxstalk"];
handler.tags = ["stalk"];
handler.command = /^(robloxstalk|rbxstalk)$/i;
handler.limit = true;
handler.register = true;
var stalk_robloxstalk_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "stalk" }
)
