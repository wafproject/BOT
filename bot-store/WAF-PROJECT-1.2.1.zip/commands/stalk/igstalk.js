/**
 * stalk/igstalk.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/stalk/ig",
  "command": [
    "igstalk"
  ],
  "kind": "text",
  "category": "stalk"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
