/**
 * stalk/ghstalk.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/stalk/github",
  "command": [
    "ghstalk",
    "githubstalk"
  ],
  "kind": "text",
  "category": "stalk"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
