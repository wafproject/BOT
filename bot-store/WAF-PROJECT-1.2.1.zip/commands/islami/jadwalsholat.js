/**
 * islami/jadwalsholat.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/tools/jadwalshalat",
  "command": [
    "jadwalsholat",
    "jadwalshalat",
    "sholat"
  ],
  "kind": "text",
  "category": "islami"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
