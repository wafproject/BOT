/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - alquran.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_alquran_exports = {};
__export(islami_alquran_exports, {
  default: () => islami_alquran_default
});
module.exports = __toCommonJS(islami_alquran_exports);
var import_node_fetch = __toESM(require("node-fetch"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  if (!(args[0] || args[1])) throw `contoh:
${usedPrefix + command} 1 2

maka hasilnya adalah surah Al-Fatihah ayat 2`;
  if (isNaN(args[0]) || isNaN(args[1])) throw `contoh:
${usedPrefix + command} 1 2

maka hasilnya adalah surah Al-Fatihah ayat 2 `;
  let res = await alquran(args[0], args[1]);
  m.reply(`
${res.arab}
${res.latin}

${res.terjemahan}
${readMore}
${res.tafsir}

( ${res.surah} )
`.trim());
};
handler.help = ["alquran <114> <1>"];
handler.tags = ["islami"];
handler.command = /^(al)?quran$/i;
handler.register = true;
handler.limit = true;
var islami_alquran_default = handler;
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
async function alquran(surah, ayat) {
  let res = await (0, import_node_fetch.default)(`https://kalam.sindonews.com/ayat/${ayat}/${surah}`);
  if (!res.ok) throw "Error, maybe not found?";
  let $ = cheerio.load(await res.text());
  let content = $("body > main > div > div.content.clearfix > div.news > section > div.list-content.clearfix");
  let Surah = $(content).find("div.ayat-title > h1").text();
  let arab = $(content).find("div.ayat-detail > div.ayat-arab").text();
  let latin = $(content).find("div.ayat-detail > div.ayat-latin").text();
  let terjemahan = $(content).find("div.ayat-detail > div.ayat-detail-text").text();
  let tafsir = "";
  $(content).find("div.ayat-detail > div.tafsir-box > div").each(function() {
    tafsir += $(this).text() + "\n";
  });
  tafsir = tafsir.trim();
  let keterangan = $(content).find("div.ayat-detail > div.ayat-summary").text();
  let audio = `https://quran.kemenag.go.id/cmsq/source/s01/${surah < 10 ? "00" : surah >= 10 && surah < 100 ? "0" : ""}${surah}${ayat < 10 ? "00" : ayat >= 10 && ayat < 100 ? "0" : ""}${ayat}.mp3`;
  return {
    surah: Surah,
    arab,
    latin,
    terjemahan,
    tafsir,
    audio,
    keterangan
  };
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
