/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - alifsearch.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_alifsearch_exports = {};
__export(islami_alifsearch_exports, {
  default: () => islami_alifsearch_default
});
module.exports = __toCommonJS(islami_alifsearch_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
async function alifSearch(keyword) {
  try {
    const { data } = await import_axios.default.get(`https://alif.id/?s=${keyword}`);
    const $ = cheerio.load(data);
    const results = [];
    $(".post.style3").each((index, element) => {
      const title = $(element).find(".post-title h5 a span").text().trim();
      const link = $(element).find(".post-title h5 a").attr("href");
      const author = $(element).find(".post-author a").text().trim();
      const date = $(element).find(".post-date").text().trim();
      const category = $(element).find(".post-category a").text().trim();
      if (title && link) {
        results.push({
          title,
          url: link,
          author,
          date,
          category
        });
      }
    });
    return results;
  } catch (error) {
    console.error("Error fetching or parsing data:", error);
    return null;
  }
}
const handler = async (m, { text, args, command }) => {
  try {
    if (command === "alifsearch") {
      if (!text) return m.reply("Masukkan kata kunci pencarian artikel! Contoh: .alifsearch doa makan");
      const results = await alifSearch(text);
      if (!results || results.length === 0) return m.reply(`Tidak ditemukan artikel dengan kata kunci "${text}".`);
      let result = `\u{1F50D} Hasil Pencarian untuk "${text}"

`;
      results.forEach((article, i) => {
        result += `${i + 1}. ${article.title}
   \u270D\uFE0F Penulis: ${article.author}
   \u{1F4C5} Tanggal: ${article.date}
   \u{1F3F7}\uFE0F Kategori: ${article.category}
   \u{1F517} ${article.url}

`;
      });
      m.reply(result.trim());
    }
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan.");
  }
};
handler.command = ["alifsearch"];
handler.help = ["alifsearch"];
handler.tags = ["islami"];
handler.limit = true;
handler.register = true;
var islami_alifsearch_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
