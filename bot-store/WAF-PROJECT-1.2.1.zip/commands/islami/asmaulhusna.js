/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - asmaulhusna.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_asmaulhusna_exports = {};
__export(islami_asmaulhusna_exports, {
  default: () => islami_asmaulhusna_default
});
module.exports = __toCommonJS(islami_asmaulhusna_exports);
let handler = async (m, { args }) => {
  let asmaulhusna = JSON.stringify(global.asmaulhusna);
  let json = JSON.parse(asmaulhusna);
  let data = json.result.data.map((v, i) => `${i + 1}. ${v.latin}
${v.arabic}
${v.translation_id}`).join("\n\n");
  if (args[0]) {
    if (args[0] < 1) throw `minimal 1!`;
    if (args[0] > 99) throw `maksimal 99!`;
    let { index, latin, arabic, translation_id, translation_en } = json.result.data.find((v) => v.index == args[0]);
    return m.reply(`No. ${index}

${latin} 
${arabic}
${translation_id} 
${translation_en}  
`);
  }
  contoh = `*Asmaul Husna*

`;
  anjuran = `

Dari Abu hurarirah radhiallahu anhu, Rasulullah Saw bersabda: "\u0625\u0650\u0646\u0651\u064E \u0644\u0650\u0644\u0651\u064E\u0647\u0650 \u062A\u064E\u0639\u064E\u0627\u0644\u064E\u0649 \u062A\u0650\u0633\u0652\u0639\u064E\u0629\u064B \u0648\u064E\u062A\u0650\u0633\u0652\u0639\u0650\u064A\u0646\u064E \u0627\u0633\u0652\u0645\u064B\u0627\u060C \u0645\u0650\u0627\u0626\u064E\u0629\u064C \u0625\u0650\u0644\u0651\u064E\u0627 \u0648\u064E\u0627\u062D\u0650\u062F\u064B\u0627\u060C \u0645\u064E\u0646\u0652 \u0623\u064E\u062D\u0652\u0635\u064E\u0627\u0647\u064E\u0627 \u062F\u062E\u0644 \u0627\u0644\u062C\u0646\u0629\u060C \u0648\u0647\u0648 \u0648\u062A\u0631 \u064A\u064F\u062D\u0650\u0628\u0651\u064F \u0627\u0644\u0652\u0648\u0650\u062A\u0652\u0631\u064E"

Artinya: "Sesungguhnya Allah mempunyai sembilan puluh sembilan nama, alias seratus kurang satu. Barang siapa yang menghitung-hitungnya, niscaya masuk surga; Dia Witir dan menyukai yang witir".`;
  m.reply(contoh + data + anjuran);
};
handler.help = ["asmaulhusna [nomor]"];
handler.tags = ["islami"];
handler.command = /^(asmaulhusna)$/i;
handler.register = true;
handler.limit = true;
var islami_asmaulhusna_default = handler;
global.asmaulhusna = {
  "result": {
    "data": [
      {
        "index": "1",
        "latin": "Ar Rahman",
        "arabic": "\u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0646\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Pemurah",
        "translation_en": "The All Beneficent"
      },
      {
        "index": "2",
        "latin": "Ar Rahiim",
        "arabic": "\u0627\u0644\u0631\u064E\u0651\u062D\u0650\u064A\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Penyayang",
        "translation_en": "The Most Merciful"
      },
      {
        "index": "3",
        "latin": "Al Malik",
        "arabic": "\u0627\u0644\u0652\u0645\u064E\u0644\u0650\u0643\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Merajai/Memerintah",
        "translation_en": "The King, The Sovereign"
      },
      {
        "index": "4",
        "latin": "Al Quddus",
        "arabic": "\u0627\u0644\u0652\u0642\u064F\u062F\u064F\u0651\u0648\u0633\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Suci",
        "translation_en": "The Most Holy"
      },
      {
        "index": "5",
        "latin": "As Salaam",
        "arabic": "\u0627\u0644\u0633\u064E\u0651\u0644\u0627\u064E\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Memberi Kesejahteraan",
        "translation_en": "Peace and Blessing"
      },
      {
        "index": "6",
        "latin": "Al Mu\u2019min",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0624\u0652\u0645\u0650\u0646\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Memberi Keamanan",
        "translation_en": "The Guarantor"
      },
      {
        "index": "7",
        "latin": "Al Muhaimin",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0647\u064E\u064A\u0652\u0645\u0650\u0646\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Pemelihara",
        "translation_en": "The Guardian, the Preserver"
      },
      {
        "index": "8",
        "latin": "Al \u2018Aziiz",
        "arabic": "\u0627\u0644\u0652\u0639\u064E\u0632\u0650\u064A\u0632\u064F",
        "translation_id": "Yang Memiliki Mutlak Kegagahan",
        "translation_en": "The Almighty, the Self Sufficient"
      },
      {
        "index": "9",
        "latin": "Al Jabbar",
        "arabic": "\u0627\u0644\u0652\u062C\u064E\u0628\u064E\u0651\u0627\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Perkasa",
        "translation_en": "The Powerful, the Irresistible"
      },
      {
        "index": "10",
        "latin": "Al Mutakabbir",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u062A\u064E\u0643\u064E\u0628\u0650\u0651\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Megah,Yang Memiliki Kebesaran",
        "translation_en": "The Tremendous"
      },
      {
        "index": "11",
        "latin": "Al Khaliq",
        "arabic": "\u0627\u0644\u0652\u062E\u064E\u0627\u0644\u0650\u0642\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Pencipta",
        "translation_en": "The Creator"
      },
      {
        "index": "12",
        "latin": "Al Baari\u2019",
        "arabic": "\u0627\u0644\u0652\u0628\u064E\u0627\u0631\u0650\u0626\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Yang Melepaskan(Membuat, Membentuk, Menyeimbangkan)",
        "translation_en": "The Maker"
      },
      {
        "index": "13",
        "latin": "Al Mushawwir",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0635\u064E\u0648\u0650\u0651\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat YangMembentuk Rupa (makhluknya)",
        "translation_en": "The Fashioner of Forms"
      },
      {
        "index": "14",
        "latin": "Al Ghaffaar",
        "arabic": "\u0627\u0644\u0652\u063A\u064E\u0641\u064E\u0651\u0627\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Pengampun",
        "translation_en": "The Ever Forgiving"
      },
      {
        "index": "15",
        "latin": "Al Qahhaar",
        "arabic": "\u0627\u0644\u0652\u0642\u064E\u0647\u064E\u0651\u0627\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Memaksa",
        "translation_en": "The All Compelling Subduer"
      },
      {
        "index": "16",
        "latin": "Al Wahhaab",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u0647\u064E\u0651\u0627\u0628\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Pemberi Karunia",
        "translation_en": "The Bestower"
      },
      {
        "index": "17",
        "latin": "Ar Razzaaq",
        "arabic": "\u0627\u0644\u0631\u064E\u0651\u0632\u064E\u0651\u0627\u0642\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Pemberi Rejeki",
        "translation_en": "The Ever Providing"
      },
      {
        "index": "18",
        "latin": "Al Fattaah",
        "arabic": "\u0627\u0644\u0652\u0641\u064E\u062A\u064E\u0651\u0627\u062D\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Pembuka Rahmat",
        "translation_en": "The Opener, the Victory Giver"
      },
      {
        "index": "19",
        "latin": "Al \u2018Aliim",
        "arabic": "\u0627\u064E\u0644\u0652\u0639\u064E\u0644\u0650\u064A\u0652\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifatMengetahui (Memiliki Ilmu)",
        "translation_en": "The All Knowing, the Omniscient"
      },
      {
        "index": "20",
        "latin": "Al Qaabidh",
        "arabic": "\u0627\u0644\u0652\u0642\u064E\u0627\u0628\u0650\u0636\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat YangMenyempitkan (makhluknya)",
        "translation_en": "The Restrainer, the Straightener"
      },
      {
        "index": "21",
        "latin": "Al Baasith",
        "arabic": "\u0627\u0644\u0652\u0628\u064E\u0627\u0633\u0650\u0637\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat YangMelapangkan (makhluknya)",
        "translation_en": "The Expander, the Munificent"
      },
      {
        "index": "22",
        "latin": "Al Khaafidh",
        "arabic": "\u0627\u0644\u0652\u062E\u064E\u0627\u0641\u0650\u0636\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat YangMerendahkan (makhluknya)",
        "translation_en": "The Abaser"
      },
      {
        "index": "23",
        "latin": "Ar Raafi\u2019",
        "arabic": "\u0627\u0644\u0631\u064E\u0651\u0627\u0641\u0650\u0639\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat YangMeninggikan (makhluknya)",
        "translation_en": "The Exalter"
      },
      {
        "index": "24",
        "latin": "Al Mu\u2019izz",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0639\u0650\u0632\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat YangMemuliakan (makhluknya)",
        "translation_en": "The Giver of Honor"
      },
      {
        "index": "25",
        "latin": "Al Mudzil",
        "arabic": "\u0627\u0644\u0645\u064F\u0630\u0650\u0644\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifatYang Menghinakan (makhluknya)",
        "translation_en": "The Giver of Dishonor"
      },
      {
        "index": "26",
        "latin": "Al Samii\u2019",
        "arabic": "\u0627\u0644\u0633\u064E\u0651\u0645\u0650\u064A\u0639\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mendengar",
        "translation_en": "The All Hearing"
      },
      {
        "index": "27",
        "latin": "Al Bashiir",
        "arabic": "\u0627\u0644\u0652\u0628\u064E\u0635\u0650\u064A\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Melihat",
        "translation_en": "The All Seeing"
      },
      {
        "index": "28",
        "latin": "Al Hakam",
        "arabic": "\u0627\u0644\u0652\u062D\u064E\u0643\u064E\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Menetapkan",
        "translation_en": "The Judge, the Arbitrator"
      },
      {
        "index": "29",
        "latin": "Al \u2018Adl",
        "arabic": "\u0627\u0644\u0652\u0639\u064E\u062F\u0652\u0644\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Adil",
        "translation_en": "The Utterly Just"
      },
      {
        "index": "30",
        "latin": "Al Lathiif",
        "arabic": "\u0627\u0644\u0644\u064E\u0651\u0637\u0650\u064A\u0641\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Lembut",
        "translation_en": "The Subtly Kind"
      },
      {
        "index": "31",
        "latin": "Al Khabiir",
        "arabic": "\u0627\u0644\u0652\u062E\u064E\u0628\u0650\u064A\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifatMaha Mengetahui Rahasia",
        "translation_en": "The All Aware"
      },
      {
        "index": "32",
        "latin": "Al Haliim",
        "arabic": "\u0627\u0644\u0652\u062D\u064E\u0644\u0650\u064A\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Penyantun",
        "translation_en": "The Forbearing, the Indulgent"
      },
      {
        "index": "33",
        "latin": "Al \u2018Azhiim",
        "arabic": "\u0627\u0644\u0652\u0639\u064E\u0638\u0650\u064A\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Agung",
        "translation_en": "The Magnificent, the Infinite"
      },
      {
        "index": "34",
        "latin": "Al Ghafuur",
        "arabic": "\u0627\u0644\u0652\u063A\u064E\u0641\u064F\u0648\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pengampun",
        "translation_en": "The All Forgiving"
      },
      {
        "index": "35",
        "latin": "As Syakuur",
        "arabic": "\u0627\u0644\u0634\u064E\u0651\u0643\u064F\u0648\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat MahaPembalas Budi (Menghargai)",
        "translation_en": "The Grateful"
      },
      {
        "index": "36",
        "latin": "Al \u2018Aliy",
        "arabic": "\u0627\u0644\u0652\u0639\u064E\u0644\u0650\u064A\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Tinggi",
        "translation_en": "The Sublimely Exalted"
      },
      {
        "index": "37",
        "latin": "Al Kabiir",
        "arabic": "\u0627\u0644\u0652\u0643\u064E\u0628\u0650\u064A\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Besar",
        "translation_en": "The Great"
      },
      {
        "index": "38",
        "latin": "Al Hafizh",
        "arabic": "\u0627\u0644\u0652\u062D\u064E\u0641\u0650\u064A\u0638\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Menjaga",
        "translation_en": "The Preserver"
      },
      {
        "index": "39",
        "latin": "Al Muqiit",
        "arabic": "\u0627\u0644\u0645\u064F\u0642\u064A\u0650\u062A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pemberi Kecukupan",
        "translation_en": "The Nourisher"
      },
      {
        "index": "40",
        "latin": "Al Hasiib",
        "arabic": "\u0627\u0644\u0652\u062D\u0633\u0650\u064A\u0628\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat MahaMembuat Perhitungan",
        "translation_en": "The Reckoner"
      },
      {
        "index": "41",
        "latin": "Al Jaliil",
        "arabic": "\u0627\u0644\u0652\u062C\u064E\u0644\u0650\u064A\u0644\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mulia",
        "translation_en": "The Majestic"
      },
      {
        "index": "42",
        "latin": "Al Kariim",
        "arabic": "\u0627\u0644\u0652\u0643\u064E\u0631\u0650\u064A\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pemurah",
        "translation_en": "The Bountiful, the Generous"
      },
      {
        "index": "43",
        "latin": "Ar Raqiib",
        "arabic": "\u0627\u0644\u0631\u064E\u0651\u0642\u0650\u064A\u0628\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mengawasi",
        "translation_en": "The Watchful"
      },
      {
        "index": "44",
        "latin": "Al Mujiib",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u062C\u0650\u064A\u0628\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mengabulkan",
        "translation_en": "The Responsive, the Answerer"
      },
      {
        "index": "45",
        "latin": "Al Waasi\u2019",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u0627\u0633\u0650\u0639\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Luas",
        "translation_en": "The Vast, the All Encompassing"
      },
      {
        "index": "46",
        "latin": "Al Hakiim",
        "arabic": "\u0627\u0644\u0652\u062D\u064E\u0643\u0650\u064A\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maka Bijaksana",
        "translation_en": "The Wise"
      },
      {
        "index": "47",
        "latin": "Al Waduud",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u062F\u064F\u0648\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pencinta",
        "translation_en": "The Loving, the Kind One"
      },
      {
        "index": "48",
        "latin": "Al Majiid",
        "arabic": "\u0627\u0644\u0652\u0645\u064E\u062C\u0650\u064A\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mulia",
        "translation_en": "The All Glorious"
      },
      {
        "index": "49",
        "latin": "Al Baa\u2019its",
        "arabic": "\u0627\u0644\u0652\u0628\u064E\u0627\u0639\u0650\u062B\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Membangkitkan",
        "translation_en": "The Raiser of the Dead"
      },
      {
        "index": "50",
        "latin": "As Syahiid",
        "arabic": "\u0627\u0644\u0634\u064E\u0651\u0647\u0650\u064A\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Menyaksikan",
        "translation_en": "The Witness"
      },
      {
        "index": "51",
        "latin": "Al Haqq",
        "arabic": "\u0627\u0644\u0652\u062D\u064E\u0642\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Benar",
        "translation_en": "The Truth, the Real"
      },
      {
        "index": "52",
        "latin": "Al Wakiil",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u0643\u0650\u064A\u0644\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Memelihara",
        "translation_en": "The Trustee, the Dependable"
      },
      {
        "index": "53",
        "latin": "Al Qawiyyu",
        "arabic": "\u0627\u0644\u0652\u0642\u064E\u0648\u0650\u064A\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Kuat",
        "translation_en": "The Strong"
      },
      {
        "index": "54",
        "latin": "Al Matiin",
        "arabic": "\u0627\u0644\u0652\u0645\u064E\u062A\u0650\u064A\u0646\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Kokoh",
        "translation_en": "The Firm, the Steadfast"
      },
      {
        "index": "55",
        "latin": "Al Waliyy",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u0644\u0650\u064A\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Melindungi",
        "translation_en": "The Protecting Friend, Patron, and Helper"
      },
      {
        "index": "56",
        "latin": "Al Hamiid",
        "arabic": "\u0627\u0644\u0652\u062D\u064E\u0645\u0650\u064A\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Terpuji",
        "translation_en": "The All Praiseworthy"
      },
      {
        "index": "57",
        "latin": "Al Mushii",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u062D\u0652\u0635\u0650\u064A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mengkalkulasi",
        "translation_en": "The Accounter, the Numberer of All"
      },
      {
        "index": "58",
        "latin": "Al Mubdi\u2019",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0628\u0652\u062F\u0650\u0626\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Memulai",
        "translation_en": "The Producer, Originator, and Initiator of all"
      },
      {
        "index": "59",
        "latin": "Al Mu\u2019iid",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0639\u0650\u064A\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat MahaMengembalikan Kehidupan",
        "translation_en": "The Reinstater Who Brings Back All"
      },
      {
        "index": "60",
        "latin": "Al Muhyii",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u062D\u0652\u064A\u0650\u064A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Menghidupkan",
        "translation_en": "The Giver of Life"
      },
      {
        "index": "61",
        "latin": "Al Mumiitu",
        "arabic": "\u0627\u064E\u0644\u0652\u0645\u064F\u0645\u0650\u064A\u062A\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mematikan",
        "translation_en": "The Bringer of Death, the Destroyer"
      },
      {
        "index": "62",
        "latin": "Al Hayyu",
        "arabic": "\u0627\u0644\u0652\u062D\u064E\u064A\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Hidup",
        "translation_en": "The Ever Living"
      },
      {
        "index": "63",
        "latin": "Al Qayyuum",
        "arabic": "\u0627\u0644\u0652\u0642\u064E\u064A\u064F\u0651\u0648\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mandiri",
        "translation_en": "The Self Subsisting Sustainer of All"
      },
      {
        "index": "64",
        "latin": "Al Waajid",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u0627\u062C\u0650\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Penemu",
        "translation_en": "The Perceiver, the Finder, the Unfailing"
      },
      {
        "index": "65",
        "latin": "Al Maajid",
        "arabic": "\u0627\u0644\u0652\u0645\u064E\u0627\u062C\u0650\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mulia",
        "translation_en": "The Illustrious, the Magnificent"
      },
      {
        "index": "66",
        "latin": "Al Wahiid",
        "arabic": "\u0627\u0644\u0652\u0648\u0627\u062D\u0650\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Tunggal",
        "translation_en": "The One, The Unique, Manifestation of Unity"
      },
      {
        "index": "67",
        "latin": "Al \u2018Ahad",
        "arabic": "\u0627\u064E\u0644\u0627\u064E\u062D\u064E\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Esa",
        "translation_en": "The One, the All Inclusive, the Indivisible"
      },
      {
        "index": "68",
        "latin": "As Shamad",
        "arabic": "\u0627\u0644\u0635\u064E\u0651\u0645\u064E\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat MahaDibutuhkan, Tempat Meminta",
        "translation_en": "The Self Sufficient, the Impregnable,the Eternally Besought of All, the Everlasting"
      },
      {
        "index": "69",
        "latin": "Al Qaadir",
        "arabic": "\u0627\u0644\u0652\u0642\u064E\u0627\u062F\u0650\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat MahaMenentukan, Maha Menyeimbangkan",
        "translation_en": "The All Able"
      },
      {
        "index": "70",
        "latin": "Al Muqtadir",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0642\u0652\u062A\u064E\u062F\u0650\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Berkuasa",
        "translation_en": "The All Determiner, the Dominant"
      },
      {
        "index": "71",
        "latin": "Al Muqaddim",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0642\u064E\u062F\u0650\u0651\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mendahulukan",
        "translation_en": "The Expediter, He who brings forward"
      },
      {
        "index": "72",
        "latin": "Al Mu\u2019akkhir",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0624\u064E\u062E\u0650\u0651\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mengakhirkan",
        "translation_en": "The Delayer, He who puts far away"
      },
      {
        "index": "73",
        "latin": "Al Awwal",
        "arabic": "\u0627\u0644\u0623\u0648\u064E\u0651\u0644\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Awal",
        "translation_en": "The First"
      },
      {
        "index": "74",
        "latin": "Al Aakhir",
        "arabic": "\u0627\u0644\u0622\u062E\u0650\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Akhir",
        "translation_en": "The Last"
      },
      {
        "index": "75",
        "latin": "Az Zhaahir",
        "arabic": "\u0627\u0644\u0638\u064E\u0651\u0627\u0647\u0650\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Nyata",
        "translation_en": "The Manifest; the All Victorious"
      },
      {
        "index": "76",
        "latin": "Al Baathin",
        "arabic": "\u0627\u0644\u0652\u0628\u064E\u0627\u0637\u0650\u0646\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Ghaib",
        "translation_en": "The Hidden; the All Encompassing"
      },
      {
        "index": "77",
        "latin": "Al Waali",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u0627\u0644\u0650\u064A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Memerintah",
        "translation_en": "The Patron"
      },
      {
        "index": "78",
        "latin": "Al Muta\u2019aalii",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u062A\u064E\u0639\u064E\u0627\u0644\u0650\u064A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Tinggi",
        "translation_en": "The Self Exalted"
      },
      {
        "index": "79",
        "latin": "Al Barri",
        "arabic": "\u0627\u0644\u0652\u0628\u064E\u0631\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Penderma",
        "translation_en": "The Most Kind and Righteous"
      },
      {
        "index": "80",
        "latin": "At Tawwaab",
        "arabic": "\u0627\u0644\u062A\u064E\u0651\u0648\u064E\u0627\u0628\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Penerima Tobat",
        "translation_en": "The Ever Returning, Ever Relenting"
      },
      {
        "index": "81",
        "latin": "Al Muntaqim",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0646\u0652\u062A\u064E\u0642\u0650\u0645\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Penuntut Balas",
        "translation_en": "The Avenger"
      },
      {
        "index": "82",
        "latin": "Al Afuww",
        "arabic": "\u0627\u0644\u0639\u064E\u0641\u064F\u0648\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pemaaf",
        "translation_en": "The Pardoner, the Effacer of Sins"
      },
      {
        "index": "83",
        "latin": "Ar Ra`uuf",
        "arabic": "\u0627\u0644\u0631\u064E\u0651\u0624\u064F\u0648\u0641\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pengasih",
        "translation_en": "The Compassionate, the All Pitying"
      },
      {
        "index": "84",
        "latin": "Malikul Mulk",
        "arabic": "\u0645\u064E\u0627\u0644\u0650\u0643\u064F \u0627\u0644\u0652\u0645\u064F\u0644\u0652\u0643\u0650",
        "translation_id": "Yang Memiliki Mutlak sifatPenguasa Kerajaan (Semesta)",
        "translation_en": "The Owner of All Sovereignty"
      },
      {
        "index": "85",
        "latin": "Dzul JalaaliWal Ikraam",
        "arabic": "\u0630\u064F\u0648\u0627\u0644\u0652\u062C\u064E\u0644\u0627\u064E\u0644\u0650\u0648\u064E\u0627\u0644\u0625\u0643\u0652\u0631\u064E\u0627\u0645\u0650",
        "translation_id": "Yang Memiliki Mutlak sifat PemilikKebesaran dan Kemuliaan",
        "translation_en": "The Lord of Majesty and Generosity"
      },
      {
        "index": "86",
        "latin": "Al Muqsith",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u0642\u0652\u0633\u0650\u0637\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Adil",
        "translation_en": "The Equitable, the Requiter"
      },
      {
        "index": "87",
        "latin": "Al Jamii\u2019",
        "arabic": "\u0627\u0644\u0652\u062C\u064E\u0627\u0645\u0650\u0639\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mengumpulkan",
        "translation_en": "The Gatherer, the Unifier"
      },
      {
        "index": "88",
        "latin": "Al Ghaniyy",
        "arabic": "\u0627\u0644\u0652\u063A\u064E\u0646\u0650\u064A\u064F\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Berkecukupan",
        "translation_en": "The All Rich, the Independent"
      },
      {
        "index": "89",
        "latin": "Al Mughnii",
        "arabic": "\u0627\u0644\u0652\u0645\u064F\u063A\u0652\u0646\u0650\u064A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Memberi Kekayaan",
        "translation_en": "The Enricher, the Emancipator"
      },
      {
        "index": "90",
        "latin": "Al Maani",
        "arabic": "\u0627\u064E\u0644\u0652\u0645\u064E\u0627\u0646\u0650\u0639\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Mencegah",
        "translation_en": "The Withholder, the Shielder, the Defender"
      },
      {
        "index": "91",
        "latin": "Ad Dhaar",
        "arabic": "\u0627\u0644\u0636\u064E\u0651\u0627\u0631\u064E\u0651",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Memberi Derita",
        "translation_en": "The Distressor, the Harmer"
      },
      {
        "index": "92",
        "latin": "An Nafii\u2019",
        "arabic": "\u0627\u0644\u0646\u064E\u0651\u0627\u0641\u0650\u0639\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Memberi Manfaat",
        "translation_en": "The Propitious, the Benefactor"
      },
      {
        "index": "93",
        "latin": "An Nuur",
        "arabic": "\u0627\u0644\u0646\u064F\u0651\u0648\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Bercahaya(Menerangi, Memberi Cahaya)",
        "translation_en": "The Light"
      },
      {
        "index": "94",
        "latin": "Al Haadii",
        "arabic": "\u0627\u0644\u0652\u0647\u064E\u0627\u062F\u0650\u064A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pemberi Petunjuk",
        "translation_en": "The Guide"
      },
      {
        "index": "95",
        "latin": "Al Baadii",
        "arabic": "\u0627\u0644\u0652\u0628\u064E\u062F\u0650\u064A\u0639\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pencipta",
        "translation_en": "Incomparable, the Originator"
      },
      {
        "index": "96",
        "latin": "Al Baaqii",
        "arabic": "\u0627\u064E\u0644\u0652\u0628\u064E\u0627\u0642\u0650\u064A",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Kekal",
        "translation_en": "The Ever Enduring and Immutable"
      },
      {
        "index": "97",
        "latin": "Al Waarits",
        "arabic": "\u0627\u0644\u0652\u0648\u064E\u0627\u0631\u0650\u062B\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pewaris",
        "translation_en": "The Heir, the Inheritor of All"
      },
      {
        "index": "98",
        "latin": "Ar Rasyiid",
        "arabic": "\u0627\u0644\u0631\u064E\u0651\u0634\u0650\u064A\u062F\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Pandai",
        "translation_en": "The Guide, Infallible Teacher, and Knower"
      },
      {
        "index": "99",
        "latin": "As Shabuur",
        "arabic": "\u0627\u0644\u0635\u064E\u0651\u0628\u064F\u0648\u0631\u064F",
        "translation_id": "Yang Memiliki Mutlak sifat Maha Sabar",
        "translation_en": "The Patient"
      }
    ]
  }
};

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
