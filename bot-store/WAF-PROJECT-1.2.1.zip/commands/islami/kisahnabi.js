/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - kisahnabi.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_kisahnabi_exports = {};
__export(islami_kisahnabi_exports, {
  default: () => islami_kisahnabi_default
});
module.exports = __toCommonJS(islami_kisahnabi_exports);
var import_node_fetch = __toESM(require("node-fetch"));
let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Masukan nama nabi
Example: ${usedPrefix + command} adam`;
  let url = await (0, import_node_fetch.default)(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`);
  let kisah = await url.json();
  let hasil = ` Nabi : ${kisah.name}
Tanggal Lahir : ${kisah.thn_kelahiran}
Tempat Lahir : ${kisah.tmp}
Usia : ${kisah.usia}
Kisah : ${kisah.description}`;
  jagoanproject.reply(m.chat, hasil, m);
};
handler.help = ["kisahnabi <name>"];
handler.tags = ["islami"];
handler.command = /^kisahnabi$/i;
handler.register = false;
handler.limit = true;
handler.register = true;
var islami_kisahnabi_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
