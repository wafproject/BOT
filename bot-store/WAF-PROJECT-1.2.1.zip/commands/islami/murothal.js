/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - murothal.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_murothal_exports = {};
__export(islami_murothal_exports, {
  default: () => islami_murothal_default
});
module.exports = __toCommonJS(islami_murothal_exports);
let handler = async (m, { jagoanproject, usedPrefix: _p }) => {
  jagoanproject.reply(m.chat, `
QUR'AN BOT:
Via Copas {SEBARKAN}
*YouTube:*
_~Drawl Nag_
Juz 1 \u21E8 http://j.mp/2b8SiNO
Juz 2 \u21E8 http://j.mp/2b8RJmQ
Juz 3 \u21E8 http://j.mp/2bFSrtF
Juz 4 \u21E8 http://j.mp/2b8SXi3
Juz 5 \u21E8 http://j.mp/2b8RZm3
Juz 6 \u21E8 http://j.mp/28MBohs
Juz 7 \u21E8 http://j.mp/2bFRIZC
Juz 8 \u21E8 http://j.mp/2bufF7o
Juz 9 \u21E8 http://j.mp/2byr1bu
Juz 10 \u21E8 http://j.mp/2bHfyUH
Juz 11 \u21E8 http://j.mp/2bHf80y
Juz 12 \u21E8 http://j.mp/2bWnTby
Juz 13 \u21E8 http://j.mp/2bFTiKQ
Juz 14 \u21E8 http://j.mp/2b8SUTA
Juz 15 \u21E8 http://j.mp/2bFRQIM
Juz 16 \u21E8 http://j.mp/2b8SegG
Juz 17 \u21E8 http://j.mp/2brHsFz
Juz 18 \u21E8 http://j.mp/2b8SCfc
Juz 19 \u21E8 http://j.mp/2bFSq95
Juz 20 \u21E8 http://j.mp/2brI1zc
Juz 21 \u21E8 http://j.mp/2b8VcBO
Juz 22 \u21E8 http://j.mp/2bFRxNP
Juz 23 \u21E8 http://j.mp/2brItxm
Juz 24 \u21E8 http://j.mp/2brHKw5
Juz 25 \u21E8 http://j.mp/2brImlf
Juz 26 \u21E8 http://j.mp/2bFRHF2
Juz 27 \u21E8 http://j.mp/2bFRXno
Juz 28 \u21E8 http://j.mp/2brI3ai
Juz 29 \u21E8 http://j.mp/2bFRyBF
Juz 30 \u21E8 http://j.mp/2bFREcc
`.trim(), m);
};
handler.help = ["murothal"];
handler.tags = ["islami"];
handler.command = /^(murothal)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.register = true;
handler.limit = true;
var islami_murothal_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
