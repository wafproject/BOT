/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - daftarsurah.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_daftarsurah_exports = {};
__export(islami_daftarsurah_exports, {
  default: () => islami_daftarsurah_default
});
module.exports = __toCommonJS(islami_daftarsurah_exports);
var import_node_fetch = __toESM(require("node-fetch"));
let handler = async (m, {
  usedPrefix,
  command
}) => {
  jagoanproject.sendMessage(m.chat, {
    react: {
      text: "\u{1F551}",
      key: m.key
    }
  });
  try {
    let response = await (0, import_node_fetch.default)("https://al-quran-8d642.firebaseio.com/data.json");
    let data = await response.json();
    let teks = data.map((item, index) => {
      return `\u{1F50D} *[ RESULT ${index + 1} ]*

\u{1F4E2} *Arti:* ${item.arti}
\u{1F310} *Asma:* ${item.asma}
\u{1F3A7} *Audio:* ${item.audio}
\u{1F4D6} *Ayat:* ${item.ayat}
\u{1F4DD} *Keterangan:* ${item.keterangan.replace(/<[^>]+>/g, "")}
\u{1F4DB} *Nama:* ${item.nama}
\u{1F522} *Nomor:* ${item.nomor}
\u{1F4D6} *Rukuk:* ${item.rukuk}
\u{1F520} *Type:* ${item.type}
\u{1F522} *Urut:* ${item.urut}
`;
    }).filter((v) => v).join("\n\n________________________\n\n");
    await m.reply(teks);
  } catch (e) {
    try {
      let f = await (0, import_node_fetch.default)(`https://api.alquran.cloud/v1/surah`);
      let xx = await f.json();
      let teks = xx.data.map((item, index) => {
        return `\u{1F50D} *[ RESULT ${index + 1} ]*

\u{1F310} *English:* ${item.englishName}
\u{1F4E2} *Arti:* ${item.englishNameTranslation}
\u{1F4DB} *Nama:* ${item.name}
\u{1F522} *Nomor:* ${item.numberOfAyahs}
\u{1F520} *Type:* ${item.type}
`;
      }).filter((v) => v).join("\n\n________________________\n\n");
      await m.reply(teks);
    } catch (e2) {
      await m.reply(eror);
    }
  }
};
handler.help = ["daftarsurah"];
handler.tags = ["islami"];
handler.command = /^((list|daftar)sura(t|h))$/i;
handler.register = true;
handler.limit = true;
var islami_daftarsurah_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
