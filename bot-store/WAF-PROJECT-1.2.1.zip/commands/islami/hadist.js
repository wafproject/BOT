/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - hadist.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_hadist_exports = {};
__export(islami_hadist_exports, {
  default: () => islami_hadist_default
});
module.exports = __toCommonJS(islami_hadist_exports);
var import_node_fetch = __toESM(require("node-fetch"));
let handler = async (m, { usedPrefix, command, args }) => {
  if (!args[0]) {
    let pilihanRes = await (0, import_node_fetch.default)(`https://allhadist.vercel.app/hadith`);
    let pilihan = await pilihanRes.json();
    let pilihanText = pilihan.map((p) => `${p.name}
1 - ${p.total}`).join("\n\n");
    throw `Contoh:
${usedPrefix + command} Bukhari 1

Pilihan tersedia:
${pilihanText}`;
  }
  if (!args[1]) throw `Hadist yang ke berapa?
Contoh: ${usedPrefix + command} ${args[0]} 1`;
  try {
    let pilihanRes = await (0, import_node_fetch.default)(`https://allhadist.vercel.app/hadith`);
    let pilihan = await pilihanRes.json();
    let hadistSlug = pilihan.find((p) => p.name.toLowerCase() === args[0].toLowerCase())?.slug;
    if (!hadistSlug) throw `Nama hadist tidak valid. Pilihan tersedia:
${pilihan.map((p) => p.name).join(", ")}`;
    let res = await (0, import_node_fetch.default)(`https://allhadist.vercel.app/hadith/${hadistSlug}/${args[1]}`);
    let json = await res.json();
    let { name, number, arab, id } = json;
    let info = `*\`HADIST:\`* ${name}
*\`NOMOR:\`* ${number}

*${arab}*

*Artinya: ${id}*`;
    await m.reply(info);
  } catch (e) {
    throw e;
  }
};
handler.help = ["hadist"];
handler.tags = ["islami"];
handler.command = /^(hadist?)$/i;
handler.register = true;
handler.limit = true;
var islami_hadist_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
