/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/islami/islami - niatsholat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var islami_niatsholat_exports = {};
__export(islami_niatsholat_exports, {
  default: () => islami_niatsholat_default
});
module.exports = __toCommonJS(islami_niatsholat_exports);
let handler = async (m) => {
  let niatsolat = JSON.stringify(global.niatsolat);
  let json = JSON.parse(niatsolat);
  let data = json.result.data.map((v, i) => `${i + 1}. ${v.niat}
${v.arabic}
${v.latin}
${v.translation_id}`).join("\n\n");
  const contoh = `*Niat Sholat*

`;
  const anjuran = `

Suatu ibadah akan diterima bila memenuhi dua hal, yaitu niat dan contoh dari rasulullah saw: "\u0625\u0650\u0646\u0651\u064E\u0645\u064E\u0627 \u0627\u0644\u0652\u0623\u064E\u0639\u0652\u0645\u064E\u0627\u0644\u064F \u0628\u0650\u0627\u0644\u0646\u0651\u0650\u064A\u0651\u064E\u0627\u062A\u0650 ...[\u0631\u0648\u0627\u0647 \u0627\u0644\u0628\u062E\u0627\u0631\u064A \u0648\u0645\u0633\u0644\u0645]\u0631\u064E"
Artinya: "Sesungguhnya (sahnya) amal itu tergantung kepada niat ... [Hadits Riwayat al-Bukhari dan Muslim]".`;
  m.reply(contoh + data + anjuran);
};
handler.help = ["niatsholat"];
handler.tags = ["islami"];
handler.command = /^(niatsholat)$/i;
handler.limit = false;
handler.register = true;
var islami_niatsholat_default = handler;
global.niatsolat = {
  "result": {
    "data": [
      {
        "index": "1",
        "niat": "Niat Sholat Subuh",
        "arabic": "\u0627\u064F\u0635\u064E\u0644\u0651\u0650\u0649 \u0641\u064E\u0631\u0652\u0636\u064E \u0627\u0644\u0635\u0651\u064F\u0628\u0652\u062D\u0650 \u0631\u064E\u0643\u0652\u0639\u064E\u062A\u064E\u064A\u0652\u0646\u0650 \u0645\u064F\u0633\u0652\u062A\u064E\u0642\u0652\u0628\u0650\u0644\u064E \u0627\u0644\u0652\u0642\u0650\u0628\u0652\u0644\u064E\u0629\u0650 \u0627\u064E\u062F\u064E\u0627\u0621\u064B \u0650\u0644\u0644\u0647\u0650 \u062A\u064E\u0639\u064E\u0627\u0644\u064E\u0649",
        "latin": "Ushalli fardhosh shubhi rok'ataini mustaqbilal qiblati adaa-an lillaahi ta'aala",
        "translation_id": "Aku berniat shalat fardhu Shubuh dua raka'at menghadap kiblat karena Allah Ta'ala"
      },
      {
        "index": "2",
        "niat": "Niat Sholat Dzuhur",
        "arabic": "\u0627\u064F\u0635\u064E\u0644\u0651\u0650\u0649 \u0641\u064E\u0631\u0652\u0636\u064E \u0627\u0644\u0638\u0651\u064F\u0647\u0652\u0631\u0650\u0627\u064E\u0631\u0652\u0628\u064E\u0639\u064E \u0631\u064E\u0643\u064E\u0639\u064E\u0627\u062A\u064D \u0645\u064F\u0633\u0652\u062A\u064E\u0642\u0652\u0628\u0650\u0644\u064E \u0627\u0644\u0652\u0642\u0650\u0628\u0652\u0644\u064E\u0629\u0650 \u0627\u064E\u062F\u064E\u0627\u0621\u064B \u0650\u0644\u0644\u0647\u0650 \u062A\u064E\u0639\u064E\u0627\u0644\u064E\u0649",
        "latin": "Ushalli fardhodl dhuhri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        "translation_id": "Aku berniat shalat fardhu Dzuhur empat raka'at menghadap kiblat karena Allah Ta'ala"
      },
      {
        "index": "3",
        "niat": "Niat Sholat Ashar",
        "arabic": "\u0627\u064F\u0635\u064E\u0644\u0651\u0650\u0649 \u0641\u064E\u0631\u0652\u0636\u064E \u0627\u0644\u0652\u0639\u064E\u0635\u0652\u0631\u0650\u0627\u064E\u0631\u0652\u0628\u064E\u0639\u064E \u0631\u064E\u0643\u064E\u0639\u064E\u0627\u062A\u064D \u0645\u064F\u0633\u0652\u062A\u064E\u0642\u0652\u0628\u0650\u0644\u064E \u0627\u0644\u0652\u0642\u0650\u0628\u0652\u0644\u064E\u0629\u0650 \u0627\u064E\u062F\u064E\u0627\u0621\u064B \u0650\u0644\u0644\u0647\u0650 \u062A\u064E\u0639\u064E\u0627\u0644\u064E\u0649",
        "latin": "Ushalli fardhol 'ashri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        "translation_id": "Aku berniat shalat fardhu 'Ashar empat raka'at menghadap kiblat karena Allah Ta'ala"
      },
      {
        "index": "4",
        "niat": "Niat Sholat Maghrib",
        "arabic": "\u0627\u064F\u0635\u064E\u0644\u0651\u0650\u0649 \u0641\u064E\u0631\u0652\u0636\u064E \u0627\u0644\u0652\u0645\u064E\u063A\u0652\u0631\u0650\u0628\u0650 \u062B\u064E\u0644\u0627\u064E\u062B\u064E \u0631\u064E\u0643\u064E\u0639\u064E\u0627\u062A\u064D \u0645\u064F\u0633\u0652\u062A\u064E\u0642\u0652\u0628\u0650\u0644\u064E \u0627\u0644\u0652\u0642\u0650\u0628\u0652\u0644\u064E\u0629\u0650 \u0627\u064E\u062F\u064E\u0627\u0621\u064B \u0650\u0644\u0644\u0647\u0650 \u062A\u064E\u0639\u064E\u0627\u0644\u064E\u0649",
        "latin": "Ushalli fardhol maghribi tsalaata raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        "translation_id": "Aku berniat shalat fardhu Maghrib tiga raka'at menghadap kiblat karena Allah Ta'ala"
      },
      {
        "index": "5",
        "niat": "Niat Sholat Isya",
        "arabic": "\u0627\u064F\u0635\u064E\u0644\u0651\u0650\u0649 \u0641\u064E\u0631\u0652\u0636\u064E \u0627\u0644\u0652\u0639\u0650\u0634\u064E\u0627\u0621\u0650 \u0627\u064E\u0631\u0652\u0628\u064E\u0639\u064E \u0631\u064E\u0643\u064E\u0639\u064E\u0627\u062A\u064D \u0645\u064F\u0633\u0652\u062A\u064E\u0642\u0652\u0628\u0650\u0644\u064E \u0627\u0644\u0652\u0642\u0650\u0628\u0652\u0644\u064E\u0629\u0650 \u0627\u064E\u062F\u064E\u0627\u0621\u064B \u0650\u0644\u0644\u0647\u0650 \u062A\u064E\u0639\u064E\u0627\u0644\u064E\u0649",
        "latin": "Ushalli fardhol 'isyaa-i arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        "translation_id": "Aku berniat shalat fardhu Isya empat raka'at menghadap kiblat karena Allah Ta'ala"
      }
    ]
  }
};

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "islami" }
)
