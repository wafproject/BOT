/**
 * game/sambungkata.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/game/susunkata",
  "command": [
    "sambungkata"
  ],
  "kind": "game",
  "title": "Sambung Kata",
  "category": "game"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
