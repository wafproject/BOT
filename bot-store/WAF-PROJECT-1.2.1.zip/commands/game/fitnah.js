/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - fitnah.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_fitnah_exports = {};
__export(game_fitnah_exports, {
  default: () => game_fitnah_default
});
module.exports = __toCommonJS(game_fitnah_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
const { proto } = __zapo_1;
let handler = async (m, { jagoanproject, text, participants }) => {
  if (!jagoanproject) {
    return m.reply("\u274C Bot tidak terhubung, silakan hubungi admin.");
  }
  if (!m.isGroup) {
    return m.reply("\u274C Fitur ini hanya bisa digunakan di dalam grup!");
  }
  if (!text) {
    return m.reply("\u274C Format salah! Contoh: .fitnah @tag text1|text2");
  }
  let who = m.mentionedJid && m.mentionedJid[0];
  if (!who) {
    return m.reply("\u26A0\uFE0F Tag salah satu pengguna!");
  }
  let [fake, real] = text.split("|");
  if (!fake || !real) {
    return m.reply("\u26A0\uFE0F Format salah! Gunakan: .fitnah @tag text1|text2");
  }
  fake = fake.replace(`@${who.split("@")[0]}`, "").trim();
  real = real.trim();
  const detectMentions = (text2) => {
    const mentions = [];
    const regex = /@(\d+)/g;
    let match;
    while ((match = regex.exec(text2)) !== null) {
      const number = match[1];
      const jid = participants.find((p) => p.id.includes(number))?.id;
      if (jid && !mentions.includes(jid)) {
        mentions.push(jid);
      }
    }
    return mentions;
  };
  let fakeMentions = detectMentions(fake);
  let realMentions = detectMentions(real);
  if (!fakeMentions.includes(who)) {
    fakeMentions.push(who);
  }
  if (!realMentions.includes(who)) {
    realMentions.push(who);
  }
  let fakeMessage = {
    key: {
      fromMe: false,
      participant: who,
      ...m.isGroup ? { remoteJid: m.chat } : { remoteJid: who }
    },
    message: {
      conversation: fake,
      extendedTextMessage: {
        text: fake,
        contextInfo: {
          mentionedJid: fakeMentions
          // Mention di pesan fake, termasuk pengguna utama
        }
      }
    }
  };
  try {
    await jagoanproject.sendMessage(m.chat, {
      text: real,
      mentions: realMentions
      // Mention semua pengguna yang terdeteksi, termasuk utama
    }, { quoted: fakeMessage });
    await jagoanproject.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.key.id,
        participant: m.key.participant || m.key.remoteJid
      }
    });
  } catch (error) {
    console.error("Gagal memproses perintah:", error);
    return m.reply("\u274C Gagal memproses perintah, coba lagi nanti.");
  }
};
handler.help = ["fitnah"].map((a) => a + " *@tag text1|text2*");
handler.tags = ["game"];
handler.command = ["fitnah"];
handler.group = true;
handler.register = true;
handler.limit = false;
var game_fitnah_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
