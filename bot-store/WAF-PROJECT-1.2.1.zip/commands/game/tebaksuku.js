/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - tebaksuku.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_tebaksuku_exports = {};
__export(game_tebaksuku_exports, {
  default: () => game_tebaksuku_default
});
module.exports = __toCommonJS(game_tebaksuku_exports);
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  jagoanproject.tebaksuku = jagoanproject.tebaksuku || {};
  let id = m.chat;
  if (["gatau", "surrender", "menyerah", "nyerah"].includes(command)) {
    if (!(id in jagoanproject.tebaksuku)) return; // WAF: .nyerah dipakai beberapa game, diam kalau bukan game ini
    let [_, soal2] = jagoanproject.tebaksuku[id];
    jagoanproject.reply(m.chat, `*\u{1F3F3}\uFE0F Kamu Menyerah!*
Jawaban yang benar adalah: *${soal2.answer}*
Coba lagi nanti ya.`, m);
    clearTimeout(jagoanproject.tebaksuku[id][3]);
    delete jagoanproject.tebaksuku[id];
    return;
  }
  if (id in jagoanproject.tebaksuku) return jagoanproject.reply(m.chat, "\u26A0\uFE0F Soal sebelumnya belum terjawab!", jagoanproject.tebaksuku[id][0]);
  let soal = pickRandom(soalSuku);
  jagoanproject.tebaksuku[id] = [
    await jagoanproject.reply(m.chat, `*\u250C\u3014 \u{1F30F} Tebak Suku Nasional \u3015\u2510*
\u251C \u{1F4CD} *Pertanyaan:* _${soal.question}_
\u251C \u23F1\uFE0F *Waktu:* 90 detik
\u251C \u{1F381} *Hadiah:* +1500 Money & +500 Exp
\u251C \u26A0\uFE0F Jawab langsung tanpa reply!
\u2514 \u{1F3F3}\uFE0F Menyerah? ketik *.gatau* / *.nyerah*`, m),
    soal,
    4,
    setTimeout(() => {
      if (jagoanproject.tebaksuku[id]) jagoanproject.reply(m.chat, `*\u23F0 Waktu Habis!*
Waktumu sudah habis!
Jawaban yang benar adalah: *${soal.answer}*`, jagoanproject.tebaksuku[id][0]);
      delete jagoanproject.tebaksuku[id];
    }, 9e4)
    // 90 detik
  ];
};
handler.help = ["tebaksuku", "gatau"];
handler.tags = ["game"];
handler.command = /^(tebaksuku|gatau|surrender|menyerah|nyerah)$/i;
handler.group = true;
handler.register = true;
handler.limit = false;
var game_tebaksuku_default = handler;
let before = async (m, { jagoanproject }) => {
  jagoanproject.tebaksuku = jagoanproject.tebaksuku || {};
  let id = m.chat;
  if (!(id in jagoanproject.tebaksuku)) return;
  let [msg, soal] = jagoanproject.tebaksuku[id];
  if (!m.text || m.fromMe) return;
  if (/^[.!#/]/.test(m.text.trim())) return;
  if (m.text.toLowerCase().trim() === soal.answer.toLowerCase().trim()) {
    global.db.data.users[m.sender].money += 1500;
    global.db.data.users[m.sender].exp += 500;
    jagoanproject.reply(m.chat, `*\u2705 Jawaban kamu benar!*
\u{1F389} Kamu mendapatkan:
\u2022 \u{1F4B0} *+1500 Money*
\u2022 \u2728 *+500 Exp*`, m);
    clearTimeout(jagoanproject.tebaksuku[id][3]);
    delete jagoanproject.tebaksuku[id];
  } else {
    jagoanproject.reply(m.chat, "\u274C Salah! Coba lagi sampai benar sebelum waktu habis.", m);
  }
};
handler.before = before;
const soalSuku = [
  { question: "Suku asli dari daerah Papua, dikenal sebagai pemburu dan peramu handal.", answer: "Asmat" },
  { question: "Suku di Kalimantan Tengah yang terkenal dengan seni ukir dan rumah betang.", answer: "Dayak" },
  { question: "Suku dari pulau Sumatra yang memiliki adat merantau dan bahasa khas.", answer: "Minang" },
  { question: "Suku dari Pulau Bali yang terkenal dengan upacara Ngaben.", answer: "Bali" },
  { question: "Suku di Sulawesi Selatan yang dikenal sebagai pelaut ulung.", answer: "Bugis" },
  { question: "Suku yang berasal dari daerah Tapanuli, Sumatra Utara.", answer: "Batak" },
  { question: "Suku yang tinggal di daerah ujung timur Indonesia.", answer: "Papua" },
  { question: "Suku yang terkenal dengan tarian Cakalele dari Maluku.", answer: "Ambon" },
  { question: "Suku dari daerah Madura, dikenal dengan karapan sapinya.", answer: "Madura" },
  { question: "Suku mayoritas di Jawa Tengah dan Jawa Timur.", answer: "Jawa" },
  { question: "Suku yang menggunakan bahasa Sunda.", answer: "Sunda" },
  { question: "Suku dari Thailand yang dikenal sebagai penggembala dan tinggal di pegunungan.", answer: "Karen" },
  { question: "Suku tradisional dari Jepang.", answer: "Ainu" },
  { question: "Suku nomaden di Mongolia.", answer: "Mongol" },
  { question: "Suku asli dari Amerika Utara, dikenal dengan tipi dan bulu hias.", answer: "Apache" },
  { question: "Suku asli dari Amerika Selatan yang membangun kota Machu Picchu.", answer: "Inca" },
  { question: "Suku asli Australia.", answer: "Aborigin" },
  { question: "Suku asli dari Afrika Tengah yang tinggal di hutan-hutan hujan tropis.", answer: "Pigmi" },
  { question: "Suku di Afrika Selatan yang terkenal karena tarian perang dan sejarah Zulu.", answer: "Zulu" },
  { question: "Suku di Tibet yang hidup di daerah pegunungan tinggi.", answer: "Sherpa" },
  { question: "Suku pedalaman dari Kalimantan Timur.", answer: "Kutai" },
  { question: "Suku yang berasal dari daerah Sulawesi Tengah.", answer: "Kaili" },
  { question: "Suku yang tinggal di sekitar Danau Toba.", answer: "Batak Toba" },
  { question: "Suku yang dikenal dengan rumah panggung dan kain tenun di Nusa Tenggara Timur.", answer: "Savu" },
  { question: "Suku di pesisir barat Sumatra yang memiliki budaya Minangkabau.", answer: "Padang" },
  { question: "Suku terkenal dari Filipina yang tinggal di pegunungan Luzon.", answer: "Igorot" },
  { question: "Suku di Kalimantan Barat yang punya tradisi naik rumah betang.", answer: "Iban" },
  { question: "Suku dari Nigeria yang merupakan kelompok etnis terbesar di sana.", answer: "Hausa" },
  { question: "Suku dari Ethiopia dengan tradisi mewarnai tubuh dan wajah.", answer: "Mursi" },
  { question: "Suku dari Sudan Selatan yang dikenal dengan tinggi badannya.", answer: "Dinka" },
  { question: "Suku di Nusa Tenggara Barat yang tinggal di Lombok.", answer: "Sasak" },
  { question: "Suku dari Kepulauan Mentawai, Sumatra Barat.", answer: "Mentawai" },
  { question: "Suku dari Sulawesi Tenggara yang dikenal dengan rumah panggung.", answer: "Tolaki" },
  { question: "Suku dari Pulau Sumba, Nusa Tenggara Timur.", answer: "Sumba" },
  { question: "Suku di Kalimantan yang sering disebut 'Orang Gunung'.", answer: "Punan" },
  { question: "Suku dari Kepulauan Riau yang hidup di laut.", answer: "Orang Laut" },
  { question: "Suku dari Sumatra Selatan yang terkenal dengan kain songket.", answer: "Palembang" },
  { question: "Suku dari Iran kuno yang menyembah api.", answer: "Zoroaster" },
  { question: "Suku dari Israel kuno.", answer: "Yahudi" },
  { question: "Suku yang berasal dari Papua dengan tradisi bakar batu?", answer: "Dani" },
  { question: "Suku terkenal di Sumatera Utara yang menganut adat patrilineal?", answer: "Batak" },
  { question: "Suku dari Jepang yang dikenal memiliki budaya unik dan berbeda dari mayoritas Jepang?", answer: "Ainu" },
  { question: "Suku Dayak terkenal berasal dari pulau?", answer: "Kalimantan" },
  { question: "Suku yang terkenal di Sulawesi Selatan dan ahli dalam pelayaran?", answer: "Bugis" }
];
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
