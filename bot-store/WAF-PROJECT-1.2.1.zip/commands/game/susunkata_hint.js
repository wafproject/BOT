/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - susunkata_hint.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_susunkata_hint_exports = {};
__export(game_susunkata_hint_exports, {
  default: () => game_susunkata_hint_default
});
module.exports = __toCommonJS(game_susunkata_hint_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.susun = jagoanproject.susun ? jagoanproject.susun : {};
  let id = m.chat;
  if (!(id in jagoanproject.susun)) {
    return m.reply("\u274C Tidak ada soal susun kata yang sedang berjalan!");
  }
  let jawaban = jagoanproject.susun[id][1];
  if (!jawaban) {
    return m.reply("\u274C Soal tidak ditemukan atau sudah kadaluarsa.");
  }
  let clue = jawaban.replace(/[aiueoAIUEO]/g, "_");
  m.reply(`\u{1F4A1} *Petunjuk Susun Kata* \u{1F4A1}

${clue}`);
};
handler.command = /^susn$/i;
handler.limit = false;
handler.fail = null;
var game_susunkata_hint_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
