/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - tebakpemainbola.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_tebakpemainbola_exports = {};
__export(game_tebakpemainbola_exports, {
  default: () => game_tebakpemainbola_default
});
module.exports = __toCommonJS(game_tebakpemainbola_exports);
var import_similarity = __toESM(require("similarity"));
let timeout = 12e4;
const MIN_SIMILARITY_CLUE = 0.6;
const MAX_SIMILARITY_TEASE = 0.98;
function normalizeAnswer(s) {
  return (s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function calcSpeedReward(elapsedMs) {
  const maxMs = timeout;
  const t = Math.max(0, Math.min(1, elapsedMs / maxMs));
  const speed = 1 - t;
  const r = Math.random();
  const bias = (r + speed) / 2;
  const money = Math.floor(3e3 + bias * (1e3 - 3e3));
  const limit = Math.floor(2 + bias * (5 - 2));
  const xp = Math.floor(3500 + bias * (6500 - 3500));
  return { money, limit, xp };
}
let handler = async (m, { jagoanproject }) => {
  jagoanproject.tebakbola = jagoanproject.tebakbola ? jagoanproject.tebakbola : {};
  let id = m.chat;
  if (id in jagoanproject.tebakbola) {
    jagoanproject.reply(
      m.chat,
      "Masih ada soal belum terjawab di chat ini\nKetik *nyerah* untuk menyerah.",
      jagoanproject.tebakbola[id].reply
    );
    throw false;
  }
  let list = await tebakbolaFromWeb(12);
  if (!list.length) throw "Gagal ambil data pemain. Coba lagi.";
  let pick = list[Math.floor(Math.random() * list.length)];
  let answer = normalizeAnswer(pick.title);
  let caption = `
\u26BD *TEBAK PEMAIN BOLA* \u26BD

\u23F3 *Waktu:* ${Math.floor(timeout / 1e3)} detik
\u2753 *Pertanyaan:* Siapakah pemain sepakbola ini?

\u{1F9E9} *Clue:* ${pick.title.replace(/[AIUEOaiueo]/g, "_")}

\u270D\uFE0F *Cara jawab:* ketik nama pemainnya
\u{1F4CC} *Contoh:* _lionel messi_
> Makin cepat menjawab, hadiah semakin besar..!!

\u{1F3F3}\uFE0F *Menyerah?:* ketik *nyerah*
`.trim();
  let q = await jagoanproject.sendMessage(
    m.chat,
    { image: { url: pick.img }, caption },
    { quoted: m }
  );
  jagoanproject.tebakbola[id] = {
    reply: q,
    img: pick.img,
    title: pick.title,
    answer,
    start: Date.now(),
    tries: 0,
    timer: null
  };
};
handler.before = async (m, { jagoanproject }) => {
  jagoanproject.tebakbola = jagoanproject.tebakbola ? jagoanproject.tebakbola : {};
  let id = m.chat;
  if (!jagoanproject.tebakbola[id]) return;
  let data = jagoanproject.tebakbola[id];
  if (!data.timer) {
    data.timer = setTimeout(() => {
      if (jagoanproject.tebakbola[id]) {
        jagoanproject.reply(
          m.chat,
          `\u23F0 *WAKTU HABIS!*

\u{1F635} Kamu belum sempat jawab...
\u2705 *Jawaban:* *${data.title}*
\u{1F4DD} *Ketik:* ${data.answer}

\u{1F3AE} Ketik *.tebakbola* untuk main lagi!`,
          jagoanproject.tebakbola[id].reply
        );
        delete jagoanproject.tebakbola[id];
      }
    }, timeout);
  }
  if (!m.text) return;
  const userTextRaw = m.text || "";
  const userText = normalizeAnswer(userTextRaw);
  if (userText === "nyerah" || userText === "surrender") {
    clearTimeout(data.timer);
    jagoanproject.reply(
      m.chat,
      `\u{1F614} Kamu menyerah.
\u2705 Jawaban: *${data.title}*
*\u2022 Ketik :* ${data.answer}`,
      data.reply
    );
    delete jagoanproject.tebakbola[id];
    return;
  }
  if (userText === data.answer) {
    const elapsed = Date.now() - data.start;
    const reward = calcSpeedReward(elapsed);
    try {
      let user = global.db.data.users[m.sender];
      user.money = (user.money || 0) + reward.money;
      user.limit = (user.limit || 0) + reward.limit;
      user.exp = (user.exp || 0) + reward.xp;
    } catch (e) {
    }
    clearTimeout(data.timer);
    delete jagoanproject.tebakbola[id];
    return jagoanproject.reply(
      m.chat,
      `\u{1F389} *BENAR! JAWABAN KAMU TEPAT!* \u2705

\u2705 *Jawaban:* *${data.title}*

\u{1F4B0} *Uang:* +${reward.money.toLocaleString("id-ID")}
\u{1F3AB} *Limit:* +${reward.limit}
\u2728 *XP:* +${reward.xp}`,
      m
    );
  }
  data.tries = (data.tries || 0) + 1;
  let sim = (0, import_similarity.default)(userText, data.answer);
  let persen = Math.floor(sim * 100);
  if (sim >= MAX_SIMILARITY_TEASE) {
    return jagoanproject.reply(
      m.chat,
      `\u274C Salah!
\u{1F633} *Dikiiiit lagi!* (Clue: *${persen}%* mendekati \u2705)
Coba lagi ya!`,
      m
    );
  }
  if (sim >= MIN_SIMILARITY_CLUE) {
    return jagoanproject.reply(
      m.chat,
      `\u274C Salah!
\u{1F4CC} Clue: *${persen}%* mendekati jawaban \u2705
Coba lagi ya!`,
      m
    );
  }
  const hint = data.title.replace(/[AIUEOaiueo]/g, "_");
  return jagoanproject.reply(m.chat, `\u274C Salah!
\u{1F4A1} Hint: ${hint}
Coba lagi \u{1F604}`, m);
};
handler.help = ["tebakpemainbola"];
handler.tags = ["game"];
handler.command = /^tebakpemainbola|tebakbola|tebaksepakbola/i;
handler.group = false;
handler.register = true;
handler.limit = false;
var game_tebakpemainbola_default = handler;
async function tebakbolaFromWeb(number = 12) {
  const url = `https://www.generatormix.com/random-football-players?number=${Math.min(
    12,
    Math.max(1, number)
  )}`;
  let res = await fetch(url, {
    method: "GET",
    headers: {
      "user-agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36",
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    }
  });
  if (!res.ok) return [];
  let html = await res.text();
  let outputMatch = html.match(
    /<div id="output">([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>\s*<\/form>/i
  );
  let output = outputMatch ? outputMatch[1] : html;
  let items = [];
  let re = /data-src="([^"]+)"[^>]*alt="([^"]+)"[\s\S]*?<h3[^>]*>([^<]+)<\/h3>/gi;
  let m;
  while ((m = re.exec(output)) !== null) {
    let img = m[1];
    let title = (m[3] || m[2] || "").trim();
    if (img && title) items.push({ img, title });
  }
  if (!items.length) {
    let imgRe = /data-src="(https:\/\/cdn-0\.generatormix\.com\/images\/football-players\/[^"]+)"/gi;
    let imgs = [];
    while ((m = imgRe.exec(output)) !== null) imgs.push(m[1]);
    items = imgs.map((img) => ({
      img,
      title: filenameToName(img)
    }));
  }
  let seen = /* @__PURE__ */ new Set();
  items = items.filter((x) => {
    let key = x.img + "|" + x.title;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  return items;
}
function filenameToName(imgUrl) {
  try {
    let file = imgUrl.split("/").pop() || "";
    file = file.replace(/\.(jpg|jpeg|png|webp)$/i, "");
    file = decodeURIComponent(file);
    return file.split("-").filter(Boolean).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  } catch {
    return "Unknown";
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
