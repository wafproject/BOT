/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - truthdare.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_truthdare_exports = {};
__export(game_truthdare_exports, {
  default: () => game_truthdare_default
});
module.exports = __toCommonJS(game_truthdare_exports);
const DARE_URL = "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/master/src/game/dare.json";
const TRUTH_URL = "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/master/src/game/truth.json";
const DARE_THUMB_URL = "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/master/src/darethumb.jpg";
const TRUTH_THUMB_URL = "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/master/src/truththumb.jpg";
const SOURCE_URL = "";
const cache = { dare: { data: null, ts: 0 }, truth: { data: null, ts: 0 } };
const CACHE_TTL_MS = 5 * 60 * 1e3;
async function getList(kind) {
  const now = Date.now();
  const bucket = cache[kind];
  const url = kind === "dare" ? DARE_URL : TRUTH_URL;
  if (bucket.data && now - bucket.ts < CACHE_TTL_MS) return bucket.data;
  const res = await fetch(url, { headers: { "User-Agent": "truthdare-bot" } });
  if (!res.ok) throw new Error(`Gagal ambil ${kind}: HTTP ${res.status}`);
  const json = await res.json();
  if (!Array.isArray(json) || json.length === 0) throw new Error(`${kind} kosong/format salah`);
  bucket.data = json;
  bucket.ts = now;
  return json;
}
const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
let handler = async function(m, { jagoanproject, command }) {
  try {
    const isDare = command === "dare";
    const kind = isDare ? "dare" : "truth";
    const title = isDare ? "\u{1F3AF} Aku Menantangmu" : "\u{1F9E0} Jawab Jujur Yaaa";
    const body = namebot;
    const thumbUrl = isDare ? DARE_THUMB_URL : TRUTH_THUMB_URL;
    const list = await getList(kind);
    const text = pickRandom(list);
    await jagoanproject.relayMessage(
      m.chat,
      {
        extendedTextMessage: {
          text,
          contextInfo: {
            extendedPreview: {
              title,
              body,
              mediaType: 1,
              // 1 = image
              previewType: 0,
              // biar keluar sebagai large card
              renderLargerThumbnail: true,
              // kunci preview besar
              thumbnailUrl: thumbUrl,
              // pakai URL (cukup, nggak wajib buffer)
              sourceUrl: SOURCE_URL
              // klik menuju repo sumber
              // showAdAttribution: false,   // opsional
            }
          },
          mentions: [m.sender]
        }
      },
      {}
    );
  } catch (e) {
    await jagoanproject.reply(m.chat, `\u{1F615} Terjadi error: ${e.message}`, m);
  }
};
handler.command = handler.help = ["dare", "truth"];
handler.tags = ["fun", "game"];
handler.limit = false;
handler.register = true;
var game_truthdare_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
