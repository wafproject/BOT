/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - ulartangga.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_ulartangga_exports = {};
__export(game_ulartangga_exports, {
  default: () => game_ulartangga_default
});
module.exports = __toCommonJS(game_ulartangga_exports);
var import_jimp = __toESM(require("jimp"));
var import_ulartangga = require("../../lib/jagoan/lib/ulartangga.js");
const TURN_TIMEOUT = 5 * 60 * 1e3;
const VOTE_TIMEOUT = 2 * 60 * 1e3;
const VOTE_KICK_IMAGE = "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/ULARR.jpg";
const LOVE_EMOJIS = ["\u2764", "\u2764\uFE0F", "\u2665", "\u2665\uFE0F", "\u{1F496}", "\u{1F498}", "\u{1F495}", "\u{1F497}", "\u{1F493}", "\u{1F49E}"];
const resize = async (image, width, height) => {
  const read = await import_jimp.default.read(image);
  const data2 = await read.resize(width, height).getBufferAsync(import_jimp.default.MIME_JPEG);
  return data2;
};
const getRandom = function(array) {
  return array[Math.floor(Math.random() * array.length)];
};
const getMention = (jid = "") => `@${jid.replace("@s.whatsapp.net", "")}`;
const getAllPlayerIds = (room) => room.player.map((p) => p.id);
const getVoteEligiblePlayers = (room, target) => room.player.map((p) => p.id).filter((id) => id !== target);
const getVoteThreshold = (room, target) => {
  const eligible = getVoteEligiblePlayers(room, target).length;
  return Math.max(1, Math.ceil(eligible * 0.5));
};
function clearTurnTimer(room) {
  if (room?.turnTimeout) {
    clearTimeout(room.turnTimeout);
    room.turnTimeout = null;
  }
}
function clearVoteKick(room) {
  if (room?.voteKick?.timeout) clearTimeout(room.voteKick.timeout);
  room.voteKick = null;
}
function cleanupRoom(ut, chat) {
  const room = ut?.[chat];
  if (!room) return;
  clearTurnTimer(room);
  clearVoteKick(room);
  delete ut[chat];
}
async function announceNextTurn(jagoanproject, chat, room, quoted = null) {
  if (!room?.player?.length) return;
  const currentPlayer = room.player[room.turn];
  await jagoanproject.sendMessage(chat, {
    text: `\u23F3 Sekarang giliran ${getMention(currentPlayer.id)}.
Ketik *.ut kocok* dalam 5 menit, kalau tidak akan muncul vote kick AFK.`,
    mentions: [currentPlayer.id]
  }, quoted ? { quoted } : {});
}
async function handlePlayerKickFromGame(jagoanproject, chat, ut, target, reason, quoted = null) {
  const room = ut[chat];
  if (!room) return;
  const index = room.player.findIndex((p) => p.id === target);
  if (index < 0) return;
  clearTurnTimer(room);
  clearVoteKick(room);
  const removed = room.player.splice(index, 1)[0];
  if (room.owner === target && room.player.length) {
    room.owner = room.player[0].id;
  }
  if (room.player.length === 0) {
    await jagoanproject.sendMessage(chat, {
      text: `\u{1F6AB} ${getMention(target)} dikeluarkan dari game (${reason}).
Tidak ada pemain tersisa, game dibubarkan.`,
      mentions: [target]
    }, quoted ? { quoted } : {});
    cleanupRoom(ut, chat);
    return;
  }
  if (room.player.length === 1) {
    const winner = room.player[0];
    await jagoanproject.sendMessage(chat, {
      text: `\u{1F6AB} ${getMention(target)} dikeluarkan dari game (${reason}).
\u{1F3C6} ${getMention(winner.id)} menang otomatis karena tinggal satu pemain.`,
      mentions: [target, winner.id]
    }, quoted ? { quoted } : {});
    cleanupRoom(ut, chat);
    return;
  }
  if (index >= room.player.length) room.turn = 0;
  else room.turn = index;
  const user1 = room.player[0] ? room.player[0].langkah : null;
  const user2 = room.player[1] ? room.player[1].langkah : null;
  const user3 = room.player[2] ? room.player[2].langkah : null;
  const user4 = room.player[3] ? room.player[3].langkah : null;
  const imageBuffer = await (0, import_ulartangga.drawBoard)(
    room.map,
    user1,
    user2,
    user3,
    user4,
    room.stabil_x,
    room.stabil_y
  );
  const nextPlayer = room.player[room.turn];
  await jagoanproject.sendMessage(chat, {
    image: imageBuffer,
    caption: `\u{1F6AB} ${getMention(removed.id)} dikeluarkan dari game (${reason}).

Giliran dilanjutkan ke ${getMention(nextPlayer.id)}.`,
    mentions: [removed.id, nextPlayer.id]
  }, quoted ? { quoted } : {});
  startTurnTimer(jagoanproject, chat, ut);
}
async function startAfkVote(jagoanproject, chat, ut) {
  const room = ut[chat];
  if (!room || !room.status || room.player.length < 2) return;
  if (room.voteKick) return;
  clearTurnTimer(room);
  const currentPlayer = room.player[room.turn];
  if (!currentPlayer) return;
  const eligibleVoters = getVoteEligiblePlayers(room, currentPlayer.id);
  const minVote = getVoteThreshold(room, currentPlayer.id);
  const mentions = getAllPlayerIds(room);
  const voteMsg = await jagoanproject.sendMessage(chat, {
    image: { url: VOTE_KICK_IMAGE },
    caption: `\u23F0 ${getMention(currentPlayer.id)} tidak kocok dadu selama 5 menit.

Semua pemain, react pesan ini dengan \u2764\uFE0F untuk *vote kick* dari game.
Minimal *${minVote}* vote dari *${eligibleVoters.length}* pemain lain (50%).

Vote ditutup dalam 2 menit.`,
    mentions
  });
  room.voteKick = {
    target: currentPlayer.id,
    messageId: voteMsg.key.id,
    voters: [],
    eligibleVoters,
    minVote,
    timeout: setTimeout(async () => {
      const activeRoom = ut[chat];
      if (!activeRoom?.voteKick || activeRoom.voteKick.messageId !== voteMsg.key.id) return;
      const totalVote = activeRoom.voteKick.voters.length;
      clearVoteKick(activeRoom);
      await jagoanproject.sendMessage(chat, {
        text: `\u{1F4CA} Vote kick untuk ${getMention(currentPlayer.id)} ditutup.
Hasil: *${totalVote}/${minVote}* vote setuju.
Karena belum mencapai 50%, pemain tetap di game dan timer giliran direset 5 menit.`,
        mentions: [currentPlayer.id]
      });
      startTurnTimer(jagoanproject, chat, ut);
    }, VOTE_TIMEOUT)
  };
}
function startTurnTimer(jagoanproject, chat, ut) {
  const room = ut[chat];
  if (!room || !room.status || room.player.length < 2) return;
  clearTurnTimer(room);
  room.turnTimeout = setTimeout(async () => {
    const activeRoom = ut[chat];
    if (!activeRoom || !activeRoom.status || activeRoom.player.length < 2) return;
    await startAfkVote(jagoanproject, chat, ut);
  }, TURN_TIMEOUT);
}
let data = [
  {
    map: "https://telegra.ph/file/46a0c38104f79cdbfe83f.jpg",
    XavierMarket: {
      2: 38,
      7: 14,
      8: 31,
      15: 26,
      21: 42,
      28: 84,
      36: 44,
      51: 67,
      78: 98,
      71: 91,
      87: 94,
      16: 6,
      46: 25,
      49: 11,
      62: 19,
      64: 60,
      74: 53,
      89: 68,
      92: 88,
      95: 75,
      99: 80
    },
    name: "Classic",
    stabil_x: 20,
    stabil_y: 20
  },
  {
    map: "https://telegra.ph/file/46a0c38104f79cdbfe83f.jpg",
    XavierMarket: {
      2: 38,
      7: 14,
      8: 31,
      15: 26,
      21: 42,
      28: 84,
      36: 44,
      51: 67,
      78: 98,
      71: 91,
      87: 94,
      16: 6,
      46: 25,
      49: 11,
      62: 19,
      64: 60,
      74: 53,
      89: 68,
      92: 88,
      95: 75,
      99: 80
    },
    name: "Classic 2",
    stabil_x: 20,
    stabil_y: 20
  }
];
let thumb = VOTE_KICK_IMAGE;
let handler = async function(m, { jagoanproject, usedPrefix, command, args }) {
  if (typeof m.react !== "function") {
    m.react = (emoji, key = m.key || m?.m?.key) => jagoanproject.sendMessage(m.chat, { react: { text: emoji, key } });
  }
  try {
    if (!global.Data) global.Data = {};
    if (!Data.ulartangga) Data.ulartangga = {};
    const chat = m.chat;
    const sender = m.sender;
    const ut = Data.ulartangga;
    const value = args[0];
    if (command === "ulartangga" || command === "ut") {
      if (value === "create") {
        if (chat in ut) return m.reply("Group masih dalam sesi permainan");
        let anu = getRandom(data);
        ut[chat] = {
          room: chat,
          owner: sender,
          status: false,
          date: Date.now(),
          turn: 0,
          player: [],
          map: anu.map,
          map_name: anu.name,
          ular_tangga: anu.XavierMarket,
          stabil_x: anu.stabil_x,
          stabil_y: anu.stabil_y,
          turnTimeout: null,
          voteKick: null
        };
        let data_player = {
          id: sender,
          number: ut[chat].player.length + 1,
          sesi: chat,
          status: false,
          langkah: 1,
          color: "Merah"
        };
        ut[chat].player.push(data_player);
        await m.reply("Room berhasil dibuat, ketik *.ut join* untuk bergabung");
      } else if (value === "join") {
        if (!ut[chat]) return m.reply("Belum ada sesi permainan");
        if (ut[chat].status === true) return m.reply("Sesi permainan sudah dimulai");
        if (ut[chat].player.length >= 4) return m.reply("Maaf jumlah player telah penuh");
        if (ut[chat].player.some((p) => p.id === sender)) return m.reply("Kamu sudah join dalam room ini");
        const colors = ["Merah", "Kuning", "Hijau", "Biru"];
        let data_player = {
          id: sender,
          number: ut[chat].player.length + 1,
          sesi: chat,
          status: false,
          langkah: 1,
          color: colors[ut[chat].player.length]
        };
        ut[chat].player.push(data_player);
        let player = [];
        let text = `
*\u2302 U L A R - T A N G G A*

`;
        for (let i = 0; i < ut[chat].player.length; i++) {
          text += `${ut[chat].player[i].color}: ${getMention(ut[chat].player[i].id)}
`;
          player.push(ut[chat].player[i].id);
        }
        text += "\nJumlah player minimal adalah 2 dan maximal 4";
        await jagoanproject.sendMessage(chat, {
          text: text.trim(),
          contextInfo: {
            extendedPreview: {
              title: "U L A R - T A N G G A",
              mediaType: 1,
              renderLargerThumbnail: true,
              thumbnail: await resize(thumb, 300, 175),
              sourceUrl: "",
              mediaUrl: thumb
            },
            mentionedJid: player
          }
        });
      } else if (value === "start") {
        if (!ut[chat]) return m.reply("Belum ada sesi permainan");
        if (ut[chat].player.length < 2) return m.reply("Maaf jumlah player belum memenuhi syarat");
        if (!ut[chat].player.some((p) => p.id === sender)) return m.reply("Kamu belum join dalam room ini");
        if (ut[chat].status === true) return m.reply("Sesi permainan telah dimulai");
        if (ut[chat].owner !== sender) return m.reply("Hanya host yang dapat memulai permainan");
        ut[chat].status = true;
        ut[chat].turn = 0;
        clearVoteKick(ut[chat]);
        clearTurnTimer(ut[chat]);
        let player = [];
        let text = `*\u2302 U L A R - T A N G G A*

`;
        for (let i = 0; i < ut[chat].player.length; i++) {
          text += `${ut[chat].player[i].color}: ${getMention(ut[chat].player[i].id)}
`;
          player.push(ut[chat].player[i].id);
        }
        text += `
Menunggu giliran pertama`;
        await jagoanproject.sendMessage(chat, {
          text: "*\u2302 U L A R - T A N G G A*\n\nGame dimulai! Ketik *.ut kocok* untuk jalan.",
          contextInfo: {
            extendedPreview: {
              title: "U L A R - T A N G G A",
              mediaType: 1,
              renderLargerThumbnail: true,
              thumbnail: await resize(thumb, 300, 175),
              sourceUrl: "",
              mediaUrl: thumb
            },
            mentionedJid: player
          }
        });
        await jagoanproject.sendMessage(chat, {
          image: await (0, import_ulartangga.drawBoard)(
            ut[chat].map,
            1,
            null,
            null,
            null,
            ut[chat].stabil_x,
            ut[chat].stabil_y
          ),
          caption: text,
          mentions: player
        });
        await announceNextTurn(jagoanproject, chat, ut[chat], m);
        startTurnTimer(jagoanproject, chat, ut);
      } else if (value === "kocok") {
        await kocokDadu(m, jagoanproject, chat, ut);
      } else if (value === "delete") {
        if (!ut[chat]) return m.reply("Tidak ada sesi permainan");
        if (ut[chat].owner !== sender) return m.reply("Hanya host yang dapat menghapus permainan");
        cleanupRoom(ut, chat);
        m.reply("Sesi permainan berhasil dihapus");
      } else {
        let text = `
*\u2302 U L A R - T A N G G A*

Command:
`;
        text += ` \u2022 ${usedPrefix}ut create
`;
        text += ` \u2022 ${usedPrefix}ut join
`;
        text += ` \u2022 ${usedPrefix}ut start
`;
        text += ` \u2022 ${usedPrefix}ut kocok
`;
        text += ` \u2022 ${usedPrefix}ut delete
`;
        text += ` \u2022 ${usedPrefix}ut player
`;
        await m.reply(text.trim());
      }
    }
  } catch (e) {
    m.reply("Error: " + e.message);
  }
};
async function kocokDadu(m, jagoanproject, chat, ut) {
  const sender = m.sender;
  if (!ut[chat]) return;
  const room = ut[chat];
  const currentPlayer = room.player[room.turn];
  if (!currentPlayer) return;
  if (currentPlayer.id !== sender) return m.reply("Bukan giliran kamu");
  clearTurnTimer(room);
  clearVoteKick(room);
  const dadu = Math.floor(Math.random() * 6 + 1);
  await jagoanproject.sendMessage(chat, {
    sticker: { url: `https://raw.githubusercontent.com/fgmods/fg-team/main/games/dados/${dadu}.webp` }
  }, { quoted: m });
  const langkahAwal = currentPlayer.langkah;
  currentPlayer.langkah += dadu;
  if (currentPlayer.langkah > 100) {
    currentPlayer.langkah = 100 - (currentPlayer.langkah - 100);
  }
  let XavierMarket = room.ular_tangga;
  let teks = "";
  if (Object.keys(XavierMarket).includes(currentPlayer.langkah.toString())) {
    teks = currentPlayer.langkah > XavierMarket[currentPlayer.langkah] ? "\n\u{1F40D} Kena ular!" : "\n\u{1FA9C} Naik tangga!";
    currentPlayer.langkah = XavierMarket[currentPlayer.langkah];
  }
  const user1 = room.player[0] ? room.player[0].langkah : null;
  const user2 = room.player[1] ? room.player[1].langkah : null;
  const user3 = room.player[2] ? room.player[2].langkah : null;
  const user4 = room.player[3] ? room.player[3].langkah : null;
  const imageBuffer = await (0, import_ulartangga.drawBoard)(
    room.map,
    user1,
    user2,
    user3,
    user4,
    room.stabil_x,
    room.stabil_y
  );
  if (currentPlayer.langkah === 100) {
    await jagoanproject.sendMessage(chat, {
      image: imageBuffer,
      caption: `\u{1F389} ${getMention(sender)} MENANG! \u{1F389}`,
      mentions: [sender]
    }, { quoted: m });
    cleanupRoom(ut, chat);
    return;
  }
  room.turn = (room.turn + 1) % room.player.length;
  const nextPlayer = room.player[room.turn];
  await jagoanproject.sendMessage(chat, {
    image: imageBuffer,
    caption: `${currentPlayer.color} *${langkahAwal}* \u2192 *${currentPlayer.langkah}*${teks}

Menunggu ${getMention(nextPlayer.id)} ketik *.ut kocok*`,
    mentions: [nextPlayer.id]
  }, { quoted: m });
  startTurnTimer(jagoanproject, chat, ut);
}
handler.before = async function(m, { jagoanproject }) {
  if (m.mtype !== "reactionMessage") return;
  if (!m.isGroup) return;
  if (!global.Data?.ulartangga?.[m.chat]) return;
  const room = global.Data.ulartangga[m.chat];
  if (!room?.voteKick) return;
  const emoji = m.msg?.text;
  const reactedToId = m.msg?.key?.id;
  if (!LOVE_EMOJIS.includes(emoji)) return;
  if (room.voteKick.messageId !== reactedToId) return;
  const voter = m.key.participant || m.key.remoteJid;
  if (!voter) return;
  if (voter === room.voteKick.target) return;
  if (!room.voteKick.eligibleVoters.includes(voter)) return;
  if (room.voteKick.voters.includes(voter)) {
    return jagoanproject.sendMessage(m.chat, {
      text: `\u26A0\uFE0F ${getMention(voter)} sudah vote untuk AFK kick ${getMention(room.voteKick.target)}.`,
      mentions: [voter, room.voteKick.target]
    });
  }
  room.voteKick.voters.push(voter);
  const totalVote = room.voteKick.voters.length;
  if (totalVote >= room.voteKick.minVote) {
    await jagoanproject.sendMessage(m.chat, {
      text: `\u2705 Vote kick berhasil: *${totalVote}/${room.voteKick.minVote}* vote setuju.
${getMention(room.voteKick.target)} dikeluarkan dari game dan giliran dilanjutkan.`,
      mentions: [room.voteKick.target]
    });
    await handlePlayerKickFromGame(jagoanproject, m.chat, global.Data.ulartangga, room.voteKick.target, "AFK 5 menit + vote 50%", m);
    return;
  }
  return jagoanproject.sendMessage(m.chat, {
    text: `\u2764\uFE0F Vote diterima dari ${getMention(voter)}.
Progress vote kick ${getMention(room.voteKick.target)}: *${totalVote}/${room.voteKick.minVote}*`,
    mentions: [voter, room.voteKick.target]
  });
};
handler.help = ["ulartangga", "ut"];
handler.tags = ["game"];
handler.command = /^(ulartangga|ut)$/i;
handler.register = true;
handler.limit = false;
var game_ulartangga_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
