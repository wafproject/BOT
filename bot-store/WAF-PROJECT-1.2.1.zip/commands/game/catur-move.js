/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - catur - move.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_catur_move_exports = {};
__export(game_catur_move_exports, {
  default: () => game_catur_move_default
});
module.exports = __toCommonJS(game_catur_move_exports);
var __chess_js_1 = __toESM(require("chess.js"));
var import_jimp_compat = __toESM(require("../../lib/jagoan/function/jimp-compat.js"));
const { Chess } = __chess_js_1;
let handler = async (m, { jagoanproject }) => {
  jagoanproject.catur = jagoanproject.catur || {};
  const ct = jagoanproject.catur;
  if (!ct[m.chat]) return;
  const moveRegex = /^([a-h][1-8])\s+([a-h][1-8])$/i;
  const match = m.text.match(moveRegex);
  if (!match) return;
  const [_, from, to] = match;
  if (m.quoted?.mtype !== "imageMessage" || m.quoted?.sender !== jagoanproject.user.jid) return;
  const game = ct[m.chat].chess;
  const player = ct[m.chat].players[m.sender];
  if (!player || game.turn() !== player.color[0]) {
    return m.reply(`\u23F3 Bukan giliranmu! Sekarang: ${game.turn() === "w" ? "Putih" : "Hitam"}`);
  }
  try {
    const move = game.move({ from, to, promotion: "q" });
    if (!move) return m.reply("\u274C Langkah tidak valid!");
    let moveText = `\u{1F4E2} *Langkah Dilakukan!*
${player.color === "white" ? "\u26AA" : "\u26AB"} @${m.sender.split("@")[0]}: ${from} \u2192 ${to}`;
    if (move.captured) {
      moveText += `
\u2694\uFE0F Menangkap ${move.captured.toUpperCase()}!`;
      ct[m.chat].captures[player.color].push(move.captured);
    }
    if (game.isCheck()) moveText += `
\u26A1 SKAK!`;
    await sendBoard(m, ct, jagoanproject);
    jagoanproject.sendMessage(m.chat, { text: moveText, mentions: [m.sender] });
    if (game.isGameOver()) {
      let endText = `\u{1F3AF} *Permainan Selesai!*

`;
      if (game.isCheckmate()) endText += `\u2B50 Skakmat! @${m.sender.split("@")[0]} Menang!
`;
      if (game.isDraw()) endText += `\u{1F91D} Seri!
`;
      delete ct[m.chat];
      return jagoanproject.sendMessage(m.chat, { text: endText, mentions: [m.sender] });
    }
    const nextPlayer = Object.keys(ct[m.chat].players).find((p) => ct[m.chat].players[p].color[0] === game.turn());
    jagoanproject.sendMessage(m.chat, { text: `\u23F3 Giliran: @${nextPlayer.split("@")[0]}`, mentions: [nextPlayer] });
  } catch (e) {
    console.error("\u274C ERROR move:", e);
    m.reply("\u274C Gerakan tidak valid!");
  }
};
handler.customPrefix = /^[a-h][1-8]\s+[a-h][1-8]$/i;
handler.command = [] /* WAF: cegah match-semua di compat lama */;
handler.tags = ["game"];
handler.register = true;
handler.limit = false;
var game_catur_move_default = handler;
async function sendBoard(m, ct, jagoanproject) {
  try {
    const fen = ct[m.chat].chess.fen().split(" ")[0];
    const boardUrl = `https://chessboardimage.com/${fen}.png?size=600&coordinates=true`;
    const img = await import_jimp_compat.default.read(boardUrl);
    const buffer = await img.getBufferAsync(import_jimp_compat.default.MIME_PNG);
    await jagoanproject.sendMessage(m.chat, {
      image: buffer,
      caption: `\u265F\uFE0F *Posisi Saat Ini*
\u{1F501} Balas gambar ini dengan langkahmu, contoh: e2 e4`,
      mentions: [jagoanproject.user.jid]
    });
  } catch (e) {
    console.error("Gagal ambil papan:", e);
    m.reply("\u274C Gagal menampilkan papan!");
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
