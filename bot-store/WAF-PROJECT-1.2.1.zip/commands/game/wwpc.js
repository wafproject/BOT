/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - wwpc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_wwpc_exports = {};
__export(game_wwpc_exports, {
  default: () => game_wwpc_default
});
module.exports = __toCommonJS(game_wwpc_exports);
var import_werewolf = __toESM(require("../../lib/jagoan/lib/werewolf.js"));
function ensureRoot() {
  if (!global.db) global.db = { data: {} };
  if (!global.db.data) global.db.data = {};
  if (!global.db.data.werewolf) global.db.data.werewolf = {};
  if (!global.db.data.werewolfDebug) global.db.data.werewolfDebug = [];
}
function ensureWWStore() {
  ensureRoot();
  return global.db.data.werewolf;
}
function safeJson(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}
function logWW(chat, event, meta = {}) {
  ensureRoot();
  const entry = {
    at: (/* @__PURE__ */ new Date()).toISOString(),
    chat,
    event,
    meta
  };
  global.db.data.werewolfDebug.push(entry);
  if (global.db.data.werewolfDebug.length > 300) {
    global.db.data.werewolfDebug.splice(0, global.db.data.werewolfDebug.length - 300);
  }
  const room = chat && global.db.data.werewolf && global.db.data.werewolf[chat];
  if (room) {
    room.debugLog = room.debugLog || [];
    room.debugLog.push(entry);
    if (room.debugLog.length > 100) room.debugLog.splice(0, room.debugLog.length - 100);
  }
  console.log(`[WW][${entry.at}][${chat || "-"}][${event}] ${safeJson(meta)}`);
}
function roleInfo(role) {
  const map = {
    werewolf: "Werewolf \u{1F43A}",
    seer: "Seer \u{1F473}",
    guardian: "Guardian \u{1F47C}",
    sorcerer: "Sorcerer \u{1F52E}",
    warga: "Warga \u{1F471}\u200D\u2642\uFE0F"
  };
  return map[role] || role || "-";
}
function help(prefix) {
  return `*WEREWOLF PRIVATE*

${prefix}wwpc role
${prefix}wwpc status
${prefix}wwpc kill 2
${prefix}wwpc dreamy 2
${prefix}wwpc deff 2
${prefix}wwpc sorcerer 2`;
}
let handler = async (m, { args, usedPrefix }) => {
  const db = ensureWWStore();
  const sub = (args[0] || "").toLowerCase();
  if (!import_werewolf.default.playerOnGame(m.sender, db)) throw "Kamu tidak sedang berada di game werewolf.";
  const me = import_werewolf.default.dataPlayer(m.sender, db);
  if (!me) throw "Data player werewolf tidak ditemukan.";
  const room = import_werewolf.default.sesi(me.sesi, db);
  if (!room) throw "Room werewolf tidak ditemukan.";
  if (!sub) {
    return m.reply(`${help(usedPrefix)}

Role kamu: *${roleInfo(me.role)}*
Status: *${me.isdead ? "mati" : "hidup"}*`);
  }
  if (sub === "role" || sub === "status") {
    return m.reply(`*STATUS WEREWOLF*

Role: *${roleInfo(me.role)}*
Status: *${me.isdead ? "mati" : "hidup"}*
Room: *${room.room}*
Hari: *${room.day}*
Fase: *${room.time}*
Aksi malam: *${me.status ? "sudah dipakai / belum tersedia" : "siap dipakai"}*`);
  }
  if (!room.status) throw "Game werewolf belum dimulai.";
  if (me.isdead) throw "Player yang sudah mati tidak bisa memakai skill.";
  if (room.time !== "malem") throw "Skill hanya bisa dipakai saat fase malam.";
  if (me.status) throw "Aksi malam kamu sudah dipakai, atau belum dibuka untuk fase ini.";
  const nomor = parseInt(args[1]);
  if (!nomor) throw `Contoh: *${usedPrefix}wwpc ${sub} 2*`;
  const target = import_werewolf.default.getPlayerById2(m.sender, nomor, db);
  if (!target) throw "Nomor player tidak valid.";
  if (target.db.isdead) throw "Target sudah mati.";
  switch (me.role) {
    case "werewolf": {
      if (sub !== "kill") throw `Role kamu *Werewolf*. Pakai: *${usedPrefix}wwpc kill <nomor>*`;
      const ok = import_werewolf.default.killWerewolf(m.sender, nomor, db);
      if (ok === false) throw "Gagal menyimpan target werewolf.";
      me.status = true;
      logWW(room.room, "night_action_kill", { by: m.sender, target: target.db.id, targetNumber: nomor });
      return m.reply(`Target makan malam diset ke player nomor *${nomor}*.`);
    }
    case "seer": {
      if (sub !== "dreamy") throw `Role kamu *Seer*. Pakai: *${usedPrefix}wwpc dreamy <nomor>*`;
      const role = import_werewolf.default.dreamySeer(m.sender, nomor, db);
      if (!role) throw "Gagal melihat role target.";
      me.status = true;
      logWW(room.room, "night_action_dreamy", { by: m.sender, target: target.db.id, targetNumber: nomor, seenRole: role });
      return m.reply(`Role player nomor *${nomor}* adalah *${roleInfo(role)}*.`);
    }
    case "guardian": {
      if (!["deff", "def", "protect", "guardian"].includes(sub)) throw `Role kamu *Guardian*. Pakai: *${usedPrefix}wwpc deff <nomor>*`;
      const ok = import_werewolf.default.protectGuardian(m.sender, nomor, db);
      if (ok === false) throw "Gagal melindungi target.";
      me.status = true;
      logWW(room.room, "night_action_protect", { by: m.sender, target: target.db.id, targetNumber: nomor });
      return m.reply(`Player nomor *${nomor}* berhasil kamu lindungi malam ini.`);
    }
    case "sorcerer": {
      if (sub !== "sorcerer") throw `Role kamu *Sorcerer*. Pakai: *${usedPrefix}wwpc sorcerer <nomor>*`;
      const role = import_werewolf.default.sorcerer(m.sender, nomor, db);
      if (!role) throw "Gagal melihat role target.";
      me.status = true;
      logWW(room.room, "night_action_sorcerer", { by: m.sender, target: target.db.id, targetNumber: nomor, seenRole: role });
      return m.reply(`Role player nomor *${nomor}* adalah *${roleInfo(role)}*.`);
    }
    case "warga":
    default:
      throw "Role warga tidak punya skill malam. Gunakan *wwpc role* atau *wwpc status* saja.";
  }
};
handler.help = ["wwpc role", "wwpc status", "wwpc kill <nomor>", "wwpc dreamy <nomor>", "wwpc deff <nomor>", "wwpc sorcerer <nomor>"];
handler.tags = ["game"];
handler.command = /^wwpc$/i;
handler.private = true;
handler.register = true;
var game_wwpc_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
