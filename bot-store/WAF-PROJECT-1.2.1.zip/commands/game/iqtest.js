/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - iqtest.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_iqtest_exports = {};
__export(game_iqtest_exports, {
  default: () => game_iqtest_default
});
module.exports = __toCommonJS(game_iqtest_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.reply(m.chat, `${pickRandom(global.iq)}`, m);
};
handler.help = ["iqtest"];
handler.tags = ["game"];
handler.command = /^(iqtest)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.register = true;
handler.limit = false;
var game_iqtest_default = handler;
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}
global.iq = [
  "IQ Anda Sebesar : 1",
  "IQ Anda Sebesar : 14",
  "IQ Anda Sebesar : 23",
  "IQ Anda Sebesar : 35",
  "IQ Anda Sebesar : 41",
  "IQ Anda Sebesar : 50",
  "IQ Anda Sebesar : 67",
  "IQ Anda Sebesar : 72",
  "IQ Anda Sebesar : 86",
  "IQ Anda Sebesar : 99",
  "IQ Anda Sebesar : 150",
  "IQ Anda Sebesar : 340",
  "IQ Anda Sebesar : 423",
  "IQ Anda Sebesar : 500",
  "IQ Anda Sebesar : 676",
  "IQ Anda Sebesar : 780",
  "IQ Anda Sebesar : 812",
  "IQ Anda Sebesar : 945",
  "IQ Anda Sebesar : 1000",
  "IQ Anda Sebesar : Tidak Terbatas!",
  "IQ Anda Sebesar : 5000",
  "IQ Anda Sebesar : 7500",
  "IQ Anda Sebesar : 10000"
];

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
