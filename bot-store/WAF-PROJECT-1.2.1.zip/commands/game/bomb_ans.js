/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - bomb_ans.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_bomb_ans_exports = {};
__export(game_bomb_ans_exports, {
  default: () => game_bomb_ans_default
});
module.exports = __toCommonJS(game_bomb_ans_exports);
var import_util = __toESM(require("util"));
let handler = (m) => m;
handler.before = async function(m) {
  try {
    let id = m.sender;
    let timeout = 18e4;
    let reward = randomInt(100, 800);
    let users = global.db.data.users[m.sender];
    let body = typeof m.text == "string" ? m.text : "";
    jagoanproject.bomb = jagoanproject.bomb ? jagoanproject.bomb : {};
    let isSurrender = /^(suren)$/i.test(body);
    if (isSurrender) {
      await jagoanproject.reply(m.chat, `\u{1F6A9} Menyerah`, m);
      clearTimeout(jagoanproject.bomb[id][2]);
      delete jagoanproject.bomb[id];
    }
    if (id in jagoanproject.bomb && !isNaN(body)) {
      let json = jagoanproject.bomb[id][1].find((v) => v.position == body);
      if (!json) return jagoanproject.reply(m.chat, `\u{1F6A9} Untuk membuka kotak kirim angka 1 - 9`, m);
      if (json.emot == "\u{1F4A3}") {
        json.state = true;
        let bomb = jagoanproject.bomb[id][1];
        let teks = `\u4E42  *B O M B*

`;
        teks += bomb.slice(0, 3).map((v) => v.state ? v.emot : v.number).join("") + "\n";
        teks += bomb.slice(3, 6).map((v) => v.state ? v.emot : v.number).join("") + "\n";
        teks += bomb.slice(6).map((v) => v.state ? v.emot : v.number).join("") + "\n\n";
        teks += `Timeout : [ *${timeout / 1e3 / 60} menit* ]
`;
        teks += `*Permainan selesai!*, kotak berisi bom terbuka : (- *${formatNumber(reward)}*)`;
        jagoanproject.reply(m.chat, teks, m).then(() => {
          users.exp < reward ? users.exp = 0 : users.exp -= reward;
          clearTimeout(jagoanproject.bomb[id][2]);
          delete jagoanproject.bomb[id];
        });
      } else if (json.state) {
        return jagoanproject.reply(m.chat, `\u{1F6A9} Kotak ${json.number} sudah di buka silahkan pilih kotak yang lain.`, m);
      } else {
        json.state = true;
        let changes = jagoanproject.bomb[id][1];
        let open = changes.filter((v) => v.state && v.emot != "\u{1F4A3}").length;
        if (open >= 8) {
          let teks = `\u4E42  *B O M B*

`;
          teks += `Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`;
          teks += changes.slice(0, 3).map((v) => v.state ? v.emot : v.number).join("") + "\n";
          teks += changes.slice(3, 6).map((v) => v.state ? v.emot : v.number).join("") + "\n";
          teks += changes.slice(6).map((v) => v.state ? v.emot : v.number).join("") + "\n\n";
          teks += `Timeout : [ *${timeout / 1e3 / 60} menit* ]
`;
          teks += `*Permainan selesai!* kotak berisi bom tidak terbuka : (+ *${formatNumber(reward)}*)`;
          jagoanproject.reply(m.chat, teks, m).then(() => {
            users.exp += reward;
            clearTimeout(jagoanproject.bomb[id][2]);
            delete jagoanproject.bomb[id];
          });
        } else {
          let teks = `\u4E42  *B O M B*

`;
          teks += `Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`;
          teks += changes.slice(0, 3).map((v) => v.state ? v.emot : v.number).join("") + "\n";
          teks += changes.slice(3, 6).map((v) => v.state ? v.emot : v.number).join("") + "\n";
          teks += changes.slice(6).map((v) => v.state ? v.emot : v.number).join("") + "\n\n";
          teks += `Timeout : [ *${timeout / 1e3 / 60} menit* ]
`;
          teks += `Kotak berisi bom tidak terbuka : (+ *${formatNumber(reward)}*)`;
          jagoanproject.reply(m.chat, teks, m).then(() => {
            users.exp += reward;
          });
        }
      }
    }
  } catch (e) {
    return jagoanproject.reply(m.chat, import_util.default.format(e), m);
  }
  return true;
};
handler.exp = 0;
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function formatNumber(number) {
  return number.toLocaleString();
}
handler.register = true;
handler.limit = false;
var game_bomb_ans_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
