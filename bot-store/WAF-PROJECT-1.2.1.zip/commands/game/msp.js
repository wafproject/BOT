/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - msp.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_msp_exports = {};
__export(game_msp_exports, {
  default: () => game_msp_default
});
module.exports = __toCommonJS(game_msp_exports);
const generate = (x, y, bombs) => {
  const field = Array.from({
    length: x
  }, () => Array(y).fill(0));
  for (let i = 0; i < bombs; i++) {
    let xBomb, yBomb;
    do {
      xBomb = Math.floor(Math.random() * x);
      yBomb = Math.floor(Math.random() * y);
    } while (field[xBomb][yBomb] === "x");
    field[xBomb][yBomb] = "x";
  }
  for (let i = 0; i < x; i++) {
    for (let j = 0; j < y; j++) {
      if (field[i][j] !== "x") {
        for (let k = -1; k <= 1; k++) {
          for (let l = -1; l <= 1; l++) {
            const ni = i + k;
            const nj = j + l;
            if (ni >= 0 && ni < x && nj >= 0 && nj < y && field[ni][nj] === "x") {
              field[i][j]++;
            }
          }
        }
      }
    }
  }
  return field;
};
const generateEmpty = (x, y) => Array.from({
  length: x
}, () => Array(y).fill(0));
const translate = (value) => {
  switch (value) {
    case 0:
      return "\u2B1C";
    case 1:
      return "1\uFE0F\u20E3";
    case 2:
      return "2\uFE0F\u20E3";
    case 3:
      return "3\uFE0F\u20E3";
    case 4:
      return "4\uFE0F\u20E3";
    case 5:
      return "5\uFE0F\u20E3";
    case 6:
      return "6\uFE0F\u20E3";
    case 7:
      return "7\uFE0F\u20E3";
    case 8:
      return "8\uFE0F\u20E3";
    case "x":
      return "\u{1F4A3}";
    case "e":
      return "\u23F9\uFE0F";
    case "f":
      return "\u{1F6A9}";
  }
};
const generateString = (map) => map.map((row) => row.map((cell) => translate(cell)).join("")).join("\n");
const detectZero = (map, x, y) => {
  const queue = [
    [x, y]
  ];
  const result = [];
  const visited = /* @__PURE__ */ new Set();
  while (queue.length > 0) {
    const [cx, cy] = queue.shift();
    if (!visited.has(`${cx},${cy}`)) {
      visited.add(`${cx},${cy}`);
      result.push([cx, cy]);
      if (map[cx][cy] === 0) {
        for (let i = -1; i <= 1; i++) {
          for (let j = -1; j <= 1; j++) {
            const ni = cx + i;
            const nj = cy + j;
            if (ni >= 0 && ni < map.length && nj >= 0 && nj < map[0].length) {
              queue.push([ni, nj]);
            }
          }
        }
      }
    }
  }
  return result;
};
const handler = async (m, {
  jagoanproject,
  args,
  usedPrefix,
  command
}) => {
  jagoanproject.minessweeper = jagoanproject.minessweeper || {};
  const orgs = args[0];
  const oX = args[1];
  const oY = args[2];
  const F = args[3];
  const x = 10;
  const y = 10;
  const bombs = 15;
  if (!orgs) {
    return jagoanproject.reply(m.chat, `\u{1F579}\uFE0F *Minesweeper Game* \u{1F579}\uFE0F
*\u25B6\uFE0F ${usedPrefix + command} go* - Start the Game
*\u{1F513} ${usedPrefix + command} open* - Open a cell
*\u{1F53D} ${usedPrefix + command} surrender* - Surrender

*Example:* ${usedPrefix + command} go`, m);
  }
  switch (orgs.toLowerCase()) {
    case "go":
    case "start":
      const map = generate(x, y, bombs);
      const empty = generateEmpty(x, y);
      const {
        key
      } = await jagoanproject.reply(m.chat, "\u{1F579}\uFE0F *Minesweeper Game* \u{1F579}\uFE0F\n\n*Board*\n" + generateString(empty), m);
      jagoanproject.minessweeper[m.chat] = {
        "map": map,
        "current": empty,
        "key": key
      };
      return;
    case "surrender":
    case "stop":
    case "end":
      if (!jagoanproject.minessweeper[m.chat]) {
        return jagoanproject.reply(m.chat, "\u{1F6A8} *No active game session.*", m);
      }
      delete jagoanproject.minessweeper[m.chat];
      return jagoanproject.reply(m.chat, "\u{1F3F3}\uFE0F *You surrendered.*", m);
    case "open":
    case "o":
    case "buka":
      if (!jagoanproject.minessweeper[m.chat]) {
        return jagoanproject.reply(m.chat, "\u{1F6A8} *No active game session.*", m);
      }
      if (oX > 10 || !oX || !oY) {
        return jagoanproject.reply(m.chat, `\u{1F6A8} *Invalid parameters. Example: ${usedPrefix + command} open 2 5*`, m);
      }
      const g = jagoanproject.minessweeper[m.chat];
      if (F === "f") {
        g.current[oY - 1][oX - 1] = "\u{1F6A9}";
      } else {
        const openedCell = g.map[oX - 1][oY - 1];
        if (openedCell === 0) {
          const zero = detectZero(g.map, oX - 1, oY - 1);
          for (const coords of zero) {
            g.current[coords[0]][coords[1]] = g.map[coords[0]][coords[1]];
          }
        } else if (openedCell === "x") {
          delete jagoanproject.minessweeper[m.chat];
          global.db.data.users[m.sender].exp -= 9e3;
          const {
            key: loseKey
          } = await jagoanproject.reply(m.chat, "\u{1F4A5} *BOOM!* \u{1F4A3} *You opened a bomb.*\n*Exp Points Deducted: 9000* \u{1F494}\n*Exp Points:* " + global.db.data.users[m.sender].exp, m);
          jagoanproject.minessweeper[m.chat] = {
            "key": loseKey
          };
          return;
        } else {
          g.current[oY - 1][oX - 1] = openedCell;
          global.db.data.users[m.sender].exp += 9e3;
        }
      }
      await jagoanproject.sendMessage(m.chat, {
        delete: g.key
      });
      const {
        key: newKey
      } = await jagoanproject.reply(m.chat, "\u{1F579}\uFE0F *Minesweeper Game* \u{1F579}\uFE0F\n\n*Board*\n" + generateString(g.current) + "\n\n*Exp Points:* +9000", m);
      jagoanproject.minessweeper[m.chat].key = newKey;
      return;
  }
};
handler.help = ["minesweeper"].map((v) => v + " *<command> <x> <y>*");
handler.tags = ["game"];
handler.command = /^(minesweeper)$/i;
handler.register = true;
handler.limit = false;
var game_msp_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
