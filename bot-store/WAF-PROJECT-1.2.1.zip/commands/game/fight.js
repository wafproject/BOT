/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - fight.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_fight_exports = {};
__export(game_fight_exports, {
  default: () => game_fight_default
});
module.exports = __toCommonJS(game_fight_exports);
let handler = async (m, { jagoanproject, participants }) => {
  let user = global.db.data.users[m.sender];
  jagoanproject.level = user;
  jagoanproject.fight = jagoanproject.fight ? jagoanproject.fight : {};
  const delay = (time) => new Promise((res) => setTimeout(res, time));
  if (jagoanproject.fight[m.sender]) {
    return m.reply("*Tidak bisa melakukan pertarungan lagi karena anda sedang bertarung bro.*");
  }
  let users = participants.map((u) => u.id);
  let lawan = users[Math.floor(users.length * Math.random())];
  while (typeof global.db.data.users[lawan] == "undefined" || lawan == m.sender) {
    lawan = users[Math.floor(users.length * Math.random())];
  }
  let lamaPertarungan = getRandom(5, 15);
  const namaSender = await getDisplayName(jagoanproject, m.sender);
  const namaLawan = await getDisplayName(jagoanproject, lawan);
  const levelSender = global.db.data.users[m.sender]?.level || 0;
  const levelLawan = global.db.data.users[lawan]?.level || 0;
  m.reply(`*${namaSender}* (level ${levelSender}) menantang *${namaLawan}* (level ${levelLawan}) dan sedang dalam pertarungan sengit.

Tunggu ${lamaPertarungan} menit lagi dan lihat siapa yg menang.`);
  jagoanproject.fight[m.sender] = true;
  await delay(1e3 * 60 * lamaPertarungan);
  let alasanKalah = ["Noob", "Cupu", "Kurang hebat", "Ampas kalahan", "Gembel kalahan"];
  let alasanMenang = ["Hebat", "Pro", "Master Game", "Legenda game", "Sangat Pro", "Rajin Nge-push"];
  let kesempatan = [];
  for (let i = 0; i < levelSender; i++) kesempatan.push(m.sender);
  for (let i = 0; i < levelLawan; i++) kesempatan.push(lawan);
  if (kesempatan.length === 0) kesempatan = [m.sender, lawan];
  let pointPemain = 0;
  let pointLawan = 0;
  for (let i = 0; i < 10; i++) {
    let unggul = getRandom(0, kesempatan.length - 1);
    if (kesempatan[unggul] == m.sender) pointPemain += 1;
    else pointLawan += 1;
  }
  if (pointPemain > pointLawan) {
    let hadiah = (pointPemain - pointLawan) * 1e4;
    global.db.data.users[m.sender].money += hadiah;
    global.db.data.users[m.sender].tiketcoin += 1;
    m.reply(`*${namaSender}* [${pointPemain * 10}] - [${pointLawan * 10}] *${namaLawan}*

*${namaSender}* (level ${levelSender}) MENANG melawan *${namaLawan}* (level ${levelLawan}) karena kamu ${alasanMenang[getRandom(0, alasanMenang.length - 1)]}

Hadiah Rp. ${hadiah.toLocaleString()}
+1 Tiketcoin`);
  } else if (pointPemain < pointLawan) {
    let denda = (pointLawan - pointPemain) * 1e4;
    global.db.data.users[m.sender].money -= denda;
    global.db.data.users[m.sender].tiketcoin += 1;
    m.reply(`*${namaSender}* [${pointPemain * 10}] - [${pointLawan * 10}] *${namaLawan}*

*${namaSender}* (level ${levelSender}) KALAH melawan *${namaLawan}* (level ${levelLawan}) karena kamu ${alasanKalah[getRandom(0, alasanKalah.length - 1)]}

Uang kamu berkurang Rp. ${denda.toLocaleString()}
+1 Tiketcoin`);
  } else {
    m.reply(`*${namaSender}* [${pointPemain * 10}] - [${pointLawan * 10}] *${namaLawan}*

Hasil imbang kak, ga dapet apa apa \u{1F602}`);
  }
  delete jagoanproject.fight[m.sender];
};
handler.help = ["fighting"];
handler.tags = ["game"];
handler.command = /^(fight(ing)?)$/i;
handler.limit = false;
handler.group = true;
handler.register = true;
var game_fight_default = handler;
function getRandom(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
async function getDisplayName(conn, jid) {
  try {
    const contact = await conn.getName(jid);
    if (contact) return contact;
  } catch {
  }
  const user = global.db.data.users[jid];
  if (user?.name) return user.name;
  return jid.split("@")[0];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
