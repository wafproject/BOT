/**
 * game/siapakahaku.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/game/siapakahaku",
  "command": [
    "siapakahaku"
  ],
  "kind": "game",
  "category": "game"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
