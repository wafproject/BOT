/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - bomb.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_bomb_exports = {};
__export(game_bomb_exports, {
  default: () => game_bomb_default
});
module.exports = __toCommonJS(game_bomb_exports);
let handler = async (m, { jagoanproject }) => {
  jagoanproject.bomb = jagoanproject.bomb ? jagoanproject.bomb : {};
  let id = m.sender, timeout = 18e4;
  if (id in jagoanproject.bomb) return jagoanproject.reply(m.chat, "*^ sesi ini belum selesai!*", jagoanproject.bomb[id][0]);
  const bom = ["\u{1F4A3}", "\u{1F355}", "\u{1F354}", "\u{1F968}", "\u{1F32D}", "\u{1F32E}", "\u{1F95E}", "\u{1F370}", "\u{1F356}"].sort(() => Math.random() - 0.5);
  const number = ["1\uFE0F\u20E3", "2\uFE0F\u20E3", "3\uFE0F\u20E3", "4\uFE0F\u20E3", "5\uFE0F\u20E3", "6\uFE0F\u20E3", "7\uFE0F\u20E3", "8\uFE0F\u20E3", "9\uFE0F\u20E3"];
  const array = bom.map((v2, i) => ({
    emot: v2,
    number: number[i],
    position: i + 1,
    state: false
  }));
  let teks = `\u4E42  *B O M B*

Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`;
  for (let i = 0; i < array.length; i += 3) teks += array.slice(i, i + 3).map((v2) => v2.state ? v2.emot : v2.number).join("") + "\n";
  teks += `
Timeout : [ *${timeout / 1e3 / 60} menit* ]
Apabila mendapat kotak yang berisi bom maka point akan di kurangi. Ketik suren untuk menyerah.`;
  let msg = await jagoanproject.sendMessage(
    m.chat,
    {
      text: teks,
      contextInfo: {
        extendedPreview: {
          title: "",
          body: "Bomb",
          thumbnailUrl: "https://telegra.ph/file/b3138928493e78b55526f.jpg",
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    },
    { quoted: m }
  );
  let { key } = msg;
  let v;
  jagoanproject.bomb[id] = [
    msg,
    array,
    setTimeout(() => {
      v = array.find((v2) => v2.emot == "\u{1F4A3}");
      if (jagoanproject.bomb[id]) jagoanproject.reply(m.chat, `*Waktu habis!*, Bom berada di kotak nomor ${v.number}.`, jagoanproject.bomb[id][0].key);
      delete jagoanproject.bomb[id];
    }, timeout),
    key
  ];
};
handler.help = ["bomb"];
handler.tags = ["game"];
handler.limit = false;
handler.command = /^(bomb)$/i;
handler.register = true;
var game_bomb_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
