/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - tebakislami.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_tebakislami_exports = {};
__export(game_tebakislami_exports, {
  default: () => game_tebakislami_default
});
module.exports = __toCommonJS(game_tebakislami_exports);
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  jagoanproject.tebakislami = jagoanproject.tebakislami || {};
  let id = m.chat;
  if (["surrender", "menyerah", "nyerah", "gatau"].includes(command)) {
    if (!(id in jagoanproject.tebakislami)) return; // WAF: .nyerah dipakai beberapa game, diam kalau bukan game ini
    let [_, soal2] = jagoanproject.tebakislami[id];
    jagoanproject.reply(m.chat, `\u{1F3F3}\uFE0F *Menyerah?*
Jawaban yang benar adalah: *${soal2.jawab}*`, m);
    clearTimeout(jagoanproject.tebakislami[id][3]);
    delete jagoanproject.tebakislami[id];
    return;
  }
  if (id in jagoanproject.tebakislami) return jagoanproject.reply(m.chat, "\u26A0\uFE0F Soal sebelumnya belum terjawab!", jagoanproject.tebakislami[id][0]);
  let soal = pickRandom(soalIslami);
  jagoanproject.tebakislami[id] = [
    await jagoanproject.reply(m.chat, `\u{1F54C} *Tebak Islami!*

\u27A1\uFE0F *Pertanyaan:* ${soal.pertanyaan}
\u23F3 *Waktu:* 30 detik
\u{1F381} *Bonus:* +1500 Money & +500 Exp

> jawab tanpa reply chat ini!

Menyerah? ketik *.surrender* / *.nyerah*`, m),
    soal,
    4,
    setTimeout(() => {
      if (jagoanproject.tebakislami[id]) jagoanproject.reply(m.chat, `\u23F0 *Waktu habis!*
Jawaban yang benar: *${soal.jawab}*`, jagoanproject.tebakislami[id][0]);
      delete jagoanproject.tebakislami[id];
    }, 3e4)
  ];
};
handler.help = ["tebakislami", "surrender"];
handler.tags = ["game"];
handler.command = /^(tebakislami|surrender|menyerah|nyerah|gatau)$/i;
handler.group = true;
handler.register = true;
handler.limit = false;
var game_tebakislami_default = handler;
let before = async (m, { jagoanproject }) => {
  jagoanproject.tebakislami = jagoanproject.tebakislami || {};
  let id = m.chat;
  if (!(id in jagoanproject.tebakislami)) return;
  let [msg, soal] = jagoanproject.tebakislami[id];
  if (!m.text || m.fromMe) return;
  if (/^[.!#/]/.test(m.text.trim())) return;
  if (m.text.toLowerCase().trim() === soal.jawab.toLowerCase().trim()) {
    global.db.data.users[m.sender].money += 1500;
    global.db.data.users[m.sender].exp = (global.db.data.users[m.sender].exp || 0) + 500;
    jagoanproject.reply(m.chat, `\u2705 ${m.name} benar!!
\u{1F389} Bonus: +1500 Money & +500 Exp`, m);
    clearTimeout(jagoanproject.tebakislami[id][3]);
    delete jagoanproject.tebakislami[id];
  } else {
    jagoanproject.reply(m.chat, "\u274C Salah! Coba lagi sampai benar sebelum waktu habis.", m);
  }
};
handler.before = before;
const soalIslami = [
  { pertanyaan: "Siapakah nabi pertama dalam Islam?", jawab: "Adam" },
  { pertanyaan: "Apa nama kitab yang diturunkan kepada Nabi Muhammad?", jawab: "Alquran" },
  { pertanyaan: "Berapa jumlah rukun Islam?", jawab: "5" },
  { pertanyaan: "Apa nama kota suci umat Islam?", jawab: "Mekah" },
  { pertanyaan: "Siapa nabi yang bisa membelah laut?", jawab: "Musa" },
  { pertanyaan: "Apa nama bulan suci umat Islam?", jawab: "Ramadhan" },
  { pertanyaan: "Berapa rakaat sholat Subuh?", jawab: "2" },
  { pertanyaan: "Hari besar umat Islam yang jatuh pada 1 Syawal?", jawab: "Idul Fitri" },
  { pertanyaan: "Berapa jumlah rakaat sholat Maghrib?", jawab: "3" },
  { pertanyaan: "Nama istri Nabi Muhammad yang pertama?", jawab: "Khadijah" },
  { pertanyaan: "Nama gunung tempat Nabi Musa menerima wahyu?", jawab: "Tur Sina" },
  { pertanyaan: "Apa nama malam yang lebih baik dari seribu bulan?", jawab: "Lailatul Qadar" },
  { pertanyaan: "Kota tempat Nabi Muhammad dilahirkan?", jawab: "Mekah" },
  { pertanyaan: "Kota tempat Nabi Muhammad hijrah?", jawab: "Madinah" },
  { pertanyaan: "Berapa jumlah total rakaat dalam sholat wajib?", jawab: "17" },
  { pertanyaan: "Siapa khalifah pertama setelah wafatnya Nabi Muhammad?", jawab: "Abu Bakar" },
  { pertanyaan: "Berapa jumlah huruf dalam Basmallah?", jawab: "19" },
  { pertanyaan: "Siapa nabi yang diangkat sejak dalam kandungan?", jawab: "Yahya" },
  { pertanyaan: "Apa nama hewan yang berbicara dalam Alquran?", jawab: "Semut" },
  { pertanyaan: "Siapakah penghuni surga yang pertama?", jawab: "Muhammad" },
  { pertanyaan: "Apa nama pintu surga untuk orang yang rajin puasa?", jawab: "Rayyan" },
  { pertanyaan: "Apa nama jin yang menjadi muslim dan mendengarkan Alquran?", jawab: "Jin" },
  { pertanyaan: "Surat apa yang paling panjang dalam Alquran?", jawab: "Al-Baqarah" },
  { pertanyaan: "Surat terakhir dalam Alquran?", jawab: "An-Nas" },
  { pertanyaan: "Berapa jumlah nabi yang wajib diketahui?", jawab: "25" },
  { pertanyaan: "Apa nama malam turunnya Alquran?", jawab: "Lailatul Qadar" },
  { pertanyaan: "Siapa nabi yang memiliki mukjizat bisa menghidupkan orang mati?", jawab: "Isa" },
  { pertanyaan: "Siapa nabi yang paling banyak disebut dalam Alquran?", jawab: "Musa" },
  { pertanyaan: "Siapa nama ayah Nabi Muhammad?", jawab: "Abdullah" },
  { pertanyaan: "Siapa nama ibu Nabi Muhammad?", jawab: "Aminah" },
  { pertanyaan: "Apa nama hewan yang menjadi tunggangan Nabi saat Isra Miraj?", jawab: "Buraq" },
  { pertanyaan: "Apa nama surah pertama dalam Alquran?", jawab: "Al-Fatihah" },
  { pertanyaan: 'Apa arti dari kata "Islam"?', jawab: "Selamat" },
  { pertanyaan: "Apa nama puasa sunah pada hari Senin dan Kamis?", jawab: "Puasa Senin Kamis" },
  { pertanyaan: "Apa nama istri Nabi yang terkenal cerdas dan meriwayatkan banyak hadits?", jawab: "Aisyah" },
  { pertanyaan: "Apa nama nabi yang bisa berbicara saat masih bayi?", jawab: "Isa" },
  { pertanyaan: "Siapa yang membangun Ka\u2019bah bersama Nabi Ibrahim?", jawab: "Ismail" },
  { pertanyaan: "Apa nama telaga milik Nabi Muhammad di surga?", jawab: "Al-Kautsar" },
  { pertanyaan: "Apa nama surat yang hanya terdiri dari 3 huruf dan sering dibaca?", jawab: "Al-Ikhlas" },
  { pertanyaan: "Berapa jumlah takbir dalam sholat Idul Fitri?", jawab: "7" },
  { pertanyaan: "Siapa nabi yang dikenal paling sabar?", jawab: "Ayyub" },
  { pertanyaan: "Siapa nabi yang ditelan ikan paus?", jawab: "Yunus" },
  { pertanyaan: "Apa nama kitab yang diturunkan kepada Nabi Isa?", jawab: "Injil" },
  { pertanyaan: "Apa nama kitab yang diturunkan kepada Nabi Musa?", jawab: "Taurat" },
  { pertanyaan: "Apa nama kitab yang diturunkan kepada Nabi Daud?", jawab: "Zabur" },
  { pertanyaan: "Siapa pemimpin kaum Quraisy yang paling menentang dakwah Nabi?", jawab: "Abu Lahab" },
  { pertanyaan: "Apa nama peperangan pertama umat Islam?", jawab: "Badar" },
  { pertanyaan: "Apa nama surah terpendek dalam Alquran?", jawab: "Al-Kautsar" }
];
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
