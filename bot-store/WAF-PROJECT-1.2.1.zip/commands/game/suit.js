/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - suit.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_suit_exports = {};
__export(game_suit_exports, {
  default: () => game_suit_default
});
module.exports = __toCommonJS(game_suit_exports);
let timeout = 6e4;
let handler = async (m, { jagoanproject, usedPrefix, args }) => {
  jagoanproject.suit = jagoanproject.suit || {};
  if (Object.values(jagoanproject.suit).find((room) => [room.p, room.p2].includes(m.sender)))
    return m.reply("\u274C Suit yang sebelumnya belum selesai!!");
  if (!m.mentionedJid[0])
    return m.reply(`\u274C FORMAT SALAH!!

\u{1F4DD} NOTE :

Tag orang yang mau di tantang suit!!

\u{1F4CC} CONTOH :

\u2013 *${usedPrefix}suit @user 100000*`);
  if (Object.values(jagoanproject.suit).find((room) => [room.p, room.p2].includes(m.mentionedJid[0])))
    return m.reply(`\u{1F639} Orang yang kamu tantang sedang bermain suit bersama orang lain :(`);
  let bet = args[1] ? parseInt(args[1]) : 0;
  if (isNaN(bet) || bet < 0) return m.reply("\u274C Jumlah taruhan tidak valid!");
  let user = global.db.data.users[m.sender];
  let target = global.db.data.users[m.mentionedJid[0]];
  if (user.money < bet)
    return m.reply(`\u274C Money kamu tidak mencukupi.
Saldo: Rp. ${user.money.toLocaleString("id-ID")}`);
  if (target.money < bet)
    return m.reply(`\u274C Money lawan tidak mencukupi!`, m.chat, { mentions: [m.mentionedJid[0]] });
  user.money -= bet;
  target.money -= bet;
  let id = "suit_" + /* @__PURE__ */ new Date() * 1;
  let caption = `
\u{1F3AE} ROOM SUIT DIBUAT \u{1F3AE}

\u{1F9D1}\u{1F3FB}\u200D\u{1F9B0} player 1 : @${m.sender.split`@`[0]}
\u{1F9D1}\u{1F3FB}\u200D\u{1F9B1} player 2 : @${m.mentionedJid[0].split`@`[0]}

\u{1F4B0} taruhan : Rp. ${bet.toLocaleString("id-ID")}
\u{1F381} jackpot : Rp. ${(bet * 2).toLocaleString("id-ID")}

kepada @${m.mentionedJid[0].split`@`[0]} dipersilahkan untuk menjawab.

TERIMA :
- terima
- oke
- gas

TOLAK :
- tolak
- gabisa
- nanti`.trim();
  await m.reply(caption, m.chat, {
    contextInfo: { mentionedJid: [m.sender, m.mentionedJid[0]] }
  });
  jagoanproject.suit[id] = {
    id,
    chat: m.chat,
    p: m.sender,
    p2: m.mentionedJid[0],
    status: "wait",
    bet,
    waktu: setTimeout(() => {
      if (jagoanproject.suit[id]) {
        global.db.data.users[jagoanproject.suit[id].p].money += bet;
        global.db.data.users[jagoanproject.suit[id].p2].money += bet;
        jagoanproject.reply(m.chat, `\u23F0 WAKTU HABIS!

> game suit dibatalkan!!`, m);
      }
      delete jagoanproject.suit[id];
    }, timeout)
  };
};
handler.before = async (m, { jagoanproject }) => {
  jagoanproject.suit = jagoanproject.suit || {};
  if (m.isZapo || !m.text) return;
  let room = Object.values(jagoanproject.suit).find(
    (room2) => [room2.p, room2.p2].includes(m.sender)
  );
  if (!room) return;
  let msg = m.text.toLowerCase();
  if (room.status === "wait" && m.sender === room.p2) {
    if (/^(tolak|gabisa|nanti)/i.test(msg)) {
      global.db.data.users[room.p].money += room.bet;
      global.db.data.users[room.p2].money += room.bet;
      jagoanproject.reply(
        room.chat,
        `\u274C @${room.p2.split`@`[0]} menolak suit.`,
        null,
        { mentions: [room.p, room.p2] }
      );
      clearTimeout(room.waktu);
      delete jagoanproject.suit[room.id];
      return true;
    }
    if (/^(terima|oke|gas)/i.test(msg)) {
      room.status = "play";
      clearTimeout(room.waktu);
      jagoanproject.reply(room.chat, `
\u{1F3AE} SUIT DIMULAI \u{1F3AE}

> silahkan pilih suit di room chat bot

\u{1F4CC} pilih suitmu disini :
https://wa.me/${jagoanproject.user.jid.split("@")[0]}
`.trim());
      let teksPC = `
\u{1F4CC} PILIH SUITMU :

- batu
- gunting
- kertas

> ketik pilihanmu tanpa reply chat!
`.trim();
      jagoanproject.reply(room.p, teksPC, null);
      jagoanproject.reply(room.p2, teksPC, null);
      return true;
    }
  }
  if (room.status === "play" && m.chat === m.sender) {
    if (!/^(batu|gunting|kertas)/i.test(msg)) return;
    let player = m.sender === room.p ? "p" : "p2";
    if (room[player + "text"])
      return m.reply("Kamu sudah memilih!");
    room[player + "text"] = msg;
    if (room.ptext && room.p2text) {
      let p1 = room.ptext;
      let p2 = room.p2text;
      let result = "";
      if (p1 === p2) result = "seri";
      else if (p1 === "batu" && p2 === "gunting" || p1 === "gunting" && p2 === "kertas" || p1 === "kertas" && p2 === "batu") result = "p";
      else result = "p2";
      let jackpot = room.bet * 2;
      if (result === "seri") {
        global.db.data.users[room.p].money += room.bet;
        global.db.data.users[room.p2].money += room.bet;
        jagoanproject.reply(room.chat, `\u{1F91D} HASIL SERI!
Uang dikembalikan.`);
      } else {
        let winner = room[result];
        let loser = result === "p" ? room.p2 : room.p;
        let winText = result === "p" ? p1 : p2;
        let loseText = result === "p" ? p2 : p1;
        global.db.data.users[winner].money += jackpot;
        let teks = `
\u{1F3AE} *HASIL SUIT* \u{1F3AE}

\u{1F9D1}\u{1F3FB}\u200D\u{1F9B0} @${winner.split`@`[0]}
- pilih : *${winText}*
- menang \u{1F973}
- dapat : Rp. ${jackpot.toLocaleString("id-ID")}

\u{1F9D1}\u{1F3FB}\u200D\u{1F9B1} @${loser.split`@`[0]}
- pilih : *${loseText}*
- kalah \u{1F639}
`.trim();
        jagoanproject.reply(room.chat, teks, null, {
          mentions: [room.p, room.p2]
        });
      }
      delete jagoanproject.suit[room.id];
    } else {
      m.reply("Pilihan diterima! Menunggu lawan...");
    }
  }
};
handler.tags = ["game"];
handler.help = ["suit @tag <bet>"];
handler.command = /^suit$/i;
handler.group = true;
handler.register = true;
var game_suit_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
