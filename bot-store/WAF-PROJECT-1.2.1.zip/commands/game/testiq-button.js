/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - testiq - button.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_testiq_button_exports = {};
__export(game_testiq_button_exports, {
  default: () => game_testiq_button_default
});
module.exports = __toCommonJS(game_testiq_button_exports);
let soalTestIQ = {
  easy: [
    { soal: "Bumi berbentuk?", opsi: ["Datar", "Kotak", "Bulat"], jawaban: "c" },
    { soal: "Berapa jumlah roda mobil pada umumnya?", opsi: ["1", "2", "4"], jawaban: "c" },
    { soal: "Jika 2 + 3 = 5, maka 5 + 4 = ?", opsi: ["7", "8", "9"], jawaban: "c" },
    { soal: "Hewan yang dikenal sebagai 'raja hutan'?", opsi: ["Singa", "Harimau", "Gajah"], jawaban: "a" },
    { soal: "1 jam = berapa menit?", opsi: ["30", "60", "90"], jawaban: "b" },
    { soal: "Warna apa yang paling genit di pelangi?", opsi: ["Merah", "Kuning", "Hijau"], jawaban: "a" }
  ],
  medium: [
    { soal: "Jika 1 kg apel harganya Rp20.000, berapa harga 2,5 kg apel?", opsi: ["Rp40.000", "Rp50.000", "Rp60.000"], jawaban: "b" },
    { soal: "Gaya yang menyebabkan benda jatuh ke bumi disebut?", opsi: ["Gesekan", "Gravitasi", "Inersia"], jawaban: "b" },
    { soal: "Unsur kimia dengan simbol 'O' adalah?", opsi: ["Osmium", "Oksigen", "Oganesson"], jawaban: "b" },
    { soal: "Siapa presiden pertama Indonesia?", opsi: ["Sukarno", "Suharto", "Habibie"], jawaban: "a" },
    { soal: "Jika A = 1, B = 2, C = 3, maka berapa nilai dari kata 'CAB'?", opsi: ["4", "6", "7"], jawaban: "b" }
  ],
  hard: [
    { soal: "Jika kecepatan mobil 60 km/jam, berapa jarak yang ditempuh dalam 2,5 jam?", opsi: ["120 km", "140 km", "150 km"], jawaban: "c" },
    { soal: "Reaksi kimia yang menghasilkan panas disebut?", opsi: ["Endoterm", "Eksoterm", "Netralisasi"], jawaban: "b" },
    { soal: "Tahun berapa Perang Dunia II berakhir?", opsi: ["1943", "1944", "1945"], jawaban: "c" },
    { soal: "Jika 3x + 5 = 20, maka x = ?", opsi: ["3", "4", "5"], jawaban: "c" },
    { soal: "Dalam psikologi, efek yang membuat orang cenderung memilih opsi pertama yang ditawarkan disebut?", opsi: ["Efek Halo", "Efek Primacy", "Efek Recency"], jawaban: "b" }
  ],
  legend: [
    { soal: "Jika sebuah benda dilempar vertikal ke atas dengan kecepatan awal 20 m/s, berapa waktu yang dibutuhkan untuk kembali ke titik awal? (g = 10 m/s\xB2)", opsi: ["2 s", "3 s", "4 s"], jawaban: "c" },
    { soal: "Unsur dengan nomor atom 26 adalah?", opsi: ["Kromium", "Besi", "Kobalt"], jawaban: "b" },
    { soal: "Peristiwa sejarah yang terjadi pada 17 Agustus 1945 di Indonesia adalah?", opsi: ["Konferensi Meja Bundar", "Proklamasi Kemerdekaan", "Agresi Militer Belanda"], jawaban: "b" },
    { soal: "Dalam deret: 2, 6, 12, 20, 30, berapa suku berikutnya?", opsi: ["42", "45", "48"], jawaban: "a" },
    { soal: "Dalam tes IQ, pola gambar segitiga dengan jumlah titik bertambah 3 setiap langkah. Jika langkah pertama memiliki 3 titik, langkah kelima memiliki berapa titik?", opsi: ["12", "15", "18"], jawaban: "b" }
  ]
};
let sesiTestIQ = {};
const timeout = 6e4;
const namebot = "Grok";
function buildSoalText(level, data) {
  let soalText = `\u{1F9E0} *TEST IQ - ${level.toUpperCase()}* \u{1F9E0}

\u{1F4DC} Soal: ${data.soal}

`;
  data.opsi.forEach((opt, i) => {
    soalText += `${String.fromCharCode(97 + i)}. ${opt}
`;
  });
  soalText += `
\u23F0 Waktu: 60 detik
\u203C\uFE0F Jawab dengan tombol di bawah.

> *.gtw* untuk menyerah.`;
  return soalText;
}
function buildButtons(usedPrefix, chatId) {
  return [
    { buttonId: `${usedPrefix}jawab ${chatId} a`, buttonText: { displayText: "a" }, type: 1 },
    { buttonId: `${usedPrefix}jawab ${chatId} b`, buttonText: { displayText: "b" }, type: 1 },
    { buttonId: `${usedPrefix}jawab ${chatId} c`, buttonText: { displayText: "c" }, type: 1 }
  ];
}
function pickRandomQuestion(level) {
  return soalTestIQ[level][Math.floor(Math.random() * soalTestIQ[level].length)];
}
let handler = async (m, { jagoanproject, command, args, usedPrefix }) => {
  let id = m.chat;
  switch ((command || "").toLowerCase()) {
    case "testiq": {
      if (sesiTestIQ[id]) {
        return jagoanproject.reply(
          m.chat,
          "\u{1F92C} Masih ada soal yang belum dijawab!\n\n> Klik tombol jawaban atau ketik *.gtw* untuk menyerah!",
          m
        );
      }
      let level = (args[0] || "").toLowerCase();
      if (!["easy", "medium", "hard", "legend"].includes(level)) {
        return jagoanproject.reply(
          m.chat,
          "\u274C Pilih level: *easy*, *medium*, *hard*, atau *legend*.\nContoh: *.testiq hard*",
          m
        );
      }
      let data = pickRandomQuestion(level);
      let soalText = buildSoalText(level, data);
      let buttons = buildButtons(usedPrefix, id);
      let kirim = await jagoanproject.sendMessage(m.chat, {
        text: soalText,
        footer: namebot,
        buttons,
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
      sesiTestIQ[id] = {
        soalData: data,
        jawaban: data.jawaban.toLowerCase(),
        idPesan: kirim.key.id,
        level,
        timeout: setTimeout(() => {
          if (!sesiTestIQ[id]) return;
          let opsiIndex = sesiTestIQ[id].jawaban.charCodeAt(0) - 97;
          let opsiTeks = sesiTestIQ[id].soalData.opsi[opsiIndex];
          jagoanproject.sendMessage(m.chat, {
            text: `\u23F0 Waktu habis!

Jawabannya adalah: *${sesiTestIQ[id].jawaban}* (${opsiTeks})`
          });
          delete sesiTestIQ[id];
        }, timeout)
      };
      break;
    }
    case "gtw": {
      if (!sesiTestIQ[id]) return jagoanproject.reply(m.chat, "\u274C Tidak ada sesi TestIQ yang aktif.", m);
      clearTimeout(sesiTestIQ[id].timeout);
      let jawabanGtw = sesiTestIQ[id].jawaban;
      let opsiIndexGtw = jawabanGtw.charCodeAt(0) - 97;
      let opsiTeksGtw = sesiTestIQ[id].soalData.opsi[opsiIndexGtw];
      await jagoanproject.sendMessage(m.chat, {
        text: `\u{1F3F3}\uFE0F *MENYERAH!*

Jawabannya adalah: *${jawabanGtw}* (${opsiTeksGtw})`
      }, { quoted: m });
      delete sesiTestIQ[id];
      break;
    }
    case "jawab": {
      if (!sesiTestIQ[id]) return jagoanproject.reply(m.chat, "\u274C Tidak ada sesi TestIQ yang aktif.", m);
      let targetChatId = (args[0] || "").trim();
      let userAnswer = (args[1] || "").toLowerCase().trim();
      if (targetChatId && targetChatId !== id) {
        return jagoanproject.reply(m.chat, "\u274C Tombol tidak valid untuk sesi ini.", m);
      }
      if (!["a", "b", "c"].includes(userAnswer)) {
        return jagoanproject.reply(m.chat, "\u274C Jawaban tidak valid. Gunakan tombol *a/b/c*.", m);
      }
      const session = sesiTestIQ[id];
      const jawaban = session.jawaban;
      const soalData = session.soalData;
      if (userAnswer === jawaban) {
        let iqScore = {
          easy: Math.floor(Math.random() * 21) + 80,
          medium: Math.floor(Math.random() * 21) + 100,
          hard: Math.floor(Math.random() * 21) + 120,
          legend: Math.floor(Math.random() * 21) + 140
        }[session.level];
        let hadiah = {
          easy: Math.floor(Math.random() * 501) + 500,
          medium: Math.floor(Math.random() * 1001) + 1e3,
          hard: Math.floor(Math.random() * 1501) + 2e3,
          legend: Math.floor(Math.random() * 2001) + 3500
        }[session.level];
        let user = global.db.data.users[m.sender];
        if (user) user.money = (user.money || 0) + hadiah;
        let opsiIndex = jawaban.charCodeAt(0) - 97;
        let opsiTeks = soalData.opsi[opsiIndex];
        let response = `\u2705 *Selamat, jawaban kamu benar!*

\u{1F4DD} Jawaban: *${jawaban}* (${opsiTeks})
\u{1F9E0} Skor IQ: *${iqScore}*
\u{1F381} Hadiah: *${hadiah} money*`;
        await jagoanproject.sendMessage(m.chat, {
          text: response,
          footer: namebot,
          headerType: 1,
          viewOnce: true
        }, { quoted: m });
        clearTimeout(session.timeout);
        delete sesiTestIQ[id];
      } else {
        await jagoanproject.reply(
          m.chat,
          `\u274C *Jawaban salah!* Coba lagi sampai benar sebelum waktu habis.`,
          m
        );
      }
      break;
    }
  }
};
handler.command = /^testiq|gtw|jawab$/i;
handler.tags = ["game"];
handler.help = ["testiq <easy|medium|hard|legend>"];
handler.limit = false;
handler.register = true;
var game_testiq_button_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
