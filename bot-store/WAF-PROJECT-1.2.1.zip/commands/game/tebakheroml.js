/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - tebakheroml.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_tebakheroml_exports = {};
__export(game_tebakheroml_exports, {
  default: () => game_tebakheroml_default
});
module.exports = __toCommonJS(game_tebakheroml_exports);
var __child_process_1 = __toESM(require("child_process"));
var import_axios = __toESM(require("axios"));
const { execSync, spawnSync } = __child_process_1;
const characters = [
  "Aamon",
  "Akai",
  "Aldous",
  "Alice",
  "Alpha",
  "Alucard",
  "Angela",
  "Argus",
  "Arlott",
  "Atlas",
  "Aulus",
  "Aurora",
  "Badang",
  "Balmond",
  "Bane",
  "Barats",
  "Baxia",
  "Beatrix",
  "Belerick",
  "Benedetta",
  "Brody",
  "Bruno",
  "Carmilla",
  "Cecilion",
  "Chou",
  "Cici",
  "Claude",
  "Clint",
  "Cyclops",
  "Diggie",
  "Dyrroth",
  "Edith",
  "Esmeralda",
  "Estes",
  "Eudora",
  "Fanny",
  "Faramis",
  "Floryn",
  "Franco",
  "Fredrinn",
  "Freya",
  "Gatotkaca",
  "Gloo",
  "Gord",
  "Granger",
  "Grock",
  "Guinevere",
  "Gusion",
  "Hanabi",
  "Hanzo",
  "Harith",
  "Harley",
  "Hayabusa",
  "Helcurt",
  "Hilda",
  "Hylos",
  "Irithel",
  "Ixia",
  "Jawhead",
  "Johnson",
  "Joy",
  "Julian",
  "Kadita",
  "Kagura",
  "Kaja",
  "Karina",
  "Karrie",
  "Khaleed",
  "Khufra",
  "Kimmy",
  "Lancelot",
  "Layla",
  "Leomord",
  "Lesley",
  "Ling",
  "Lolita",
  "Lunox",
  "Luo Yi",
  "Lylia",
  "Martis",
  "Masha",
  "Mathilda",
  "Melissa",
  "Minotaur",
  "Minsitthar",
  "Miya",
  "Moskov",
  "Nana",
  "Natalia",
  "Natan",
  "Novaria",
  "Odette",
  "Paquito",
  "Pharsa",
  "Phoveus",
  "Popol and Kupa",
  "Rafaela",
  "Roger",
  "Ruby",
  "Saber",
  "Selena",
  "Silvanna",
  "Sun",
  "Terizla",
  "Thamuz",
  "Tigreal",
  "Uranus",
  "Vale",
  "Valentina",
  "Valir",
  "Vexana",
  "Wanwan",
  "Xavier",
  "Yin",
  "Yu Zhong",
  "Yve",
  "Zhask",
  "Zilong"
];
let hadiah = { money: 5e3, limit: 2, exp: 200 };
function toWikiTitle(name) {
  return encodeURIComponent(String(name).trim().replace(/\s+/g, "_"));
}
function buildHeaders() {
  return {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.8,id;q=0.7",
    "Accept-Encoding": "gzip, deflate",
    // penting: NO br
    "Connection": "keep-alive"
  };
}
function guessExt(url) {
  const u = String(url);
  const m = u.match(/\.(ogg|mp3|wav)(?:\/|$|\?)/i);
  return m ? m[1].toLowerCase() : "ogg";
}
function mimeFromExt(ext) {
  if (ext === "mp3") return "audio/mpeg";
  if (ext === "wav") return "audio/wav";
  return "audio/ogg";
}
async function fetchText(url) {
  const res = await import_axios.default.get(url, {
    timeout: 3e4,
    maxRedirects: 5,
    responseType: "text",
    headers: buildHeaders(),
    validateStatus: () => true
  });
  if (res.status < 200 || res.status >= 300) {
    throw new Error(`HTTP ${res.status} ketika fetch: ${url}`);
  }
  return typeof res.data === "string" ? res.data : String(res.data);
}
async function fetchFandomParsedHtml(pageTitle) {
  const apiUrl = "https://mobile-legends.fandom.com/api.php";
  const res = await import_axios.default.get(apiUrl, {
    timeout: 3e4,
    headers: buildHeaders(),
    params: {
      action: "parse",
      page: pageTitle,
      prop: "text",
      format: "json",
      redirects: 1,
      origin: "*"
    },
    validateStatus: () => true
  });
  if (res.status < 200 || res.status >= 300) {
    throw new Error(`HTTP ${res.status} parse API untuk page: ${pageTitle}`);
  }
  const html = res.data?.parse?.text?.["*"];
  if (!html || typeof html !== "string") {
    throw new Error(`Parse API tidak mengembalikan HTML untuk: ${pageTitle}`);
  }
  return html;
}
function extractDirectStaticAudioUrls(text) {
  const out = /* @__PURE__ */ new Set();
  const re = /https?:\/\/static\.wikia\.nocookie\.net\/[^"'<> \n\r\t]+?\.(?:ogg|mp3|wav)(?:[^"'<> \n\r\t]*)/gi;
  let m;
  while ((m = re.exec(text)) !== null) out.add(m[0]);
  return [...out];
}
function extractAudioFilenamesFromText(text) {
  const out = /* @__PURE__ */ new Set();
  const re = /File(?::|%3A)([^"'\s?#<>]+?\.(?:ogg|mp3|wav))/gi;
  let m;
  while ((m = re.exec(text)) !== null) {
    try {
      out.add(decodeURIComponent(m[1]));
    } catch {
      out.add(m[1]);
    }
  }
  return [...out];
}
function extractSpecialFilePathLinks(text) {
  const out = /* @__PURE__ */ new Set();
  const re = /\/wiki\/Special:FilePath\/([^"'<>\s?#]+)/gi;
  let m;
  while ((m = re.exec(text)) !== null) {
    try {
      out.add(decodeURIComponent(m[1]));
    } catch {
      out.add(m[1]);
    }
  }
  return [...out];
}
function filePathUrl(filename) {
  return `https://mobile-legends.fandom.com/wiki/Special:FilePath/${encodeURIComponent(filename)}`;
}
function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
async function scrapeOneHeroAudioUrl(heroName) {
  const normalized = String(heroName).trim().replace(/\s+/g, "_");
  const pageTitlesToTry = [
    `${normalized}/Audio/id`,
    `${normalized}/Audio`
  ];
  for (const pageTitle of pageTitlesToTry) {
    try {
      const html = await fetchFandomParsedHtml(pageTitle);
      const direct = extractDirectStaticAudioUrls(html);
      if (direct.length) return pickRandom(direct);
      const sp = extractSpecialFilePathLinks(html);
      if (sp.length) return filePathUrl(pickRandom(sp));
      const files = extractAudioFilenamesFromText(html);
      if (files.length) return filePathUrl(pickRandom(files));
    } catch {
    }
  }
  const titleEnc = toWikiTitle(heroName);
  const jwUrlsToTry = [
    `https://mobile-legends.fandom.com/wiki/${titleEnc}/JWPlayer.js`,
    `https://mobile-legends.fandom.com/wiki/${titleEnc}/Audio/JWPlayer.js`,
    // kadang bentuk tanpa encode underscore juga bisa
    `https://mobile-legends.fandom.com/wiki/${normalized}/JWPlayer.js`,
    `https://mobile-legends.fandom.com/wiki/${normalized}/Audio/JWPlayer.js`
  ];
  for (const jwUrl of jwUrlsToTry) {
    try {
      const js = await fetchText(jwUrl);
      const direct = extractDirectStaticAudioUrls(js);
      if (direct.length) return pickRandom(direct);
      const files = extractAudioFilenamesFromText(js);
      if (files.length) return filePathUrl(pickRandom(files));
    } catch {
    }
  }
  return null;
}
async function scrapeHeroAudio(attempt = 1, maxAttempts = 5) {
  try {
    const pickedHero = characters[Math.floor(Math.random() * characters.length)];
    const audio = await scrapeOneHeroAudioUrl(pickedHero);
    if (!audio) throw new Error(`No audio links found on audio page for: ${pickedHero}`);
    return {
      displayName: pickedHero,
      answer: pickedHero.toLowerCase(),
      audio
    };
  } catch (err) {
    console.error(`Scrape Error (Attempt ${attempt}):`, err?.message || err);
    if (attempt < maxAttempts) return scrapeHeroAudio(attempt + 1, maxAttempts);
    throw new Error("Failed to fetch hero audio data after multiple attempts");
  }
}
async function downloadToBuffer(url) {
  const res = await import_axios.default.get(url, {
    responseType: "arraybuffer",
    timeout: 3e4,
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept-Encoding": "gzip, deflate"
    },
    validateStatus: () => true
  });
  if (res.status < 200 || res.status >= 300) {
    throw new Error(`Gagal download audio: HTTP ${res.status} | ${url}`);
  }
  return Buffer.from(res.data);
}
function hasFfmpeg() {
  try {
    execSync("ffmpeg -version", { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}
function convertToOpusOgg(inputBuf) {
  const result = spawnSync("ffmpeg", [
    "-hide_banner",
    "-loglevel",
    "error",
    "-y",
    "-i",
    "pipe:0",
    "-vn",
    "-c:a",
    "libopus",
    "-b:a",
    "48k",
    "-ar",
    "48000",
    "-f",
    "ogg",
    "pipe:1"
  ], {
    input: inputBuf,
    maxBuffer: 64 * 1024 * 1024
  });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error(`ffmpeg gagal: ${String(result.stderr || "").trim() || `exit ${result.status}`}`);
  }
  if (!result.stdout?.length) throw new Error("Hasil convert ffmpeg kosong");
  return Buffer.from(result.stdout);
}
async function handler(m, { jagoanproject }) {
  jagoanproject.game = jagoanproject.game || {};
  let id = "tebakheroml_" + m.chat;
  if (id in jagoanproject.game) {
    return jagoanproject.reply(
      m.chat,
      "\u2757 Masih ada game *Tebak Hero ML* yang belum selesai di chat ini.",
      jagoanproject.game[id].msg
    );
  }
  try {
    const { displayName, answer, audio } = await scrapeHeroAudio();
    const ext = guessExt(audio);
    const mime = mimeFromExt(ext);
    const teks = `\u{1F3AE} *Tebak Hero ML!*

\u{1F9E0} Tebak nama hero dari suara berikut ini!
\u23F1\uFE0F Waktu menjawab: *60 detik*
\u{1F616} Salah menjawab akan diberi emot \u{1F4A9}

\u{1F3F3}\uFE0F Ketik *nyerah* jika ingin menyerah.
\u{1F381} Hadiah jika menang:
+\u{1F4B0} ${hadiah.money} Money
+\u{1F50B} ${hadiah.limit} Limit
+\u2728 ${hadiah.exp} XP`;
    let msg;
    try {
      const rawBuf = await downloadToBuffer(audio);
      let vnBuf = rawBuf;
      if (hasFfmpeg()) {
        try {
          vnBuf = convertToOpusOgg(rawBuf);
        } catch {
          vnBuf = rawBuf;
        }
      }
      msg = await jagoanproject.sendMessage(
        m.chat,
        {
          audio: vnBuf,
          mimetype: "audio/ogg; codecs=opus",
          ptt: true
        },
        { quoted: m }
      );
    } catch (e1) {
      try {
        msg = await jagoanproject.sendMessage(
          m.chat,
          {
            audio: { url: audio },
            mimetype: mime,
            ptt: false
          },
          { quoted: m }
        );
      } catch (e2) {
        msg = await jagoanproject.sendMessage(
          m.chat,
          {
            document: { url: audio },
            mimetype: mime,
            fileName: `${displayName}.${ext}`
          },
          { quoted: m }
        );
      }
    }
    await jagoanproject.sendMessage(m.chat, { text: teks }, { quoted: m });
    jagoanproject.game[id] = {
      id,
      displayName,
      name: answer,
      msg,
      starter: m.sender,
      timeout: setTimeout(() => {
        if (jagoanproject.game[id]) {
          jagoanproject.reply(
            m.chat,
            `\u23F1\uFE0F Waktu habis!
Jawaban: *${displayName}*`,
            jagoanproject.game[id].msg
          );
          delete jagoanproject.game[id];
        }
      }, 6e4)
    };
  } catch (e) {
    console.error(e);
    m.reply("\u274C Terjadi kesalahan saat memulai game. Coba lagi nanti.");
  }
}
handler.before = async function(m, { jagoanproject }) {
  jagoanproject.game = jagoanproject.game || {};
  let id = "tebakheroml_" + m.chat;
  if (!(id in jagoanproject.game)) return false;
  let room = jagoanproject.game[id];
  let userJawab = m.text?.toLowerCase();
  if (!userJawab) return false;
  if (/^(me)?nyerah$/i.test(userJawab)) {
    if (m.sender !== room.starter) return m.reply("\u274C Hanya yang memulai game yang bisa menyerah.");
    clearTimeout(room.timeout);
    jagoanproject.reply(m.chat, `\u{1F614} Menyerah ya?
Jawaban: *${room.displayName}*`, room.msg);
    delete jagoanproject.game[id];
    return true;
  }
  if (userJawab === room.name) {
    clearTimeout(room.timeout);
    let user = global.db.data.users[m.sender];
    user.money += hadiah.money;
    user.limit += hadiah.limit;
    user.exp += hadiah.exp;
    jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F389}", key: m.key } });
    jagoanproject.reply(
      m.chat,
      `\u{1F389} *Benar!* Jawabannya: *${room.displayName}*

\u{1F381} Kamu mendapat:
+\u{1F4B0} ${hadiah.money} Money
+\u{1F50B} ${hadiah.limit} Limit
+\u2728 ${hadiah.exp} XP`,
      room.msg
    );
    delete jagoanproject.game[id];
  } else {
    jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F4A9}", key: m.key } });
  }
  return true;
};
handler.help = ["tebakheroml"];
handler.tags = ["game"];
handler.command = /^tebakheroml$/i;
handler.group = true;
handler.register = true;
handler.limit = false;
var game_tebakheroml_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
