/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - dadu.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_dadu_exports = {};
__export(game_dadu_exports, {
  default: () => game_dadu_default
});
module.exports = __toCommonJS(game_dadu_exports);
let handler = async (m, { jagoanproject }) => {
  try {
    jagoanproject.daducd = jagoanproject.daducd ? jagoanproject.daducd : {};
    const now = Date.now();
    if (jagoanproject.daducd[m.sender] && now < jagoanproject.daducd[m.sender]) {
      const sisa = Math.ceil((jagoanproject.daducd[m.sender] - now) / 1e3);
      const jam = Math.floor(sisa / 3600);
      const menit = Math.floor(sisa % 3600 / 60);
      const detik = sisa % 60;
      return m.reply(`Anda menang sebelumnya jadi kena cooldown 1 jam.
Sisa cooldown: *${jam} jam ${menit} menit ${detik} detik*`);
    } else if (jagoanproject.daducd[m.sender] && now >= jagoanproject.daducd[m.sender]) {
      delete jagoanproject.daducd[m.sender];
    }
    const diceValue = Math.floor(Math.random() * 6) + 1;
    const diceImage = rollDice(diceValue);
    const isWin = diceValue >= 4;
    const additionalCoins = diceValue === 3 ? 300 : diceValue * 100;
    const baseCoins = isWin ? Math.min(Math.floor(Math.random() * 15001), 15e3) : 0;
    const baseExp = isWin ? Math.min(Math.floor(Math.random() * 10001), 1e4) : 0;
    const multiplier = isWin ? Math.floor(Math.random() * 2) + 1 : 1;
    const coins = Math.min(baseCoins * multiplier + additionalCoins, 15e3);
    const exp = Math.min(baseExp * multiplier, 1e4);
    const player = global.db.data.users[m.sender];
    player.money += coins;
    player.exp += exp;
    if (isWin) {
      jagoanproject.daducd[m.sender] = Date.now() + 36e5;
    }
    const resultMessage = isWin ? `\u{1F389} *Kamu menang!*` : `\u{1F639} *Kamu belum menang!*`;
    const coinMessage = coins ? `\u{1F4B0} *${coins.toLocaleString()}* coins earned!` : "No coins earned.";
    const expMessage = exp ? `\u{1F31F} *${exp.toLocaleString()}* exp gained!` : "No exp gained.";
    const additionalCoinsMessage = additionalCoins ? `\u{1F4B0} Additional *${additionalCoins.toLocaleString()}* coins for rolling a ${diceValue}!` : "";
    const multiplierMessage = multiplier > 1 ? `Multiplier: *${multiplier}*` : "";
    const msg = `${resultMessage}
\u{1F3B2} Hasil dadu: *${diceValue}*

${coinMessage}
${expMessage}
${additionalCoinsMessage}
${multiplierMessage}`;
    await jagoanproject.reply(m.chat, msg, m, {
      contextInfo: {
        mentionedJid: [m.sender],
        extendedPreview: {
          title: "\u{1F3B2} Roll the dice!",
          thumbnail: await (await jagoanproject.getFile(diceImage)).data
        }
      }
    });
  } catch (error) {
    console.error(error);
    await m.reply("Error processing the dice roll.");
  }
};
handler.help = ["dadu"].map((a) => a + " *[Rolling dice]*");
handler.tags = ["game"];
handler.command = ["dadu"];
handler.register = true;
handler.limit = false;
var game_dadu_default = handler;
function rollDice(value) {
  return `https://www.random.org/dice/dice${value}.png`;
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
