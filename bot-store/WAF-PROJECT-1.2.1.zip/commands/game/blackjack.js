/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - blackjack.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_blackjack_exports = {};
__export(game_blackjack_exports, {
  default: () => game_blackjack_default
});
module.exports = __toCommonJS(game_blackjack_exports);
async function jagoanprojectt(m, { jagoanproject, usedPrefix, command, text }) {
  jagoanproject.bj = jagoanproject.bj ? jagoanproject.bj : {};
  jagoanproject.bjcd = jagoanproject.bjcd ? jagoanproject.bjcd : {};
  if (m.sender in jagoanproject.bj) return m.reply("Kamu masih dalam game, tunggu sampai selesai!!");
  const now = Date.now();
  if (jagoanproject.bjcd[m.sender] && now < jagoanproject.bjcd[m.sender]) {
    const sisa = Math.ceil((jagoanproject.bjcd[m.sender] - now) / 1e3);
    const jam = Math.floor(sisa / 3600);
    const menit = Math.floor(sisa % 3600 / 60);
    const detik = sisa % 60;
    return m.reply(`Anda menang sebelumnya jadi kena cooldown 1 jam.
Sisa cooldown: *${jam} jam ${menit} menit ${detik} detik*`);
  } else if (jagoanproject.bjcd[m.sender] && now >= jagoanproject.bjcd[m.sender]) {
    delete jagoanproject.bjcd[m.sender];
  }
  const toRupiah = (num) => {
    num = Number(num) || 0;
    return "Rp. " + num.toLocaleString("id-ID");
  };
  const THUMB_WIN = "https://thumbs.dreamstime.com/b/jackpot-slots-icons-slot-sign-machine-night-vegas-vector-illustration-398753517.jpg";
  const THUMB_LOSE = "https://st4.depositphotos.com/5777490/29768/v/450/depositphotos_297685432-stock-illustration-you-lose-casino-loss-slot.jpg";
  const USER_WIN_RATE = 0.2;
  const DRAW_RATE = 0.5;
  const rollOutcome = () => {
    const r = Math.random();
    if (r < USER_WIN_RATE) return "WIN";
    if (r < USER_WIN_RATE + DRAW_RATE) return "DRAW";
    return "LOSE";
  };
  try {
    const cards = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    const calculateTotal = (hand) => {
      let total = 0;
      let aceCount = 0;
      for (const c of hand) {
        if (c === "A") {
          total += 11;
          aceCount++;
        } else if (c === "K" || c === "Q" || c === "J") {
          total += 10;
        } else {
          total += parseInt(c);
        }
      }
      while (aceCount > 0 && total > 21) {
        total -= 10;
        aceCount--;
      }
      return total;
    };
    const pickRandomCard = () => cards[Math.floor(Math.random() * cards.length)];
    const pickDealerCardBiased = (dealerHand, playerTotal2, targetOutcome2) => {
      const scored = cards.map((c) => {
        const testHand = dealerHand.slice();
        testHand.push(c);
        const t = calculateTotal(testHand);
        let score = Math.random() * 0.15;
        if (playerTotal2 > 21) {
          return { c, t, score: score + Math.random() };
        }
        if (targetOutcome2 === "LOSE") {
          if (t > 21) score -= 5;
          else {
            if (t >= 17) score += 0.7;
            if (t > playerTotal2) score += 1.2;
            score += t / 21 * 0.6;
          }
        } else if (targetOutcome2 === "WIN") {
          if (t > 21) score += 2;
          else {
            if (t < playerTotal2) score += 1;
            if (t >= 17 && t < playerTotal2) score += 0.6;
            score -= t / 21 * 0.4;
          }
        } else {
          if (t > 21) score -= 4;
          else {
            const diff = Math.abs(playerTotal2 - t);
            score += 1.2 - diff / 21;
            if (t === playerTotal2) score += 1.2;
            if (t >= 17) score += 0.4;
          }
        }
        return { c, t, score };
      });
      scored.sort((a, b) => b.score - a.score);
      const top = scored.slice(0, 4);
      return top[Math.floor(Math.random() * top.length)].c;
    };
    const dealerPlay = (dealerHand, playerTotal2, targetOutcome2) => {
      const MAX_DEALER_CARDS = 8;
      let hand = dealerHand.slice();
      while (calculateTotal(hand) < 17 && hand.length < MAX_DEALER_CARDS) {
        const next = pickDealerCardBiased(hand, playerTotal2, targetOutcome2);
        hand.push(next);
      }
      return hand;
    };
    const sendResultMessage = (resultType, resultText, playerTotal2, dealerTotal, playerHand, dealerHand) => {
      const thumb = resultType === "LOSE" ? THUMB_LOSE : THUMB_WIN;
      let message = `*\u2022 H A S I L - B L A C K J A C K*

`;
      message += `\u256D\u2500\u2500 \u2022
`;
      message += `\u2502 \u25E6 *Kartu Kamu:* ${playerHand.join(", ")}
`;
      message += `\u2502 \u25E6 *Total Kamu:* ${playerTotal2}
`;
      message += `\u251C\u2500 \u2022
`;
      message += `\u2502 \u25E6 *Kartu Komputer:* ${dealerHand.join(", ")}
`;
      message += `\u2502 \u25E6 *Total Komputer:* ${dealerTotal}
`;
      message += `\u2570\u2500\u2500 \u2022

`;
      message += resultText;
      jagoanproject.reply(m.chat, message, m, {
        contextInfo: {
          extendedPreview: {
            title: "C A S I N O",
            body: resultType === "LOSE" ? "Rungkat \u{1F635}" : "Slot gacor \u{1F525}",
            thumbnailUrl: thumb,
            sourceUrl: "",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      });
    };
    const bet = parseInt(text);
    if (isNaN(bet) || bet <= 0) {
      return m.reply(`Masukkan Jumlah!

Contoh: *${usedPrefix + command} 1000*`);
    }
    if (global.db.data.users[m.sender].money < bet) {
      return m.reply(`Money kamu tidak mencukupi.
Uang kamu: *${toRupiah(global.db.data.users[m.sender].money)}*`);
    }
    let playerCards = [pickRandomCard(), pickRandomCard()];
    let dealerCards = [pickRandomCard()];
    const targetOutcome = rollOutcome();
    jagoanproject.bj[m.sender] = {
      playerCards,
      dealerCards,
      bet,
      targetOutcome,
      timeout: setTimeout(() => {
        const { bet: bet2 } = jagoanproject.bj[m.sender];
        global.db.data.users[m.sender].money -= bet2;
        m.reply(`\u23F0 Waktu habis!
Taruhan kamu hangus sebesar *${toRupiah(bet2)}*`);
        delete jagoanproject.bj[m.sender];
      }, 6e4)
    };
    const playerTotal = calculateTotal(playerCards);
    let msg = `*\u2022 B L A C K J A C K*

`;
    msg += `\u256D\u2500\u2500 \u2022
`;
    msg += `\u2502 \u25E6 *Kartu Kamu:* ${playerCards.join(", ")}
`;
    msg += `\u2502 \u25E6 *Total Kamu:* ${playerTotal}
`;
    msg += `\u251C\u2500 \u2022
`;
    msg += `\u2502 \u25E6 *Kartu Komputer:* ${dealerCards[0]}, ?
`;
    msg += `\u2502 \u25E6 *Taruhan:* ${toRupiah(bet)}
`;
    msg += `\u2570\u2500\u2500 \u2022

`;
    msg += `Ketik *hit* untuk mengambil kartu tambahan.
`;
    msg += `Ketik *stand* untuk mengakhiri giliran.`;
    jagoanproject.reply(m.chat, msg, m, {
      contextInfo: {
        extendedPreview: {
          title: "C A S I N O",
          body: "Slot gacor",
          thumbnailUrl: "https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1772009319273.jpeg",
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    });
  } catch (e) {
    console.error(e);
    jagoanproject.reply(m.chat, "Terjadi kesalahan saat menjalankan game Blackjack.", m);
    if (m.sender in jagoanproject.bj) {
      let { timeout } = jagoanproject.bj[m.sender];
      clearTimeout(timeout);
      delete jagoanproject.bj[m.sender];
      return true;
    }
  }
}
jagoanprojectt.before = async (m, { jagoanproject }) => {
  jagoanproject.bj = jagoanproject.bj ? jagoanproject.bj : {};
  jagoanproject.bjcd = jagoanproject.bjcd ? jagoanproject.bjcd : {};
  if (!(m.sender in jagoanproject.bj)) return;
  if (m.isZapo) return;
  const toRupiah = (num) => {
    num = Number(num) || 0;
    return "Rp. " + num.toLocaleString("id-ID");
  };
  const THUMB_WIN = "https://thumbs.dreamstime.com/b/jackpot-slots-icons-slot-sign-machine-night-vegas-vector-illustration-398753517.jpg";
  const THUMB_LOSE = "https://st4.depositphotos.com/5777490/29768/v/450/depositphotos_297685432-stock-illustration-you-lose-casino-loss-slot.jpg";
  const cards = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
  const calculateTotal = (hand) => {
    let total = 0;
    let aceCount = 0;
    for (const c of hand) {
      if (c === "A") {
        total += 11;
        aceCount++;
      } else if (c === "K" || c === "Q" || c === "J") {
        total += 10;
      } else total += parseInt(c);
    }
    while (aceCount > 0 && total > 21) {
      total -= 10;
      aceCount--;
    }
    return total;
  };
  const pickRandomCard = () => cards[Math.floor(Math.random() * cards.length)];
  const pickDealerCardBiased = (dealerHand, playerTotal, targetOutcome2) => {
    const scored = cards.map((c) => {
      const testHand = dealerHand.slice();
      testHand.push(c);
      const t = calculateTotal(testHand);
      let score = Math.random() * 0.15;
      if (playerTotal > 21) {
        return { c, t, score: score + Math.random() };
      }
      if (targetOutcome2 === "LOSE") {
        if (t > 21) score -= 5;
        else {
          if (t >= 17) score += 0.7;
          if (t > playerTotal) score += 1.2;
          score += t / 21 * 0.6;
        }
      } else if (targetOutcome2 === "WIN") {
        if (t > 21) score += 2;
        else {
          if (t < playerTotal) score += 1;
          if (t >= 17 && t < playerTotal) score += 0.6;
          score -= t / 21 * 0.4;
        }
      } else {
        if (t > 21) score -= 4;
        else {
          const diff = Math.abs(playerTotal - t);
          score += 1.2 - diff / 21;
          if (t === playerTotal) score += 1.2;
          if (t >= 17) score += 0.4;
        }
      }
      return { c, t, score };
    });
    scored.sort((a, b) => b.score - a.score);
    const top = scored.slice(0, 4);
    return top[Math.floor(Math.random() * top.length)].c;
  };
  const dealerPlay = (dealerHand, playerTotal, targetOutcome2) => {
    const MAX_DEALER_CARDS = 8;
    let hand = dealerHand.slice();
    while (calculateTotal(hand) < 17 && hand.length < MAX_DEALER_CARDS) {
      const next = pickDealerCardBiased(hand, playerTotal, targetOutcome2);
      hand.push(next);
    }
    return hand;
  };
  const sendResultMessage = (resultType, resultText, playerTotal, dealerTotal, playerHand, dealerHand) => {
    const thumb = resultType === "LOSE" ? THUMB_LOSE : THUMB_WIN;
    let message = `*\u2022 H A S I L - B L A C K J A C K*

`;
    message += `\u256D\u2500\u2500 \u2022
`;
    message += `\u2502 \u25E6 *Kartu Kamu:* ${playerHand.join(", ")}
`;
    message += `\u2502 \u25E6 *Total Kamu:* ${playerTotal}
`;
    message += `\u251C\u2500 \u2022
`;
    message += `\u2502 \u25E6 *Kartu Komputer:* ${dealerHand.join(", ")}
`;
    message += `\u2502 \u25E6 *Total Komputer:* ${dealerTotal}
`;
    message += `\u2570\u2500\u2500 \u2022

`;
    message += resultText;
    jagoanproject.reply(m.chat, message, m, {
      contextInfo: {
        extendedPreview: {
          title: "C A S I N O",
          body: resultType === "LOSE" ? "Rungkat \u{1F635}" : "Slot gacor \u{1F525}",
          thumbnailUrl: thumb,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    });
  };
  const bjData = jagoanproject.bj[m.sender];
  const { timeout, bet, targetOutcome } = bjData;
  let playerCards = bjData.playerCards;
  let dealerCards = bjData.dealerCards;
  const txt = (m.msg?.selectedDisplayText ? m.msg.selectedDisplayText : m.text ? m.text : "").toLowerCase();
  if (txt !== "stand" && txt !== "hit") return;
  try {
    if (txt === "hit") {
      playerCards.push(pickRandomCard());
      const playerTotal = calculateTotal(playerCards);
      if (playerTotal > 21) {
        const dealerTotalNow = calculateTotal(dealerCards);
        sendResultMessage("LOSE", `*Kamu kalah! Total kartu melebihi 21.*
*-${toRupiah(bet)} uang*`, playerTotal, dealerTotalNow, playerCards, dealerCards);
        global.db.data.users[m.sender].money -= bet;
        clearTimeout(timeout);
        delete jagoanproject.bj[m.sender];
        return;
      }
      let msg = `*\u2022 B L A C K J A C K*

`;
      msg += `\u256D\u2500\u2500 \u2022
`;
      msg += `\u2502 \u25E6 *Kartu Kamu:* ${playerCards.join(", ")}
`;
      msg += `\u2502 \u25E6 *Total Kamu:* ${playerTotal}
`;
      msg += `\u251C\u2500 \u2022
`;
      msg += `\u2502 \u25E6 *Kartu Komputer:* ${dealerCards[0]}, ?
`;
      msg += `\u2502 \u25E6 *Taruhan:* ${toRupiah(bet)}
`;
      msg += `\u2570\u2500\u2500 \u2022

`;
      msg += `Ketik *hit* untuk mengambil kartu tambahan.
`;
      msg += `Ketik *stand* untuk mengakhiri giliran.`;
      jagoanproject.reply(m.chat, msg, m, {
        contextInfo: {
          extendedPreview: {
            title: "C A S I N O",
            body: "Slot gacor",
            thumbnailUrl: "https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1772009319273.jpeg",
            sourceUrl: "",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      });
      return;
    }
    if (txt === "stand") {
      const playerTotal = calculateTotal(playerCards);
      dealerCards = dealerPlay(dealerCards, playerTotal, targetOutcome);
      const dealerTotal = calculateTotal(dealerCards);
      let resultType = "DRAW";
      let resultText = "";
      if (playerTotal > 21) {
        resultType = "LOSE";
        resultText = `*Kamu kalah! Total kartu melebihi 21.*
*-${toRupiah(bet)} uang*`;
        global.db.data.users[m.sender].money -= bet;
      } else if (dealerTotal > 21) {
        resultType = "WIN";
        resultText = `*Kamu menang! Total kartu Komputer melebihi 21.*
*+${toRupiah(bet)} uang*`;
        global.db.data.users[m.sender].money += bet;
        jagoanproject.bjcd[m.sender] = Date.now() + 36e5;
      } else if (playerTotal > dealerTotal) {
        resultType = "WIN";
        resultText = `*Kamu menang!*
*+${toRupiah(bet)} uang*`;
        global.db.data.users[m.sender].money += bet;
        jagoanproject.bjcd[m.sender] = Date.now() + 36e5;
      } else if (playerTotal < dealerTotal) {
        resultType = "LOSE";
        resultText = `*Kamu kalah!*
*-${toRupiah(bet)} uang*`;
        global.db.data.users[m.sender].money -= bet;
      } else {
        resultType = "DRAW";
        resultText = `*Hasilnya SERI bosa, gak ada yang menang!*`;
      }
      sendResultMessage(resultType, resultText, playerTotal, dealerTotal, playerCards, dealerCards);
      clearTimeout(timeout);
      delete jagoanproject.bj[m.sender];
      return;
    }
  } catch (e) {
    console.error(e);
    jagoanproject.reply(m.chat, "Terjadi kesalahan saat menjalankan game Blackjack.", m);
    clearTimeout(timeout);
    delete jagoanproject.bj[m.sender];
    return true;
  }
};
jagoanprojectt.command = jagoanprojectt.help = ["blackjack", "bj"];
jagoanprojectt.tags = ["game"];
jagoanprojectt.register = true;
jagoanprojectt.limit = false;
var game_blackjack_default = jagoanprojectt;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
