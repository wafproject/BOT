/**
 * game/tebakbendera.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/game/tebakbendera",
  "command": [
    "tebakbendera"
  ],
  "kind": "game",
  "category": "game"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
