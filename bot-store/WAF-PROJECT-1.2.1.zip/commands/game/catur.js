/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - catur.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_catur_exports = {};
__export(game_catur_exports, {
  default: () => game_catur_default
});
module.exports = __toCommonJS(game_catur_exports);
var __chess_js_1 = __toESM(require("chess.js"));
var __zapo_2 = __toESM(require("../../lib/jagoan/simple.js"));
var import_jimp_compat = __toESM(require("../../lib/jagoan/function/jimp-compat.js"));
const { Chess } = __chess_js_1;
const { generateWAMessageFromContent, proto } = __zapo_2;
const GAME_TIMEOUT = 18e4;
const TARUHAN_MONEY = 5e4;
let handler = async (m, { jagoanproject, text, usedPrefix }) => {
  jagoanproject.catur = jagoanproject.catur || {};
  const ct = jagoanproject.catur;
  if (!global.db.data.users[m.sender]) global.db.data.users[m.sender] = { money: 0 };
  let user = global.db.data.users[m.sender];
  const cmd = text?.toLowerCase();
  if (!text || cmd === "create") {
    if (ct[m.chat]) return m.reply("\u203C\uFE0F *GAME SEDANG BERLANGSUNG*");
    if (user.money < TARUHAN_MONEY) return m.reply(`\u274C Saldo kurang! Butuh *Rp${TARUHAN_MONEY.toLocaleString()}*`);
    ct[m.chat] = {
      chess: new Chess(),
      status: "\u231B MENUNGGU",
      host: m.sender,
      players: {},
      timer: null,
      totalBet: TARUHAN_MONEY
    };
    ct[m.chat].players[m.sender] = { color: "white" };
    user.money -= TARUHAN_MONEY;
    return jagoanproject.sendMessage(m.chat, {
      text: `\u{1F3E0} *ROOM CATUR DIBUAT*
\u{1F4B0} *Taruhan:* Rp${TARUHAN_MONEY.toLocaleString()}

Ketik *${usedPrefix}catur join* untuk melawan @${m.sender.split("@")[0]}`,
      mentions: [m.sender]
    }, { quoted: m });
  }
  if (cmd === "join") {
    if (!ct[m.chat]) return m.reply("\u203C\uFE0F *ROOM TIDAK DITEMUKAN*");
    if (m.sender === ct[m.chat].host) return m.reply("\u203C\uFE0F Kamu sudah di dalam.");
    if (Object.keys(ct[m.chat].players).length >= 2) return m.reply("\u203C\uFE0F Room penuh.");
    if (user.money < TARUHAN_MONEY) return m.reply(`\u274C Saldo kamu kurang.`);
    ct[m.chat].players[m.sender] = { color: "black" };
    ct[m.chat].status = "\u{1F3AF} BERMAIN";
    ct[m.chat].totalBet += TARUHAN_MONEY;
    user.money -= TARUHAN_MONEY;
    await m.reply(`\u{1F3AE} *GAME DIMULAI*
\u{1F4B0} *Total Hadiah:* Rp${ct[m.chat].totalBet.toLocaleString()}
\u23F0 *Limit:* 3 Menit`);
    startAFKTimer(m, jagoanproject.catur, jagoanproject);
    return sendBoard(m, jagoanproject.catur, jagoanproject);
  }
  if (cmd === "nyerah" || cmd === "menyerah") {
    const room = ct[m.chat];
    if (!room || room.status !== "\u{1F3AF} BERMAIN") return m.reply("\u274C Tidak ada game aktif.");
    if (!room.players[m.sender]) return m.reply("\u274C Kamu bukan pemain.");
    const winner = Object.keys(room.players).find((id) => id !== m.sender);
    global.db.data.users[winner].money += room.totalBet;
    await jagoanproject.sendMessage(m.chat, {
      text: `\u{1F3F3}\uFE0F *MENYERAH!*

@${m.sender.split("@")[0]} menyerah.
\u{1F3C6} Pemenang: @${winner.split("@")[0]}
\u{1F4B0} Hadiah: *Rp${room.totalBet.toLocaleString()}*`,
      mentions: [m.sender, winner]
    }, { quoted: m });
    if (room.timer) clearTimeout(room.timer);
    delete ct[m.chat];
    return;
  }
  if (cmd === "delete") {
    if (ct[m.chat] && ct[m.chat].timer) clearTimeout(ct[m.chat].timer);
    delete ct[m.chat];
    return m.reply("\u2705 Room dihapus.");
  }
};
handler.before = async (m, { jagoanproject }) => {
  jagoanproject.catur = jagoanproject.catur || {};
  let ct = jagoanproject.catur[m.chat];
  if (!ct || ct.status !== "\u{1F3AF} BERMAIN" || !m.text) return;
  if (m.text.toLowerCase() === "nyerah" || m.text.toLowerCase() === "menyerah") {
    if (ct.players[m.sender]) {
      const winner = Object.keys(ct.players).find((id) => id !== m.sender);
      global.db.data.users[winner].money += ct.totalBet;
      await jagoanproject.sendMessage(m.chat, {
        text: `\u{1F3F3}\uFE0F *MENYERAH!*

@${m.sender.split("@")[0]} menyerah.
\u{1F3C6} Pemenang: @${winner.split("@")[0]}
\u{1F4B0} Hadiah: *Rp${ct.totalBet.toLocaleString()}*`,
        mentions: [m.sender, winner]
      });
      if (ct.timer) clearTimeout(ct.timer);
      delete jagoanproject.catur[m.chat];
      return;
    }
  }
  const game = ct.chess;
  const turnColor = game.turn() === "w" ? "white" : "black";
  if (!ct.players[m.sender] || ct.players[m.sender].color !== turnColor) return;
  const moveRegex = /^[a-h][1-8]\s?[a-h][1-8]$/i;
  if (!moveRegex.test(m.text)) return;
  let moveInput = m.text.toLowerCase().replace(/\s/g, "");
  let from = moveInput.slice(0, 2);
  let to = moveInput.slice(2, 4);
  try {
    if (game.move({ from, to, promotion: "q" })) {
      if (ct.timer) clearTimeout(ct.timer);
      if (game.isGameOver()) {
        handleWin(m, jagoanproject.catur, jagoanproject);
      } else {
        await sendBoard(m, jagoanproject.catur, jagoanproject);
        startAFKTimer(m, jagoanproject.catur, jagoanproject);
      }
    }
  } catch (e) {
    m.reply("\u274C Langkah ilegal!");
  }
};
function startAFKTimer(m, ct, jagoanproject) {
  const room = ct[m.chat];
  if (!room) return;
  if (room.timer) clearTimeout(room.timer);
  room.timer = setTimeout(async () => {
    if (!ct[m.chat]) return;
    const turnColor = room.chess.turn() === "w" ? "white" : "black";
    const loser = Object.keys(room.players).find((id) => room.players[id].color === turnColor);
    const winner = Object.keys(room.players).find((id) => id !== loser);
    if (winner) {
      global.db.data.users[winner].money += room.totalBet;
      await jagoanproject.sendMessage(m.chat, {
        text: `\u23F0 *WAKTU HABIS!*

@${loser.split("@")[0]} AFK.
\u{1F3C6} Pemenang: @${winner.split("@")[0]}
\u{1F4B0} Hadiah: *Rp${room.totalBet.toLocaleString()}*`,
        mentions: [loser, winner]
      });
    }
    delete ct[m.chat];
  }, GAME_TIMEOUT);
}
async function sendBoard(m, ct, jagoanproject) {
  const room = ct[m.chat];
  const game = room.chess;
  const fen = game.fen().split(" ")[0];
  const nextPlayer = Object.keys(room.players).find((id) => room.players[id].color === (game.turn() === "w" ? "white" : "black"));
  const boardUrl = `https://chessboardimage.com/${fen}.png?size=600&coordinates=true`;
  try {
    const img = await import_jimp_compat.default.read(boardUrl);
    const buffer = await img.getBufferAsync(import_jimp_compat.default.MIME_PNG);
    await jagoanproject.sendMessage(m.chat, {
      image: buffer,
      caption: `\u265F\uFE0F *GILIRAN:* @${nextPlayer.split("@")[0]}
\u{1F4B0} *Hadiah:* Rp${room.totalBet.toLocaleString()}
\u23F0 *Limit:* 3 Menit`,
      mentions: [nextPlayer]
    }, { quoted: m });
  } catch (e) {
    m.reply("\u274C Gagal muat papan.");
  }
}
function handleWin(m, ct, jagoanproject) {
  const room = ct[m.chat];
  const game = room.chess;
  let winner = null;
  if (game.isCheckmate()) {
    const winColor = game.turn() === "w" ? "black" : "white";
    winner = Object.keys(room.players).find((id) => room.players[id].color === winColor);
  }
  if (winner) {
    global.db.data.users[winner].money += room.totalBet;
    jagoanproject.sendMessage(m.chat, {
      text: `\u{1F389} *SKAKMAT!*
\u{1F3C6} @${winner.split("@")[0]} menang \u{1F4B0} *Rp${room.totalBet.toLocaleString()}*`,
      mentions: [winner]
    });
  } else {
    Object.keys(room.players).forEach((id) => global.db.data.users[id].money += room.totalBet / 2);
    m.reply("\u{1F91D} Game Draw! Modal balik.");
  }
  if (room.timer) clearTimeout(room.timer);
  delete ct[m.chat];
}
handler.command = ["catur"];
handler.tags = ["game"];
handler.help = ["catur"];
var game_catur_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
