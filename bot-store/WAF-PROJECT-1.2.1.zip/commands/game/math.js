/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - math.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_math_exports = {};
__export(game_math_exports, {
  default: () => game_math_default
});
module.exports = __toCommonJS(game_math_exports);
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  jagoanproject.math = jagoanproject.math || {};
  let id = m.chat;
  if (/^surender$/i.test(command)) {
    if (!(id in jagoanproject.math)) {
      return jagoanproject.reply(m.chat, "\u274C Tidak ada soal yang sedang berlangsung.", m);
    }
    let mathData = jagoanproject.math[id];
    jagoanproject.reply(
      m.chat,
      `\u{1F3F3}\uFE0F *Menyerah!*
Jawaban yang benar adalah: *${formatNumber(mathData.result)}*`,
      m
    );
    clearTimeout(mathData.timeout);
    delete jagoanproject.math[id];
    return;
  }
  if (args.length < 1) throw `
\u{1F4DA} *Mode tersedia:* ${Object.keys(modes).join(" | ")}

\u{1F4A1} *Contoh:* ${usedPrefix}math epic
`.trim();
  let mode = args[0].toLowerCase();
  if (!(mode in modes)) throw `
\u{1F4DA} *Mode tersedia:* ${Object.keys(modes).join(" | ")}

\u{1F4A1} *Contoh:* ${usedPrefix}math epic
`.trim();
  if (id in jagoanproject.math) {
    return jagoanproject.reply(
      m.chat,
      "\u26A0\uFE0F Soal sebelumnya belum terjawab!",
      jagoanproject.math[id].message
    );
  }
  let math = genMath(mode);
  let rewardRange = getMoneyRangeByMode(mode);
  let msg = await jagoanproject.reply(
    m.chat,
    `\u{1F9EE} *TANTANGAN MATEMATIKA!*

\u27A1\uFE0F *Soal:* ${math.str}
\u23F3 *Waktu:* ${(math.time / 1e3).toFixed(0)} detik
\u{1F381} *Bonus:* +${math.bonus} XP
\u{1F4B0} *Hadiah Uang:* ${rewardRange.min.toLocaleString("id-ID")} - ${rewardRange.max.toLocaleString("id-ID")}
\u{1F465} *Setiap orang punya 3 kesempatan!*

Ketik jawabanmu tanpa reply.
Desimal bisa pakai *titik* atau *koma*.
Menyerah? ketik *.surender*`,
    m
  );
  jagoanproject.math[id] = {
    message: msg,
    ...math,
    users: {},
    // { userJid: { attempts: 0 } }
    start: Date.now(),
    timeout: setTimeout(() => {
      if (jagoanproject.math[id]) {
        jagoanproject.reply(
          m.chat,
          `\u23F0 *Waktu Habis!*
Jawaban yang benar: *${formatNumber(math.result)}*`,
          jagoanproject.math[id].message
        );
        delete jagoanproject.math[id];
      }
    }, math.time)
  };
};
handler.help = ["math [mode]", "surender"];
handler.tags = ["game"];
handler.command = /^(math|surender)$/i;
handler.group = true;
handler.register = true;
handler.limit = false;
handler.before = async (m, { jagoanproject }) => {
  jagoanproject.math = jagoanproject.math || {};
  let id = m.chat;
  if (m.fromMe) return;
  if (!(id in jagoanproject.math)) return;
  if (!m.text) return;
  let game = jagoanproject.math[id];
  let userKey = m.sender;
  let userAnswerRaw = m.text.trim();
  if (/^[./#!]/.test(userAnswerRaw)) return;
  if (!(userKey in game.users)) {
    game.users[userKey] = { attempts: 0 };
  }
  let isCorrect = isSameAnswer(userAnswerRaw, game.result);
  if (isCorrect) {
    let money = calcSpeedMoneyReward(
      Date.now() - game.start,
      game.time,
      game.mode
    );
    try {
      let user = global.db.data.users[m.sender];
      if (user) {
        user.exp = (user.exp || 0) + game.bonus;
        user.money = (user.money || 0) + money;
      }
    } catch (e) {
    }
    jagoanproject.reply(
      m.chat,
      `\u2705 *Jawaban Benar!* @${userKey.split("@")[0]} berhasil!
\u{1F9E0} *Jawaban:* ${formatNumber(game.result)}
\u2728 *Bonus XP:* +${game.bonus}
\u{1F4B0} *Uang:* +${money.toLocaleString("id-ID")}`,
      m,
      { mentions: [userKey] }
    );
    clearTimeout(game.timeout);
    delete jagoanproject.math[id];
    return true;
  }
  game.users[userKey].attempts += 1;
  let attempts = game.users[userKey].attempts;
  let maxAttempts = 3;
  let remaining = maxAttempts - attempts;
  if (attempts >= maxAttempts) {
    jagoanproject.reply(
      m.chat,
      `\u274C @${userKey.split("@")[0]} kehabisan kesempatan!
Jawaban yang benar: *${formatNumber(game.result)}*`,
      m,
      { mentions: [userKey] }
    );
    clearTimeout(game.timeout);
    delete jagoanproject.math[id];
    return true;
  }
  jagoanproject.reply(
    m.chat,
    `\u274C *Salah!* @${userKey.split("@")[0]}
Sisa kesempatan: *${remaining}*`,
    m,
    { mentions: [userKey] }
  );
  return true;
};
var game_math_default = handler;
let modes = {
  master: [-3, 3, -3, 3, "+-", 15e3, 10],
  gm: [-10, 10, -10, 10, "*/+-", 2e4, 40],
  epic: [-40, 40, -20, 20, "*/", 4e4, 150],
  legend: [-100, 100, -70, 70, "*/", 3e4, 350],
  mythic: [-999999, 999999, -999999, 999999, "*/", 4e4, 666],
  glory: [-99999999999, 99999999999, -99999999999, 999999999999, "*/", 6e4, 888],
  platinum: [-999999999999999, 999999999999999, -999, 999, "/", 9e4, 999]
};
let operators = {
  "+": "+",
  "-": "-",
  "*": "\xD7",
  "/": "\xF7"
};
function genMath(mode) {
  let [a1, a2, b1, b2, ops, time, bonus] = modes[mode];
  let a = randomInt(a1, a2);
  let b = randomInt(b1, b2);
  let op = pickRandom([...ops]);
  if (op === "/") {
    while (b === 0) b = randomInt(b1, b2);
  }
  let result = new Function(
    `return ${a} ${op.replace("/", "*")} ${b < 0 ? `(${b})` : b}`
  )();
  if (op == "/") [a, result] = [result, a];
  result = roundSmart(result);
  return {
    str: `${formatNumber(a)} ${operators[op]} ${formatNumber(b)}`,
    mode,
    time,
    bonus,
    result
  };
}
function randomInt(from, to) {
  if (from > to) [from, to] = [to, from];
  from = Math.floor(from);
  to = Math.floor(to);
  return Math.floor((to - from) * Math.random() + from);
}
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}
function roundSmart(num) {
  return Number(Number(num).toFixed(2));
}
function normalizeNumberInput(value) {
  return String(value || "").trim().replace(/\s+/g, "").replace(",", ".");
}
function isSameAnswer(input, result) {
  let normalized = normalizeNumberInput(input);
  if (!normalized) return false;
  let parsed = Number(normalized);
  if (Number.isNaN(parsed)) return false;
  return Math.abs(parsed - Number(result)) < 1e-7;
}
function formatNumber(num) {
  let n = Number(num);
  if (Number.isInteger(n)) return String(n);
  return String(n).replace(".", ",");
}
function getMoneyRangeByMode(mode) {
  const ranges = {
    master: { min: 500, max: 1500 },
    gm: { min: 1e3, max: 2500 },
    epic: { min: 2e3, max: 5e3 },
    legend: { min: 4e3, max: 8e3 },
    mythic: { min: 8e3, max: 15e3 },
    glory: { min: 12e3, max: 25e3 },
    platinum: { min: 2e4, max: 4e4 }
  };
  return ranges[mode] || { min: 2e3, max: 5e3 };
}
function calcSpeedMoneyReward(elapsedMs, maxTimeMs, mode) {
  const { min, max } = getMoneyRangeByMode(mode);
  const t = Math.max(0, Math.min(1, elapsedMs / maxTimeMs));
  const speed = 1 - t;
  const r = Math.random();
  const bias = (r + speed) / 2;
  return Math.floor(min + bias * (max - min));
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
