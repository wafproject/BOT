/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - suit_ans.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_suit_ans_exports = {};
__export(game_suit_ans_exports, {
  default: () => game_suit_ans_default
});
module.exports = __toCommonJS(game_suit_ans_exports);
let handler = (m) => m;
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
handler.before = async function(m, { jagoanproject }) {
  this.suit = this.suit || {};
  if (typeof db.data.users[m.sender].suit !== "number") db.data.users[m.sender].suit = 0;
  if (typeof db.data.users[m.sender].suitLoseStreak !== "number") db.data.users[m.sender].suitLoseStreak = 0;
  let room = Object.values(this.suit).find((room2) => room2.id && room2.status && [room2.p, room2.p2].includes(m.sender));
  let mmr = rwd(20, 30);
  if (room) {
    let win = "";
    let tie = false;
    if (m.sender == room.p2 && /^(acc(ept)?|terima|gas|oke?|no|yes|tolak|gamau|nanti|ga(k.)?bisa)/i.test(m.text) && m.isGroup && room.status == "wait") {
      if (/^(no?|tolak|gamau|nanti|ga(k.)?bisa)/i.test(m.text)) {
        jagoanproject.reply(m.chat, `\u274C @${room.p2.split`@`[0]} menolak suit!!

> game suit dibatalkan`, m);
        delete this.suit[room.id];
        return true;
      }
      room.status = "play";
      room.asal = m.chat;
      clearTimeout(room.waktu);
      let botNumber = jagoanproject.user.jid.split("@")[0];
      m.reply(`\u{1F3AE} SUIT DIMULAI \u{1F3AE}

> silahkan pilih suit di room chat bot

\u{1F4CC} pilih suitmu disini :
wa.me/${botNumber}`);
      await delay(1500);
      if (!room.pilih) jagoanproject.reply(room.p, "\u{1F4CC} PILIH SUITMU :\n\n- batu\n- gunting\n- kertas\n\n> ketik pilihanmu tanpa reply chat!", m);
      await delay(1500);
      if (!room.pilih2) jagoanproject.reply(room.p2, "\u{1F4CC} PILIH SUITMU :\n\n- batu\n- gunting\n- kertas\n\n> ketik pilihanmu tanpa reply chat!", m);
      room.waktu_milih = setTimeout(() => {
        if (!room.pilih && !room.pilih2) jagoanproject.reply(room.asal, `\u{1F621} Kedua pemain tidak memilih

> game suit dibatalkan!`, m);
        else if (!room.pilih || !room.pilih2) {
          win = !room.pilih ? room.p2 : room.p;
          jagoanproject.reply(room.asal, `@${(room.pilih ? room.p2 : room.p).split`@`[0]} ga niat main! \u{1F621}

> game suit dibatalkan!`, m);
          db.data.users[win].exp += room.poin;
          db.data.users[win == room.p ? room.p2 : room.p].exp -= room.poin_lose;
        }
        delete this.suit[room.id];
      }, room.timeout);
    }
    let j = m.sender == room.p;
    let j2 = m.sender == room.p2;
    let reg = /^(gunting|batu|kertas)/i;
    if (j && reg.test(m.text) && !room.pilih && !m.isGroup) {
      room.pilih = reg.exec(m.text.toLowerCase())[0];
      room.text = m.text;
      m.reply(`\u2705 Kamu telah memilih

- ${m.text}${!room.pilih2 ? "\n\n> menunggu lawan memilih..." : ""}`);
    }
    if (j2 && reg.test(m.text) && !room.pilih2 && !m.isGroup) {
      room.pilih2 = reg.exec(m.text.toLowerCase())[0];
      room.text2 = m.text;
      m.reply(`\u2705 Kamu telah memilih

- ${m.text}${!room.pilih ? "\n\n> menunggu lawan memilih..." : ""}`);
    }
    if (room.pilih && room.pilih2) {
      clearTimeout(room.waktu_milih);
      const p = room.pilih;
      const p2 = room.pilih2;
      if (p === p2) tie = true;
      else if (p === "batu" && p2 === "gunting" || p === "gunting" && p2 === "kertas" || p === "kertas" && p2 === "batu") win = room.p;
      else win = room.p2;
      const pWin = win;
      const pLose = win === room.p ? room.p2 : room.p;
      if (!tie) {
        db.data.users[pWin].exp += room.poin;
        db.data.users[pLose].exp -= room.poin_lose;
        db.data.users[pWin].suit += mmr;
        db.data.users[pLose].suit -= mmr / 2;
        db.data.users[pWin].suitLoseStreak = 0;
        db.data.users[pLose].suitLoseStreak = (db.data.users[pLose].suitLoseStreak || 0) + 1;
        let loseStreak = db.data.users[pLose].suitLoseStreak;
        if (room.asal && loseStreak >= 3) {
          await jagoanproject.groupParticipantsUpdate(room.asal, [pLose], "remove").catch((e) => m.reply(`\u274C Gagal kick @${pLose.split("@")[0]} karena bot bukan admin.`, m));
          db.data.users[pLose].suitLoseStreak = 0;
          jagoanproject.reply(room.asal, `\u203C\uFE0F LOSE STREAK

- @${pLose.split`@`[0]} CUPU!!

> kalah 3x dan telah di kick!! \u{1F639}`, m);
        }
      }
      jagoanproject.reply(room.asal, `
\u{1F3AE} *HASIL SUIT* \u{1F3AE}

\u{1F9D1}\u{1F3FB}\u200D\u{1F9B0} player : @${room.p.split`@`[0]}
- ${room.text}
- ${tie ? "seri \u{1F62D}" : room.p === win ? "menang \u{1F973}" : "kalah \u{1F639}"}

\u{1F9D1}\u{1F3FB}\u200D\u{1F9B1} player : @${room.p2.split`@`[0]}
- ${room.text2}
- ${tie ? "seri \u{1F62D}" : room.p2 === win ? "menang \u{1F973}" : "kalah \u{1F639}"}
`.trim(), m);
      delete this.suit[room.id];
    }
  }
  return true;
};
handler.exp = 0;
handler.register = true;
handler.limit = false;
var game_suit_ans_default = handler;
function rwd(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
