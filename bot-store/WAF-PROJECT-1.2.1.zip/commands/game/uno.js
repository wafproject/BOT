/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - uno.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_uno_exports = {};
__export(game_uno_exports, {
  default: () => game_uno_default
});
module.exports = __toCommonJS(game_uno_exports);
let games = {};
const colors = ["red", "yellow", "green", "blue"];
const specialCards = ["skip", "reverse", "draw2", "wild", "wild4"];
function generateDeck() {
  let deck = [];
  for (let color of colors) {
    for (let i = 0; i <= 9; i++) {
      deck.push({ color, value: i.toString() });
      if (i !== 0) deck.push({ color, value: i.toString() });
    }
    for (let s of ["skip", "reverse", "draw2"]) {
      deck.push({ color, value: s });
      deck.push({ color, value: s });
    }
  }
  for (let i = 0; i < 4; i++) {
    deck.push({ color: "wild", value: "wild" });
    deck.push({ color: "wild", value: "wild4" });
  }
  return shuffle(deck);
}
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
function formatCard(c) {
  return c.color === "wild" ? `\u{1F308} ${c.value}` : `${c.color} ${c.value}`;
}
let handler = async (m, { jagoanproject, command, text, args }) => {
  let subcmd = (args[0] || "").toLowerCase();
  let game = Object.values(games).find((g) => g.players.includes(m.sender));
  let roomId = game ? game.origin : m.chat;
  switch (command) {
    case "uno": {
      if (subcmd === "create") {
        if (games[roomId]) return m.reply("\u274C Room sudah ada!");
        games[roomId] = {
          host: m.sender,
          players: [m.sender],
          hands: {},
          deck: generateDeck(),
          discard: [],
          turn: 0,
          started: false,
          origin: roomId
        };
        return m.reply("\u{1F3AE} Room UNO berhasil dibuat!\nKetik *.uno join* untuk bergabung.");
      }
      if (subcmd === "join") {
        game = games[roomId];
        if (!game) return m.reply("\u274C Belum ada room. Buat dulu dengan *.uno create*");
        if (game.started) return m.reply("\u274C Game sudah dimulai!");
        if (game.players.includes(m.sender)) return m.reply("\u274C Kamu sudah join.");
        game.players.push(m.sender);
        return m.reply("\u2705 Kamu join ke room UNO!");
      }
      if (subcmd === "start") {
        game = games[roomId];
        if (!game) return m.reply("\u274C Tidak ada room UNO.");
        if (m.sender !== game.host) return m.reply("\u274C Hanya host yang bisa start!");
        if (game.players.length < 2) return m.reply("\u274C Minimal 2 pemain!");
        game.started = true;
        for (let p of game.players) {
          game.hands[p] = [];
          for (let i = 0; i < 7; i++) {
            game.hands[p].push(game.deck.pop());
          }
          let cards = game.hands[p].map((c, i) => `[${i + 1}] ${formatCard(c)}`).join("\n");
          jagoanproject.sendMessage(p, { text: `\u{1F0CF} Kartu kamu:
${cards}

Gunakan: .uno play <nomor> [warna]` });
        }
        game.discard.push(game.deck.pop());
        return jagoanproject.sendMessage(game.origin, {
          text: `\u{1F389} *Game UNO dimulai!*

\u{1F0A0} Top card pertama: *${formatCard(game.discard.at(-1))}*
\u{1F449} Giliran pertama: @${game.players[0].split("@")[0]}

Gunakan perintah: .uno play <nomor> [warna]`,
          mentions: game.players
        });
      }
      if (subcmd === "cards") {
        if (!game) return m.reply("\u274C Tidak ada room.");
        if (!game.hands[m.sender]) return m.reply("\u274C Kamu tidak ikut game.");
        let cards = game.hands[m.sender].map((c, i) => `[${i + 1}] ${formatCard(c)}`).join("\n");
        return jagoanproject.sendMessage(m.sender, { text: `\u{1F0CF} Kartu kamu:
${cards}` });
      }
      if (subcmd === "status") {
        if (!game) return m.reply("\u274C Tidak ada room.");
        let playerList = game.players.map((p, i) => `${i === game.turn ? "\u{1F449}" : ""} @${p.split("@")[0]} (${game.hands[p].length} kartu)`).join("\n");
        return m.reply(
          `\u{1F3AE} Status UNO
Top card: ${formatCard(game.discard.at(-1))}

${playerList}`,
          { mentions: game.players }
        );
      }
      if (subcmd === "play") {
        if (!game) return m.reply("\u274C Tidak ada room.");
        if (!game.started) return m.reply("\u274C Game belum dimulai.");
        if (game.players[game.turn] !== m.sender) return m.reply("\u274C Bukan giliranmu!");
        let idx = parseInt(args[1]) - 1;
        if (isNaN(idx)) return m.reply("\u274C Masukkan nomor kartu.");
        let card = game.hands[m.sender][idx];
        if (!card) return m.reply("\u274C Nomor kartu tidak valid.");
        let top = game.discard.at(-1);
        if (card.color !== top.color && card.value !== top.value && card.color !== "wild") {
          return m.reply("\u274C Kartu tidak cocok dengan top card!");
        }
        game.hands[m.sender].splice(idx, 1);
        game.discard.push(card);
        if (card.color === "wild") {
          let newColor = (args[2] || "").toLowerCase();
          if (!colors.includes(newColor)) return m.reply("\u274C Pilih warna baru: red, yellow, green, blue");
          card.color = newColor;
        }
        if (game.hands[m.sender].length === 0) {
          delete games[roomId];
          return m.reply(
            `\u{1F389} UNO SELESAI!
Pemenang: @${m.sender.split("@")[0]}`,
            { mentions: [m.sender] }
          );
        }
        game.turn = (game.turn + 1) % game.players.length;
        return jagoanproject.sendMessage(game.origin, {
          text: `\u2705 @${m.sender.split("@")[0]} memainkan ${formatCard(card)}
\u{1F0A0} Top card baru: *${formatCard(card)}*
\u{1F449} Giliran berikutnya: @${game.players[game.turn].split("@")[0]}`,
          mentions: [m.sender, game.players[game.turn]]
        });
      }
      if (subcmd === "draw") {
        if (!game) return m.reply("\u274C Tidak ada room.");
        if (game.players[game.turn] !== m.sender) return m.reply("\u274C Bukan giliranmu!");
        let newCard = game.deck.pop();
        game.hands[m.sender].push(newCard);
        let cards = game.hands[m.sender].map((c, i) => `[${i + 1}] ${formatCard(c)}`).join("\n");
        jagoanproject.sendMessage(m.sender, { text: `\u{1F0CF} Kamu ambil 1 kartu: ${formatCard(newCard)}

Kartu kamu sekarang:
${cards}` });
        game.turn = (game.turn + 1) % game.players.length;
        return jagoanproject.sendMessage(game.origin, {
          text: `@${m.sender.split("@")[0]} ambil kartu.
\u{1F449} Giliran berikutnya: @${game.players[game.turn].split("@")[0]}`,
          mentions: [m.sender, game.players[game.turn]]
        });
      }
      if (subcmd === "leave") {
        if (!game) return m.reply("\u274C Tidak ada room.");
        if (!game.players.includes(m.sender)) return m.reply("\u274C Kamu tidak ikut game.");
        game.players = game.players.filter((p) => p !== m.sender);
        delete game.hands[m.sender];
        if (game.players.length < 2) {
          delete games[roomId];
          return m.reply("\u274C Game berakhir karena pemain kurang.");
        }
        return m.reply(`@${m.sender.split("@")[0]} keluar dari game.`, { mentions: [m.sender] });
      }
      return m.reply(
        `\u{1F3AE} *UNO MULTIPLAYER GAME*

\u{1F4DD} *Commands:*
\u2022 .uno create
\u2022 .uno join
\u2022 .uno start
\u2022 .uno play <nomor> [warna]
\u2022 .uno draw
\u2022 .uno cards
\u2022 .uno status
\u2022 .uno leave`
      );
    }
  }
};
handler.help = ["uno"];
handler.tags = ["game"];
handler.command = /^uno$/i;
handler.register = true;
handler.limit = false;
var game_uno_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
