/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - wwgc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_wwgc_exports = {};
__export(game_wwgc_exports, {
  default: () => game_wwgc_default
});
module.exports = __toCommonJS(game_wwgc_exports);
var import_werewolf = __toESM(require("../../lib/jagoan/lib/werewolf.js"));
const LOBBY_TIMEOUT_MS = Number(globalThis.__WW_LOBBY_TIMEOUT_MS || 10 * 60 * 1e3);
function ensureRoot() {
  if (!global.db) global.db = { data: {} };
  if (!global.db.data) global.db.data = {};
  if (!global.db.data.werewolf) global.db.data.werewolf = {};
  if (!global.db.data.werewolfDebug) global.db.data.werewolfDebug = [];
}
function ensureWWStore() {
  ensureRoot();
  return global.db.data.werewolf;
}
function ensureWWDebugStore() {
  ensureRoot();
  return global.db.data.werewolfDebug;
}
function ensureLobbyTimers() {
  if (!globalThis.__wwLobbyTimers) globalThis.__wwLobbyTimers = {};
  return globalThis.__wwLobbyTimers;
}
function safeJson(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}
function logWW(chat, event, meta = {}) {
  const logs = ensureWWDebugStore();
  const entry = {
    at: (/* @__PURE__ */ new Date()).toISOString(),
    chat,
    event,
    meta
  };
  logs.push(entry);
  if (logs.length > 300) logs.splice(0, logs.length - 300);
  if (chat) {
    const db = ensureWWStore();
    if (db[chat]) {
      const room = db[chat];
      room.debugLog = room.debugLog || [];
      room.debugLog.push(entry);
      if (room.debugLog.length > 100) room.debugLog.splice(0, room.debugLog.length - 100);
    }
  }
  console.log(`[WW][${entry.at}][${chat || "-"}][${event}] ${safeJson(meta)}`);
  return entry;
}
function clearLobbyTimeout(chat) {
  const timers = ensureLobbyTimers();
  if (timers[chat]) {
    clearTimeout(timers[chat]);
    delete timers[chat];
  }
}
function cleanupRoom(chat, reason, error = null) {
  const db = ensureWWStore();
  const room = db[chat];
  logWW(chat, "cleanup_room", {
    reason,
    hasRoom: !!room,
    error: error ? error.stack || error.message || String(error) : null
  });
  clearLobbyTimeout(chat);
  if (room) {
    room.runnerActive = false;
    room.starting = false;
  }
  delete db[chat];
}
function scheduleLobbyTimeout(chat, reason = "schedule") {
  const db = ensureWWStore();
  const room = db[chat];
  if (!room) return;
  clearLobbyTimeout(chat);
  if (room.status || room.starting || room.runnerActive) return;
  room.createdAt = room.createdAt || Date.now();
  room.lastLobbyActivityAt = Date.now();
  room.lobbyExpireAt = Date.now() + LOBBY_TIMEOUT_MS;
  logWW(chat, "lobby_timeout_scheduled", {
    reason,
    timeoutMs: LOBBY_TIMEOUT_MS,
    expireAt: room.lobbyExpireAt
  });
  const timers = ensureLobbyTimers();
  timers[chat] = setTimeout(() => {
    const current = ensureWWStore()[chat];
    if (!current) return;
    if (current.status || current.starting || current.runnerActive) return;
    cleanupRoom(chat, "lobby_timeout");
  }, LOBBY_TIMEOUT_MS);
}
function resumeSweepOnce() {
  if (globalThis.__wwResumeSweepStarted) return;
  globalThis.__wwResumeSweepStarted = true;
  let attempts = 0;
  const timer = setInterval(() => {
    attempts += 1;
    if (!global.db?.data) {
      if (attempts > 24) clearInterval(timer);
      return;
    }
    clearInterval(timer);
    ensureRoot();
    const db = ensureWWStore();
    const chats = Object.keys(db);
    if (!chats.length) return;
    for (const chat of chats) {
      const room = db[chat];
      if (!room) continue;
      const reason = room.status || room.runnerActive || room.starting ? "resume_cleanup_stale_active_room" : "resume_cleanup_stale_lobby_room";
      cleanupRoom(chat, reason);
    }
  }, 5e3);
}
resumeSweepOnce();
function makePlayer(id, sesi, number) {
  return {
    id,
    sesi,
    number,
    role: false,
    isdead: false,
    isvote: false,
    vote: 0,
    effect: [],
    status: true
  };
}
function createRoom(chat, host) {
  return {
    room: chat,
    host,
    status: false,
    iswin: null,
    cooldown: 0,
    day: 1,
    time: "malem",
    voting: false,
    seer: false,
    guardian: [],
    dead: [],
    player: [makePlayer(host, chat, 1)],
    starting: false,
    runnerActive: false,
    runnerToken: 0,
    debugLog: [],
    createdAt: Date.now(),
    lastLobbyActivityAt: Date.now(),
    lobbyExpireAt: Date.now() + LOBBY_TIMEOUT_MS
  };
}
function renumber(room) {
  room.player.forEach((p, i) => {
    p.number = i + 1;
    p.sesi = room.room;
  });
}
function formatStatus(room) {
  const status = room.status ? "berjalan" : "menunggu";
  const fase = room.time || "-";
  const host = room.host ? `@${room.host.split("@")[0]}` : "-";
  const players = room.player.map((p) => {
    const dead = p.isdead ? " \u2620\uFE0F" : "";
    const voted = room.voting && p.isvote ? " \u2705" : "";
    return `(${p.number}) @${p.id.split("@")[0]}${dead}${voted}`;
  }).join("\n") || "-";
  const lobbyInfo = !room.status ? `
Lobby expire: ${room.lobbyExpireAt ? new Date(room.lobbyExpireAt).toLocaleString("id-ID") : "-"}
Timeout: ${Math.floor(LOBBY_TIMEOUT_MS / 6e4)} menit` : "";
  return `*WEREWOLF STATUS*

Host: ${host}
Status: ${status}
Hari: ${room.day}
Fase: ${fase}
Player: ${room.player.length}
Runner: ${room.runnerActive ? "aktif" : "idle"}
Starting lock: ${room.starting ? "aktif" : "idle"}
Log room: ${(room.debugLog || []).length}${lobbyInfo}

${players}`;
}
function formatLogs(room) {
  const logs = (room?.debugLog || []).slice(-15);
  if (!logs.length) return "*WEREWOLF LOG*\n\nBelum ada log.";
  return "*WEREWOLF LOG*\n\n" + logs.map((x) => {
    const time = x.at.replace("T", " ").replace("Z", "");
    return `[${time}] ${x.event} ${Object.keys(x.meta || {}).length ? "- " + safeJson(x.meta) : ""}`;
  }).join("\n");
}
function help(prefix) {
  return `*WEREWOLF*

${prefix}ww create  - buat room
${prefix}ww join    - gabung room
${prefix}ww start   - mulai game (min 4 player)
${prefix}ww vote 2  - voting saat fase voting
${prefix}ww leave   - keluar room
${prefix}ww status  - lihat status room
${prefix}ww log     - lihat debug log room
${prefix}ww end     - hapus room

Aksi role malam dilakukan di private chat dengan command *${prefix}wwpc*.`;
}
let handler = async (m, { jagoanproject, args, usedPrefix, isAdmin, isOwner }) => {
  ensureRoot();
  const db = ensureWWStore();
  const sub = (args[0] || "").toLowerCase();
  const room = db[m.chat];
  if (!sub) {
    return m.reply(help(usedPrefix));
  }
  switch (sub) {
    case "create":
    case "buat": {
      if (room) throw "Room werewolf di grup ini sudah ada.";
      if (import_werewolf.default.playerOnGame(m.sender, db)) throw "Kamu masih ada di room werewolf lain.";
      db[m.chat] = createRoom(m.chat, m.sender);
      logWW(m.chat, "room_created", { by: m.sender });
      scheduleLobbyTimeout(m.chat, "create");
      return m.reply(`Room werewolf berhasil dibuat.

Player 1: @${m.sender.split("@")[0]}
Suruh pemain lain ketik *${usedPrefix}ww join*`, null, { mentions: [m.sender] });
    }
    case "join": {
      if (!room) throw `Belum ada room. Buat dulu dengan *${usedPrefix}ww create*`;
      if (room.status || room.starting || room.runnerActive) throw "Game sudah/sedang dimulai, tidak bisa join.";
      if (import_werewolf.default.playerOnGame(m.sender, db)) throw "Kamu masih ada di room werewolf lain.";
      room.player.push(makePlayer(m.sender, m.chat, room.player.length + 1));
      room.lastLobbyActivityAt = Date.now();
      logWW(m.chat, "player_join", { by: m.sender, total: room.player.length });
      scheduleLobbyTimeout(m.chat, "join");
      return m.reply(`Berhasil join room werewolf sebagai player ${room.player.length}.`, null, { mentions: [m.sender] });
    }
    case "leave":
    case "keluar": {
      if (!room) throw "Tidak ada room werewolf di grup ini.";
      if (!import_werewolf.default.playerOnRoom(m.sender, m.chat, db)) throw "Kamu tidak ada di room ini.";
      if (room.status || room.starting || room.runnerActive) throw "Game sudah berjalan. Untuk menghindari room rusak, leave saat game berjalan dinonaktifkan.";
      import_werewolf.default.playerExit(m.chat, m.sender, db);
      if (!room.player.length) {
        cleanupRoom(m.chat, "last_player_left");
        return m.reply("Room werewolf dibubarkan karena tidak ada player tersisa.");
      }
      if (room.host === m.sender) room.host = room.player[0].id;
      renumber(room);
      room.lastLobbyActivityAt = Date.now();
      logWW(m.chat, "player_leave", { by: m.sender, total: room.player.length, newHost: room.host });
      scheduleLobbyTimeout(m.chat, "leave");
      return m.reply("Berhasil keluar dari room werewolf.");
    }
    case "start":
    case "mulai": {
      if (!room) throw `Belum ada room. Buat dulu dengan *${usedPrefix}ww create*`;
      if (room.starting) throw "Room sedang proses start. Tunggu sebentar.";
      if (room.runnerActive) throw "Game werewolf sudah punya runner aktif. Start ganda diblokir.";
      if (room.status) throw "Game werewolf sudah berjalan.";
      if (room.host !== m.sender && !isAdmin && !isOwner) throw "Hanya host/admin/owner yang bisa memulai game.";
      if (room.player.length < 4) throw "Minimal 4 player untuk memulai werewolf.";
      room.starting = true;
      clearLobbyTimeout(m.chat);
      logWW(m.chat, "start_requested", { by: m.sender, total: room.player.length });
      try {
        room.status = false;
        room.iswin = null;
        room.cooldown = 0;
        room.day = 1;
        room.time = "malem";
        room.voting = false;
        room.seer = false;
        room.guardian = [];
        room.dead = [];
        for (const p of room.player) {
          p.role = false;
          p.isdead = false;
          p.isvote = false;
          p.vote = 0;
          p.effect = [];
          p.status = true;
        }
        renumber(room);
        import_werewolf.default.roleGenerator(m.chat, db);
        import_werewolf.default.startGame(m.chat, db);
        room.runnerToken = (room.runnerToken || 0) + 1;
        const token = room.runnerToken;
        room.runnerActive = true;
        logWW(m.chat, "game_started", { by: m.sender, token, total: room.player.length });
        const mentions = room.player.map((p) => p.id);
        await jagoanproject.sendMessage(m.chat, {
          text: `*WEREWOLF DIMULAI*

Player: ${room.player.length}
Hari: 1
Fase awal: malam

Cek private chat bot untuk melihat peran dan aksi malam.`,
          mentions
        }, { quoted: m });
        Promise.resolve().then(async () => {
          logWW(m.chat, "runner_started", { token });
          await import_werewolf.default.run_malam(jagoanproject, m.chat, db);
          logWW(m.chat, "runner_finished", { token });
        }).catch((e) => {
          logWW(m.chat, "runner_error", { token, error: e?.stack || e?.message || String(e) });
          cleanupRoom(m.chat, "runner_error", e);
        }).finally(() => {
          const current = db[m.chat];
          if (current && current.runnerToken === token) {
            current.runnerActive = false;
            current.starting = false;
          }
        });
        return;
      } catch (e) {
        cleanupRoom(m.chat, "start_error", e);
        throw new Error(`Start werewolf gagal: ${e?.message || e}`);
      }
    }
    case "vote": {
      if (!room || !room.status) throw "Belum ada game werewolf yang berjalan di grup ini.";
      if (!room.voting) throw "Sekarang belum fase voting.";
      if (!import_werewolf.default.playerOnRoom(m.sender, m.chat, db)) throw "Kamu bukan player di room ini.";
      const me = import_werewolf.default.dataPlayer(m.sender, db);
      if (!me || me.isdead) throw "Player yang sudah mati tidak bisa voting.";
      if (me.isvote) throw "Kamu sudah voting di ronde ini.";
      const nomor = parseInt(args[1]);
      if (!nomor) throw `Contoh: *${usedPrefix}ww vote 2*`;
      const target = import_werewolf.default.getPlayerById(m.chat, m.sender, nomor, db);
      if (!target) throw "Nomor player tidak valid.";
      if (target.db.isdead) throw "Target sudah mati.";
      if (target.db.id === m.sender) throw "Kamu tidak bisa vote diri sendiri.";
      const ok = import_werewolf.default.vote(m.chat, nomor, m.sender, db);
      if (!ok) throw "Vote ditolak oleh sistem werewolf.";
      logWW(m.chat, "vote_cast", { by: m.sender, target: target.db.id, targetNumber: nomor });
      return m.reply(`Vote diterima untuk player nomor *${nomor}*.`);
    }
    case "status":
    case "list":
    case "pemain": {
      if (!room) throw "Tidak ada room werewolf di grup ini.";
      return m.reply(formatStatus(room), null, { mentions: room.player.map((p) => p.id).concat(room.host ? [room.host] : []) });
    }
    case "log":
    case "debug": {
      if (!room) throw "Tidak ada room werewolf di grup ini.";
      return m.reply(formatLogs(room));
    }
    case "end":
    case "delete":
    case "hapus":
    case "stop": {
      if (!room) throw "Tidak ada room werewolf di grup ini.";
      if (room.host !== m.sender && !isAdmin && !isOwner) throw "Hanya host/admin/owner yang bisa menghapus room.";
      cleanupRoom(m.chat, "manual_end", null);
      return m.reply("Room werewolf berhasil dihapus.");
    }
    default:
      return m.reply(help(usedPrefix));
  }
};
handler.help = ["ww create", "ww join", "ww start", "ww vote <nomor>", "ww leave", "ww status", "ww log", "ww end"];
handler.tags = ["game"];
handler.command = /^(ww|werewolf)$/i;
handler.group = true;
handler.register = true;
var game_wwgc_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
