/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - jackpot.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_jackpot_exports = {};
__export(game_jackpot_exports, {
  default: () => game_jackpot_default
});
module.exports = __toCommonJS(game_jackpot_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
let { MessageType } = __zapo_1;
let handler = async (m, { jagoanproject, usedPrefix }) => {
  try {
    let _spin1 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin2 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin3 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin4 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin5 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin6 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin7 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin8 = pickRandom(["1", "2", "3", "4", "5"]);
    let _spin9 = pickRandom(["1", "2", "3", "4", "5"]);
    let spin1 = _spin1 * 1;
    let spin2 = _spin2 * 1;
    let spin3 = _spin3 * 1;
    let spin4 = _spin4 * 1;
    let spin5 = _spin5 * 1;
    let spin6 = _spin6 * 1;
    let spin7 = _spin7 * 1;
    let spin8 = _spin8 * 1;
    let spin9 = _spin9 * 1;
    let spins1 = spin1 == 1 ? "\u{1F34A}" : spin1 == 2 ? "\u{1F347}" : spin1 == 3 ? "\u{1F349}" : spin1 == 4 ? "\u{1F34C}" : spin1 == 5 ? "\u{1F34D}" : "";
    let spins2 = spin2 == 1 ? "\u{1F34A}" : spin2 == 2 ? "\u{1F347}" : spin2 == 3 ? "\u{1F349}" : spin2 == 4 ? "\u{1F34C}" : spin2 == 5 ? "\u{1F34D}" : "";
    let spins3 = spin3 == 1 ? "\u{1F34A}" : spin3 == 2 ? "\u{1F347}" : spin3 == 3 ? "\u{1F349}" : spin3 == 4 ? "\u{1F34C}" : spin3 == 5 ? "\u{1F34D}" : "";
    let spins4 = spin4 == 1 ? "\u{1F34A}" : spin4 == 2 ? "\u{1F347}" : spin4 == 3 ? "\u{1F349}" : spin4 == 4 ? "\u{1F34C}" : spin4 == 5 ? "\u{1F34D}" : "";
    let spins5 = spin5 == 1 ? "\u{1F34A}" : spin5 == 2 ? "\u{1F347}" : spin5 == 3 ? "\u{1F349}" : spin5 == 4 ? "\u{1F34C}" : spin5 == 5 ? "\u{1F34D}" : "";
    let spins6 = spin6 == 1 ? "\u{1F34A}" : spin6 == 2 ? "\u{1F347}" : spin6 == 3 ? "\u{1F349}" : spin6 == 4 ? "\u{1F34C}" : spin6 == 5 ? "\u{1F34D}" : "";
    let spins7 = spin7 == 1 ? "\u{1F34A}" : spin7 == 2 ? "\u{1F347}" : spin7 == 3 ? "\u{1F349}" : spin7 == 4 ? "\u{1F34C}" : spin7 == 5 ? "\u{1F34D}" : "";
    let spins8 = spin8 == 1 ? "\u{1F34A}" : spin8 == 2 ? "\u{1F347}" : spin8 == 3 ? "\u{1F349}" : spin8 == 4 ? "\u{1F34C}" : spin8 == 5 ? "\u{1F34D}" : "";
    let spins9 = spin9 == 1 ? "\u{1F34A}" : spin9 == 2 ? "\u{1F347}" : spin9 == 3 ? "\u{1F349}" : spin9 == 4 ? "\u{1F34C}" : spin9 == 5 ? "\u{1F34D}" : "";
    let WinOrLose;
    if (spin1 == 1 && spin2 == 1 && spin3 == 1 && spin4 == 1 && spin5 == 1 && spin6 == 1 && spin7 == 1 && spin8 == 1 && spin9 == 1 || spin1 == 2 && spin2 == 2 && spin3 == 2 && spin4 == 2 && spin5 == 2 && spin6 == 2 && spin7 == 2 && spin8 == 2 && spin9 == 2 || spin1 == 3 && spin2 == 3 && spin3 == 3 && spin4 == 3 && spin5 == 3 && spin6 == 3 && spin7 == 3 && spin8 == 3 && spin9 == 3 || spin1 == 4 && spin2 == 4 && spin3 == 4 && spin4 == 4 && spin5 == 4 && spin6 == 4 && spin7 == 4 && spin8 == 4 && spin9 == 4 || spin1 == 5 && spin2 == 5 && spin3 == 5 && spin4 == 5 && spin5 == 5 && spin6 == 5 && spin7 == 5 && spin8 == 5 && spin9 == 5) {
      WinOrLose = "Kamu menang lagi dan mendapatkan Mega Jackpot!";
    } else if (spin4 == 1 && spin5 == 1 && spin6 == 1 || spin4 == 2 && spin5 == 2 && spin6 == 2 || spin4 == 3 && spin5 == 3 && spin6 == 3 || spin4 == 4 && spin5 == 4 && spin6 == 4 || spin4 == 5 && spin5 == 5 && spin6 == 5) {
      WinOrLose = "Kamu menang dan mendapatkan Jackpot!";
    } else if (spin1 == 1 && spin2 == 1 && spin3 == 1 || spin1 == 2 && spin2 == 2 && spin3 == 2 || spin1 == 3 && spin2 == 4 && spin3 == 3 || spin1 == 4 && spin2 == 4 && spin3 == 4 || spin1 == 5 && spin2 == 5 && spin3 == 5 || spin1 == 6 && spin2 == 6 && spin3 == 6 || spin1 == 7 && spin2 == 7 && spin3 == 7 || spin1 == 8 && spin2 == 8 && spin3 == 8 || spin1 == 9 && spin2 == 9 && spin3 == 9) {
      WinOrLose = "Kamu menang dalam Pertandingan ini!";
    } else {
      WinOrLose = "Kamu kalah dalam Pertandingan ini!";
    }
    jagoanproject.reply(m.chat, `
       *VIRTUAL SLOTS*

${spins1}|${spins2}|${spins3}
${spins4}|${spins5}|${spins6} <<==
${spins7}|${spins8}|${spins9}

*${WinOrLose}*
`.trim(), m);
  } catch (e) {
    console.log(e);
    jagoanproject.reply(m.chat, "Error", m);
    if (DevMode) {
      for (let jid of global.jpOwner.map((v) => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").filter((v) => v != jagoanproject.user.jid)) {
        jagoanproject.sendMessage(jid, "Menu.js error\nNo: *" + m.sender.split`@`[0] + "*\nCommand: *" + m.text + "*\n\n*" + e + "*", MessageType.text);
      }
    }
  }
};
handler.help = ["jackpot"];
handler.tags = ["game"];
handler.command = /^(jackpot)$/i;
handler.group = true;
handler.register = true;
handler.limit = false;
var game_jackpot_default = handler;
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
