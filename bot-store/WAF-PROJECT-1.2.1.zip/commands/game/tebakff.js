/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/game/game - tebakff.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var game_tebakff_exports = {};
__export(game_tebakff_exports, {
  default: () => game_tebakff_default
});
module.exports = __toCommonJS(game_tebakff_exports);
// WAF: canvas opsional; kalau tidak terpasang, gambar disusun dengan sharp
var import_similarity = __toESM(require("similarity"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_node_fetch = __toESM(require("node-fetch"));
var import_sharp = __toESM(require("sharp"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
function __jpCanvas() { try { return require("canvas"); } catch { return null; } }
async function __jpSharpCompose(bgBuf, charBuf) {
  const sharp = require("sharp");
  const meta = await sharp(bgBuf).metadata();
  const W = meta.width || 800, H = meta.height || 800;
  const maxW = Math.max(1, Math.floor(W / 1.35)), maxH = Math.max(1, Math.floor(H / 1.35));
  const ch = await sharp(charBuf).resize({ width: maxW, height: maxH, fit: "inside" }).png().toBuffer();
  const cm = await sharp(ch).metadata();
  return sharp(bgBuf).composite([{ input: ch, left: Math.floor((W - cm.width) / 2), top: Math.floor((H - cm.height) / 2) }]).png().toBuffer();
}
let timeout = 12e4;
const MIN_SIMILARITY_CLUE = 0.6;
const MAX_SIMILARITY_TEASE = 0.98;
const IMAGE_COOLDOWN = 18 * 60 * 60 * 1e3;
const TEBakFF_DEBUG = false;
const TEBakFF_DEBUG_SAVE = false;
const TEBakFF_BG_FORCE_REFETCH = false;
function dlog(...args) {
  if (!TEBakFF_DEBUG) return;
  console.log("[TEBAKFF]", ...args);
}
function isPng(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 8) return false;
  return buf[0] === 137 && buf[1] === 80 && buf[2] === 78 && buf[3] === 71 && buf[4] === 13 && buf[5] === 10 && buf[6] === 26 && buf[7] === 10;
}
function headHex(buf, n = 24) {
  return Buffer.isBuffer(buf) ? buf.subarray(0, Math.min(n, buf.length)).toString("hex") : "-";
}
function safeWrite(filePath, data) {
  try {
    import_fs.default.mkdirSync(import_path.default.dirname(filePath), { recursive: true });
    import_fs.default.writeFileSync(filePath, data);
  } catch {
  }
}
const VERCEL_BASE = "https://jagoanproject-freefire-6282252509320.vercel.app/";
const img = (fileName) => `${VERCEL_BASE}/images/${encodeURIComponent(fileName)}`;
const BG_URL = "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/JAGOAN%20PROJECT%20(1779%20x%202880%20piksel).jpg";
const TMP_DIR = import_path.default.resolve(__dirname, "../../tmp");
const BG_CACHE_PNG = import_path.default.join(TMP_DIR, "tebakff-bg-cache.png");
const BG_CACHE_META = import_path.default.join(TMP_DIR, "tebakff-bg-cache.json");
const BG_CACHE_TTL = 7 * 24 * 60 * 60 * 1e3;
function normalizeAnswer(s) {
  return (s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function calcSpeedReward(elapsedMs) {
  const maxMs = timeout;
  const t = Math.max(0, Math.min(1, elapsedMs / maxMs));
  const speed = 1 - t;
  const r = Math.random();
  const bias = (r + speed) / 2;
  const money = Math.floor(3e3 + bias * (1e4 - 3e3));
  const limit = Math.floor(2 + bias * (5 - 2));
  const xp = Math.floor(200 + bias * (2e3 - 200));
  return { money, limit, xp };
}
function getChatStore(chatId) {
  global.db = global.db || {};
  global.db.data = global.db.data || {};
  global.db.data.chats = global.db.data.chats || {};
  global.db.data.chats[chatId] = global.db.data.chats[chatId] || {};
  const chat = global.db.data.chats[chatId];
  chat.tebakff_usedImages = chat.tebakff_usedImages || {};
  return chat;
}
async function fetchImageBuffer(url, extraHeaders = {}) {
  dlog("FETCH:", url);
  const res = await (0, import_node_fetch.default)(url, {
    redirect: "follow",
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
      Accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
      ...extraHeaders
    }
  });
  const ct = (res.headers.get("content-type") || "").toLowerCase();
  const status = res.status;
  const finalUrl = res.url || url;
  const buf = Buffer.from(await res.arrayBuffer());
  dlog("RESP:", { status, contentType: ct, size: buf.length, finalUrl });
  dlog("HEADHEX:", headHex(buf));
  if (TEBakFF_DEBUG_SAVE) {
    safeWrite(import_path.default.join(TMP_DIR, "dbg_last_fetch_headhex.txt"), headHex(buf, 64));
    safeWrite(
      import_path.default.join(TMP_DIR, "dbg_last_fetch_url.txt"),
      `${finalUrl}
${ct}
${status}
`
    );
    safeWrite(import_path.default.join(TMP_DIR, "dbg_last_fetch_raw.bin"), buf);
  }
  if (!ct.startsWith("image/")) {
    const head = buf.toString("utf8", 0, 250).replace(/\s+/g, " ");
    throw new Error(
      `URL tidak mengembalikan gambar.
URL: ${finalUrl}
status: ${status}
content-type: ${ct}
preview: ${head}`
    );
  }
  return buf;
}
async function toPngBuffer(inputBuf, label = "img") {
  try {
    const out = await (0, import_sharp.default)(inputBuf).png().toBuffer();
    dlog(`${label} -> PNG:`, { size: out.length, isPng: isPng(out), headHex: headHex(out) });
    if (!isPng(out)) throw new Error("hasil convert bukan PNG valid");
    return out;
  } catch (e) {
    const head = inputBuf.toString("utf8", 0, 200).replace(/\s+/g, " ");
    throw new Error(
      `${label} gagal di-convert ke PNG (sharp).
err: ${String(e.message || e)}
preview: ${head}`
    );
  }
}
async function getBackgroundPngBuffer() {
  if (!import_fs.default.existsSync(TMP_DIR)) import_fs.default.mkdirSync(TMP_DIR, { recursive: true });
  if (TEBakFF_BG_FORCE_REFETCH) {
    dlog("FORCE REFRESH BG: true -> hapus cache");
    try {
      import_fs.default.unlinkSync(BG_CACHE_PNG);
    } catch {
    }
    try {
      import_fs.default.unlinkSync(BG_CACHE_META);
    } catch {
    }
  }
  try {
    if (import_fs.default.existsSync(BG_CACHE_PNG)) {
      const cached = import_fs.default.readFileSync(BG_CACHE_PNG);
      dlog("CACHE BG FOUND:", BG_CACHE_PNG, "size:", cached.length, "isPng:", isPng(cached));
      dlog("CACHE HEADHEX:", headHex(cached));
      if (isPng(cached) && cached.length > 1e4) {
        if (import_fs.default.existsSync(BG_CACHE_META)) {
          const meta = JSON.parse(import_fs.default.readFileSync(BG_CACHE_META, "utf8"));
          const age = Date.now() - (meta.ts || 0);
          dlog("CACHE META:", meta, "age(ms):", age);
          if (age < BG_CACHE_TTL) return cached;
          dlog("CACHE EXPIRED -> refetch");
        } else {
          return cached;
        }
      } else {
        dlog("CACHE INVALID -> delete and refetch");
        try {
          import_fs.default.unlinkSync(BG_CACHE_PNG);
        } catch {
        }
        try {
          import_fs.default.unlinkSync(BG_CACHE_META);
        } catch {
        }
      }
    }
  } catch (e) {
    dlog("CACHE READ ERROR:", String(e.message || e));
  }
  dlog("FETCH BG FROM:", BG_URL);
  const bgRaw = await fetchImageBuffer(BG_URL, { Referer: "https://www.shutterstock.com/" });
  const bgPng = await toPngBuffer(bgRaw, "BG");
  if (TEBakFF_DEBUG_SAVE) {
    safeWrite(import_path.default.join(TMP_DIR, "dbg_bg_raw.bin"), bgRaw);
    safeWrite(import_path.default.join(TMP_DIR, "dbg_bg_png.bin"), bgPng);
    safeWrite(import_path.default.join(TMP_DIR, "dbg_bg_png_headhex.txt"), headHex(bgPng, 64));
  }
  import_fs.default.writeFileSync(BG_CACHE_PNG, bgPng);
  import_fs.default.writeFileSync(BG_CACHE_META, JSON.stringify({ ts: Date.now(), src: BG_URL }));
  return bgPng;
}
async function composeTebakFFImage(characterUrl) {
  dlog("COMPOSE START:", characterUrl);
  const bgPngBuf = await getBackgroundPngBuffer();
  dlog("BG BUFFER:", { size: bgPngBuf.length, isPng: isPng(bgPngBuf), headHex: headHex(bgPngBuf) });
  const charRaw = await fetchImageBuffer(characterUrl);
  const charPngBuf = await toPngBuffer(charRaw, "CHAR");
  if (TEBakFF_DEBUG_SAVE) {
    safeWrite(import_path.default.join(TMP_DIR, "dbg_char_raw.bin"), charRaw);
    safeWrite(import_path.default.join(TMP_DIR, "dbg_char_png.bin"), charPngBuf);
  }
  const __cv = __jpCanvas();
  if (!__cv) return __jpSharpCompose(bgPngBuf, charPngBuf);
  const { createCanvas, loadImage } = __cv;
  const bg = await loadImage(bgPngBuf);
  const charImg = await loadImage(charPngBuf);
  const canvas = createCanvas(bg.width, bg.height);
  const ctx = canvas.getContext("2d");
  ctx.drawImage(bg, 0, 0, bg.width, bg.height);
  const scale = Math.min(
    bg.width / (charImg.width * 1.35),
    bg.height / (charImg.height * 1.35)
  );
  const w = Math.max(1, Math.floor(charImg.width * scale));
  const h = Math.max(1, Math.floor(charImg.height * scale));
  const x = Math.floor((bg.width - w) / 2);
  const y = Math.floor((bg.height - h) / 2);
  ctx.shadowColor = "rgba(0,0,0,0.45)";
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;
  ctx.drawImage(charImg, x, y, w, h);
  const out = canvas.toBuffer("image/png");
  dlog("COMPOSE DONE:", { outSize: out.length, headHex: headHex(out) });
  if (TEBakFF_DEBUG_SAVE) safeWrite(import_path.default.join(TMP_DIR, "dbg_last_compose.png"), out);
  return out;
}
const FF_CHARACTERS = [
  { name: "A124", file: "A124 - A124.png" },
  { name: "A Patroa", file: "A_Patroa - APatroa.png" },
  { name: "Alok", file: "Alok - Alok.png" },
  { name: "Alvaro", file: "Alvaro - Alvaro.png" },
  { name: "Andrew", file: "Andrew - FreeFireAndrew.png" },
  { name: "Antonio", file: "Antonio - Antonio.png" },
  { name: "Caroline", file: "Caroline - Caroline.png" },
  { name: "Chrono", file: "Chrono - Chrono.png" },
  { name: "Clu", file: "Clu - Clu.png" },
  { name: "D Bee", file: "D_Bee - DBee.png" },
  { name: "Dasha", file: "Dasha - Dasha.png" },
  { name: "Dimitri", file: "Dimitri - Dimitri.png" },
  { name: "Ford", file: "Ford - FFFord.png" },
  { name: "Hayato", file: "Hayato - FreeFireHayato.png" },
  { name: "Homer", file: "Homer - FFHomer.png" },
  { name: "Iris", file: "Iris - FFIris.png" },
  { name: "J Beibs", file: "J_Beibs - JBeibs.png" },
  { name: "Joseph", file: "Joseph - FFJoseph.png" },
  { name: "Jota", file: "Jota - Jota.png" },
  { name: "K", file: "K - K.png" },
  { name: "Kapella", file: "Kapella - Kapella.png" },
  { name: "Kelly", file: "Kelly - FreeFireKelly.png" },
  { name: "Kenta", file: "Kenta - Kenta.png" },
  { name: "Kla", file: "Kla - Kla.png" },
  { name: "Laura", file: "Laura - Laura.png" },
  { name: "Leon", file: "Leon - Leon.png" },
  { name: "Luna", file: "Luna - Luna.png" },
  { name: "Luqueta", file: "Luqueta - Luqueta.png" },
  { name: "Maro", file: "Maro - Maro.png" },
  { name: "Maxim", file: "Maxim - FreeFireMaxim.png" },
  { name: "Miguel", file: "Miguel - Miguel.png" },
  { name: "Misha", file: "Misha - FreeFireMisha.png" },
  { name: "Moco", file: "Moco - FreeFireMoco.png" },
  { name: "Nairi", file: "Nairi - Nairi.png" },
  { name: "Nikita", file: "Nikita - Nikita.png" },
  { name: "Notora", file: "Notora - Notora.png" },
  { name: "Olivia", file: "Olivia - FFOlivia.png" },
  { name: "Orion", file: "Orion - Orion.png" },
  { name: "Otho", file: "Otho - Otho.png" },
  { name: "Paloma", file: "Paloma - Paloma.png" },
  { name: "Shirou", file: "Shirou - Shirou.png" },
  { name: "Skyler", file: "Skyler - Skyler.png" },
  { name: "Sonia", file: "Sonia - Sonia.png" },
  { name: "Steffie", file: "Steffie - FreeFireSteffie.png" },
  { name: "Suzy", file: "Suzy - Suzy.png" },
  { name: "Tatsuya", file: "Tatsuya - Tatsuya.png" },
  { name: "Thiva", file: "Thiva - Thiva.png" },
  { name: "Wolfrahh", file: "Wolfrahh - Wolfrahh.png" },
  { name: "Wukong", file: "Wukong - Wukong.png" },
  { name: "Xayne", file: "Xayne - Xayne.png" }
].map((x) => ({
  name: x.name,
  imageUrl: img(x.file),
  answer: normalizeAnswer(x.name)
}));
let handler = async (m, { jagoanproject }) => {
  jagoanproject.tebakff = jagoanproject.tebakff ? jagoanproject.tebakff : {};
  let id = m.chat;
  if (id in jagoanproject.tebakff) {
    jagoanproject.reply(
      m.chat,
      "Masih ada soal *Tebak Karakter FF* belum terjawab di chat ini\nKetik *nyerah* untuk menyerah.",
      jagoanproject.tebakff[id].reply
    );
    throw false;
  }
  if (!FF_CHARACTERS.length) throw "Dataset karakter FF kosong.";
  const now = Date.now();
  const chatStore = getChatStore(id);
  const used = chatStore.tebakff_usedImages;
  for (let imageUrl in used) {
    if (now - used[imageUrl] > IMAGE_COOLDOWN) delete used[imageUrl];
  }
  const available = FF_CHARACTERS.filter((c) => !used[c.imageUrl]);
  if (!available.length) {
    throw "\u274C Semua gambar karakter sudah muncul dalam 18 jam terakhir di grup ini.\n\u23F3 Coba lagi nanti.";
  }
  const pick = available[Math.floor(Math.random() * available.length)];
  used[pick.imageUrl] = now;
  const clue = pick.name.replace(/[AIUEOaiueo]/g, "_");
  const caption = `
\u{1F525} *TEBAK KARAKTER FREE FIRE* \u{1F525}

\u23F3 *Waktu:* ${Math.floor(timeout / 1e3)} detik
\u2753 *Pertanyaan:* Siapakah karakter FF ini?

\u{1F9E9} *Clue:* ${clue}

\u270D\uFE0F *Cara jawab:* ketik nama karakternya
\u{1F4CC} *Contoh:* _alok_
\u{1F3F3}\uFE0F *Menyerah?:* ketik *nyerah*
`.trim();
  let finalImage;
  try {
    finalImage = await composeTebakFFImage(pick.imageUrl);
  } catch (e) {
    const msg = `\u274C Gagal tempel background.

\u{1F4CC} Error: ${String(e.message || e)}

\u{1F5C2} Cache folder: ${TMP_DIR}
\u{1F4C4} Cache file: ${BG_CACHE_PNG}

\u2705 Debug files (kalau debug ON):
- dbg_bg_raw.bin / dbg_bg_png.bin
- dbg_char_raw.bin / dbg_char_png.bin
- dbg_last_compose.png (kalau sempat jadi)
`;
    return jagoanproject.reply(m.chat, msg, m);
  }
  let q = await jagoanproject.sendMessage(
    m.chat,
    { image: finalImage, caption },
    { quoted: m }
  );
  jagoanproject.tebakff[id] = {
    reply: q,
    title: pick.name,
    answer: pick.answer,
    img: pick.imageUrl,
    start: Date.now(),
    timer: null
  };
};
handler.before = async (m, { jagoanproject }) => {
  jagoanproject.tebakff = jagoanproject.tebakff ? jagoanproject.tebakff : {};
  let id = m.chat;
  if (!jagoanproject.tebakff[id]) return;
  const data = jagoanproject.tebakff[id];
  if (!data.timer) {
    data.timer = setTimeout(() => {
      if (!jagoanproject.tebakff[id]) return;
      jagoanproject.reply(
        m.chat,
        `\u23F0 *WAKTU HABIS!*

\u2705 *Jawaban:* *${data.title}*

\u{1F3AE} Ketik *.tebakff* untuk main lagi!`,
        data.reply
      );
      delete jagoanproject.tebakff[id];
    }, timeout);
  }
  if (!m.text) return;
  const userText = normalizeAnswer(m.text);
  if (userText === "nyerah" || userText === "surrender") {
    clearTimeout(data.timer);
    jagoanproject.reply(
      m.chat,
      `\u{1F614} Kamu menyerah.
\u2705 Jawaban: *${data.title}*`,
      data.reply
    );
    delete jagoanproject.tebakff[id];
    return;
  }
  if (userText === data.answer) {
    const elapsed = Date.now() - data.start;
    const reward = calcSpeedReward(elapsed);
    try {
      let user = global.db.data.users[m.sender];
      user.money = (user.money || 0) + reward.money;
      user.limit = (user.limit || 0) + reward.limit;
      user.exp = (user.exp || 0) + reward.xp;
    } catch {
    }
    clearTimeout(data.timer);
    delete jagoanproject.tebakff[id];
    return jagoanproject.reply(
      m.chat,
      `\u{1F389} *BENAR! JAWABAN KAMU TEPAT!* \u2705

\u2705 *Jawaban:* *${data.title}*

\u{1F4B0} *Uang:* +${reward.money.toLocaleString("id-ID")}
\u{1F3AB} *Limit:* +${reward.limit}
\u2728 *XP:* +${reward.xp}`,
      m
    );
  }
  const sim = (0, import_similarity.default)(userText, data.answer);
  const persen = Math.floor(sim * 100);
  if (sim >= MAX_SIMILARITY_TEASE) {
    return jagoanproject.reply(
      m.chat,
      `\u274C Salah!
\u{1F633} *Dikiiiit lagi!* (Clue: *${persen}%*)`,
      m
    );
  }
  if (sim >= MIN_SIMILARITY_CLUE) {
    return jagoanproject.reply(
      m.chat,
      `\u274C Salah!
\u{1F4CC} Clue: *${persen}%* mendekati jawaban \u2705`,
      m
    );
  }
  const hint = data.title.replace(/[AIUEOaiueo]/g, "_");
  return jagoanproject.reply(m.chat, `\u274C Salah!
\u{1F4A1} Hint: ${hint}
Coba lagi \u{1F604}`, m);
};
handler.help = ["tebakff"];
handler.tags = ["game"];
handler.command = /^(tebak(ff|freefire|fr)|tebakkarakter(ff|freefire))$/i;
handler.group = false;
handler.register = true;
handler.limit = false;
var game_tebakff_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "game" }
)
