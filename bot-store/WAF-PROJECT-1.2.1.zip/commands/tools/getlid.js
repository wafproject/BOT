/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - getlid.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_getlid_exports = {};
__export(tools_getlid_exports, {
  default: () => tools_getlid_default
});
module.exports = __toCommonJS(tools_getlid_exports);
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  let who;
  if (m.isGroup) {
    if (m.mentionedJid && m.mentionedJid[0]) {
      who = m.mentionedJid[0];
    } else if (m.quoted) {
      who = m.quoted.sender;
    } else {
      who = m.sender;
      m.reply(`Tidak ada reply pesan atau tag. Mengambil LID kamu sendiri:`);
    }
  } else {
    who = m.sender;
  }
  if (!who) {
    return m.reply(`Penggunaan salah. Reply pesan, tag seseorang, atau gunakan di private chat.`);
  }
  if (typeof global.getLidFromJid !== "function") {
    return m.reply("Fungsi `getLidFromJid` tidak ditemukan. Pastikan sudah didefinisikan dan di-export ke `global` di file handler utama Anda.");
  }
  try {
    let lid = await global.getLidFromJid(who, jagoanproject);
    m.reply(`*ID Target:* ${who}
*LID Target:* ${lid}`);
  } catch (e) {
    console.error(e);
    m.reply("Terjadi kesalahan saat mencoba mendapatkan LID. Pastikan bot terhubung dan ID valid.");
  }
};
handler.help = ["getlid"];
handler.tags = ["tools"];
handler.command = /^(getlid)$/i;
handler.register = true;
handler.limit = true;
var tools_getlid_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
