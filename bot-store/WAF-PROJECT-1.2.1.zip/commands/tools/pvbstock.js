/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - pvbstock.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_pvbstock_exports = {};
__export(tools_pvbstock_exports, {
  default: () => tools_pvbstock_default
});
module.exports = __toCommonJS(tools_pvbstock_exports);
var import_node_fetch = __toESM(require("node-fetch"));
function getZoneLabel(zone) {
  const found = [
    { zone: "Asia/Jakarta", label: "WIB" },
    { zone: "Asia/Makassar", label: "WITA" },
    { zone: "Asia/Jayapura", label: "WIT" }
  ].find((z) => z.zone === zone);
  return found ? found.label : zone;
}
async function getStockData() {
  try {
    const response = await (0, import_node_fetch.default)("https://plantsvsbrainrots.com/api/latest-message");
    const data = await response.json();
    if (!data || data.length === 0) {
      return null;
    }
    const latestMessage = data[0];
    const embed = latestMessage.embeds[0];
    const description = embed.description;
    const seedsSection = description.match(/\*\*Seeds\*\*\n([\s\S]*?)\n\*\*Gear\*\*/);
    const gearSection = description.match(/\*\*Gear\*\*\n([\s\S]*?)\n\n/);
    const emojiMap = {
      "Sunflower": "\u{1F33B}",
      "Pumpkin": "\u{1F383}",
      "Strawberry": "\u{1F353}",
      "Cactus": "\u{1F335}",
      "Cocotank": "\u{1F965}",
      "Eggplant": "\u{1F346}",
      "Dragon Fruit": "\u{1F409}",
      "Carrot Launcher": "\u{1F955}",
      "Banana Gun": "\u{1F34C}",
      "Frost Grenade": "\u2744\uFE0F",
      "Water Bucket": "\u{1FAA3}"
    };
    const parseItems = (section) => {
      if (!section) return [];
      return section[1].split("\n").map((line) => {
        const match = line.match(/<:.*?:.*?>\s*(.*?)\s*x(\d+)/);
        if (match) {
          const name = match[1];
          return {
            name,
            quantity: parseInt(match[2]),
            emoji: emojiMap[name] || "\u{1F331}"
          };
        }
        return null;
      }).filter((item) => item);
    };
    const seeds = parseItems(seedsSection);
    const gear = parseItems(gearSection);
    let textResult = "\u{1F331} *Plants vs Brainrots Stock Updates!*\n\n";
    if (seeds.length > 0) {
      textResult += "\u{1F33F} *SEEDS*\n";
      for (let item of seeds) {
        textResult += `${item.emoji} ${item.name} \u2794 +${item.quantity} stock
`;
      }
      textResult += "\n";
    }
    if (gear.length > 0) {
      textResult += "\u2699\uFE0F *GEAR*\n";
      for (let item of gear) {
        textResult += `${item.emoji} ${item.name} \u2794 +${item.quantity} stock
`;
      }
      textResult += "\n";
    }
    let updateTime;
    try {
      const dateObj = new Date(latestMessage.createdAt);
      updateTime = dateObj.toLocaleString("id-ID", {
        day: "2-digit",
        month: "long",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
        timeZone: "Asia/Makassar"
      }) + ` WITA`;
    } catch {
      updateTime = "Format waktu tidak valid";
    }
    return { text: textResult + `\u{1F552} *Last Update:* 
${updateTime}`, seeds, gear };
  } catch (err) {
    return null;
  }
}
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  await jagoanproject.sendMessage(m.chat, { react: { text: "\u23F3", key: m.key } });
  try {
    const stockData = await getStockData();
    if (!stockData) {
      await jagoanproject.sendMessage(m.chat, { react: { text: "\u26A0\uFE0F", key: m.key } });
      return m.reply("Tidak ada data diterima dari API.");
    }
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } });
    await m.reply(stockData.text.trim());
  } catch (err) {
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u26A0\uFE0F", key: m.key } });
    await m.reply("Terjadi kesalahan saat mengambil data stok.");
  }
};
handler.help = ["pvbstock"];
handler.tags = ["tools"];
handler.command = ["plantsvsbrainrotsstock", "pvbstock", "stockpvb"];
handler.register = true;
handler.limit = true;
var tools_pvbstock_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
