/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - folio.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_folio_exports = {};
__export(tools_folio_exports, {
  default: () => tools_folio_default
});
module.exports = __toCommonJS(tools_folio_exports);
var __util_1 = __toESM(require("util"));
var __child_process_2 = __toESM(require("child_process"));
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const { format } = __util_1;
const { spawn } = __child_process_2;
let fontPath = "src/font/Zahraaa.ttf";
let handler = async (m, { jagoanproject, args }) => {
  if (!global.support.convert && !global.support.magick && !global.support.gm) return handler.disabled = true;
  let inputPath = "src/kertas/kertaslucu.jpg";
  let d = /* @__PURE__ */ new Date();
  let tgl = d.toLocaleDateString("id-Id");
  let hari = d.toLocaleDateString("id-Id", { weekday: "long" });
  let teks = args.join` `;
  let bufs = [];
  const [_spawnprocess, ..._spawnargs] = [
    ...global.support.gm ? ["gm"] : global.support.magick ? ["magick"] : [],
    "convert",
    inputPath,
    "-font",
    fontPath,
    "-size",
    "1024x784",
    "-pointsize",
    "20",
    "-interline-spacing",
    "1",
    "-annotate",
    "+806+78",
    hari,
    "-font",
    fontPath,
    "-size",
    "1024x784",
    "-pointsize",
    "18",
    "-interline-spacing",
    "1",
    "-annotate",
    "+806+102",
    tgl,
    "-font",
    fontPath,
    "-size",
    "1024x784",
    "-pointsize",
    "20",
    "-interline-spacing",
    "-7.5",
    "-annotate",
    "+344+142",
    teks,
    "jpg:-"
  ];
  spawn(_spawnprocess, _spawnargs).on("error", (e) => m.reply(format(e))).on("close", () => {
    jagoanproject.sendFile(m.chat, Buffer.concat(bufs), "nulis.jpg", "Ini kak hasil Tulisan di folio :v", m);
  }).stdout.on("data", (chunk) => bufs.push(chunk));
};
handler.help = ["f"].map((v) => v + "olio <teks>");
handler.tags = ["tools"];
handler.command = /^folio$/i;
handler.register = true;
handler.limit = true;
var tools_folio_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
