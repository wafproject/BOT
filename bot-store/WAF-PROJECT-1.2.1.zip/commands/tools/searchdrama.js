/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - searchdrama.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_searchdrama_exports = {};
__export(tools_searchdrama_exports, {
  default: () => tools_searchdrama_default
});
module.exports = __toCommonJS(tools_searchdrama_exports);
var import_axios = __toESM(require("axios"));
const TMDB_API_KEY = () => String(global.tmdbapikey || "").trim(); // isi di settings.js: global.tmdbapikey = "..."
async function searchDrama(query) {
  try {
    const searchResponse = await import_axios.default.get(`https://api.themoviedb.org/3/search/multi?api_key=${TMDB_API_KEY()}&query=${encodeURIComponent(query)}&language=en-US`);
    const results = searchResponse.data.results;
    if (results.length === 0) {
      return { error: "Tidak ditemukan drama atau film dengan judul tersebut!" };
    }
    const randomIndex = Math.floor(Math.random() * results.length);
    const media = results[randomIndex];
    const mediaId = media.id;
    const mediaType = media.media_type === "movie" ? "movie" : "tv";
    const detailResponse = await import_axios.default.get(`https://api.themoviedb.org/3/${mediaType}/${mediaId}?api_key=${TMDB_API_KEY()}&language=en-US`);
    const details = detailResponse.data;
    const creditsResponse = await import_axios.default.get(`https://api.themoviedb.org/3/${mediaType}/${mediaId}/credits?api_key=${TMDB_API_KEY()}&language=en-US`);
    const cast = creditsResponse.data.cast.slice(0, 5).map((actor) => actor.name).join(", ");
    const tmdbLink = `https://www.themoviedb.org/${mediaType}/${mediaId}`;
    return {
      title: mediaType === "movie" ? details.title : details.name,
      overview: details.overview || "Sinopsis tidak tersedia.",
      release_date: mediaType === "movie" ? details.release_date : details.first_air_date,
      cast: cast || "Informasi pemain tidak tersedia.",
      poster: details.poster_path ? `https://image.tmdb.org/t/p/w500${details.poster_path}` : null,
      type: mediaType === "movie" ? "Film" : "Serial/Drama",
      link: tmdbLink
    };
  } catch (error) {
    return { error: `Error: ${error.message}` };
  }
}
var handler = async (m, { jagoanproject, text }) => {
  if (!text) {
    return jagoanproject.reply(m.chat, "Masukkan judul drama/film! Contoh: .searchdrama Moana", m);
  }
  await jagoanproject.reply(m.chat, "Sedang mencari drama/film... Silahkan tunggu", m);
  const result = await searchDrama(text);
  if (result.error) {
    return jagoanproject.reply(m.chat, result.error, m);
  }
  let dramaMessage = `*Informasi Drama/Film:*

`;
  dramaMessage += `\u{1F539} *Judul*: ${result.title}
`;
  dramaMessage += `\u{1F4FA} *Tipe*: ${result.type}
`;
  dramaMessage += `\u{1F4C5} *Tanggal Rilis*: ${result.release_date || "Tidak diketahui"}
`;
  dramaMessage += `\u{1F465} *Pemain Utama*: ${result.cast}
`;
  dramaMessage += `\u{1F4DC} *Sinopsis*: ${result.overview}
`;
  dramaMessage += `\u{1F517} *Link*: ${result.link}

`;
  const buttons = [
    {
      buttonId: `.searchdrama ${text}`,
      buttonText: { displayText: "Next Drama" },
      type: 1
    }
  ];
  const buttonMessage = {
    image: result.poster ? { url: result.poster } : null,
    caption: dramaMessage,
    footer: "Semoga membantu! \u{1F642}",
    buttons,
    headerType: 4,
    viewOnce: true
  };
  await jagoanproject.sendMessage(m.chat, buttonMessage, { quoted: m });
};
handler.help = ["searchdrama <judul>"];
handler.tags = ["tools"];
handler.command = /^(searchdrama|sd)$/i;
handler.register = true;
handler.limit = true;
var tools_searchdrama_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
