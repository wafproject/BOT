/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - catatanbuat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_catatanbuat_exports = {};
__export(tools_catatanbuat_exports, {
  default: () => tools_catatanbuat_default
});
module.exports = __toCommonJS(tools_catatanbuat_exports);
let handler = async (m, { jagoanproject, command, usedPrefix, text }) => {
  let fail = "format salah, example: " + usedPrefix + command + " resep|1. Masak";
  global.db.data.users[m.sender].catatan = global.db.data.users[m.sender].catatan || [];
  let catatan = global.db.data.users[m.sender].catatan;
  let split = text.split("|");
  let title = split[0];
  let isi = split[1];
  if (catatan.includes(title)) return m.reply("Judul tidak tersedia!\n\nAlasan: Sudah digunakan");
  if (!title || !isi) return m.reply(fail);
  let cttn = {
    "title": title,
    "isi": isi
  };
  global.db.data.users[m.sender].catatan.push(cttn);
  jagoanproject.reply(m.chat, `Catatan berhasil dibuat!
Untuk melihat catatan. Ketik: ${usedPrefix}lihatcatatan`, m, false, {
    contextInfo: {
      mentionedJid: jagoanproject.parseMention(text)
    }
  });
};
handler.help = ["buatcatatan <title|isi>"];
handler.tags = ["catatan"];
handler.command = /^buatcatatan$/i;
handler.register = true;
handler.limit = true;
var tools_catatanbuat_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
