/**
 * tools/carigrup.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/search/linkgroupwa",
  "command": [
    "carigrup",
    "carigroup",
    "carigc"
  ],
  "kind": "text",
  "category": "tools"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
