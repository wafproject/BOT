/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - chord.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_chord_exports = {};
__export(tools_chord_exports, {
  default: () => tools_chord_default
});
module.exports = __toCommonJS(tools_chord_exports);
var import_chord = __toESM(require("../../lib/jagoan/scrape/chord.js"));
let handler = async (m, { jagoanproject, text, command }) => {
  try {
    if (!text) {
      return m.reply(`Please provide a song title or artist name to search for chords!

Example:
.${command} Shape of You`);
    }
    m.reply("Searching for chords, please wait...");
    const chords = new import_chord.default(text);
    const results = await chords.getSearch();
    if (results.length === 0) {
      return m.reply("No chords found for the given song or artist.");
    }
    const firstResult = results[0];
    const detail = await chords.getDetail(firstResult.link);
    if (detail) {
      let message = `
\u{1F3B8} *Chords Found!* \u{1F3B8}

\u{1F4DC} Title: ${detail.title}
\u{1F464} Artist: ${detail.artist}
\u{1F5D3}\uFE0F Date: ${detail.date}
\u{1F517} [View Artist Profile](${detail.artistProfileLink})

\u{1F3B6} Chords:
${detail.chords}
`;
      await jagoanproject.sendMessage(m.chat, { text: message, footer: "BabyBotz" }, { quoted: m });
    } else {
      m.reply("Failed to fetch chords details.");
    }
  } catch (error) {
    console.error(error);
    m.reply("An error occurred: " + error.message);
  }
};
handler.help = ["chords"];
handler.tags = ["tools"];
handler.command = /^(chords|chord)$/i;
handler.register = true;
handler.limit = true;
var tools_chord_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
