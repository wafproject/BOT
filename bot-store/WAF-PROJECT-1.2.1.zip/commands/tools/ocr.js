/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - ocr.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_ocr_exports = {};
__export(tools_ocr_exports, {
  default: () => tools_ocr_default
});
module.exports = __toCommonJS(tools_ocr_exports);
var import_axios = __toESM(require("axios"));
var import_form_data = __toESM(require("form-data"));
let handler = async (m, { jagoanproject }) => {
  const performOCR = async (imageBuffer, mime2 = "image/jpeg") => {
    try {
      const form = new import_form_data.default();
      form.append("apikey", "K81241004488957");
      form.append("file", imageBuffer, {
        filename: mime2.includes("png") ? "image.png" : "image.jpg",
        contentType: mime2
      });
      form.append("language", "eng");
      const response = await import_axios.default.post("https://api.ocr.space/parse/image", form, {
        headers: form.getHeaders(),
        maxBodyLength: 16 * 1024 * 1024,
        timeout: 6e4
      });
      if (response.data.OCRExitCode !== 1) {
        throw new Error("Gagal melakukan OCR, periksa gambar atau API key.");
      }
      return response.data.ParsedResults?.[0]?.ParsedText || "Tidak ada teks yang terdeteksi.";
    } catch (error) {
      console.error("Terjadi kesalahan OCR:", error);
      throw error;
    }
  };
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || "";
  if (!mime) throw "Balas gambar dengan perintah .ocr";
  if (!/image\/(jpe?g|png)/.test(mime)) throw `_*Jenis ${mime} tidak didukung!*_`;
  try {
    const img = await q.download();
    if (!img) throw new Error("Gambar gagal diunduh!");
    const textResult = await performOCR(Buffer.from(img), mime);
    console.log("Hasil OCR:", textResult);
    await m.reply(textResult);
  } catch (err) {
    console.error(err);
    throw `Terjadi kesalahan: ${err.message || err}`;
  }
};
handler.help = ["ocr", "totext"];
handler.tags = ["tools", "premium"];
handler.command = /^(ocr|totext)$/i;
handler.limit = true;
handler.premium = true;
handler.register = true;
var tools_ocr_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
