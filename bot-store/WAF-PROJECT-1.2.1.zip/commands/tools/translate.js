/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - translate.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_translate_exports = {};
__export(tools_translate_exports, {
  default: () => tools_translate_default
});
module.exports = __toCommonJS(tools_translate_exports);
var __google_translate_api_1 = __toESM(require("@vitalets/google-translate-api"));
const { translate } = __google_translate_api_1;
const defaultLang = "id";
let handler = async (m, { args, usedPrefix, command }) => {
  if (!args[0] && !m.quoted) {
    throw `Reply pesan atau ketik. *\u2022 contoh* :  ${usedPrefix + command} how are you`;
  }
  let lang = args[0];
  let text = args.slice(1).join(" ");
  if ((args[0] || "").length !== 2) {
    lang = defaultLang;
    text = args.join(" ");
  }
  if (!text && m.quoted && m.quoted.text) text = m.quoted.text;
  let result = await translate(text, { to: lang, autoCorrect: true }).catch((_) => null);
  if (!result) throw "*Translation failed.*";
  m.reply(result.text.toString());
};
handler.help = ["translate", "tl", "trid", "tr"].map((a) => a + " *[Lang Query]*");
handler.tags = ["tools"];
handler.command = ["translate", "tl", "trid", "tr"];
handler.register = true;
handler.limit = true;
var tools_translate_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
