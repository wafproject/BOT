/**
 * tools/cloneweb.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/tools/web2zip",
  "command": [
    "webclone",
    "cloneweb",
    "clone"
  ],
  "kind": "download",
  "category": "tools"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
