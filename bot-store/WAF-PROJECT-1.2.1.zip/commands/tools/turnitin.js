/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - turnitin.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_turnitin_exports = {};
__export(tools_turnitin_exports, {
  default: () => tools_turnitin_default
});
module.exports = __toCommonJS(tools_turnitin_exports);
var import_axios = __toESM(require("axios"));
let handler = async (m, { jagoanproject, text }) => {
  if (!text) throw "masukin text dulu donggg~ \u{1F97A}\ncontoh: .turnitin hai";
  try {
    const res = await import_axios.default.post(
      "https://reilaa.com/api/turnitin-match",
      { text },
      { headers: { "Content-Type": "application/json" } }
    );
    const data = res.data;
    if (!data || !data.reilaaResult || !data.reilaaResult.value) {
      throw "hasilnya kosong ihh \u{1F62D}";
    }
    const result = data.reilaaResult.value;
    const hasil = `
\u2728 *Turnitin AI Checker* \u2728

\u{1F9E0} *Classification* : ${result.classification}
\u{1F3AF} *AI Score*       : ${result.aiScore}%
\u26A0\uFE0F *Risk*           : ${result.details?.analysis?.risk || "-"}
\u{1F4A1} *Suggestion*     : ${result.details?.analysis?.suggestion || "-"}

\u{1F4C4} *Text* :
"${result.inputText}"
    `.trim();
    await jagoanproject.sendMessage(
      m.chat,
      { text: hasil },
      { quoted: m }
    );
  } catch (err) {
    const msg = err?.response?.data?.message || err?.message || String(err);
    await jagoanproject.sendMessage(
      m.chat,
      { text: `yahh error \u{1F63F}
${msg}` },
      { quoted: m }
    );
  }
};
handler.help = ["turnitin"];
handler.tags = ["tools"];
handler.command = /^(turnitin)$/i;
handler.register = true;
handler.limit = true;
var tools_turnitin_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
