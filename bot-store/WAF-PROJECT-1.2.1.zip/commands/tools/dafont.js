/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - dafont.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_dafont_exports = {};
__export(tools_dafont_exports, {
  default: () => tools_dafont_default
});
module.exports = __toCommonJS(tools_dafont_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, text, args, usedPrefix, command }) => {
  if (!text) {
    throw `*Cara Pakai: ${usedPrefix}${command} <subcommand> [query/link]*

Subcommand:
1. *search [nama_font]* - Cari font berdasarkan nama
2. *dl [link_download]* - Unduh font dari link

Contoh:
${usedPrefix}${command} search fancy
${usedPrefix}${command} dl https://dl.dafont.com/dl/?f=fancy_nancy_2`;
  }
  let [subcommand, ...query] = args;
  subcommand = subcommand?.toLowerCase();
  let queryText = query.join(" ");
  if (subcommand === "search") {
    if (!queryText) throw "Masukkan nama font untuk dicari!";
    await handleSearch(m, jagoanproject, queryText);
  } else if (subcommand === "dl") {
    if (!queryText) throw "Masukkan link download!";
    await handleDownload(m, jagoanproject, queryText);
  } else {
    throw `Subcommand tidak valid! Gunakan:
${usedPrefix}${command} search [nama_font]
${usedPrefix}${command} dl [link_download]`;
  }
};
async function handleSearch(m, jagoanproject, query) {
  await jagoanproject.sendMessage(m.chat, { text: "Mencari font..." }, { quoted: m });
  try {
    let result = await dafont(query);
    if (result.length === 0) {
      throw `Font "${query}" tidak ditemukan!`;
    }
    let teks = `*\u300E PENCARIAN DAFONT \u300F*

`;
    result.forEach((font, i) => {
      teks += `*${i + 1}. ${font.name}*
\u250C\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
\u251C *Pembuat:* ${font.creator}
\u251C *Total Unduhan:* ${font.total_down}
\u251C *Link:* ${font.link}
\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

`;
    });
    teks += `Untuk mengunduh, gunakan:
*.dafont dl [link]*`;
    await jagoanproject.sendMessage(m.chat, { text: teks }, { quoted: m });
  } catch (error) {
    console.error(error);
    throw "Gagal mencari font. Coba lagi nanti.";
  }
}
async function handleDownload(m, jagoanproject, url) {
  if (!url.startsWith("https://dl.dafont.com/")) {
    throw "Link download tidak valid!";
  }
  await jagoanproject.sendMessage(m.chat, { text: "Mengunduh font..." }, { quoted: m });
  try {
    const response = await (0, import_axios.default)({
      method: "get",
      url,
      responseType: "arraybuffer"
    });
    const fontName = url.split("=").pop();
    const fileName = `${fontName}.zip`;
    await jagoanproject.sendMessage(m.chat, {
      document: response.data,
      mimetype: "application/zip",
      fileName
    }, { quoted: m });
  } catch (error) {
    console.error(error);
    throw "Gagal mengunduh font. Coba lagi nanti.";
  }
}
async function dafont(query) {
  try {
    const { data } = await import_axios.default.get("https://www.dafont.com/search.php?q=" + encodeURIComponent(query));
    const $ = cheerio.load(data);
    const result = [];
    $(".lv1left.dfbg").each((i, el) => {
      let elem = $(el).text();
      let name = elem.split("by")[0].trim();
      let creator = elem.split("by")[1]?.trim() || "Tidak Diketahui";
      let total_down = $(el).next().next().find(".light").text().trim() || "N/A";
      let link = $(el).next().next().next().find("a.dl").attr("href");
      if (link) {
        result.push({
          name,
          creator,
          total_down,
          link: "https:" + link
        });
      }
    });
    return result;
  } catch (error) {
    throw error;
  }
}
handler.command = /^dafont$/i;
handler.tags = ["tools"];
handler.register = true;
handler.limit = true;
var tools_dafont_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
