/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - vocalremover.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_vocalremover_exports = {};
__export(tools_vocalremover_exports, {
  default: () => tools_vocalremover_default
});
module.exports = __toCommonJS(tools_vocalremover_exports);
let fetch;
let uploader;
let __deps_inited = false;
async function __init_deps() {
  if (__deps_inited) return;
  __deps_inited = true;
  {
    const m = await import("node-fetch");
    fetch = m && "default" in m ? m.default : m;
  }
  {
    const m = await import("../../lib/jagoan/lib/uploadFile.js");
    uploader = m && "default" in m ? m.default : m;
  }
}
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  await __init_deps();
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || q.mediaType || "";
  if (!/audio\/(mp3|mpeg)/.test(mime)) {
    return m.reply(`Reply *audio MP3* dengan perintah ${usedPrefix + command}`);
  }
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  try {
    let buffer = await q.download();
    console.log("Downloaded file size:", buffer.length);
    let media = await uploader(buffer);
    console.log("Uploaded media URL:", media);
    const boundary = "----WebKitFormBoundary" + Math.random().toString(16).slice(2);
    const multipartBody = Buffer.concat([
      Buffer.from(`--${boundary}\r
`),
      Buffer.from(`Content-Disposition: form-data; name="fileName"; filename="audio.mp3"\r
`),
      Buffer.from(`Content-Type: audio/mpeg\r
\r
`),
      buffer,
      Buffer.from(`\r
--${boundary}--\r
`)
    ]);
    let uploadResponse = await fetch("https://aivocalremover.com/api/v2/FileUpload", {
      method: "POST",
      headers: {
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": multipartBody.length,
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "XMLHttpRequest"
      },
      body: multipartBody
    });
    let uploadRes = await uploadResponse.json();
    console.log("Upload response:", uploadRes);
    if (uploadRes.error) {
      throw uploadRes.message || "Gagal mengunggah audio ke aivocalremover.";
    }
    const params = new URLSearchParams({
      file_name: uploadRes.file_name,
      action: "watermark_video",
      key: uploadRes.key,
      web: "web"
    });
    let processResponse = await fetch("https://aivocalremover.com/api/v2/ProcessFile", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "XMLHttpRequest"
      },
      body: params.toString()
    });
    let processRes = await processResponse.json();
    console.log("Process response:", processRes);
    if (processRes.error) {
      throw processRes.message || "Gagal memproses audio.";
    }
    await jagoanproject.sendMessage(m.chat, {
      audio: { url: processRes.instrumental_path },
      mimetype: "audio/mpeg",
      fileName: "instrumental.mp3"
    }, {
      quoted: m,
      caption: "Hasil Instrumental (musik tanpa vokal)"
    });
    await jagoanproject.sendMessage(m.chat, {
      audio: { url: processRes.vocal_path },
      mimetype: "audio/mpeg",
      fileName: "vocal.mp3"
    }, {
      quoted: m,
      caption: "Hasil Vokal (suara tanpa musik)"
    });
  } catch (e) {
    console.error("Error:", e);
    throw e.message || "*[INTERNAL SERVER ERROR!]*";
  }
};
handler.help = ["vocalremover", "instrumenremover"];
handler.command = ["vocalremover", "instrumenremover", "voiceremover", "voiceremove"];
handler.tags = ["tools", "premium"];
handler.limit = true;
handler.register = true;
var tools_vocalremover_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
