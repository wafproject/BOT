/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - tohtml.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_tohtml_exports = {};
__export(tools_tohtml_exports, {
  default: () => tools_tohtml_default
});
module.exports = __toCommonJS(tools_tohtml_exports);
var import_url = require("url");
var import_path = require("path");
var import_module = require("module");
let uploadImage;
let fetch;
let path;
let __deps_inited = false;
async function __init_deps() {
  if (__deps_inited) return;
  __deps_inited = true;
  {
    const m = await import("../../lib/jagoan/lib/uploadImage.js");
    uploadImage = m && "default" in m ? m.default : m;
  }
  {
    const m = await import("node-fetch");
    fetch = m && "default" in m ? m.default : m;
  }
  {
    const m = await import("path");
    path = m && "default" in m ? m.default : m;
  }
}
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path.dirname)(__filename);
const fs = require2("fs").promises;
const handler = async (m, { jagoanproject }) => {
  await __init_deps();
  try {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    if (!/image/.test(mime)) {
      return jagoanproject.reply(m.chat, "Kirim atau balas gambar dengan caption tocode", m);
    }
    await jagoanproject.reply(
      m.chat,
      `\u23F3 *Sedang memproses gambar Anda...* \u23F3
Mohon tunggu 1-2 menit ya! Website sedang dibuat dengan cinta \u{1F496}\u2728`,
      m
    );
    const media = await q.download();
    if (!media) throw new Error("Gagal mendownload media");
    const uploadedImageUrl = await uploadImage(media);
    if (!uploadedImageUrl) throw new Error("Gagal mengupload gambar");
    console.log(`Gambar berhasil diupload: ${uploadedImageUrl}`);
    const apiUrl = `https://fastrestapis.fasturl.cloud/aiexperience/screenshottocode?imageUrl=${encodeURIComponent(uploadedImageUrl)}`;
    const response = await fetch(apiUrl, { timeout: 3e4 });
    if (!response.ok) throw new Error(`API request failed with status: ${response.status}`);
    const result = await response.json();
    console.log(`Hasil dari API: ${JSON.stringify(result)}`);
    if (result.status === 200 && result.result) {
      const extractedCode = result.result.code;
      const responsiveHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screenshot to Code</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }
        .responsive-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }
        @media (max-width: 768px) {
            .responsive-container {
                padding: 10px;
            }
        }
        /* Pastikan elemen dalam extractedCode responsif */
        img, video, iframe {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="responsive-container">
        ${extractedCode}
    </div>
</body>
</html>
            `;
      const fileName = `result_${Date.now()}.html`;
      const filePath = path.join(__dirname, fileName);
      await fs.writeFile(filePath, responsiveHtml);
      await jagoanproject.sendMessage(m.chat, {
        document: { url: filePath },
        mimetype: "text/html",
        fileName: "Result.html",
        caption: `\u{1F389} *Website Anda Sudah Jadi!* \u{1F389}
Silakan download file di atas dan buka di browser Anda! \u{1F310}\u2728
\u2728 *Responsif untuk semua perangkat!* \u2728`
      }, { quoted: m });
      setTimeout(() => fs.unlink(filePath).catch(console.error), 5e3);
    } else {
      throw new Error("API tidak mengembalikan hasil yang valid");
    }
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    const errorMessage = error.message === "Gagal mengupload gambar" ? "\u26A0 Gagal mengupload gambar, coba lagi nanti ya! \u{1F613}" : "\u274C Oops! Terjadi kesalahan saat memproses: " + error.message + " \u{1F622}";
    await jagoanproject.reply(m.chat, errorMessage, m);
  }
};
handler.help = ["tocode *kirim/reply gambar*"];
handler.tags = ["tools"];
handler.command = /^(imgtocode|sstocode|tocode|tohtml)$/i;
handler.register = true;
handler.limit = true;
var tools_tohtml_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
