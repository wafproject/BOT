/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - enchtml.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_enchtml_exports = {};
__export(tools_enchtml_exports, {
  default: () => tools_enchtml_default
});
module.exports = __toCommonJS(tools_enchtml_exports);
var import_crypto_js = __toESM(require("crypto-js"));
let handler = async (m, { jagoanproject, text }) => {
  try {
    if (!m.quoted) {
      return jagoanproject.sendMessage(m.chat, { text: "\u26A0\uFE0F Reply pesan yang berisi kode HTML yang mau di-encrypt." });
    }
    const quoted = m.quoted;
    const html = quoted.text && quoted.text.toString && quoted.text.toString() || quoted.message && quoted.message.conversation || quoted.message && quoted.message.extendedTextMessage && quoted.message.extendedTextMessage.text || "";
    if (!html || html.trim().length === 0) {
      return jagoanproject.sendMessage(m.chat, { text: "\u274C Gagal membaca HTML dari pesan yang di-reply. Pastikan pesan tersebut berisi kode HTML sebagai teks." });
    }
    const password = (text || "").trim();
    const usePassword = password.length > 0;
    const ciphertext = import_crypto_js.default.AES.encrypt(html, password).toString();
    const safeCipher = ciphertext.replace(/(["\\])/g, "\\$1");
    const wrapper = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Encrypted HTML</title>
</head>
<body>

  <!-- CryptoJS CDN -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"><\/script>
  <script>
    (function(){
      try {
        var ciphertext = "${safeCipher}";
        var pass = ${usePassword ? "prompt('Masukkan password untuk membuka halaman:')" : "''"};
        if (${usePassword} && pass === null) {
          document.getElementById('status').innerText = 'Decrypt dibatalkan.';
          return;
        }
        var bytes = CryptoJS.AES.decrypt(ciphertext, pass || '');
        var original = bytes.toString(CryptoJS.enc.Utf8);
        if (!original) throw new Error('Password salah atau isi rusak.');
        document.open();
        document.write(original);
        document.close();
      } catch (e) {
        document.getElementById('status').innerText = 'Gagal membuka halaman: ' + e.message;
      }
    })();
  <\/script>
</body>
</html>`;
    await jagoanproject.sendMessage(m.chat, {
      document: Buffer.from(wrapper, "utf8"),
      fileName: "encrypted.html",
      mimetype: "text/html"
    });
    if (usePassword) {
      await jagoanproject.sendMessage(m.chat, {
        text: "\u2705 Selesai \u2014 HTML berhasil di-encrypt dengan password yang kamu berikan.\n\n\u{1F510} *Catatan penting:* File akan meminta password saat dibuka. Jangan bagikan password ini di chat umum \u2014 bagi ke penerima secara terpisah.\n\n\u2022 Jika mau agar aku mengirim password ke chat ini juga, sebutkan saat pemanggilan, tapi itu mengurangi keamanan."
      });
    } else {
      await jagoanproject.sendMessage(m.chat, {
        text: "\u2705 Selesai \u2014 HTML telah di-encrypt tanpa password (auto-decrypt di browser). Ini hanya obfuscation ringan, bukan proteksi penuh."
      });
    }
  } catch (err) {
    console.error("\u274C Error enchtml:", err);
    await jagoanproject.sendMessage(m.chat, { text: `\u274C Gagal mengencrypt HTML:
${err.message}` });
  }
};
handler.help = ["enchtml", "enchtml <password>"];
handler.tags = ["tools"];
handler.command = /^(enchtml|encryhtml|encrypthtml)$/i;
handler.limit = 20;
handler.register = true;
var tools_enchtml_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
