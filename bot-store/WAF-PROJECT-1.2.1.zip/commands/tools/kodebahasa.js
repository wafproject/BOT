/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - kodebahasa.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_kodebahasa_exports = {};
__export(tools_kodebahasa_exports, {
  default: () => tools_kodebahasa_default
});
module.exports = __toCommonJS(tools_kodebahasa_exports);
let handler = async (m) => m.reply(`
\u2554\u2550\u2550\u2550\u300C KODE BAHASA GOOGLE \u300D
\u255F Jagoan project
\u255F af : Afrikaans
\u255F sq : Albanian
\u255F ar : Arab
\u255F hy : Armenian
\u255F ca : Catalan
\u255F zh : Chinese
\u255F zh-cn : Chinese (Mandarin/China)
\u255F zh-tw : Chinese (Mandarin/Taiwan)
\u255F zh-yue : Chinese (Cantonese)
\u255F hr : Croatian
\u255F cs : Czech
\u255F da : Danish
\u255F nl : Dutch
\u255F en : English
\u255F en-au : English (Australia)
\u255F en-uk : English (United Kingdom)
\u255F en-us : English (United States)
\u255F eo : Esperanto
\u255F fi : Finnish
\u255F fr : French
\u255F de : German
\u255F el : Greek
\u255F ht : Haitian Creole
\u255F hi : Hindi
\u255F hu : Hungarian
\u255F is : Icelandic
\u255F id : Indonesian
\u255F it : Italian
\u255F ja : Japanese
\u255F ko : Korean
\u255F la : Latin
\u255F lv : Latvian
\u255F mk : Macedonian
\u255F no : Norwegian
\u255F pl : Polish
\u255F pt : Portuguese
\u255F pt-br : Portuguese (Brazil)
\u255F ro : Romanian
\u255F ru : Russian
\u255F sr : Serbian
\u255F sk : Slovak
\u255F es : Spanish
\u255F es-es : Spanish (Spain)
\u255F es-us : Spanish (United States)
\u255F sw : Swahili
\u255F sv : Swedish
\u255F ta : Tamil
\u255F th : Thai
\u255F tr : Turkish
\u255F vi : Vietnamese
\u255F cy : Welsh
\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
`.trim());
handler.help = ["kodebahasa"];
handler.tags = ["tools"];
handler.command = /^kodebahasa$/i;
handler.register = true;
handler.limit = true;
var tools_kodebahasa_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
