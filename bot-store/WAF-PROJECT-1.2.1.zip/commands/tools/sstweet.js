/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - sstweet.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_sstweet_exports = {};
__export(tools_sstweet_exports, {
  default: () => tools_sstweet_default
});
module.exports = __toCommonJS(tools_sstweet_exports);
var import_axios = __toESM(require("axios"));
async function SsPost(tweetUrl) {
  try {
    const match = tweetUrl.match(/status\/(\d+)/);
    if (!match) throw new Error("Link tweet tidak valid, kak! Pastikan URL dari Twitter/X \u{1F614}");
    const tweetId = match[1];
    const payload = {
      templateSlug: "tweet-image",
      modifications: { tweetUrl, tweetId },
      renderType: "images",
      responseFormat: "png",
      responseType: "base64",
      userAPIKey: false
    };
    const { data } = await import_axios.default.post(
      "https://orshot.com/api/templates/make-playground-request",
      JSON.stringify(payload),
      {
        headers: {
          "Content-Type": "text/plain; charset=UTF-8",
          "Origin": "https://orshot.com",
          "Referer": "https://orshot.com/templates/tweet-image/generate",
          "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/107.0.0.0 Safari/537.36",
          "Accept": "*/*"
        }
      }
    );
    if (!data?.data?.content) throw new Error("Gagal mendapatkan screenshot tweet \u{1F614}");
    const base64Data = data.data.content.replace(/^data:image\/png;base64,/, "");
    return Buffer.from(base64Data, "base64");
  } catch (err) {
    throw new Error(err.message);
  }
}
let handler = async (m, { jagoanproject, args, text, usedPrefix, command }) => {
  if (!text) {
    return jagoanproject.sendMessage(m.chat, {
      text: `\u{1F4CC} Masukkan link tweet, kak! Contoh: *${usedPrefix}${command} https://x.com/username/status/12345* \u{1F343}`,
      contextInfo: {
        extendedPreview: {
          title: "Fitur Screenshot Tweet \u2728",
          body: "",
          thumbnailUrl: global.thumb2,
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  }
  if (!/^https?:\/\/(www\.)?(twitter\.com|x\.com)\/.*\/status\/\d+/i.test(text)) {
    return jagoanproject.sendMessage(m.chat, {
      text: "\u{1F4CC} Link tweet tidak valid, kak! Pastikan URL dari Twitter/X dan berisi /status/ \u{1F614}",
      contextInfo: {
        extendedPreview: {
          title: "Error Screenshot Tweet \u{1F6AB}",
          body: "",
          thumbnailUrl: global.thumb4,
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  }
  try {
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F343}", key: m.key } });
    const imgbuff = await SsPost(text);
    await jagoanproject.sendFile(m.chat, imgbuff, "tweet_screenshot.png", `\u2705 Screenshot tweet berhasil diambil! \u{1F33F}`, m);
  } catch (e) {
    console.error("Error processing tweet screenshot:", e);
    return jagoanproject.sendMessage(m.chat, {
      text: `\u274C Terjadi kesalahan: ${e.message} \u{1F614} Coba lagi nanti ya! \u{1F343}`,
      contextInfo: {
        extendedPreview: {
          title: "Error Screenshot Tweet \u{1F6AB}",
          body: "",
          thumbnailUrl: global.thumb4,
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  }
};
handler.help = ["sstweet <url>"];
handler.tags = ["tools"];
handler.command = /^sstweet$/i;
handler.limit = true;
handler.register = true;
var tools_sstweet_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
