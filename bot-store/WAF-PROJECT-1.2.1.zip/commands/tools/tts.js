/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - tts.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_tts_exports = {};
__export(tools_tts_exports, {
  default: () => tools_tts_default
});
module.exports = __toCommonJS(tools_tts_exports);
var import_node_fetch = __toESM(require("node-fetch"));
const API_BASE_URL = "https://api.elevenlabs.io/v1";
function getElevenLabsApiKey() {
  return String(global.elevenLabsApiKey || "").trim().replace(/^['"]|['"]$/g, "");
}
let cachedVoices = null;
let cachedApiKey = "";
let cacheTimestamp = 0;
const CACHE_DURATION = 3600 * 1e3;
async function handler(m, { jagoanproject, usedPrefix, args, command, text }) {
  const apiKey = getElevenLabsApiKey();
  if (!apiKey || apiKey === "YOUR_ELEVENLABS_API_KEY") {
    return m.reply("Kunci API ElevenLabs belum dikonfigurasi untuk plugin ini.");
  }
  try {
    const voiceMatch = command.match(/^tts-(.+)/i);
    if (!voiceMatch || !voiceMatch[1]) {
      console.log(`Perintah tidak valid untuk TTS: ${command}`);
      return;
    }
    const voiceIdentifier = voiceMatch[1].trim().toLowerCase();
    const inputText = text.trim();
    if (!inputText) {
      const voices2 = await getVoices(m);
      const voiceList = voices2 ? voices2.map((v) => v.name).join(", ") : "(tidak dapat mengambil daftar suara)";
      return m.reply(`\u274C *Format tidak valid*

 \u{1F4DD} Contoh Penggunaan: .tts-<nama_suara> <teks> (.tts-aria Halo apa kabar?)

\u{1F50A} Suara yang tersedia:
 ${voiceList}`);
    }
    const voices = await getVoices(m);
    if (!voices || voices.length === 0) {
      return m.reply("Tidak dapat mengambil daftar suara dari ElevenLabs. Silakan periksa kunci API atau jaringan.");
    }
    const selectedVoice = voices.find((v) => v.name.toLowerCase() === voiceIdentifier);
    if (!selectedVoice) {
      const availableVoiceNames = voices.map((v) => v.name).join(", ");
      return m.reply(`Suara "${voiceIdentifier}" tidak ditemukan. Suara yang tersedia: ${availableVoiceNames}`);
    }
    const voiceId = selectedVoice.voice_id;
    await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
    const audioBuffer = await generateSpeech(inputText, voiceId, m);
    if (audioBuffer) {
      jagoanproject.sendMessage(m.chat, { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true }, { quoted: m });
    } else {
      await jagoanproject.sendMessage(m.chat, global.eror, { quoted: m });
    }
  } catch (error) {
    console.error("TTS Plugin Error:", error);
    await jagoanproject.sendMessage(m.chat, { ...global.eror, text: `${global.eror.text}

Detail: ${error.message}` }, { quoted: m });
  }
}
async function getVoices(m) {
  const now = Date.now();
  const apiKey = getElevenLabsApiKey();
  if (!apiKey || apiKey === "YOUR_ELEVENLABS_API_KEY") {
    throw new Error("Kunci API ElevenLabs belum dikonfigurasi untuk plugin ini.");
  }
  if (cachedApiKey !== apiKey) {
    cachedVoices = null;
    cacheTimestamp = 0;
    cachedApiKey = apiKey;
  }
  if (cachedVoices && now - cacheTimestamp < CACHE_DURATION) {
    return cachedVoices;
  }
  try {
    const response = await (0, import_node_fetch.default)(`${API_BASE_URL}/voices`, {
      headers: { "xi-api-key": apiKey }
    });
    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Kesalahan API (${response.status}): ${response.statusText}. ${errorBody}`);
    }
    const data = await response.json();
    const allVoicesFromAPI = data.voices.map((v) => ({ name: v.name, voice_id: v.voice_id }));
    const customVoices = [
      { name: "Putra", voice_id: "RWiGLY9uXI70QL540WNd" },
      { name: "Mahaputra", voice_id: "v70fYBHUOrHA3AKIBjPq" },
      { name: "Andi", voice_id: "TMvmhlKUioQA4U7LOoko" }
    ];
    const combinedVoices = [...customVoices, ...allVoicesFromAPI.filter(
      (apiVoice) => !customVoices.some((customVoice) => customVoice.name.toLowerCase() === apiVoice.name.toLowerCase())
    )];
    if (!combinedVoices || combinedVoices.length === 0) {
      m.reply("Tidak ada suara yang ditemukan (termasuk suara kustom).");
      return null;
    }
    cachedVoices = combinedVoices;
    cacheTimestamp = now;
    return cachedVoices;
  } catch (error) {
    console.error("Kesalahan saat mengambil suara:", error);
    m.reply(`Kesalahan saat mengambil suara dari ElevenLabs: ${error.message}`);
    return null;
  }
}
async function generateSpeech(text, voiceId, m) {
  try {
    const apiKey = getElevenLabsApiKey();
    if (!apiKey || apiKey === "YOUR_ELEVENLABS_API_KEY") {
      throw new Error("Kunci API ElevenLabs belum dikonfigurasi untuk plugin ini.");
    }
    const response = await (0, import_node_fetch.default)(`${API_BASE_URL}/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "xi-api-key": apiKey,
        "Accept": "audio/mpeg"
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_multilingual_v2",
        // Model default yang bagus untuk banyak bahasa
        voice_settings: {
          stability: 0.7,
          similarity_boost: 0.75
          // style: 0.3, // Opsional: Sesuaikan penekanan gaya
          // use_speaker_boost: true // Opsional: Tingkatkan kejelasa bicara
        }
      })
    });
    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Kesalahan API (${response.status}): ${response.statusText}. ${errorBody}`);
    }
    const audioBuffer = await response.arrayBuffer();
    return Buffer.from(audioBuffer);
  } catch (error) {
    console.error("Kesalahan saat menghasilkan suara:", error);
    m.reply(`Kesalahan saat menghasilkan suara: ${error.message}`);
    return null;
  }
}
handler.tags = ["sound"];
handler.command = /^tts-([a-zA-Z0-9]+)$/i;
handler.limit = true;
handler.register = true;
handler.help = ["tts-<nama_suara> <teks>"];
async function updateHelp() {
  try {
    const voices = await getVoices({ reply: console.log });
    if (voices && voices.length > 0) {
      handler.help = voices.map((v) => `tts-${v.name.toLowerCase()} <teks>`);
      console.log("Bantuan TTS diperbarui dengan daftar suara.");
    } else {
      handler.help = ["tts-<nama_suara> <teks> (gagal mengambil daftar suara)"];
      console.warn("Gagal memperbarui bantuan TTS dengan daftar suara.");
    }
  } catch (error) {
    console.error("Kesalahan saat memperbarui bantuan TTS:", error);
    handler.help = ["tts-<nama_suara> <teks> (error saat mengambil daftar suara)"];
  }
}
var tools_tts_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
