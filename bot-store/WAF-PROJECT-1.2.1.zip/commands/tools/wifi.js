/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - wifi.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_wifi_exports = {};
__export(tools_wifi_exports, {
  default: () => tools_wifi_default
});
module.exports = __toCommonJS(tools_wifi_exports);
let handler = (m, { text, usedPrefix, command }) => {
  if (!text) throw "_Masukkan nama wifi!_\n\nContoh:\n" + usedPrefix + command + " fh_8eaf58";
  if (!/^fh_[0-9a-f]{6}$/.test(text.toLowerCase())) {
    throw "_Format nama wifi salah!_\nGunakan format: fh_xxxxxx (6 karakter setelah fh_)";
  }
  const encryptDict = {
    "1": "e",
    "2": "d",
    "3": "c",
    "4": "b",
    "5": "a",
    "6": "9",
    "7": "8",
    "8": "7",
    "9": "7",
    "0": "f",
    "f": "0",
    "e": "1",
    "a": "5"
  };
  const decryptDict = {
    "e": ["1"],
    "d": ["2"],
    "c": ["3"],
    "b": ["4"],
    "a": ["5"],
    "9": ["6"],
    "8": ["7"],
    "7": ["8", "9"],
    "f": ["0"],
    "0": ["f"],
    "1": ["e"],
    "5": ["a"]
  };
  let code = text.toLowerCase().slice(3);
  let encrypted = "wlan";
  encrypted += code.split("").map((char) => encryptDict[char] || char).join("");
  let possibilities = [""];
  code.split("").forEach((char) => {
    let options = decryptDict[encryptDict[char]] || [char];
    let newPossibilities = [];
    possibilities.forEach((p) => {
      options.forEach((o) => {
        newPossibilities.push(p + o);
      });
    });
    possibilities = newPossibilities;
  });
  let result = `\u{1F310} *Nama Wifi:* ${text}
\u{1F511} *Password Utama:* ${encrypted}

`;
  if (possibilities.length > 1) {
    result += "\u{1F50D} *Kemungkinan Password Lain:*\n";
    possibilities.forEach((opt, i) => {
      if ("wlan" + opt !== encrypted) {
        result += `${i + 1}. wlan${opt}
`;
      }
    });
  }
  result += "\n\u2728 Gunakan password dengan bijak ya!";
  m.reply(result);
};
handler.tags = ["tools", "fun"];
handler.command = ["wifi"];
handler.help = ["wifi <fh_xxxxxx>"];
handler.register = true;
handler.limit = true;
var tools_wifi_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
