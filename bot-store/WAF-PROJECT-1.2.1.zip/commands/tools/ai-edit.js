/**
 * tools/ai-edit.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/maker/imgedit",
  "command": [
    "aiedit"
  ],
  "kind": "media",
  "mediaInput": true,
  "category": "ai"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
