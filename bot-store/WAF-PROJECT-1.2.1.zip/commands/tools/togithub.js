/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - togithub.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_togithub_exports = {};
__export(tools_togithub_exports, {
  default: () => tools_togithub_default
});
module.exports = __toCommonJS(tools_togithub_exports);
var __child_process_1 = __toESM(require("child_process"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
let { execSync } = __child_process_1;
const username = "typographuniverse";
const repo = "uploader-Jagpro";
const branch = "main";
const email = "jagoanproject@example.com";
const LOCAL_DIR = "/home/container/tmp";
const TARGET_FOLDER = "Uploads";
const MAX_SIZE = 100 * 1024 * 1024;
process.env.GIT_DISCOVERY_ACROSS_FILESYSTEM = "1";
function getGithubToken() {
  try {
    if (typeof global !== "undefined" && global.tokengithub) return global.tokengithub;
  } catch (e) {
  }
  return process.env.GITHUB_TOKEN || "";
}
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || "";
  if (!mime) {
    return m.reply(
      `\u{1F4CE} Kirim file dengan caption *${usedPrefix + command}* atau balas file dengan perintah:
> ${usedPrefix + command}`
    );
  }
  if (q.fileLength > MAX_SIZE) {
    return m.reply(`\u{1F6AB} Ukuran file terlalu besar!

\u{1F4E6} Maksimum: *100 MB*`);
  }
  const token = getGithubToken();
  if (!token) {
    return m.reply(
      `\u274C *GitHub token tidak ditemukan!*

Set dulu di *settings.js*:
> global.tokengithub = 'ghxxxxx'

Atau set env *GITHUB_TOKEN*.`
    );
  }
  const GIT_REPO = `https://${username}:${token}@github.com/${username}/${repo}.git`;
  try {
    let buffer = await q.download();
    if (!buffer) {
      return m.reply(`\u274C Gagal mengunduh file, coba lagi nanti.`);
    }
    let ext = String(mime.split("/")[1] || "bin").split(";")[0].replace(/[^a-z0-9]/gi, "").slice(0, 10) || "bin"; // WAF: cegah karakter shell dari mimetype
    let fileName = `file-${Date.now()}.${ext}`;
    if (import_fs.default.existsSync(LOCAL_DIR)) {
      try {
        execSync(`git -C "${LOCAL_DIR}" rev-parse --is-inside-work-tree`, { stdio: "ignore" });
      } catch (gitError) {
        import_fs.default.rmSync(LOCAL_DIR, { recursive: true, force: true });
        execSync(`git clone "${GIT_REPO}" "${LOCAL_DIR}"`, { stdio: "inherit" });
      }
    } else {
      execSync(`git clone "${GIT_REPO}" "${LOCAL_DIR}"`, { stdio: "inherit" });
    }
    execSync(`git -C "${LOCAL_DIR}" remote set-url origin "${GIT_REPO}"`, { stdio: "ignore" });
    try {
      execSync(`git -C "${LOCAL_DIR}" checkout ${branch}`, { stdio: "inherit" });
    } catch (e) {
      execSync(`git -C "${LOCAL_DIR}" checkout -b ${branch}`, { stdio: "inherit" });
    }
    let filePath = import_path.default.join(LOCAL_DIR, TARGET_FOLDER, fileName);
    import_fs.default.mkdirSync(import_path.default.dirname(filePath), { recursive: true });
    import_fs.default.writeFileSync(filePath, buffer);
    execSync(`git -C "${LOCAL_DIR}" add .`, { stdio: "inherit" });
    execSync(`git -C "${LOCAL_DIR}" config user.name "${username}"`);
    execSync(`git -C "${LOCAL_DIR}" config user.email "${email}"`);
    execSync(`git -C "${LOCAL_DIR}" commit -m "Upload ${fileName}"`, { stdio: "inherit" });
    execSync(`git -C "${LOCAL_DIR}" push origin ${branch}`, { stdio: "inherit" });
    let fileUrl = `https://raw.githubusercontent.com/${username}/${repo}/${branch}/${TARGET_FOLDER}/${fileName}`;
    if (m.key && jagoanproject.sendMessage) {
      await jagoanproject.sendMessage(m.chat, {
        react: { text: "\u2705", key: m.key }
      });
    }
    await m.reply(
      `\u2705 *Upload Berhasil!*

\u{1F4C4} Nama: ${fileName}

\u{1F517} Link: ${fileUrl}`
    );
    if (import_fs.default.existsSync(LOCAL_DIR)) {
      import_fs.default.readdirSync(LOCAL_DIR).forEach((item) => {
        const itemPath = import_path.default.join(LOCAL_DIR, item);
        import_fs.default.rmSync(itemPath, { recursive: true, force: true });
      });
    }
  } catch (e) {
    console.error(e);
    m.reply(`\u274C Gagal upload ke GitHub.
Error: ${e.message}`);
  }
};
handler.help = ["uploadgithub", "upgit"];
handler.tags = ["tools"];
handler.command = /^uploadgithub|togit|upgit$/i;
handler.limit = 20;
handler.register = true;
var tools_togithub_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
