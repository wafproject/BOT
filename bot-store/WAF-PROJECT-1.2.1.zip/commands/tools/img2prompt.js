/**
 * tools/img2prompt.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/tools/img2prompt",
  "command": [
    "img2prompt"
  ],
  "kind": "text",
  "mediaInput": true,
  "category": "tools"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
