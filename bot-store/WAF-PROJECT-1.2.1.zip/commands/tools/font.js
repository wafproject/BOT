/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - font.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_font_exports = {};
__export(tools_font_exports, {
  default: () => tools_font_default
});
module.exports = __toCommonJS(tools_font_exports);
var __jsdom_1 = __toESM(require("jsdom"));
var import_node_fetch = __toESM(require("node-fetch"));
let { JSDOM } = __jsdom_1;
let handler = async (m, { jagoanproject, text }) => {
  if (!text) return m.reply("Contoh: .font tes");
  jagoanproject.reply(m.chat, Object.entries(await stylizeText(text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text)).map(([name, value]) => `*${name}*
${value}`).join`\n\n`, m);
};
handler.help = ["font", "styletext"].map((v) => v + " <text>");
handler.tags = ["tools"];
handler.command = /^(font|styletext)$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = true;
handler.register = true;
var tools_font_default = handler;
async function stylizeText(text) {
  let res = await (0, import_node_fetch.default)("http://qaz.wtf/u/convert.cgi?text=" + encodeURIComponent(text));
  let html = await res.text();
  let dom = new JSDOM(html);
  let table = dom.window.document.querySelector("table").children[0].children;
  let obj = {};
  for (let tr of table) {
    let name = tr.querySelector(".aname").innerHTML;
    let content = tr.children[1].textContent.replace(/^\n/, "").replace(/\n$/, "");
    obj[name + (obj[name] ? " Reversed" : "")] = content;
  }
  return obj;
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
