/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - cekcode.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_cekcode_exports = {};
__export(tools_cekcode_exports, {
  default: () => tools_cekcode_default
});
module.exports = __toCommonJS(tools_cekcode_exports);
var import_esprima = __toESM(require("esprima"));
let handler = async (m, { text, quoted, usedPrefix, command }) => {
  const code = text || quoted && quoted.text;
  if (!code) return m.reply(`\u{1F4CC} Contoh:
${usedPrefix + command} console.log("halo")
Atau balas pesan berisi kode.`);
  try {
    import_esprima.default.parseScript(code);
  } catch (err) {
    const row = err.lineNumber || 0;
    const col = err.column || 0;
    const lines = code.split("\n");
    const barisError = lines[row - 1] || "";
    const pointer = " ".repeat(Math.max(col - 1, 0)) + "^";
    let pesan = `\u274C *Syntax Error Terdeteksi!*

\u{1F4CC} *Jenis:* ${err.description}
\u{1F4CD} *Lokasi:* Baris ${row}, Kolom ${col}

\u{1F4C4} *Cuplikan Baris ${row}:*
\`\`\`js
${barisError}
${pointer}
\`\`\`
`;
    return m.reply(pesan);
  }
  try {
    new Function(code);
    return m.reply("\u2705 Kode valid. Tidak ada syntax maupun runtime error.");
  } catch (err) {
    let pesan = `\u26A0\uFE0F *Runtime Error Terdeteksi!*

\u{1F4CC} *Jenis:* ${err.name}
\u{1F4E2} *Pesan:* ${err.message}
\u{1F4CE} Catatan: Runtime error terjadi saat kode dijalankan, bukan karena salah tulis struktur.
`;
    return m.reply(pesan);
  }
};
handler.help = ["cekcode <teks>/<reply>"];
handler.tags = ["tools"];
handler.command = /^cekcode$/i;
handler.limit = true;
handler.register = true;
var tools_cekcode_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
