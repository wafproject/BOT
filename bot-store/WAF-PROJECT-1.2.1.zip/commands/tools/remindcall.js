/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - remindcall.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_remindcall_exports = {};
__export(tools_remindcall_exports, {
  default: () => tools_remindcall_default
});
module.exports = __toCommonJS(tools_remindcall_exports);
var import_ms = __toESM(require("ms"));
var import_moment_timezone = __toESM(require("moment-timezone"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const libDir = import_path.default.join(__dirname, "../../database");
const dbPath = import_path.default.join(libDir, "pengingat.json");
if (!import_fs.default.existsSync(libDir)) {
  import_fs.default.mkdirSync(libDir, { recursive: true });
}
if (!import_fs.default.existsSync(dbPath)) {
  import_fs.default.writeFileSync(dbPath, JSON.stringify({}));
}
const readDb = () => JSON.parse(import_fs.default.readFileSync(dbPath, "utf-8"));
const writeDb = (data) => import_fs.default.writeFileSync(dbPath, JSON.stringify(data, null, 2));
const normalizePhoneNumber = (number) => {
  number = number.replace(/[\s-]/g, "");
  if (number.startsWith("0")) number = "62" + number.slice(1);
  if (!number.startsWith("62")) number = "62" + number;
  if (!number.endsWith("@s.whatsapp.net")) number += "@s.whatsapp.net";
  return number;
};
let handler = async (m, { text, jagoanproject, participants }) => {
  let targetUser = m.sender;
  let pesan, waktu, targetInput;
  if (!text.includes("|")) {
    return m.reply("\u203C\uFE0F *Format tidak valid*\n\n\u{1F4DD} *Contoh penggunaan:*\n\n> .remindcall @user|makan|13:21\n> .remindcall +62895362282300|makan|10m\n> .remindcall 082123456789|makan|10m\n> .remindcall me|olahraga|20m");
  }
  [targetInput, pesan, waktu] = text.split("|").map((a) => a.trim());
  if (!pesan || !waktu || !targetInput) {
    return m.reply("\u203C\uFE0F *Format tidak valid*\n\n\u2013 Kamu harus memasukkan target, pesan, dan waktu.\n\n\u{1F4DD} *Contoh penggunaan:*\n\n.remindcall @user|makan|13:21\n\n.remindcall +62895362282300|makan|10m\n\n.remindcall me|olahraga|20m");
  }
  if (targetInput.toLowerCase() === "me") {
    targetUser = m.sender;
  } else if (targetInput.startsWith("@")) {
    let cleanedTag = targetInput.replace("@", "");
    let foundUser = participants.find((p) => p.id.includes(cleanedTag));
    if (!foundUser && !m.isGroup) {
      foundUser = { id: `${cleanedTag}@s.whatsapp.net` };
    }
    if (!foundUser) {
      return m.reply("\u203C\uFE0F *Pengguna tidak ditemukan!* Pastikan tag valid atau pengguna ada di grup.");
    }
    targetUser = foundUser.id;
  } else {
    targetUser = normalizePhoneNumber(targetInput);
  }
  const timeZoneConfig = {
    WIB: false,
    // Asia/Jakarta
    WITA: true,
    // Asia/Makassar
    WIT: false
    // Asia/Jayapura
  };
  let timeZone;
  if (timeZoneConfig.WIB) timeZone = "Asia/Jakarta";
  else if (timeZoneConfig.WITA) timeZone = "Asia/Makassar";
  else if (timeZoneConfig.WIT) timeZone = "Asia/Jayapura";
  else timeZone = "Asia/Makassar";
  const timePattern = /^(\d+)(s|m|h)$/i;
  const clockPattern = /^(\d{1,2}):(\d{2})$/;
  const dateClockPattern = /^(\d{1,2})-(\d{1,2}):(\d{2})$/;
  let delay, targetTime;
  if (timePattern.test(waktu)) {
    delay = (0, import_ms.default)(waktu.toLowerCase());
    if (!delay || delay < 1e3) {
      return m.reply("\u203C\uFE0F *Minimal waktu satu detik!*");
    }
    targetTime = (0, import_moment_timezone.default)().tz(timeZone).add(delay, "ms");
  } else if (clockPattern.test(waktu)) {
    const [hours, minutes] = waktu.split(":").map(Number);
    if (hours > 23 || minutes > 59) {
      return m.reply("\u203C\uFE0F *Format jam tidak valid!* Gunakan HH:mm (contoh: 13:21).");
    }
    targetTime = (0, import_moment_timezone.default)().tz(timeZone).set({ hour: hours, minute: minutes, second: 0 });
    if (targetTime.isBefore((0, import_moment_timezone.default)().tz(timeZone))) {
      targetTime.add(1, "day");
    }
    delay = targetTime.diff((0, import_moment_timezone.default)().tz(timeZone));
  } else if (dateClockPattern.test(waktu)) {
    const [day, hours, minutes] = waktu.split(/[-:]/).map(Number);
    const currentYear = (0, import_moment_timezone.default)().tz(timeZone).year();
    const currentMonth = (0, import_moment_timezone.default)().tz(timeZone).month();
    if (day < 1 || day > 31 || hours > 23 || minutes > 59) {
      return m.reply("\u203C\uFE0F *Format tanggal/jam tidak valid!* Gunakan DD-HH:mm (contoh: 13-13:21).");
    }
    targetTime = (0, import_moment_timezone.default)().tz(timeZone).set({
      year: currentYear,
      month: currentMonth,
      date: day,
      hour: hours,
      minute: minutes,
      second: 0
    });
    if (targetTime.isBefore((0, import_moment_timezone.default)().tz(timeZone))) {
      return m.reply("\u203C\uFE0F *Tanggal/jam sudah lewat!* Pilih waktu di masa depan.");
    }
    delay = targetTime.diff((0, import_moment_timezone.default)().tz(timeZone));
  } else {
    return m.reply("\u203C\uFE0F *Format waktu tidak valid!*\n\n\u2013 Gunakan:\n  - `s` (detik), `m` (menit), `h` (jam)\n  - HH:mm (jam)\n  - DD-HH:mm (tanggal dan jam)");
  }
  if (delay <= 0) {
    return m.reply("\u203C\uFE0F *Waktu tidak valid!* Pastikan waktu di masa depan.");
  }
  const db = readDb();
  const chatId = m.chat;
  if (!db[chatId]) db[chatId] = [];
  const reminderId = Date.now().toString();
  db[chatId].push({
    id: reminderId,
    pesan,
    targetUser,
    targetTime: targetTime.toISOString(),
    delay,
    chatId,
    isCall: true
  });
  writeDb(db);
  await jagoanproject.reply(m.chat, `\u2705 *Pengingat panggilan telah diterima.*

\u2013 Bot akan memanggil @${targetUser.split("@")[0]} sesuai format yang diminta.

\u2013 \u23F0 Waktu: *${(0, import_moment_timezone.default)(targetTime).format("DD-MM-YYYY HH:mm")} ${timeZone.split("/")[1]}*

\u2013 \u{1F4CD} Untuk: *${pesan}*`, m, { mentions: [targetUser] });
  setTimeout(async () => {
    const currentDb = readDb();
    const reminder = currentDb[chatId]?.find((r) => r.id === reminderId);
    if (reminder) {
      try {
        await jagoanproject.sendMessage(reminder.targetUser, {
          text: `\u23F0 *Pengingat Panggilan!*

\u2013 Haii, sudah waktunya *${reminder.pesan}*`
        });
        await jagoanproject.offerCall(reminder.targetUser, true);
        await jagoanproject.sendMessage(reminder.targetUser, {
          text: `\u{1F4DE} *Panggilan Pengingat Selesai!*

\u2013 Ini pengingat untuk: *${reminder.pesan}*`
        });
        currentDb[chatId] = currentDb[chatId].filter((r) => r.id !== reminderId);
        if (currentDb[chatId].length === 0) delete currentDb[chatId];
        writeDb(currentDb);
      } catch (error) {
        console.error("Error saat mengirim panggilan:", error);
        await jagoanproject.sendMessage(reminder.targetUser, {
          text: `\u26A0\uFE0F *Gagal mengirim panggilan untuk pengingat!* Tapi ini pengingat untuk: *${reminder.pesan}*`
        });
      }
    }
  }, delay);
};
handler.help = ["remindcall @user|pesan|waktu", "remindcall +nomor|pesan|waktu", "remindcall me|pesan|waktu"];
handler.tags = ["tools", "group"];
handler.command = /^remindcall$/i;
handler.register = true;
handler.limit = true;
var tools_remindcall_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
