/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - nikparse.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_nikparse_exports = {};
__export(tools_nikparse_exports, {
  default: () => tools_nikparse_default
});
module.exports = __toCommonJS(tools_nikparse_exports);
var import_axios = __toESM(require("axios"));
async function nikParse(nik) {
  try {
    const provincesRes = await import_axios.default.get("https://emsifa.github.io/api-wilayah-indonesia/api/provinces.json");
    const provinces = Object.fromEntries(provincesRes.data.map((p) => [p.id, p.name.toUpperCase()]));
    nik = nik.toString();
    if (nik.length !== 16 || !provinces[nik.slice(0, 2)]) throw new Error("NIK tidak valid: panjang atau kode provinsi salah");
    const provinceId = nik.slice(0, 2);
    const regenciesRes = await import_axios.default.get(`https://emsifa.github.io/api-wilayah-indonesia/api/regencies/${provinceId}.json`);
    const regencies = Object.fromEntries(regenciesRes.data.map((r) => [r.id, r.name.toUpperCase()]));
    if (!regencies[nik.slice(0, 4)]) throw new Error("NIK tidak valid: kode kabupaten/kota salah");
    const regencyId = nik.slice(0, 4);
    const districtsRes = await import_axios.default.get(`https://emsifa.github.io/api-wilayah-indonesia/api/districts/${regencyId}.json`);
    const districts = Object.fromEntries(districtsRes.data.map((d) => [d.id.slice(0, -1), `${d.name.toUpperCase()}`]));
    if (!districts[nik.slice(0, 6)]) throw new Error("NIK tidak valid: kode kecamatan salah");
    const province = provinces[provinceId];
    const city = regencies[regencyId];
    const subdistrict = districts[nik.slice(0, 6)];
    const day = parseInt(nik.slice(6, 8));
    const month = parseInt(nik.slice(8, 10));
    const yearCode = nik.slice(10, 12);
    const uniqCode = nik.slice(12, 16);
    const gender = day > 40 ? "PEREMPUAN" : "LAKI-LAKI";
    const birthDay = day > 40 ? (day - 40).toString().padStart(2, "0") : day.toString().padStart(2, "0");
    const birthYear = yearCode < (/* @__PURE__ */ new Date()).getFullYear().toString().slice(-2) ? `20${yearCode}` : `19${yearCode}`;
    const birthDate = `${birthDay}/${month.toString().padStart(2, "0")}/${birthYear}`;
    const birth = new Date(birthYear, month - 1, birthDay);
    if (isNaN(birth.getTime())) throw new Error("Tanggal lahir tidak valid");
    const today = /* @__PURE__ */ new Date();
    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    let remainingDays = today.getDate() - birth.getDate();
    if (remainingDays < 0) {
      remainingDays += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
      months--;
    }
    if (months < 0) {
      months += 12;
      years--;
    }
    const age = `${years} Tahun ${months} Bulan ${remainingDays} Hari`;
    let ageCategory = "";
    if (years < 12) ageCategory = "Anak-anak";
    else if (years < 18) ageCategory = "Remaja";
    else if (years < 60) ageCategory = "Dewasa";
    else ageCategory = "Lansia";
    const nextBirthday = new Date(today.getMonth() < month - 1 ? today.getFullYear() : today.getFullYear() + 1, month - 1, birthDay);
    const timeDiff = nextBirthday - today;
    const monthsLeft = Math.floor(timeDiff / (1e3 * 60 * 60 * 24 * 30));
    const daysLeft = Math.floor(timeDiff % (1e3 * 60 * 60 * 24 * 30) / (1e3 * 60 * 60 * 24));
    const birthdayCountdown = `${monthsLeft} Bulan ${daysLeft} Hari`;
    const baseDate = new Date(1970, 0, 2);
    const diffDays = Math.floor((birth - baseDate + 864e5) / (1e3 * 60 * 60 * 24));
    const pasaranIndex = Math.round(diffDays % 5 * 2) / 2;
    const pasaranNames = ["Wage", "Kliwon", "Legi", "Pahing", "Pon"];
    const dayNames = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    const birthDateFull = `${birthDay} ${monthNames[month - 1]} ${birthYear}`;
    const pasaran = `${dayNames[birth.getDay()]} ${pasaranNames[pasaranIndex] || ""}, ${birthDay} ${monthNames[month - 1]} ${birthYear}`;
    let zodiac = "";
    if (month === 1 && day >= 20 || month === 2 && day < 19) zodiac = "Aquarius";
    else if (month === 2 && day >= 19 || month === 3 && day < 21) zodiac = "Pisces";
    else if (month === 3 && day >= 21 || month === 4 && day < 20) zodiac = "Aries";
    else if (month === 4 && day >= 20 || month === 5 && day < 21) zodiac = "Taurus";
    else if (month === 5 && day >= 21 || month === 6 && day < 22) zodiac = "Gemini";
    else if (month === 6 && day >= 21 || month === 7 && day < 23) zodiac = "Cancer";
    else if (month === 7 && day >= 23 || month === 8 && day < 23) zodiac = "Leo";
    else if (month === 8 && day >= 23 || month === 9 && day < 23) zodiac = "Virgo";
    else if (month === 9 && day >= 23 || month === 10 && day < 24) zodiac = "Libra";
    else if (month === 10 && day >= 24 || month === 11 && day < 23) zodiac = "Scorpio";
    else if (month === 11 && day >= 23 || month === 12 && day < 22) zodiac = "Sagitarius";
    else if (month === 12 && day >= 22 || month === 1 && day < 20) zodiac = "Capricorn";
    const regencyType = city.includes("KOTA") ? "Kota" : "Kabupaten";
    const areaCode = `${provinceId}.${regencyId.slice(2)}.${nik.slice(4, 6)}`;
    return {
      nik,
      kelamin: gender,
      lahir: birthDate,
      lahir_lengkap: birthDateFull,
      provinsi: {
        kode: provinceId,
        nama: province
      },
      kotakab: {
        kode: regencyId,
        nama: city,
        jenis: regencyType
      },
      kecamatan: {
        kode: nik.slice(0, 6),
        nama: subdistrict
      },
      kode_wilayah: areaCode,
      nomor_urut: uniqCode,
      tambahan: {
        pasaran,
        usia: age,
        kategori_usia: ageCategory,
        ultah: `${birthdayCountdown} Lagi`,
        zodiak: zodiac
      }
    };
  } catch (error) {
    throw new Error(error.message);
  }
}
let handler = async (m, { text, jagoanproject }) => {
  if (!text) throw "Masukkan NIK yang akan di-parse!\n\nContoh: .nikparse 1234567890123456";
  try {
    const result = await nikParse(text);
    let response = `*\u{1F4CB} NIK PARSE RESULT*

`;
    response += `*NIK:* ${result.nik}
`;
    response += `*Kelamin:* ${result.kelamin}
`;
    response += `*Tanggal Lahir:* ${result.lahir}
`;
    response += `*Lahir Lengkap:* ${result.lahir_lengkap}

`;
    response += `*\u{1F5FA}\uFE0F WILAYAH*
`;
    response += `*Provinsi:* ${result.provinsi.nama} (${result.provinsi.kode})
`;
    response += `*${result.kotakab.jenis}:* ${result.kotakab.nama} (${result.kotakab.kode})
`;
    response += `*Kecamatan:* ${result.kecamatan.nama} (${result.kecamatan.kode})
`;
    response += `*Kode Wilayah:* ${result.kode_wilayah}
`;
    response += `*Nomor Urut:* ${result.nomor_urut}

`;
    response += `*\u2728 TAMBAHAN*
`;
    response += `*Pasaran:* ${result.tambahan.pasaran}
`;
    response += `*Usia:* ${result.tambahan.usia}
`;
    response += `*Kategori Usia:* ${result.tambahan.kategori_usia}
`;
    response += `*Ulang Tahun:* ${result.tambahan.ultah}
`;
    response += `*Zodiak:* ${result.tambahan.zodiak}`;
    jagoanproject.reply(m.chat, response, m);
  } catch (error) {
    jagoanproject.reply(m.chat, `\u274C Error: ${error.message}`, m);
  }
};
handler.help = ["nikparse"];
handler.tags = ["tools"];
handler.command = /^(nikparse|nik)$/i;
handler.register = true;
handler.limit = true;
var tools_nikparse_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
