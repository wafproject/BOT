/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - tomp3.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_tomp3_exports = {};
__export(tools_tomp3_exports, {
  default: () => tools_tomp3_default
});
module.exports = __toCommonJS(tools_tomp3_exports);
var import_converter = __toESM(require("../../lib/jagoan/lib/converter.js"));
const { toAudio, toPTT } = import_converter.default;
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (m.quoted ? m.quoted : m.msg).mimetype || "";
  if (!/video|audio/.test(mime)) {
    throw `Balas video/audio dengan perintah *${usedPrefix + command}*`;
  }
  let media = await q.download();
  if (!media) throw "Media tidak dapat diunduh";
  try {
    if (/^(tomp3|toaudio)$/i.test(command)) {
      let audio = await toAudio(media, "mp4");
      await jagoanproject.sendMessage(m.chat, {
        audio: audio.data,
        mimetype: "audio/mpeg",
        fileName: "converted.mp3"
      }, { quoted: m });
    } else if (/^tovn$/i.test(command)) {
      let ptt = await toPTT(media, "mp4");
      await jagoanproject.sendMessage(m.chat, {
        audio: ptt.data,
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        fileName: "voice.ogg"
      }, { quoted: m });
    }
  } catch (err) {
    console.error(err);
    throw "Gagal mengonversi media. Coba lagi dengan file berbeda.";
  }
};
handler.help = ["tomp3", "toaudio", "tovn"].map((v) => v + " (reply audio/video)");
handler.tags = ["tools"];
handler.command = /^(tomp3|toaudio|tovn)$/i;
handler.register = true;
handler.limit = true;
var tools_tomp3_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
