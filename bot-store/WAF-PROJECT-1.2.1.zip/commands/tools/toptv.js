/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - toptv.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_toptv_exports = {};
__export(tools_toptv_exports, {
  default: () => tools_toptv_default
});
module.exports = __toCommonJS(tools_toptv_exports);
let handler = async (m, { jagoanproject, command, usedPrefix }) => {
  try {
    if (m.message.extendedTextMessage) {
      if (!m.message.extendedTextMessage.contextInfo?.quotedMessage?.videoMessage) {
        throw `Balas video dengan perintah ${usedPrefix + command}`;
      }
      var datavid = { ptvMessage: m.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage };
      jagoanproject.relayMessage(m.chat, datavid, {});
    } else {
      if (!m.message.videoMessage) {
        throw `Balas video dengan perintah ${usedPrefix + command}`;
      }
      var datavid = { ptvMessage: m.message.videoMessage };
      jagoanproject.relayMessage(m.chat, datavid, {});
    }
  } catch (error) {
    m.reply(error.toString());
  }
};
handler.help = ["ptv", "toptv"];
handler.command = /^(toptv|ptv|ptvmessage)$/i;
handler.tags = ["tools"];
handler.limit = true;
handler.register = true;
var tools_toptv_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
