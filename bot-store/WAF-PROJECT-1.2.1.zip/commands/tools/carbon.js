/**
 * tools/carbon.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/maker/carbon",
  "command": [
    "carbon"
  ],
  "kind": "media",
  "category": "tools"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
