/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - readqr.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_readqr_exports = {};
__export(tools_readqr_exports, {
  default: () => tools_readqr_default
});
module.exports = __toCommonJS(tools_readqr_exports);
var import_axios = __toESM(require("axios"));
var import_form_data = __toESM(require("form-data"));
let handler = async (m) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime || !/image\/(png|jpe?g)/.test(mime)) {
    throw "Reply gambar QR-nya dengan perintah *.readqr*";
  }
  let media = await q.download();
  const maxSize = 1048576;
  if (media.length > maxSize) {
    throw "Ukuran gambar terlalu besar (lebih dari 1MB). Tolong kirim QR yang lebih kecil / crop area QR saja.";
  }
  try {
    let form = new import_form_data.default();
    form.append("file", media, {
      filename: "qrcode.jpg",
      // bebas, cuma nama file
      contentType: mime || "image/jpeg"
    });
    form.append("outputformat", "json");
    const apiUrl = "https://api.qrserver.com/v1/read-qr-code/";
    let { data } = await import_axios.default.post(apiUrl, form, {
      headers: form.getHeaders()
    });
    const symbol = data?.[0]?.symbol?.[0];
    const result = symbol?.data;
    const errorMsg = symbol?.error;
    if (!result) {
      if (errorMsg) {
        throw `QR tidak terbaca.
Pesan dari server: ${errorMsg}`;
      } else {
        throw "QR tidak terbaca atau kosong! Pastikan gambar fokus & QR-nya jelas.";
      }
    }
    await m.reply(
      `\u2705 QR berhasil dibaca!

\u{1F4E5} Isi QR:
${result}`
    );
  } catch (err) {
    console.error("\u274C Gagal baca QR:", err?.response?.data || err);
    let extra = "";
    try {
      const symbol = err?.response?.data?.[0]?.symbol?.[0];
      if (symbol?.error) {
        extra = `

\u{1F50E} Detail error server: ${symbol.error}`;
      }
    } catch (_) {
    }
    throw `Terjadi kesalahan saat membaca QR.
Pastikan gambar adalah QR code yang jelas & tidak blur.${extra}`;
  }
};
handler.help = ["readqr <reply image>"];
handler.tags = ["tools"];
handler.command = /^readqr$/i;
handler.limit = true;
handler.register = true;
var tools_readqr_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
