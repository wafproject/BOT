/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - runningtext.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_runningtext_exports = {};
__export(tools_runningtext_exports, {
  default: () => tools_runningtext_default
});
module.exports = __toCommonJS(tools_runningtext_exports);
var __child_process_1 = __toESM(require("child_process"));
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
let handler = async (m, { jagoanproject, text }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!/image/.test(mime)) throw `balas gambarnya!`;
  try {
    q = m.quoted.download();
  } catch (e) {
    q = m.download();
  }
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  running(await q).then((vid) => jagoanproject.sendFile(m.chat, vid, "run.mp4", "\nMade with FFmpeg", m));
};
handler.help = ["run"];
handler.tags = ["tools"];
handler.command = /^run$/i;
handler.limit = true;
handler.register = true;
var tools_runningtext_default = handler;
let { spawn } = __child_process_1;
let tmp = import_path.default.join(__dirname, "../src/tmp/");
function running(img, duration = 10, fps = 60) {
  return new Promise((resolve, reject) => {
    let layers = [
      `color=s=512x512:d=${duration}:r=${fps}[bg]`,
      "[0:v]scale=-2:512[img]",
      `[bg][img]overlay=x='(w+h)*((n/${fps})*-1/${duration})+h'`
    ];
    let n = +/* @__PURE__ */ new Date() + "run.jpg";
    let i = import_path.default.join(tmp, n);
    import_fs.default.writeFileSync(i, img);
    console.log(img);
    let o = import_path.default.join(tmp, n + ".mp4");
    let args = [
      "-y",
      "-i",
      i,
      "-t",
      duration.toString(),
      "-filter_complex",
      layers.join(";"),
      "-pix_fmt",
      "yuv420p",
      "-crf",
      "18",
      o
    ];
    console.log("ffmpeg", ...args);
    spawn("ffmpeg", args, { stdio: "inherit" }).on("error", reject).on("close", () => {
      try {
        import_fs.default.unlinkSync(i);
        resolve(import_fs.default.readFileSync(o));
        import_fs.default.unlinkSync(o);
      } catch (e) {
        reject(e);
      }
    });
  });
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
