/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - emoji.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_emoji_exports = {};
__export(tools_emoji_exports, {
  default: () => tools_emoji_default
});
module.exports = __toCommonJS(tools_emoji_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, { jagoanproject, text, command }) => {
  if (!text) return m.reply("[\u2757] Masukkan nama emoji\ncontoh: .emoji car");
  let emot = await simbol(text);
  const p = emot.symbols;
  shuffleArray(p);
  let pus = p.slice(0, 50);
  let woi = [];
  pus.forEach((pus2) => {
    woi.push(pus2);
  });
  jagoanproject.reply(m.chat, woi.join(" "), m);
};
handler.help = ["emoji"];
handler.command = /^(emoji|emot)$/i;
handler.tags = ["tools", "internet"];
handler.register = true;
handler.limit = true;
var tools_emoji_default = handler;
async function simbol(query) {
  try {
    const r = await import_axios.default.get(
      `https://emojidb.org/${query.toLowerCase().trim().split(" ").join("-")}-emojis`,
      {
        headers: {
          pragma: "no-cache",
          priority: "u=0, i",
          "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "document",
          "sec-fetch-mode": "navigate",
          "sec-fetch-site": "none",
          "sec-fetch-user": "?1",
          "upgrade-insecure-requests": "1",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        }
      }
    );
    const $ = cheerio.load(r.data);
    const d = $("div.emoji-list > div.emoji-ctn").map((i, el) => $(el).find("div.emoji").text().trim()).get();
    if (!d.length) throw new Error(`Symbols is empty!`);
    return { query, total: d.length, symbols: d };
  } catch (e) {
    throw new Error(`Error in simbol function: ${e}`);
  }
}
async function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
