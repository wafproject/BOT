/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - rvo.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_rvo_exports = {};
__export(tools_rvo_exports, {
  default: () => tools_rvo_default
});
module.exports = __toCommonJS(tools_rvo_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
const { downloadContentFromMessage } = __zapo_1;
let handler = async (m, { jagoanproject }) => {
  if (!m.quoted) return m.reply("\u274C Harap reply ke pesan view-once!");
  let msg = m.quoted.message || m.quoted;
  let chat = m.chat;
  console.log("DEBUG: Isi pesan yang dikutip =>", JSON.stringify(msg, null, 2));
  await jagoanproject.sendMessage(chat, { react: { text: "\u23F3", key: m.key } });
  if (!msg.viewOnce) {
    return m.reply("\u274C Pesan tersebut bukan view-once!");
  }
  try {
    let mediaType = msg.mimetype.includes("image") ? "image" : msg.mimetype.includes("video") ? "video" : msg.mimetype.includes("audio") ? "audio" : null;
    if (!mediaType) return m.reply("\u26A0\uFE0F Jenis media tidak dikenali.");
    let mediaStream = await downloadContentFromMessage(msg, mediaType);
    if (!mediaStream) return m.reply("\u274C Gagal mengunduh media, coba lagi nanti!");
    let buffer = Buffer.from([]);
    for await (const chunk of mediaStream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    if (!buffer.length) return m.reply("\u274C Gagal mengonversi media, coba lagi nanti!");
    let sendOptions = { quoted: m };
    if (mediaType === "video") {
      sendOptions.video = buffer;
      sendOptions.caption = msg.caption || "";
    } else if (mediaType === "image") {
      sendOptions.image = buffer;
      sendOptions.caption = msg.caption || "";
    } else if (mediaType === "audio") {
      sendOptions.audio = buffer;
      sendOptions.mimetype = "audio/mpeg";
      sendOptions.ptt = true;
    }
    await jagoanproject.sendMessage(chat, sendOptions);
    await jagoanproject.sendMessage(chat, { react: { text: "\u2705", key: m.key } });
  } catch (err) {
    console.error("\u274C Error saat mengunduh media:", err);
    await jagoanproject.sendMessage(chat, { react: { text: "\u274C", key: m.key } });
    return m.reply("\u26A0\uFE0F Terjadi kesalahan saat mengambil pesan view-once. Pastikan pesan belum dihapus dan coba lagi.");
  }
};
handler.command = ["rvo", "readviewonce"];
handler.help = ["rvo", "readviewonce"];
handler.tags = ["tools"];
handler.register = true;
handler.limit = true;
var tools_rvo_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
