/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - catatanlihat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_catatanlihat_exports = {};
__export(tools_catatanlihat_exports, {
  default: () => tools_catatanlihat_default
});
module.exports = __toCommonJS(tools_catatanlihat_exports);
let handler = async (m, { jagoanproject, command, usedPrefix, text }) => {
  global.db.data.users[m.sender].catatan = global.db.data.users[m.sender].catatan || [];
  let i = 0;
  if (global.db.data.users[m.sender].catatan.length == 0) return m.reply("Kamu belum punya catatan!");
  let txt = "\u{1F5D2}\uFE0FDaftar catatan\u{1F5D2}\uFE0F\n\n";
  for (let ct in global.db.data.users[m.sender].catatan) {
    i += 1;
    txt += "[" + i + "]. " + global.db.data.users[m.sender].catatan[ct].title + "\n";
  }
  txt += `
Penggunaan: ${usedPrefix}lihatcatatan 1
Hapus catatan: ${usedPrefix}hapuscatatan 1`;
  if (text.length == 0) return m.reply(txt);
  let catatan = global.db.data.users[m.sender].catatan;
  let split = text.split("|");
  if (catatan.length == 0) return m.reply("Kamu belum memiliki catatan!");
  let n = Number(split[0]) - 1;
  let isi = global.db.data.users[m.sender].catatan[n] != void 0 ? global.db.data.users[m.sender].catatan[n].isi : "Catatan tidak ditemukan!";
  jagoanproject.reply(m.chat, `${isi}`, m, false, {
    contextInfo: {
      mentionedJid: jagoanproject.parseMention(text)
    }
  });
};
handler.help = ["lihatcatatan <title>"];
handler.tags = ["catatan"];
handler.command = /^lihatcatatan$/i;
handler.register = true;
handler.limit = true;
var tools_catatanlihat_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
