/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - cekvirus.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_cekvirus_exports = {};
__export(tools_cekvirus_exports, {
  default: () => tools_cekvirus_default
});
module.exports = __toCommonJS(tools_cekvirus_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_node_fetch = __toESM(require("node-fetch"));
var import_form_data = __toESM(require("form-data"));
const apikeyvirustotal = "b96d9c52c91f66e5afaa3f8f91ada8a0b3a856084b53d3ea67a569f4ec9817da";
const TMP_DIR = import_path.default.join(process.cwd(), "tmp");
const MAX_POLL = 18;
const POLL_DELAY = 5e3;
const LIMIT_32MB = 32 * 1024 * 1024;
const MAX_MSG_CHARS = 3500;
if (!import_fs.default.existsSync(TMP_DIR)) import_fs.default.mkdirSync(TMP_DIR, { recursive: true });
function ensureApiKey() {
  if (!apikeyvirustotal || apikeyvirustotal === "ISI_APIKEY_VIRUSTOTAL_KAMU_DI_SINI") {
    throw new Error("API key VirusTotal belum diisi. Isi dulu di variabel: apikeyvirustotal");
  }
}
function normalizeUrl(input) {
  if (!input) return "";
  let u = String(input).trim().replace(/^<+|>+$/g, "");
  if (/^https?:\/\//i.test(u)) return u;
  if (/^\/\//.test(u)) return "https:" + u;
  return "https://" + u;
}
function isValidUrl(input) {
  try {
    const u = new URL(input);
    return ["http:", "https:"].includes(u.protocol) && !!u.hostname;
  } catch {
    return false;
  }
}
function splitText(text, maxLen = MAX_MSG_CHARS) {
  const parts = [];
  let cur = "";
  for (const line of text.split("\n")) {
    if (cur.length + line.length + 1 > maxLen) {
      parts.push(cur);
      cur = line;
    } else {
      cur += (cur ? "\n" : "") + line;
    }
  }
  if (cur) parts.push(cur);
  return parts;
}
function formatSize(bytes) {
  const b = Number(bytes || 0);
  if (!b || b <= 0) return "0 B";
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(2)} KB`;
  return `${(b / (1024 * 1024)).toFixed(2)} MB`;
}
function toBuffer(data) {
  if (!data) return null;
  if (Buffer.isBuffer(data)) return data;
  if (typeof data === "string" && import_fs.default.existsSync(data)) {
    try {
      return import_fs.default.readFileSync(data);
    } catch {
      return null;
    }
  }
  if (typeof data === "object" && data.data) {
    try {
      return Buffer.isBuffer(data.data) ? data.data : Buffer.from(data.data);
    } catch {
      return null;
    }
  }
  if (data instanceof Uint8Array) return Buffer.from(data);
  if (data instanceof ArrayBuffer) return Buffer.from(new Uint8Array(data));
  try {
    return Buffer.from(data);
  } catch {
    return null;
  }
}
function guessExtFromMime(mime = "") {
  const m = String(mime).toLowerCase();
  if (m.includes("pdf")) return "pdf";
  if (m.includes("zip")) return "zip";
  if (m.includes("rar")) return "rar";
  if (m.includes("7z")) return "7z";
  if (m.includes("msword")) return "doc";
  if (m.includes("officedocument.wordprocessingml")) return "docx";
  if (m.includes("officedocument.spreadsheetml")) return "xlsx";
  if (m.includes("officedocument.presentationml")) return "pptx";
  if (m.includes("image/jpeg")) return "jpg";
  if (m.includes("image/png")) return "png";
  if (m.includes("video/mp4")) return "mp4";
  if (m.includes("audio/mpeg")) return "mp3";
  const p = m.split("/")[1];
  if (p && p.length <= 8) return p;
  return "bin";
}
function formatStats(stats = {}) {
  return `\u2705 Harmless/Clean : *${stats.harmless ?? 0}*
\u274C Malicious      : *${stats.malicious ?? 0}*
\u26A0\uFE0F Suspicious     : *${stats.suspicious ?? 0}*
\u{1F575}\uFE0F Undetected     : *${stats.undetected ?? 0}*
\u23F3 Timeout        : *${stats.timeout ?? 0}*`;
}
function formatVendors(resultsObj = {}, limit = 20) {
  const entries = Object.entries(resultsObj);
  if (!entries.length) return "_Tidak ada detail vendor yang ditampilkan._";
  const slice = limit === Infinity ? entries : entries.slice(0, limit);
  return slice.map(([engine, v]) => `\u2022 ${engine}: *${v?.category || "unknown"}*${v?.result ? ` \u2192 ${v.result}` : ""}`).join("\n");
}
function vtGuiUrlLink(url) {
  const id = Buffer.from(url).toString("base64").replace(/=+$/g, "");
  return `https://www.virustotal.com/gui/url/${id}/detection`;
}
function vtGuiFileLink(sha256) {
  return `https://www.virustotal.com/gui/file/${sha256}/detection`;
}
async function vtFetch(url, options = {}) {
  ensureApiKey();
  const headers = {
    accept: "application/json",
    "x-apikey": apikeyvirustotal,
    ...options.headers || {}
  };
  const res = await (0, import_node_fetch.default)(url, { ...options, headers });
  const text = await res.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }
  if (!res.ok) {
    const msg = json?.error?.message || json?.error?.code || json?.message || `HTTP ${res.status} ${res.statusText}`;
    throw new Error(msg);
  }
  return json;
}
async function pollAnalysis(analysisId) {
  for (let i = 0; i < MAX_POLL; i++) {
    await new Promise((r) => setTimeout(r, POLL_DELAY));
    const result = await vtFetch(`https://www.virustotal.com/api/v3/analyses/${analysisId}`, { method: "GET" });
    if (result?.data?.attributes?.status === "completed") return result;
  }
  throw new Error("Analisis terlalu lama / belum selesai. Coba lagi beberapa saat.");
}
async function getLargeUploadUrlV3() {
  const json = await vtFetch("https://www.virustotal.com/api/v3/files/upload_url", { method: "GET" });
  const uploadUrl = typeof json?.data === "string" && json.data || json?.data?.upload_url || json?.data?.attributes?.upload_url || json?.upload_url;
  if (!uploadUrl) throw new Error("Gagal mendapatkan upload_url untuk file besar.");
  return uploadUrl;
}
async function uploadFileToVT(filePath) {
  const sizeBytes = import_fs.default.statSync(filePath).size;
  let endpoint = "https://www.virustotal.com/api/v3/files";
  let mode = "normal";
  if (sizeBytes > LIMIT_32MB) {
    mode = "large";
    endpoint = await getLargeUploadUrlV3();
  }
  const form = new import_form_data.default();
  form.append("file", import_fs.default.createReadStream(filePath));
  const res = await (0, import_node_fetch.default)(endpoint, {
    method: "POST",
    headers: {
      ...form.getHeaders(),
      accept: "application/json",
      "x-apikey": apikeyvirustotal
    },
    body: form
  });
  const text = await res.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text };
  }
  if (!res.ok) {
    const msg = json?.error?.message || json?.error?.code || json?.message || `HTTP ${res.status} ${res.statusText}`;
    if (mode === "large") {
      throw new Error(
        `Upload >32MB butuh akses khusus VirusTotal.
Solusi: kecilkan file / zip ulang / kirim file <32MB.
Detail: ${msg}`
      );
    }
    throw new Error(msg);
  }
  const analysisId = json?.data?.id;
  if (!analysisId) throw new Error("Upload berhasil tapi analysis ID tidak ditemukan.");
  return { analysisId, mode };
}
const handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  const reply = (text) => jagoanproject.reply(m.chat, text, m);
  try {
    ensureApiKey();
    const wantAll = (args || []).some((x) => String(x).toLowerCase() === "all");
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || "";
    const canDownload = !!q.download;
    if (mime && canDownload) {
      const raw = await q.download();
      const buffer = toBuffer(raw);
      if (!buffer || buffer.length === 0) {
        throw new Error("Gagal mengunduh file dari reply. Coba kirim ulang file lalu reply lagi.");
      }
      const ext = guessExtFromMime(mime);
      const originalName = (q?.msg?.fileName || q?.fileName || "").toString().trim();
      const safeName = (originalName || `file-${Date.now()}.${ext}`).replace(/[^\w.\-]/g, "_");
      const tmpPath = import_path.default.join(TMP_DIR, `vt-${Date.now()}-${safeName}`);
      import_fs.default.writeFileSync(tmpPath, buffer);
      const sizeBytes = import_fs.default.statSync(tmpPath).size;
      const sizeText = formatSize(sizeBytes);
      await reply(
        `\u{1F9EA} *Virus Check Mode: FILE*
\u{1F4CE} MIME: *${mime}*
\u{1F5C2}\uFE0F Nama: *${safeName}*
\u{1F4CF} Ukuran: *${sizeText}*

\u{1F680} Upload ke VirusTotal...`
      );
      const { analysisId, mode } = await uploadFileToVT(tmpPath);
      await reply(
        `\u2705 Upload sukses (${mode}).
\u{1F194} Analysis ID: *${analysisId}*
\u{1F50E} Menunggu hasil scan...`
      );
      const result = await pollAnalysis(analysisId);
      const attrs = result?.data?.attributes || {};
      const stats = attrs.stats || {};
      const vendors = attrs.results || {};
      const sha256 = result?.meta?.file_info?.sha256 || result?.data?.attributes?.sha256 || result?.data?.meta?.file_info?.sha256 || null;
      const guiLink = sha256 ? vtGuiFileLink(sha256) : null;
      const malicious = stats.malicious ?? 0;
      const suspicious = stats.suspicious ?? 0;
      const verdict = malicious > 0 || suspicious > 0 ? `\u26A0\uFE0F *Indikasi berbahaya terdeteksi.*` : `\u2705 *Tidak ada deteksi malware dari engine yang memindai.*`;
      try {
        import_fs.default.unlinkSync(tmpPath);
      } catch {
      }
      const limit = wantAll ? Infinity : 20;
      const text = `\u{1F9A0} *HASIL SCAN FILE*

\u{1F5C2}\uFE0F Nama: *${safeName}*
\u{1F4CE} MIME: *${mime}*
\u{1F4CF} Ukuran: *${sizeText}*

${verdict}

${formatStats(stats)}

\u{1F9FE} *Vendor (${wantAll ? "FULL" : "maks 20"}):*
` + formatVendors(vendors, limit) + (guiLink ? `

\u{1F50D} Detail GUI:
${guiLink}` : `

\u2139\uFE0F Detail GUI: _SHA256 tidak ditemukan di response._`);
      const parts = splitText(text);
      for (let i = 0; i < parts.length; i++) {
        await reply(parts.length > 1 ? `${parts[i]}

(${i + 1}/${parts.length})` : parts[i]);
      }
      return;
    }
    if (args && args.length) {
      const filtered = args.filter((x) => String(x).toLowerCase() !== "all");
      const rawUrl = filtered.join(" ").trim();
      const normalized = normalizeUrl(rawUrl);
      if (!isValidUrl(normalized)) {
        return reply(
          `\u2757 URL tidak valid.

\u2705 Contoh:
\u2022 ${usedPrefix + command} Jagoanproject.web.id/Panel
\u2022 ${usedPrefix + command} https://example.com

\u{1F50E} FULL vendor:
\u2022 ${usedPrefix + command} Jagoanproject.web.id/Panel all`
        );
      }
      await reply(`\u{1F310} *Virus Check Mode: URL*
\u{1F517} Target: ${normalized}
\u{1F680} Submit ke VirusTotal...`);
      const submit = await vtFetch("https://www.virustotal.com/api/v3/urls", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `url=${encodeURIComponent(normalized)}`
      });
      const analysisId = submit?.data?.id;
      if (!analysisId) throw new Error("Gagal submit URL (analysis ID tidak ada).");
      await reply(`\u2705 URL disubmit.
\u{1F194} Analysis ID: *${analysisId}*
\u{1F50E} Menunggu hasil scan...`);
      const result = await pollAnalysis(analysisId);
      const attrs = result?.data?.attributes || {};
      const stats = attrs.stats || {};
      const vendors = attrs.results || {};
      const malicious = stats.malicious ?? 0;
      const suspicious = stats.suspicious ?? 0;
      const verdict = malicious > 0 || suspicious > 0 ? `\u26A0\uFE0F *Indikasi berbahaya terdeteksi.*` : `\u2705 *Tidak ada deteksi malware dari engine yang memindai.*`;
      const limit = wantAll ? Infinity : 20;
      const text = `\u{1F9A0} *HASIL SCAN URL*

\u{1F517} ${normalized}

${verdict}

${formatStats(stats)}

\u{1F9FE} *Vendor (${wantAll ? "FULL" : "maks 20"}):*
` + formatVendors(vendors, limit) + `

\u{1F50D} Detail GUI:
${vtGuiUrlLink(normalized)}`;
      const parts = splitText(text);
      for (let i = 0; i < parts.length; i++) {
        await reply(parts.length > 1 ? `${parts[i]}

(${i + 1}/${parts.length})` : parts[i]);
      }
      return;
    }
    return reply(
      `\u{1F4CC} *Cara pakai cekvirus:*

1) Scan URL:
\u2022 ${usedPrefix + command} Jagoanproject.web.id/Panel

2) Scan URL + FULL vendor:
\u2022 ${usedPrefix + command} Jagoanproject.web.id/Panel all

3) Scan File:
\u2022 Reply dokumen/foto/video/audio lalu ketik: ${usedPrefix + command}

\u{1F4A1} Tips: kalau URL tanpa http/https, bot otomatis tambah *https://*`
    );
  } catch (e) {
    console.error("\u274C Error cekvirus:", e);
    return jagoanproject.reply(m.chat, `\u2757 *Gagal cek virus*
\u{1F9E9} Alasan: ${e?.message || String(e)}`, m);
  }
};
handler.help = ["cekvirus <url / reply file>"];
handler.tags = ["tools"];
handler.command = /^cekvirus$/i;
handler.limit = true;
handler.premium = true;
handler.register = true;
var tools_cekvirus_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
