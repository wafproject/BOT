/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - compressimg.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_compressimg_exports = {};
__export(tools_compressimg_exports, {
  default: () => tools_compressimg_default
});
module.exports = __toCommonJS(tools_compressimg_exports);
var import_node_fetch = __toESM(require("node-fetch"));
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
let sharp;
try {
  sharp = require2("sharp");
} catch (e) {
  console.warn("Sharp tidak terinstall. Install: npm install sharp");
}
let handler = async (m, { jagoanproject, args, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || q.mediaType || "";
  let isImage = /image\//.test(mime);
  if (!isImage || !mime) {
    return m.reply(
      `\u274C Reply gambar valid (PNG/JPG/WebP)! MIME sekarang: ${mime || "kosong"}`
    );
  }
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  try {
    let buffer = await q.download();
    if (!buffer || buffer.length === 0) throw "Gagal unduh gambar!";
    console.log("[DEBUG] Ukuran asli:", buffer.length, "bytes");
    console.log("[DEBUG] MIME asli:", mime);
    let originalSize = buffer.length;
    let contentType = "image/png";
    if (sharp) {
      try {
        console.log("[DEBUG] Convert ke PNG...");
        buffer = await sharp(buffer).png({ quality: 100 }).toBuffer();
        console.log("[DEBUG] Convert sukses. Ukuran PNG:", buffer.length, "bytes");
      } catch (convErr) {
        console.error("[DEBUG] Sharp gagal:", convErr.message);
        contentType = mime;
      }
    } else {
      contentType = mime;
    }
    const TINIFY_KEY = global.tinypngkey || "KCCfFhCkwdrbtnjHdGVTw6Grf6yrpczC";
    if (!TINIFY_KEY) throw "API Key belum diset!";
    console.log("[DEBUG] Kirim raw binary dengan Content-Type:", contentType);
    let response = await (0, import_node_fetch.default)("https://api.tinify.com/shrink", {
      method: "POST",
      headers: {
        "Authorization": "Basic " + Buffer.from("api:" + TINIFY_KEY).toString("base64"),
        "Content-Type": contentType
        // penting: image/png atau sesuai format
      },
      body: buffer
      // langsung buffer sebagai body
    });
    if (!response.ok) {
      let errText = await response.text();
      throw `TinyPNG error: ${response.status} - ${errText}`;
    }
    let json = await response.json();
    console.log("[DEBUG] Response TinyPNG:", JSON.stringify(json, null, 2));
    let compressedUrl = json.output?.url;
    if (!compressedUrl) throw "Tidak dapat URL hasil kompres!";
    let newSize = json.output?.size || "Tidak diketahui";
    await jagoanproject.sendMessage(m.chat, {
      image: { url: compressedUrl },
      caption: `\u{1F39E} *Hasil Kompres TinyPNG*

Asli : ${(originalSize / 1024).toFixed(2)} KB
Baru : ${(newSize / 1024).toFixed(2)} KB
Hemat: ${((originalSize - newSize) / originalSize * 100).toFixed(1)}%
Link Download : ${compressedUrl}`
    }, { quoted: m });
  } catch (e) {
    console.error("[TinyImg Error]:", e);
    let errMsg = e.message || e || "Error tidak diketahui.";
    if (errMsg.includes("415")) {
      errMsg += "\nFormat mungkin masih tidak cocok. Coba tanpa sharp (hapus convert) atau test gambar lain.";
    } else if (errMsg.includes("401")) {
      errMsg += "\nKey invalid. Cek https://tinypng.com/developers";
    }
    await jagoanproject.sendMessage(m.chat, { ...global.eror, text: `${global.eror.text}

Detail: ${errMsg}` }, { quoted: m });
  }
};
handler.help = ["compress", "tinypng"].map((v) => v + " <reply gambar>");
handler.tags = ["tools"];
handler.command = /^(tinyimg|tinypng|compress|compressimg)$/i;
handler.limit = 2;
handler.register = true;
var tools_compressimg_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
