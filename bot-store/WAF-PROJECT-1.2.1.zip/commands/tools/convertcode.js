/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - convertcode.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_convertcode_exports = {};
__export(tools_convertcode_exports, {
  default: () => tools_convertcode_default
});
module.exports = __toCommonJS(tools_convertcode_exports);
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
let handler = async (m, { jagoanproject, args, text, usedPrefix, command }) => {
  let codeToConvert = text || m.quoted && m.quoted.text;
  if (!codeToConvert) throw `Masukkan atau reply kode yang ingin diubah`;
  let result;
  if (command === "toesm") {
    result = convertCJSToESM(codeToConvert);
  } else if (command === "tocjs") {
    result = convertESMToCJS(codeToConvert);
  } else {
    throw `Perintah tidak dikenal`;
  }
  m.reply(result);
};
handler.help = ["toesm <kode>", "tocjs <kode>"];
handler.tags = ["tools"];
handler.command = /^(toesm|tocjs)$/i;
handler.limit = true;
handler.register = true;
var tools_convertcode_default = handler;
function convertCJSToESM(code) {
  return code.replace(/const (\w+) = require\(['"](.+?)['"]\);?/g, "import $1 from '$2';").replace(/let (\w+) = require\(['"](.+?)['"]\);?/g, "import $1 from '$2';").replace(/var (\w+) = require\(['"](.+?)['"]\);?/g, "import $1 from '$2';").replace(/module\.exports\s*=\s*(.*?);?/g, "export default $1;").replace(/exports\.(\w+)\s*=\s*(.*?);?/g, "export const $1 = $2;").replace(/require\(['"](.+?)['"]\)/g, "await import('$1')");
}
function convertESMToCJS(code) {
  return code.replace(/import (\w+) from ['"](.+?)['"];/g, "const $1 = require('$2');").replace(/import \* as (\w+) from ['"](.+?)['"];/g, "const $1 = require('$2');").replace(/import \{(.*?)\} from ['"](.+?)['"];/g, (match, p1, p2) => {
    const imports = p1.split(",").map((i) => i.trim());
    return `const { ${imports.join(", ")} } = require('${p2}');`;
  }).replace(/export default (\w+);?/g, "export default $1;").replace(/export const (\w+) = (\w+);?/g, "exports.$1 = $2;").replace(/export (.*?) from ['"](.+?)['"];/g, (match, p1, p2) => {
    return `module.exports.${p1} = require('${p2}');`;
  });
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
