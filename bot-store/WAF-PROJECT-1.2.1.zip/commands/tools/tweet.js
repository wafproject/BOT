/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - tweet.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_tweet_exports = {};
__export(tools_tweet_exports, {
  default: () => tools_tweet_default
});
module.exports = __toCommonJS(tools_tweet_exports);
let handler = async (m, { jagoanproject, text }) => {
  if (!text) throw `*\u2022 Example:* .tweet *your message*`;
  try {
    const avatar = await jagoanproject.profilePictureUrl(m.sender, "image").catch((_) => "https://telegra.ph/file/24fa902ead26340f3df2c.png");
    const displayName = m.pushName;
    const username = m.pushName.replace(/ /g, "_");
    const replies = "176k";
    const retweets = "672k";
    const theme = "dark";
    const url = `https://some-random-api.com/canvas/misc/tweet?displayname=${encodeURIComponent(displayName)}&username=${encodeURIComponent(username)}&avatar=${encodeURIComponent(avatar)}&comment=${encodeURIComponent(text)}&replies=${encodeURIComponent(replies)}&retweets=${encodeURIComponent(retweets)}&theme=${encodeURIComponent(theme)}`;
    await jagoanproject.sendMessage(m.chat, {
      image: { url },
      caption: "Success! Here is your fake tweet image."
    }, { quoted: m });
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.");
  }
};
handler.help = ["tweet *your message*"];
handler.tags = ["fun"];
handler.command = /^(tweet|faketweet)$/i;
handler.register = true;
handler.limit = true;
var tools_tweet_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
