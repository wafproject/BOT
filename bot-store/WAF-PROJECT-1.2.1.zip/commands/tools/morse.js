/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - morse.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_morse_exports = {};
__export(tools_morse_exports, {
  default: () => tools_morse_default
});
module.exports = __toCommonJS(tools_morse_exports);
let handler = (m, { text, usedPrefix, command }) => {
  let teks = text || m.quoted && m.quoted.text || false;
  if (!teks) throw "_Masukkan teks!_\n\nContoh\n" + usedPrefix + command + " " + global.author;
  const morseDict = {
    "a": "\u2022\u2013",
    "b": "\u2013\u2022\u2022\u2022",
    "c": "\u2013\u2022\u2013\u2022",
    "d": "\u2013\u2022\u2022",
    "e": "\u2022",
    "f": "\u2022\u2022\u2013\u2022",
    "g": "\u2013\u2013\u2022",
    "h": "\u2022\u2022\u2022\u2022",
    "i": "\u2022\u2022",
    "j": "\u2022\u2013\u2013\u2013",
    "k": "\u2013\u2022\u2013",
    "l": "\u2022\u2013\u2022\u2022",
    "m": "\u2013\u2013",
    "n": "\u2013\u2022",
    "o": "\u2013\u2013\u2013",
    "p": "\u2022\u2013\u2013\u2022",
    "q": "\u2013\u2013\u2022\u2013",
    "r": "\u2022\u2013\u2022",
    "s": "\u2022\u2022\u2022",
    "t": "\u2013",
    "u": "\u2022\u2022\u2013",
    "v": "\u2022\u2022\u2022\u2013",
    "w": "\u2022\u2013\u2013",
    "x": "\u2013\u2022\u2022\u2013",
    "y": "\u2013\u2022\u2013\u2013",
    "z": "\u2013\u2013\u2022\u2022",
    "1": "\u2022\u2013\u2013\u2013\u2013",
    "2": "\u2022\u2022\u2013\u2013\u2013",
    "3": "\u2022\u2022\u2022\u2013\u2013",
    "4": "\u2022\u2022\u2022\u2022\u2013",
    "5": "\u2022\u2022\u2022\u2022\u2022",
    "6": "\u2013\u2022\u2022\u2022\u2022",
    "7": "\u2013\u2013\u2022\u2022\u2022",
    "8": "\u2013\u2013\u2013\u2022\u2022",
    "9": "\u2013\u2013\u2013\u2013\u2022",
    "0": "\u2013\u2013\u2013\u2013\u2013",
    " ": "/"
  };
  let morse = teks.toLowerCase().split("").map((char) => {
    return morseDict[char] || char;
  }).join(" ");
  m.reply(`Kode morse:

${morse}`);
};
handler.tags = ["fun", "tools"];
handler.command = ["morse"];
handler.help = ["morse"];
handler.register = true;
handler.limit = true;
var tools_morse_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
