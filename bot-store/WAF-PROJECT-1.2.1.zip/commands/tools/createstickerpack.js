/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - createstickerpack.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_createstickerpack_exports = {};
__export(tools_createstickerpack_exports, {
  default: () => tools_createstickerpack_default
});
module.exports = __toCommonJS(tools_createstickerpack_exports);
var import_botcahx = require("../../lib/botcahx.js");
var import_node_crypto = __toESM(require("node:crypto"));
var import_node_https = __toESM(require("node:https"));
var import_sharp = __toESM(require("sharp"));
var import_axios = __toESM(require("axios"));
var import_uploadImage = __toESM(require("../../lib/jagoan/lib/uploadImage.js"));
const MAX_STICKERS = 30;
const STORE_KEY = "createStickerPack";
async function removeBackgroundBuffer(buffer, options = {}) {
  // hapus background lewat BOTCAHX (dulu API Jagoan)
  const media = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer || []);
  if (!media.length) throw new Error("Buffer gambar removebg kosong.");
  if (media.length > 5 * 1024 * 1024) {
    throw new Error("Ukuran gambar removebg tidak boleh melebihi 5MB.");
  }
  const uploadedUrl = await (0, import_uploadImage.default)(media, {
    mustBeDirectImage: true,
    originalName: options.originalName || "cspack-image"
  });
  if (!uploadedUrl) throw new Error("Gagal mengunggah gambar untuk removebg.");
  const out = await import_botcahx.getMedia("/api/tools/removebg", { url: uploadedUrl });
  if (!out?.buf?.length) throw new Error("Hasil removebg kosong.");
  return { buffer: out.buf };
}
function cleanText(value, fallback) {
  const text = String(value || "").split(/\r?\n/).map((v) => v.trim()).find(Boolean);
  return text || fallback;
}
function toBuffer(value) {
  if (Buffer.isBuffer(value)) return value;
  if (value && value.type === "Buffer" && Array.isArray(value.data)) return Buffer.from(value.data);
  if (typeof value === "string") return Buffer.from(value, "base64");
  throw new Error("Format buffer sticker tidak dikenali.");
}
function toStoredBuffer(buffer) {
  return Buffer.from(buffer).toString("base64");
}
function sha256(buffer) {
  return import_node_crypto.default.createHash("sha256").update(buffer).digest();
}
function toB64Url(buffer) {
  return Buffer.from(buffer).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function isWebP(buffer) {
  return buffer.length >= 12 && buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP";
}
function isAnimatedWebP(buffer) {
  if (!isWebP(buffer)) return false;
  let offset = 12;
  while (offset <= buffer.length - 8) {
    const chunk = buffer.toString("ascii", offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    if (chunk === "VP8X" && offset + 8 < buffer.length && buffer[offset + 8] & 2) return true;
    if (chunk === "ANIM" || chunk === "ANMF") return true;
    offset += 8 + size + size % 2;
  }
  return false;
}
function unwrapMessage(message = {}) {
  let current = message;
  for (let i = 0; i < 8; i += 1) {
    if (!current || typeof current !== "object") return {};
    if (current.imageMessage || current.stickerMessage) return current;
    const next = current.ephemeralMessage?.message || current.viewOnceMessage?.message || current.viewOnceMessageV2?.message || current.viewOnceMessageV2Extension?.message || current.documentWithCaptionMessage?.message || current.editedMessage?.message || current.associatedChildMessage?.message;
    if (!next) return current;
    current = next;
  }
  return current || {};
}
function quotedMediaInfo(m) {
  if (!m?.quoted) return null;
  const raw = unwrapMessage(m.quoted.fakeObj?.message || m.quoted.message || {});
  const imageMessage = raw.imageMessage || (m.quoted.mtype === "imageMessage" ? m.quoted.msg : null);
  const stickerMessage = raw.stickerMessage || (m.quoted.mtype === "stickerMessage" ? m.quoted.msg : null);
  const mimetype = String(
    imageMessage?.mimetype || stickerMessage?.mimetype || m.quoted.mimetype || m.quoted.msg?.mimetype || ""
  ).toLowerCase();
  if (imageMessage || mimetype.startsWith("image/")) {
    return { kind: "image", imageMessage, sourceId: m.quoted.id || m.quoted.key?.id || "" };
  }
  if (stickerMessage || mimetype === "image/webp" || m.quoted.mtype === "stickerMessage") {
    return { kind: "sticker", stickerMessage: stickerMessage || m.quoted.msg || {}, sourceId: m.quoted.id || m.quoted.key?.id || "" };
  }
  return null;
}
function getStickerStore(sender) {
  if (!global.db?.data) throw new Error("Database bot belum siap.");
  if (!global.db.data[STORE_KEY] || typeof global.db.data[STORE_KEY] !== "object") {
    global.db.data[STORE_KEY] = {};
  }
  if (!Array.isArray(global.db.data[STORE_KEY][sender])) {
    global.db.data[STORE_KEY][sender] = [];
  }
  const list = global.db.data[STORE_KEY][sender];
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const item = list[i];
    try {
      if (!item || !item.buffer) throw new Error("invalid");
      if (typeof item.buffer !== "string") item.buffer = toStoredBuffer(toBuffer(item.buffer));
      if (!item.hash) item.hash = sha256(toBuffer(item.buffer)).toString("hex");
    } catch {
      list.splice(i, 1);
    }
  }
  return list;
}
function classifySticker(buffer, stickerMessage = {}) {
  if (stickerMessage?.isLottie) {
    return { ext: "json", mimetype: "application/json", isAnimated: true, isLottie: true };
  }
  return {
    ext: "webp",
    mimetype: "image/webp",
    isAnimated: Boolean(stickerMessage?.isAnimated) || isAnimatedWebP(buffer),
    isLottie: false
  };
}
async function imageToStickerWebp(buffer) {
  return (0, import_sharp.default)(buffer, { failOn: "none" }).rotate().resize(512, 512, {
    fit: "contain",
    background: { r: 0, g: 0, b: 0, alpha: 0 }
  }).webp({ quality: 86, effort: 4 }).toBuffer();
}
async function prepareQuotedItem(m) {
  const info = quotedMediaInfo(m);
  if (!info) throw new Error("Reply gambar atau sticker yang ingin dimasukkan ke pack.");
  if (typeof m.quoted?.download !== "function") throw new Error("Media reply tidak dapat diunduh.");
  const downloaded = await m.quoted.download();
  if (!downloaded?.length) throw new Error("Gagal download media yang direply.");
  if (info.kind === "image") {
    const buffer = await imageToStickerWebp(downloaded);
    return {
      sourceId: info.sourceId,
      hash: sha256(buffer).toString("hex"),
      buffer: toStoredBuffer(buffer),
      ext: "webp",
      mimetype: "image/webp",
      isAnimated: false,
      isLottie: false
    };
  }
  const type = classifySticker(downloaded, info.stickerMessage);
  return {
    sourceId: info.sourceId,
    hash: sha256(downloaded).toString("hex"),
    buffer: toStoredBuffer(downloaded),
    ...type
  };
}
async function makeTrayWebp(buffer) {
  return (0, import_sharp.default)(buffer, { animated: false, failOn: "none" }).resize(252, 252, { fit: "cover" }).webp({ quality: 82 }).toBuffer();
}
async function makeBlankTrayWebp() {
  return (0, import_sharp.default)({
    create: {
      width: 252,
      height: 252,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 }
    }
  }).webp().toBuffer();
}
async function makeThumbnailJpeg(buffer) {
  return (0, import_sharp.default)(buffer, { failOn: "none" }).resize(252, 252, { fit: "cover" }).jpeg({ quality: 82 }).toBuffer();
}
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();
function crc32(buffer) {
  let crc = 4294967295;
  for (const byte of buffer) crc = CRC_TABLE[(crc ^ byte) & 255] ^ crc >>> 8;
  return (crc ^ 4294967295) >>> 0;
}
function dosDateTime(date = /* @__PURE__ */ new Date()) {
  const year = Math.max(1980, date.getFullYear());
  const dosTime = date.getHours() << 11 | date.getMinutes() << 5 | Math.floor(date.getSeconds() / 2);
  const dosDate = year - 1980 << 9 | date.getMonth() + 1 << 5 | date.getDate();
  return { dosTime, dosDate };
}
function makeStoredZip(files = []) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  const { dosTime, dosDate } = dosDateTime();
  for (const file of files) {
    const fileName = String(file?.fileName || "");
    const data = toBuffer(file?.buffer);
    if (!fileName) throw new Error("Nama file sticker pack kosong.");
    const name = Buffer.from(fileName, "utf8");
    const checksum = crc32(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(67324752, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(dosTime, 10);
    local.writeUInt16LE(dosDate, 12);
    local.writeUInt32LE(checksum, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    localParts.push(local, name, data);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(33639248, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(dosTime, 12);
    central.writeUInt16LE(dosDate, 14);
    central.writeUInt32LE(checksum, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centralParts.push(central, name);
    offset += local.length + name.length + data.length;
  }
  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(101010256, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...localParts, ...centralParts, end]);
}
async function uploadToServer(conn, buffer, { hkdf, mediaPath, mediaKey = import_node_crypto.default.randomBytes(32) }) {
  const expanded = Buffer.from(
    import_node_crypto.default.hkdfSync("sha256", mediaKey, Buffer.alloc(32), Buffer.from(hkdf), 112)
  );
  const iv = expanded.subarray(0, 16);
  const cipherKey = expanded.subarray(16, 48);
  const macKey = expanded.subarray(48, 80);
  const cipher = import_node_crypto.default.createCipheriv("aes-256-cbc", cipherKey, iv);
  const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
  const mac = import_node_crypto.default.createHmac("sha256", macKey).update(iv).update(encrypted).digest().subarray(0, 10);
  const encBuffer = Buffer.concat([encrypted, mac]);
  const fileSha256 = sha256(buffer);
  const fileEncSha256 = sha256(encBuffer);
  const iq = await conn.query({
    tag: "iq",
    attrs: {
      id: conn.generateMessageTag?.() ?? Date.now().toString(),
      to: "s.whatsapp.net",
      type: "set",
      xmlns: "w:m"
    },
    content: [{ tag: "media_conn", attrs: {} }]
  });
  const mediaConn = iq?.content?.find?.((v) => v?.tag === "media_conn");
  if (!mediaConn) throw new Error("media_conn tidak ditemukan dari WhatsApp.");
  const auth = mediaConn.attrs?.auth;
  if (!auth) throw new Error("auth media_conn tidak ditemukan.");
  const hosts = (mediaConn.content || []).filter((v) => v?.tag === "host").map((v) => v?.attrs?.hostname).filter(Boolean);
  if (!hosts.length) throw new Error("Host upload sticker pack tidak ditemukan.");
  const token = encodeURIComponent(toB64Url(fileEncSha256));
  let lastError;
  for (const host of hosts) {
    try {
      const json = await new Promise((resolve, reject) => {
        const url = new URL(`https://${host}${mediaPath}/${token}?auth=${encodeURIComponent(auth)}&token=${token}`);
        const req = import_node_https.default.request({
          hostname: url.hostname,
          port: 443,
          path: url.pathname + url.search,
          method: "POST",
          headers: {
            Origin: "https://web.whatsapp.com",
            Referer: "https://web.whatsapp.com/",
            "Content-Type": "application/octet-stream",
            "Content-Length": encBuffer.length
          }
        }, (res) => {
          let body = "";
          res.on("data", (chunk) => {
            body += chunk;
          });
          res.on("end", () => {
            if ((res.statusCode || 0) < 200 || (res.statusCode || 0) >= 300) {
              reject(new Error(`Upload gagal ${res.statusCode}: ${body}`));
              return;
            }
            try {
              resolve(JSON.parse(body));
            } catch {
              reject(new Error(`Response upload bukan JSON: ${body}`));
            }
          });
        });
        req.on("error", reject);
        req.write(encBuffer);
        req.end();
      });
      const directPath = json.direct_path ?? json.directPath ?? json.url ?? json.path;
      if (!directPath) throw new Error("directPath hasil upload tidak ditemukan.");
      return {
        mediaKey,
        fileLength: buffer.length,
        fileSha256,
        fileEncSha256,
        directPath,
        ...json
      };
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError ?? new Error("Semua host upload sticker pack gagal.");
}
async function sendCustomStickerPack(conn, m, pack, options = {}) {
  if (!Array.isArray(pack) || !pack.length) throw new Error("Pack masih kosong.");
  if (pack.length > MAX_STICKERS) throw new Error(`Maksimal ${MAX_STICKERS} sticker per pack.`);
  const hydrated = pack.map((item) => ({ ...item, buffer: toBuffer(item.buffer) }));
  const zipFiles = [];
  const stickersMetadata = [];
  for (const item of hydrated) {
    const fileName = `${toB64Url(sha256(item.buffer))}.${item.ext || "webp"}`;
    zipFiles.push({ fileName, buffer: item.buffer });
    stickersMetadata.push({
      fileName,
      isAnimated: Boolean(item.isAnimated),
      emojis: [""],
      accessibilityLabel: "",
      isLottie: Boolean(item.isLottie),
      mimetype: item.mimetype || "image/webp"
    });
  }
  const trayIconFileName = "tray_icon.webp";
  const traySource = hydrated.find((v) => !v.isLottie)?.buffer;
  const trayBuffer = traySource ? await makeTrayWebp(traySource) : await makeBlankTrayWebp();
  zipFiles.push({ fileName: trayIconFileName, buffer: trayBuffer });
  const archive = makeStoredZip(zipFiles);
  const packUpload = await uploadToServer(conn, archive, {
    hkdf: "WhatsApp Sticker Pack Keys",
    mediaPath: "/mms/sticker-pack"
  });
  const thumbnailBuffer = await makeThumbnailJpeg(trayBuffer);
  const thumbUpload = await uploadToServer(conn, thumbnailBuffer, {
    hkdf: "WhatsApp Sticker Pack Thumbnail Keys",
    mediaPath: "/mms/thumbnail-sticker-pack",
    mediaKey: packUpload.mediaKey
  });
  const defaultName = cleanText(global.packname || global.namebot, "Jagoan Project");
  const name = cleanText(options.packName, defaultName).slice(0, 128);
  const publisher = cleanText(global.nameowner || global.author, "Jagoan Project");
  await conn.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        messageSecret: import_node_crypto.default.randomBytes(32)
      },
      stickerPackMessage: {
        stickerPackId: `Pack_${import_node_crypto.default.randomBytes(8).toString("hex")}`,
        name,
        publisher,
        packDescription: `Sticker pack dibuat menggunakan ${global.namebot || "Jagoan Project"}`,
        stickers: stickersMetadata,
        fileLength: packUpload.fileLength,
        fileSha256: packUpload.fileSha256,
        fileEncSha256: packUpload.fileEncSha256,
        mediaKey: packUpload.mediaKey,
        directPath: packUpload.directPath,
        mediaKeyTimestamp: Math.floor(Date.now() / 1e3),
        stickerPackSize: packUpload.fileLength,
        stickerPackOrigin: 2,
        trayIconFileName,
        thumbnailDirectPath: thumbUpload.directPath,
        thumbnailSha256: thumbUpload.fileSha256,
        thumbnailEncSha256: thumbUpload.fileEncSha256,
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash: thumbUpload.fileSha256.toString("base64")
      }
    },
    { quoted: m }
  );
}
function usage(prefix = ".") {
  return [
    "*CREATE STICKER PACK*",
    "",
    "*Pilih gambar/sticker:*",
    `Reply media 1 \u2192 ${prefix}cspack`,
    `Reply media 2 \u2192 ${prefix}cspack`,
    `Reply media 3 \u2192 ${prefix}cspack`,
    "",
    "*Buat pack dari pilihan:*",
    `${prefix}cspack \u2192 apa adanya + nama default`,
    `${prefix}cspack Nama Pack \u2192 apa adanya + nama custom`,
    `${prefix}cspacknobg \u2192 remove background + nama default`,
    `${prefix}cspacknobg Nama Pack \u2192 remove background + nama custom`,
    "",
    `Cek pilihan: ${prefix}cspack status`,
    `Hapus media tertentu: reply media \u2192 ${prefix}cspack del`,
    `Kosongkan semua: ${prefix}cspack clear`,
    "",
    `Maksimal ${MAX_STICKERS} item per pack.`
  ].join("\n");
}
async function addToPack(m, pack) {
  if (pack.length >= MAX_STICKERS) throw new Error(`Pack sudah mencapai batas ${MAX_STICKERS} sticker.`);
  const item = await prepareQuotedItem(m);
  if (pack.some((v) => item.sourceId && v.sourceId === item.sourceId || v.hash === item.hash)) {
    return { duplicate: true, count: pack.length };
  }
  pack.push(item);
  return { duplicate: false, count: pack.length };
}
async function deleteFromPack(m, pack) {
  const info = quotedMediaInfo(m);
  if (!info) throw new Error("Reply gambar/sticker yang ingin dihapus dari pilihan.");
  let index = info.sourceId ? pack.findIndex((v) => v.sourceId === info.sourceId) : -1;
  if (index < 0) {
    const item = await prepareQuotedItem(m);
    index = pack.findIndex((v) => v.hash === item.hash);
  }
  if (index < 0) return false;
  pack.splice(index, 1);
  return true;
}
async function removeBackgroundFromPack(pack, onProgress) {
  const output = [];
  for (let index = 0; index < pack.length; index += 1) {
    const item = pack[index];
    if (item?.isLottie || item?.isAnimated) {
      throw new Error(
        `Item ${index + 1} berupa sticker animated/Lottie. Mode cspacknobg hanya mendukung gambar atau sticker statis.`
      );
    }
    if (typeof onProgress === "function") await onProgress(index + 1, pack.length);
    const source = toBuffer(item.buffer);
    let removed;
    try {
      removed = await removeBackgroundBuffer(source, {
        originalName: `cspack-${index + 1}.webp`
      });
    } catch (error) {
      throw new Error(`Remove background item ${index + 1}/${pack.length} gagal: ${error?.message || error}`);
    }
    const webp = await imageToStickerWebp(removed.buffer);
    output.push({
      ...item,
      hash: sha256(webp).toString("hex"),
      buffer: toStoredBuffer(webp),
      ext: "webp",
      mimetype: "image/webp",
      isAnimated: false,
      isLottie: false
    });
  }
  return output;
}
function parseFinalPackName(text = "", action = "") {
  const raw = String(text || "").trim();
  if (!raw) return "";
  if (["done", "create", "buat", "selesai"].includes(action)) {
    return raw.split(/\s+/).slice(1).join(" ").trim();
  }
  return raw;
}
const handler = async (m, { conn, jagoanproject, text = "", usedPrefix = ".", command = "" }) => {
  const client = conn || jagoanproject;
  if (!client) throw new Error("Koneksi WhatsApp tidak tersedia.");
  try {
    const pack = getStickerStore(m.sender);
    const rawText = String(text || "").trim();
    const action = rawText.split(/\s+/)[0]?.toLowerCase() || "";
    const quoted = quotedMediaInfo(m);
    const commandName = String(command || "").toLowerCase();
    const removeBgMode = commandName === "cspacknobg";
    if (["help", "cara", "?"].includes(action)) return m.reply(usage(usedPrefix));
    if (!removeBgMode && ["status", "list", "cek"].includes(action)) {
      return m.reply(`\u{1F9E9} Media terpilih: ${pack.length}/${MAX_STICKERS}

${usage(usedPrefix)}`);
    }
    if (!removeBgMode && ["clear", "reset", "batal"].includes(action)) {
      const count2 = pack.length;
      pack.splice(0, pack.length);
      return m.reply(count2 ? `\u2705 ${count2} pilihan dihapus.` : "\u2139\uFE0F Pack memang masih kosong.");
    }
    if (!removeBgMode && ["del", "delete", "hapus", "remove"].includes(action)) {
      if (!quoted) throw new Error("Reply gambar/sticker yang ingin dihapus dari pilihan.");
      const removed = await deleteFromPack(m, pack);
      return m.reply(removed ? `\u2705 Dihapus. Sisa ${pack.length} sticker.` : "\u2139\uFE0F Media itu tidak ada di pack.");
    }
    if (!removeBgMode && quoted && (!action || ["add", "pilih", "select", "+"].includes(action))) {
      await client.sendMessage?.(m.chat, { react: { text: "\u2795", key: m.key } }).catch(() => {
      });
      const result = await addToPack(m, pack);
      await client.sendMessage?.(m.chat, { react: { text: "\u2705", key: m.key } }).catch(() => {
      });
      return m.reply(
        result.duplicate ? `\u2139\uFE0F Media itu sudah dipilih. Total ${result.count}/${MAX_STICKERS}.` : `\u2705 Ditambahkan. Total ${result.count}/${MAX_STICKERS}.
Reply gambar/sticker lain lalu ${usedPrefix}cspack lagi. Jika selesai, kirim ${usedPrefix}cspack tanpa reply.`
      );
    }
    if (quoted && removeBgMode) {
      return m.reply(
        `\u2139\uFE0F ${usedPrefix}cspacknobg dipakai untuk membuat pack dari media yang sudah tersimpan.
Tambahkan media dulu dengan reply \u2192 ${usedPrefix}cspack, lalu kirim ${usedPrefix}cspacknobg tanpa reply.`
      );
    }
    if (!pack.length) return m.reply(`Pack masih kosong.

${usage(usedPrefix)}`);
    const explicitDone = ["done", "create", "buat", "selesai"].includes(action);
    const packName = removeBgMode ? rawText : parseFinalPackName(rawText, explicitDone ? action : "");
    await client.sendMessage?.(m.chat, { react: { text: removeBgMode ? "\u{1FA84}" : "\u{1F9E9}", key: m.key } }).catch(() => {
    });
    let finalPack = pack;
    if (removeBgMode) {
      await m.reply(
        `\u{1FA84} Menghapus background ${pack.length} gambar via removebg botcahx.
Mohon tunggu sampai seluruh gambar selesai diproses...`
      );
      finalPack = await removeBackgroundFromPack(pack);
    }
    await sendCustomStickerPack(client, m, finalPack, { packName });
    const count = pack.length;
    const finalName = cleanText(packName, cleanText(global.packname || global.namebot, "Jagoan Project")).slice(0, 128);
    pack.splice(0, pack.length);
    await client.sendMessage?.(m.chat, { react: { text: "\u2705", key: m.key } }).catch(() => {
    });
    return m.reply(
      `\u2705 Sticker pack berhasil dibuat dari ${count} sticker.
\u{1F4E6} Nama pack: ${finalName}
\u{1FA84} Remove background: ${removeBgMode ? "Ya" : "Tidak"}`
    );
  } catch (error) {
    console.error("[CREATE STICKER PACK]", error);
    await client.sendMessage?.(m.chat, { react: { text: "\u274C", key: m.key } }).catch(() => {
    });
    return m.reply(`\u274C Gagal membuat sticker pack.
${error?.message || error}`);
  }
};
handler.help = ["createstickerpack"];
handler.tags = ["tools"];
handler.command = /^(?:cspack|createstickerpack|cspacknobg)$/i;
handler.register = true;
handler.limit = true;
var tools_createstickerpack_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
