/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - element.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_element_exports = {};
__export(tools_element_exports, {
  default: () => tools_element_default
});
module.exports = __toCommonJS(tools_element_exports);
var import_node_fetch = __toESM(require("node-fetch"));
let handler = async (m, { jagoanproject, text }) => {
  if (!text) throw `Harap simbol atau nama elemen
Contoh : .element carbon`;
  try {
    let res = await (0, import_node_fetch.default)(`https://api.popcat.xyz/periodic-table?element=${text}`);
    if (!res.ok) {
      throw new Error(`API request failed with status ${res.status}`);
    }
    let buffer = await res.arrayBuffer();
    let json = JSON.parse(Buffer.from(buffer).toString());
    console.log("JSON response:", json);
    let elementInfo = `*Element Information:*


\u2022 *Name:* ${json.name}


\u2022 *Symbol:* ${json.symbol}


\u2022 *Atomic Number:* ${json.atomic_number}


\u2022 *Atomic Mass:* ${json.atomic_mass}


\u2022 *Period:* ${json.period}


\u2022 *Phase:* ${json.phase}


\u2022 *Discovered By:* ${json.discovered_by}


\u2022 *Summary:* ${json.summary}`;
    jagoanproject.sendFile(m.chat, json.image, "element.jpg", elementInfo, m);
  } catch (error) {
    console.error(error);
  }
};
handler.help = ["element"];
handler.tags = ["tools"];
handler.command = /^(element|ele)$/i;
handler.register = true;
handler.limit = true;
var tools_element_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
