/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - cekdata.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_cekdata_exports = {};
__export(tools_cekdata_exports, {
  default: () => tools_cekdata_default
});
module.exports = __toCommonJS(tools_cekdata_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
async function checkDataBreach(email) {
  try {
    const url = "https://periksadata.com/";
    const formData = new URLSearchParams();
    formData.append("email", email);
    const response = await import_axios.default.post(url, formData, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
      }
    });
    const $ = cheerio.load(response.data);
    const info = $(".text-center.col-md-6.col-lg-5 > div > h2").text();
    if (info.includes("WAH SELAMAT!")) {
      return [];
    }
    const breaches = [];
    $("div.col-md-6").each((i, element) => {
      try {
        const title = $(element).find("div.feature__body > h5").text().trim();
        const boldElements = $(element).find("div.feature__body > p > b");
        if (boldElements.length >= 3) {
          const date = $(boldElements[0]).text().trim();
          const breachedData = $(boldElements[1]).text().trim();
          const totalBreach = $(boldElements[2]).text().trim();
          if (title) {
            breaches.push({
              title,
              date,
              breached_data: breachedData,
              total_breach: totalBreach
            });
          }
        }
      } catch (error) {
        console.error("Error parsing breach data:", error);
      }
    });
    return breaches;
  } catch (error) {
    console.error("Error checking data breach:", error.message);
    throw new Error("Gagal terhubung ke PeriksaData.com atau terjadi kesalahan.");
  }
}
const handler = async (m, { jagoanproject, text, command }) => {
  if (!text || !text.includes("@")) {
    return m.reply(`\u2757 Format salah! Masukkan email yang ingin diperiksa.

Contoh:
*.${command} email@contoh.com*`);
  }
  const email = text.trim();
  await m.reply(`\u{1F50D} Sedang memeriksa email *${email}* di database kebocoran data...`);
  try {
    const results = await checkDataBreach(email);
    if (results.length === 0) {
      let safeText = `\u2705 *DATA AMAN*

`;
      safeText += `\u{1F4E7} Email: *${email}*
`;
      safeText += `\u{1F4CC} Status: *Selamat!* Tidak ditemukan dalam kebocoran data.

`;
      safeText += `\u{1F4A1} Tetap waspada dan ganti password secara berkala!`;
      return m.reply(safeText);
    }
    let breachText = `\u26A0 *DATA BOCOR TERDETEKSI*

`;
    breachText += `\u{1F4E7} Email: *${email}*
`;
    breachText += `\u{1F4CA} Ditemukan dalam *${results.length}* kebocoran data:

`;
    results.forEach((item, index) => {
      breachText += `\u{1F4C2} Kebocoran #${index + 1}
`;
      breachText += `\u2022 \u{1F516} Sumber: *${item.title}*
`;
      breachText += `\u2022 \u{1F4C5} Tanggal: ${item.date}
`;
      breachText += `\u2022 \u{1F4D1} Data Bocor: ${item.breached_data}
`;
      breachText += `\u2022 \u{1F465} Total Terdampak: ${item.total_breach}

`;
    });
    breachText += `\u26A0 Segera ganti password pada akun-akun yang terdampak!`;
    m.reply(breachText);
  } catch (e) {
    console.error("PeriksaData Plugin Error:", e);
    m.reply(`\u274C Gagal memeriksa data.
${e.message}`);
  }
};
handler.help = ["cekdata <email>"];
handler.command = ["periksadata", "cekdata"];
handler.tags = ["tools"];
handler.description = "Mengecek apakah email pernah mengalami kebocoran data.";
handler.limit = 5;
handler.register = true;
var tools_cekdata_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
