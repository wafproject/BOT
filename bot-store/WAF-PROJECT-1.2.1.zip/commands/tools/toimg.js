/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - toimg.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_toimg_exports = {};
__export(tools_toimg_exports, {
  default: () => tools_toimg_default
});
module.exports = __toCommonJS(tools_toimg_exports);
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  if (!m.quoted) throw ` *${usedPrefix + command}*`;
  let mime = m.quoted.mimetype || "";
  if (!/webp/.test(mime)) throw `balas stiker dengan caption *${usedPrefix + command}*`;
  let media = await m.quoted.download();
  await jagoanproject.sendMessage(m.chat, { image: media, caption: "*DONE*" }, { quoted: m });
};
handler.help = ["toimg"];
handler.tags = ["tools"];
handler.command = ["toimg"];
handler.register = true;
handler.limit = true;
var tools_toimg_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
