/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - enc.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_enc_exports = {};
__export(tools_enc_exports, {
  default: () => tools_enc_default
});
module.exports = __toCommonJS(tools_enc_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_javascript_obfuscator = __toESM(require("javascript-obfuscator"));
let handler = async (m, { jagoanproject, args }) => {
  const q = m.quoted || m;
  const mime = q?.mimetype || "";
  const isJS = mime === "application/javascript" || /\.js$/i.test(q?.fileName || "");
  if (!isJS) {
    return m.reply("\u274C Balas atau kirim file `.js` untuk dienkripsi.\nContoh: kirim file lalu balas *.enc <watermark>*");
  }
  const watermark = (args.join(" ") || "EncryptedByFast").replace(/[^\w]/g, "").slice(0, 30);
  const fileName = q.fileName || "file.js";
  m.reply(`\u23F3 Downloading *${fileName}*...`);
  let buffer;
  try {
    buffer = await q.download();
  } catch {
    return m.reply("\u274C Gagal mengunduh file.");
  }
  m.reply(`\u26A1 Fast encrypt with watermark: *${watermark}*`);
  try {
    const result = import_javascript_obfuscator.default.obfuscate(buffer.toString(), {
      compact: true,
      controlFlowFlattening: false,
      deadCodeInjection: false,
      debugProtection: false,
      selfDefending: false,
      renameGlobals: false,
      stringArray: true,
      stringArrayThreshold: 0.7,
      stringArrayEncoding: ["base64"],
      splitStrings: true,
      splitStringsChunkLength: 8,
      identifierNamesGenerator: "hexadecimal",
      identifiersPrefix: watermark,
      disableConsoleOutput: true,
      transformObjectKeys: true
    });
    const outPath = import_path.default.join("../../tmp", `enc-fast-${Date.now()}-${fileName}`);
    import_fs.default.writeFileSync(outPath, result.getObfuscatedCode());
    await jagoanproject.sendMessage(m.chat, {
      document: import_fs.default.readFileSync(outPath),
      mimetype: "application/javascript",
      fileName,
      caption: `\u2705 *ENC berhasil*
\u{1F516} Watermark: *${watermark}*`
    }, { quoted: m });
    import_fs.default.unlinkSync(outPath);
  } catch (err) {
    console.error(err);
    m.reply(`\u274C Gagal enkripsi:
${err.message}`);
  }
};
handler.help = ["enc <watermark>"];
handler.tags = ["tools"];
handler.command = /^enc(rypt)?(hard)?$/i;
handler.premium = true;
handler.register = true;
handler.limit = true;
var tools_enc_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
