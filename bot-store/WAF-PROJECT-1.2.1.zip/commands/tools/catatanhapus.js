/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - catatanhapus.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_catatanhapus_exports = {};
__export(tools_catatanhapus_exports, {
  default: () => tools_catatanhapus_default
});
module.exports = __toCommonJS(tools_catatanhapus_exports);
let handler = async (m, { jagoanproject, command, usedPrefix, text }) => {
  global.db.data.users[m.sender].catatan = global.db.data.users[m.sender].catatan || [];
  let i = 0;
  if (global.db.data.users[m.sender].catatan.length == 0) return m.reply("Kamu belum punya catatan!");
  let txt = "\u{1F5D2}\uFE0FDaftar catatan\u{1F5D2}\uFE0F\n\n";
  for (let ct in global.db.data.users[m.sender].catatan) {
    i += 1;
    txt += "[" + i + "]. " + global.db.data.users[m.sender].catatan[ct].title + "\n";
  }
  txt += `
Penggunaan: ${usedPrefix}hapuscatatan 1`;
  if (text.length == 0) return m.reply(txt);
  let catatan = global.db.data.users[m.sender].catatan;
  let split = text.split("|");
  if (catatan.length == 0) return m.reply("Kamu belum memiliki catatan!");
  let n = Number(split[0]) - 1;
  if (catatan[n] == void 0) return m.reply("Catatan tidak ditemukan!");
  let tmp = [];
  for (let ct in catatan) {
    if (ct != n) {
      tmp.push(catatan[ct]);
    } else {
      continue;
    }
  }
  cdang = global.db.data.users[m.sender].catatan;
  global.db.data.users[m.sender].catatan = tmp;
  jagoanproject.reply(m.chat, `Berhasil menghapus catatan!`, m, false, {
    contextInfo: {
      mentionedJid: jagoanproject.parseMention(text)
    }
  });
};
handler.help = ["hapuscatatan title"];
handler.tags = ["catatan"];
handler.command = /^hapuscatatan$/i;
handler.register = true;
handler.limit = true;
var tools_catatanhapus_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
