/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - caripesan.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_caripesan_exports = {};
__export(tools_caripesan_exports, {
  default: () => tools_caripesan_default
});
module.exports = __toCommonJS(tools_caripesan_exports);
var import_node_fetch = __toESM(require("node-fetch"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, {
  command,
  usedPrefix,
  jagoanproject,
  text,
  args
}) => {
  let lister = [
    "gc",
    "pc"
  ];
  let [feature, inputs, inputs_, inputs__, inputs___] = text.split("|");
  if (!lister.includes(feature)) throw "*Example:*\n.caripesan pc|halo\n\n*Pilih type yg ada*\n" + lister.map((v, index) => "  \u25CB " + v).join("\n");
  if (lister.includes(feature)) {
    if (feature == "gc") {
      if (!inputs) throw "Input pesan yang mau di cari";
      let chats = Object.entries(await jagoanproject.chats).filter(([nama]) => !nama.endsWith("s.whatsapp.net")).map(([nama, isi]) => ({
        nama,
        messages: Object.values(isi.messages || {})
      }));
      let msge = chats.flatMap(({
        messages
      }) => Object.values(messages)).filter(
        (obj) => obj.message.extendedTextMessage && obj.message.extendedTextMessage.text.includes(inputs) || obj.message.conversation && obj.message.conversation.includes(inputs)
      );
      if (msge) {
        let teks = await Promise.all(
          msge.map(async (v, index) => {
            let groupName = await jagoanproject.getName(v.key.remoteJid);
            let participantNumber = "@" + v.key.participant.split("@")[0];
            return `*[ ${index + 1} ]*
*Grup:*
${groupName}
*Dari:*
${participantNumber}
*Pesan:*
${v.message.extendedTextMessage ? v.message.extendedTextMessage.text : v.message.conversation}`.trim();
          })
        );
        let caption = teks.filter((v) => v).join("\n\n________________________\n\n");
        m.reply(caption, m.chat, {
          mentions: await jagoanproject.parseMention(caption)
        });
      } else throw "Not found";
    }
    if (feature == "pc") {
      if (!inputs) throw "Input pesan yang mau di cari";
      let chats = Object.entries(await jagoanproject.chats).filter(([nama]) => !nama.endsWith("g.us")).map(([nama, isi]) => ({
        nama,
        messages: Object.values(isi.messages || {})
      }));
      let msge = chats.flatMap(({
        messages
      }) => Object.values(messages)).filter(
        (obj) => obj.message.extendedTextMessage && obj.message.extendedTextMessage.text.includes(inputs) || obj.message.conversation && obj.message.conversation.includes(inputs)
      );
      if (msge) {
        let teks = await Promise.all(
          msge.map(async (v, index) => {
            let participantNumber = "@" + v.key.remoteJid.split("@")[0];
            return `*[ ${index + 1} ]*
*Dari:*
${participantNumber}
*Pesan:*
${v.message.extendedTextMessage ? v.message.extendedTextMessage.text : v.message.conversation}`.trim();
          })
        );
        let caption = teks.filter((v) => v).join("\n\n________________________\n\n");
        m.reply(caption, m.chat, {
          mentions: await jagoanproject.parseMention(caption)
        });
      } else throw "Not found";
    }
  }
};
handler.help = ["caripesan type query"];
handler.tags = ["tools"];
handler.command = /^(caripesan|searchmessage)$/i;
handler.register = true;
handler.limit = true;
var tools_caripesan_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
