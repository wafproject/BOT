/**
 * tools/removebg.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/tools/removebg",
  "command": [
    "removebg",
    "nobg"
  ],
  "kind": "media",
  "mediaInput": true,
  "category": "tools"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
