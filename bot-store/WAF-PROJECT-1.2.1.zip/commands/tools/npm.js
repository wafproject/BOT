/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - npm.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_npm_exports = {};
__export(tools_npm_exports, {
  default: () => tools_npm_default
});
module.exports = __toCommonJS(tools_npm_exports);
let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `*\u2022 Example:* ${usedPrefix + command} package_name`;
  let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`);
  let { objects } = await res.json();
  if (!objects.length) throw `Query "${text}" not found :/`;
  let txt = objects.map(({ package: pkg }) => {
    return `*${pkg.name}* (v${pkg.version})
_${pkg.links.npm}_
_${pkg.description}_`;
  }).join`\n\n`;
  m.reply(txt);
};
handler.help = ["npmsearch", "npm"].map((a) => a + " *[package name]*");
handler.tags = ["tools"];
handler.command = /^npm(js|search)?$/i;
handler.register = true;
handler.limit = true;
var tools_npm_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
