/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - allbutton.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_allbutton_exports = {};
__export(tools_allbutton_exports, {
  default: () => tools_allbutton_default
});
module.exports = __toCommonJS(tools_allbutton_exports);
let handler = async (m, { jagoanproject }) => {
  await jagoanproject.sendMessage(
    m.chat,
    {
      text: "This is an Interactive message!",
      title: "ARMAN BOTzz",
      subtitle: "There is a subtitle",
      footer: "ARMAN GZ Official",
      interactiveButtons: [
        {
          name: "quick_reply",
          buttonParamsJson: JSON.stringify({
            display_text: "Click Me!",
            id: "your_id"
          })
        },
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Follow Me",
            url: "https://whatsapp.com/channel/0029VbAtJrf2Jl8H9Ivph30q",
            merchant_url: "https://whatsapp.com/channel/0029VbAtJrf2Jl8H9Ivph30q"
          })
        },
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "Click Me!",
            copy_code: "https://whatsapp.com/channel/0029VbAtJrf2Jl8H9Ivph30q"
          })
        },
        {
          name: "cta_call",
          buttonParamsJson: JSON.stringify({
            display_text: "Call Me!",
            phone_number: "6285820947960"
          })
        },
        {
          name: "cta_catalog",
          buttonParamsJson: JSON.stringify({
            business_phone_number: "6285820947960"
          })
        },
        {
          name: "cta_reminder",
          buttonParamsJson: JSON.stringify({
            display_text: "Set Reminder"
          })
        },
        {
          name: "cta_cancel_reminder",
          buttonParamsJson: JSON.stringify({
            display_text: "Cancel Reminder"
          })
        },
        {
          name: "address_message",
          buttonParamsJson: JSON.stringify({
            display_text: "Send Address"
          })
        },
        {
          name: "send_location",
          buttonParamsJson: JSON.stringify({
            display_text: "Send Location"
          })
        },
        {
          name: "open_webview",
          buttonParamsJson: JSON.stringify({
            title: "Follow Me!",
            link: {
              in_app_webview: true,
              url: "https://whatsapp.com/channel/0029VbAtJrf2Jl8H9Ivph30q"
            }
          })
        },
        {
          name: "mpm",
          buttonParamsJson: JSON.stringify({
            product_id: "8816262248471474"
          })
        },
        {
          name: "wa_payment_transaction_details",
          buttonParamsJson: JSON.stringify({
            transaction_id: "12345848"
          })
        },
        {
          name: "automated_greeting_message_view_catalog",
          buttonParamsJson: JSON.stringify({
            business_phone_number: "6285820947960",
            catalog_product_id: "12345"
          })
        },
        {
          name: "galaxy_message",
          buttonParamsJson: JSON.stringify({
            mode: "published",
            flow_message_version: "3",
            flow_token: "1:1307913409923914:293680f87029f5a13d1ec5e35e718af3",
            flow_id: "1307913409923914",
            flow_cta: "ARMAN BOTzz",
            flow_action: "navigate",
            flow_action_payload: {
              screen: "QUESTION_ONE",
              params: {
                user_id: "123456789",
                referral: "campaign_xyz"
              }
            },
            flow_metadata: {
              flow_json_version: "201",
              data_api_protocol: "v2",
              flow_name: "Lead Qualification [en]",
              data_api_version: "v2",
              categories: ["Lead Generation", "Sales"]
            }
          })
        },
        {
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: "Click Me!",
            sections: [
              {
                title: "Title 1",
                highlight_label: "Highlight label 1",
                rows: [
                  {
                    header: "Header 1",
                    title: "Title 1",
                    description: "Description 1",
                    id: "Id 1"
                  },
                  {
                    header: "Header 2",
                    title: "Title 2",
                    description: "Description 2",
                    id: "Id 2"
                  }
                ]
              }
            ]
          })
        }
      ]
    }
  );
};
handler.command = /^allbutton$/i;
handler.help = ["allbutton"];
handler.tags = ["tools"];
handler.register = true;
handler.limit = true;
var tools_allbutton_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
