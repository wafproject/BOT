/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - transcribe.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_transcribe_exports = {};
__export(tools_transcribe_exports, {
  default: () => tools_transcribe_default
});
module.exports = __toCommonJS(tools_transcribe_exports);
var import_axios = __toESM(require("axios"));
async function transcribe(url) {
  try {
    let res = await import_axios.default.get("https://yts.kooska.xyz/", {
      params: { url },
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
        "Referer": "https://kooska.xyz/"
      }
    }).then((i) => i.data);
    return {
      status: true,
      video_id: res.video_id,
      summarize: res.ai_response,
      transcript: res.transcript
    };
  } catch (e) {
    return {
      status: false,
      msg: `Gagal mendapatkan respon, dengan pesan: ${e.message}`
    };
  }
}
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`*Cara Penggunaan:*
${usedPrefix + command} <url video>

*Contoh:*
${usedPrefix + command} https://youtu.be/xxxxxxxxxxx`);
  }
  try {
    m.reply("Membuat Ringkasan Dan Transkrip...");
    const result = await transcribe(text);
    if (!result.status) {
      return m.reply(`*Error:* ${result.msg}`);
    }
    let resultMessage = `*Youtube Transcription And Summary*

`;
    resultMessage += `*Summary Ai :*
${result.summarize}

`;
    resultMessage += `*Full Transcription:*
${result.transcript}`;
    m.reply(resultMessage);
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan saat memproses permintaan Anda.");
  }
};
handler.help = ["transcribe", "transkripsi"];
handler.tags = ["tools"];
handler.command = /^(transcribe|transkripsi)$/i;
handler.limit = false;
handler.register = true;
var tools_transcribe_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
