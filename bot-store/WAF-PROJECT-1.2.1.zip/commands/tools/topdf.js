/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - topdf.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_topdf_exports = {};
__export(tools_topdf_exports, {
  default: () => tools_topdf_default
});
module.exports = __toCommonJS(tools_topdf_exports);
var import_fileType = require("../../lib/jagoan/function/fileType.js");
var import_node_fetch = __toESM(require("node-fetch"));
var import_form_data = __toESM(require("form-data"));
let handler = async (m, {
  command,
  usedPrefix,
  jagoanproject,
  text
}) => {
  const CONVERTAPI_TOKEN = () => String(global.convertapikey || "").trim(); // isi di settings.js: global.convertapikey = "..."
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime || !/image|video|audio|document|application|pdf|zip/i.test(mime) || mime.includes("text/plain")) {
    return m.reply(
      `\u2728 *Cara pakai ${usedPrefix + command}*

Reply gambar / dokumen / file yang ingin diubah jadi PDF

Contoh: kirim gambar \u2192 reply gambar \u2192 ketik .topdf`
    );
  }
  await m.reply("\u{1F504} Sedang mengkonversi ke PDF... (5\u201320 detik)");
  try {
    let media = await q.download();
    if (!media || media.length < 1e3) {
      throw new Error("Gagal download file atau file kosong");
    }
    if (media.length > 25 * 1024 * 1024) {
      throw new Error("File terlalu besar! Maksimal ~25MB");
    }
    const type = await (0, import_fileType.fromBuffer)(media).catch(() => ({ ext: "bin", mime: "application/octet-stream" }));
    const ext = type.ext || mime.split("/")[1] || "bin";
    const fileName = `file-${Date.now()}.${ext}`;
    const form = new import_form_data.default();
    form.append("File", media, {
      filename: fileName,
      contentType: mime || type.mime
    });
    form.append("StoreFile", "true");
    const res = await (0, import_node_fetch.default)(`https://v2.convertapi.com/convert/any/to/pdf?Secret=${CONVERTAPI_TOKEN()}`, {
      method: "POST",
      body: form,
      headers: form.getHeaders()
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => "");
      throw new Error(`ConvertAPI error ${res.status}: ${errText}`);
    }
    const json = await res.json();
    if (!json?.Files?.[0]?.Url) {
      throw new Error("Tidak mendapatkan link PDF dari server");
    }
    const { Url, FileName, FileSize } = json.Files[0];
    await jagoanproject.sendMessage(m.chat, {
      document: { url: Url },
      mimetype: "application/pdf",
      fileName: FileName || "Hasil_Konversi.pdf",
      caption: `\u2705 *Konversi selesai!*

Ukuran PDF: ${(FileSize / 1024 / 1024).toFixed(2)} MB
Link expired dalam ~3 jam`
    }, { quoted: m });
  } catch (e) {
    console.error("[ERROR TOPDF]", e);
    await m.reply(
      `\u274C Gagal konversi!

Kemungkinan penyebab:
\u2022 Format file tidak didukung
\u2022 File terlalu besar (>25MB)
\u2022 Kuota ConvertAPI habis
\u2022 Masalah koneksi/server

Detail: ${e.message || "tidak diketahui"}`
    );
  }
};
handler.help = ["topdf"];
handler.tags = ["tools", "converter"];
handler.command = /^(topdf|convertpdf|pdf)$/i;
handler.limit = true;
handler.register = true;
var tools_topdf_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
