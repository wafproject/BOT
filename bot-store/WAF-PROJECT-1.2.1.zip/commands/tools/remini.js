/**
 * .hd / .remini / .remini2 — AI remini (botcahx); kalau gagal otomatis pakai HD lokal.
 * .remini3 / .remini4 [2/3/4/5] — AI remini dengan pilihan resolusi (default 2).
 * .hdr — HD lokal 4x (tanpa API), untuk gambar yang sangat kecil.
 * HD lokal pakai library sharp: supersampling, bersihkan noise, pertajam (bukan AI).
 */
const axios = require('axios')
const btc = require('../../lib/botcahx.js')

const MAX_IN = 15 * 1024 * 1024
const MAX_SIDE = 4096

// perintah AI remini (botcahx) -> endpoint
const AI = {
  hd: { path: '/api/tools/remini', label: 'AI remini' },
  remini: { path: '/api/tools/remini', label: 'AI remini' },
  remini2: { path: '/api/tools/remini-v2', label: 'Remini V2' },
  remini3: { path: '/api/tools/remini-v3', label: 'Remini V3', resolusi: true },
  remini4: { path: '/api/tools/remini-v4', label: 'Remini V4', resolusi: true },
}

let sharpLib = null
function sharp() {
  if (!sharpLib) sharpLib = require('sharp')
  return sharpLib
}

async function getImage(m, text) {
  const url = (String(text || '').match(/https?:\/\/\S+/) || [])[0]
  if (url) {
    const r = await axios.get(url, { responseType: 'arraybuffer', timeout: 60_000, maxContentLength: MAX_IN, validateStatus: () => true })
    if (r.status !== 200) throw new Error(`gambar dari link tidak bisa diambil (HTTP ${r.status})`)
    return Buffer.from(r.data)
  }
  for (const q of [m.quoted, m]) {
    const mime = String(btc.mediaOf(q) || '')
    if (!/^image\//.test(mime)) continue
    const buf = await btc.downloadFrom(q)
    if (!buf) throw new Error('gagal mengambil gambar')
    return buf
  }
  return null
}

// Cara kerja (tanpa AI):
// 1. bersihkan kotak-kotak kompresi WA (blur sangat ringan)
// 2. perbesar melewati target (supersampling), haluskan, lalu turunkan ke target
//    -> tepi jadi halus, tidak bergerigi
// 3. gambar grafis/teks: pertegas kontras tepi | foto: pertajam lembut
async function enhance(input, mode) {
  const s = sharp()
  const base = s(input, { failOn: 'none', animated: false }).rotate()
  const meta = await base.clone().metadata()
  const w = meta.autoOrient?.width || meta.width || 0
  const h = meta.autoOrient?.height || meta.height || 0
  if (!w || !h) throw new Error('file bukan gambar')
  const long = Math.max(w, h)
  const want = typeof mode === 'number' ? mode : mode === 'hdr' ? 4 : 2
  const factor = Math.max(1, Math.min(want, MAX_SIDE / long))
  const W = Math.round(w * factor)
  const H = Math.round(h * factor)
  const alpha = !!meta.hasAlpha

  // grafis (screenshot, teks, QRIS) punya entropi rendah; foto tinggi
  const st = await base.clone().stats()
  const graphic = st.entropy < 5.5

  const superScale = Math.max(1, Math.min(2, 6000 / Math.max(W, H)))
  const BW = Math.round(W * superScale)
  const BH = Math.round(H * superScale)
  const k = factor * superScale / 2 // skala relatif ukuran besar
  let big = await base.clone()
    .blur(graphic ? 0.4 : 0.35)
    .resize(BW, BH, { kernel: 'cubic' })
    .blur(Math.max(0.3, (graphic ? 0.6 : 0.4) * k))
    .toBuffer()
  // grafis: buang bintik-bintik sisa kompresi supaya latar bersih
  if (graphic) big = await s(big).median(Math.min(5, 2 * Math.max(1, Math.round(k)) + 1)).toBuffer()

  let img = s(await s(big).resize(W, H, { kernel: 'lanczos3' }).toBuffer())
  if (graphic) {
    // tepi huruf/garis dipersempit -> tajam; warna terang tetap (titik tumpu ~240)
    img = img.linear(1.7, -168).sharpen({ sigma: Math.max(0.5, 0.3 * factor), m1: 0.4, m2: 1.2 })
  } else {
    img = img.sharpen({ sigma: Math.max(0.7, 0.5 * factor), m1: 0.5, m2: 2.0 }).modulate({ saturation: 1.05 })
  }

  img = alpha ? img.png({ compressionLevel: 8 }) : img.jpeg({ quality: 95, chromaSubsampling: '4:4:4', mozjpeg: true })
  const out = await img.toBuffer()
  return { out, w, h, W, H, alpha, graphic }
}

const handler = async (m, { wafproject, text, usedPrefix, command }) => {
  let input
  const cmd = String(command).toLowerCase()
  const model = AI[cmd]
  // resolusi untuk remini3 / remini4: angka 2-5 (default 2)
  let res = 2
  if (model?.resolusi) {
    const n = (String(text || '').replace(/https?:\/\/\S+/g, ' ').match(/\d+/) || [])[0]
    if (n !== undefined) {
      res = Number(n)
      if (![2, 3, 4, 5].includes(res)) return m.reply(`Resolusi pilih *2, 3, 4,* atau *5*.\nContoh: reply foto, ketik *${usedPrefix}${cmd} 4*`)
    }
  }

  try {
    input = await getImage(m, text)
  } catch (e) {
    return m.reply(`❌ ${e?.message || e}`)
  }
  if (!input) {
    return m.reply(`Kirim atau reply gambar dengan caption *${usedPrefix}${cmd}${model?.resolusi ? ' [2/3/4/5]' : ''}*` +
      (model?.resolusi ? `\nAngka = resolusi (default 2). Contoh: *${usedPrefix}${cmd} 4*` : '') +
      `\nBisa juga pakai link: *${usedPrefix}${cmd} <link gambar>*`)
  }
  if (input.length > MAX_IN) return m.reply('❌ Gambar terlalu besar (maks 15 MB).')

  const react = (e) => wafproject.sendMessage(m.chat, { react: { text: e, key: m.key } }).catch(() => {})
  await react('⏳')
  let aiNote = ''
  if (model) {
    // 1) AI remini botcahx: upload ke uguu.se lalu proses (maks 5 menit)
    const t0 = Date.now()
    const params = model.resolusi ? { resolusi: String(res) } : {}
    let lastErr = ''
    try {
      const up = await btc.uploadWithHost(input, [])
      const out = await btc.getMedia(model.path, { url: up.url, ...params })
      if (!/^image\//.test(out.mime || '')) throw new Error('hasil bukan gambar')
      const label = `${model.label}${model.resolusi ? `, resolusi ${res}` : ''}`
      await wafproject.sendMessage(m.chat, { image: out.buf, caption: `✨ *HD selesai* (${label}, ${((Date.now() - t0) / 1000).toFixed(1)} dtk)` }, { quote: m })
      return react('✅')
    } catch (e) {
      lastErr = e?.message || String(e)
    }
    console.warn(`[HD] ${model.label} gagal, pakai HD lokal:`, lastErr)
    aiNote = `\n_${model.label} sedang gagal, dipakai HD lokal._`
  }
  // 2) HD lokal
  try {
    const t0 = Date.now()
    const factor = cmd === 'hdr' ? 4 : model?.resolusi ? Math.min(res, 4) : 2
    const r = await enhance(input, factor)
    const caption = `✨ *HD selesai* (${r.graphic ? 'mode teks/grafis' : 'mode foto'})\n${r.w}×${r.h} → *${r.W}×${r.H}* (${((Date.now() - t0) / 1000).toFixed(1)} dtk)` +
      (r.W === r.w ? '\n_Gambar sudah besar, hanya dipertajam._' : '') + aiNote
    await wafproject.sendMessage(m.chat, r.alpha
      ? { document: r.out, mimetype: 'image/png', fileName: 'hd.png', caption }
      : { image: r.out, caption }, { quote: m })
    await react('✅')
  } catch (e) {
    console.error('[HD]', e)
    await react('❌')
    return m.reply(`❌ HD gagal: ${e?.message || e}`)
  }
}

handler.help = ['hd (reply gambar)', 'remini (reply gambar)', 'remini2 (reply gambar)', 'remini3 [2/3/4/5] (reply gambar)', 'remini4 [2/3/4/5] (reply gambar)', 'hdr (reply gambar, HD lokal 4x)']
handler.tags = ['tools']
handler.category = 'tools'
handler.command = ['hd', 'hdr', 'remini', 'remini2', 'remini3', 'remini4']
handler.limit = true
handler.register = true

module.exports = handler
