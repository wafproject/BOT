/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - pesan.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_pesan_exports = {};
__export(tools_pesan_exports, {
  default: () => tools_pesan_default
});
module.exports = __toCommonJS(tools_pesan_exports);
let handler = async (m, { jagoanproject, text, usedPrefix }) => {
  let [number, pesan] = text.split`|`;
  if (!number) return jagoanproject.reply(m.chat, "\u2022 *Example :* .pesan 6288980870067|Hai", m);
  if (!pesan) return jagoanproject.reply(m.chat, "\u2022 *Example :* .pesan 6288980870067|Hai", m);
  if (text > 500) return jagoanproject.reply(m.chat, "Teks Kepanjangan!", m);
  jagoanproject.sendMessage(m.chat, {
    react: {
      text: "\u{1F552}",
      key: m.key
    }
  });
  let user = global.db.data.users[m.sender];
  let korban = `${number}`;
  var nomor = m.sender;
  let spam1 = `*\u300C PENITIPAN PESAN \u300D*

Untuk : wa.me/${korban}
Pesan : ${pesan}

*${global.wm}*`;
  jagoanproject.reply(`${korban}@s.whatsapp.net`, spam1, m);
  let logs = `[ \u2714\uFE0F ] Berhasil mengirim pesan wa ke nomor wa.me/${korban}`;
  jagoanproject.reply(m.chat, logs, m);
};
handler.command = /^(pesan|chat)$/i;
handler.rowner = false;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.register = true;
handler.limit = true;
var tools_pesan_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
