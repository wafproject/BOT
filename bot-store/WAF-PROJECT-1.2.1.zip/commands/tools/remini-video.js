/**
 * tools/remini-video.js — sekarang lewat BOTCAHX (dulu API Jagoan Project)
 * Nama perintah tetap sama. Mesin: lib/botcahx.js
 */
const handler_def = {
  "path": "/api/tools/hdvideo",
  "command": [
    "remini-video"
  ],
  "kind": "media",
  "mediaInput": true,
  "category": "tools"
}
module.exports = require('../../lib/botcahx.js').makeAlias(handler_def)
