/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - waygroundcheat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_waygroundcheat_exports = {};
__export(tools_waygroundcheat_exports, {
  default: () => tools_waygroundcheat_default
});
module.exports = __toCommonJS(tools_waygroundcheat_exports);
var import_node_fetch = __toESM(require("node-fetch"));
let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Uhmm.. linknya mana?

Contoh:
${usedPrefix}guiziz https://wayground.com/join?gc=651911
atau
${usedPrefix}wayground https://wayground.com/join?gc=651911`;
  const linkMatch = text.match(/https?:\/\/wayground\.com\/join\?gc=(\d+)/i);
  if (!linkMatch) throw "Link Wayground tidak valid! Pastikan formatnya https://wayground.com/join?gc=xxxxxx";
  const gcId = linkMatch[1];
  const apiUrl = `https://api.cheatnetwork.eu/quizizz/${gcId}/answers`;
  try {
    await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
    const response = await (0, import_node_fetch.default)(apiUrl);
    if (!response.ok) throw "Gagal mengambil data dari API. Mungkin link sudah tidak aktif atau error server.";
    const data = await response.json();
    if (!data.success || !data.answers || data.answers.length === 0) {
      throw "Tidak ada jawaban yang ditemukan. Mungkin quiz belum dimulai atau link salah.";
    }
    let teks = `*\u{1F4DA} JAWABAN QUIZ (Untuk Pembelajaran)*

`;
    data.answers.forEach((ans, i) => {
      const no = i + 1;
      const question = ans.question || "Soal tidak terbaca";
      const options = ans.options || [];
      const answerIndices = ans.answer || [];
      const correctAnswers = answerIndices.filter((idx) => idx >= 0 && idx < options.length).map((idx) => options[idx].text || "Pilihan tidak diketahui");
      const jawabanBenar = correctAnswers.length > 0 ? correctAnswers.join(" dan ") : "Tidak diketahui";
      teks += `${no}. *Soal:* ${question}
*Jawaban Benar:* ${jawabanBenar}

`;
    });
    teks += `> "Menjadi jujur mungkin tidak membuat Anda memiliki banyak teman, tetapi itu akan selalu membuat Anda menjadi teman yang tepat." - John Lennon`;
    await m.reply(teks);
  } catch (error) {
    console.error(error);
    throw "Terjadi kesalahan saat mengambil jawaban. Coba lagi nanti atau periksa linknya.\n > Note : tidak semua soal bisa di ambil, tergantung settingan host quiz ya dek ya";
  }
};
handler.help = ["guiziz <link wayground>", "wayground <link wayground>"];
handler.tags = ["tools"];
handler.command = /^(guiziz|wayground|waygroundcheat)$/i;
handler.limit = true;
handler.register = true;
var tools_waygroundcheat_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
