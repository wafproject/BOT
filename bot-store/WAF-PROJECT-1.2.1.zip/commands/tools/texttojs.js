/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - texttojs.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_texttojs_exports = {};
__export(tools_texttojs_exports, {
  default: () => tools_texttojs_default
});
module.exports = __toCommonJS(tools_texttojs_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  let isReply = m.quoted && m.quoted.text;
  let content = isReply ? m.quoted.text : text;
  if (!content || !content.includes("|")) {
    return m.reply(`\u{1F4CC} *Contoh Penggunaan:*
1. Ketik langsung:
${usedPrefix + command} namafile|console.log("Halo Dunia!")

2. Atau reply pesan:
Balas pesan berisi kode dengan caption:
${usedPrefix + command} namafile`);
  }
  let [judul, ...isi] = isReply ? [text.trim(), content] : content.split("|");
  let fileName = `${judul.trim().replace(/[^\w\s]/gi, "") || "file"}.js`;
  let isiFile = isi.join("|").trim();
  if (!isiFile) return m.reply("\u274C Isi file tidak boleh kosong.");
  let tmpPath = import_path.default.join(__dirname, "../tmp");
  if (!import_fs.default.existsSync(tmpPath)) import_fs.default.mkdirSync(tmpPath);
  let filePath = import_path.default.join(tmpPath, fileName);
  import_fs.default.writeFileSync(filePath, isiFile);
  let buffer = import_fs.default.readFileSync(filePath);
  await jagoanproject.sendMessage(m.chat, {
    document: buffer,
    fileName,
    mimetype: "application/javascript",
    caption: `\u{1F4C1} *Berhasil membuat file:*
\u{1F4DD} ${fileName}`
  }, { quoted: m });
  import_fs.default.unlinkSync(filePath);
};
handler.help = ["texttojs <judul>|<isi>", "texttojs <judul> (reply)"];
handler.tags = ["tools"];
handler.command = ["texttojs"];
handler.register = true;
handler.limit = true;
var tools_texttojs_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
