/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - wallpaper.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_wallpaper_exports = {};
__export(tools_wallpaper_exports, {
  default: () => tools_wallpaper_default
});
module.exports = __toCommonJS(tools_wallpaper_exports);
var __zapo_1 = __toESM(require("../../lib/jagoan/simple.js"));
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const axios = require2("axios");
const { getDevice } = __zapo_1;
const ACCESS_KEY = "YSx9q0ue7fcO-aD9UM1K1F64yfidKLfQyGvhJ7k6-5s";
const UTM_SOURCE = "whatsapp_bot";
const sessions = /* @__PURE__ */ new Map();
function withUtm(url) {
  if (!url) return "";
  const joiner = url.includes("?") ? "&" : "?";
  return `${url}${joiner}utm_source=${encodeURIComponent(UTM_SOURCE)}&utm_medium=referral`;
}
async function searchUnsplash(query, page = 1, perPage = 8) {
  const res = await axios.get("https://api.unsplash.com/search/photos", {
    headers: {
      Authorization: `Client-ID ${ACCESS_KEY}`,
      "Accept-Version": "v1",
      "User-Agent": "WhatsAppBot/1.0 (Unsplash API)"
    },
    params: {
      query,
      page,
      per_page: perPage,
      orientation: "landscape"
    },
    timeout: 2e4
  });
  return res.data;
}
function caption(photo, q, idxSent, sentCount) {
  const photographer = photo?.user?.name || "Unknown";
  const userLink = withUtm(photo?.user?.links?.html || "");
  const photoLink = withUtm(photo?.links?.html || "");
  return `\u{1F5BC}\uFE0F *Unsplash Wallpaper*
\u{1F50E} *Query*: ${q}
\u{1F4CC} *Terkirim*: ${idxSent}${sentCount ? ` / ${sentCount}` : ""}

\u{1F464} *Photo by*: ${photographer}
\u{1F517} *Photographer*: ${userLink || "-"}
\u{1F517} *Unsplash*: ${photoLink || "-"}

_Tekan Next untuk lanjut._`;
}
async function getNextUnique(session) {
  while (true) {
    while (session.index < session.results.length) {
      const photo = session.results[session.index];
      session.index += 1;
      const id = photo?.id;
      if (!id) continue;
      if (!session.seen.has(id)) {
        session.seen.add(id);
        return { photo, ended: false };
      }
    }
    if (session.page < session.totalPages) {
      session.page += 1;
      session.index = 0;
      const data = await searchUnsplash(session.q, session.page, session.perPage);
      const results = data?.results || [];
      if (!results.length) {
        return { photo: null, ended: true };
      }
      session.results = results;
      session.total = data?.total || session.total;
      session.totalPages = data?.total_pages || session.totalPages;
      continue;
    }
    return { photo: null, ended: true };
  }
}
async function sendPhoto(sock, m, session, photo, usedPrefix, command) {
  const imageUrl = photo?.urls?.regular || photo?.urls?.full || photo?.urls?.small;
  if (!imageUrl) return m.reply("\u274C Foto tidak punya URL yang bisa dikirim.");
  const nextCmd = `${usedPrefix + command} --next`.trim();
  const msg = {
    image: { url: imageUrl },
    caption: caption(photo, session.q, session.seen.size, session.total),
    footer: "Unsplash",
    buttons: [{ buttonId: nextCmd, buttonText: { displayText: "Next \u25B6\uFE0F" }, type: 1 }],
    headerType: 4,
    viewOnce: true
  };
  await sock.sendMessage(m.chat, msg, { quoted: m });
}
let handler = async (m, { jagoanproject, text, usedPrefix, command, args }) => {
  const raw = String(text || "").trim();
  const isNext = raw === "--next" || args && args[0] === "--next";
  if (isNext) {
    const session2 = sessions.get(m.chat);
    if (!session2) return m.reply("Session habis. Ketik `.wallpaper <query>` lagi.");
    let next;
    try {
      next = await getNextUnique(session2);
    } catch (e) {
      sessions.delete(m.chat);
      return m.reply("\u274C Gagal load next: " + (e?.message || e));
    }
    if (next.ended || !next.photo) {
      sessions.delete(m.chat);
      return m.reply("\u2705 Sudah tidak ada hasil lagi (mentok).");
    }
    return sendPhoto(jagoanproject, m, session2, next.photo, usedPrefix || ".", command || "wallpaper");
  }
  const q = raw;
  if (!q) {
    return m.reply(
      `\u{1F5BC}\uFE0F *Wallpaper (Unsplash)*

Contoh:
${(usedPrefix || ".") + (command || "wallpaper")} red
${(usedPrefix || ".") + (command || "wallpaper")} mountain`
    );
  }
  await jagoanproject.sendMessage(m.chat, { react: { text: "\u23F3", key: m.key } });
  let data;
  try {
    data = await searchUnsplash(q, 1, 8);
  } catch (e) {
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } });
    return m.reply("\u274C Gagal request Unsplash: " + (e?.message || e));
  }
  const results = data?.results || [];
  const total = data?.total || 0;
  const totalPages = data?.total_pages || 0;
  if (!results.length) {
    sessions.delete(m.chat);
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } });
    return m.reply("\u274C Tidak ada hasil pencarian.");
  }
  const session = {
    q,
    page: 1,
    perPage: 8,
    results,
    index: 0,
    total,
    totalPages,
    seen: /* @__PURE__ */ new Set()
  };
  sessions.set(m.chat, session);
  try {
    const device = await getDevice(m.key.id);
    if (device === "ios") {
      await jagoanproject.sendMessage(
        m.chat,
        { text: `Ketik *${(usedPrefix || ".") + (command || "wallpaper")} --next* untuk Next` },
        { quoted: m }
      );
    }
  } catch {
  }
  let first;
  try {
    first = await getNextUnique(session);
  } catch (e) {
    sessions.delete(m.chat);
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } });
    return m.reply("\u274C Gagal ambil hasil: " + (e?.message || e));
  }
  if (first.ended || !first.photo) {
    sessions.delete(m.chat);
    await jagoanproject.sendMessage(m.chat, { react: { text: "\u274C", key: m.key } });
    return m.reply("\u274C Tidak ada hasil unik yang bisa ditampilkan.");
  }
  await sendPhoto(jagoanproject, m, session, first.photo, usedPrefix || ".", command || "wallpaper");
  await jagoanproject.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } });
};
handler.help = ["wallpaper <query>"];
handler.tags = ["tools"];
handler.command = ["wallpaper", "wp", "unsplash"];
handler.register = true;
handler.limit = true;
var tools_wallpaper_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
