/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - inspectlink.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_inspectlink_exports = {};
__export(tools_inspectlink_exports, {
  default: () => tools_inspectlink_default
});
module.exports = __toCommonJS(tools_inspectlink_exports);
let linkRegex = /chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i;
let handler = async (m, { jagoanproject, text }) => {
  let txt = text ? text : m.quoted ? m.quoted.text : false;
  let [, code] = txt.match(linkRegex) || [];
  if (!code) throw "Link invalid";
  let res = await jagoanproject.query({
    json: ["query", "invite", code],
    expect200: true
  });
  if (!res) throw res;
  let caption = `
-- [Group Link Inspector] --
${res.id}
*Judul:* ${res.subject}
*Dibuat* oleh @${res.id.split("-")[0]} pada *${formatDate(res.creation * 1e3)}*${res.subjectOwner ? `
*Judul diubah* oleh @${res.subjectOwner.split`@`[0]} pada *${formatDate(res.subjectTime * 1e3)}*` : ""}${res.descOwner ? `
*Deskripsi diubah* oleh @${res.descOwner.split`@`[0]} pada *${formatDate(res.descTime * 1e3)}*` : ""}
*Jumlah Member:* ${res.size}
*Member yang diketahui join*: ${res.participants ? "\n" + res.participants.map((user, i) => ++i + ". @" + user.id.split`@`[0]).join("\n").trim() : "Tidak ada"}
${res.desc ? `*Deskripsi:*
${res.desc}` : "*Tidak ada Deskripsi*"}

*JSON Version*
\`\`\`${JSON.stringify(res, null, 1)}\`\`\`
`.trim();
  let pp = await jagoanproject.profilePictureUrl(res.id).catch(console.error);
  if (pp) jagoanproject.sendFile(m.chat, pp, "pp.jpg", null, m);
  m.reply(caption, false, {
    contextInfo: {
      mentionedJid: jagoanproject.parseMention(caption)
    }
  });
};
handler.help = ["inspect <chat.whatsapp.com>"];
handler.tags = ["tools"];
handler.command = /^inspect$/i;
handler.register = true;
handler.limit = true;
var tools_inspectlink_default = handler;
function formatDate(n, locale = "id") {
  let d = new Date(n);
  return d.toLocaleDateString(locale, {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric"
  });
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
