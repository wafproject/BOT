/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - smaker.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_smaker_exports = {};
__export(tools_smaker_exports, {
  default: () => tools_smaker_default
});
module.exports = __toCommonJS(tools_smaker_exports);
var __xml2js_1 = __toESM(require("xml2js"));
var import_axios = __toESM(require("axios"));
const { parseStringPromise } = __xml2js_1;
const effects = [
  "sweetheart",
  "flutter",
  "pinkglow",
  "volcano",
  "petalprint",
  "giftwrap",
  "mrfrosty",
  "littlehelper",
  "sprinklesparkle",
  "seasonsgreetings",
  "heartbeat",
  "valentine",
  "sapphireheart",
  "signature",
  "lollipop",
  "handbag",
  "tiptoe",
  "sketchy",
  "ghostship",
  "oldenglish",
  "dragonscale",
  "magicdust",
  "substance",
  "piratescove",
  "backstreet",
  "funkyzeit",
  "airman",
  "foolsgold",
  "zephyr",
  "paintbrush",
  "lokum",
  "insignia",
  "cottoncandy",
  "fairygarden",
  "neonlights",
  "glowstick",
  "lavender",
  "ohhai",
  "bluegecko",
  "moderno",
  "petalprint",
  "rhizome",
  "devana",
  "cupcake",
  "fame",
  "ionize",
  "volcano",
  "broadway",
  "sweetheart",
  "starshine",
  "flowerpower",
  "gobstopper",
  "discodiva",
  "medieval",
  "fruityfresh",
  "letterboard",
  "greenstone",
  "alieninvasion",
  "pinkglow",
  "pinkcandy",
  "losttales",
  "glowtxt",
  "purple",
  "yourstruly",
  "electricblue",
  "greek",
  "cyrillic",
  "cyrillic2",
  "cyrillic3",
  "korean",
  "arabic",
  "arabic2",
  "arabic3",
  "hindi",
  "chinese",
  "japanese",
  "hebrew",
  "hebrew2",
  "hebrew3",
  "ethiopic",
  "ethiopic2",
  "ethiopic3",
  "vietnamese",
  "icelandic",
  "bengali",
  "yoruba",
  "igbo",
  "armenian",
  "armenian2",
  "georgian",
  "georgian2",
  "thai",
  "euro",
  "euro2",
  "euro3",
  "allstars",
  "dearest",
  "metropol",
  "ransom",
  "bronco",
  "platformtwo",
  "fictional",
  "typeface",
  "stardate",
  "beachfront",
  "arthouse",
  "sterling",
  "jukebox",
  "bubbles",
  "invitation",
  "frontier",
  "surprise",
  "firstedition",
  "republika",
  "jumble",
  "warehouse",
  "orientexpress",
  "orbitron",
  "starlight",
  "jet",
  "tamil",
  "kannada",
  "telugu",
  "punjabi",
  "malayalam",
  "odia",
  "thai2",
  "thai3",
  "thai4",
  "hindi2",
  "hindi3",
  "hindi4",
  "hindi5",
  "hindi6",
  "hindi7",
  "hindi8",
  "euro4",
  "arabic4",
  "arabic5",
  "arabic6",
  "hebrew4",
  "hebrew5",
  "hebrew6",
  "cyrillic4",
  "japanese2",
  "japanese3",
  "japanese4",
  "japanese5",
  "japanese6",
  "japanese7",
  "japanese8",
  "japanese9",
  "japanese10",
  "japanese11",
  "japanese12",
  "japanese13",
  "chinese_tc"
];
let handler = async (m, { jagoanproject, text, command }) => {
  const args = text.split("|").map((arg) => arg.trim());
  const effect = args[0];
  const message = args[1];
  if (!effect || !message) {
    return m.reply(`Contoh penggunaan: ${command} electricblue | Hello World

\u2022 List Effect
> ${effects.join("\n> ")}`);
  }
  if (!effects.includes(effect)) {
    return m.reply(`Efek tidak ditemukan. Silakan pilih dari list berikut:

> ${effects.join("\n> ")}`);
  }
  await jagoanproject.sendMessage(m.chat, global.wait, { quoted: m });
  try {
    const babyUrl = await createGlowText(effect, message);
    if (babyUrl) {
      await jagoanproject.sendMessage(m.chat, { image: { url: babyUrl }, caption: "Glow Text" }, { quoted: m });
    } else {
      m.reply("Gagal membuat Glow Text. Data tidak ditemukan.");
    }
  } catch (error) {
    await jagoanproject.sendMessage(m.chat, { ...global.eror, text: `${global.eror.text}

Detail: ${error.message}` }, { quoted: m });
  }
};
handler.help = ["smaker"];
handler.tags = ["tools"];
handler.command = /^smaker$/i;
handler.register = true;
handler.limit = true;
var tools_smaker_default = handler;
async function createGlowText(effect, text) {
  try {
    const url = `https://glowtxt.com/gentext2.php`;
    const params = {
      text,
      text2: "",
      text3: "",
      font_style: effect,
      font_size: "x",
      font_colour: "0",
      bgcolour: "#000000",
      glow_halo: "2",
      non_trans: "false",
      glitter_border: "false",
      anim_type: "none",
      submit_type: "text"
    };
    const headers = {
      "Host": "glowtxt.com",
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
      "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    };
    const response = await import_axios.default.get(url, { params, headers });
    const result = await parseStringPromise(response.data);
    const datadir = result?.image?.datadir?.[0];
    const fullFilename = result?.image?.fullfilename?.[0];
    if (datadir && fullFilename) {
      return `https://glowtxt.com/${datadir}/${fullFilename}`;
    } else {
      return null;
    }
  } catch (error) {
    throw new Error(`Terjadi kesalahan: ${error.message}`);
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
