/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - toqr.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_toqr_exports = {};
__export(tools_toqr_exports, {
  default: () => tools_toqr_default
});
module.exports = __toCommonJS(tools_toqr_exports);
var import_axios = __toESM(require("axios"));
let handler = async (m, { jagoanproject, text }) => {
  const generateQR = async (textInput) => {
    try {
      const safeText = encodeURIComponent(String(textInput).trim());
      const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${safeText}&size=1080x1080`;
      const response = await import_axios.default.get(apiUrl, {
        responseType: "arraybuffer",
        timeout: 6e4,
        maxContentLength: 16 * 1024 * 1024
      });
      if (response.status !== 200) throw new Error("Gagal menghasilkan QR code, periksa teks atau API.");
      return Buffer.from(response.data);
    } catch (error) {
      console.error("Terjadi kesalahan saat generate QR:", error);
      throw error;
    }
  };
  if (!text) throw "Berikan teks untuk diubah ke QR code!\nContoh: .toqr https://example.com";
  const inputText = String(text).trim();
  if (!inputText) throw "Teks tidak valid atau kosong!";
  const safeCaption = `QR Code untuk: ${inputText}`.replace(/[@\n\r\t]/g, " ").trim();
  try {
    const qrBuffer = await generateQR(inputText);
    await jagoanproject.sendMessage(m.chat, {
      image: qrBuffer,
      caption: safeCaption
    }, { quoted: m });
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
    throw `Terjadi kesalahan: ${err.message || err}`;
  }
};
handler.help = ["toqr"];
handler.tags = ["tools"];
handler.command = /^toqr$/i;
handler.limit = true;
handler.register = true;
var tools_toqr_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
