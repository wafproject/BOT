/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - ssweb.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_ssweb_exports = {};
__export(tools_ssweb_exports, {
  default: () => tools_ssweb_default
});
module.exports = __toCommonJS(tools_ssweb_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_node_fetch = __toESM(require("node-fetch"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const SS_API_KEY = "cb33e4";
const SS_BASE_URL = "https://api.screenshotmachine.com/";
var handler = async (m, { jagoanproject, command, args }) => {
  if (!args[0]) return jagoanproject.reply(m.chat, "Input URL!", m);
  if (args[0].match(/xnxx\.com|hamster\.com|nekopoi\.care/i)) {
    return jagoanproject.reply(m.chat, "Link tersebut dilarang!", m);
  }
  await m.reply("\uFF2C\uFF4F\uFF41\uFF44\uFF49\uFF4E\uFF47\uFF0E\uFF0E\uFF0E");
  let url = args[0].startsWith("http") ? args[0] : "https://" + args[0];
  let device = command === "sspc" ? "phone" : "desktop";
  let dimension;
  if (device === "desktop") {
    dimension = "1366x768";
  } else {
    dimension = "480x800";
  }
  const apiUrl = `${SS_BASE_URL}?key=${SS_API_KEY}&url=${encodeURIComponent(url)}&dimension=${dimension}&device=${device}&format=jpg&cacheLimit=0`;
  try {
    const img = await (0, import_node_fetch.default)(apiUrl);
    if (!img.ok) {
      return jagoanproject.reply(m.chat, "Gambar tidak tersedia", m);
    }
    const tmpDir = import_path.default.join(__dirname, "../../tmp/");
    if (!import_fs.default.existsSync(tmpDir)) import_fs.default.mkdirSync(tmpDir, { recursive: true });
    const filepath = import_path.default.join(tmpDir, +/* @__PURE__ */ new Date() + ".jpeg");
    const dest = import_fs.default.createWriteStream(filepath);
    dest.on("finish", () => {
      jagoanproject.sendFile(m.chat, filepath, "screenshot.jpeg", "Nih gambarnya.", m).then(() => {
      }).catch(() => {
      });
    });
    img.body.pipe(dest);
  } catch (e) {
    console.log(e);
    jagoanproject.reply(m.chat, "Terjadi error!", m);
  }
};
handler.help = ["ssweb", "sspc", "ss"];
handler.tags = ["tools"];
handler.command = ["ssweb", "sspc", "ss"];
handler.limit = true;
handler.fail = null;
handler.register = true;
var tools_ssweb_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
