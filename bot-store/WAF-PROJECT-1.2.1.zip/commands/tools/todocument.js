/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - todocument.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_todocument_exports = {};
__export(tools_todocument_exports, {
  default: () => tools_todocument_default
});
module.exports = __toCommonJS(tools_todocument_exports);
var import_path = __toESM(require("path"));
const extFromMime = (mime = "") => {
  const m = String(mime).toLowerCase();
  if (m.includes("image/jpeg")) return "jpg";
  if (m.includes("image/png")) return "png";
  if (m.includes("image/webp")) return "webp";
  if (m.includes("image/gif")) return "gif";
  if (m.includes("video/mp4")) return "mp4";
  if (m.includes("video/quicktime")) return "mov";
  if (m.includes("audio/mpeg")) return "mp3";
  if (m.includes("audio/mp4") || m.includes("audio/m4a")) return "m4a";
  if (m.includes("audio/ogg")) return "ogg";
  if (m.includes("audio/wav")) return "wav";
  if (m.includes("application/pdf")) return "pdf";
  if (m.includes("application/zip")) return "zip";
  if (m.includes("text/plain")) return "txt";
  if (m.includes("application/msword")) return "doc";
  if (m.includes("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) return "docx";
  if (m.includes("application/vnd.ms-excel")) return "xls";
  if (m.includes("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) return "xlsx";
  if (m.includes("application/vnd.ms-powerpoint")) return "ppt";
  if (m.includes("application/vnd.openxmlformats-officedocument.presentationml.presentation")) return "pptx";
  return "bin";
};
const safeName = (s = "") => String(s).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").replace(/\s+/g, " ").trim().slice(0, 120);
let handler = async (m, { jagoanproject, command, text }) => {
  const q = m.quoted ? m.quoted : m;
  const isViewOnce = q?.msg?.viewOnce || q?.msg?.viewOnceMessageV2 || q?.msg?.viewOnceMessage || false;
  if (isViewOnce) throw "\u274C Tidak bisa ambil media *view-once*. Kirim ulang tanpa view-once ya.";
  const mime = q?.mimetype || q?.msg?.mimetype || q?.msg?.documentMessage?.mimetype || q?.msg?.imageMessage?.mimetype || q?.msg?.videoMessage?.mimetype || q?.msg?.audioMessage?.mimetype || q?.msg?.stickerMessage?.mimetype || "";
  if (typeof q.download !== "function") {
    throw "\u{1F4CE} Reply *pesan yang ada medianya* (foto/video/audio/sticker/file), lalu ketik (salah satu):\n\n> .todoc\n> .todoc <namafile>";
  }
  let buffer;
  try {
    buffer = await q.download();
  } catch (e) {
    throw "\u274C Gagal download medianya. Coba reply ulang atau kirim ulang filenya.";
  }
  if (!buffer) throw "\u274C Buffer kosong. Media tidak bisa diproses.";
  let originalName = q?.fileName || q?.msg?.fileName || q?.msg?.documentMessage?.fileName || q?.msg?.audioMessage?.fileName || q?.msg?.videoMessage?.fileName || q?.msg?.imageMessage?.fileName || "";
  const userNameRaw = (text || "").trim();
  const ext = extFromMime(mime);
  let fileName = "";
  if (userNameRaw) {
    const safe = safeName(userNameRaw);
    fileName = import_path.default.extname(safe) ? safe : `${safe}.${ext}`;
  } else if (originalName) {
    fileName = safeName(originalName);
    if (!import_path.default.extname(fileName)) fileName = `${fileName}.${ext}`;
  } else {
    fileName = `media.${ext}`;
  }
  await m.reply("\u23F3 Mengubah menjadi *document*...");
  await jagoanproject.sendMessage(
    m.chat,
    {
      document: buffer,
      mimetype: mime || "application/octet-stream",
      fileName
    },
    { quoted: m }
  );
};
handler.help = ["todocument"];
handler.tags = ["tools"];
handler.command = /^(todoc|todocument)$/i;
handler.register = true;
var tools_todocument_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
