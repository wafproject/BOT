/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - fakesize.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_fakesize_exports = {};
__export(tools_fakesize_exports, {
  default: () => tools_fakesize_default
});
module.exports = __toCommonJS(tools_fakesize_exports);
let fetch;
let uploadImage;
let __deps_inited = false;
async function __init_deps() {
  if (__deps_inited) return;
  __deps_inited = true;
  {
    const m = await import("node-fetch");
    fetch = m && "default" in m ? m.default : m;
  }
  {
    const m = await import("../../lib/jagoan/lib/uploadImage.js");
    uploadImage = m && "default" in m ? m.default : m;
  }
}
async function handler(m, { jagoanproject, usedPrefix, command, args, text }) {
  if (!text) return m.reply("kirim video/gambar/audio dengan caption .fakesize <angka>");
  const angka = args.join` `;
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || q.mediaType || "";
  if (!mime) throw "Reply video/image/audio";
  const img = await q.download();
  const out = await uploadImage(img);
  let fileSizeLimit = 15 * 1024 * 1024;
  if (img.length > fileSizeLimit) {
    throw "Ukuran media tidak boleh melebihi 15MB";
  }
  if (/^audio/.test(mime)) {
    jagoanproject.sendMessage(m.chat, {
      audio: img,
      mimetype: "audio/mpeg",
      fileLength: angka
    });
  } else if (/^video/.test(mime)) {
    jagoanproject.sendMessage(m.chat, {
      video: img,
      gifPlayback: false,
      fileLength: angka
    });
  } else if (/^image/.test(mime)) {
    jagoanproject.sendMessage(m.chat, {
      image: img,
      fileLength: angka
    });
  } else {
    m.reply(`Kirim gambar/video/audio dengan caption *${usedPrefix + command}* <angka> atau tag gambar/video/audio yang sudah dikirim.`);
  }
}
handler.help = ["fakesize <angka>"];
handler.tags = ["tools"];
handler.command = ["fakesize"];
handler.premium = false;
handler.limit = false;
handler.register = true;
var tools_fakesize_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
