/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - cekresolusi.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_cekresolusi_exports = {};
__export(tools_cekresolusi_exports, {
  default: () => tools_cekresolusi_default
});
module.exports = __toCommonJS(tools_cekresolusi_exports);
let jimp;
let uploadImage;
let uploadFile;
let __deps_inited = false;
async function __init_deps() {
  if (__deps_inited) return;
  __deps_inited = true;
  {
    const m = await import("jimp");
    jimp = m && "default" in m ? m.default : m;
  }
  {
    const m = await import("../../lib/jagoan/lib/uploadImage.js");
    uploadImage = m && "default" in m ? m.default : m;
  }
  {
    const m = await import("../../lib/jagoan/lib/uploadFile.js");
    uploadFile = m && "default" in m ? m.default : m;
  }
}
let handler = async (m, { jagoanproject, usedPrefix }) => {
  await __init_deps();
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw "where the media?";
  let media = await q.download();
  let isMedia = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
  let link = await (isMedia ? uploadImage : uploadImage)(media);
  let source = await jimp.read(await link);
  let height = await source.getHeight();
  let width = await source.getWidth();
  m.reply(`*_RESOLUSI:_* ${width} x ${height}

*> Lebar :* ${width}
*> Tinggi :* ${height}

*> Link :* ${link}`);
};
handler.help = ["cekresolution *<foto>*", "cekreso *<foto>*"];
handler.tags = ["tools"];
handler.command = /^(cekreso(lution)?)$/i;
handler.register = true;
handler.limit = true;
var tools_cekresolusi_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
