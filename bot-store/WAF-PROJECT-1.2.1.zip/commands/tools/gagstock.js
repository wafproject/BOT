/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - gagstock.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_gagstock_exports = {};
__export(tools_gagstock_exports, {
  default: () => tools_gagstock_default
});
module.exports = __toCommonJS(tools_gagstock_exports);
var import_node_fetch = __toESM(require("node-fetch"));
var import_ws = __toESM(require("ws"));
let handler = async (m, { jagoanproject }) => {
  await jagoanproject.sendMessage(m.chat, {
    react: { text: "\u23F3", key: m.key }
  });
  let data = null;
  let source = "growagarden pro";
  try {
    const ws = new import_ws.default("wss://ws.growagardenpro.com", [], {
      headers: {
        "Host": "ws.growagardenpro.com",
        "Origin": "https://growagardenpro.com",
        "User-Agent": "NekoHost/1.0.0"
      }
    });
    let packets = [];
    let isOpen = false;
    ws.on("open", () => {
      isOpen = true;
    });
    ws.on("message", (msg) => {
      try {
        const parsed = JSON.parse(msg.toString());
        packets.push(parsed);
      } catch {
        packets.push(msg.toString());
      }
    });
    await new Promise((resolve) => {
      const check = () => isOpen ? resolve() : setTimeout(check, 100);
      check();
    });
    await new Promise((resolve) => setTimeout(resolve, 1e4));
    ws.close();
    const last = packets.pop();
    if (last && last.data) data = last.data;
  } catch (err) {
    console.error("[Nekolabs Error]", err.message);
  }
  if (!data) {
    source = "gagstock gleeze";
    try {
      const res = await (0, import_node_fetch.default)("https://gagstock.gleeze.com/grow-a-garden", {
        headers: { Accept: "application/json" }
      });
      const json = await res.json();
      if (json?.data) data = json.data;
    } catch (err) {
      console.error("[GAGStock Error]", err.message);
    }
  }
  if (!data) {
    await jagoanproject.sendMessage(m.chat, {
      react: { text: "\u26A0\uFE0F", key: m.key }
    });
    return m.reply("\u274C Gagal mengambil data dari kedua sumber (Nekolabs & GAGStock).");
  }
  let textResult = "\u{1F33F} *\u0262\u0280\u1D0F\u1D21 \u1D00 \u0262\u1D00\u0280\u1D05\u1D07\u0274 \u0280\u1D07\u1D18\u1D0F\u0280\u1D1B*\n\n";
  textResult += `\u{1F4E1} *Source:* ${source}

`;
  const section = (title, emoji, items) => {
    if (!items || items.length === 0) return "";
    let t = `${emoji} *${title}*
`;
    for (let i of items) t += `\u2022 ${i.name} \u2794 ${i.quantity}
`;
    return t + "\n";
  };
  textResult += section("\uA731\u1D07\u1D07\u1D05\uA731", "\u{1F331}", data.seeds || data.seed);
  textResult += section("\u0262\u1D07\u1D00\u0280", "\u{1F6E0}\uFE0F", data.gear);
  textResult += section("\u1D07\u0262\u0262\uA731", "\u{1F95A}", data.eggs || data.egg);
  textResult += section("\u1D04\u1D0F\uA731\u1D0D\u1D07\u1D1B\u026A\u1D04\uA731", "\u{1F484}", data.cosmetics);
  textResult += section("\u029C\u1D0F\u0274\u1D07\u028F", "\u{1F36F}", data.honey);
  if (data.weather) {
    textResult += "\u26C5 *\u1D21\u1D07\u1D00\u1D1B\u029C\u1D07\u0280*\n";
    textResult += `\u2022 \u1D1B\u028F\u1D18\u1D07: ${data.weather.type}
`;
    textResult += `\u2022 \u1D00\u1D04\u1D1B\u026A\u1D20\u1D07: ${data.weather.active ? "\u2705 \u028F\u1D07\uA731" : "\u274C \u0274\u1D0F"}
`;
    if (data.weather.effects?.length) {
      textResult += "\u2022 \u1D07\uA730\uA730\u1D07\u1D04\u1D1B\uA731:\n";
      for (let fx of data.weather.effects) textResult += `   \u2794 ${fx}
`;
    }
    textResult += "\n";
  }
  if (data.weatherHistory) {
    textResult += "\u{1F4CA} *\u1D21\u1D07\u1D00\u1D1B\u029C\u1D07\u0280 \u029C\u026A\uA731\u1D1B\u1D0F\u0280\u028F*\n";
    for (let item of data.weatherHistory)
      textResult += `\u2022 ${item.type} (${item.active ? "Active" : "Ended"})
`;
    textResult += "\n";
  }
  if (data.travelingmerchant) {
    const t = data.travelingmerchant;
    textResult += `\u{1F6B6} *\u1D1B\u0280\u1D00\u1D20\u1D07\u029F\u026A\u0274\u0262 \u1D0D\u1D07\u0280\u1D04\u029C\u1D00\u0274\u1D1B*
`;
    textResult += `\u2022 \uA731\u1D1B\u1D00\u1D1B\u1D1C\uA731: ${t.status === "leaved" ? "\u274C Not in area" : "\u2705 Active"}
`;
    if (t.merchantName) textResult += `\u2022 \u0274\u1D00\u1D0D\u1D07: ${t.merchantName}
`;
    if (t.appearIn) textResult += `\u2022 \u0274\u1D07x\u1D1B \u1D00\u1D18\u1D18\u1D07\u1D00\u0280: ${t.appearIn}
`;
    if (t.items?.length) {
      textResult += "\u2022 \u026A\u1D1B\u1D07\u1D0D\uA731:\n";
      for (let i of t.items) textResult += `   \u2794 ${i.name} \xD7${i.quantity}
`;
    }
    textResult += "\n";
  }
  const lastKey = Object.keys(data).find((k) => k.toLowerCase().includes("lastglobalupdate"));
  let updateTime = lastKey ? data[lastKey] : data.updated_at || null;
  if (updateTime) {
    try {
      let d = new Date(updateTime);
      let tanggal = d.toLocaleDateString("id-ID", {
        day: "2-digit",
        month: "long",
        year: "numeric",
        timeZone: "Asia/Jakarta"
      });
      let jam = d.toLocaleTimeString("id-ID", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
        timeZone: "Asia/Jakarta"
      });
      updateTime = `${tanggal} - ${jam} WIB`;
    } catch {
      updateTime = "Format waktu tidak valid";
    }
  } else updateTime = "Data tidak tersedia";
  textResult += `\u{1F552} *\u029F\u1D00\uA731\u1D1B \u1D1C\u1D18\u1D05\u1D00\u1D1B\u1D07:*
${updateTime}`;
  await jagoanproject.sendMessage(m.chat, { react: { text: "\u2705", key: m.key } });
  await m.reply(textResult.trim());
};
handler.help = ["gagstock"];
handler.tags = ["tools"];
handler.command = ["gagstock", "growgardenstock", "stockgag"];
handler.register = true;
handler.limit = true;
var tools_gagstock_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
