/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - copyme.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_copyme_exports = {};
__export(tools_copyme_exports, {
  default: () => tools_copyme_default
});
module.exports = __toCommonJS(tools_copyme_exports);
let handler = async (m, { jagoanproject }) => {
  let sender = m.sender || m.key.participant || m.key.remoteJid;
  let number = sender.replace(/[^0-9]/g, "");
  const interactiveMessage = {
    text: `
 \u{1FA80} nomor kamu
 \u2570\u2508\u27A4 *${number}*`,
    title: "\u2705 *BERHASIL COPY NOMOR*",
    footer: "\n\u1D1B\u1D07\u1D0B\u1D00\u0274 \u1D1B\u1D0F\u1D0D\u0299\u1D0F\u029F \u1D05\u026A\u0299\u1D00\u1D21\u1D00\u029C \u026A\u0274\u026A \u1D1C\u0274\u1D1B\u1D1C\u1D0B \u1D0D\u1D07\u0274\u028F\u1D00\u029F\u026A\u0274 \u0274\u1D0F\u1D0D\u1D0F\u0280.",
    interactiveButtons: [
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "\u{1F4CB} SALIN NOMOR",
          id: "copy_number",
          copy_code: number
        })
      }
    ]
  };
  await jagoanproject.sendMessage(m.chat, interactiveMessage, { quoted: m });
};
handler.help = ["copyme"];
handler.tags = ["tools"];
handler.command = /^copyme$/i;
handler.register = true;
handler.limit = true;
var tools_copyme_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
