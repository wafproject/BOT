/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - react.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_react_exports = {};
__export(tools_react_exports, {
  default: () => tools_react_default
});
module.exports = __toCommonJS(tools_react_exports);
let handler = async (m, { jagoanproject, usedPrefix, text }) => {
  if (!m.quoted) throw "Balas chat yang ingin diberi reaction!";
  if (!text) throw `\u2022 Contoh Penggunaan :
${usedPrefix}react \u{1F602}\u{1F917}\u{1F975}`;
  let emojis = text.match(new RegExp("\\p{Emoji_Presentation}|\\p{Emoji}\\uFE0F", "gu")) || [];
  if (emojis.length === 0) throw "Mana emojinya? Masukkan emoji yang valid.";
  for (let emoji of emojis) {
    await jagoanproject.relayMessage(m.chat, {
      reactionMessage: {
        key: {
          id: m.quoted.id,
          remoteJid: m.chat,
          fromMe: m.quoted.fromMe
        },
        text: emoji
      }
    }, { messageId: m.id });
  }
};
handler.help = ["react *<emoji>*"];
handler.tags = ["tools"];
handler.command = /^(react)$/i;
handler.register = true;
handler.limit = true;
var tools_react_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
