/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - deployweb.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_deployweb_exports = {};
__export(tools_deployweb_exports, {
  default: () => tools_deployweb_default
});
module.exports = __toCommonJS(tools_deployweb_exports);
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var import_unzipper = __toESM(require("unzipper"));
var import_url = require("url");
var import_path2 = require("path");
const __jpUnused___filename = (0, import_url.fileURLToPath)(__jpImportMetaUrl);
const __jpUnused___dirname = (0, import_path2.dirname)(__filename);
const TOKEN_PATH = import_path.default.join(__dirname, "../database/tokenvercel.json");
function getVercelToken() {
  try {
    if (import_fs.default.existsSync(TOKEN_PATH)) {
      const data = JSON.parse(import_fs.default.readFileSync(TOKEN_PATH, "utf8"));
      return data.token || null;
    }
  } catch (e) {
    console.error("Error membaca token:", e);
  }
  return null;
}
function saveVercelToken(token) {
  try {
    import_fs.default.mkdirSync(import_path.default.dirname(TOKEN_PATH), { recursive: true });
    import_fs.default.writeFileSync(TOKEN_PATH, JSON.stringify({ token: token.trim() }, null, 2));
    return true;
  } catch (e) {
    console.error("Error menyimpan token:", e);
    return false;
  }
}
const getFetch = async () => {
  if (typeof fetch !== "undefined") return fetch;
  const mod = await import("node-fetch");
  return mod.default;
};
let handler = async (m, { text, usedPrefix, command }) => {
  const cmd = (command || "").toLowerCase();
  const senderNumber = m.sender.replace(/[^0-9]/g, "");
  const isOwner = global.jpOwner?.some(([no]) => no === senderNumber);
  const onlyOwner = (msg) => m.reply(msg || "\u274C Perintah ini hanya bisa digunakan oleh *Owner Bot*!");
  if (cmd === "setvercel") {
    if (!isOwner) return onlyOwner();
    if (!text)
      return m.reply(
        "\u2699\uFE0F Contoh:\n.setvercel <token_vercel_kamu>\n> Dapatkan Token Vercel di: https://vercel.com/account/settings/tokens\nSetting:\n - Nama: Bebas\n - Scope: Full Account\n - Expiration: No Expired"
      );
    const ok = saveVercelToken(text);
    return m.reply(ok ? "\u2705 Token Vercel berhasil disimpan di ./database/tokenvercel.json" : "\u274C Gagal menyimpan token. Cek permission folder ./database/");
  }
  if (cmd === "deployweb") {
    if (!text) throw `Contoh: ${usedPrefix + command} <nama_web>`;
    const token = getVercelToken();
    if (!token)
      return m.reply(
        "\u26A0\uFE0F Token belum diset oleh owner bot!\nGunakan perintah: .setvercel <token_vercel_kamu>"
      );
    const webName = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, "");
    if (!webName) return m.reply("\u274C Nama web tidak valid.");
    const domainCheckUrl = `https://${webName}.vercel.app`;
    const $fetch = await getFetch();
    try {
      const check = await $fetch(domainCheckUrl);
      if (check.status === 200)
        return m.reply(`\u274C Nama web *${webName}* sudah digunakan. Silakan pakai nama lain.`);
    } catch (_) {
    }
    const quotedFile = m.quoted ? m.quoted : m;
    const mime = (quotedFile.msg || quotedFile).mimetype || quotedFile.mediaType || "";
    const filesToUpload = [];
    if (/zip/.test(mime)) {
      m.reply("\u23F3 Memproses file ZIP, mohon tunggu...");
      const zipBuffer = await quotedFile.download();
      const directory = await import_unzipper.default.Open.buffer(zipBuffer);
      for (const file of directory.files) {
        if (file.type === "File") {
          const content = await file.buffer();
          const filePath = file.path.replace(/^\/+/, "").replace(/\\/g, "/");
          filesToUpload.push({
            file: filePath,
            data: content.toString("base64"),
            encoding: "base64"
          });
        }
      }
      if (!filesToUpload.some((x) => x.file.toLowerCase().endsWith("index.html"))) {
        return m.reply("\u274C File index.html tidak ditemukan dalam ZIP.");
      }
    } else if (/html/.test(mime)) {
      m.reply("\u23F3 Memproses file HTML, mohon tunggu...");
      const content = await quotedFile.download();
      filesToUpload.push({
        file: "index.html",
        data: content.toString("base64"),
        encoding: "base64"
      });
    } else {
      return m.reply("\u{1F4CE} Kirim/quote file .zip atau .html lalu jalankan perintah:\n.deployweb <nama_web>");
    }
    const headers = {
      Authorization: `Bearer ${getVercelToken()}`,
      "Content-Type": "application/json"
    };
    try {
      await $fetch("https://api.vercel.com/v9/projects", {
        method: "POST",
        headers,
        body: JSON.stringify({ name: webName })
      });
    } catch (_) {
    }
    const deployRes = await $fetch("https://api.vercel.com/v13/deployments", {
      method: "POST",
      headers,
      body: JSON.stringify({
        name: webName,
        project: webName,
        files: filesToUpload,
        projectSettings: { framework: null }
      })
    });
    let deployData = null;
    try {
      deployData = await deployRes.json();
    } catch (_) {
    }
    if (!deployRes.ok || !deployData || !deployData.url) {
      console.log("Deploy Error:", deployData);
      return m.reply(
        "\u274C Gagal deploy ke Vercel.\n" + (deployData ? "```" + JSON.stringify(deployData, null, 2) + "```" : "")
      );
    }
    return m.reply(
      `\u2705 Website berhasil dibuat!

\u{1F310} URL: https://${webName}.vercel.app
> Jika belum muncul, tunggu beberapa menit (proses deploy).`
    );
  }
  return;
};
handler.help = ["setvercel", "deployweb"];
handler.tags = ["tools"];
handler.command = ["setvercel", "deployweb", "deploy", "tovercel"];
handler.limit = true;
var tools_deployweb_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
