/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/tools/tools - voiceflow.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var tools_voiceflow_exports = {};
__export(tools_voiceflow_exports, {
  default: () => tools_voiceflow_default
});
module.exports = __toCommonJS(tools_voiceflow_exports);
var import_node_fetch = __toESM(require("node-fetch"));
const ses = {};
const handler = async (m, {
  jagoanproject,
  args,
  usedPrefix,
  command,
  text
}) => {
  const id = m.chat;
  const txt = (args.join(" ") || text || "").trim();
  console.log(`Input received: ${txt}, Chat: ${id}, Sender: ${m.sender}`);
  if (ses[id] && /^\d+$/.test(txt)) {
    console.log(`Session found for ${id}, processing number: ${txt}`);
    const num = parseInt(txt);
    const s = ses[id];
    if (isNaN(num) || num < 1 || num > s.v.length) {
      console.log(`Invalid number: ${num}`);
      return jagoanproject.reply(m.chat, "Nomor tidak valid. Pilih nomor dari daftar.", m);
    }
    const vc = s.v[num - 1];
    const url = Object.values(vc).find((x) => typeof x === "string" && x.endsWith(".wav"));
    if (!url) {
      console.log(`Audio URL not found for choice ${num}`);
      clearTimeout(s.to);
      delete ses[id];
      return jagoanproject.reply(m.chat, "Audio tidak ditemukan.", m);
    }
    try {
      console.log(`Sending audio: ${url}`);
      await jagoanproject.sendFile(m.chat, url, "voice.wav", null, m, false, {
        mimetype: "audio/mpeg"
      });
      clearTimeout(s.to);
      delete ses[id];
      console.log(`Audio sent, session cleared for ${id}`);
    } catch (e) {
      console.log(`Error sending audio: ${e}`);
      clearTimeout(s.to);
      delete ses[id];
      return jagoanproject.reply(m.chat, "Gagal mengirim audio: " + e.message, m);
    }
    return;
  }
  if (command !== "voiceflow") return;
  if (!txt) {
    console.log("No text provided");
    return jagoanproject.reply(m.chat, `Masukkan teks
Contoh: ${usedPrefix}${command} Halo dunia`, m);
  }
  try {
    console.log(`Fetching text-to-speech for text: ${txt}`);
    const res = await (0, import_node_fetch.default)(`${flowfalcon}tools/text-to-speech?text=${encodeURIComponent(txt)}`);
    const json = await res.json();
    if (!json.status || !json.result) {
      console.log("API response error");
      throw "Respon error dari API";
    }
    ses[id] = {
      t: txt,
      v: json.result,
      to: setTimeout(() => {
        console.log(`Session timeout for ${id}`);
        delete ses[id];
      }, 18e4)
    };
    let ls = json.result.map((v, i) => `${i + 1}. ${v.voice_name}`).join("\n");
    console.log(`Session created for ${id}, voice list: ${ls}`);
    return jagoanproject.reply(m.chat, `Teks diterima!
Pilih suara dengan mengetik nomor saja (misalnya: 1):

${ls}`, m);
  } catch (e) {
    console.log(`Error fetching voices: ${e}`);
    return jagoanproject.reply(m.chat, "Gagal mengambil suara: " + e.message, m);
  }
};
handler.help = ["voiceflow"];
handler.tags = ["tools"];
handler.command = /^voiceflow$/i;
handler.before = async (m, { jagoanproject }) => {
  const id = m.chat;
  const txt = (m.text || "").trim();
  if (ses[id] && /^\d+$/.test(txt)) {
    console.log(`Before handler: Processing number ${txt} for chat ${id}`);
    const num = parseInt(txt);
    const s = ses[id];
    if (isNaN(num) || num < 1 || num > s.v.length) {
      console.log(`Before handler: Invalid number ${num}`);
      return jagoanproject.reply(m.chat, "Nomor tidak valid. Pilih nomor dari daftar.", m);
    }
    const vc = s.v[num - 1];
    const url = Object.values(vc).find((x) => typeof x === "string" && x.endsWith(".wav"));
    if (!url) {
      console.log(`Before handler: Audio URL not found for choice ${num}`);
      clearTimeout(s.to);
      delete ses[id];
      return jagoanproject.reply(m.chat, "Audio tidak ditemukan.", m);
    }
    try {
      console.log(`Before handler: Sending audio ${url}`);
      await jagoanproject.sendFile(m.chat, url, "voice.wav", null, m, false, {
        mimetype: "audio/mpeg"
      });
      clearTimeout(s.to);
      delete ses[id];
      console.log(`Before handler: Audio sent, session cleared for ${id}`);
    } catch (e) {
      console.log(`Before handler: Error sending audio: ${e}`);
      clearTimeout(s.to);
      delete ses[id];
      return jagoanproject.reply(m.chat, "Gagal mengirim audio: " + e.message, m);
    }
  }
};
handler.limit = false;
handler.register = true;
var tools_voiceflow_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "tools" }
)
