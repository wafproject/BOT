/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - fakepolling.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_fakepolling_exports = {};
__export(fun_fakepolling_exports, {
  default: () => fun_fakepolling_default
});
module.exports = __toCommonJS(fun_fakepolling_exports);
let handler = async (m, { jagoanproject, text }) => {
  if (!text || !text.includes("|")) {
    return m.reply(
      `\u274C Format salah!
Cara Penggunaaan : .fakepoll Judulnya, Disini yahh gess|Opsi1,100|Opsi2,254

Contoh:
> .fakepoll Admin apakah Gantenk?|Iya,8100|Najis,9100|Kami Cinta Admin\u2764\uFE0F,6000`
    );
  }
  const firstPipe = text.indexOf("|");
  const title = text.slice(0, firstPipe).trim();
  const optionsRaw = text.slice(firstPipe + 1);
  if (title.length === 0) return m.reply("\u26A0\uFE0F Judul nya mana ? kok gak ada !!");
  if (title.length > 200) return m.reply("\u26A0\uFE0F Judul maks 200 karakter!");
  const optionParts = optionsRaw.split("|").map((v) => v.trim()).filter((v) => v);
  if (optionParts.length === 0) return m.reply("\u26A0\uFE0F Minimal 1 opsi!");
  if (optionParts.length > 10) return m.reply("\u26A0\uFE0F Maksimal 10 opsi!");
  const pollVotes = [];
  for (const part of optionParts) {
    if (!part.includes(",")) continue;
    let [name, countStr] = part.split(",").map((v) => v.trim());
    if (!name || !countStr) continue;
    if (name.length > 50) return m.reply(`\u26A0\uFE0F Opsi "${name}" terlalu panjang (maks 50 karakter)!`);
    const voteCount = parseInt(countStr.replace(/\D/g, ""), 10);
    if (isNaN(voteCount) || voteCount < 0) continue;
    pollVotes.push({
      optionName: name,
      optionVoteCount: voteCount
    });
  }
  if (pollVotes.length === 0) {
    return m.reply("\u26A0\uFE0F Tidak ada opsi valid!");
  }
  try {
    await jagoanproject.relayMessage(m.chat, {
      pollResultSnapshotMessage: {
        name: title,
        pollVotes
      }
    }, { quoted: m });
  } catch (e) {
    console.error("FAKE POLL ERROR:", e);
    return m.reply("\u26A0\uFE0F Gagal kirim poll: " + (e.message || e));
  }
};
handler.help = ["fakepoll"];
handler.tags = ["fun"];
handler.command = /^fakepoll$/i;
var fun_fakepolling_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
