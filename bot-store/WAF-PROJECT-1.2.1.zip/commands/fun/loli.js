/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - loli.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_loli_exports = {};
__export(fun_loli_exports, {
  default: () => fun_loli_default
});
module.exports = __toCommonJS(fun_loli_exports);
let handler = async (m, { jagoanproject }) => {
  let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? jagoanproject.user.jid : m.sender;
  jagoanproject.sendFile(m.chat, global.API("https://some-random-api.com", "/canvas/misc/lolice", {
    avatar: await jagoanproject.profilePictureUrl(who, "image").catch((_) => "https://telegra.ph/file/24fa902ead26340f3df2c.png")
  }), "error.png", "*\u{1F694}\u{1F6A8} \u{1D40B}\u{1D40E}\u{1D40B}\u{1D408}\u{1D402}\u{1D40E}\u{1D40D}\u{1D412} like you only belong in jail \u{1F6A8}\u{1F694}*", m);
};
handler.help = ["lolicon"];
handler.tags = ["fun"];
handler.command = /^(lolicon)$/i;
handler.register = true;
handler.limit = true;
var fun_loli_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
