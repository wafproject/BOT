/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - say.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_say_exports = {};
__export(fun_say_exports, {
  default: () => fun_say_default
});
module.exports = __toCommonJS(fun_say_exports);
let handler = async (m, { jagoanproject, text }) => {
  if (!text) return m.reply("\u2757Contoh:\n.say Penyakit andi gila\u{1F974}.");
  const fakeFrom = "0@s.whatsapp.net";
  const fakeText = "@ Group ini disebut.";
  const fakeJid = "status@broadcast";
  await jagoanproject.fakeReply(m.chat, text, fakeFrom, fakeText, fakeJid);
};
handler.help = ["say <teks>"];
handler.tags = ["fun"];
handler.command = /^say$/i;
handler.register = true;
handler.limit = true;
var fun_say_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
