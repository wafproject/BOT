/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - tetyys.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_tetyys_exports = {};
__export(fun_tetyys_exports, {
  default: () => fun_tetyys_default
});
module.exports = __toCommonJS(fun_tetyys_exports);
var import_node_fetch = __toESM(require("node-fetch"));
let handler = async (m, {
  jagoanproject,
  isOwner,
  usedPrefix,
  command,
  args
}) => {
  const lister = [
    "Adult Female #1, American English (TruVoice)",
    "Adult Female #2, American English (TruVoice)",
    "Adult Male #1, American English (TruVoice)",
    "Adult Male #2, American English (TruVoice)",
    "Adult Male #3, American English (TruVoice)",
    "Adult Male #4, American English (TruVoice)",
    "Adult Male #5, American English (TruVoice)",
    "Adult Male #6, American English (TruVoice)",
    "Adult Male #7, American English (TruVoice)",
    "Adult Male #8, American English (TruVoice)",
    "Female Whisper",
    "Male Whisper",
    "Mary",
    "Mary (for Telephone)",
    "Mary in Hall",
    "Mary in Space",
    "Mary in Stadium",
    "Mike",
    "Mike (for Telephone)",
    "Mike in Hall",
    "Mike in Space",
    "Mike in Stadium",
    "RoboSoft Five",
    "RoboSoft Four",
    "RoboSoft One",
    "RoboSoft Six",
    "RoboSoft Three",
    "RoboSoft Two",
    "Sam",
    "BonziBUDDY"
  ];
  const readMore = String.fromCharCode(8206).repeat(4001);
  const query = `\u2022 *Example :* ${usedPrefix + command} [number]|[text]

` + readMore + lister.map((v, index) => `  ${index + 1}. ${v}`).join("\n");
  if (args.length < 1 && (!m.quoted || !m.quoted.text)) {
    throw query;
  }
  const text = args.length >= 1 ? args.join(" ") : m.quoted.text;
  const [atas, bawah, kiri, kanan] = text.split("|");
  if (!atas || !bawah) {
    return m.reply(query);
  }
  jagoanproject.sendMessage(m.chat, { react: { text: "\u{1F552}", key: m.key } });
  try {
    const res = await SayTTS(lister[atas - 1], bawah, kiri || 140, kanan || 157);
    if (res) {
      await jagoanproject.sendMessage(m.chat, {
        audio: res,
        mimetype: "audio/mp4",
        ptt: true,
        waveform: [100, 0, 100, 0, 100, 0, 100]
      }, {
        quoted: m
      });
    }
  } catch (e) {
    await m.reply("Error: " + e.message);
  }
};
handler.help = ["tetyys *<number>|<text>*"];
handler.tags = ["fun"];
handler.command = /^(tetyys)$/i;
handler.register = true;
handler.limit = true;
var fun_tetyys_default = handler;
async function SayTTS(voice, text, pitch, speed) {
  try {
    pitch = parseInt(pitch);
    speed = parseInt(speed);
    const url = `https://tetyys.com/SAPI4/SAPI4?text=${encodeURIComponent(text)}&voice=${encodeURIComponent(voice)}&pitch=${pitch}&speed=${speed}`;
    if (text.length > 4088) {
      throw new Error("Text exceeds the maximum allowed length (1000 characters)");
    }
    const response = await (0, import_node_fetch.default)(url);
    if (!response.ok) throw new Error(`Failed to fetch audio: ${response.statusText}`);
    const buffer = await response.arrayBuffer();
    return Buffer.from(buffer);
  } catch (error) {
    throw error;
  }
}
async function VoiceLimitations(voice) {
  try {
    const url = `https://tetyys.com/SAPI4/VoiceLimitations?voice=${encodeURIComponent(voice)}`;
    const response = await (0, import_node_fetch.default)(url);
    if (!response.ok) throw new Error(`Failed to fetch voice limitations: ${response.statusText}`);
    return await response.json();
  } catch (error) {
    throw error;
  }
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
