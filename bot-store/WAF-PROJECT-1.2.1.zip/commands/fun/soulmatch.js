/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - soulmatch.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_soulmatch_exports = {};
__export(fun_soulmatch_exports, {
  default: () => fun_soulmatch_default
});
module.exports = __toCommonJS(fun_soulmatch_exports);
var import_moment_timezone = __toESM(require("moment-timezone"));
let handler = async (m, { text, jagoanproject }) => {
  if (!text) {
    return m.reply(`\u256D\u2550\u2550\u2550\u276F *BELAHAN JIWA* \u276E\u2550\u2550\u2550
\u2502
\u2502 \u274C Masukkan 2 nama untuk dianalisis!
\u2502 
\u2502 \u{1F4DD} *Format:*
\u2502 .enc nama1|nama2
\u2502
\u2502 \u{1F4CC} *Contoh:*
\u2502 .enc Raiden|Mei
\u2502
\u2570\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550`);
  }
  try {
    const [nama1, nama2] = text.split("|").map((name) => name.trim());
    if (!nama2) {
      return m.reply("\u274C Format salah! Gunakan tanda '|' untuk memisahkan nama\nContoh: .enc Raiden|Mei");
    }
    const generateSoulData = (name, previousElement2) => {
      const numerologyValue = name.toLowerCase().split("").map((char) => char.charCodeAt(0) - 96).reduce((a, b) => a + b, 0) % 9 + 1;
      const elements = ["Api \u{1F525}", "Air \u{1F4A7}", "Tanah \u{1F30D}", "Angin \u{1F32A}\uFE0F", "Petir \u26A1", "Es \u2744\uFE0F", "Cahaya \u2728", "Bayangan \u{1F311}"];
      let element;
      do {
        element = elements[Math.floor(Math.random() * elements.length)];
      } while (element === previousElement2);
      const zodiacSigns = [
        "\u2648 Aries",
        "\u2649 Taurus",
        "\u264A Gemini",
        "\u264B Cancer",
        "\u264C Leo",
        "\u264D Virgo",
        "\u264E Libra",
        "\u264F Scorpio",
        "\u2650 Sagittarius",
        "\u2651 Capricorn",
        "\u2652 Aquarius",
        "\u2653 Pisces"
      ];
      const zodiac = zodiacSigns[Math.floor(Math.random() * zodiacSigns.length)];
      return { numerologyValue, element, zodiac };
    };
    let previousElement = null;
    const soul1 = generateSoulData(nama1, previousElement);
    previousElement = soul1.element;
    const soul2 = generateSoulData(nama2, previousElement);
    const calculateCompatibility = () => Math.floor(Math.random() * 100) + 1;
    const compatibility = calculateCompatibility();
    const soulTypes = [
      "Pemimpin Yang Berani",
      "Penyeimbang Bijaksana",
      "Kreator Ekspresif",
      "Pembangun Solid",
      "Petualang Bebas",
      "Pelindung Setia",
      "Pemikir Mistis",
      "Penakluk Kuat",
      "Humanitarian Murni"
    ];
    const getRandomSoulType = () => soulTypes[Math.floor(Math.random() * soulTypes.length)];
    const getMatchDescription = (score) => {
      if (score >= 90) return "\u{1F4AB} Takdir Sejati";
      if (score >= 80) return "\u2728 Harmoni Sempurna";
      if (score >= 70) return "\u{1F31F} Koneksi Kuat";
      if (score >= 60) return "\u2B50 Potensi Bagus";
      if (score >= 50) return "\u{1F319} Perlu Perjuangan";
      return "\u{1F311} Tantangan Berat";
    };
    const generateSoulReading = (compatibility2) => {
      const readings = [
        compatibility2 >= 90 ? [
          "\u2502 \u2728 Jiwa kalian memiliki koneksi yang sangat",
          "\u2502    istimewa dan langka",
          "\u2502 \u{1F31F} Takdir telah merencanakan pertemuan ini",
          "\u2502 \u{1F4AB} Resonansi jiwa kalian menciptakan",
          "\u2502    harmoni sempurna"
        ] : compatibility2 >= 80 ? [
          "\u2502 \u{1F31F} Ada chemistry yang sangat kuat di antara",
          "\u2502    kalian",
          "\u2502 \u2728 Jiwa kalian saling melengkapi dengan",
          "\u2502    cara yang unik",
          "\u2502 \u{1F4AB} Pertemuan kalian membawa energi positif"
        ] : compatibility2 >= 70 ? [
          "\u2502 \u{1F319} Potensi hubungan yang dalam dan berarti",
          "\u2502 \u2728 Perbedaan kalian justru menciptakan",
          "\u2502    harmoni",
          "\u2502 \u{1F4AB} Ada pelajaran berharga dalam pertemuan",
          "\u2502    ini"
        ] : compatibility2 >= 60 ? [
          "\u2502 \u{1F31F} Butuh waktu untuk saling memahami",
          "\u2502 \u{1F4AB} Setiap tantangan akan memperkuat ikatan",
          "\u2502 \u2728 Fokus pada hal positif dari perbedaan",
          "\u2502    kalian"
        ] : compatibility2 >= 50 ? [
          "\u2502 \u{1F319} Perlu usaha ekstra untuk harmonisasi",
          "\u2502 \u2728 Tantangan akan menguji kesungguhan",
          "\u2502 \u{1F4AB} Komunikasi jadi kunci utama hubungan"
        ] : [
          "\u2502 \u{1F311} Perbedaan yang signifikan dalam energi",
          "\u2502    jiwa",
          "\u2502 \u2728 Butuh banyak adaptasi dan pengertian",
          "\u2502 \u{1F4AB} Setiap hubungan punya maksud tersendiri"
        ]
      ];
      return readings[0].join("\n");
    };
    const caption = `\u256D\u2550\u2550\u2550\u276F *BELAHAN JIWA* \u276E\u2550\u2550\u2550
\u2502
\u2502 \u{1F464} *${nama1}*
\u2502 \u251C \u{1F52E} Soul Type: ${getRandomSoulType()}
\u2502 \u251C \u{1F31F} Element: ${soul1.element}
\u2502 \u2514 \u{1F3AF} Zodiac: ${soul1.zodiac}
\u2502
\u2502 \u{1F464} *${nama2}*
\u2502 \u251C \u{1F52E} Soul Type: ${getRandomSoulType()}
\u2502 \u251C \u{1F31F} Element: ${soul2.element}
\u2502 \u2514 \u{1F3AF} Zodiac: ${soul2.zodiac}
\u2502
\u2502 \u{1F4AB} *COMPATIBILITY*
\u2502 \u251C \u{1F4CA} Score: ${compatibility}%
\u2502 \u2514 \u{1F3AD} Status: ${getMatchDescription(compatibility)}
\u2502
\u2502 \u{1F52E} *Soul Reading*
${generateSoulReading(compatibility)}
\u2502
\u2570\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550

\u{1F4C5} *Analysis Date:* ${(0, import_moment_timezone.default)().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`;
    return m.reply(caption);
  } catch (error) {
    console.error("Error in soulmatch command:", error);
    return m.reply(`\u256D\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
\u2502 \u274C *Terjadi Kesalahan*
\u2502 Mohon coba beberapa saat lagi
\u2570\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550`);
  }
};
handler.help = ["soulmatch"];
handler.tags = ["fun"];
handler.command = /^soulmatch$/i;
handler.group = true;
handler.limit = 1;
handler.register = true;
var fun_soulmatch_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
