/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - soundmeme.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_soundmeme_exports = {};
__export(fun_soundmeme_exports, {
  default: () => fun_soundmeme_default
});
module.exports = __toCommonJS(fun_soundmeme_exports);
var import_axios = __toESM(require("axios"));
var cheerio = __toESM(require("cheerio"));
let handler = async (m, {
  jagoanproject,
  text,
  command
}) => {
  const baseUrl = "https://www.myinstants.com/en/search/?name=";
  if (command === "soundmeme-listnama") {
    if (!text) {
      return m.reply("Silakan masukkan nama suara untuk DICARI.");
    }
    const url = `${baseUrl}${encodeURIComponent(text)}`;
    try {
      const {
        data
      } = await import_axios.default.get(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }
      });
      const $ = cheerio.load(data);
      const instants = $("div.instant");
      if (instants.length === 0) {
        return m.reply("Suara tidak ditemukan dengan nama tersebut.");
      }
      let list = "";
      instants.each((index, element) => {
        const soundName = $(element).find(".instant-link").text().trim();
        list += `${index + 1}. ${soundName}
`;
      });
      m.reply(`noh ada:

\u2022 ${list || "Tidak ada sound meme."}`);
    } catch (err) {
      console.error(err);
      m.reply("Terjadi kesalahan saat mengambil suara.");
    }
  } else if (command === "soundmeme-random") {
    const url = "https://www.myinstants.com/en/index/id/";
    try {
      const {
        data
      } = await import_axios.default.get(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }
      });
      const $ = cheerio.load(data);
      const randomInstant = $("div.instant").eq(Math.floor(Math.random() * $("div.instant").length));
      const audioUrl = `https://www.myinstants.com${randomInstant.find("button").attr("onclick").match(/'([^']+)'/)[1]}`;
      const response = await (0, import_axios.default)({
        url: audioUrl,
        method: "GET",
        responseType: "arraybuffer"
      });
      const contentType = response.headers["content-type"];
      let mimetype = "audio/mpeg";
      if (contentType.includes("mp3")) {
        mimetype = "audio/mp3";
      } else if (contentType.includes("ogg")) {
        mimetype = "audio/ogg";
      } else if (contentType.includes("wav")) {
        mimetype = "audio/wav";
      }
      await jagoanproject.sendMessage(m.chat, {
        audio: response.data,
        mimetype,
        ptt: false
      }, {
        quoted: m
      });
    } catch (err) {
      console.error(err);
      m.reply("Terjadi kesalahan saat mengambil suara.");
    }
  } else if (command === "soundmeme-search") {
    if (!text) {
      return m.reply("nama?.");
    }
    const url = `${baseUrl}${encodeURIComponent(text)}`;
    try {
      const {
        data
      } = await import_axios.default.get(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }
      });
      const $ = cheerio.load(data);
      const instants = $("div.instant");
      if (instants.length === 0) {
        return m.reply("Suara tidak ditemukan dengan nama tersebut.");
      }
      let closestMatch = "";
      let bestMatchScore = 0;
      instants.each((index, element) => {
        const soundName = $(element).find(".instant-link").text().trim();
        const score = soundName.toLowerCase().includes(text.toLowerCase()) ? 1 : 0;
        if (score > bestMatchScore) {
          bestMatchScore = score;
          closestMatch = soundName;
        }
      });
      if (closestMatch) {
        const audioUrl = `https://www.myinstants.com${$("div.instant").find("button").attr("onclick").match(/'([^']+)'/)[1]}`;
        const response = await (0, import_axios.default)({
          url: audioUrl,
          method: "GET",
          responseType: "arraybuffer"
        });
        const contentType = response.headers["content-type"];
        let mimetype = "audio/mpeg";
        if (contentType.includes("mp3")) {
          mimetype = "audio/mp3";
        } else if (contentType.includes("ogg")) {
          mimetype = "audio/ogg";
        } else if (contentType.includes("wav")) {
          mimetype = "audio/wav";
        }
        await jagoanproject.sendMessage(m.chat, {
          audio: response.data,
          mimetype,
          ptt: false
        }, {
          quoted: m
        });
      } else {
        m.reply("Tidak ada suara yang mendekati nama yang di cari.");
      }
    } catch (err) {
      console.error(err);
      m.reply("Terjadi kesalahan saat mengambil suara.");
    }
  }
};
handler.command = /^soundmeme/i;
handler.help = ["soundmeme-listnama nama", "soundmeme-random", "soundmeme-search nama"];
handler.tags = ["fun"];
handler.limit = true;
handler.register = true;
var fun_soundmeme_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
