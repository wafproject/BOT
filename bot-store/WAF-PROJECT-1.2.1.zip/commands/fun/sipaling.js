/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - sipaling.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_sipaling_exports = {};
__export(fun_sipaling_exports, {
  default: () => fun_sipaling_default
});
module.exports = __toCommonJS(fun_sipaling_exports);
const pickRandom = (list) => {
  return list[Math.floor(Math.random() * list.length)];
};
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const handler = async (m, { jagoanproject, text, groupMetadata, usedPrefix, command }) => {
  if (!text) throw `Contoh:
${usedPrefix + command} Alay`;
  await delay(5e3);
  const em = ["\u{1F976}", "\u{1F928}", "\u{1F5FF}", "\u{1F914}", "\u{1F62B}", "\u{1F92B}", "\u{1F974}", "\u{1F923}", "\u{1F60A}", "\u{1F60D}"];
  const toM = (a2) => "@" + a2.split("@")[0];
  const ps = groupMetadata.participants.map((v) => v.id);
  const a = pickRandom(ps);
  const am = pickRandom(em);
  jagoanproject.reply(m.chat, `Sii Paling *${text}* Adalah ${toM(a)} ${am}`, m, { mentions: [a] });
};
handler.help = ["sipaling"];
handler.command = ["sipaling"];
handler.tags = ["fun"];
handler.limit = 3;
handler.group = true;
handler.register = true;
var fun_sipaling_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
