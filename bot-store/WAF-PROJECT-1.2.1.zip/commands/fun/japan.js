/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - japan.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_japan_exports = {};
__export(fun_japan_exports, {
  default: () => fun_japan_default
});
module.exports = __toCommonJS(fun_japan_exports);
let handler = (m, { text, usedPrefix, command }) => {
  let teks = text || m.quoted && m.quoted.text || false;
  if (!teks) throw "_Masukkan teks!_\n\nContoh\n" + usedPrefix + command + " " + global.author;
  let japan = teks.replace(/[a-z]/gi, (v) => {
    switch (v.toLowerCase()) {
      case "a":
        return "ka";
      case "b":
        return "zu";
      case "c":
        return "mi";
      case "d":
        return "te";
      case "e":
        return "ku";
      case "f":
        return "lu";
      case "g":
        return "ji";
      case "h":
        return "ri";
      case "i":
        return "ki";
      case "j":
        return "zus";
      case "k":
        return "me";
      case "l":
        return "ta";
      case "m":
        return "rin";
      case "n":
        return "to";
      case "o":
        return "mo";
      case "p":
        return "no";
      case "q":
        return "ke";
      case "r":
        return "shi";
      case "s":
        return "ari";
      case "t":
        return "chi";
      case "u":
        return "do";
      case "v":
        return "ru";
      case "w":
        return "mei";
      case "x":
        return "na";
      case "y":
        return "fu";
      case "z":
        return "zi";
    }
  });
  m.reply(`Nama jepang:

*${japan[0].toUpperCase() + japan.substring(1)}*`);
};
handler.tags = ["fun"];
handler.command = ["japan"];
handler.help = ["japan"];
handler.register = true;
handler.limit = true;
var fun_japan_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
