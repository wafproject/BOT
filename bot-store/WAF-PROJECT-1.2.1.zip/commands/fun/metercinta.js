/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - metercinta.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_metercinta_exports = {};
__export(fun_metercinta_exports, {
  default: () => fun_metercinta_default
});
module.exports = __toCommonJS(fun_metercinta_exports);
var import_node_fetch = __toESM(require("node-fetch"));
const getThumb = () => {
  return "https://telegra.ph/file/bf9bcc6db5c112c772a80.jpg";
};
let toM = (a) => "@" + a.split("@")[0];
let handler = async (m, {
  jagoanproject,
  groupMetadata,
  usedPrefix,
  text,
  args,
  command
}) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? jagoanproject.user.jid : m.sender;
  let pp = await jagoanproject.profilePictureUrl(who).catch((_) => getThumb());
  let name = await jagoanproject.getName(who);
  if (command == "menikah" && groupMetadata) {
    let ps = groupMetadata.participants.map((v) => v.id);
    let a = ps[Math.floor(Math.random() * ps.length)];
    let b;
    do
      b = ps[Math.floor(Math.random() * ps.length)];
    while (b === a);
    m.reply(`*${toM(a)}, KAU HARUS MENIKAHI ${toM(b)}, KAMU PASTI AKAN MENJADI PASANGAN YANG BAIK \u{1F493}*`, null, {
      mentions: [a, b]
    });
  }
  if (command == "metercinta") {
    if (!text) throw `Contoh penggunaan ${usedPrefix}${command} terserah`;
    jagoanproject.reply(m.chat, `
*\u2764\uFE0F\u2764\uFE0F METER CINTA \u2764\uFE0F\u2764\uFE0F*
*cinta dari ${text} itu untuk kamu* *${Math.floor(Math.random() * 100)}%* *dari 100%*
*kamu harus memintanya untuk menjadi pacar kamu?*
`.trim(), m, m.mentionedJid ? {
      contextInfo: {
        mentionedJid: m.mentionedJid
      }
    } : {});
  }
  if (command == "bertanya") {
    if (!text) throw `Contoh penggunaan ${usedPrefix}${command} haruskah saya makan?`;
    m.reply(`
*\u2049\uFE0F PERTANYAAN \u2049\uFE0F*
 
*PERTANYAAN:* ${text}
*TANGGAPAN:* ${["Ya", "Mungkin ya", "Mungkin", "Mungkin tidak", "Tidak", "Tidak mungkin"][Math.floor(Math.random() * 6)]}
`.trim(), null, m.mentionedJid ? {
      mentions: m.mentionedJid
    } : {});
  }
};
handler.command = handler.help = ["menikah", "metercinta", "bertanya"];
handler.tags = ["fun"];
handler.register = true;
handler.limit = true;
var fun_metercinta_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
