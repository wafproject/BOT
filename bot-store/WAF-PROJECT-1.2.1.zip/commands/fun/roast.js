/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - roast.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_roast_exports = {};
__export(fun_roast_exports, {
  default: () => fun_roast_default
});
module.exports = __toCommonJS(fun_roast_exports);
var import_axios = __toESM(require("axios"));
const handler = async (m, {
  jagoanproject,
  text
}) => {
  if (!text) {
    return m.reply("nama?");
  }
  try {
    const {
      data
    } = await import_axios.default.post(`https://github-roaster.programordie.workers.dev/${text}`);
    const roastMessage = data.roast || "Wah, kayaknya aku kehabisan kata buat nge-roast dia.";
    await jagoanproject.sendMessage(m.chat, {
      text: `\u{1F525} *Roasting Time!* \u{1F525}

${roastMessage}`
    }, {
      quoted: m
    });
  } catch (error) {
    console.error("Error:", error);
    await m.reply("Yah, ada error nih. Coba lagi deh, mungkin codenya lagi ngambek.");
  }
};
handler.help = ["roast nama"];
handler.tags = ["fun"];
handler.command = /^(roast|roastme)$/i;
handler.register = true;
handler.limit = true;
var fun_roast_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
