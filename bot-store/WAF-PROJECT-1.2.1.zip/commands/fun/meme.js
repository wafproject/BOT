/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - meme.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_meme_exports = {};
__export(fun_meme_exports, {
  default: () => fun_meme_default
});
module.exports = __toCommonJS(fun_meme_exports);
var import_axios = __toESM(require("axios"));
async function lahelu(query) {
  try {
    const { data } = await import_axios.default.get("https://lahelu.com/api/post/get-search", {
      params: { query },
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36",
        Accept: "application/json, text/plain, */*",
        "Sec-Ch-Ua": '"Chromium";v="140", "Not=A?Brand";v="24", "Google Chrome";v="140"'
      }
    });
    if (!data.postInfos) return [];
    const posts = data.postInfos.map((info) => {
      const contents = info.content?.map((c) => {
        let key = "";
        if (c.type === 0 || c.type === 3) key = "image";
        if (c.type === 1 || c.type === 4) key = "video";
        return { type: c.type, [key]: c.value };
      });
      const ui = info.userInfo;
      return {
        idUser: info.userId,
        idPost: info.postId,
        title: info.title,
        comments: info.totalComments,
        createTime: info.createTime,
        type: info.type,
        hashtags: info.hashtags,
        ageTime: info.ageTime,
        content: contents,
        userInfo: {
          userId: ui.userId,
          authId: ui.authId,
          avatar: info.userAvatar,
          username: ui.username,
          email: ui.email,
          description: ui.description,
          totalUpv: ui.totalUpvotes,
          totalDownv: ui.totalDownvotes,
          totalPost: ui.totalPosts,
          upVotesMap: ui.upvotesMap
        }
      };
    });
    return posts;
  } catch (error) {
    throw error;
  }
}
let handler = async (m, { jagoanproject, text }) => {
  if (!text) throw `Masukkan kata kunci!

Contoh: .meme jokowi`;
  try {
    let results = await lahelu(text);
    if (!results || results.length === 0) throw `Meme tidak ditemukan!`;
    let selected = results[Math.floor(Math.random() * results.length)];
    let caption = `*${selected.title || "Meme"}*
\u{1F464} ${selected.userInfo?.username || "-"}
\u{1F4AC} ${selected.comments} komentar
\u{1F552} ${selected.ageTime || ""}`;
    let content = selected.content?.[0];
    if (!content) throw `Konten kosong!`;
    if (content.image) {
      await jagoanproject.sendMessage(m.chat, { image: { url: content.image }, caption }, { quoted: m });
    } else if (content.video) {
      await jagoanproject.sendMessage(m.chat, { video: { url: content.video }, caption }, { quoted: m });
    } else {
      throw `Konten tidak valid!`;
    }
  } catch (e) {
    console.error(e);
    throw `Error: ${e.message || e}`;
  }
};
handler.command = /^(meme)$/i;
handler.tags = ["fun"];
handler.help = ["meme <query>"];
handler.limit = true;
handler.register = true;
var fun_meme_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
