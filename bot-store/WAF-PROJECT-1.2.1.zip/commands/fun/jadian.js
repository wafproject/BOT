/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - jadian.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_jadian_exports = {};
__export(fun_jadian_exports, {
  default: () => fun_jadian_default
});
module.exports = __toCommonJS(fun_jadian_exports);
let toM = (a) => "@" + a.split("@")[0];
function handler(m, { jagoanproject, groupMetadata }) {
  let ps = groupMetadata.participants.map((v) => v.jid || jagoanproject.decodeJid(v.id, groupMetadata));
  let a, b;
  a = m.mentionedJid && m.mentionedJid[0] ? jagoanproject.decodeJid(m.mentionedJid[0], groupMetadata) : m.fromMe ? jagoanproject.user.jid : jagoanproject.decodeJid(m.sender, groupMetadata);
  do {
    b = ps[Math.floor(Math.random() * ps.length)];
  } while (b === a || !b);
  if (!a.endsWith("@s.whatsapp.net") || !b.endsWith("@s.whatsapp.net")) {
    console.log("Debug: Invalid JID - a:", a, "b:", b);
    return jagoanproject.reply(m.chat, "\u{1F6A9} Pengguna tidak valid!", m);
  }
  console.log("Debug: a:", a, "b:", b, "m.mentionedJid:", m.mentionedJid, "m.sender:", m.sender);
  jagoanproject.reply(m.chat, `${toM(a)} \u2764\uFE0F ${toM(b)}`, null, {
    mentions: [a, b]
  });
}
handler.help = ["jadian [@tag]"];
handler.tags = ["fun"];
handler.command = ["jadian"];
handler.limit = true;
handler.group = true;
handler.register = true;
var fun_jadian_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
