/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - menfess_ans.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_menfess_ans_exports = {};
__export(fun_menfess_ans_exports, {
  default: () => fun_menfess_ans_default
});
module.exports = __toCommonJS(fun_menfess_ans_exports);
const delay = (time) => new Promise((res) => setTimeout(res, time));
let handler = (m) => m;
handler.all = async function(m) {
  if (!m.chat.endsWith("@s.whatsapp.net")) return true;
  this.menfess = this.menfess ? this.menfess : {};
  let mf = Object.values(this.menfess).find((v) => v.status === false && v.penerima == m.sender);
  if (!mf) return true;
  console.log({ text: m.text });
  if ((m.text === "BALAS PESAN" || m.text === "") && m.quoted.mtype == "buttonMessage") return m.reply("Silahkan Ketik Pesan Balasan Mu");
  let txt = `Hai kak @${mf.dari.split("@")[0]}, Kamu Menerima Pesan Balasan

Pesan Kamu: 
${mf.pesan}

Pesan Balasannya: 
${m.text}
`.trim();
  await this.reply(mf.dari, txt, null).then(() => {
    m.reply("Berhasil mengirim balasan!");
    delay(2e3);
    delete this.menfess[mf.id];
    return true;
  });
  return true;
};
handler.register = true;
handler.limit = true;
var fun_menfess_ans_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
