/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - repeat.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_repeat_exports = {};
__export(fun_repeat_exports, {
  default: () => fun_repeat_default
});
module.exports = __toCommonJS(fun_repeat_exports);
let handler = async (m, { jagoanproject, text, mentionedJid }) => {
  let who, displayName;
  if (m.mentionedJid && m.mentionedJid[0]) {
    who = m.mentionedJid[0];
    displayName = `@${who.split("@")[0]}`;
  } else {
    who = null;
    displayName = "";
  }
  if (m.text.match(/^[!.]repeat\s/i)) {
    if (!text || text.trim().length === 0) {
      return jagoanproject.reply(m.chat, "\u26A0\uFE0F Harap masukkan jumlah pengulangan dan teks untuk diulang. Contoh: .repeat 50 @taguser teks\n\n> Maksimal 500", m, { contextInfo: { mentionedJid: who ? [who] : [] } });
    }
    let args = text.split(" ");
    let count = parseInt(args.shift());
    let repeatText = args.join(" ");
    if (who) {
      repeatText = repeatText.replace(/@\d+(@lid)?/g, "").trim();
    }
    if (isNaN(count) || count <= 0) {
      return jagoanproject.reply(m.chat, "\u26A0\uFE0F Jumlah harus angka positif!", m, { contextInfo: { mentionedJid: who ? [who] : [] } });
    }
    if (count > 500) count = 500;
    let repeatedMessage = Array(count).fill(`${displayName}${displayName && repeatText ? " " : ""}${repeatText}`).join("\n");
    await jagoanproject.reply(m.chat, repeatedMessage, m, { contextInfo: { mentionedJid: who ? [who] : [] } });
  }
  if (m.text.match(/^[!.]repeatscroll\s/i)) {
    if (!text) return jagoanproject.reply(m.chat, "\u26A0\uFE0F Masukkan teks untuk scrolling! Contoh: .repeatscroll @taguser teks\n\n> Maksimal 20 karakter", m, { contextInfo: { mentionedJid: who ? [who] : [] } });
    let scrollText = text.trim();
    if (who) {
      scrollText = scrollText.replace(/@\d+(@lid)?/g, "").trim();
    }
    if (scrollText.length > 20) return jagoanproject.reply(m.chat, "\u26A0\uFE0F Teks tidak boleh lebih dari 20 karakter (termasuk spasi)!", m, { contextInfo: { mentionedJid: who ? [who] : [] } });
    let scrollEffect = [];
    const maxCharsPerMessage = 65536;
    const maxSpaces = 20;
    const countChars = (lines) => lines.join("\n").length + lines.length - 1;
    for (let i = 0; i < 23; i++) {
      scrollEffect.push(`${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    for (let i = 1; i <= maxSpaces; i++) {
      scrollEffect.push(" ".repeat(i) + `${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    for (let i = maxSpaces; i >= 0; i--) {
      scrollEffect.push(" ".repeat(i) + `${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    for (let i = 1; i <= maxSpaces; i++) {
      scrollEffect.push(" ".repeat(i) + `${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    for (let i = maxSpaces; i >= 0; i--) {
      scrollEffect.push(" ".repeat(i) + `${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    let chars = scrollText.split("");
    let currentText = scrollText;
    for (let i = chars.length - 1; i >= 0; i--) {
      let spaces = " ".repeat(chars.length - i - 1);
      let shiftedText2 = currentText.slice(0, i) + spaces + currentText.slice(i);
      scrollEffect.push(`${displayName}${displayName && shiftedText2 ? " " : ""}${shiftedText2}`);
    }
    for (let j = 0; j < 3; j++) {
      let shiftedText2 = scrollText;
      for (let i = 1; i <= scrollText.length; i++) {
        scrollEffect.push(`${displayName}${displayName && shiftedText2 ? " " : ""}${shiftedText2.slice(i) + shiftedText2.slice(0, i)}`);
      }
      scrollEffect.push(`${displayName}${displayName && shiftedText2 ? " " : ""}${shiftedText2}`);
    }
    for (let i = 1; i <= maxSpaces; i++) {
      scrollEffect.push(" ".repeat(i) + `${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    for (let i = maxSpaces; i >= 0; i--) {
      scrollEffect.push(" ".repeat(i) + `${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    let words = scrollText.split(" ");
    for (let i = 0; i < words.length - 1; i++) {
      let shiftedText2 = words.slice(0, words.length - 1 - i).join(" ") + " ".repeat(i + 1) + words.slice(words.length - 1 - i).join(" ");
      scrollEffect.push(`${displayName}${displayName && shiftedText2 ? " " : ""}${shiftedText2}`);
    }
    for (let i = words.length - 2; i >= 0; i--) {
      let shiftedText2 = words.slice(0, words.length - 1 - i).join(" ") + " ".repeat(i + 1) + words.slice(words.length - 1 - i).join(" ");
      scrollEffect.push(`${displayName}${displayName && shiftedText2 ? " " : ""}${shiftedText2}`);
    }
    for (let i = 0; i < words.length - 1; i++) {
      let shiftedText2 = words.slice(0, words.length - 1 - i).join(" ") + " ".repeat(i + 1) + words.slice(words.length - 1 - i).join(" ");
      scrollEffect.push(`${displayName}${displayName && shiftedText2 ? " " : ""}${shiftedText2}`);
    }
    for (let i = words.length - 2; i >= 0; i--) {
      let shiftedText2 = words.slice(0, words.length - 1 - i).join(" ") + " ".repeat(i + 1) + words.slice(words.length - 1 - i).join(" ");
      scrollEffect.push(`${displayName}${displayName && shiftedText2 ? " " : ""}${shiftedText2}`);
    }
    let shiftedText = scrollText;
    for (let i = 1; i <= scrollText.length; i++) {
      scrollEffect.push(`${displayName}${displayName && shiftedText ? " " : ""}${shiftedText.slice(i) + shiftedText.slice(0, i)}`);
    }
    scrollEffect.push(`${displayName}${displayName && shiftedText ? " " : ""}${shiftedText}`);
    for (let i = 0; i < 35; i++) {
      scrollEffect.push(`${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
    }
    let singleCycle = scrollEffect.slice();
    let fullOutput = [];
    let totalChars = 0;
    let cycleCount = 0;
    const maxCycles = 10;
    while (totalChars < maxCharsPerMessage && cycleCount < maxCycles) {
      fullOutput.push(...singleCycle);
      totalChars = countChars(fullOutput);
      cycleCount++;
    }
    while (totalChars > maxCharsPerMessage) {
      fullOutput.pop();
      totalChars = countChars(fullOutput);
    }
    while (totalChars + scrollText.length + (displayName ? displayName.length + 1 : 0) + 1 <= maxCharsPerMessage) {
      fullOutput.push(`${displayName}${displayName && scrollText ? " " : ""}${scrollText}`);
      totalChars += scrollText.length + (displayName ? displayName.length + 1 : 0) + 1;
    }
    let messages = [];
    let currentMessage = [];
    let currentChars = 0;
    for (let line of fullOutput) {
      let lineChars = line.length + 1;
      if (currentChars + lineChars > maxCharsPerMessage) {
        messages.push(currentMessage.join("\n"));
        currentMessage = [line];
        currentChars = lineChars;
      } else {
        currentMessage.push(line);
        currentChars += lineChars;
      }
    }
    if (currentMessage.length > 0) {
      messages.push(currentMessage.join("\n"));
    }
    for (let i = 0; i < messages.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      await jagoanproject.reply(m.chat, messages[i], m, { contextInfo: { mentionedJid: who ? [who] : [] } });
    }
  }
};
handler.help = ["repeat <jumlah> <teks> [@tag]", "repeatscroll <teks> [@tag]"];
handler.tags = ["fun"];
handler.command = /^(repeat|repeatscroll)$/i;
handler.register = true;
handler.limit = true;
var fun_repeat_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
