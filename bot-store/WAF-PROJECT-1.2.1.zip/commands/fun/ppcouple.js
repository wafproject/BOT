/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - ppcouple.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_ppcouple_exports = {};
__export(fun_ppcouple_exports, {
  default: () => fun_ppcouple_default
});
module.exports = __toCommonJS(fun_ppcouple_exports);
var __color_1 = __toESM(require("../../lib/jagoan/lib/color.js"));
var __zapo_2 = __toESM(require("../../lib/jagoan/simple.js"));
var import_fs = __toESM(require("fs"));
var import_node_fetch = __toESM(require("node-fetch"));
var import_moment_timezone = __toESM(require("moment-timezone"));
var import_module = require("module");
const require2 = (0, import_module.createRequire)(__jpImportMetaUrl);
const axios = require2("axios");
const { color } = __color_1;
const { MessageType } = __zapo_2;
let handler = async (m, { jagoanproject, command }) => {
  const time = import_moment_timezone.default.tz("Asia/Jakarta").format("HH:mm:ss");
  let username = jagoanproject.getName(m.sender);
  console.log(color("[COMMAND]", "pink"), color(command, "yellow"), color(time, "white"), color("Name:", "yellow"), color(username, "cyan"), color("Number:", "yellow"), color(m.sender.split("@")[0], "cyan"));
  let data = import_fs.default.readFileSync("./lib/ppcouple.js");
  let jsonData = JSON.parse(data);
  let randIndex = Math.floor(Math.random() * jsonData.length);
  let json = jsonData[randIndex];
  let randCowo = await getBuffer(json.cowo);
  jagoanproject.sendMessage(m.chat, { image: randCowo, caption: "*Cowo*", quoted: m });
  let randCewe = await getBuffer(json.cewe);
  jagoanproject.sendMessage(m.chat, { image: randCewe, caption: "*Cewe*", quoted: m });
};
handler.help = ["ppcouple"];
handler.tags = ["fun"];
handler.command = /^ppcouple|ppcp$/i;
handler.owner = false;
handler.limit = true;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.register = true;
var fun_ppcouple_default = handler;
const fetchJson = (url, options) => new Promise(async (resolve, reject) => {
  (0, import_node_fetch.default)(url, options).then((response) => response.json()).then((json) => {
    resolve(json);
  }).catch((err) => {
    reject(err);
  });
});
const getBuffer = async (url, options) => {
  try {
    options ? options : {};
    const res = await axios({
      method: "get",
      url,
      headers: {
        "DNT": 1,
        "User-Agent": "GoogleBot",
        "Upgrade-Insecure-Request": 1
      },
      ...options,
      responseType: "arraybuffer"
    });
    return res.data;
  } catch (e) {
    console.log(`Error : ${e}`);
  }
};

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
