/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - pick.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_pick_exports = {};
__export(fun_pick_exports, {
  default: () => fun_pick_default
});
module.exports = __toCommonJS(fun_pick_exports);
let handler = async (m, { text, args, participants, command }) => {
  if (args[0] < 0, args.length < 2) throw "Example: #pick 15 gay";
  let users = participants.map((u) => u.jid);
  m.reply(`*\u{1F389} Kamu Ter${command} sebagai ${text.replace(args, "").trimStart()}*
    
${new Array(Math.min(users.length, args[0])).fill().map(() => {
    let index = Math.floor(Math.random() * users.length);
    return `@${users.splice(index, 1)}`;
  }).join`\n`.replace(/@s.whatsapp.net/g, "")}`);
};
handler.help = ["pick <jumlah> <teks>"];
handler.tags = ["fun"];
handler.command = /^pick/i;
handler.register = true;
handler.limit = true;
var fun_pick_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
