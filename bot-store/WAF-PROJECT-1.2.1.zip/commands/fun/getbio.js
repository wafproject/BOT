/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - getbio.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_getbio_exports = {};
__export(fun_getbio_exports, {
  default: () => fun_getbio_default
});
module.exports = __toCommonJS(fun_getbio_exports);
let handler = async (m, { jagoanproject, text, command }) => {
  try {
    let who;
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;
    else who = m.quoted.sender ? m.quoted.sender : m.sender;
    let bio = await jagoanproject.fetchStatus(who);
    m.reply(bio.status);
  } catch {
    if (text) return jagoanproject.reply(m.chat, `bio is private!`, m);
    else try {
      let who = m.quoted ? m.quoted.sender : m.sender;
      let bio = await jagoanproject.fetchStatus(who);
      jagoanproject.reply(m.chat, bio.status, m);
    } catch {
      return jagoanproject.reply(m.chat, `bio is private!`, m);
    }
  }
};
handler.help = ["getbio *<@user/reply>*"];
handler.tags = ["fun"];
handler.command = /^(getb?io)$/i;
handler.register = true;
handler.limit = true;
var fun_getbio_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
