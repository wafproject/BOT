/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - zodiac.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_zodiac_exports = {};
__export(fun_zodiac_exports, {
  default: () => fun_zodiac_default
});
module.exports = __toCommonJS(fun_zodiac_exports);
let handler = (m, { usedPrefix, command, text }) => {
  if (!text) throw `\u2022 *Example :* ${usedPrefix + command} 2002 02 25`;
  const date = new Date(text);
  if (date == "Invalid Date") throw date;
  const d = /* @__PURE__ */ new Date();
  const [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()];
  const birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()];
  const zodiac = getZodiac(birth[1], birth[2]);
  const ageD = new Date(d - date);
  const age = ageD.getFullYear() - new Date(1970, 0, 1).getFullYear();
  const birthday = [tahun + (+new Date(1970, bulan - 1, tanggal) > +new Date(1970, birth[1] - 1, birth[2])), ...birth.slice(1)];
  const cekusia = bulan === birth[1] && tanggal === birth[2] ? `Selamat ulang tahun yang ke-${age} \uFFFD\u620A` : age;
  const teks = `
Lahir : ${birth.join("-")}
Ultah Mendatang : ${birthday.join("-")}
Usia : ${cekusia}
Zodiak : ${zodiac}
`.trim();
  m.reply(teks);
};
handler.help = ["zodiac *2002 02 25*"];
handler.tags = ["fun"];
handler.command = /^zodia[kc]$/i;
handler.register = true;
handler.limit = true;
var fun_zodiac_default = handler;
const zodiak = [
  ["Capricorn", new Date(1970, 0, 1)],
  ["Aquarius", new Date(1970, 0, 20)],
  ["Pisces", new Date(1970, 1, 19)],
  ["Aries", new Date(1970, 2, 21)],
  ["Taurus", new Date(1970, 3, 21)],
  ["Gemini", new Date(1970, 4, 21)],
  ["Cancer", new Date(1970, 5, 22)],
  ["Leo", new Date(1970, 6, 23)],
  ["Virgo", new Date(1970, 7, 23)],
  ["Libra", new Date(1970, 8, 23)],
  ["Scorpio", new Date(1970, 9, 23)],
  ["Sagittarius", new Date(1970, 10, 22)],
  ["Capricorn", new Date(1970, 11, 22)]
].reverse();
function getZodiac(month, day) {
  let d = new Date(1970, month - 1, day);
  return zodiak.find(([_, _d]) => d >= _d)[0];
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
