/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - couple.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_couple_exports = {};
__export(fun_couple_exports, {
  default: () => fun_couple_default
});
module.exports = __toCommonJS(fun_couple_exports);
var import_node_fetch = __toESM(require("node-fetch"));
const handler = async (m, {
  jagoanproject
}) => {
  const fetchJson = async (url2) => {
    const response = await (0, import_node_fetch.default)(url2);
    if (!response.ok) throw new Error(`Failed to fetch ${url2}: ${response.statusText}`);
    return response.json();
  };
  const url = "https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json";
  try {
    await jagoanproject.sendMessage(m.chat, {
      react: {
        text: "\u23F3",
        key: m.key
      }
    });
    const data = await fetchJson(url);
    const randomCouple = data[Math.floor(Math.random() * data.length)];
    await jagoanproject.sendMessage(
      m.chat,
      {
        image: {
          url: randomCouple.male
        },
        caption: "\u{1F466} *Male*"
      },
      {
        quoted: m
      }
    );
    await jagoanproject.sendMessage(
      m.chat,
      {
        image: {
          url: randomCouple.female
        },
        caption: "\u{1F469} *Female*"
      },
      {
        quoted: m
      }
    );
  } catch (error) {
    await jagoanproject.sendMessage(m.chat, {
      text: `${error.message}`
    }, {
      quoted: m
    });
  }
};
handler.help = ["couple"];
handler.tags = ["fun"];
handler.command = /^(couple)$/i;
handler.limit = true;
handler.register = true;
var fun_couple_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
