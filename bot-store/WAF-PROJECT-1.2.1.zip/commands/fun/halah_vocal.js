/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun-halah_vocal.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_halah_vocal_exports = {};
__export(fun_halah_vocal_exports, {
  default: () => fun_halah_vocal_default
});
module.exports = __toCommonJS(fun_halah_vocal_exports);
let handler = async (m, { command, text }) => {
  let ter = command[1].toLowerCase();
  let txt = m.quoted && m.quoted.text ? m.quoted.text : text ? text : "";
  if (!txt) {
    return m.reply(`\u2022 *Cara penggunaan:* 
Ketik \`${command} <teks>\` atau reply pesan dengan \`${command}\`
Contoh: \`${command} saya suka coding\` atau reply pesan dengan \`${command}\``);
  }
  let result = txt.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase());
  await m.reply(result);
};
handler.help = [..."aiueo"].map((v) => `h${v}l${v}h <teks>`);
handler.tags = ["fun"];
handler.command = /^h([aiueo])l\1h/i;
handler.limit = true;
handler.register = true;
var fun_halah_vocal_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
