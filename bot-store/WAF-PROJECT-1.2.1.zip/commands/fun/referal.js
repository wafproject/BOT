/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - referal.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_referal_exports = {};
__export(fun_referal_exports, {
  default: () => fun_referal_default
});
module.exports = __toCommonJS(fun_referal_exports);
var import_crypto = __toESM(require("crypto"));
const xp_first_time = 2500;
const xp_link_creator = 15e3;
const xp_bonus = {
  5: 4e4,
  10: 1e5,
  20: 25e4,
  50: 1e6,
  100: 1e7
};
let handler = async (m, { jagoanproject, usedPrefix, text }) => {
  let users = global.db.data.users;
  if (text) {
    if ("ref_count" in users[m.sender]) throw "Tidak bisa menggunakan kode referal!";
    let link_creator = (Object.entries(users).find(([, { ref_code }]) => ref_code === text.trim()) || [])[0];
    if (!link_creator) throw "Kode referal tidak valid";
    let count = users[link_creator].ref_count++;
    let extra = xp_bonus[count] || 0;
    users[link_creator].exp += xp_link_creator + extra;
    users[m.sender].exp += xp_first_time;
    users[m.sender].ref_count = 0;
    m.reply(`
Selamat!
+${xp_first_time} XP
`.trim());
    m.reply(`
Seseorang telah menggunakan kode referal kamu
+${xp_link_creator + extra} XP
`.trim(), link_creator);
  } else {
    let code = users[m.sender].ref_code = users[m.sender].ref_code || new Array(11).fill().map(() => [..."0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"][import_crypto.default.randomInt(62)]).join("");
    users[m.sender].ref_count = users[m.sender].ref_count ? users[m.sender].ref_count : 0;
    let command_text = `${usedPrefix}ref ${code}`;
    let command_link = `wa.me/${jagoanproject.user.jid.split("@")[0]}?text=${encodeURIComponent(command_text)}`;
    let share_text = `
Dapatkan ${xp_first_time} XP untuk yang menggunakan link/kode referal dibawah ini

Referal Code: *${code}*

${command_link}
`.trim();
    m.reply(`
Dapatkan ${xp_link_creator} XP untuk setiap pengguna baru yang menggunakan kode referal kamu
${users[m.sender].ref_count} orang telah menggunakan kode referal kamu

Kode referal kamu: ${code}

Bagikan link kepada teman: ${command_link}

atau kirim pesan kepada teman wa.me/?text=${encodeURIComponent(share_text)}

${Object.entries(xp_bonus).map(([count, xp]) => `${count} Orang = Bonus ${xp} XP`).join("\n")}
`.trim());
  }
};
handler.help = ["ref"];
handler.tags = ["fun"];
handler.command = ["ref"];
handler.register = true;
handler.limit = true;
var fun_referal_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
