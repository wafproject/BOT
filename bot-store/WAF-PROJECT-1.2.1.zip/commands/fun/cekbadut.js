/**
 * .cekbadut — versi offline (tanpa API). Isi daftar & teks: lib/cek-offline.js
 */
module.exports = require('../../lib/cek-offline.js').makeCek("cekbadut")
