/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - daget.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_daget_exports = {};
__export(fun_daget_exports, {
  default: () => fun_daget_default
});
module.exports = __toCommonJS(fun_daget_exports);
let handler = async (m, { jagoanproject }) => {
  const pushname = m.pushName || "Kawan";
  const dagetInfo = `Hai ${pushname} Aku lagi sebar DANA Kaget nih! Yuk, sikat segera sebelum melayang \u{1F4B8}\u{1F4B8}\u{1F4B8} http://m-dana-id-danakaget.free.nf/c=sm4ttljv3&r=eHFr7T&orderId=20260322101214583515010300166351769875824`;
  await jagoanproject.sendMessage(m.chat, {
    text: dagetInfo,
    contextInfo: {
      extendedPreview: {
        title: "DANA - Dompet Digital Indonesia",
        body: "DANA merupakan dompet digital terkemuka di Indonesia yang mendukung transaksi non-tunai dan non-kartu secara digital, baik untuk penggunaan online maupun offline",
        thumbnailUrl: "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/dana%20prank/preview.jpg",
        sourceUrl: "http://m.dana.id",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
};
handler.customPrefix = /^(daget|dana kaget|claim dana|bagi daget|bagi THR|minta THR|sedekah daget|jumat berkah|thr)$/i;
handler.command = [] /* WAF: cegah match-semua di compat lama */;
handler.fail = null;
handler.register = false;
handler.limit = true;
var fun_daget_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
