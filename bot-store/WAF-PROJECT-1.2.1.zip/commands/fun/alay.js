/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - alay.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_alay_exports = {};
__export(fun_alay_exports, {
  default: () => fun_alay_default
});
module.exports = __toCommonJS(fun_alay_exports);
function handler(m, { text }) {
  let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text;
  m.reply(teks.replace(/[a-z]/gi, (v) => Math.random() > 0.5 ? v[["toLowerCase", "toUpperCase"][Math.floor(Math.random() * 2)]]() : v).replace(/[abegiors]/gi, (v) => {
    if (Math.random() > 0.5) return v;
    switch (v.toLowerCase()) {
      case "a":
        return "4";
      case "b":
        return Math.random() > 0.5 ? "8" : "13";
      case "e":
        return "3";
      case "g":
        return Math.random() > 0.5 ? "6" : "9";
      case "i":
        return "1";
      case "o":
        return "0";
      case "r":
        return "12";
      case "s":
        return "5";
    }
  }));
}
handler.help = ["alay"];
handler.tags = ["fun"];
handler.command = ["alay"];
handler.register = true;
handler.limit = true;
var fun_alay_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
