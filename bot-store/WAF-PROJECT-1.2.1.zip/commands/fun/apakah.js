/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - apakah.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_apakah_exports = {};
__export(fun_apakah_exports, {
  default: () => fun_apakah_default
});
module.exports = __toCommonJS(fun_apakah_exports);
let handler = async (m, { command, text }) => {
  let jawab = ["Ya", "Mungkin iya", "Mungkin", "Mungkin tidak", "Tidak", "Tidak mungkin"];
  let siapa = jawab[Math.floor(Math.random() * jawab.length)];
  jagoanproject.reply(m.chat, `
*Pertanyaan:* ${command} ${text}
*Jawaban:* ${siapa}
  `, m);
};
handler.help = ["apakah *<teks>*"];
handler.tags = ["fun"];
handler.command = /^apakah$/i;
handler.limit = true;
handler.register = true;
var fun_apakah_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
