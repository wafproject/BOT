/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - menfess.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_menfess_exports = {};
__export(fun_menfess_exports, {
  default: () => fun_menfess_default
});
module.exports = __toCommonJS(fun_menfess_exports);
let handler = async (m, { jagoanproject, text, usedPrefix, command }) => {
  jagoanproject.menfess = jagoanproject.menfess ? jagoanproject.menfess : {};
  if (!text) throw `*Cara penggunaan :*

${usedPrefix + command} nomor|nama pengirim|pesan

*Note:* nama pengirim boleh nama samaran atau anonymous.

*Contoh:* ${usedPrefix + command} ${m.sender.split`@`[0]}|Anonymous|Hai.`;
  let [jid, name, pesan] = text.split("|");
  if (!jid || !name || !pesan) throw `*Cara penggunaan :*

${usedPrefix + command} nomor|nama pengirim|pesan

*Note:* nama pengirim boleh nama samaran atau anonymous.

*Contoh:* ${usedPrefix + command} ${m.sender.split`@`[0]}|Anonymous|Hai.`;
  jid = jid.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  let data = (await jagoanproject.onWhatsApp(jid))[0] || {};
  if (!data.exists) throw "Nomer tidak terdaftar di whatsapp.";
  if (jid == m.sender) throw "tidak bisa mengirim pesan menfess ke diri sendiri.";
  let mf = Object.values(jagoanproject.menfess).find((mf2) => mf2.status === true);
  if (mf) return true;
  let id = +/* @__PURE__ */ new Date();
  let teks = `Hai @${data.jid.split("@")[0]}, kamu menerima pesan Menfess nih.

Dari: *${name}*
Pesan: 
${pesan}

Mau balas pesan ini kak? bisa kok kak. tinggal ketik pesan kakak lalu kirim, nanti saya sampaikan ke *${name}*.`.trim();
  await jagoanproject.relayMessage(data.jid, {
    extendedTextMessage: {
      text: teks,
      contextInfo: {
        mentionedJid: [data.jid],
        extendedPreview: {
          title: "M E N F E S S",
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIyz1dMPkZuNleUyfXPMsltHwKKdVddTf4-A&usqp=CAU",
          sourceUrl: ""
        }
      }
    }
  }, {}).then(() => {
    m.reply("Berhasil mengirim pesan menfess.");
    jagoanproject.menfess[id] = {
      id,
      dari: m.sender,
      nama: name,
      penerima: data.jid,
      pesan,
      status: false
    };
    return true;
  });
};
handler.tags = ["fun"];
handler.help = ["menfess"];
handler.command = /^(menfess|menfes)$/i;
handler.private = true;
handler.register = true;
handler.limit = true;
var fun_menfess_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
