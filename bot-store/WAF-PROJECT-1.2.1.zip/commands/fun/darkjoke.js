/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - darkjoke.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_darkjoke_exports = {};
__export(fun_darkjoke_exports, {
  default: () => fun_darkjoke_default
});
module.exports = __toCommonJS(fun_darkjoke_exports);
var import_https = __toESM(require("https"));
const SOURCE_URL = "https://raw.githubusercontent.com/ChandraGO/Databasee-gamee/refs/heads/main/text/darkjoke.json";
let handler = async (m, { jagoanproject, usedPrefix, command }) => {
  try {
    await jagoanproject.reply(m.chat, "\u23F3 *Sedang mengambil darkjoke...*", m);
    const list = await getJson(SOURCE_URL);
    if (!Array.isArray(list) || list.length < 1) throw "Data darkjoke kosong / format tidak valid.";
    const pick = list[Math.floor(Math.random() * list.length)];
    const caption = `\u250F\u2501\u2501\u2501\u300E \u{1F5A4} *DARK JOKES* \u300F\u2501\u2501\u2501\u2513
\u2503
\u2503 \u{1F3AD} Random Dark Meme
\u2503 \u{1F525} Mode: ${command.toUpperCase()}
\u2503 \u{1F4E6} Total: ${list.length} gambar
\u2503
\u2503 \u26A0\uFE0F *Humor gelap, jangan baper ya \u{1F605}*
\u2517\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u251B`;
    await jagoanproject.sendMessage(
      m.chat,
      {
        image: { url: pick },
        caption
      },
      { quoted: m }
    );
  } catch (e) {
    const msg = e && e.message ? e.message : String(e);
    return jagoanproject.reply(
      m.chat,
      `\u250F\u2501\u2501\u2501\u300E \u274C *GAGAL* \u300F\u2501\u2501\u2501\u2513
\u2503 ${msg}
\u2517\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u251B`,
      m
    );
  }
};
handler.help = ["darkjoke"];
handler.tags = ["fun"];
handler.command = /^(darkjoke|darkjokes)$/i;
handler.limit = true;
handler.register = true;
var fun_darkjoke_default = handler;
function getJson(url) {
  return new Promise((resolve, reject) => {
    import_https.default.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => {
        try {
          resolve(JSON.parse(data));
        } catch (err) {
          reject(new Error("Gagal parse JSON dari sumber."));
        }
      });
    }).on("error", (err) => reject(err));
  });
}

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
