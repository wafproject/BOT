/**
 * ========================================================
 * 🔁 Dipindahkan dari bot lama (Jagoan Project)
 * Asal  : plugins/fun/fun - lokbut.js
 * Jalan lewat lapisan kompatibilitas: lib/jagoan/compat.js
 * ========================================================
 */
const __jpImportMetaUrl = require('url').pathToFileURL(__filename).href;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fun_lokbut_exports = {};
__export(fun_lokbut_exports, {
  default: () => fun_lokbut_default
});
module.exports = __toCommonJS(fun_lokbut_exports);
let handler = async (m, { jagoanproject }) => {
  await jagoanproject.sendMessage(m.chat, {
    location: {
      degreesLatitude: 40.741895,
      degreesLongitude: -73.989308,
      name: "jawa hama",
      address: "ah crot"
    },
    caption: "\u{1F4CD} Ini lokasi dummy",
    footer: `ARMAN GZ Official`,
    buttons: [
      {
        buttonId: ".menu",
        buttonText: { displayText: "\u{1F4DC} Menu" },
        type: 1
      },
      {
        buttonId: ".owner",
        buttonText: { displayText: "\u{1F464} Owner" },
        type: 1
      }
    ],
    headerType: 6
  }, { quoted: m });
};
handler.help = ["lokbut"];
handler.tags = ["fun"];
handler.command = /^lokbut$/i;
handler.register = true;
handler.limit = true;
var fun_lokbut_default = handler;

// == bungkus handler lama agar cocok dengan handler WAF Project ==
module.exports = require("../../lib/jagoan/compat.js").wrap(
  (module.exports && module.exports.default) || module.exports,
  { file: __filename, category: "fun" }
)
