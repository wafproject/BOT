/**
 * .autoai — Auto AI pakai Gemini (langsung ke Google, tanpa API Jagoan)
 * Mesin: lib/autoai.js · lib/gemini.js
 */
const fs = require('fs').promises
const path = require('path')
const ai = require('../../lib/autoai.js')
const gemini = require('../../lib/gemini.js')

async function writeSetting(name, value) {
  const file = path.join(process.cwd(), 'settings.js')
  let src = await fs.readFile(file, 'utf8')
  const re = new RegExp(`^(\\s*global\\.${name}\\s*=\\s*)(["'\`])[^"'\`]*\\2\\s*;?`, 'm')
  if (re.test(src)) src = src.replace(re, `$1"${value}";`)
  else src += `\nglobal.${name} = "${value}";\n`
  await fs.writeFile(file, src, 'utf8')
  global[name] = value
}

function help(p) {
  return [
    '🤖 *AUTO AI (Gemini)*',
    '',
    'Di grup, AI membalas kalau bot di-*tag*, pesan bot di-*reply*, atau nama panggilannya disebut.',
    'Bisa baca gambar, stiker & voice note, dan bisa menjalankan fitur bot dari obrolan.',
    '',
    '*Admin grup*',
    `• ${p}autoai on / off`,
    `• ${p}autoai reset — hapus ingatan obrolan grup ini`,
    `• ${p}autoai persona — daftar persona`,
    `• ${p}autoai setpersona <nama>`,
    '',
    '*Owner*',
    `• ${p}autoai onall / offall`,
    `• ${p}autoai addpersona nama|panggilan|sifat & gaya bicara`,
    `• ${p}autoai delpersona <nama>`,
    `• ${p}autoai setkey <API key Gemini>`,
    `• ${p}autoai setmodel <model>`,
    `• ${p}autoai status`,
  ].join('\n')
}

const handler = async (m, { args, text, usedPrefix, isOwner, isROwner, isAdmin }) => {
  const p = usedPrefix || '.'
  const sub = String(args[0] || '').toLowerCase()
  const rest = String(text || '').slice(String(args[0] || '').length).trim()
  const owner = isOwner || isROwner
  const admin = owner || isAdmin
  const C = ai.CONF
  const conf = ai.chatConf(m.chat)

  if (!sub || sub === 'help') return m.reply(help(p))

  if (sub === 'status') {
    const keys = gemini.keys()
    return m.reply([
      '🤖 *Status Auto AI*',
      `• Chat ini: ${conf.enabled ? '✅ aktif' : '❌ mati'}`,
      `• Default semua chat: ${C.enabled ? 'aktif' : 'mati'}`,
      `• Persona: *${conf.persona.key}* (${conf.persona.nama}${conf.persona.panggilan ? `, panggilan "${conf.persona.panggilan}"` : ''})`,
      `• Ingatan chat ini: ${ai.memOf(m.chat).length} pesan`,
      `• Model: ${gemini.model()}`,
      `• API key: ${keys.length ? `${keys.length} terpasang` : '❌ belum diisi'}`,
    ].join('\n'))
  }

  if (sub === 'on' || sub === 'off') {
    if (m.isGroup ? !admin : !owner) return m.reply(m.isGroup ? 'Khusus admin grup.' : 'Khusus owner.')
    const on = sub === 'on'
    if (m.isGroup) { C.groups[m.chat] = { ...(C.groups[m.chat] || {}), enabled: on } } else C.enabled = on
    ai.saveConf()
    return m.reply(on ? '✅ Auto AI aktif di chat ini.' : '❌ Auto AI dimatikan di chat ini.')
  }

  if (sub === 'onall' || sub === 'offall') {
    if (!owner) return m.reply('Khusus owner.')
    C.enabled = sub === 'onall'
    for (const g of Object.values(C.groups)) delete g.enabled
    ai.saveConf()
    return m.reply(C.enabled ? '✅ Auto AI aktif di semua chat.' : '❌ Auto AI dimatikan di semua chat.')
  }

  if (sub === 'reset' || sub === 'clear') {
    if (m.isGroup && !admin) return m.reply('Khusus admin grup.')
    ai.forget(m.chat)
    return m.reply('🧹 Ingatan obrolan di chat ini sudah dihapus.')
  }

  if (sub === 'persona' || sub === 'personas') {
    const d = ai.defaultPersona()
    const rows = [`• *default* — ${d.nama}${d.panggilan ? ` (panggilan "${d.panggilan}")` : ''}`]
    for (const [k, v] of Object.entries(C.personas)) rows.push(`• *${k}* — ${v.nama}${v.panggilan ? ` (panggilan "${v.panggilan}")` : ''}`)
    return m.reply(`🎭 *Persona Auto AI*\nAktif di sini: *${conf.persona.key}*\n\n${rows.join('\n')}\n\nGanti: *${p}autoai setpersona <nama>*`)
  }

  if (sub === 'setpersona') {
    if (m.isGroup ? !admin : !owner) return m.reply(m.isGroup ? 'Khusus admin grup.' : 'Khusus owner.')
    const name = rest.toLowerCase()
    if (!name || (name !== 'default' && !C.personas[name])) return m.reply(`Persona tidak ada. Lihat daftar: *${p}autoai persona*`)
    if (m.isGroup) C.groups[m.chat] = { ...(C.groups[m.chat] || {}), persona: name }
    else C.persona = name
    ai.saveConf()
    ai.forget(m.chat)
    return m.reply(`🎭 Persona diganti ke *${name}*${m.isGroup ? ' untuk grup ini' : ' (default semua chat)'}. Ingatan obrolan direset.`)
  }

  if (sub === 'addpersona') {
    if (!owner) return m.reply('Khusus owner.')
    const [nama, panggilan, ...sifat] = rest.split('|').map((x) => x.trim())
    const prompt = sifat.join('|').trim()
    if (!nama || !prompt) {
      return m.reply(`Format: *${p}autoai addpersona nama|panggilan|sifat & gaya bicara*\n\nContoh:\n${p}autoai addpersona Indah|indah|Kamu Indah, cewek ramah yang suka bercanda, jawab singkat pakai bahasa gaul.`)
    }
    const key = nama.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20)
    if (!key || key === 'default') return m.reply('Nama persona tidak valid.')
    C.personas[key] = { nama, panggilan: (panggilan || '').toLowerCase().slice(0, 30), prompt: prompt.slice(0, 4000) }
    ai.saveConf()
    return m.reply(`✅ Persona *${key}* disimpan.\nPakai: *${p}autoai setpersona ${key}*`)
  }

  if (sub === 'delpersona') {
    if (!owner) return m.reply('Khusus owner.')
    const name = rest.toLowerCase()
    if (!C.personas[name]) return m.reply('Persona tidak ada.')
    delete C.personas[name]
    if (C.persona === name) C.persona = 'default'
    for (const g of Object.values(C.groups)) if (g.persona === name) delete g.persona
    ai.saveConf()
    return m.reply(`🗑️ Persona *${name}* dihapus.`)
  }

  if (sub === 'setkey') {
    if (!owner) return m.reply('Khusus owner.')
    const key = rest.split(/\s+/)[0]
    if (!/^[\w-]{20,}$/.test(key || '')) return m.reply(`Format: *${p}autoai setkey <API key Gemini>*\nAmbil gratis di aistudio.google.com → Get API key.`)
    try { await writeSetting('geminikey', key) } catch (e) { return m.reply('❌ Gagal menulis settings.js: ' + (e?.message || e)) }
    try {
      await gemini.generate({ contents: [{ role: 'user', parts: [{ text: 'balas: ok' }] }], generationConfig: { maxOutputTokens: 5 } })
      return m.reply('✅ API key Gemini disimpan & berhasil dites. Auto AI siap dipakai.\n(Hapus pesan berisi key tadi biar aman.)')
    } catch (e) {
      return m.reply(`⚠️ Key disimpan, tapi tes gagal: ${e?.message || e}\n(Hapus pesan berisi key tadi biar aman.)`)
    }
  }

  if (sub === 'setmodel') {
    if (!owner) return m.reply('Khusus owner.')
    const model = rest.split(/\s+/)[0]
    if (!/^[\w.-]{3,60}$/.test(model || '')) return m.reply(`Format: *${p}autoai setmodel <nama model>*\nSekarang: ${gemini.model()}\nContoh: gemini-flash-latest`)
    try { await writeSetting('geminimodel', model) } catch (e) { return m.reply('❌ Gagal menulis settings.js: ' + (e?.message || e)) }
    return m.reply(`✅ Model Gemini diganti ke *${model}*.`)
  }

  return m.reply(help(p))
}

handler.help = ['autoai on/off', 'autoai status', 'autoai reset', 'autoai persona', 'autoai setpersona <nama>']
handler.tags = ['ai']
handler.category = 'ai'
handler.command = /^(autoai)$/i
handler.register = false
handler.limit = false
// dipanggil untuk setiap pesan; langsung kembali, AI diproses di belakang
handler.all = function (m, ctx) { ai.hook(m, ctx) }

module.exports = handler
