/**
 * 🎮 CEK HONOR OF KINGS — WAF PROJECT
 * Provider: G2Bulk public player validation API
 * Perintah: .cekhok <Player ID> / .cekhonorofkings <Player ID>
 * Install: commands/stalk/cekhok.js
 * Requires: axios (already used by WAF Project)
 * Note: Provider support for HOK is discovered live via /v1/games, not assumed.
 */
'use strict'

const axios = require('axios')
const BASE = 'https://api.g2bulk.com/v1'
const CACHE_TTL = 5 * 60 * 1000
const cache = new Map()
let gameCache = { code: '', expiresAt: 0 }

const line = '━━━━━━━━━━━━━━━━━━'
const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

function waktuWIB() {
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta', dateStyle: 'long', timeStyle: 'medium'
  }).format(new Date()) + ' WIB'
}

function normalizeName(val) {
  return String(val ?? '').replace(/\s+/g, ' ').trim()
}

function safeMessage(err) {
  if (err?.userMessage) return err.userMessage
  if (err?.code === 'ECONNABORTED' || /timeout/i.test(String(err?.message || ''))) {
    return 'Waktu cek akun habis. Silakan coba lagi.'
  }
  return 'Layanan pengecekan Honor of Kings sedang bermasalah. Coba lagi nanti.'
}

function newUserError(message) {
  const e = new Error(message)
  e.userMessage = message
  return e
}

async function request(method, route, data) {
  let lastErr
  for (let i = 0; i < 2; i++) {
    try {
      const rsp = await axios({
        method, url: `${BASE}${route}`, data,
        timeout: 12000,
        headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        validateStatus: () => true
      })
      if ([429, 500, 502, 503, 504].includes(rsp.status) && i === 0) {
        await delay(800)
        continue
      }
      return rsp
    } catch (error) {
      lastErr = error
      const retriable = ['ECONNRESET', 'ETIMEDOUT', 'ECONNABORTED', 'EAI_AGAIN'].includes(error?.code) ||
        /socket hang up|timeout/i.test(String(error?.message || ''))
      if (retriable && i === 0) { await delay(800); continue }
      break
    }
  }
  throw lastErr || new Error('Gagal menghubungi API.')
}

async function getHokCode() {
  if (gameCache.code && gameCache.expiresAt > Date.now()) return gameCache.code

  const rsp = await request('GET', '/games')
  if (rsp.status < 200 || rsp.status >= 300) {
    throw new Error(`Gagal membaca daftar game provider: HTTP ${rsp.status}`)
  }
  const payload = rsp.data
  const games = Array.isArray(payload?.games) ? payload.games :
    Array.isArray(payload?.data?.games) ? payload.data.games :
    Array.isArray(payload?.data) ? payload.data : null

  if (!games) throw new Error('Format daftar game API berubah.')
  const selected = games.find(game => {
    const name = String(game?.name || game?.title || '')
    const code = String(game?.code || game?.slug || '')
    return /honor\s*(of\s*)?kings/i.test(name.replace(/[_-]/g, ' ')) ||
      /^(hok|honor[_-]?of[_-]?kings|honorofkings)$/i.test(code)
  })
  if (!selected) {
    throw newUserError('Pengecekan Honor of Kings belum tersedia di API G2Bulk saat ini. Bot tidak akan menebak nickname akun.')
  }

  const code = String(selected.code || selected.slug || '').trim()
  if (!code) throw new Error('Game HOK ditemukan tetapi kode gamenya kosong.')
  gameCache = { code, expiresAt: Date.now() + 10 * 60 * 1000 }
  return code
}

const INVALID_ACCOUNT_TEXT = /(?:\b(?:player|user|account|uid|id)\b.{0,60}\b(?:invalid|not[\s_-]?found|not[\s_-]?exist|does\s+not\s+exist|doesn.t\s+exist|unknown|unregistered)\b|\b(?:invalid|unknown|unregistered)\b.{0,50}\b(?:player|user|account|uid|id)\b|\b(?:player|user|account|uid|id)\b.{0,60}(?:tidak\s+(?:valid|ditemukan|terdaftar|ada)|salah)|(?:tidak\s+(?:valid|ditemukan|terdaftar))\b.{0,50}\b(?:id|akun|pemain)|(?:invalid[\s_-]?(?:player[\s_-]?)?(?:id|uid)|player[\s_-]?not[\s_-]?found|user[\s_-]?not[\s_-]?found|account[\s_-]?not[\s_-]?found))/i
const INVALID_CODES = new Set([
  'INVALID_ID', 'INVALID_UID', 'INVALID_USER_ID', 'INVALID_PLAYER_ID',
  'PLAYER_NOT_FOUND', 'USER_NOT_FOUND', 'ACCOUNT_NOT_FOUND', 'ID_NOT_FOUND',
  'UID_NOT_FOUND', 'PLAYER_ID_NOT_FOUND', 'ACCOUNT_INVALID', 'NOT_REGISTERED'
])
const INVALID_STATES = new Set(['invalid', 'not_found', 'not found', 'notfound', 'not_exist', 'not exist', 'nonexistent', 'not registered', 'not_registered', 'unknown_user', 'unknown_player'])

function getValidationStatus(data) {
  const obj = data && typeof data === 'object' ? data : {}
  const nested = obj.data && typeof obj.data === 'object' ? obj.data : {}
  const detail = obj.detail && typeof obj.detail === 'object' ? obj.detail : {}
  const explicit = [obj.valid, nested.valid, detail.valid]
  const states = [obj.status, nested.status]
  const reasonParts = [obj.message, obj.error, obj.error_code, obj.code,
    nested.message, nested.error, nested.error_code,
    detail.message, detail.error, detail.code].filter(x => x != null)
  const reason = reasonParts.map(x => String(x)).join(' | ').slice(0, 500)

  // Respons server bermasalah jangan dianggap sebagai Player ID invalid.
  const outage = /rate[\s_-]?limit|too many requests|server error|internal error|temporar(?:ily)? unavailable|maintenance|upstream|gateway|timeout|timed out|service unavailable|unauthorized|forbidden|invalid api[\s_-]?key|game (?:not supported|unavailable|not available)|missing required/i.test(reason)
  if (outage) return { type: 'error', reason }

  if (explicit.some(v => v === false || v === 0 || INVALID_STATES.has(String(v).toLowerCase().trim()))) {
    return { type: 'invalid', reason }
  }
  if (states.some(v => INVALID_STATES.has(String(v).toLowerCase().trim()))) return { type: 'invalid', reason }
  if (reasonParts.some(v => INVALID_CODES.has(String(v).toUpperCase().trim()))) return { type: 'invalid', reason }
  if (INVALID_ACCOUNT_TEXT.test(reason)) return { type: 'invalid', reason }

  const valid = explicit.some(v => v === true || v === 1 || ['valid', 'true', '1'].includes(String(v).toLowerCase().trim()))
  return { type: valid ? 'valid' : 'unknown', reason }
}

function invalidPlayerError() {
  return newUserError('❌ *ID HONOR OF KINGS TIDAK VALID*\nPastikan Player ID yang dimasukkan sudah benar.')
}

async function checkHok(uid) {
  const cached = cache.get(uid)
  if (cached && cached.expiresAt > Date.now()) return cached.name

  const game = await getHokCode()
  const rsp = await request('POST', '/games/checkPlayerId', { game, user_id: uid })
  const result = rsp.data
  const code = Number(rsp.status)

  // Bila layanan mengalami gangguan, jangan menyebut Player ID salah.
  if (code === 429 || code >= 500 || code === 401 || code === 403) {
    throw new Error(`Provider HTTP ${code}`)
  }
  if (!result || typeof result !== 'object') throw new Error('Respons API kosong/tidak valid.')

  const check = getValidationStatus(result)
  if (check.type === 'invalid') throw invalidPlayerError()

  // HTTP 400/404/422 saja tidak cukup membuktikan ID salah: bisa salah route/parameter.
  // Pesan dan kode validasi dari API yang dipakai sebagai bukti.
  if (code < 200 || code >= 300) {
    console.error('[CEKHOK API]', 'HTTP', code, 'reason:', check.reason || '-', 'body:', JSON.stringify(result).slice(0, 700))
    throw new Error(`Provider HTTP ${code}: ${check.reason || 'Tidak ada detail'}`)
  }
  if (check.type !== 'valid') {
    console.error('[CEKHOK API] respons tidak dikenali:', JSON.stringify(result).slice(0, 700))
    throw new Error('API tidak mengembalikan status validasi yang jelas.')
  }

  const name = normalizeName(result.name ?? result.nickname ?? result.data?.name ?? result.data?.nickname ?? result.data?.username)
  if (!name || name === uid || /^(null|undefined|unknown|n\/a|-)$/i.test(name)) {
    throw new Error('API tidak memberikan nickname terverifikasi.')
  }
  cache.set(uid, { name, expiresAt: Date.now() + CACHE_TTL })
  if (cache.size > 250) cache.delete(cache.keys().next().value)
  return name
}

async function plugin(m, { wafproject, args = [], text = '', usedPrefix = '.', command = '' }) {
  if (!/^(cekhok|cekhonorofkings)$/i.test(command)) return
  const uid = (args.length ? args.join(' ') : text || '').trim()
  if (!/^\d{6,24}$/.test(uid)) {
    return wafproject.sendMessage(m.chat, { text:
      `❓ *FORMAT TIDAK VALID*\n\nGunakan:\n${usedPrefix || '.'}cekhok 17960996468644334037\n\nMasukkan Player ID Honor of Kings (hanya angka).` }, { quote: m })
  }

  try { await wafproject.sendMessage(m.chat, { react: { text: '🔎', key: m.key } }) } catch {}
  try {
    const nickname = await checkHok(uid)
    const output = `🎮 *CEK AKUN HONOR OF KINGS*\n${line}\n🆔 *Player ID* : ${uid}\n👤 *Nickname* : ${nickname}\n🕒 *Waktu Cek* : ${waktuWIB()}`
    await wafproject.sendMessage(m.chat, { text: output }, { quote: m })
    try { await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) } catch {}
  } catch (error) {
    console.error('[CEKHOK]', error?.message || error)
    try { await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }) } catch {}
    return wafproject.sendMessage(m.chat, { text: safeMessage(error) }, { quote: m })
  }
}

plugin.command = ['cekhok', 'cekhonorofkings']
plugin.category = 'stalk'
plugin.description = 'Cek nickname Honor of Kings melalui validasi G2Bulk'
module.exports = plugin
