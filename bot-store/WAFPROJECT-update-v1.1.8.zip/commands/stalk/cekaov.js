/**
 * WAF PROJECT — CEK ARENA OF VALOR (AOV)
 *
 * Public API: https://api-cek-id-game-ten.vercel.app/api/check-id-game
 * Docs: https://github.com/sandrocods/api-cek-id-game
 *
 * - Tanpa API key; tidak memakai Isan
 * - Tidak mengubah order/saldo/pembayaran
 * - Sukses hanya jika provider menandai akun valid DAN nickname tersedia
 * - ID salah tidak disamakan dengan kegagalan provider
 */
'use strict'

const axios = require('axios')

const ENDPOINT = 'https://api-cek-id-game-ten.vercel.app/api/check-id-game'
const TIMEOUT_MS = 15000
const CACHE_TTL_MS = 5 * 60 * 1000
const CACHE_LIMIT = 200
const nickCache = new Map()

function str(value) {
  return value === undefined || value === null ? '' : String(value).trim()
}

function errorOf(kind, message, details) {
  const err = new Error(message)
  err.kind = kind
  if (details) err.details = details
  return err
}

function cleanId(input) {
  const id = str(input)
  return /^\d{5,25}$/.test(id) ? id : null
}

function sanitizeNickname(value) {
  return str(value)
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, 100)
}

function messageOf(body) {
  const data = body?.data
  return str(body?.message || body?.error || body?.errorMsg || data?.message || data?.error)
}

// Hanya error API yang SECARA JELAS berarti akun tidak ditemukan.
function isExplicitInvalidId(message, body) {
  const code = str(body?.code || body?.error_code || body?.data?.code).toLowerCase()
  if (/^(user_not_found|player_not_found|account_not_found|invalid_user_id|invalid_player_id|id_not_found|user_id_not_eligible)$/.test(code)) return true
  return /useridnoteligible|useridnotfound|user.?id.?not.?found|player.?id.?not.?found|account.?not.?found|player.?not.?found|user.?not.?found|id.{0,12}not.?found|id.{0,12}does.?not.?exist|id.{0,12}tidak.?ditemukan|id.{0,12}tidak.?valid|invalid.?player.?id|invalid.?user.?id|invalid.?account.?id|not.?eligible.?user|unknown.?player/i.test(message)
}

function parseResponse(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw errorOf('provider', 'Format respons API tidak dikenali.')
  }
  const message = messageOf(body)
  if (body.status === true) {
    const data = body.data && typeof body.data === 'object' ? body.data : {}
    const nickname = sanitizeNickname(body.nickname || body.username || data.nickname || data.username)
    if (!nickname || /^(?:-|null|undefined|unknown|tidak diketahui)$/i.test(nickname)) {
      throw errorOf('provider', 'Provider menyatakan sukses, tetapi nickname kosong.')
    }
    return { nickname }
  }
  if (body.status === false) {
    if (isExplicitInvalidId(message, body)) {
      throw errorOf('invalid_id', 'ID AOV tidak ditemukan di provider.')
    }
    throw errorOf('provider', `Provider tidak dapat memverifikasi ID: ${message || 'pesan tidak tersedia'}`)
  }
  throw errorOf('provider', 'Format status respons API berubah.')
}

function isTemporaryHttp(status) {
  return status === 429 || status === 408 || status >= 500
}
function isTransientNetwork(err) {
  return ['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN', 'ECONNABORTED', 'EPIPE'].includes(str(err?.code)) ||
    /timeout|socket hang up/i.test(str(err?.message))
}

async function requestWithRetry(body) {
  let lastError
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await axios.post(ENDPOINT, body, {
        timeout: TIMEOUT_MS,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        validateStatus: () => true
      })
      if (attempt === 0 && isTemporaryHttp(res.status)) {
        await new Promise(resolve => setTimeout(resolve, 700))
        continue
      }
      return res
    } catch (err) {
      lastError = err
      if (attempt === 0 && isTransientNetwork(err)) {
        await new Promise(resolve => setTimeout(resolve, 700))
        continue
      }
      throw errorOf('provider', `Gagal menghubungi API (${str(err?.code || err?.message) || 'network error'}).`)
    }
  }
  throw errorOf('provider', `Gagal menghubungi API (${str(lastError?.code || lastError?.message) || 'server error'}).`)
}

function cacheGet(id) {
  const row = nickCache.get(id)
  if (!row) return null
  if (row.expires <= Date.now()) {
    nickCache.delete(id)
    return null
  }
  return row.value
}
function cacheSet(id, value) {
  if (nickCache.size >= CACHE_LIMIT) nickCache.delete(nickCache.keys().next().value)
  nickCache.set(id, { value, expires: Date.now() + CACHE_TTL_MS })
}

async function lookupAov(id) {
  const cached = cacheGet(id)
  if (cached) return { ...cached, cached: true }
  let res
  try {
    res = await requestWithRetry({ type_name: 'arena_of_valor', userId: id, zoneId: '' })
  } catch (err) {
    if (err.kind) throw err
    throw errorOf('provider', `Gagal terhubung ke provider: ${str(err.message)}`)
  }

  // 4xx dapat berisi respons ID invalid. Baca body dulu, jangan semua 4xx = provider rusak.
  const data = res.data
  if (res.status >= 200 && res.status < 300) {
    const result = parseResponse(data)
    cacheSet(id, result)
    return { ...result, cached: false }
  }
  if (res.status >= 400 && res.status < 500 && res.status !== 429 &&
      data && data.status === false && isExplicitInvalidId(messageOf(data), data)) {
    throw errorOf('invalid_id', 'ID AOV ditolak provider sebagai tidak valid.')
  }
  throw errorOf('provider', `API merespons HTTP ${res.status}${messageOf(data) ? `: ${messageOf(data)}` : ''}.`)
}

function waktuWIB() {
  return new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: '2-digit', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }) + ' WIB'
}

async function reactSafe(conn, m, emoji) {
  try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) }
  catch { /* Gagal reaksi tidak boleh mengganggu cek ID */ }
}

async function plugin(m, { wafproject, args = [], text = '', usedPrefix = '.', command = '' } = {}) {
  if (!/^cekaov$/i.test(command)) return
  const raw = (Array.isArray(args) && args.length ? args.join(' ') : str(text)).trim()
  const uid = cleanId(raw)
  if (!uid) {
    return wafproject.sendMessage(m.chat, {
      text: `❓ *FORMAT CEK ARENA OF VALOR*\n\nGunakan:\n${usedPrefix || '.'}cekaov 124590895269021\n\nMasukkan *Player ID / Open ID AOV* berupa angka (5–25 digit), bukan nickname.`
    }, { quote: m })
  }

  await reactSafe(wafproject, m, '🔎')
  try {
    const { nickname } = await lookupAov(uid)
    await wafproject.sendMessage(m.chat, {
      text: `🎮 *CEK AKUN ARENA OF VALOR*\n━━━━━━━━━━━━━━━━━━\n🆔 *Player ID* : ${uid}\n👤 *Nickname* : ${nickname}\n🕒 *Waktu Cek* : ${waktuWIB()}`
    }, { quote: m })
    await reactSafe(wafproject, m, '✅')
  } catch (err) {
    // Log teknis hanya di server agar tidak memenuhi chat.
    console.error('[CEKAOV]', JSON.stringify({ id: uid, kind: err?.kind || 'provider', message: str(err?.message) }))
    await reactSafe(wafproject, m, '❌')
    return wafproject.sendMessage(m.chat, {
      text: err?.kind === 'invalid_id'
        ? '❌ *ID ARENA OF VALOR TIDAK DITEMUKAN*\nPastikan Player ID / Open ID yang dimasukkan benar.'
        : '⚠️ *CEK ID ARENA OF VALOR GAGAL*\nLayanan pengecekan sedang bermasalah. ID belum bisa dipastikan benar atau salah. Coba lagi nanti.'
    }, { quote: m })
  }
}

plugin.command = ['cekaov']
plugin.category = 'stalk'
plugin.description = 'Cek ID Arena of Valor (AOV) via Sandrocods Public API'
module.exports = plugin
plugin._test = { cleanId, isExplicitInvalidId, parseResponse, lookupAov, cacheGet }
