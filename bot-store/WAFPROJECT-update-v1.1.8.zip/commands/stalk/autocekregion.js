/**
========================
🚀 WAF PROJECT — AUTO CEK REGION MOBILE LEGENDS (ALXPEDIA)
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================

* Auto deteksi pesan ID + Zone tanpa command.
* Hanya react bendera (tidak membalas pesan).
* Format: 757454413 12026 / 757454413 (12026).
* Cache 10 menit + anti double process + deduplikasi request.
* Node.js 18+ (fetch bawaan), CommonJS, tanpa dependensi tambahan.
*
* Catatan: situs pihak ketiga. Gunakan secara wajar dan sesuai kebijakan penyedia.
*/
'use strict'

const BASE = 'https://alxpedia.id'
const PAGE = BASE + '/id/cekml'
const CACHE_MS = 10 * 60 * 1000
const PROCESS_TTL_MS = 60 * 1000
const TIMEOUT_MS = 30 * 1000

const cache = new Map()
const pendingChecks = new Map()
const processedMessages = new Map()

/* ======= PARSER ID & ZONE: STRICT ======= */
function parseIdZoneStrict(input = '') {
  const text = String(input || '').trim()
  if (!text || !/^[0-9()\s]+$/.test(text)) return null

  let match = /^(\d{5,20})\s+(\d{1,10})$/.exec(text)
  if (!match) match = /^(\d{5,20})\s*\(\s*(\d{1,10})\s*\)$/.exec(text)
  return match ? { uid: match[1], zone: match[2] } : null
}

function getMessageText(m) {
  return String(
    m?.text ??
    m?.body ??
    m?.message?.conversation ??
    m?.message?.extendedTextMessage?.text ??
    m?.msg?.text ??
    m?.msg?.conversation ??
    ''
  ).trim()
}

/* ======= ALXPEDIA FORM/SESSION HELPERS ======= */
function getAttr(tag, name) {
  // Mendukung urutan atribut HTML yang berbeda dan petik tunggal/ganda.
  const regex = new RegExp('\\b' + name + '\\s*=\\s*(?:(["\\\'])(.*?)\\1|([^\\s>]+))', 'i')
  const match = String(tag || '').match(regex)
  return match ? String(match[2] ?? match[3] ?? '') : ''
}

function findCsrf(html) {
  for (const tag of html.match(/<input\b[^>]*>/gi) || []) {
    if (getAttr(tag, 'name') === '_token') return getAttr(tag, 'value')
  }
  for (const tag of html.match(/<meta\b[^>]*>/gi) || []) {
    if (getAttr(tag, 'name').toLowerCase() === 'csrf-token') return getAttr(tag, 'content')
  }
  return ''
}

function rememberCookies(headers, jar) {
  const list = typeof headers.getSetCookie === 'function'
    ? headers.getSetCookie()
    : String(headers.get('set-cookie') || '')
      .split(/,(?=\s*[^;,=\s]+=[^;]+)/)
      .filter(Boolean)

  for (const entry of list) {
    const pair = String(entry).split(';', 1)[0].trim()
    const i = pair.indexOf('=')
    if (i > 0) jar.set(pair.slice(0, i), pair.slice(i + 1))
  }
}

function cookieHeader(jar) {
  return [...jar].map(([key, value]) => `${key}=${value}`).join('; ')
}

async function readLimitedText(response) {
  const max = 2_000_000
  const length = Number(response.headers.get('content-length') || 0)
  if (length > max) throw new Error('Halaman ALXPEDIA terlalu besar.')
  const text = await response.text()
  if (text.length > max) throw new Error('Halaman ALXPEDIA terlalu besar.')
  return text
}

function throwForHttp(response, step) {
  if (response.status === 403) throw new Error(`${step}: akses ditolak (HTTP 403).`)
  if (response.status === 419) throw new Error(`${step}: sesi/CSRF kedaluwarsa (HTTP 419).`)
  if (response.status === 429) throw new Error(`${step}: terlalu banyak permintaan (HTTP 429).`)
  if (!response.ok) throw new Error(`${step}: HTTP ${response.status}.`)
}

/* ======= PARSER HASIL: BLOK "AKUN DITEMUKAN" ======= */
function plainHtmlText(html) {
  return String(html || '')
    .replace(/<svg\b[^>]*>[\s\S]*?<\/svg>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&#x27;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim()
}

// Label dan nilainya berasal dari dua <span> dalam baris hasil akun.
function accountField(block, field) {
  const spans = [...block.matchAll(/<span\b[^>]*>([\s\S]*?)<\/span>/gi)]
  const label = String(field).toLowerCase()
  for (let i = 0; i < spans.length - 1; i++) {
    if (plainHtmlText(spans[i][1]).toLowerCase() === label) {
      return plainHtmlText(spans[i + 1][1])
    }
  }
  return ''
}

function parseAccountHtml(html, uid, zone) {
  const safe = String(html || '')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '')

  // FIX: h3 ALXPEDIA dapat berisi ikon/SVG sebelum teks "Akun Ditemukan".
  // Versi lama mengharuskan teks persis setelah pembuka <h3> sehingga
  // menganggap hasil akun tidak ditemukan meskipun pengecekan sukses.
  let start = -1
  const headings = /<h[1-6]\b[^>]*>([\s\S]*?)<\/h[1-6]>/gi
  for (const heading of safe.matchAll(headings)) {
    if (/\bAkun\s+Ditemukan\b/i.test(plainHtmlText(heading[1]))) {
      start = heading.index + heading[0].length
      break
    }
  }

  // Cadangan untuk perubahan markup heading, hanya valid jika ID dan Zone
  // hasil akhirnya cocok dengan pesan masuk.
  if (start < 0) {
    const match = /Akun\s+Ditemukan/i.exec(safe)
    if (match) start = match.index + match[0].length
  }
  if (start < 0) return null

  const block = safe.slice(start, start + 5500)
  const idAndZone = accountField(block, 'ID (Zone)')
  const idMatch = /^(\d{5,20})\s*\(\s*(\d{1,10})\s*\)$/.exec(idAndZone)
  if (!idMatch) {
    throw new Error('Hasil ALXPEDIA ditemukan, tetapi ID (Zone) tidak terbaca.')
  }
  if (idMatch[1] !== uid || idMatch[2] !== zone) {
    throw new Error('ID/Zone hasil ALXPEDIA tidak cocok dengan permintaan.')
  }

  const countryCode = accountField(block, 'Region').toUpperCase().trim()
  if (!/^[A-Z]{2}$/.test(countryCode) || ['XX', 'ZZ'].includes(countryCode)) {
    throw new Error('Kode region pada hasil ALXPEDIA tidak ditemukan/invalid.')
  }

  const nickname = accountField(block, 'Username')
  return { uid, zone, nickname, countryCode }
}

/* ======= ALXPEDIA: GET FORM → POST → FOLLOW SAME-ORIGIN 302 ======= */
async function checkAlxpediaML(uid, zone) {
  const jar = new Map()
  const page = await fetch(PAGE, {
    headers: { Accept: 'text/html' },
    signal: AbortSignal.timeout(TIMEOUT_MS)
  })
  throwForHttp(page, 'Membuka halaman ALXPEDIA')
  rememberCookies(page.headers, jar)
  const token = findCsrf(await readLimitedText(page))
  if (!token) throw new Error('Token CSRF ALXPEDIA tidak ditemukan.')

  const payload = new URLSearchParams({
    _token: token,
    userid: uid,
    zoneid: zone
  })

  const result = await fetch(PAGE, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Accept: 'text/html,application/json',
      Origin: BASE,
      Referer: PAGE,
      ...(jar.size ? { Cookie: cookieHeader(jar) } : {})
    },
    body: payload.toString(),
    redirect: 'manual',
    signal: AbortSignal.timeout(TIMEOUT_MS)
  })
  rememberCookies(result.headers, jar)

  let finalResponse = result
  if ([301, 302, 303].includes(result.status)) {
    const location = result.headers.get('location')
    if (!location) throw new Error('ALXPEDIA redirect tanpa lokasi tujuan.')

    const destination = new URL(location, PAGE)
    if (destination.origin !== BASE || destination.protocol !== 'https:') {
      throw new Error('ALXPEDIA mengarahkan ke alamat di luar situs.')
    }

    finalResponse = await fetch(destination.href, {
      headers: {
        Accept: 'text/html',
        Referer: PAGE,
        ...(jar.size ? { Cookie: cookieHeader(jar) } : {})
      },
      redirect: 'manual',
      signal: AbortSignal.timeout(TIMEOUT_MS)
    })
  }

  throwForHttp(finalResponse, 'Mengambil hasil ALXPEDIA')
  const responseHtml = await readLimitedText(finalResponse)
  const account = parseAccountHtml(responseHtml, uid, zone)
  if (!account) {
    console.warn('[AUTO ML REGION ALXPEDIA DIAGNOSTIC]', {
      postHttp: result.status,
      hasilHttp: finalResponse.status,
      adaTeksAkunDitemukan: /Akun\s+Ditemukan/i.test(responseHtml),
      adaTeksValidasi: /validasi|akun tidak ditemukan|invalid/i.test(responseHtml)
    })
    throw new Error('Halaman hasil ALXPEDIA belum berisi status Akun Ditemukan.')
  }
  return account
}

/* ======= CACHE 10 MENIT + SATU REQUEST PER UID/ZONE ======= */
function cleanupCache(now = Date.now()) {
  for (const [key, entry] of cache) {
    if (entry.expires <= now) cache.delete(key)
  }
  if (cache.size > 1000) cache.clear()
}

async function getAccount(uid, zone) {
  const key = `${uid}|${zone}`
  const now = Date.now()
  cleanupCache(now)
  const hit = cache.get(key)
  if (hit && hit.expires > now) return hit.data
  if (pendingChecks.has(key)) return pendingChecks.get(key)

  const task = checkAlxpediaML(uid, zone)
    .then(data => {
      cache.set(key, { data, expires: Date.now() + CACHE_MS })
      return data
    })
    .finally(() => pendingChecks.delete(key))
  pendingChecks.set(key, task)
  return task
}

function markMessageOnce(m) {
  const now = Date.now()
  for (const [id, timestamp] of processedMessages) {
    if (now - timestamp > PROCESS_TTL_MS) processedMessages.delete(id)
  }
  if (processedMessages.size > 3000) processedMessages.clear()

  const messageId = String(m?.key?.id || m?.id || '')
  if (!messageId) return true
  const key = `${m.chat || ''}|${messageId}`
  if (processedMessages.has(key)) return false
  processedMessages.set(key, now)
  return true
}

function iso2ToFlagEmoji(code) {
  const value = String(code || '').toUpperCase().trim()
  if (!/^[A-Z]{2}$/.test(value)) return ''
  return String.fromCodePoint(...[...value].map(letter =>
    0x1F1E6 + letter.charCodeAt(0) - 65
  ))
}

async function core(m, { wafproject } = {}) {
  if (!m || !wafproject || m.fromMe) return
  const text = getMessageText(m)
  if (!text || /^[.!\/#]/.test(text)) return

  const ids = parseIdZoneStrict(text)
  if (!ids || !markMessageOnce(m)) return

  try {
    const account = await getAccount(ids.uid, ids.zone)
    const flag = iso2ToFlagEmoji(account.countryCode)
    if (!flag) return

    // HANYA emoji reaction, tidak ada balasan teks.
    await wafproject.sendMessage(m.chat, {
      react: { text: flag, key: m.key }
    })
    console.log(`[AUTO ML REGION ALXPEDIA] ${ids.uid} (${ids.zone}) -> ${account.countryCode} ${flag}`)
  } catch (err) {
    // Tidak kirim pesan error atau reaction palsu ke WhatsApp.
    console.error('[AUTO ML REGION ALXPEDIA]', err?.message || err)
  }
}

/* ======= EXPORT: KOMPATIBEL BERBAGAI LOADER ======= */
async function handler(m, ctx) { return core(m, ctx) }
handler.before = async (m, ctx) => core(m, ctx)
handler.all = async (m, ctx) => core(m, ctx)
handler.customPrefix = /^[0-9()\s]+$/
handler.command = /^$/i
handler.category = 'stalk'
handler.description = 'Auto react bendera region Mobile Legends melalui ALXPEDIA'
module.exports = handler
