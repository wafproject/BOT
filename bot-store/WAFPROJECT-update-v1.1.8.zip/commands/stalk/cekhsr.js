/**
 * WAF PROJECT — Cek Honkai: Star Rail via Enka.Network
 * Command: .cekhsr / .cekstarrail <UID>
 * Endpoint: GET https://enka.network/api/hsr/uid/{UID}/
 * Hanya membaca profil publik; tidak perlu akun game / API key.
 * Tidak mengubah bot order, settings.js, saldo, PayKita, ataupun Digiflazz.
 */
'use strict'

const axios = require('axios')

const API_BASE = 'https://enka.network/api/hsr/uid'
const REQUEST_TIMEOUT = 15000
const MAX_RETRIES = 1
const MAX_CACHE_ITEMS = 400
const MAX_CACHE_SECONDS = 600
const DEFAULT_CACHE_SECONDS = 60
const cache = new Map()
const pending = new Map()
const wait = ms => new Promise(resolve => setTimeout(resolve, ms))

function safeText(value, limit = 80) {
  return String(value ?? '')
    .replace(/[\x00-\x1f\x7f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, limit)
}

function serverFromUid(uid) {
  const map = {
    '1': 'China', '2': 'China', '5': 'China',
    '6': 'America', '7': 'Europe', '8': 'Asia', '9': 'TW / HK / MO'
  }
  return map[String(uid)[0]] || 'Tidak diketahui'
}

function formatRegion(raw, uid) {
  const region = safeText(raw, 32).toUpperCase()
  const map = {
    ASIA: 'Asia', EUROPE: 'Europe', USA: 'America', AMERICA: 'America',
    CHINA: 'China', CN: 'China', TW: 'TW / HK / MO',
    'CHT': 'TW / HK / MO', 'OVERSEAS': serverFromUid(uid)
  }
  return region ? (map[region] || safeText(raw, 32)) : serverFromUid(uid)
}

function timeWIB() {
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta', year: 'numeric', month: 'short', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).format(new Date()) + ' WIB'
}

function getCache(uid) {
  const item = cache.get(uid)
  if (!item) return null
  if (Date.now() >= item.until) { cache.delete(uid); return null }
  return item.data
}

function saveCache(uid, data, seconds) {
  const n = Number(seconds)
  const ttl = Number.isFinite(n) && n > 0
    ? Math.min(MAX_CACHE_SECONDS, Math.max(1, Math.floor(n)))
    : DEFAULT_CACHE_SECONDS
  if (cache.size >= MAX_CACHE_ITEMS && !cache.has(uid)) cache.delete(cache.keys().next().value)
  cache.set(uid, { until: Date.now() + ttl * 1000, data })
}

function apiError(status) {
  const text = {
    400: 'Format UID tidak diterima oleh Enka. Periksa UID.',
    403: 'Permintaan ditolak oleh Enka.',
    404: 'Akun tidak ditemukan. Periksa kembali UID Honkai: Star Rail.',
    424: 'Layanan data game sedang maintenance. Coba lagi nanti.',
    429: 'Enka sedang membatasi jumlah request. Coba beberapa menit lagi.',
    500: 'Server Enka sedang mengalami masalah.',
    502: 'Server Enka sementara tidak tersedia.',
    503: 'Server Enka sedang tidak tersedia.'
  }[status] || (status >= 500 ? 'Server Enka sedang bermasalah.' : `Gagal membaca data (HTTP ${status}).`)
  const err = new Error(text)
  err.status = status
  return err
}

function readableError(err) {
  const code = String(err?.code || '')
  if (['ENOTFOUND', 'EAI_AGAIN'].includes(code)) return 'DNS Enka tidak dapat dijangkau dari server bot.'
  if (['ECONNABORTED', 'ETIMEDOUT'].includes(code) || /timeout/i.test(err?.message || '')) {
    return 'Pengecekan melewati batas waktu. Coba lagi nanti.'
  }
  if (code === 'ECONNRESET') return 'Koneksi ke Enka terputus. Coba lagi nanti.'
  return safeText(err?.message || 'Tidak dapat mengecek UID saat ini.', 220)
}

function isTransientNetworkError(err) {
  return ['ETIMEDOUT', 'ECONNRESET', 'ECONNABORTED', 'EAI_AGAIN', 'ENOTFOUND'].includes(String(err?.code || '')) ||
    /timeout|socket hang up/i.test(String(err?.message || ''))
}

function parseHSR(body, uid) {
  // Enka HSR: { detailInfo: { nickname, level, worldLevel, signature }, region, ttl }
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new Error('Respons Enka tidak berupa JSON profil yang valid.')
  }
  const info = body.detailInfo
  const nickname = safeText(info?.nickname, 72)
  if (!info || !nickname) {
    throw new Error('Enka belum mengembalikan nickname akun. Coba lagi nanti.')
  }
  if (info.uid != null && String(info.uid) !== uid) {
    throw new Error('UID pada respons Enka tidak sesuai permintaan.')
  }
  if (body.uid != null && String(body.uid) !== uid) {
    throw new Error('UID pada respons Enka tidak sesuai permintaan.')
  }
  const num = value => value === '' || value == null || !Number.isFinite(Number(value)) ? null : Number(value)
  return {
    uid,
    nickname,
    region: formatRegion(body.region, uid),
    trailblaze: num(info.level),
    equilibrium: num(info.worldLevel),
    bio: safeText(info.signature, 100),
    ttl: body.ttl
  }
}

async function fetchHSR(uid) {
  const cached = getCache(uid)
  if (cached) return cached
  if (pending.has(uid)) return pending.get(uid)

  const job = (async () => {
    let lastErr
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      try {
        const response = await axios.get(`${API_BASE}/${encodeURIComponent(uid)}/`, {
          timeout: REQUEST_TIMEOUT,
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'WAFPROJECT-CekHSR/1.0 (WhatsApp UID checker)'
          },
          validateStatus: () => true
        })
        const status = Number(response?.status || 0)
        if (status < 200 || status >= 300) {
          const error = apiError(status)
          if ((status === 429 || status >= 500) && attempt < MAX_RETRIES) {
            lastErr = error
            const rawRetry = Number(response?.headers?.['retry-after'])
            const delay = status === 429 && Number.isFinite(rawRetry) && rawRetry > 0
              ? Math.min(5000, Math.max(1000, rawRetry * 1000))
              : 1000
            await wait(delay)
            continue
          }
          throw error
        }
        const result = parseHSR(response.data, uid)
        saveCache(uid, result, result.ttl)
        return result
      } catch (err) {
        lastErr = err
        if (err?.status || !isTransientNetworkError(err) || attempt === MAX_RETRIES) break
        await wait(1000)
      }
    }
    throw lastErr || new Error('Gagal terhubung ke Enka.')
  })()
  pending.set(uid, job)
  try { return await job } finally { pending.delete(uid) }
}

async function react(conn, m, emoji) {
  try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) }
  catch (_) { /* Reaksi opsional; jangan ganggu pesan utama */ }
}

function reply(conn, m, message) {
  return conn.sendMessage(m.chat, { text: message }, { quote: m })
}

async function plugin(m, { wafproject, args, text, usedPrefix, command }) {
  if (!/^(cekhsr|cekstarrail)$/i.test(String(command || ''))) return
  const input = (Array.isArray(args) && args.length ? args.join(' ') : (text || '')).trim()
  if (!/^\d{9}$/.test(input)) {
    return reply(wafproject, m,
      `❓ *FORMAT CEK HONKAI: STAR RAIL*\n\n` +
      `Gunakan:\n${usedPrefix || '.'}cekhsr 700358535\n\n` +
      `Masukkan UID HSR (9 digit angka), tanpa ID server.`)
  }

  await react(wafproject, m, '🔎')
  try {
    const result = await fetchHSR(input)
    const level = result.trailblaze == null ? '-' : String(result.trailblaze)
    const eq = result.equilibrium == null ? '-' : String(result.equilibrium)
    const bio = result.bio ? `\n📝 *Bio*               : ${result.bio}` : ''
    const message =
      `🚄 *CHECK AKUN HONKAI: STAR RAIL*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `🆔 *UID*                 : ${result.uid}\n` +
      `👤 *Nickname*       : ${result.nickname}\n` +
      `🌏 *Server*           : ${result.region}\n` +
      `⭐ *Trailblaze Lv*   : ${level}\n` +
      `⚖️ *Equilibrium*    : ${eq}${bio}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `🕒 *Waktu Cek* : ${timeWIB()}`
    await reply(wafproject, m, message)
    await react(wafproject, m, '✅')
  } catch (err) {
    console.error('[CEKHSR ENKA]', err?.status || err?.code || '-', err?.message || err)
    await react(wafproject, m, '❌')
    return reply(wafproject, m,
      `❌ *GAGAL CEK HSR*\n\n${readableError(err)}\n\n` +
      `🆔 UID: ${input}\n\n` +
      `⚠️ Gangguan API tidak selalu berarti UID salah.`)
  }
}

plugin.command = ['cekhsr', 'cekstarrail']
plugin.category = 'stalk'
plugin.description = 'Cek UID & nickname Honkai: Star Rail via Enka.Network'
module.exports = plugin
module.exports._test = { parseHSR, serverFromUid, fetchHSR, formatRegion, getCache }
