/**
 * WAF PROJECT — PUBG Mobile ID Checker
 * Provider: G2Bulk public game ID checker
 * Docs: https://github.com/botsgalaxy/G2Bulk-Public-API-DOC
 * Only performs ID lookup; never creates top-up orders or payments.
 */
'use strict'

const axios = require('axios')

const API_URL = 'https://api.g2bulk.com/v1/games/checkPlayerId'
const API_GAME = 'pubgm' // documented game code for PUBG Mobile
const TIMEOUT_MS = 15000
const CACHE_MS = 5 * 60 * 1000
const cache = new Map()

function shortMessage(value, max = 180) {
  return String(value == null ? '' : value).replace(/[\r\n\t]+/g, ' ').trim().slice(0, max)
}

function wib() {
  return new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }) + ' WIB'
}

async function react(conn, m, emoji) {
  try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) }
  catch (_) { /* WhatsApp reaction is optional */ }
}

class PlayerNotFound extends Error {
  constructor(message = 'Player ID tidak ditemukan.') {
    super(message)
    this.name = 'PlayerNotFound'
  }
}

class ProviderError extends Error {
  constructor(message = 'Layanan pengecekan sedang bermasalah.') {
    super(message)
    this.name = 'ProviderError'
  }
}

function interpretResponse(body, uid, httpStatus) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new ProviderError('Respons API tidak berupa JSON yang diharapkan.')
  }

  const rawValid = body.valid
  const flag = typeof rawValid === 'string' ? rawValid.toLowerCase().trim() : rawValid
  const nickname = shortMessage(body.name || body.nickname || body.player_name || '')
  const reason = shortMessage(body.message || body.msg || body.error || body.detail || '')

  if (httpStatus === 429 || httpStatus >= 500 || httpStatus === 401 || httpStatus === 403) {
    throw new ProviderError(`HTTP ${httpStatus}${reason ? ` — ${reason}` : ''}`)
  }

  // Reject only explicit provider-provided invalid responses.
  if (flag === 'invalid' || flag === 'not_found' || flag === false || body.valid === 0) {
    throw new PlayerNotFound('Player ID dinyatakan tidak valid oleh provider.')
  }

  if (httpStatus >= 400) {
    throw new ProviderError(`HTTP ${httpStatus}${reason ? ` — ${reason}` : ''}`)
  }

  // Never infer that an account exists from HTTP 200 or echoed ID alone.
  if (flag !== 'valid' && flag !== true) {
    throw new ProviderError(`API tidak memberikan status valid yang tegas${reason ? ` — ${reason}` : ''}.`)
  }
  if (!nickname || /^(-|null|undefined|unknown|tidak diketahui)$/i.test(nickname)) {
    throw new ProviderError('API menandai ID valid, tetapi tidak mengembalikan nickname.')
  }

  const returnedUid = body.user_id || body.player_id || body.uid || body.id
  if (returnedUid != null && String(returnedUid) !== String(uid)) {
    throw new ProviderError('ID pada respons API tidak cocok dengan permintaan.')
  }

  return { uid, nickname, provider: 'G2Bulk Public API' }
}

async function checkPUBG(uid) {
  const cached = cache.get(uid)
  if (cached && cached.expiresAt > Date.now()) return { ...cached.data, cached: true }
  cache.delete(uid)

  let response
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      response = await axios.post(API_URL, {
        game: API_GAME,
        user_id: uid
      }, {
        timeout: TIMEOUT_MS,
        validateStatus: () => true,
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
      })
      if (response.status !== 429 && response.status < 500) break
      if (attempt === 0) await new Promise(r => setTimeout(r, 750))
    } catch (error) {
      const code = String(error.code || '')
      if (attempt === 0 && ['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN', 'ECONNABORTED'].includes(code)) {
        await new Promise(r => setTimeout(r, 750))
        continue
      }
      throw new ProviderError(`${code || 'NETWORK'}: ${shortMessage(error.message)}`)
    }
  }

  const data = interpretResponse(response?.data, uid, Number(response?.status || 0))
  cache.set(uid, { data, expiresAt: Date.now() + CACHE_MS })
  if (cache.size > 300) cache.delete(cache.keys().next().value)
  return data
}

async function plugin(m, { wafproject, args, text, usedPrefix, command }) {
  if (!/^(cekpubg|cekpubgm)$/i.test(String(command || ''))) return

  const input = String((args && args.length ? args.join(' ') : text) || '').trim()
  if (!/^\d{7,15}$/.test(input)) {
    return wafproject.sendMessage(m.chat, {
      text: `❓ *FORMAT CEK PUBG MOBILE*\n━━━━━━━━━━━━━━━━━━\nGunakan: *${usedPrefix || '.'}cekpubg 52115806933*\n\nMasukkan Player ID numerik (7–15 digit), bukan nickname.`
    }, { quote: m })
  }

  await react(wafproject, m, '🔎')
  try {
    const account = await checkPUBG(input)
    const result = `🎯 *CEK AKUN PUBG MOBILE*\n━━━━━━━━━━━━━━━━━━\n🆔 *Player ID* : ${account.uid}\n👤 *Nickname* : ${account.nickname}\n🕒 *Waktu Cek* : ${wib()}`
    await wafproject.sendMessage(m.chat, { text: result }, { quote: m })
    await react(wafproject, m, '✅')
  } catch (error) {
    const notFound = error instanceof PlayerNotFound
    console.error('[CEKPUBG]', error.name || 'Error', shortMessage(error.message))
    await react(wafproject, m, '❌')
    const message = notFound
      ? '❌ *PLAYER ID PUBG TIDAK DITEMUKAN*\nPastikan Player ID benar dan bukan nickname.'
      : '⚠️ *CEK PUBG BELUM BERHASIL*\nLayanan pengecekan sedang bermasalah atau memberikan respons yang tidak dapat diverifikasi.\nJangan anggap ID salah sebelum dicoba lagi.\n\n🧩 *Detail:* ' + shortMessage(error.message)
    return wafproject.sendMessage(m.chat, { text: message }, { quote: m })
  }
}

plugin.command = ['cekpubg', 'cekpubgm']
plugin.category = 'stalk'
plugin.description = 'Cek nickname Player ID PUBG Mobile via G2Bulk Public API'
module.exports = plugin

// For isolated unit testing only; does not affect bot plugin loader.
module.exports._test = { interpretResponse, PlayerNotFound, ProviderError }
