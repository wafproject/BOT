/**
 * WAF PROJECT — Cek Mobile Legends (XGameShop) + Bendera Region
 * Command: .cekml <User ID> <Zone ID>
 * Node.js 18+ (fetch bawaan), CommonJS, tanpa dependensi tambahan.
 *
 * Sumber data: halaman pengecekan XGameShop dan endpoint formnya.
 * Endpoint milik pihak ketiga; tetap tunduk pada aturan dan batas akses penyedia.
 */
'use strict'

const BASE = 'https://xgameshop.ai'
const PAGE = BASE + '/groups/mobile-legends-1781470900284?server=6a2f16b4fcb132f08edb0df4'
const ENDPOINT = BASE + '/ml-region-check/check'
const GAME = 'mobile_legends'

const TIMEOUT_MS = 25_000
const CACHE_TTL_MS = 30_000
const CHAT_COOLDOWN_MS = 10_000
const TIERS = ['50', '150', '250', '500']
const cache = new Map()
const inFlight = new Map()
const recentChats = new Map()

function parseIdZone(value = '') {
  const s = String(value ?? '').trim()
  const patterns = [
    /^(\d{5,20})\s+(\d{1,10})$/,
    /^(\d{5,20})\s*\(\s*(\d{1,10})\s*\)$/,
    /^(\d{5,20})\s*\|\s*(\d{1,10})$/
  ]
  for (const pattern of patterns) {
    const m = pattern.exec(s)
    if (m) return { uid: m[1], zone: m[2] }
  }
  return null
}

function htmlDecode(s) {
  return String(s || '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&#x27;/gi, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
}

function attr(tag, name) {
  const pattern = new RegExp('\\b' + name + '\\s*=\\s*(?:(["\\\'])(.*?)\\1|([^\\s>]+))', 'i')
  const m = String(tag).match(pattern)
  return htmlDecode(m?.[2] || m?.[3] || '')
}

function csrfFromHtml(html) {
  for (const tag of html.match(/<meta\b[^>]*>/gi) || []) {
    if (attr(tag, 'name').toLowerCase() === 'csrf-token') return attr(tag, 'content')
  }
  for (const tag of html.match(/<input\b[^>]*>/gi) || []) {
    if (attr(tag, 'name') === '_csrf') return attr(tag, 'value')
  }
  return html.match(/\bcsrfToken\s*=\s*["']([^"']+)["']/i)?.[1] || ''
}

function cookiesFromHeaders(headers) {
  // Menggunakan cookie sesi yang diberikan halaman yang sama, bukan cookie eksternal.
  const entries = typeof headers.getSetCookie === 'function'
    ? headers.getSetCookie()
    : (headers.get('set-cookie') ? [headers.get('set-cookie')] : [])
  return entries.map(line => line.split(';', 1)[0]).filter(Boolean).join('; ')
}

async function readText(response) {
  const raw = await response.text()
  if (raw.length > 3_000_000) throw new Error('Respons penyedia terlalu besar.')
  return raw
}

function providerError(status, data) {
  if (status === 403) return 'Akses pengecekan ditolak penyedia (HTTP 403).'
  if (status === 429) return 'Penyedia sedang membatasi permintaan (HTTP 429). Coba lagi nanti.'
  if (status >= 500) return `Layanan pengecekan sedang bermasalah (HTTP ${status}).`
  const msg = typeof data?.error === 'string' ? data.error
    : typeof data?.message === 'string' ? data.message : ''
  return (msg || `Pengecekan tidak berhasil (HTTP ${status}).`).replace(/[\r\n\t]+/g, ' ').slice(0, 200)
}

async function fetchAccount(uid, zone) {
  const pageResponse = await fetch(PAGE, {
    headers: { Accept: 'text/html' },
    signal: AbortSignal.timeout(TIMEOUT_MS)
  })
  if (!pageResponse.ok) {
    throw new Error(`Halaman pengecekan gagal dibuka (HTTP ${pageResponse.status}).`)
  }
  const cookie = cookiesFromHeaders(pageResponse.headers)
  const csrf = csrfFromHtml(await readText(pageResponse))
  if (!csrf) throw new Error('Token CSRF halaman pengecekan tidak ditemukan.')

  const form = new URLSearchParams({
    player_id: uid,
    zone_id: zone,
    game: GAME,
    _csrf: csrf
  })

  const response = await fetch(ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Accept: 'application/json',
      Origin: BASE,
      Referer: PAGE,
      ...(cookie ? { Cookie: cookie } : {})
    },
    body: form.toString(),
    signal: AbortSignal.timeout(TIMEOUT_MS)
  })

  const raw = await readText(response)
  let data
  try { data = JSON.parse(raw) } catch {
    throw new Error(`Respons pengecekan bukan JSON (HTTP ${response.status}).`)
  }

  if (!response.ok) throw new Error(providerError(response.status, data))
  if (data?.ok !== true || data?.valid !== true) {
    throw new Error(providerError(response.status, data))
  }

  const nickname = String(data.playerName || '').trim()
  if (!nickname) throw new Error('Penyedia tidak mengembalikan nickname pemain.')

  const dd = data.doubleDiamond && typeof data.doubleDiamond === 'object'
    && !Array.isArray(data.doubleDiamond) ? data.doubleDiamond : null
  const statuses = {}
  for (const tier of TIERS) {
    const value = dd && Object.hasOwn(dd, tier) ? dd[tier] : undefined
    statuses[tier] = value === true ? true : value === false ? false : null
  }
  return {
    nickname,
    region: data.showRegion === false ? '' : String(data.region || '').trim(),
    statuses
  }
}

async function getAccount(uid, zone) {
  const key = uid + ':' + zone
  const cached = cache.get(key)
  if (cached && Date.now() < cached.until) return { ...cached.value, cached: true }
  if (inFlight.has(key)) return inFlight.get(key)

  const pending = fetchAccount(uid, zone)
    .then(value => {
      if (cache.size >= 300) cache.clear()
      cache.set(key, { value, until: Date.now() + CACHE_TTL_MS })
      return value
    })
    .finally(() => inFlight.delete(key))
  inFlight.set(key, pending)
  return pending
}

/* ================= BENDERA REGION SEMUA NEGARA ================= */
function normalizeCountryName(value) {
  return String(value ?? '')
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .toLocaleLowerCase('en')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .replace(/\s+/g, ' ')
}

function buildCountryIndex() {
  const lookup = new Map()
  // Nama negara otomatis dari data Intl (Bahasa Indonesia + Inggris).
  // Kode ISO 3166-1 alpha-2 dikonversi menjadi emoji bendera.
  const displayNames = ['id', 'en', 'ms'].map(locale => {
    try { return new Intl.DisplayNames([locale], { type: 'region' }) } catch { return null }
  }).filter(Boolean)

  for (let i = 65; i <= 90; i++) {
    for (let j = 65; j <= 90; j++) {
      const code = String.fromCharCode(i, j)
      for (const names of displayNames) {
        const countryName = names.of(code)
        if (countryName && countryName !== code && countryName !== 'Unknown Region') {
          const normalized = normalizeCountryName(countryName)
          if (normalized && !lookup.has(normalized)) lookup.set(normalized, code)
        }
      }
    }
  }

  // Alias yang sering muncul di website top-up dan variasi terjemahan.
  const aliases = {
    indonesia: 'ID', malaysia: 'MY', singapura: 'SG', singapore: 'SG',
    filipina: 'PH', philippines: 'PH', philipines: 'PH',
    thailand: 'TH', tailandia: 'TH', vietnam: 'VN', 'viet nam': 'VN',
    myanmar: 'MM', burma: 'MM', laos: 'LA', 'lao pdr': 'LA',
    kamboja: 'KH', cambodia: 'KH', brunei: 'BN', 'brunei darussalam': 'BN',
    'timor leste': 'TL', 'timor timur': 'TL', 'east timor': 'TL',
    jepang: 'JP', japan: 'JP', china: 'CN', tiongkok: 'CN',
    'hong kong': 'HK', macau: 'MO', macao: 'MO', taiwan: 'TW',
    'korea selatan': 'KR', 'south korea': 'KR', 'republic of korea': 'KR',
    'korea utara': 'KP', 'north korea': 'KP',
    'united states': 'US', 'united states of america': 'US',
    'amerika serikat': 'US', usa: 'US', 'u s a': 'US',
    'united kingdom': 'GB', britain: 'GB', 'great britain': 'GB', uk: 'GB',
    inggris: 'GB', 'arab saudi': 'SA', 'saudi arabia': 'SA',
    uae: 'AE', 'united arab emirates': 'AE', 'uni emirat arab': 'AE',
    rusia: 'RU', russia: 'RU', 'russian federation': 'RU',
    'selandia baru': 'NZ', 'new zealand': 'NZ',
    belanda: 'NL', netherlands: 'NL', jerman: 'DE', germany: 'DE',
    prancis: 'FR', france: 'FR', spanyol: 'ES', spain: 'ES',
    brasil: 'BR', brazil: 'BR', turki: 'TR', turkey: 'TR', turkiye: 'TR',
    india: 'IN', pakistan: 'PK', bangladesh: 'BD', nepal: 'NP',
    'sri lanka': 'LK', australia: 'AU', mexico: 'MX', meksiko: 'MX'
  }
  for (const [name, code] of Object.entries(aliases)) {
    lookup.set(normalizeCountryName(name), code)
  }
  return lookup
}

const COUNTRY_INDEX = buildCountryIndex()
const VALID_COUNTRY_CODES = new Set(COUNTRY_INDEX.values())

function countryFlag(code) {
  if (!/^[A-Z]{2}$/.test(code)) return ''
  return String.fromCodePoint(
    ...Array.from(code, char => 0x1F1E6 + char.charCodeAt(0) - 65)
  )
}

function formatRegion(region) {
  const label = String(region ?? '').trim()
  if (!label) return '🌏 Tidak tersedia'
  // Jangan menampilkan bendera dua kali jika respons sudah memilikinya.
  if (/^[\u{1F1E6}-\u{1F1FF}]{2}/u.test(label)) return label

  const normalized = normalizeCountryName(label)
  let code = COUNTRY_INDEX.get(normalized)

  // Respons dapat berupa kode negara 'ID' atau 'Indonesia (ID)'.
  if (!code && /^[a-z]{2}$/.test(normalized)) code = normalized.toUpperCase()
  if (!code) {
    const match = /\(([A-Za-z]{2})\)\s*$/.exec(label)
    if (match) code = match[1].toUpperCase()
  }

  // Hindari mengarang bendera untuk region umum seperti "Global" atau "Asia".
  if (!code || !VALID_COUNTRY_CODES.has(code)) return `🌏 ${label}`
  return `${countryFlag(code)} ${label}`
}
/* ================= END BENDERA REGION ================= */

function formatResult(uid, zone, result) {
  const lines = [
    '📊 *CHECK AKUN MOBILE LEGENDS*',
    '',
    `🆔 *User ID*   : ${uid}`,
    `🌐 *Zone ID*   : ${zone}`,
    `👤 *Username*  : ${result.nickname}`,
    `🌏 *Region*    : ${formatRegion(result.region)}`,
    '━━━━━━━━━━━━━━━━━━━━━',
    '💎 *Status Double Diamond:*'
  ]
  for (const tier of TIERS) {
  const available = result.statuses[tier]

  const lock = available === true
    ? '🔓'
    : available === false
      ? '🔒'
      : '⚠️'

  const status = available === true
    ? '✅ Tersedia'
    : available === false
      ? '❌ Tidak tersedia'
      : 'Belum diketahui'

  lines.push(`${lock} ${tier} + ${tier} : ${status}`)
  }
  lines.push('')
  lines.push(`🕒 *Waktu Cek:* ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB`)
  if (result.cached) lines.push('♻️ Hasil tersimpan sementara (maks. 30 detik).')
  return lines.join('\n')
}

async function react(wafproject, m, emoji) {
  if (!m?.key) return
  await wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }).catch(() => {})
}

async function plugin(m, { wafproject, args, text, usedPrefix, command } = {}) {
  if (!/^cekml$/i.test(String(command || ''))) return
  const prefix = usedPrefix || '.'
  const raw = Array.isArray(args) && args.length ? args.join(' ') : text || ''
  const ids = parseIdZone(raw)
  const send = (message) => wafproject.sendMessage(m.chat, { text: message }, { quote: m })

  if (!ids) {
    return send(
      `❓ *Format tidak valid.*\n\n` +
      `Gunakan salah satu format berikut:\n` +
      `• ${prefix}cekml 290188675 9507\n` +
      `• ${prefix}cekml 290188675 (9507)\n` +
      `• ${prefix}cekml 290188675|9507`
    )
  }

  const now = Date.now()
  const chat = String(m.chat || '')
  const last = recentChats.get(chat) || 0
  if (now - last < CHAT_COOLDOWN_MS) {
    const remaining = Math.ceil((CHAT_COOLDOWN_MS - (now - last)) / 1000)
    return send(`⏳ Tunggu ${remaining} detik sebelum mengecek akun lagi.`)
  }
  if (recentChats.size >= 2000) recentChats.clear()
  recentChats.set(chat, now)

  await react(wafproject, m, '🔎')
  try {
    const result = await getAccount(ids.uid, ids.zone)
    await send(formatResult(ids.uid, ids.zone, result))
    await react(wafproject, m, '✅')
  } catch (error) {
    console.error('[CEKML XGAMESHOP]', error?.message || error)
    await react(wafproject, m, '❌')
    const message = /timeout|aborted|fetch failed/i.test(error?.message || '')
      ? 'Koneksi ke layanan pengecekan timeout/terputus. Coba lagi nanti.'
      : String(error?.message || 'Pengecekan gagal.').slice(0, 200)
    return send(`❌ *Gagal cek Mobile Legends*\n${message}`)
  }
}

plugin.command = ['cekml']
plugin.category = 'stalk'
plugin.description = 'Cek nickname, bendera region, dan Double Diamond ML via XGameShop'

module.exports = plugin
