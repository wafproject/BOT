/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
*/

const axios = require('axios')

/* =========================================================
   CONFIG ISAN FREE FIRE API
   ========================================================= */

const ISAN = {
  baseUrl: 'https://api.isan.eu.org',
  path: '/nickname/ff',
  timeout: 20000
}

/* =========================================================
   RETRY — HANYA UNTUK ERROR SEMENTARA
   ========================================================= */

async function withRetry(fn, { retries = 2, baseDelay = 700 } = {}) {
  let lastErr

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err

      const code = err?.code || ''
      const status = err?.response?.status || 0
      const message = String(err?.message || '').toLowerCase()

      const retriable =
        ['ECONNRESET', 'ETIMEDOUT', 'ECONNABORTED', 'EAI_AGAIN', 'ENOTFOUND'].includes(code) ||
        message.includes('socket hang up') ||
        message.includes('timeout') ||
        status === 429 ||
        status >= 500

      if (!retriable || attempt === retries) break

      await new Promise(resolve =>
        setTimeout(resolve, baseDelay * (attempt + 1))
      )
    }
  }

  throw lastErr
}

/* =========================================================
   CHECK FREE FIRE VIA ISAN
   ========================================================= */

async function fetchIsanFF(uid) {
  const res = await withRetry(() =>
    axios.get(`${ISAN.baseUrl}${ISAN.path}`, {
      params: { id: uid },
      headers: {
        Accept: 'application/json',
        'User-Agent': 'WAF-PROJECT/1.0'
      },
      timeout: ISAN.timeout
    })
  )

  const body = res.data

  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new Error('Respons API Free Fire tidak valid')
  }

  if (body.success !== true) {
    throw new Error(
      String(body.message || body.error ||
        'Player ID Free Fire tidak valid atau akun tidak ditemukan')
    )
  }

  const responseUid = String(body.id ?? '').trim()
  if (responseUid && responseUid !== String(uid)) {
    throw new Error('UID dari API tidak cocok dengan Player ID yang diminta')
  }

  const nickname = String(body.name ?? '').trim()
  if (!nickname) {
    throw new Error('Nickname Free Fire tidak ditemukan')
  }

  return {
    uid: String(uid),
    nickname
  }
}

/* =========================================================
   PARSE UID
   ========================================================= */

function parseUid(input = '') {
  const uid = String(input || '').trim()
  return /^\d{5,20}$/.test(uid) ? uid : null
}

/* =========================================================
   WAKTU WIB
   ========================================================= */

function waktu() {
  return new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta'
  })
}

/* =========================================================
   ERROR MESSAGE
   ========================================================= */

function getErrorMessage(err) {
  const data = err?.response?.data

  let message =
    (data && typeof data === 'object' && (data.message || data.error)) ||
    err?.message ||
    'Terjadi kesalahan'

  if (typeof message !== 'string') {
    try {
      message = JSON.stringify(message)
    } catch {
      message = 'Terjadi kesalahan'
    }
  }

  return message.length > 300 ? `${message.slice(0, 300)}...` : message
}

/* =========================================================
   HANDLER
   ========================================================= */

async function plugin(m, { wafproject, args, text, usedPrefix, command }) {
  if (!/^cekff$/i.test(command)) return

  const raw = (
    args && args.length ? args.join(' ') : text || ''
  ).trim()

  const uid = parseUid(raw)

  if (!uid) {
    const pfx = usedPrefix || '.'

    return wafproject.sendMessage(
      m.chat,
      {
        text: `❓ Format tidak valid.\n\nGunakan format:\n• ${pfx}cekff 11616942944`
      },
      { quote: m }
    )
  }

  try {
    await wafproject.sendMessage(
      m.chat,
      { react: { text: '🔎', key: m.key } }
    ).catch(() => {})

    const account = await fetchIsanFF(uid)

    const teks = `📊 *CHECK AKUN FREE FIRE*\n\n` +
      `🆔 *Player ID* : ${account.uid}\n` +
      `👤 *Nickname*  : ${account.nickname}\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `🕒 *Waktu Cek:*\n${waktu()}`

    await wafproject.sendMessage(
      m.chat,
      { text: teks },
      { quote: m }
    )

    await wafproject.sendMessage(
      m.chat,
      { react: { text: '✅', key: m.key } }
    ).catch(() => {})
  } catch (err) {
    await wafproject.sendMessage(
      m.chat,
      { react: { text: '❌', key: m.key } }
    ).catch(() => {})

    console.error(
      '[ERROR][commands/stalk/cekff.js]',
      err?.response?.status || '',
      err?.response?.data || err?.message || err
    )

    return wafproject.sendMessage(
      m.chat,
      { text: `❌ Error: ${getErrorMessage(err)}` },
      { quote: m }
    )
  }
}

/* =========================================================
   PLUGIN INFO
   ========================================================= */

plugin.command = ['cekff']
plugin.category = 'stalk'
plugin.description = 'Cek nickname Free Fire via ISAN API'

module.exports = plugin
