/**
 * WAF PROJECT — CEK AKUN ZENLESS ZONE ZERO (ENKA.NETWORK)
 * Perintah : .cekzzz <UID>
 * Endpoint : https://enka.network/api/zzz/uid/{UID}
 * Node.js CommonJS / axios yang sudah digunakan oleh bot
 * Tidak menggunakan login atau API key; tidak menyentuh order / pembayaran.
 */
'use strict'

const axios = require('axios')

const API_URL = 'https://enka.network/api/zzz/uid'
const API_TIMEOUT = 16000
const CACHE_FALLBACK_SEC = 60
const CACHE_MAX_SEC = 600
const CACHE_LIMIT = 500
const cache = new Map()
const inFlight = new Map()
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

function plain(value, maxLength = 90) {
  return String(value ?? '')
    .replace(/[\x00-\x1f\x7f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength)
}

// Prefix server hanya diturunkan jika cocok dengan pola UID global yang dikenal.
// Untuk UID server lain, kosongkan server; jangan menebak wilayah pemain.
function serverFromUid(uid) {
  if (!/^\d{10}$/.test(String(uid))) return ''
  return ({
    '10': 'America',
    '13': 'Asia',
    '15': 'Europe',
    '17': 'TW / HK / MO'
  })[String(uid).slice(0, 2)] || ''
}

function wibTime() {
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).format(new Date()) + ' WIB'
}

function checkCache(uid) {
  const item = cache.get(uid)
  if (!item) return null
  if (Date.now() >= item.expires) { cache.delete(uid); return null }
  return item.profile
}

function putCache(uid, profile, ttl) {
  const n = Number(ttl)
  const seconds = Number.isFinite(n) && n > 0
    ? Math.max(1, Math.min(CACHE_MAX_SEC, Math.floor(n)))
    : CACHE_FALLBACK_SEC
  if (cache.size >= CACHE_LIMIT && !cache.has(uid)) {
    cache.delete(cache.keys().next().value)
  }
  cache.set(uid, { profile, expires: Date.now() + seconds * 1000 })
}

function httpError(status) {
  const detail = ({
    400: 'Format UID ditolak oleh Enka. Periksa UID ZZZ.',
    403: 'Akses ke layanan Enka ditolak.',
    404: 'UID tidak ditemukan. Periksa kembali UID Zenless Zone Zero.',
    424: 'Layanan data game sedang maintenance. Coba lagi nanti.',
    429: 'Enka sedang membatasi permintaan (rate limit). Coba lagi beberapa menit.',
    500: 'Server Enka sedang bermasalah.',
    502: 'Gateway Enka sedang bermasalah.',
    503: 'Layanan Enka tidak tersedia untuk sementara.'
  })[status] || `Gagal membaca data akun (HTTP ${status}).`
  const err = new Error(detail)
  err.httpStatus = status
  return err
}

function parseZZZ(body, uid) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new Error('Respons Enka tidak berisi data profil yang valid.')
  }
  // Dokumentasi resmi Enka ZZZ: PlayerInfo.SocialDetail.ProfileDetail
  const detail = body.PlayerInfo?.SocialDetail?.ProfileDetail
  if (!detail || typeof detail !== 'object') {
    throw new Error('Enka belum mengembalikan profil akun. Coba beberapa saat lagi.')
  }
  const nickname = plain(detail.Nickname, 72)
  if (!nickname) {
    throw new Error('Enka tidak mengembalikan nickname. Tidak bisa memverifikasi akun ini.')
  }
  for (const claimed of [body.uid, detail.Uid]) {
    if (claimed != null && String(claimed) !== String(uid)) {
      throw new Error('UID dalam respons Enka tidak cocok dengan yang diminta.')
    }
  }
  const level = detail.Level != null && String(detail.Level).trim() !== '' &&
    Number.isFinite(Number(detail.Level)) && Number(detail.Level) >= 0
    ? Number(detail.Level) : null
  return {
    uid: String(uid), nickname, level,
    server: serverFromUid(uid),
    bio: plain(body.PlayerInfo?.SocialDetail?.Desc, 120),
    ttl: body.ttl
  }
}

function transient(err) {
  const code = String(err?.code || '')
  return ['ETIMEDOUT', 'ECONNRESET', 'ECONNABORTED', 'EAI_AGAIN', 'ENOTFOUND'].includes(code) ||
    /timeout|socket hang up/i.test(String(err?.message || ''))
}

function readableError(err) {
  const code = String(err?.code || '')
  if (['ENOTFOUND', 'EAI_AGAIN'].includes(code)) return 'Server bot tidak dapat menemukan alamat Enka (gangguan DNS).'
  if (['ETIMEDOUT', 'ECONNABORTED'].includes(code)) return 'Permintaan ke Enka timeout. Coba lagi nanti.'
  if (code === 'ECONNRESET') return 'Koneksi ke Enka terputus. Coba lagi nanti.'
  return plain(err?.message || 'Pengecekan belum bisa dilakukan.', 220)
}

async function fetchProfile(uid) {
  const hit = checkCache(uid)
  if (hit) return hit
  if (inFlight.has(uid)) return inFlight.get(uid)

  const task = (async () => {
    let error
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await axios.get(`${API_URL}/${encodeURIComponent(uid)}`, {
          timeout: API_TIMEOUT,
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'WAFPROJECT-CekZZZ/1.0 (+WhatsApp bot)'
          },
          validateStatus: () => true
        })
        const status = Number(response?.status || 0)
        if (status < 200 || status >= 300) {
          throw httpError(status)
        }
        const profile = parseZZZ(response.data, uid)
        putCache(uid, profile, profile.ttl)
        return profile
      } catch (err) {
        error = err
        // Jangan mengulang request saat rate-limited.
        const retryableStatus = [500, 502, 503].includes(err?.httpStatus)
        if (attempt === 1 || (!transient(err) && !retryableStatus)) break
        await sleep(700)
      }
    }
    throw error || new Error('Enka tidak merespons.')
  })()

  inFlight.set(uid, task)
  try { return await task } finally { inFlight.delete(uid) }
}

function reply(conn, m, content) {
  return conn.sendMessage(m.chat, { text: content }, { quote: m })
}

async function react(conn, m, emoji) {
  try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) }
  catch (_) { /* emoji tidak wajib */ }
}

async function plugin(m, { wafproject, args, text, usedPrefix, command } = {}) {
  if (!/^cekzzz$/i.test(String(command || ''))) return
  const uid = (Array.isArray(args) && args.length ? args.join(' ') : String(text || '')).trim()
  // 9 digit (beberapa UID China) hingga 12 digit agar fleksibel dengan UID ZZZ.
  if (!/^\d{9,12}$/.test(uid)) {
    return reply(wafproject, m,
      `❓ *FORMAT CEK ZENLESS ZONE ZERO*\n\n` +
      `Gunakan:\n${usedPrefix || '.'}cekzzz 1316621282\n\n` +
      `Masukkan UID ZZZ berupa angka, tanpa spasi atau server.`)
  }

  await react(wafproject, m, '🔎')
  try {
    const profile = await fetchProfile(uid)
    const serverLine = profile.server ? `\n🌏 *Server*         : ${profile.server}` : ''
    const levelLine = profile.level == null ? '' : `\n⭐ *Inter-Knot Lv* : ${profile.level}`
    const bioLine = profile.bio ? `\n📝 *Bio*               : ${profile.bio}` : ''
    const message =
      `🎮 *CEK AKUN ZENLESS ZONE ZERO*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `🆔 *UID*               : ${profile.uid}\n` +
      `👤 *Nickname*     : ${profile.nickname}` +
      `${serverLine}${levelLine}${bioLine}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `🕒 *Waktu Cek* : ${wibTime()}`
    await reply(wafproject, m, message)
    await react(wafproject, m, '✅')
  } catch (err) {
    console.error('[CEKZZZ ENKA]', err?.httpStatus || err?.code || '-', err?.message || err)
    await react(wafproject, m, '❌')
    const heading = err?.httpStatus === 404 ? 'UID ZZZ TIDAK DITEMUKAN' : 'GAGAL CEK ZZZ'
    return reply(wafproject, m,
      `❌ *${heading}*\n\n${readableError(err)}\n\n🆔 UID: ${uid}` +
      (err?.httpStatus === 404 ? '' : '\n\n⚠️ Gangguan API tidak berarti UID salah.'))
  }
}

plugin.command = ['cekzzz']
plugin.category = 'stalk'
plugin.description = 'Cek UID, nickname, dan Inter-Knot Level ZZZ via Enka.Network'
module.exports = plugin
module.exports._test = { parseZZZ, serverFromUid, fetchProfile, readableError }
