/**
 * WAF PROJECT — CEK GENSHIN IMPACT UID (Enka.Network)
 * Command: .cekgi <uid>
 * Sumber: https://github.com/EnkaNetwork/API-docs
 * Tidak memerlukan akun Genshin, cookie, maupun API key.
 * Catatan: Ini API Enka, bukan API RedXGame.
 */
'use strict'

const axios = require('axios')

const API_BASE = 'https://enka.network/api/uid'
const TIMEOUT_MS = 15000
const MAX_CACHE = 300
const CACHE_FALLBACK_SEC = 60
const CACHE_MAX_SEC = 3600
const cache = new Map()
const pause = ms => new Promise(resolve => setTimeout(resolve, ms))

function serverFromUid(uid) {
  const x = String(uid || '')
  if (x.startsWith('18')) return 'Asia'
  switch (x[0]) {
    case '6': return 'America'
    case '7': return 'Europe'
    case '8': return 'Asia'
    case '9': return 'TW / HK / MO'
    case '1': case '2': case '3': case '5': return 'China'
    default: return 'Tidak diketahui'
  }
}

function formatWIB() {
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta', year: 'numeric', month: 'short', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).format(new Date()) + ' WIB'
}

function getCache(uid) {
  const entry = cache.get(uid)
  if (!entry) return null
  if (entry.expireAt <= Date.now()) { cache.delete(uid); return null }
  return entry.data
}
function setCache(uid, data, ttlSec) {
  const ttl = Math.max(30, Math.min(CACHE_MAX_SEC, Number(ttlSec) || CACHE_FALLBACK_SEC))
  if (cache.size >= MAX_CACHE) cache.delete(cache.keys().next().value)
  cache.set(uid, { expireAt: Date.now() + ttl * 1000, data })
}

async function fetchGenshin(uid) {
  const cached = getCache(uid)
  if (cached) return { ...cached, cached: true }

  const url = `${API_BASE}/${encodeURIComponent(uid)}/?info`
  let lastErr
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const rsp = await axios.get(url, {
        timeout: TIMEOUT_MS,
        headers: { 'User-Agent': 'WAFPROJECT-CekGI/1.0 (personal game UID verification)', 'Accept': 'application/json' },
        validateStatus: () => true
      })
      const status = rsp.status
      if (status === 400) throw new Error('Format UID ditolak server Genshin.')
      if (status === 404) throw new Error('UID tidak ditemukan. Periksa kembali angka UID dan region.')
      if (status === 424) throw new Error('Layanan Genshin sedang maintenance. Coba lagi nanti.')
      if (status === 429) throw new Error('Layanan pengecekan sedang dibatasi (rate limit). Coba beberapa menit lagi.')
      if (status >= 500) {
        const e = new Error(`Layanan pengecekan sementara tidak tersedia (HTTP ${status}).`)
        e.retryable = true
        throw e
      }
      if (status < 200 || status >= 300) throw new Error(`Gagal mengecek UID (HTTP ${status}).`)

      const body = rsp.data
      const nickname = String(body?.playerInfo?.nickname || '').trim()
      if (!nickname) throw new Error('Nickname tidak tersedia pada respons API. Silakan coba lagi nanti.')
      const data = { nickname, server: serverFromUid(uid), ar: body?.playerInfo?.level ?? null }
      setCache(uid, data, body?.ttl)
      return data
    } catch (err) {
      lastErr = err
      const code = String(err?.code || '')
      const retryable = err?.retryable || ['ECONNRESET','ETIMEDOUT','EAI_AGAIN'].includes(code)
        || /timeout|socket hang up/i.test(String(err?.message || ''))
      if (!retryable || attempt === 1) break
      await pause(650)
    }
  }
  if (lastErr?.response?.status) throw new Error(`Layanan pengecekan bermasalah (HTTP ${lastErr.response.status}).`)
  if (['ENOTFOUND','EAI_AGAIN'].includes(lastErr?.code)) throw new Error('DNS penyedia pengecekan bermasalah. Coba lagi nanti.')
  if (/timeout|ETIMEDOUT/i.test(String(lastErr?.message || ''))) throw new Error('Pengecekan timeout. Coba lagi nanti.')
  throw lastErr || new Error('Gagal mengecek UID.')
}

async function plugin(m, { wafproject, args, text, usedPrefix, command }) {
  if (!/^cekgi$/i.test(String(command || ''))) return
  const input = (Array.isArray(args) && args.length ? args.join(' ') : text || '').trim()
  if (!/^\d{9,10}$/.test(input)) {
    const prefix = usedPrefix || '.'
    return wafproject.sendMessage(m.chat, {
      text: `❓ *FORMAT CEK GENSHIN*\n\nGunakan:\n${prefix}cekgi 618285856\n\nMasukkan UID Genshin Impact (9–10 digit).`
    }, { quote: m })
  }
  try { await wafproject.sendMessage(m.chat, { react: { text: '🔎', key: m.key } }) } catch (_) {}
  try {
    const result = await fetchGenshin(input)
    const teks = `🎮 *CHECK AKUN GENSHIN IMPACT*\n━━━━━━━━━━━━━━━━━━\n🆔 *UID*       : ${input}\n👤 *Nickname*  : ${result.nickname}\n🌏 *Server*    : ${result.server}\n${result.ar == null ? '' : `🎖️ *Adventure Rank* : ${result.ar}\n`}━━━━━━━━━━━━━━━━━━\n🕒 *Waktu Cek:* ${formatWIB()}`
    await wafproject.sendMessage(m.chat, { text: teks }, { quote: m })
    try { await wafproject.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) } catch (_) {}
  } catch (err) {
    console.error('[ERROR][commands/stalk/cekgi.js]', err?.code || '', err?.message || err)
    try { await wafproject.sendMessage(m.chat, { react: { text: '❌', key: m.key } }) } catch (_) {}
    return wafproject.sendMessage(m.chat, {
      text: `❌ *CEK UID GENSHIN GAGAL*\n\n${String(err?.message || 'Server pengecekan bermasalah.').slice(0, 250)}\n\nPeriksa UID atau coba lagi nanti.`
    }, { quote: m })
  }
}

plugin.command = ['cekgi']
plugin.category = 'stalk'
plugin.description = 'Cek UID Genshin Impact (nickname, region) via Enka.Network'
module.exports = plugin
module.exports._test = { serverFromUid, fetchGenshin, getCache }
