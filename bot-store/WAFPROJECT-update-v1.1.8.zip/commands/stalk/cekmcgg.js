/**
========================
🚀 WAF PROJECT
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================

Cek Magic Chess: Go Go via Buzz Gaming Shop.
Command: .cekmcgg <User ID> <Zone ID>
Node.js 18+ (fetch bawaan, tanpa axios / Puppeteer).
Data berasal dari layanan pihak ketiga; patuhi ketentuan aksesnya.
*/
'use strict'

/* =========================================================
   CONFIG BUZZ GAMING SHOP
   ========================================================= */

const BUZZ = {
  baseUrl: 'https://buzzgamingshop.com',
  page: 'https://buzzgamingshop.com/region-checker',
  endpoint: 'https://buzzgamingshop.com/api/validate-account',
  gameId: 14,
  gameCode: 'magicchess'
}

const TIERS = ['50', '150', '250', '500']
const PAGE_TIMEOUT_MS = 20_000
const API_TIMEOUT_MS = 30_000
const CACHE_TTL_MS = 10 * 60 * 1000
const CACHE_MAX = 500
const cache = new Map()
const pendingChecks = new Map()

/* =========================================================
   RETRY HANYA UNTUK GANGGUAN SEMENTARA
   ========================================================= */

async function withRetry(fn, { retries = 1, delay = 750 } = {}) {
  let lastError
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn()
    } catch (error) {
      lastError = error
      const status = Number(error?.status || 0)
      const message = String(error?.message || '').toLowerCase()
      const temporary =
        status === 429 || status >= 500 ||
        /timeout|fetch failed|socket hang up|econnreset|eai_again/.test(message)
      if (!temporary || attempt === retries) break
      await new Promise(resolve => setTimeout(resolve, delay * (attempt + 1)))
    }
  }
  throw lastError
}

/* =========================================================
   CSRF DAN COOKIE SESI DARI HALAMAN
   ========================================================= */

function htmlAttr(tag, name) {
  const pattern = new RegExp('\\b' + name + '\\s*=\\s*(?:(["\\\'])(.*?)\\1|([^\\s>]+))', 'i')
  const match = String(tag || '').match(pattern)
  return match?.[2] || match?.[3] || ''
}

function csrfFromHtml(html) {
  for (const tag of html.match(/<meta\b[^>]*>/gi) || []) {
    if (htmlAttr(tag, 'name').toLowerCase() === 'csrf-token') {
      return htmlAttr(tag, 'content')
    }
  }
  // Cadangan jika token ditaruh langsung pada fetch() di script halaman.
  return html.match(/["']X-CSRF-TOKEN["']\s*:\s*["']([^"']+)["']/i)?.[1] || ''
}

function cookieFromHeaders(headers) {
  const values = typeof headers.getSetCookie === 'function'
    ? headers.getSetCookie()
    : (headers.get('set-cookie') ? [headers.get('set-cookie')] : [])

  return values
    .map(value => String(value).split(';')[0])
    .filter(value => /^[^=;\s]+=/.test(value))
    .join('; ')
}

async function fetchBuzzMCGG(uid, zone) {
  const page = await fetch(BUZZ.page, {
    headers: { Accept: 'text/html' },
    signal: AbortSignal.timeout(PAGE_TIMEOUT_MS)
  })

  if (!page.ok) {
    const error = new Error(`Halaman Buzz gagal diakses (HTTP ${page.status}).`)
    error.status = page.status
    throw error
  }

  const cookie = cookieFromHeaders(page.headers)
  const html = await page.text()
  const csrf = csrfFromHtml(html)
  if (!csrf) throw new Error('CSRF Buzz tidak ditemukan pada halaman checker.')

  const payload = {
    gameid: BUZZ.gameId,
    game_code: BUZZ.gameCode,
    user_id: String(uid),
    server_id: String(zone),
    skip_region_check: 1
  }

  const response = await fetch(BUZZ.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-TOKEN': csrf,
      Accept: 'application/json',
      Origin: BUZZ.baseUrl,
      Referer: BUZZ.page,
      ...(cookie ? { Cookie: cookie } : {})
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(API_TIMEOUT_MS)
  })

  let data
  try {
    data = await response.json()
  } catch {
    throw new Error(`Respons Buzz bukan JSON (HTTP ${response.status}).`)
  }

  if (!response.ok) {
    const error = new Error(
      response.status === 429
        ? 'Buzz sedang membatasi permintaan (HTTP 429).'
        : response.status === 403
          ? 'Buzz menolak akses pengecekan (HTTP 403).'
          : String(data?.message || data?.error || `Buzz HTTP ${response.status}`).slice(0, 200)
    )
    error.status = response.status
    throw error
  }

  if (data?.is_valid !== true && !(data?.is_valid == null && data?.success === true)) {
    throw new Error(
      String(data?.message || data?.error || 'Akun MCGG tidak ditemukan atau tidak valid.').slice(0, 200)
    )
  }

  // Buzz mengembalikan nickname di "ign", bukan "nickname".
  const nickname = String(data.ign || '').trim() || 'Tidak diketahui'
  const country = String(data.region || '').trim().toUpperCase()
  const regionName = String(data.region_name || '').trim()

  // Buzz menggunakan unavailable_variations untuk paket DD yang tidak tersedia.
  // Jika field tidak diberikan, status harus TIDAK DIKETAHUI, bukan dianggap tersedia.
  const hasBonusData = Array.isArray(data.unavailable_variations)
  const unavailable = new Set()

  if (hasBonusData) {
    for (const entry of data.unavailable_variations) {
      const sku = String(entry || '')
      const match = sku.match(/(?:^|[_-])(50|150|250|500)(?=[_-]|$)/i)
      if (match) unavailable.add(match[1])
    }
  }

  const doubleDiamond = {}
  for (const tier of TIERS) {
    doubleDiamond[tier] = hasBonusData ? !unavailable.has(tier) : null
  }

  return { uid: String(uid), zone: String(zone), nickname, country, regionName, doubleDiamond }
}

/* =========================================================
   CACHE 10 MENIT + ANTI DOUBLE REQUEST
   ========================================================= */

async function getMCGG(uid, zone) {
  const key = `${uid}|${zone}`
  const hit = cache.get(key)
  if (hit && hit.expiresAt > Date.now()) return hit.value
  if (hit) cache.delete(key)

  if (pendingChecks.has(key)) return pendingChecks.get(key)

  const pending = withRetry(() => fetchBuzzMCGG(uid, zone))
    .then(value => {
      if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value)
      cache.set(key, { value, expiresAt: Date.now() + CACHE_TTL_MS })
      return value
    })
    .finally(() => pendingChecks.delete(key))

  pendingChecks.set(key, pending)
  return pending
}

/* =========================================================
   PARSE ID + ZONE
   ========================================================= */

function parseIdZone(input = '') {
  const s = String(input || '').trim()
  const forms = [
    /^(\d{5,20})\s+(\d{1,10})$/,
    /^(\d{5,20})\s*\(\s*(\d{1,10})\s*\)$/,
    /^(\d{5,20})\s*\|\s*(\d{1,10})$/
  ]
  for (const form of forms) {
    const match = s.match(form)
    if (match) return { uid: match[1], zone: match[2] }
  }
  return null
}

/* =========================================================
   REGION, FLAG & WAKTU
   ========================================================= */

function iso2ToFlagEmoji(iso2 = '') {
  const code = String(iso2 || '').trim().toUpperCase()
  if (!/^[A-Z]{2}$/.test(code)) return ''
  return String.fromCodePoint(...[...code].map(c => 0x1F1E6 + c.charCodeAt(0) - 65))
}

function countryName(code = '', providerName = '') {
  if (providerName) return providerName
  if (!/^[A-Z]{2}$/.test(String(code))) return 'Tidak diketahui'
  try {
    return new Intl.DisplayNames(['id'], { type: 'region' }).of(code) || code
  } catch {
    return code
  }
}

function waktu() {
  return new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) + ' WIB'
}

function getErrorMessage(error) {
  const message = String(error?.message || 'Terjadi kesalahan saat cek MCGG.')
  return message.replace(/[\r\n\t]+/g, ' ').slice(0, 250)
}

/* =========================================================
   HANDLER
   ========================================================= */

async function plugin(m, { wafproject, args, text, usedPrefix, command } = {}) {
  if (!/^cekmcgg$/i.test(String(command || ''))) return
  if (!wafproject) return

  const raw = String(Array.isArray(args) && args.length ? args.join(' ') : (text || '')).trim()
  const parsed = parseIdZone(raw)
  const send = text => wafproject.sendMessage(m.chat, { text }, { quoted: m })
  const react = async emoji => {
    if (m?.key) {
      await wafproject.sendMessage(m.chat, {
        react: { text: emoji, key: m.key }
      }).catch(() => {})
    }
  }

  if (!parsed) {
    const prefix = usedPrefix || '.'
    return send(
      `❓ *Format tidak valid.*\n\n` +
      `• ${prefix}cekmcgg 14080077 4155\n` +
      `• ${prefix}cekmcgg 14080077 (4155)\n` +
      `• ${prefix}cekmcgg 14080077|4155`
    )
  }

  const { uid, zone } = parsed
  await react('🔎')

  try {
    const account = await getMCGG(uid, zone)
    const flag = iso2ToFlagEmoji(account.country)
    const region = countryName(account.country, account.regionName)

    const bonusLines = TIERS.map(tier => {
      const available = account.doubleDiamond[tier]
      return available === true
        ? `🔓 ${tier} + ${tier} : ✅ Tersedia`
        : available === false
          ? `🔒 ${tier} + ${tier} : ❌ Tidak tersedia`
          : `⚠️ ${tier} + ${tier} : Belum diketahui`
    }).join('\n')

    const result = `📊 *CHECK AKUN MAGIC CHESS GO GO*\n\n` +
      `🆔 *User ID*   : ${uid}\n` +
      `🌐 *Zone ID*   : ${zone}\n` +
      `👤 *Username*  : ${account.nickname}\n` +
      `🌏 *Region*    : ${flag ? `${flag} ` : ''}${region}\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `💎 *Status Double Diamond:*\n${bonusLines}\n\n` +
      `🕒 *Waktu Cek:*\n${waktu()}`

    await send(result)
    await react('✅')
  } catch (error) {
    console.error('[ERROR][commands/stalk/cekmcgg.js][BUZZ]', error?.message || error)
    await react('❌')
    return send(`❌ Error: ${getErrorMessage(error)}`)
  }
}

plugin.command = ['cekmcgg']
plugin.category = 'stalk'
plugin.description = 'Cek akun Magic Chess Go Go + region + Double Diamond via Buzz Gaming Shop'

module.exports = plugin
