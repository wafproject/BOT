/**
 * WAF PROJECT — CEK POINT BLANK (ZEPETTO ID)
 *
 * Provider utama: sandrocods (public game ID API)
 * Dokumentasi: https://github.com/sandrocods/api-cek-id-game
 * Opsional fallback: Evo Game Check (requires own free API key)
 * Dokumentasi: https://gamecheck.evogamestore.com/
 *
 * Tidak menggunakan API Isan, dan tidak mengubah sistem order.
 * API publik pihak ketiga bisa berubah; gangguan API bukan bukti ID salah.
 */
'use strict'
const axios = require('axios')

const PUBLIC_ENDPOINT = 'https://api-cek-id-game-ten.vercel.app/api/check-id-game'
const EVO_ENDPOINT = 'https://gamecheck.evogamestore.com/api/v1/check'
const TIMEOUT_MS = 14000
const CACHE_MS = 5 * 60 * 1000
const CACHE_MAX = 200
const cache = new Map()

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
const valueStr = v => (v === undefined || v === null ? '' : String(v).trim())

function errorOf(kind, message) {
  const e = new Error(message)
  e.kind = kind
  return e
}
function isRetriable(error) {
  const status = error?.response?.status || 0
  return [429, 502, 503, 504].includes(status) ||
    ['ETIMEDOUT', 'ECONNRESET', 'EAI_AGAIN', 'ECONNABORTED'].includes(error?.code) ||
    /timeout|socket hang up/i.test(valueStr(error?.message))
}
async function retryRequest(fn) {
  try { return await fn() }
  catch (e) {
    if (!isRetriable(e)) throw e
    await sleep(650)
    return fn()
  }
}
function getCached(id) {
  const saved = cache.get(id.toLowerCase())
  if (!saved) return null
  if (saved.at + CACHE_MS < Date.now()) { cache.delete(id.toLowerCase()); return null }
  return saved
}
function saveCached(id, nickname, provider) {
  const key = id.toLowerCase()
  if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value)
  cache.set(key, { nickname, provider, at: Date.now() })
}

function normalizeResult(body, provider) {
  if (!body || typeof body !== 'object') {
    throw errorOf('provider', `${provider}: respons API tidak valid.`)
  }
  if (body.status === true) {
    const name = valueStr(body.nickname || body.username || body.data?.nickname || body.data?.username)
    if (!name || /^(-|null|undefined|unknown|tidak diketahui)$/i.test(name)) {
      throw errorOf('provider', `${provider}: API tidak mengembalikan nickname.`)
    }
    return name
  }
  if (body.status === false) {
    const msg = valueStr(body.message || body.error || body.errorMsg)
    if (/useridnoteligible|account not found|user not found|id.*not found|tidak ditemukan|invalid user.?id/i.test(msg)) {
      throw errorOf('not_found', `${provider}: ID Zepetto tidak ditemukan.`)
    }
    throw errorOf('provider', `${provider}: ${msg || 'layanan belum bisa memverifikasi akun.'}`)
  }
  throw errorOf('provider', `${provider}: format respons berubah.`)
}

async function publicLookup(id) {
  let res
  try {
    res = await retryRequest(() => axios.post(PUBLIC_ENDPOINT,
      { type_name: 'point_blank', userId: id, zoneId: '' },
      { timeout: TIMEOUT_MS, headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, validateStatus: () => true }
    ))
  } catch (err) { throw errorOf('provider', `API publik tidak dapat dihubungi (${err?.code || err?.message || 'network error'}).`) }

  if (res.status < 200 || res.status >= 300) {
    throw errorOf('provider', `API publik HTTP ${res.status}.`)
  }
  return normalizeResult(res.data, 'API publik')
}

function evoKey() {
  return valueStr(process.env.EVO_GAMECHECK_API_KEY || global.evoGamecheckApiKey)
}
async function evoLookup(id) {
  const key = evoKey()
  if (!key) throw errorOf('provider', 'API key Evo belum dikonfigurasi.')
  let res
  try {
    res = await retryRequest(() => axios.post(EVO_ENDPOINT,
      { game: 'point-blank', user_id: id },
      { timeout: TIMEOUT_MS, headers: { 'Content-Type': 'application/json', 'X-API-Key': key }, validateStatus: () => true }
    ))
  } catch (err) { throw errorOf('provider', `Evo API tidak dapat dihubungi (${err?.code || err?.message || 'network error'}).`) }

  const status = valueStr(res.data?.status).toLowerCase()
  if (res.status === 404 && status === 'not_found') throw errorOf('not_found', 'ID Zepetto tidak ditemukan (Evo).')
  if (res.status < 200 || res.status >= 300 || status !== 'success') {
    const msg = valueStr(res.data?.message)
    throw errorOf('provider', `Evo API HTTP ${res.status}${msg ? `: ${msg}` : ''}.`)
  }
  const nick = valueStr(res.data?.data?.username)
  if (!nick) throw errorOf('provider', 'Evo API mengembalikan nickname kosong.')
  return nick
}

async function lookupPointBlank(id) {
  const cached = getCached(id)
  if (cached) return { ...cached, cached: true }
  const key = evoKey()
  // Kalau pengguna sudah memasang key Evo, pakai terlebih dahulu API yang terbaru.
  const sources = key
    ? [{ name: 'Evo Game Check', run: evoLookup }, { name: 'Public API', run: publicLookup }]
    : [{ name: 'Public API', run: publicLookup }]
  const errors = []
  for (const source of sources) {
    try {
      const nickname = await source.run(id)
      saveCached(id, nickname, source.name)
      return { nickname, provider: source.name, cached: false }
    } catch (e) {
      errors.push({ source: source.name, type: e.kind || 'provider', message: valueStr(e.message) })
    }
  }
  // Jangan menyebut ID tidak valid jika ada satu sumber yang gagal teknis.
  const notFound = errors.length > 0 && errors.every(e => e.type === 'not_found')
  const error = errorOf(notFound ? 'not_found' : 'provider', notFound
    ? 'ID Zepetto tidak ditemukan. Pastikan memakai ID login, bukan nickname karakter.'
    : 'Layanan pengecekan Point Blank sedang bermasalah. Coba lagi nanti.')
  error.details = errors
  throw error
}

function cleanId(input) {
  const value = valueStr(input)
  // ID login Zepetto berupa teks; format ini membatasi karakter spesial berisiko.
  if (!/^[a-zA-Z0-9_.-]{3,25}$/.test(value)) return null
  return value
}
function waktuWIB() {
  return new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }) + ' WIB'
}

async function reactSafe(conn, m, emoji) {
  try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) }
  catch { /* Reaksi gagal tidak mematikan pemeriksaan */ }
}
async function plugin(m, { wafproject, args = [], text = '', usedPrefix = '.', command = '' } = {}) {
  if (!/^cekpb$/i.test(command)) return
  const raw = (Array.isArray(args) && args.length ? args.join(' ') : valueStr(text)).trim()
  const id = cleanId(raw)
  if (!id) {
    return wafproject.sendMessage(m.chat, {
      text: `❓ *FORMAT CEK POINT BLANK*\n\nGunakan:\n${usedPrefix || '.'}cekpb zepidqa34\n\nMasukkan *ID login Zepetto* (bukan nickname karakter dan bukan password).\nID hanya boleh huruf, angka, _ . - sepanjang 3–25 karakter.`
    }, { quote: m })
  }
  await reactSafe(wafproject, m, '🔎')
  try {
    const result = await lookupPointBlank(id)
    const message = `🎯 *CEK AKUN POINT BLANK*\n━━━━━━━━━━━━━━━━━━\n🆔 *Zepetto ID* : ${id}\n👤 *Username*   : ${result.nickname}\n🕒 *Waktu Cek* : ${waktuWIB()}`
    await wafproject.sendMessage(m.chat, { text: message }, { quote: m })
    await reactSafe(wafproject, m, '✅')
  } catch (err) {
    console.error('[CEKPB]', JSON.stringify({ id, reason: err.kind || 'provider', details: err.details || [err.message] }))
    await reactSafe(wafproject, m, '❌')
    return wafproject.sendMessage(m.chat, {
      text: err.kind === 'not_found'
        ? '❌ *ID POINT BLANK TIDAK DITEMUKAN*\nPastikan yang dimasukkan adalah ID login Zepetto, bukan nickname karakter.'
        : '⚠️ *CEK ID POINT BLANK GAGAL*\nLayanan pengecekan sedang bermasalah. Belum dapat dipastikan ID benar atau salah. Silakan coba lagi nanti.'
    }, { quote: m })
  }
}

plugin.command = ['cekpb']
plugin.category = 'stalk'
plugin.description = 'Cek ID login Point Blank Zepetto via public API (opsional fallback Evo)'
module.exports = plugin
// Expose helper only for automated test; does not change plugin behavior.
plugin._test = { cleanId, normalizeResult, lookupPointBlank, publicLookup, evoLookup }
