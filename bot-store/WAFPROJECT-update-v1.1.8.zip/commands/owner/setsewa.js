/**
 * Plugin SEWA BOT — CJS
 * Penyimpanan tetap: database/sewa.json
 * Semua perubahan data melewati lib/sewa-store agar tidak saling menimpa.
 */

"use strict"

const {
  readSewaResult,
  updateSewa,
} = require("../../lib/sewa-store")

const linkRegex = /chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})(?:[?#/]|\s|$)/i
// Grup lama memakai format "<nomor>-<timestamp>@g.us", grup baru "1203...@g.us".
const groupJidRegex = /^\d+(?:-\d+)?@g\.us$/i

function isValidGroupJid(value) {
  return groupJidRegex.test(String(value || ""))
}

// Terima "1203...@g.us", "1203..." (tanpa suffix), atau "628xx-123@g.us".
function toGroupJid(value) {
  const raw = String(value || "").trim().replace(/:\d+@/, "@")
  if (!raw) return null
  if (isValidGroupJid(raw)) return raw
  if (/^\d+(?:-\d+)?$/.test(raw) && raw.length >= 10) return `${raw}@g.us`
  return null
}

function activeSewaEntries(data, now = Date.now()) {
  return Object.entries(data || {}).filter(([, row]) => Number(row?.expired || 0) > now)
}

function groupIdFromInviteInfo(info) {
  const direct = [
    info?.jid,
    info?.id,
    info?.groupJid,
    info?.group_id,
    info?.groupId,
    info?.gid,
    info?.group?.jid,
    info?.group?.id,
    info?.attrs?.id,
    info?.metadata?.id,
  ]
  for (const value of direct) {
    const jid = toGroupJid(value)
    if (jid) return jid
  }
  return null
}

function normalizeSubject(value) {
  return String(value || "")
    .normalize("NFC")
    .replace(/[​-‍︎️]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase()
}

function collectGroupList(groups) {
  if (!groups) return []
  const list = Array.isArray(groups)
    ? groups.map((meta) => [meta?.id || meta?.jid, meta])
    : Object.entries(groups).map(([gid, meta]) => [meta?.id || meta?.jid || gid, meta])
  return list
    .map(([gid, meta]) => [toGroupJid(gid), meta])
    .filter(([gid]) => !!gid)
}

/**
 * Cari JID grup yang SUDAH diikuti bot berdasarkan subject undangan.
 * Bot yang ikut banyak grup butuh waktu lebih lama untuk groupFetchAllParticipating,
 * jadi timeout dibuat longgar dan dicoba dua kali.
 */
async function findJoinedGroupBySubject(wafproject, subject, { size = 0 } = {}) {
  const wanted = normalizeSubject(subject)
  if (!wanted || typeof wafproject.groupFetchAllParticipating !== "function") return null

  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const groups = await withTimeout(wafproject.groupFetchAllParticipating(), 15000, null)
      const list = collectGroupList(groups)
      if (list.length) {
        let matches = list.filter(([, meta]) => normalizeSubject(meta?.subject) === wanted)

        // Nama sama di beberapa grup: persempit memakai jumlah anggota dari preview link.
        if (matches.length > 1 && Number(size) > 0) {
          const bySize = matches.filter(([, meta]) => {
            const count = Array.isArray(meta?.participants) ? meta.participants.length : Number(meta?.size || 0)
            return count === Number(size)
          })
          if (bySize.length === 1) matches = bySize
        }

        if (matches.length === 1) return matches[0][0]
        if (matches.length > 1) return null // ambigu, jangan menebak
      }
    } catch (error) {
      console.error("[ADDSEWA FIND GROUP]", error?.message || error)
    }
    if (attempt < 2) await new Promise((resolve) => setTimeout(resolve, 1500))
  }
  return null
}

function errorText(error) {
  return String(error?.message || error?.output?.payload?.message || error || "Unknown Error")
}

function inviteErrorCode(error) {
  const text = errorText(error)
  const fromText = text.match(/\((\d{3})\s*:/) || text.match(/\b(40[0-9]|41[0-9]|429|500)\b/)
  const code = Number(error?.output?.statusCode || error?.data?.code || error?.code || (fromText && fromText[1]) || 0)
  if (code) return code
  if (/conflict|already/i.test(text)) return 409
  if (/not.?authori[sz]ed/i.test(text)) return 401
  return 0
}

function isAlreadyMemberError(error) {
  return inviteErrorCode(error) === 409 || /already.?(?:a.?)?(?:participant|member)|conflict/i.test(errorText(error))
}

function explainInviteError(error) {
  switch (inviteErrorCode(error)) {
    case 401:
      return "Nomor bot tidak diizinkan memakai link ini. Biasanya karena bot pernah dikeluarkan admin dari grup itu, atau link sudah direset."
    case 403:
      return "Bot ditolak masuk (grup penuh, dibatasi admin, atau nomor bot dibatasi WhatsApp)."
    case 404:
    case 406:
    case 410:
      return "Link sudah direset / kadaluarsa. Minta link baru ke admin grup."
    case 409:
      return "Bot sudah menjadi anggota grup ini."
    case 429:
      return "Terlalu banyak permintaan ke WhatsApp. Tunggu beberapa menit lalu coba lagi."
    default:
      return "WhatsApp menolak permintaan ini."
  }
}

function manualGuide(usedPrefix, durasiArg) {
  return (
    `💡 *Cara aman tanpa link:*\n` +
    `1. Minta admin grup menambahkan nomor bot lewat *Tambah anggota*.\n` +
    `2. Owner ketik di grup itu: ${usedPrefix}addsewa ${durasiArg || "30d"}\n` +
    `   atau dari mana saja: ${usedPrefix}addsewa <idgrup> ${durasiArg || "30d"}`
  )
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

function withTimeout(promise, timeoutMs, fallback = null) {
  let timer
  return Promise.race([
    Promise.resolve(promise),
    new Promise((resolve) => {
      timer = setTimeout(() => resolve(fallback), timeoutMs)
    }),
  ]).finally(() => clearTimeout(timer))
}

function setBypass(gid, durationMs = 90_000) {
  if (!gid) return
  global.__antiCulikBypass ||= {}
  global.__antiCulikBypass[gid] = Date.now() + durationMs
}

function clearBypass(gid) {
  if (!gid || !global.__antiCulikBypass) return
  delete global.__antiCulikBypass[gid]
}

async function getGroupName(wafproject, gid, fallback = "Unknown") {
  try {
    const meta = await withTimeout(wafproject.groupMetadata(gid), 2500, null)
    return meta?.subject || fallback
  } catch {
    return fallback
  }
}

function isTerminalLeaveError(error) {
  const text = String(
    error?.message || error?.output?.payload?.message || error || ""
  ).toLowerCase()
  return /not.?authorized|not.?a.?participant|forbidden|item.?not.?found|status.?code.?40[34]/i.test(text)
}

// Pemeriksa sewa habis. Socket selalu diambil saat interval berjalan,
// bukan menyimpan socket lama saat reconnect.
if (!global.__sewaIntervalStarted) {
  global.__sewaIntervalStarted = true
  global.__sewaExpiryRunning = false

  setInterval(async () => {
    if (global.__sewaExpiryRunning) return
    const wafproject = global.__sewaConn || global.wafproject || global.conn
    if (!wafproject) return

    global.__sewaExpiryRunning = true
    try {
      const read = readSewaResult({ allowCached: false })
      if (!read.ok) {
        console.error("[SEWA EXPIRED] database gagal dibaca; proses leave dibatalkan:", read.error?.message || read.error)
        return
      }

      const now = Date.now()
      const expiredGroups = Object.entries(read.data)
        .filter(([, row]) => Number(row?.expired || 0) > 0 && Number(row.expired) <= now)
        .map(([gid]) => gid)

      for (const gid of expiredGroups) {
        let mayDelete = false
        try {
          await wafproject.sendMessage(gid, {
            text: "⏰ *Waktu sewa bot habis!*\nBot akan keluar dari grup."
          })
          await wafproject.groupLeave(gid)
          mayDelete = true
          console.log(`[SEWA EXPIRED] ${gid} — bot berhasil keluar`)
        } catch (error) {
          mayDelete = isTerminalLeaveError(error)
          console.error(
            `[SEWA EXPIRED] ${gid} — gagal keluar${mayDelete ? " (record tetap dibersihkan karena bot bukan anggota)" : ", akan dicoba lagi"}:`,
            error?.message || error
          )
        }

        if (!mayDelete) continue

        try {
          await updateSewa((data) => {
            // Jangan menghapus bila owner/pembayaran sudah memperpanjang saat proses leave.
            if (Number(data?.[gid]?.expired || 0) <= Date.now()) delete data[gid]
          })
        } catch (error) {
          console.error(`[SEWA EXPIRED] ${gid} — gagal menghapus record:`, error?.message || error)
        }
      }
    } finally {
      global.__sewaExpiryRunning = false
    }
  }, 10_000)
}

let handler = async (m, { wafproject, command, args, groupMetadata, usedPrefix }) => {
  global.__sewaConn = wafproject
  const idChat = m.chat

  switch (command) {
    case "addsewa": {
      if (!args[0]) {
        return wafproject.sendMessage(idChat, {
          text:
            `❌ Format Salah!\n\n` +
            `Di grup target:\n${usedPrefix}addsewa 30d\n\n` +
            `Dari chat mana pun:\n${usedPrefix}addsewa <idgrup> 30d\n` +
            `${usedPrefix}addsewa <linkgc> 30d`
        })
      }

      let targetID = idChat
      let durasiArg = args[0]
      let namaGrup = groupMetadata?.subject || "Unknown"
      let bypassSetFor = null
      let inviteCode = null

      // Mode link undangan.
      const linkMatch = String(args[0]).match(linkRegex)
      if (linkMatch) {
        inviteCode = linkMatch[1]
        if (!args[1]) {
          return wafproject.sendMessage(idChat, {
            text: "❌ Durasi tidak ditemukan!\nContoh: 30d"
          })
        }
        durasiArg = args[1]

        if (!parseDuration(durasiArg)) {
          return wafproject.sendMessage(idChat, { text: "❌ Format durasi salah!\nContoh: 30d, 12h, 1d12h" })
        }

        // 1) Preview link. Error 401/5xx kadang hanya sesaat, jadi dicoba ulang sekali.
        let info = null
        let infoError = null
        for (let attempt = 1; attempt <= 2; attempt++) {
          try {
            info = await wafproject.groupGetInviteInfo(inviteCode)
            infoError = null
            break
          } catch (error) {
            infoError = error
            console.error(`[ADDSEWA INVITE ERROR] percobaan ${attempt}:`, errorText(error))
            const code = inviteErrorCode(error)
            // Link mati (404/406/410) tidak perlu dicoba ulang.
            if ([404, 406, 410].includes(code)) break
            if (attempt < 2) await sleep(2000)
          }
        }

        if (info) {
          // queryGroupInviteInfo pada Zapo adalah preview dan tidak selalu membawa JID grup.
          // Jangan pernah menyimpan sewa memakai key kosong.
          targetID = groupIdFromInviteInfo(info)
          namaGrup = info?.subject || namaGrup
        }
        const inviteSize = Number(info?.size || info?.participantCount || info?.participants?.length || 0)

        // Jika bot ternyata sudah berada di grup, resolve dari daftar grup berdasarkan subject.
        if (!targetID && info?.subject) {
          targetID = await findJoinedGroupBySubject(wafproject, namaGrup, { size: inviteSize })
        }

        let alreadyJoined = false
        if (isValidGroupJid(targetID)) {
          setBypass(targetID)
          bypassSetFor = targetID
          try {
            const meta = await withTimeout(wafproject.groupMetadata(targetID), 5000, null)
            if (meta) {
              alreadyJoined = true
              namaGrup = meta.subject || namaGrup
            }
          } catch (_error) { console.error("[ERROR][commands/owner/setsewa.js]", _error?.message || _error) }
        }

        // 2) Join. Tetap dicoba walau preview gagal, karena error preview bisa sesaat.
        if (!alreadyJoined) {
          let joinError = null
          try {
            const res = await wafproject.groupAcceptInvite(inviteCode)
            const joinedID = toGroupJid(res?.id || res?.jid || res)
            targetID = joinedID || targetID

            // Zapo 1.9.x pada beberapa akun bisa mengembalikan IQ ack yang membuat
            // parser join melempar error walau join sebenarnya sukses. Adapter punya
            // recovery, tapi lakukan verifikasi kedua di sini juga.
            if (!isValidGroupJid(targetID)) {
              targetID = await findJoinedGroupBySubject(wafproject, namaGrup, { size: inviteSize })
            }
            if (!isValidGroupJid(targetID)) {
              throw new Error("Join berhasil tetapi ID grup tidak dapat di-resolve")
            }
          } catch (error) {
            joinError = error
            console.error("[ADDSEWA JOIN ERROR]", errorText(error))
          }

          if (joinError) {
            const alreadyMember = isAlreadyMemberError(joinError)

            // 409 = bot SUDAH anggota grup. Ini bukan kegagalan: cukup temukan ID grupnya.
            // Error lain: bila join sebenarnya sukses tetapi library melempar error parser,
            // grup akan muncul di daftar participating.
            let recoveredID = isValidGroupJid(targetID) ? targetID : null
            if (!recoveredID && info?.subject) {
              recoveredID = await findJoinedGroupBySubject(wafproject, namaGrup, { size: inviteSize })
            }

            if (isValidGroupJid(recoveredID)) {
              targetID = recoveredID
              if (alreadyMember) console.log(`[ADDSEWA] bot sudah anggota ${targetID}; sewa langsung diaktifkan`)
            } else {
              clearBypass(bypassSetFor)
              // Jangan membuat record dengan key kosong / status pending. Tanpa JID grup,
              // record tidak dapat dipakai gerbang sewa, anti-culik, maupun delsewa.
              const firstError = alreadyMember ? joinError : (infoError || joinError)
              const headline = alreadyMember
                ? `⚠️ Bot *sudah ada* di grup ini, tapi ID grupnya tidak bisa dipastikan dari link.`
                : `❌ Bot gagal masuk lewat link.`
              return wafproject.sendMessage(idChat, {
                text:
                  `${headline}\n\n` +
                  `👥 Grup: *${namaGrup}*\n` +
                  `⏰ Durasi: *${durasiArg}*\n\n` +
                  `Penyebab: ${explainInviteError(firstError)}\n` +
                  `Detail: ${errorText(firstError)}\n\n` +
                  `Sewa *belum dicatat*.\n\n` +
                  (alreadyMember
                    ? `💡 Ketik di grup itu: ${usedPrefix}addsewa ${durasiArg}`
                    : manualGuide(usedPrefix, durasiArg))
              })
            }
          }

          if (bypassSetFor !== targetID) {
            clearBypass(bypassSetFor)
            setBypass(targetID)
            bypassSetFor = targetID
          }
          namaGrup = await getGroupName(wafproject, targetID, namaGrup)
        }
      } else if (groupJidRegex.test(String(args[0]))) {
        // Mode ID grup, digunakan juga oleh pesan peringatan anti-culik.
        if (!args[1]) {
          return wafproject.sendMessage(idChat, {
            text: "❌ Durasi tidak ditemukan!\nContoh: .addsewa 120363xxxx@g.us 30d"
          })
        }
        targetID = String(args[0])
        durasiArg = args[1]
        namaGrup = await getGroupName(wafproject, targetID, namaGrup)
      } else if (!String(idChat).endsWith("@g.us")) {
        return wafproject.sendMessage(idChat, {
          text:
            `❌ Dari private chat, gunakan ID atau link grup.\n\n` +
            `${usedPrefix}addsewa 120363xxxx@g.us 30d\n` +
            `${usedPrefix}addsewa https://chat.whatsapp.com/xxxx 30d`
        })
      }

      const ms = parseDuration(durasiArg)
      if (!ms) {
        clearBypass(bypassSetFor)
        return wafproject.sendMessage(idChat, { text: "❌ Format durasi salah!" })
      }

      const expired = Date.now() + ms
      try {
        await updateSewa((data) => {
          data[targetID] = {
            name: namaGrup,
            expired,
            status: "active",
            createdAt: Date.now()
          }
        })
      } catch (error) {
        clearBypass(bypassSetFor)
        return wafproject.sendMessage(idChat, {
          text: `❌ Gagal menyimpan sewa: ${error?.message || error}`
        })
      }

      clearBypass(bypassSetFor)

      return wafproject.sendMessage(idChat, {
        text:
          `✅ Sewa berhasil ditambahkan.\n\n` +
          `👥 Grup: *${namaGrup}*\n` +
          `🆔 ID: ${targetID}\n` +
          `⏰ Durasi: *${durasiArg}*\n` +
          `📅 Expired: *${new Date(expired).toLocaleString()}*`
      })
    }

    case "tambahsewa": {
      if (!args[0] || !args[1]) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Format salah!\n\nContoh:\n${usedPrefix}tambahsewa 1 30d`
        })
      }

      const read = readSewaResult({ allowCached: false })
      if (!read.ok) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Database sewa gagal dibaca: ${read.error?.message || read.error}`
        })
      }

      const index = parseInt(args[0], 10) - 1
      const tambahan = parseDuration(args[1])
      const gid = activeSewaEntries(read.data)[index]?.[0]
      if (!gid || !tambahan) {
        return wafproject.sendMessage(idChat, { text: "❌ Nomor atau durasi tidak valid!" })
      }

      let result
      try {
        result = await updateSewa((data) => {
          if (!data[gid]) throw new Error("Data grup berubah; silakan buka listsewa lagi")
          data[gid].expired = Number(data[gid].expired || Date.now()) + tambahan
          return {
            name: data[gid].name || gid,
            expired: data[gid].expired
          }
        })
      } catch (error) {
        return wafproject.sendMessage(idChat, { text: `❌ Gagal menambah sewa: ${error?.message || error}` })
      }

      const sisa = result.expired - Date.now()
      try {
        await wafproject.sendMessage(gid, {
          text:
            `📢 Masa sewa grup diperpanjang!\n\n` +
            `➕ Tambahan: *${args[1]}*\n` +
            `⏳ Sisa baru: *${formatDuration(sisa)}*`
        })
      } catch (error) {
        console.error(`[TAMBAHSEWA NOTIFY] ${gid}:`, error?.message || error)
      }

      return wafproject.sendMessage(idChat, {
        text:
          `✅ Berhasil menambah sewa.\n\n` +
          `Grup: *${result.name}*\n` +
          `Tambahan: *${args[1]}*\n` +
          `Sisa Baru: *${formatDuration(sisa)}*`
      })
    }

    case "delsewa": {
      if (!args[0]) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Gunakan: ${usedPrefix}delsewa <nomor> / <idgrup> / <link>`
        })
      }

      const read = readSewaResult({ allowCached: false })
      if (!read.ok) {
        return wafproject.sendMessage(idChat, {
          text: `❌ Database sewa gagal dibaca: ${read.error?.message || read.error}`
        })
      }

      let targetID = null
      let targetExists = false
      const arg = String(args[0])
      const linkMatch = arg.match(linkRegex)
      if (linkMatch) {
        try {
          const info = await wafproject.groupGetInviteInfo(linkMatch[1])
          targetID = groupIdFromInviteInfo(info)

          // Preview invite Zapo bisa tidak membawa JID. Cari record sewa berdasarkan
          // nama grup bila hasilnya unik.
          if (!targetID && info?.subject) {
            const matches = Object.entries(read.data).filter(([, row]) => {
              return String(row?.name || "").trim() === String(info.subject).trim()
            })
            if (matches.length === 1) targetID = matches[0][0]
          }
        } catch (error) {
          console.error("[DELSEWA INVITE ERROR]", error?.message || error)
          return wafproject.sendMessage(idChat, {
            text: `❌ Link tidak valid.\n\nError: ${error?.message || error?.output?.payload?.message || "Unknown Error"}`
          })
        }
      } else if (groupJidRegex.test(arg)) {
        targetID = arg
      } else if (/^\d+$/.test(arg)) {
        // Nomor harus sama persis dengan urutan yang tampil di listsewa.
        const pair = activeSewaEntries(read.data)[parseInt(arg, 10) - 1]
        if (pair) targetID = pair[0]
      }

      // Object key kosong dari bug versi lama tetap harus bisa dibersihkan lewat nomor list.
      targetExists = targetID !== null && Object.prototype.hasOwnProperty.call(read.data, targetID)
      if (!targetExists) {
        return wafproject.sendMessage(idChat, { text: "❌ Grup tidak ada di listsewa." })
      }

      if (isValidGroupJid(targetID)) {
        try {
          await wafproject.sendMessage(targetID, {
            text: "❌ Masa sewa dihapus oleh owner.\nBot akan keluar."
          })
          await wafproject.groupLeave(targetID)
        } catch (error) {
          console.error(`[DELSEWA LEAVE] ${targetID}:`, error?.message || error)
        }
      } else {
        console.warn(`[DELSEWA CLEANUP] Menghapus record sewa invalid tanpa leave: ${JSON.stringify(targetID)}`)
      }

      try {
        await updateSewa((data) => {
          delete data[targetID]
        })
      } catch (error) {
        return wafproject.sendMessage(idChat, { text: `❌ Gagal menghapus data sewa: ${error?.message || error}` })
      }

      return wafproject.sendMessage(idChat, {
        text: isValidGroupJid(targetID)
          ? "✅ Grup berhasil dihapus dari daftar sewa."
          : "✅ Data sewa rusak/pending berhasil dibersihkan dari daftar sewa."
      })
    }
  }
}

handler.help = ["addsewa", "tambahsewa", "delsewa"]
handler.category = ["owner"]
handler.command = ["addsewa", "tambahsewa", "delsewa"]
handler.owner = true

module.exports = handler

function parseDuration(str) {
  const input = String(str || "").trim().toLowerCase()
  if (!input) return null

  let total = 0
  let consumed = ""
  const regex = /(\d+)([dhms])/g
  let match

  while ((match = regex.exec(input)) !== null) {
    consumed += match[0]
    const num = parseInt(match[1], 10)
    const unit = match[2]
    if (unit === "d") total += num * 86400000
    if (unit === "h") total += num * 3600000
    if (unit === "m") total += num * 60000
    if (unit === "s") total += num * 1000
  }

  return consumed === input && total > 0 ? total : null
}

function formatDuration(ms) {
  ms = Math.max(0, Number(ms) || 0)
  const d = Math.floor(ms / 86400000)
  const h = Math.floor((ms % 86400000) / 3600000)
  const m = Math.floor((ms % 3600000) / 60000)
  const s = Math.floor((ms % 60000) / 1000)

  return [
    d ? `${d} Hari` : "",
    h ? `${h} Jam` : "",
    m ? `${m} Menit` : "",
    s ? `${s} Detik` : ""
  ].filter(Boolean).join(" ") || "0 Detik"
}
