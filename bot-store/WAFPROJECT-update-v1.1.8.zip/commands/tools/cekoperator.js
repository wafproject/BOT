/**
========================
🚀 WAF PROJECT — CEKOPERATOR V2 (SINGLE FILE / CJS)
🧑‍💻 Developer : ENZI
© 2025 — All Rights Reserved 🔒
========================
Identifikasi ALOKASI nomor Indonesia berdasarkan prefix (BUKAN HLR).
Tidak memakai lib proyek / npm install / database eksternal.
Update daftar referensi di MEMORI dari IAK & J-Tronik (best effort).
Fallback ke snapshot bawaan saat jaringan/situs referensi bermasalah.
Mode HLR (owner) opsional dan dapat dikenakan biaya jika dikonfigurasi.
*/
'use strict'

const UPDATE_INTERVAL_MS = 24 * 60 * 60 * 1000
const REFERENCE_TIMEOUT_MS = 12000
const REFERENCE_MAX_BYTES = 4_000_000
const NUSAKIT_TIMEOUT_MS = 9000
const BUILTIN_SNAPSHOT = '2026-10-27'
const REF_URLS = {
  iak: 'https://api.iak.id/api/prepaid/prefix-list',
  jtronik: 'https://j-tronik.com/harga.html'
}

// Referensi utama: daftar prefix prabayar IAK (snapshot). Prefix 6 digit by.U
// sengaja dicek lebih dulu daripada prefix umum 0851 milik Telkomsel.
const IAK_SNAPSHOT = {
  'Telkomsel': ['0812','0813','0852','0853','0821','0823','0822','0851'],
  'by.U': ['085154','085155','085156','085157','085158'],
  'Indosat IM3': ['0814','0815','0816','0855','0856','0857','0858'],
  'Tri (3)': ['0896','0897','0898','0899','0895'],
  'XL': ['0817','0818','0819','0859','0878','0877'],
  'AXIS': ['0838','0837','0831','0832'],
  'Smartfren': ['0881','0882','0883','0884','0885','0886','0887','0888']
}

// Referensi tambahan: daftar sekunder J-Tronik (10 September 2026).
// Prefix yang HANYA ada di sini ditandai indikasi, bukan kepastian.
const SECONDARY_SNAPSHOT = {
  'Telkomsel': ['0811','0812','0813','0821','0822','0823','0851','0852','0853'],
  'by.U': ['085154','085155','085156','085157','085161'],
  'Indosat IM3': ['0814','0815','0816','0855','0856','0857','0858'],
  'Tri (3)': ['0893','0894','0895','0896','0897','0898','0899'],
  'XL': ['0817','0818','0819','0859','0877','0878'],
  'AXIS': ['0830','0831','0833','0835','0838','0839'],
  'Smartfren': ['0810','0881','0882','0883','0884','0885','0886','0887','0888','0889']
}

// Prefix historis: 0879 pernah tercatat untuk XL dalam daftar nomor lama.
// Karena tidak muncul di daftar IAK terkini, selalu beri label HISTORIS.
const HISTORIC_SNAPSHOT = { 'XL': ['0879'] }

const GROUP_BY_OPERATOR = Object.freeze({
  'Telkomsel': 'Telkomsel',
  'by.U': 'Telkomsel',
  'Indosat IM3': 'Indosat Ooredoo Hutchison',
  'Tri (3)': 'Indosat Ooredoo Hutchison',
  'XL': 'XLSMART',
  'AXIS': 'XLSMART',
  'Smartfren': 'XLSMART'
})
const OPERATORS = Object.keys(GROUP_BY_OPERATOR)

const STATE_KEY = '__WAF_CEKOPERATOR_PREFIX_V2__'
const state = global[STATE_KEY] || {
  iak: IAK_SNAPSHOT,
  jtronik: SECONDARY_SNAPSHOT,
  updated: { iak: 0, jtronik: 0 },
  errors: { iak: '', jtronik: '' },
  inFlight: null,
  started: false
}
global[STATE_KEY] = state

function cleanPhone(input) {
  const raw = String(input ?? '').trim()
  if (!raw || raw.length > 40 || !/^\+?[\d\s().-]+$/.test(raw)) {
    return { valid: false, message: 'Format nomor HP tidak valid.' }
  }
  const digits = raw.replace(/\D/g, '')
  const local = digits.startsWith('62') ? `0${digits.slice(2)}`
    : digits.startsWith('08') ? digits
    : digits.startsWith('8') ? `0${digits}` : ''
  if (!/^08\d{8,11}$/.test(local)) {
    return { valid: false, message: 'Masukkan nomor seluler Indonesia 10–13 digit (08, 62, +62).' }
  }
  return { valid: true, number: local, e164: `+62${local.slice(1)}` }
}

function canonicalOperator(raw) {
  const name = String(raw || '').replace(/\s+/g, ' ').trim().toLowerCase()
  if (/^by\.?\s*u\b|^byu\b/.test(name)) return 'by.U'
  if (/^(?:telkomsel|telkom|tsel)\b/.test(name)) return 'Telkomsel'
  if (/^(?:indosat|im3)\b/.test(name)) return 'Indosat IM3'
  if (/^(?:tri\b|three\b|3\s*\()/.test(name)) return 'Tri (3)'
  if (/^xl\b/.test(name)) return 'XL'
  if (/^axis\b/.test(name)) return 'AXIS'
  if (/^(?:smart\s*fren|smartfren)\b/.test(name)) return 'Smartfren'
  return ''
}

function normalizeReferenceTable(table) {
  const result = {}
  for (const [name, prefixes] of Object.entries(table || {})) {
    if (!OPERATORS.includes(name) || !Array.isArray(prefixes)) continue
    const unique = [...new Set(prefixes.map(x => String(x).trim()).filter(x => /^08\d{2,4}$/.test(x)))]
    if (unique.length) result[name] = unique
  }
  return result
}

function buildEntries(table, source) {
  const entries = []
  for (const [operator, prefixes] of Object.entries(normalizeReferenceTable(table))) {
    for (const prefix of prefixes) {
      entries.push({ prefix, operator, source })
    }
  }
  return entries
}

function matchInSource(number, table, source) {
  return buildEntries(table, source)
    .filter(row => number.startsWith(row.prefix))
    .sort((a, b) => b.prefix.length - a.prefix.length)[0] || null
}

function getAllMatches(number) {
  const main = matchInSource(number, state.iak, 'IAK')
  const additional = matchInSource(number, state.jtronik, 'J-Tronik')
  const historical = matchInSource(number, HISTORIC_SNAPSHOT, 'Referensi historis')
  // Longest-prefix, lalu urutan kepercayaan: IAK > J-Tronik > historis.
  const all = [main, additional, historical].filter(Boolean)
  const winner = all.sort((a, b) => b.prefix.length - a.prefix.length)[0] || null
  const exactConfirmation = winner
    ? all.filter(row => row.prefix === winner.prefix && row.operator === winner.operator)
    : []
  const prefixConflict = Boolean(winner && all.some(row =>
    row.prefix === winner.prefix && row.operator !== winner.operator))
  const historicalOnly = Boolean(winner?.source === 'Referensi historis')
  const secondaryOnly = Boolean(winner?.source === 'J-Tronik' &&
    !exactConfirmation.some(row => row.source === 'IAK'))

  return { main, additional, historical, winner, secondaryOnly, historicalOnly,
    prefixConflict, exactConfirmation }
}

function analyzePhone(value) {
  const norm = cleanPhone(value)
  if (!norm.valid) return norm
  const matching = getAllMatches(norm.number)
  const winner = matching.winner
  const op = winner?.operator || 'Belum diketahui'
  const info = {
    ...norm,
    operator: op,
    group: GROUP_BY_OPERATOR[op] || '-',
    prefix: winner?.prefix || norm.number.slice(0, 4),
    known: Boolean(winner),
    confidence: !winner ? 'unknown' : matching.prefixConflict ? 'conflict'
      : matching.historicalOnly ? 'historical'
      : matching.secondaryOnly ? 'tentative' : 'listed',
    sources: matching.exactConfirmation.map(m => m.source),
    matches: matching,
    mode: 'offline'
  }
  info.note = !winner
    ? 'Prefix belum ditemukan dalam referensi. Jangan menganggap nomor tidak aktif.'
    : matching.prefixConflict
      ? 'Referensi saling bertentangan; provider perlu diperiksa manual.'
      : matching.historicalOnly
        ? 'Prefix tercatat di referensi historis, tidak ada di daftar IAK terkini.'
        : matching.secondaryOnly
          ? 'Indikasi dari referensi tambahan. Belum dikonfirmasi daftar utama IAK.'
          : 'Alokasi prefix, bukan informasi jaringan aktual atau bukti SIM aktif.'
  return info
}

function htmlDecode(raw) {
  return String(raw || '')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&#x27;/gi, "'")
    .replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([a-f\d]+);/gi, (_m, n) => String.fromCodePoint(parseInt(n, 16)))
}

function stripTags(raw) {
  return htmlDecode(String(raw || '').replace(/<[^>]*>/g, ' '))
    .replace(/\s+/g, ' ').trim()
}

// Baca baris TABLE publik (bukan mengandalkan posisi HTML/teks acak).
// Tidak mengeksekusi script HTML dan menolak daftar jika parsial/aneh.
function parseReferenceHtml(html, kind) {
  const source = String(html || '')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
  const rows = [...source.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)]
  const out = {}
  for (const row of rows) {
    const cells = [...row[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)]
      .map(match => stripTags(match[1]))
    if (cells.length < 2) continue
    const op = canonicalOperator(cells[0])
    if (!op) continue
    // Hanya ambil cell prefix, jangan dari deskripsi harga/paket.
    const maybePrefixes = cells[1].match(/\b08\d{2,4}\b/g) || []
    if (maybePrefixes.length < 2) continue
    out[op] = [...new Set([...(out[op] || []), ...maybePrefixes])]
  }
  const count = Object.values(out).flat().length
  if ((kind === 'iak' && (Object.keys(out).length < 6 || count < 30)) ||
      (kind === 'jtronik' && (Object.keys(out).length < 5 || count < 25))) {
    throw new Error('Daftar prefix gagal diparsing secara lengkap; snapshot lama dipertahankan.')
  }
  return normalizeReferenceTable(out)
}

async function loadReference(kind) {
  const url = REF_URLS[kind]
  const res = await fetch(url, {
    headers: { Accept: 'text/html,application/xhtml+xml' },
    signal: AbortSignal.timeout(REFERENCE_TIMEOUT_MS),
    redirect: 'follow'
  })
  const target = new URL(res.url || url)
  if (target.hostname !== new URL(url).hostname || target.protocol !== 'https:') {
    throw new Error('Referensi melakukan redirect ke domain lain.')
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  if (Number(res.headers.get('content-length') || 0) > REFERENCE_MAX_BYTES) {
    throw new Error('Dokumen sumber terlalu besar.')
  }
  const html = await res.text()
  if (html.length > REFERENCE_MAX_BYTES) throw new Error('Dokumen sumber terlalu besar.')
  return parseReferenceHtml(html, kind)
}

async function updateReferences() {
  if (state.inFlight) return state.inFlight
  state.inFlight = (async () => {
    const results = await Promise.allSettled(['iak', 'jtronik'].map(loadReference))
    let refreshed = 0
    for (let i = 0; i < results.length; i++) {
      const key = i === 0 ? 'iak' : 'jtronik'
      const r = results[i]
      if (r.status === 'fulfilled') {
        state[key] = r.value
        state.updated[key] = Date.now()
        state.errors[key] = ''
        refreshed++
      } else {
        state.errors[key] = String(r.reason?.message || r.reason || 'Gagal').slice(0, 180)
      }
    }
    return { refreshed, errors: { ...state.errors } }
  })().finally(() => { state.inFlight = null })
  return state.inFlight
}

// Pembaruan otomatis setiap 24 jam; timer non-blocking, tidak menyentuh
// settings.js, DB user, atau file eksternal. Reload: tetap satu scheduler.
if (!state.started) {
  state.started = true
  if (typeof fetch === 'function' && process.env.CEKOPERATOR_AUTOUPDATE !== 'false') {
    const startup = setTimeout(() => {
      void updateReferences().catch(err => console.warn('[CEKOPERATOR UPDATE]', err.message))
    }, 8000)
    if (startup.unref) startup.unref()
    state.timer = setInterval(() => {
      void updateReferences().catch(err => console.warn('[CEKOPERATOR UPDATE]', err.message))
    }, UPDATE_INTERVAL_MS)
    if (state.timer.unref) state.timer.unref()
  }
}

// HLR live bersifat OPSIONAL, khusus owner. Tidak pernah dipakai untuk mode biasa.
function hlrEnabled() {
  return process.env.CEKOPERATOR_ALLOW_HLR === 'true' &&
    Boolean(process.env.HLR_API_KEY && process.env.HLR_API_SECRET)
}
const hlrCache = new Map()
const hlrFlights = new Map()
async function lookupHlr(phone) {
  const basic = analyzePhone(phone)
  if (!basic.valid) return basic
  if (!hlrEnabled()) throw new Error('Mode HLR belum dikonfigurasi.')
  if (typeof fetch !== 'function') throw new Error('Node.js 18+ diperlukan.')
  const key = basic.e164
  const prev = hlrCache.get(key)
  if (prev && prev.until > Date.now()) return { ...prev.data, fromCache: true }
  if (hlrFlights.has(key)) return hlrFlights.get(key)
  const task = (async () => {
    const response = await fetch('https://api.hlrlookup.com/apiv2/hlr', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        api_key: process.env.HLR_API_KEY,
        api_secret: process.env.HLR_API_SECRET,
        requests: [{ telephone_number: basic.e164.slice(1), cache_days_private: 1 }]
      }),
      signal: AbortSignal.timeout(18000)
    })
    if (!response.ok) throw new Error(`HLR HTTP ${response.status}`)
    const data = await response.json()
    const item = data?.body?.results?.[0]
    if (!item || String(item.error || '').toUpperCase() !== 'NONE') {
      throw new Error('HLR tidak memberikan respons terverifikasi.')
    }
    const network = String(item.current_network_details?.name || '').trim()
    const raw = String(item.live_status || '').toUpperCase()
    const liveStatus = raw === 'LIVE' ? 'active'
      : ['DEAD', 'INACTIVE', 'NOT_LIVE'].includes(raw) ? 'inactive' : 'unknown'
    const result = { ...basic, mode: 'hlr', network, liveStatus,
      note: 'Data HLR bergantung pada kemampuan operator dan penyedia layanan.' }
    if (hlrCache.size >= 200) hlrCache.delete(hlrCache.keys().next().value)
    hlrCache.set(key, { data: result, until: Date.now() + 60 * 60 * 1000 })
    return result
  })().finally(() => hlrFlights.delete(key))
  hlrFlights.set(key, task)
  return task
}

// Cek silang opsional memakai API Nusakit, BUKAN pengganti HLR.
async function crossCheckNusakit(phone) {
  const url = 'https://nusakit.my.id/v1/phone/operator?phone=' + encodeURIComponent(phone)
  const res = await fetch(url, {
    headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(NUSAKIT_TIMEOUT_MS)
  })
  if (!res.ok) throw new Error(`Nusakit HTTP ${res.status}`)
  const body = await res.json()
  if (body?.success !== true || body?.data?.valid !== true || !body?.data?.operator) {
    throw new Error('Nusakit tidak mengenali nomor ini.')
  }
  return String(body.data.operator).trim()
}

function wib(ts) {
  return new Date(ts).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) + ' WIB'
}
function fmtDate(ts) { return ts ? wib(ts) : `Snapshot ${BUILTIN_SNAPSHOT}` }

function formatResult(info) {
  if (!info.valid) return `❌ ${info.message}`
  const label = info.confidence === 'tentative' ? `${info.operator} (indikasi)`
    : info.confidence === 'historical' ? `${info.operator} (historis)`
      : info.confidence === 'conflict' ? `${info.operator} (berbeda antar sumber)`
        : info.operator
  const sources = info.sources.length ? info.sources.join(' + ')
    : (info.known ? 'Referensi tambahan' : 'Tidak ada')
  const mode = info.mode === 'hlr' ? 'HLR live' : 'Database prefix'
  const extra = info.mode === 'hlr' ?
    `\n📶 *Jaringan HLR* : ${info.network || 'Tidak diketahui'}` +
    `\n📱 *Status SIM* : ${info.liveStatus === 'active' ? 'Terindikasi aktif' : info.liveStatus === 'inactive' ? 'Terindikasi tidak aktif' : 'Tidak diketahui'}` : ''
  return `📱 *CEK PROVIDER NOMOR*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `📞 *Nomor* : ${info.number}\n` +
    `🌐 *Internasional* : ${info.e164}\n` +
    `📡 *Alokasi* : ${label}\n` +
    `🏢 *Grup jaringan* : ${info.group}\n` +
    `🔢 *Prefix* : ${info.prefix}\n` +
    `📚 *Referensi* : ${sources}\n` +
    `🔎 *Metode* : ${mode}${extra}\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `ℹ️ ${info.note}`
}

function formatDatabaseStatus() {
  const count = table => Object.values(table || {}).reduce((sum, arr) => sum + arr.length, 0)
  return `📚 *STATUS DATABASE PREFIX*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `📘 IAK : ${count(state.iak)} prefix\n` +
    `🕒 IAK : ${fmtDate(state.updated.iak)}\n` +
    `📗 J-Tronik : ${count(state.jtronik)} prefix\n` +
    `🕒 J-Tronik : ${fmtDate(state.updated.jtronik)}\n` +
    `🔄 Pembaruan : ${process.env.CEKOPERATOR_AUTOUPDATE === 'false' ? 'Manual' : 'Otomatis 24 jam'}\n` +
    `📖 Prefix historis 0879 (XL)\n` +
    `📌 Prefix sumber tambahan bisa berstatus indikasi.\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `ℹ️ Semua ini data alokasi, bukan pengecekan SIM aktif.`
}

async function plugin(m, { wafproject, args, text, usedPrefix, command, isOwner, isROwner } = {}) {
  if (!/^cekoperator$/i.test(String(command || '')) || !wafproject || !m?.chat) return
  const raw = (Array.isArray(args) && args.length ? args.join(' ') : String(text || '')).trim()
  const pfx = usedPrefix || '.'
  const reply = message => wafproject.sendMessage(m.chat, { text: String(message) }, { quoted: m })
  const react = emoji => wafproject.sendMessage(m.chat, { react: { text: emoji, key: m.key } }).catch(() => {})
  const owner = Boolean(isOwner || isROwner)

  if (!raw) {
    return reply(`📱 *CEKOPERATOR V2*\n` +
      `• ${pfx}cekoperator 081234567890\n` +
      `• ${pfx}cekoperator daftar\n` +
      `• ${pfx}cekoperator banding 081234567890\n` +
      `• ${pfx}cekoperator update (owner)\n` +
      `• ${pfx}cekoperator live 081234567890 (owner, HLR berbayar)`)
  }

  const [action, ...parts] = raw.split(/\s+/)
  const cmd = action.toLowerCase()
  if (['daftar', 'db', 'database', 'sumber', 'status'].includes(cmd)) {
    return reply(formatDatabaseStatus())
  }
  if (cmd === 'update') {
    if (!owner) return reply('❌ Update referensi hanya untuk owner.')
    if (typeof fetch !== 'function') return reply('❌ Fitur update memerlukan Node.js 18+.')
    await react('🔎')
    const result = await updateReferences()
    await react(result.refreshed ? '✅' : '⚠️')
    return reply(`${result.refreshed ? '✅' : '⚠️'} *PEMBARUAN DATABASE*\n` +
      `Sumber berhasil: ${result.refreshed}/2\n` +
      `${result.errors.iak ? `IAK: ${result.errors.iak}\n` : ''}` +
      `${result.errors.jtronik ? `J-Tronik: ${result.errors.jtronik}\n` : ''}` +
      `Database cadangan tetap tersedia.\n\n${formatDatabaseStatus()}`)
  }

  const isLive = cmd === 'live'
  const isCompare = cmd === 'banding' || cmd === 'compare'
  const phone = isLive || isCompare ? parts.join(' ') : raw
  const info = analyzePhone(phone)
  if (!info.valid) return reply(formatResult(info))
  if (isLive && !owner) return reply('❌ Mode HLR live hanya untuk owner dan bisa berbayar.')
  if (isLive && !hlrEnabled()) {
    return reply('⚠️ HLR belum dikonfigurasi. Tanpa *live*, pemeriksaan prefix tetap gratis.')
  }

  await react('🔎')
  try {
    if (isLive) {
      const live = await lookupHlr(phone)
      await reply(formatResult(live))
    } else if (isCompare) {
      const local = formatResult(info)
      let extra
      try {
        const fromNusakit = await crossCheckNusakit(info.number)
        const localNormalized = canonicalOperator(info.operator)
        const remoteNormalized = canonicalOperator(fromNusakit)
        const same = Boolean(localNormalized && remoteNormalized && localNormalized === remoteNormalized)
        extra = `\n\n🔍 *CEK SILANG NUSAKIT*\n` +
          `📡 Nusakit : ${fromNusakit}\n` +
          `🧩 Kecocokan : ${same ? '✅ Sama' : '⚠️ Beda / tidak bisa dibandingkan'}\n` +
          `ℹ️ Ini tetap perbandingan hasil deteksi prefix, bukan HLR.`
      } catch (error) {
        extra = `\n\n⚠️ Nusakit gagal: ${String(error?.message || error).slice(0, 120)}\nData offline tetap bisa digunakan.`
      }
      await reply(local + extra)
    } else {
      await reply(formatResult(info))
    }
    await react('✅')
  } catch (error) {
    console.error('[CEKOPERATOR ERROR]', error?.message || error)
    await react('❌')
    return reply(`⚠️ Pengecekan gagal: ${String(error?.message || error).slice(0, 150)}`)
  }
}

plugin.command = ['cekoperator']
plugin.category = 'stalk'
plugin.description = 'Cek alokasi provider Indonesia; referensi 2 sumber, pembaruan, cek silang (1 file).'
module.exports = plugin
